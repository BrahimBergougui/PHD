# references_todo.md (reference-manager, build mode, 2026-09-28)

File built: `bib/references.bib`.
Sources used: `summaries/P01.bib` to `P25.bib` and the "## Citation" section of each `summaries/PNN.md`; the author lines in `papers/paper_17.md`, `paper_22.md`, `paper_14.md`, `paper6.md`, `paper13.md`, `paper_25.md`, `paper5.md`; the Note de Synthèse bibliography (`source/Note_de_Synthese.pdf`, pp. 23-25) and mapping table (p. 3); the reference lists in `source/txt/General_Introduction.txt`, `Chapter_1.txt`, `Chapter_2.txt` (section 2.9), `Chapter3.txt`, `Chapter4.txt`, `Chapter5.txt`. `Conclusion.txt` has no reference list.
No web search was used. No DOI, volume, issue, page range or year was added unless a source printed it.

Parse check: BibTeX 0.99e with `plainnat` on a `\nocite{*}` test document ran with 84 entries, 0 errors and one warning ("empty year in bergougui2026automation", expected, see section 6). Braces are balanced, there are no duplicate keys, and there is no unescaped `&` or `%`.

## (i) Portfolio: P01-P25 and final key

| Paper | Final key | Entry type |
|---|---|---|
| P01 | `bergougui2025assessing` | article |
| P02 | `bergougui2025artificialadvance` | article |
| P03 | `bergougui2025institutional` | article |
| P04 | `bergougui2025industrial` | article |
| P05 | `bergougui2025ecoefficiency` | article |
| P06 | `bergougui2026robots` | article |
| P07 | `bergougui2026heterogeneous` | article |
| P08 | `bergougui2024moving` | article |
| P09 | `bergougui2024asymmetricimpact` | article |
| P10 | `bergougui2024asymmetricnexus` | article |
| P11 | `bergougui2024algerias` | article |
| P12 | `bergougui2024investigating` | article |
| P13 | `meziane2026aggregate` | article |
| P14 | `bergougui2025benefits` | article |
| P15 | `bergougui2025artificialmitigate` | article |
| P16 | `bergougui2025income` | article |
| P17 | `bergougui2024institutional` | article |
| P18 | `bergougui2024impact` | article |
| P19 | `dogan2025unveiling` | article |
| P20 | `bergougui2025secure` | article |
| P21 | `benali2025climate` | article |
| P22 | `bergougui2026hightech` | article |
| P23 | `bergougui2026industrial` | article |
| P24 | `bergougui2026automation` | unpublished |
| P25 | `bergougui2026shock` | article |

## (ii) Key changes and merges

### Key changes

| Paper | Key in summaries/*.bib | Final key | Reason |
|---|---|---|---|
| P02 | `bergougui2025artificial` | `bergougui2025artificialadvance` | Collision with P15 (orchestrator instruction) |
| P15 | `bergougui2025artificial` | `bergougui2025artificialmitigate` | Collision with P02 (orchestrator instruction) |
| P09 | `bergougui2024asymmetric` | `bergougui2024asymmetricimpact` | Collision with P10 (orchestrator instruction) |
| P10 | `bergougui2024asymmetric` | `bergougui2024asymmetricnexus` | Collision with P09 (orchestrator instruction) |
| P24 | `bergougui_nd_mitigating` | `bergougui2026automation` | Official title and key given by orchestrator; old key broke the lowercase-ASCII rule (underscores, "nd") |
| P20 | `bergougui2025towards` | `bergougui2025secure` | Consistency check (my decision). P05 ("Towards eco-efficiency ...") skips "Towards" as a non-significant preposition and uses `ecoefficiency`. P20 ("Towards secure energy systems ...") is treated the same way. Using "towards" for both would have produced two `bergougui2025towards` keys. |

The other 19 portfolio keys follow the rule (first author + year + first significant title word) and are unique. The same stop-word convention is applied throughout: articles, prepositions, and leading question words or auxiliaries are skipped. So "How income ..." gives `income`, "How do institutional ..." gives `institutional`, "When Do Robots ..." gives `robots`, "When does high-tech ..." gives `hightech`, and "Who Benefits ..." gives `benefits`.
`bergougui2024institutional` (P17) and `bergougui2025institutional` (P03) are distinct because the years differ. The same applies to `bergougui2025industrial` (P04) and `bergougui2026industrial` (P23).
P24 does not strictly follow the rule, because it has a year in the key but no year field. This is the orchestrator's instruction.

### Author and field fixes in portfolio entries

- P13: the paper prints the second author reversed as "Bergougui Brahim" (p. 1) and "B. Brahim" (running header). The entry now reads `Meziane, Said and Bergougui, Brahim`, following the orchestrator instruction. This also matches the Note de Synthèse and the chapter lists.
- P17 and P22: the summaries' .bib files gave initials only. The papers print full names (papers/paper_17.md, paper_22.md), so full names were used: Brahim Bergougui, Reda Hamza Boudjana, Samer Mehibel, Manuel A. Zambrano-Monserrate, Sudeshna Ghosh, Buhari Doğan, Ahmed Samour, Rabindra Nepal. With these forms, each author has one form across all entries.
- P14: `Do{\u{g}}an` was normalised to UTF-8 `Doğan`, as in P18, P19 and P22.
- P24: the title is "When Does Automation Secure Energy?". The type is `@unpublished`, with no year field. The note is exactly `Under review. NEEDS VERIFICATION: manuscript title differs; year not printed`. A comment above the entry records the manuscript title, the journal and the submission ID.
- P07: `number = {3}` is kept from P07.bib. The issue number appears only in the Wiley download stamp in the page margin, not in the article header.
- Proper nouns and acronyms in titles are braced ({Algeria}, {OECD}, {G7}, {MENA}, {FDI}, {COP28}, {SDGs}, {NARDL}, {Fourier}, {ARDL}, {PVAR-GMM}, {AI}, {Chinese}) so that `plainnat` does not lowercase them. P08 "CO2" is written as `{CO$_2$}`.

### Merges (one entry per work)

- Pre-existing entries kept: `chancel2015carbon` (merged with the Chancel and Piketty 2015 entries in the General Introduction, Chapter 1, Chapter 5 and the Note de Synthèse, adding `month = nov` from the Note de Synthèse) and `ipcc2023synthesis` (kept unchanged; it is cited in `chapters/ch00_introduction.tex`).
- Portfolio: for each P01-P25, the summary .bib, the Note de Synthèse bibliography entry (21 portfolio works are listed there; P06-P25 numbering as in the mapping table) and the chapter-list entries (Chapter 2: 13 works; Chapter 3: 5; Chapter 4: 7; Chapter 5: 25) were merged into one entry. The paper's printed details are kept.
- External works listed in more than one source were merged into one entry each. Codes: N = Note de Synthèse, 1 = Chapter 1, 5 = Chapter 5, G = General Introduction.
  - N+1+5: `aghion2016carbon`, `boyce1994inequality`, `enders2012unit`, `folke2005adaptive`, `grossman1995economic`, `hansen1999threshold`, `lenton2008tipping`, `rockstrom2009safe`, `scheffer2001catastrophic`, `shin2014modelling`, `sim2015oil`, `sovacool2020decarbonisation`
  - N+1+5+G: `chancel2015carbon`
  - N+1+G: `ipcc2023climate`
  - N+1: `acemoglu2020robots`, `bridge2013geographies`, `brynjolfsson2014second`, `pesaran2012autoregressive`, `rolnick2022tackling`, `strubell2020energy`, `wooldridge2010econometric`
  - 1+5: `acemoglu2012environment`, `arthur1999complexity`, `chancel2022global`, `cherp2014concept`, `koenker1978regression`, `machado2019quantiles`, `mccauley2018just`, `north1990institutions`, `ostrom2009general`, `popp2002induced`, `porter1995toward`, `sovacool2011conceptualizing`, `stern2004rise`
  - Single source (Chapter 1 only): `ambec2013porter`, `bhaskar1975realist`, `blundell1998initial`, `broock1996test`, `driscoll1998consistent`, `dumitrescu2012testing`, `goldsmithpinkham2020bartik`, `grinsted2004application`, `grunewald2017tradeoff`, `johnstone2010renewable`, `lange2020digitalization`, `lawson1997economics`, `levinson2008unmasking`, `love2006financial`, `masanet2020recalibrating`, `oswald2020large`, `pesaran2007simple`, `pesaran2008testing`, `pesaran2021general`, `sorrell2009jevons`, `torrence1998practical`, `vinuesa2020role`, `westerlund2007testing`
  - Single source (Note de Synthèse only): `mcwilliams2022preparing`
- DOIs for external works come only from the Note de Synthèse, where they are printed. Entries that appear only in Chapter 1 have no DOI because none is printed there.
- Candidate's non-portfolio works: none are cited in any reference list or in the chapter texts. For example, Bergougui and Meziane (2025, Sustainability) does not appear in any source, so no entry was added. The excluded "paper 26" (Bergougui 2027, Energy Policy) is also absent.

## (iii) Entries marked NEEDS VERIFICATION (11)

| Key | Reason |
|---|---|
| `bergougui2025artificialadvance` (P02) | The paper (early view) prints 2025 and pp. 1-23, with no volume. The Note de Synthèse gives 34(S2), 222-244 (year 2025). Chapters 2 and 5 give 2026, 34(S2), 222-244. The final issue data need confirming before the paper's details are replaced. |
| `bergougui2026robots` (P06) | Early view: volume printed as 0, no issue. The final volume and pages are unknown. |
| `bergougui2025benefits` (P14) | Early view: volume printed as 0, no issue. The final volume and pages are unknown. |
| `bergougui2024impact` (P18) | Online-first: no volume, issue or pages in the paper or in any list. |
| `benali2025climate` (P21) | The paper (early view) prints 2025 and pp. 1-25, with no volume. CLAUDE.md states Sustainable Development 34(1). No source gives the issue pages. |
| `bergougui2026automation` (P24) | The manuscript title differs from the official title. No year is printed. The submission venue is also uncertain (see iv). |
| `bergougui2026shock` (P25) | Online-first: volume and issue printed as 0(0). The final volume and pages are unknown. |
| `chancel2015carbon` | The sources give only the institution. The Note de Synthèse adds "November, 48pp.". No report number or URL is printed. |
| `ipcc2023climate` | All lists print the year 2023 for a title dated 2021. The Note de Synthèse uses "Climate Change 2021 – The Physical Science Basis" and the chapters use a colon. The publication year of the cited edition needs confirming. |
| `ipcc2023synthesis` | Pre-existing entry that is not in any source list. The sources cite the WG I report (`ipcc2023climate`). It is cited in ch00_introduction.tex. Decide which IPCC report the introduction means. |
| `mcwilliams2022preparing` | Only the Note de Synthèse lists it, as "Bruegel Blog, 28.". The meaning of "28" and the URL are unknown. No chapter list includes it. |

## (iv) Disagreements between the Note de Synthèse, the chapter lists and the papers

In every case the entry follows what the paper prints.

### Portfolio

| Paper | Paper prints | Note de Synthèse | Chapter lists |
|---|---|---|---|
| P02 | 2025; Sustainable Development 0:1-23 (early view) | 2025b; 34(S2), 222-244 | Ch2, Ch5: **2026**; 34(S2), 222-244 |
| P07 | **2026**; 50(3), 1299-1319 | **2025**; n/a(n/a), no pages; in-text also "Bergougui & Murshed, 2025" (section 3.3.1) | Ch2, Ch5: 2026; 50, 1299-1319 (no issue) |
| P15 | 25, 1316-1336 | No volume or pages | Ch3, Ch5: 25, 1316-1336 |
| P13 | Authors "Said Meziane, Bergougui Brahim" (reversed) | Meziane, S., & Bergougui, B. | Same as Note de Synthèse |
| P14, P21 | Early view pagination 1-21 and 1-25 | n/a(n/a) | No volume |
| P21 | Early view, no volume | n/a(n/a) | No volume. CLAUDE.md gives 34(1) (source not stated) |
| P23 | Energy Nexus 23, 100760 (2026), "Industrial robots and energy security risk ..." | Mapping table no. 22: "Robots for secure energy systems: AI impact on energy security risk", **With Editor (Energy & Environment)**. Not in the bibliography | Ch4, Ch5: Energy Nexus, matches the paper |
| P24 | Manuscript: "Mitigating Energy Vulnerability with Industrial Robotics ...", Energy Sources, Part B, ID 269271714, no year | Mapping table no. 21: "When Does Automation Secure Energy? Industrial Robotics on Energy Vulnerability", **With Editor (Journal of Innovation & Knowledge)**. Not in the bibliography | Ch4, Ch5: manuscript title, Energy Sources, Part B |
| P09 | "Algeria's Ecological Future" (capitalised) | Same as paper | Ch2, Ch5: "ecological future" (lowercase). Trivial |
| P03, P04 | n/a | Letter suffixes: 2025c = P04, 2025d = P03 | Ch5: 2025b = P04, 2025c = P03. Irrelevant to BibTeX; natbib assigns its own suffixes |
| Numbering | n/a | Mapping table: 21 = automation (P24), 22 = robots-ESR (P23), 23 = Ben Ali (P21), 24 = high-tech R&D (P22) | Ch5 tags follow CLAUDE.md (P21 Ben Ali, P22 ECMX, P23 Energy Nexus, P24 manuscript) |
| Count | n/a | "23 peer-reviewed publications and 2 manuscripts with editor" | CLAUDE.md: 24 published + 1 under review. The P23 paper confirms publication |

### External works

- **IPCC**: all sources give "IPCC (2023). Climate Change 2021: The Physical Science Basis. CUP" (Note de Synthèse also gives DOI 10.1017/9781009157896). The pre-existing `ipcc2023synthesis` (Synthesis Report, IPCC, Geneva) is a different report. Both are kept.
- **Aghion et al. 2016**: the Note de Synthèse prints "Dechezleprêtre, Hémous"; Chapters 1 and 5 print "Dechezlepretre, Hemous". The accented form is used.
- **Rockström et al. 2009**: the Note de Synthèse and Chapter 5 print "Rockström, Persson Å."; Chapter 1 prints "Rockstrom, Persson A.". The accented form is used.
- **Pesaran and Shin 2012**: editor "Strøm" in the Note de Synthèse, "Strom" in Chapter 1. "Strøm" is used.
- **Shin, Yu and Greenwood-Nimmo 2014**: the Note de Synthèse gives "Springer New York" and has a reference-manager export artefact ("BT -") in the title; Chapters 1 and 5 give "Springer". The entry uses Springer, New York.
- **Chancel and Piketty 2015**: only the Note de Synthèse adds "November, 48pp.".
- **Acemoglu and Restrepo 2020**: "us labor markets" in the Note de Synthèse, "US" in Chapter 1. "{US}" is used.
- **Rolnick et al. 2022**: "ACM Computing Surveys (CSUR)" in the Note de Synthèse, "ACM Computing Surveys" in Chapter 1. The latter is used.
- **Folke et al. 2005**: the title is in capitals in the Note de Synthèse and in sentence case elsewhere. Sentence case is used.
- **Enders and Lee 2012**: "fourier" in the Note de Synthèse, "Fourier" elsewhere. "{Fourier}" is used.
- **Brynjolfsson and McAfee 2014**: "WW Norton & company" in the Note de Synthèse, "W. W. Norton" in Chapter 1. "W. W. Norton" is used.
- **McWilliams et al. 2022**: listed only in the Note de Synthèse (cited in its section 1.2). It is absent from all chapter lists.
- The Note de Synthèse lists 22 external works and Chapter 1 lists 57. All 22 in the Note de Synthèse except McWilliams et al. are also in Chapter 1. The Chapter 5 and General Introduction lists add no new external works.

## (v) Counts

| Category | Count |
|---|---|
| Total entries in bib/references.bib | 84 |
| Portfolio (P01-P25) | 25 (24 @article, 1 @unpublished) |
| External | 59 (includes the 2 pre-existing entries) |
| NEEDS VERIFICATION | 11 (7 portfolio, 4 external) |

## 6. Open problems for the orchestrator

1. **P24 has no year.** `plainnat` prints the citation as "Bergougui ()", and BibTeX warns "empty year". This follows the instruction, but before the build either add `year = {n.d.}` (or "under review") or cite it with `\citeauthor` plus text. The venue is also unresolved: the Note de Synthèse says Journal of Innovation & Knowledge, while the manuscript and chapters say Energy Sources, Part B. The candidate should confirm.
2. **`ipcc2023synthesis` vs `ipcc2023climate`.** ch00_introduction.tex cites the Synthesis Report, but every source list cites the WG I report. Decide which one the introduction needs. If only the WG I report is needed, drop `ipcc2023synthesis`.
3. **P02 and P21 final issue data.** Other sources report issue data (34(S2), 222-244 for P02; 34(1) for P21) that the early-view PDFs cannot confirm. The candidate should supply the final version, or confirm it, before the entry is changed.
4. **Note de Synthèse errors to correct in that document** (not in the .bib): P07 year 2025, mapping-table entries 21-24 (numbering, P23 shown as "With Editor" although it is published), and the portfolio count 23+2.
5. External works that appear only in Chapter 1 have no DOIs. None were added, because none were printed.
