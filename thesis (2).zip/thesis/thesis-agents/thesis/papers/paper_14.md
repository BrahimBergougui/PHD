Sustainable Development




   RESEARCH ARTICLE                     OPEN ACCESS




Who Benefits From Green Tech? How Eco-­Innovation and
Process Eco-­Innovation Shape Emissions Inequality Across
G7 Economies
Brahim Bergougui1,2,3 | Buhari Doğan4,5,6,7 | Emmanuel Yamoah Cobbold8                                  | Hayet Soltani9          |
Hamid Ghazi H Sulimany   10   | Ehab Ebrahim Mohamed Ebrahim11,12

1International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
                                                                                                         | 2National Higher School of Statistics and
Applied Economics (ENSSEA), Kolea, Algeria |       3College of Business and Economics, Qatar University, Doha, Qatar
                                                                                                                  | 4Department of Economics,
                                                5
Suleyman Demirel University, Isparta, Turkey | Institute for Statistical Studies and Economics of Knowledge, National Research University Higher School
of Economics, Moscow, Russia | 6Applied Science Research Center, Applied Science Private University, Amman, Jordan | 7Economic Research Center
(WCERC), Western Caspian University, Baku, Azerbaijan | 8Ulster University, Birmingham Campus, Birmingham, UK | 9Department of Finance, Faculty
of Economics and Management of Sfax, Laboratory LEG, University of Sfax, Sfax, Tunisia | 10Accounting Department, Business Administration College,
Taif University, Taif, Saudi Arabia | 11Department of Economics, College of Business, Imam Mohammad Ibn Saud Islamic University (IMSIU), Riyadh,
Saudi Arabia | 12Department of Economics, Faculty of Commerce, Kafrelsheikh University, Kafrelsheikh, Egypt

Correspondence: Brahim Bergougui (bergougui@iss.nl; brahimbergougui@gmail.com)

Received: 3 October 2025 | Revised: 18 November 2025 | Accepted: 25 November 2025

Keywords: asymmetric effects | CO2 emissions inequality | eco-­innovation | G7 economies | green technology | MMQR | process eco-­innovation


  ABSTRACT
  This study examines the asymmetric effects of eco-­innovation on income-­based carbon emissions inequality within G7 econ-
  omies over the period 1990–2023. Theoretically grounded in innovation diffusion theory and political economy frameworks,
  we argue that green technological advancements exert non-­linear, directional effects on emissions inequality due to differen-
  tial adoption patterns across income groups, elite capture mechanisms, and path-­dependent lock-­in effects. Unlike prior re-
  search that conflates eco-­innovation types or focuses solely on aggregate emissions, we distinguish between comprehensive
  eco-­innovation (ECON) and process-­oriented eco-­innovation (ECOP), examining their separate positive and negative shocks on
  emissions inequality—measured as per capita CO2 emissions of the wealthiest 10% of the population. Employing the method of
  moments quantile regression (MMQR) with asymmetric specifications, we provide novel evidence that increases and decreases
  in eco-­innovation produce differential distributional impacts across the emissions inequality spectrum. Our findings reveal that
  while eco-­innovation expansion reduces emissions inequality in low-­inequality contexts, its benefits are asymmetrically con-
  centrated among affluent groups in high-­inequality settings, with process eco-­innovation showing heterogeneous effects across
  quantiles and innovation directions. These results underscore the critical need for differentiated policy interventions that ensure
  green technological transitions promote both environmental sustainability and social equity, preventing the entrenchment of
  carbon privilege among wealthy populations.


1   |   Introduction                                                                rate, and natural disasters becoming more frequent and se-
                                                                                    vere, (Fuso Nerini et al. 2019; Jha and Dev 2024; Singh 2021;
The contemporary world is confronting an unprecedented                              Xu, Wang, et al. 2022, Xu, Wang, et al. 2022; Guo et al. 2025;
climate crisis, with global temperatures rising at an alarming                      Hong et al. 2025). The magnitude of these issues and their



This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium,
provided the original work is properly cited.
© 2025 The Author(s). Sustainable Development published by ERP Environment and John Wiley & Sons Ltd.


Sustainable Development, 2025; 0:1–21                                                                                                                         1
https://doi.org/10.1002/sd.70525
                                                                                                                                            10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
widespread effects are global, presenting significant chal-          between R&D efforts and emissions levels changes across dif-
lenges to the survival and progress of humanity. In fact, cli-       ferent historical periods.
mate change stands as a profound crisis in modern society,
with consequences that extend across the globe. Increasing           Despite extensive research linking innovation, globalization,
heat levels, unpredictable severe weather, and evolving natu-        and economic growth to environmental outcomes, limited at-
ral habitats are reshaping communities everywhere (Griscom           tention has been paid to how these dynamics influence the un-
et al. 2017; Kaldellis et al. 2007; Li, Zhang, et al. 2023;          even distribution of emissions across regions, sectors, or income
Jauregui et al. 2026). More precisely, climate change inequal-       groups, that is, carbon emissions inequality. Existing studies
ity refers to the disproportionate impact of climate change on       focus on aggregate emission levels, thereby overlooking dispar-
different regions, sectors, and social groups, with the most         ities in how green technologies and economic activities affect
vulnerable populations often bearing the brunt of its effects.       different parts of the economy and society. Moreover, previous
This inequality is compounded by development levels, socio-­         studies do not distinguish between eco-­innovation and process-­
economic, geographical, and political factors, meaning that          oriented eco-­ innovation, despite their potentially divergent
while some regions and communities may be able to adapt and          implications for environmental quality and equity. Addressing
recover from climate-­related disruptions, others face more se-      these omissions, this study examines the heterogeneous impacts
vere and persistent challenges. Addressing climate change is         of eco-­innovation and process eco-­innovation on carbon emis-
crucial not only for protecting the environment but also for         sions inequality in G7 economies, thereby extending current
tackling growing inequality. Efforts to combat climate change        understanding of how various measures of green technological
must not exacerbate existing social and economic disparities         progress can promote both environmental sustainability and so-
(Costa et al. 2024).                                                 cial inclusiveness.

A crucial aspect of this initiative is lowering CO2 emissions.       This study addresses this gap and makes several distinctive con-
Between the 19th and 20th centuries, global CO2 levels expe-         tributions to the existing body of knowledge on green innovation
rienced a significant rise of 30%, highlighting the urgency of       and climate inequality. First, we advance the theoretical under-
addressing this issue (Akram et al. 2023). In this context, eco-­    standing of eco-­innovation by providing a comprehensive dis-
innovation (ECON) has emerged as a strategic approach aimed          aggregated analysis that distinguishes between eco-­innovation
at reducing environmental degradation and promoting long-­           and process eco-­innovation, examining their potentially diver-
term sustainability. Indeed, the adoption of eco-­innovation has     gent effects on emissions inequality. This approach transcends
demonstrated significant potential in curbing air pollution,         the conventional treatment of green innovation as a monolithic
minimizing waste, and optimizing the use of material resources       construct and reveals the nuanced mechanisms through which
(Akram et al. 2023; Chien et al. 2022). Recent research indi-        different innovation types influence environmental outcomes.
cates that eco-­innovations serve a dual purpose in reducing the     Second, we introduce a novel analytical framework that shifts
environmental footprint of industrial activities. They directly      the focus from aggregate environmental impacts to distribu-
mitigate adverse impacts and also foster beneficial spillover        tional consequences, specifically investigating how the benefits
effects across various market sectors (Olanrewaju et al. 2022).      and burdens of green technological advancement are allocated
Additionally, these innovations offer cost-­effective, sustainable   across sectoral, regional, and income-­     based stratifications
strategies that help limit the growing contribution of commer-       within advanced economies. This distributional lens addresses a
cial and trade operations to CO2 emissions. Ahmad et al. (2021)      critical gap in environmental economics literature by answering
conducted a comprehensive study investigating how financial          the fundamental question of “who benefits” from green techno-
globalization, urban development, eco-­     innovative practices,    logical progress. Third, we extend the temporal scope of analysis
and economic expansion influence the ecological footprints of        to 2023, incorporating the most recent developments in green
G7 nations, using annual data from 1980 to 2016. Their findings      technology adoption, policy implementation, and post-­pandemic
reveal that when financial markets become more integrated and        economic recovery patterns. This extended timeframe captures
industries adopt eco-­friendly innovations, the overall environ-     contemporary dynamics that previous studies have not exam-
mental burden, as measured by ecological footprints, tends to        ined, providing insights into how recent global disruptions have
decrease. Conversely, as urban areas expand, they contribute         affected the relationship between eco-­innovation and emissions
to environmental degradation, leading to larger ecological foot-     inequality. Fourth, we contribute methodologically by employ-
prints. Fernández Fernández et al. (2018) explore how innova-        ing longitudinal panel data analysis across G7 economies, en-
tive measures impact CO2 emissions reductions. They contend          abling robust cross-­country comparisons while controlling for
that boosting investments in research and development (R&D)          country-­specific heterogeneity. The G7 economies were chosen
can markedly lower CO2 emissions in advanced economies.              because they are highly industrialized, major contributors to
Additionally, they contend that eco-­innovation plays a critical     global emissions, and leaders in green innovation. Their strong
role in mitigating environmental pollution and curbing the over-     policy frameworks and reliable data make them ideal for exam-
exploitation of natural resources. This is because eco-­innovation   ining how advanced economies balance eco-­innovation, carbon
typically involves processes that consume fewer resources and        reduction, and inequality. This approach allows for the identi-
promote energy-­   efficient practices, ultimately contributing      fication of both common patterns and country-­specific varia-
to more sustainable and environmentally friendly activities.         tions in how eco-­innovation influences emissions distribution.
Awaworyi Churchill et al. (2019) utilized a non-­parametric panel    Finally, the study offers practical policy implications by identi-
data model to explore how R&D intensity has influenced emis-         fying which types of eco-­innovation are most effective in reduc-
sions in G7 countries, drawing on data from as far back as the       ing emissions inequality and which populations or sectors may
nineteenth century. Their analysis reveals that the connection       require targeted support to benefit from green technological

2                                                                                                           Sustainable Development, 2025
                                                                                                                                         10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
advancement. These findings contribute to the development of        construction-­
                                                                                 sector initiatives yield minimal reductions.
more equitable and effective climate policy frameworks that en-     Similarly, Ahmed et al. (2016) affirmed technology's critical role
sure no group is left behind in the transition to a sustainable     in cutting emissions in European nations. Li, Jia, et al. (2023)
economy.                                                            applied the Quantile ARDL method to assess how innovation in-
                                                                    fluences emissions (1986 to 2022), revealing consistent emission
                                                                    reductions across all quantiles.
2   |   Literature Survey
                                                                    Based on the above, the following hypothesis is formulated.
Global anthropogenic activities continue to drive alarming rates
of carbon dioxide emissions, a pattern observed even in eco-        H1. Eco-­innovation significantly reduces CO2 emissions in G7
nomically advanced regions. Although technological progress         economies.
and climate consciousness have expanded, the enduring depen-
dence on non-­renewable energy sources, manufacturing sys-
tems, and vehicular transport persists as a primary contributor     2.2   |   Economic Growth and CO2 Emissions
to planetary carbon footprints, as noted by Mensah et al. (2018).
Scholarly discourse on innovation's role within the interplay       The relationship between economic growth and CO2 emissions
of economic expansion and ecological sustainability encom-          is contingent on many factors such as technological advance-
passes diverse perspectives. This investigation categorizes the     ment and economic development. For example, some studies
analyzed body of work into four thematic segments. Initially,       suggest that growth reduces emissions through technological in-
we investigated the link between technological advancement          novation, energy efficiency, and renewables (Ahmed et al. 2017;
and greenhouse gas output. Subsequently, the analysis shifts        Aye and Edoja 2017; Ozturk et al. 2022). Others find that growth
to the correlation between macroeconomic development and            elevates emissions, particularly in developing economies reliant
atmospheric CO2 concentrations. The third segment evaluates         on fossil fuels (Khan et al. 2022, on N-­11 nations).
how economic diversification influences emission patterns, cul-
minating in a final assessment of how cross-­border economic        In the context of G7 economies, Rasheed and Liu (2024) identify
integration (GLO) and market liberalization (TO) shape carbon       that GDP and emissions are positively correlated. Their ARDL
emission trajectories.                                              model and data from 1990 to 2022 point out significant positive
                                                                    effects for the USA, Canada, Germany, and the UK whereas a
                                                                    weak effect is found in the case of France, Italy and Japan. Still
2.1   |   Eco-­Innovation and CO2 Emissions                         on the G7, found that factors such as GDP and energy intensity
                                                                    are immense contributors to emissions, whereas eco-­innovation
Recognized as a vital strategy for curbing environmental harm       measures such as renewable energies foster emissions reduction
from economic activities, sustainability-­  focused innovation      in varying zones of their quantile regression model. Regarding
emphasizes creating eco-­innovative products to mitigate eco-       other nations and regions, Li and Wei (2021) employed panel
logical destruction (Ben Amara and Chen 2020; Gente and             smooth transition regression on 30 Chinese provinces (1987
Pattanaro 2019). Research has examined the interplay be-            to 2017), identifying a nonlinear link between financial devel-
tween sustainability innovation and carbon dioxide emissions        opment, innovation, growth, and emissions, with energy con-
(Erdoğan et al. 2020; Henriques and Borowiecki 2017). Scholars      sumption as a threshold; northern China transitions faster to
often embed this concept in analytical models to gauge its          lower emissions than the south. Also, Amin et al. (2022) ana-
emission-­reducing potential.                                       lyzed N-­11 economies (1995 to 2019) via CS-­A RDL, revealing
                                                                    that a 1% GDP rise causes a 1.20% long-­term emissions increase.
Regarding G7 economies, using data from 1997 to 2019, Akram
et al. (2023) found that eco-­innovation measures (green energy,    Overall, growth can drive environmental gains under favorable
carbon taxes, and environmental policies) are very instrumental     conditions but often heightens emissions in emerging markets,
in reducing emission volumes. From their CS-­A RDL, CCEMG           highlighting the need for decoupling via sustainable technolo-
and other methods, they however, conclude that natural re-          gies, renewables, and integrated strategies.
source dependence and financial development exacerbate emis-
sions. Another such study is Wang et al. (2020), which highlights   Drawing on the mixed findings on the growth–emission rela-
eco-­innovation as a critical component in the global race to net   tionship, the following hypothesis is proposed:
zero. In their study on G7 economies using data from 1990 to
2017, they found that whereas ecological innovation reduces         H2. Economic growth increases CO2 emissions in G7 econo-
emissions, factors such as trade act on the contrary.               mies, although the magnitude may vary across countries depend-
                                                                    ing on technological advancement and energy efficiency.
Similar findings are observed in other countries and blocks.
For example, Mensah et al. (2018) analyzed innovation's role
in reducing emissions across 28 OECD nations from 1990 to           2.3   |   Economic Complexity and CO2 Emissions
2014. Their work underscores innovation's significant emission-­
reduction effects, though its efficacy varies regionally. Erdoğan   Economic complexity (ECI) encompasses the expertise, abil-
et al. (2020) evaluated sectoral impacts of innovation on car-      ities, and resources inherent in a nation's productive systems,
bon emissions in 14 G20 countries (1991 to 2017), finding that      shaping its capacity to generate advanced and varied products
industrial eco-­innovations markedly lower emissions, whereas       and services. This concept is closely tied to advancements in

Sustainable Development, 2025                                                                                                       3
                                                                                                                                            10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
industrialization, technological progress, and innovative ca-        Yurtkuran (2021) for Turkey, Khan et al. (2022) for South
pacity. Recent research on the G7 bloc indicates varying roles       Asia, and Sadiq et al. (2023) for top nuclear energy nations.
of ECI in emission reduction and sustainability. For instance,       Regarding trade openness (TO), Sun et al. (2020), Oh and
empirical analysis covering 1995–2016 indicates that the ECI         Bhuyan (2018), and Sohag et al. (2017) note that TO contrib-
reduces emissions in the G7 nations. Their analyses emphasize        uted to rising emission levels. However, contrasting views
that these economies are well diversified in terms of produc-        emerge: Shahbaz et al. (2017) reported minimal TO effects on
tion processes. This enables G7 nations to produce in an envi-       emissions. Kim et al. (2019) used panel IV-­quantile methods
ronmentally friendly manner, hence the reducing effect of ECI        across trade directions, finding adverse TO impacts on CO2
on emissions. Similarly, robust econometric evidence reveals a       in advanced economies but potential reductions in wealthier
positive relationship between ECI and climate change—largely         nations. Recent work by Haq et al. (2024) in SAARC nations
driven by emissions—in the G7 countries. While ECI initially         showed GLO and GDP boost CO2 emissions, while techno-
exerts adverse environmental effects, surpassing certain thresh-     logical innovation and renewables mitigate it. Overall, these
olds reverses this impact, leading to an environmental repair        studies illustrate GLO and TO's multifaceted effects on CO2 ,
effect.                                                              varying by context, with effective regulation essential for sus-
                                                                     tainable global integration.
Other studies that focus on other countries and regions in-
clude Doğan et al. (2019) which examined 55 nations over             In light of the empirical evidence showing that globalization and
four decades (1971 to 2014), grouping them into three income         trade openness influence emissions through multiple channels,
categories based on development status. The analysis revealed        the following hypothesis is proposed:
that in lower-­and middle-­income nations, increased ECI was
linked to greater environmental harm, whereas in wealthier           H4. Trade openness and globalization exert a nonlinear (U-­
countries, it correlated with reduced emissions. Another such        shaped) relationship with CO2 emissions in G7 economies.
study is Neagu and Teodoru (2019), which focuses on 25 EU
member states from 1995 to 2016 and finds that higher eco-
nomic complexity correlated with elevated greenhouse gas             2.5   |   Synthesis and Literature Gap
emissions. Another insight emerges from Ren et al. (2025),
who studied 82 countries between 2001 and 2019 using geo-            The reviewed literature provides valuable insights into the re-
graphical impact analysis. Their work highlights that while          lationships among technological innovation, economic growth,
complexity boosts local emissions, largely through shifts in         globalization, and carbon emissions. However, three key gaps
energy systems, it indirectly mitigates emissions in neighbor-       remain. First, existing studies primarily examine the aggre-
ing regions by driving efficiency improvements in energy use.        gate effect of eco-­innovation on emission levels, overlooking
In all, these studies underscore the complex role of economic        its potential to create or mitigate carbon inequality across sec-
complexity in environmental outcomes, varying across con-            tors or regions. Second, limited attention has been given to
texts, regions, and nations.                                         process-­oriented eco-­innovation (ECOP) as a distinct channel
                                                                     through which green technologies influence environmental
Given the dual effects of economic complexity on environmental       outcomes. Third, empirical evidence on eco-­innovation for de-
outcomes across different stages of development, the following       veloped economies, especially G7 nations, remains scarce de-
hypothesis is formulated:                                            spite their technological leadership and high carbon intensity.
                                                                     This study addresses these gaps by empirically examining how
H3. Economic complexity reduces CO2 emissions in G7 econo-           eco-­innovation and process eco-­innovation affect carbon emis-
mies by promoting diversified and environmentally efficient pro-     sions inequality across G7 countries, employing quantile-­based
duction structures.                                                  methods to capture heterogeneous effects across the emissions
                                                                     distribution.

2.4   |   Trade Openness, Globalization, and CO2
Emissions                                                            3   |   Theoretical Channels and Framework

Debates on CO2 emissions highlight the complex links between         Eco-­innovation (ECON), encompassing both product and orga-
global integration, trade openness, and environmental destruc-       nizational innovations, is theorized to play a transformative role
tion. Research reveals varied impacts of globalization (GLO) on      in reducing environmental degradation while promoting sus-
ecological footprints. In the case of G7 nations, found a positive   tainable competitiveness. According to Ecological Economics
relationship between GLO and emissions in the long run using         Theory eco-­ innovation enhances resource efficiency and re-
data from 199 to 202 and the ARDL model. Correspondingly,            duces pollution intensity across production systems. Yet, it can
highlight a U-­ shaped effect of GLO on emissions, further           be deduced from the Innovation Inequality Hypothesis that
strengthening the EKC hypothesis in G7.                              the benefits of such innovation may accrue disproportionately
                                                                     to countries or sectors with advanced technological capac-
Similar observations are made in other regions and nations.          ities, thereby reinforcing emissions inequality (Aghion and
For instance, applying the ARDL on data from Pakistan                Griffith 2024). In this context, ECON's effectiveness depends
(1971 to 2016) Khan et al. (2019) find that economic, so-            on the inclusivity of green technology diffusion and the absorp-
cial, and political GLO significantly raise CO2 emissions in         tive capacity of industries. Empirical evidence suggests that
Pakistan. Other studies that share similar findings include,         broader access to environmental technologies and supportive

4                                                                                                           Sustainable Development, 2025
                                                                                                                                           10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
policy frameworks can mitigate carbon disparities by fostering        To quantify this inequality, we adopt the measurement ap-
equitable green transitions. Hence, this study views ECON as a        proach developed by, operationalizing CI as the average per
systemic determinant of both aggregate emissions reduction and        capita carbon emissions of the top decile (wealthiest 10%) of
the equitable distribution of environmental gains.                    the population within each country. This metric captures the
                                                                      concentration of carbon footprints among affluent segments of
Similarly, theoretically, process eco-­innovation (ECOP) can          society, who typically exhibit substantially higher consumption-­
influence carbon emissions inequality (CI) through both effi-         based emissions through activities such as international travel,
ciency and distributional channels. Insights from the Ecological      energy-­intensive housing, and luxury consumption. By focusing
Modernization Theory indicate that technological innovations          on the top decile's emissions, this measure provides a clear indi-
that improve production efficiency can decouple economic              cator of how emission privileges are concentrated at the upper
growth from carbon emissions, leading to aggregate environ-           end of the income distribution, making it particularly suitable
mental gains. However, cautions that such benefits may be             for analyzing the distributional impacts of eco-­innovation and
unevenly distributed when access to cleaner technologies is con-      economic factors.
centrated among advanced industries or wealthier regions. This
uneven diffusion can widen emissions inequality despite overall
reductions in emissions. Moreover, the Environmental Kuznets          4.1.2   |   Independent Variables:
Curve (EKC) framework suggests that early stages of technolog-        Eco-­Innovation Measures
ical adoption may exacerbate inequality before inclusive innova-
tion mechanisms take hold.                                            The analytical framework incorporates dual measures of
                                                                      eco-­innovation: process-­specific eco-­innovation (ECOP) and
From a critical standpoint, the net effect of ECOP on CI therefore    comprehensive eco-­   innovation (ECON). This methodological
depends on how innovation incentives, institutional quality, and      distinction represents a departure from conventional approaches
knowledge transfer mechanisms are structured across econo-            that typically employ singular, undifferentiated measures of
mies. Inclusive eco-­innovation policies that promote technology      eco-­innovation. ECOP is operationalized through patent counts
diffusion, skill development, and equitable financing can trans-      specifically associated with climate change mitigation technolo-
form ECOP into a tool for both emission mitigation and social         gies, encompassing innovations in production processes, energy
equity. By integrating these theoretical perspectives, this study     transition methodologies, effluent treatment systems, carbon
positions ECOP not merely as a determinant of emission reduc-         capture and storage technologies, and building-­related environ-
tion but as a potential lever for achieving distributive environ-     mental innovations. Conversely, ECON is measured using the
mental justice across the G7 economies.                               broader portfolio of environmental technology patents, encom-
                                                                      passing all the aforementioned climate mitigation categories
                                                                      while also integrating environmental management systems,
4   |   Methodology                                                   climate change adaptation technologies, and marine pollution
                                                                      control solutions (OECD 2024). This dual-­measure approach
4.1   |   Data Framework and Variable Selection                       enables us to distinguish between targeted process-­level inno-
                                                                      vations and broader systemic eco-­innovations in their effects on
This investigation employs longitudinal data spanning 1990–           emissions inequality.
2023 to analyze the environmental dynamics in the G7 coun-
tries, with particular emphasis on carbon emissions inequality
(CI) as the response variable. The analysis leverages data from       4.1.3   |   Control Variables
the World Inequality Database (WID), World Development
Indicators (WDI), and OECD repositories.                              The selection of control variables is theoretically motivated by
                                                                      their established relationships with carbon emissions inequal-
                                                                      ity. Economic growth, proxied by GDP per capita, represents
4.1.1   |   Dependent Variable                                        a core determinant of both consumption patterns and envi-
                                                                      ronmental impact, as affluence typically drives higher energy
Carbon emissions inequality (CI) serves as the primary outcome        use and emissions while simultaneously creating financial ca-
variable in this study. While previous research has extensively       pacity for green technology adoption (Boyce 1994; Jorgenson
examined emissions disparities between developed and devel-           et al. 2017). The Economic Complexity Index (ECI) measures the
oping nations or across geographic regions, within-­country in-       knowledge intensity and diversification of national production
equality remains equally critical yet underexplored. Although         systems; greater economic complexity signals advanced techno-
higher aggregate carbon emissions often correlate with im-            logical capacity that may either exacerbate emissions inequality
proved living standards, these benefits are rarely distributed        through concentrated industrial activities or mitigate it through
equitably across society (Bergougui et al. 2025, 2024). In reality,   sophisticated low-­carbon innovations accessible across income
disadvantaged and marginalized populations disproportionately         groups (Hartmann et al. 2017). Trade openness (TO) quantifies
bear the adverse consequences of environmental degradation            the extent of international economic engagement, which affects
and climate change, despite contributing least to the problem         emissions inequality through various mechanisms including
(Chancel and Piketty 2015). Addressing the unequal distribu-          production relocation, cross-­border technology diffusion, and
tion of both emission privileges and environmental burdens is         the potential for either a “race to the bottom” in environmen-
therefore essential for achieving social and environmental jus-       tal standards or the dissemination of sustainable practices
tice (Bergougui 2025; Bergougui 2024a, 2024b, 2025).                  (Antweiler et al. 2001; Copeland and Taylor 2004). Globalization

Sustainable Development, 2025                                                                                                         5
                                                                                                                                                            10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 1    |    Variable description and source.

    Variable                                  Symbol                                       Measurement                                       Source
    CO2 emissions inequality                      CI                    Total CO2 Equivalent per Capita (CO2 Emissions per                     WID
                                                                          Capita of the Wealthiest 10% of the Population)
    Process eco-­innovation                     ECOP                        The count of patents related to technologies                      OECD
                                                                               designed to mitigate climate change
    Eco-­Innovation                             ECON                        The total volume of patents associated with                       OECD
                                                                       environmentally focused technological advancements
    Economic Growth                              GDP                 Gross domestic product per capita, measured in U.S. dollars               WDI
    Economic complexity                          ECI                                Economic complexity index                                 OWID
    Trade openness                                TO                                  Trade percentage of GDP                                 OECD
    Globalization                                GLO                                (Overall) Globalization Index                              KOF
Note: OWID (Our World in Data), WID (World inequality database), OECD (Organization for Economic Co-­operation and Development), WDI (World Development
Indicators), and KOF (Konjunkturforschungsstelle/Swiss Economic Institute).




(GLO), captured through a multidimensional index spanning                          indicate the percentage change in emissions inequality resulting
economic, social, and political integration, reflects the depth of                 from a 1% change in any of the explanatory variables.
international connectedness that shapes consumption behav-
iors, production networks, and the transnational transmission                      While the baseline models assume symmetric effects of tech-
of environmental policies and technologies—all factors that                        nological drivers (ECON and ECOP) on CI, empirical evidence
determine how carbon footprints are distributed across socio-                      from prior studies (e.g., Bergougui 2024a; Bergougui, Mehibel,
economic strata (Dreher 2006; Figge et al. 2017). Collectively,                    and Boudjana 2024) suggests potential asymmetries, where pos-
these variables constitute an integrated analytical framework                      itive and negative fluctuations in innovation may exert differ-
for examining how economic structure, global integration, and                      ential influences (Sun, Yesilada, et al. 2021). From a theoretical
development pathways mediate the relationship between eco-­                        standpoint, this asymmetry can be rooted in several environ-
innovation and carbon emissions inequality in developed econ-                      mental economics paradigms. Drawing on prospect theory from
omies. Table 1 details variable definitions and data sources.                      behavioral economics (Kahneman and Tversky 1979), decreases
                                                                                   in eco-­innovation (negative shocks) may have disproportion-
                                                                                   ately larger adverse effects on CI compared to equivalent in-
4.2   |   Econometric Model                                                        creases (positive shocks), as societies and economies exhibit loss
                                                                                   aversion—prioritizing the avoidance of environmental degrada-
This study constructs its econometric framework by extending                       tion over gains in sustainability (Wang et al. 2020). Additionally,
established models from the environmental economics litera-                        path dependency and technological lock-­in effects, as articu-
ture, notably those employed by Bergougui (2024a), Bergougui,                      lated in innovation diffusion theory, imply that reductions in
Doğan, et al. (2024), and Kinyar and Bothongo (2024). The rela-                    eco-­innovation could entrench high-­emission practices among
tionships between eco-­innovation measures and carbon emis-                        lower-­income groups, widening inequality, whereas increases
sions inequality (CI) are examined via a multivariate panel data                   facilitate creative destruction and broader diffusion of green
model, specified as follows:                                                       technologies, potentially narrowing disparities more gradually
                                                                                   (Sovacool et al. 2022). Within the EKC framework, asymmetries
               CIi,t = 𝛽 i + 𝛼 1 ECONi,t + 𝛼 2 GDPi,t + 𝛼 3 ECIi,t                 arise because early-­stage eco-­innovations may initially benefit
                                                                            (1)
                       + 𝛼 4 TOi,t + 𝛼 5 GLOi,t + 𝜇 i,t                            wealthier segments (reducing their emissions faster and thus
                                                                                   heightening inequality), while sustained positive changes en-
               CIi,t = 𝛽 i + 𝛼 1 ECOPi,t + 𝛼 2 GDPi,t + 𝛼 3 ECIi,t                 able spillover effects that promote equitable decarbonization
                                                                            (2)    across income strata (Afshan et al. 2022; Aydin et al. 2023).
                       + 𝛼 4 TOi,t + 𝛼 5 GLOi,t + 𝜇i,t                             Furthermore, scale, composition, and technique effects in en-
                                                                                   vironmental economics highlight that positive eco-­innovation
where i represents the G7 economies and t denotes the year, re-                    shocks enhance technique effects (efficiency gains) to mitigate
spectively. The dependent variable, CO2 emissions inequality,                      CI, but negative shocks amplify scale effects (expanded dirty
is analyzed in relation to four independent variables to inves-                    production), exacerbating inequality in unevenly distributed
tigate technological drivers of environmental outcomes. This                       economic contexts (Xu 2020; Zhang et al. 2024). These theoreti-
comprehensive variable selection enables examination of both                       cal insights underscore the need to decompose innovation vari-
technological innovation and economic factors in environmen-                       ables to capture nuanced, non-­linear dynamics.
tal outcomes. The parameters, denoted as β1 to β5, are estimated
through regression analysis. To mitigate issues of heteroskedas-                   To incorporate this asymmetry, the study follows the approach
ticity, all variables are expressed in natural logarithmic form, al-               of Shin et al. (2014) by decomposing the innovation series into
lowing the coefficients to represent elasticities. These elasticities              positive and negative partial sums:

6                                                                                                                           Sustainable Development, 2025
                                                                                                                                                      10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
  {               (         )              (          )
      ECON+t = max 0, ΔECONt , ECON−t = min 0, ΔECONt                    Model (1):
                  (         )              (          )                               (          )
      ECOP+t = max 0, ΔECOPt , ECOP−t = min 0, ΔECOPt                            QCIit 𝜏| 𝛽 i Xit = 𝛽 0 + 𝛼 1 ECON+it + 𝛼 2 GDPit + 𝛼 3 ECIit
                                                                                                                                                (5)
                                                                                                   + 𝛼 4 TOit + 𝛼 5 GLOit + 𝜇it
These advanced models facilitate the assessment of how in-
creases and decreases in innovation variables uniquely affect            Model (2):
CO2 emissions inequality within the G7 nations.                                       (          )
                                                                                 QCIit 𝜏| 𝛽 i Xit = 𝛽 0 + 𝛼 1 ECON−it + 𝛼 2 GDPit + 𝛼 3 ECIit
                                                                                                                                                (6)
                                                                                                   + 𝛼 4 TOit + 𝛼 5 GLOit + 𝜇it
4.3   |   Quantile Regression via Method of Moments
(MMQR)                                                                   Model (3):
                                                                                     (          )
Environmental datasets frequently exhibit distributional char-                  QCIit 𝜏| 𝛽 i Xit = 𝛽 0 + 𝛼 11 ECOP+it + 𝛼 2 GDPit + 𝛼 3 ECIit
acteristics—such as high kurtosis, heavy tails, and skewness—                                                                                   (7)
                                                                                                   + 𝛼 4 TOit + 𝛼 5 GLOit + 𝜇 it
that violate the assumptions of classical linear regression.
Conventional panel data methods relying on conditional mean
                                                                         Model (4):
regression provide estimates of average effects but fail to capture
                                                                                      (          )
heterogeneous impacts across the conditional distribution of emis-               QCIit 𝜏| 𝛽 i Xit = 𝛽 0 + 𝛼 1 ECOP−it + 𝛼 2 GDPit + 𝛼 3 ECIit
sions inequality. This limitation is particularly problematic when                                                                              (8)
                                                                                                   + 𝛼 4 TOit + 𝛼 5 GLOit + 𝜇 it
studying inequality measures, as the determinants of emissions
inequality may operate differently at low versus high inequality
levels. Moreover, mean-­based approaches are vulnerable to out-          By applying quantile regression across these intervals, the analysis
liers and may produce biased estimates when unobserved hetero-           captures how independent variables influence different sections
geneity is present.                                                      of the CI distribution, offering detailed insights into its variations.


To address these limitations, this study employs panel quantile re-
gression, which enables examination of how eco-­innovation and           5   |   Empirical Results
other determinants influence the entire conditional distribution of
carbon emissions inequality across G7 economies. Unlike mean             This study uses a multi-­stage method to analyze how innovation
regression, quantile regression is robust to outliers and does not re-   affects carbon inequality (CI) in G7 nations. We first tested the
quire distributional assumptions (Machado and Santos Silva 2019).        data distribution, finding all variables are non-­normal (Table 2),
However, standard panel quantile regression methods often strug-         which justified using quantile regression. After confirming data
gle with unobserved heterogeneity and endogeneity concerns. The          stationarity and long-­run relationships, we applied an asymmet-
Method of Moments Panel Quantile Regression (MMPQR) frame-               ric Method of Moments Quantile Regression (MMQR) to assess
work developed by Machado and Santos Silva (2019) overcomes              the varying impacts of innovation on CI across different emis-
these limitations by explicitly modeling both location and scale         sion levels. Finally, we used bootstrap causality tests to deter-
effects on the conditional distribution. MMPQR accommodates              mine the direction of influence between variables. This process
asymmetries in effects, accounts for time-­invariant unobserved          is outlined in Figure 1.
heterogeneity through individual fixed effects, and provides con-
sistent estimates even under endogeneity—making it particularly
suitable for analyzing the complex, nonlinear relationships be-          5.1   |   Pre-­Test Diagnostics
tween eco-­innovation and emissions inequality. The general panel
quantile regression model is specified as:                               The summary statistics in Table 2 confirm the non-­        normal
                                                                         distribution of all variables, as evidenced by the significant
                           (       )
                      Qyi,t 𝜏| Xi,t = 𝛽 𝜏 + Xi,t� 𝛼 𝜏              (3)   Shapiro–Wilk test results (p = 0.000). Most variables are left-­
                                                                         skewed, with kurtosis values indicating light to moderate tails.
                                               (      )                  This non-­normality is visually confirmed by the Q–Q plot for
In the model framework, where 0 < 𝜏 < 1, Qyi,t 𝜏| xi,t represents
                                                                         the dependent variable, CI (Figure 2), validating the use of quan-
the τth conditional quantile of the dependent variable CI. The
                                                                         tile regression for further analysis.
parameter ατ quantifies the impact of the observed independent
variable X, while βτ captures the effects of unobserved hetero-
geneity. The estimation procedure for the coefficients related to
the τth conditional quantile is formally defined in Equation (4).        5.2   |   Preliminary Tests

                                n
                                ∑       (                     )          5.2.1   |   Results of the CSD and SH Tests
               ̂𝜏 = arg min
               𝛼                      𝜌𝜏 yi − 𝛽 𝜏 − Xi,t� 𝛼 𝜏      (4)
                                i=1                                      To examine the interrelatedness across the cross-­     sectional
                                                                         units, this study conducts the CSD test (Pesaran 2007) for the
Here, I(.) expresses the indicator function, w 𝜌𝜏 = 𝜇 ( 𝜏 − I(𝜇 < 0))    individual models, and their outcomes are displayed in Table 3.
is identified as the check function. Consequently, Equations (5–         Observably, the p values of all models are 0.000, making a case
8) outline the respective quantile regression models derived             for a strong rejection of the null hypothesis of no dependence,
from the foundational Equations (1) and (2).                             implying significant cross-­ sectional dependence. Practically,

Sustainable Development, 2025                                                                                                                    7
                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 2    |    Summary statistics.

                 Mean           Std. dev.            Min.    Max.       Skew.         Kurt.         Shapiro–Wilk test            Prob.
    CI           2.086            0.684              0.352   2.847      −1.484         4.042                8.552                0.000
    ECOP         0.763            0.239              0.324   1.198       0.015         1.900                4.244                0.000
    ECON         10.461           0.312              9.820   11.311     −0.159         2.361                3.939                0.000
    GDP          0.948            0.193              0.432   1.237      −0.982         3.730                6.553                0.000
    ECI          3.841            0.423              2.817   4.614      −0.653         2.459                5.694                0.000
    TO           4.390            0.088              4.037   4.505      −1.335         5.318                6.647                0.000
    GLO          2.086            0.684              0.352   2.847      −1.484         4.042                8.552                0.000




FIGURE 1    |    Flowchart of the empirical steps.



                                                                      relationships between variables differ across units, which must
                                                                      be accounted for in model estimation.

                                                                      Table 4 presents results from the CIPS (Pesaran 2007) and CADF
                                                                      (Im et al. 2003) panel unit root tests, examining the stationarity
                                                                      of the variables under different conditions. At levels, all vari-
                                                                      ables except ECON−, ECOP−, and ECI show significance at 1% or
                                                                      10% levels in both tests. Observably, at (I)1, all variables become
                                                                      significant at 1% in both tests, indicating that they are station-
                                                                      ary after differencing. To evaluate the possibilities of long-­run
                                                                      equilibrium relationships among variables in the models, three
                                                                      stringent approaches are adopted, and the findings are pre-
                                                                      sented in Table 5. The Kao test (Kao 1999), shows test statistics
                                                                      ranging from −5.9516 to −10.1483 with p < 0.01 for all models,
FIGURE 2    |    The Q–Q plot for CI.                                 strongly rejecting the null hypothesis of no cointegration. In the
                                                                      Pedroni test (Pedroni 2004), the statistics range from −1.8156 to
                                                                      −3.1713. The statistical significance in all models is 5% or 1%.
due to their strong trade ties, financial interdependencies, and      Lastly, the (Westerlund 2007) test shows highly significant sta-
economic integration, the G7 nations exhibit strong reliance.         tistics (−8.679 to −15.941, with p < 0.01) across all models fur-
Still in Table 3, the slope homogeneity test (Blomquist and           ther confirming cointegration. This highlights the reliability of
Westerlund 2013), both Δ ̂ and its adjustment test statistics show    these long-­run relationships, even under cross-­sectional depen-
p values of 0.000, rejecting the null hypothesis of slope homo-       dence. Finally, the graph in Figure 2 illustrates a positive linear
geneity. This suggests substantial heterogeneity, indicating that     relationship between the inverse normal distribution and CO2

8                                                                                                             Sustainable Development, 2025
                                                                                                                                                               10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 3    |    CDS and SH test outcomes.

                                Cross-­sectional dependence test                                       Slope heterogeneity test outcomes

  Model                             LM test                          Prob.                         ̂
                                                                                                   𝚫                        ̂ Adj
                                                                                                                            𝚫                   Prob.
  Model (1)                        219.12***                         0.0000                    13.638***                  15.304***             0.0000
  Model (2)                        167.785***                        0.0000                    11.487***                  12.89***              0.0000
  Model (3)                       220.988***                         0.0000                    13.196***                  14.808***             0.0000
  Model (4)                       222.413***                         0.0000                    12.367***                  13.877***             0.0000
Note: *** denotes the significance level at 1%.



TABLE 4    |    Panel unit root tests.

                                                              CIPS                                                           CADF
  Variables                          Level I(0)                         Difference I(1)                      Level I(0)               Difference I(1)
  ECON    +
                                        −1.619                               −2.489**                          −2.024                    −3.969***
  ECON−                               −2.747***                              −3.661***                        −2.213**                   −3.173***
  ECOP+                                −2.086                                −4.091***                         −1.954                    −5.089***
  ECOP    −
                                       −2.258*                               −4.675***                         −2.183                    −5.866***
  CI                                    −1.691                               −3.688***                       −2.767***                   −4.985***
  GDP                                  −2.121                                −3.822***                         −1.788                    −4.676***
  ECI                                  −2.260*                               −3.439***                        −2.243*                    −4.899***
  TO                                   −2.204                                −2.741***                         −1.619                    −3.154***
  GLO                                   −1.218                               −2.657***                         −1.220                    −3.696***
Note: *** denotes the significance level at 1%.


TABLE 5    |    Cointegration test outcomes.                                             of this effect decreases as the quantiles rise, with coefficients
                                                                                         becoming insignificant at the higher quantiles (0.80 and 0.90).
                                                                Bootstrap                This suggests that eco-­process innovation is more effective in
                                                                Westerlund               reducing emissions inequality in countries with lower initial
  Model              Kao test            Pedroni test              test                  levels of inequality, though its impact diminishes as inequal-
  Model (1)         −5.9516***             −1.8156**              −15.941***             ity increases. These results highlight the role of ecological
                                                                                         technological advancements, particularly those aimed at miti-
  Model (2)        −10.1483***            −3.1530***             −11.035***
                                                                                         gating climate change, in addressing emissions inequality and
  Model (3)        −10.1233***             −2.2326**              −8.679***              emissions in general as reported by earlier studies (Rahko and
                                                                                         Alola 2024; Sadiq et al. 2024). However, the reduced impacts at
  Model (4)         −8.6198***            −3.1713 ***            −12.057 ***
                                                                                         higher quantiles suggest that structural factors in regions with
Note: *** and * denote the statistical significance at 1% and 10%, respectively.         high inequality may constrain the benefits of these innovations.
                                                                                         These findings signify that an increase in a positive shift in
                                                                                         ECOP can reduce emissions in wealthier groups, thereby mit-
emissions inequality, with data points closely following the di-                         igating overall inequality. Ultimately, it facilitates a transition
agonal line.                                                                             from carbon-­intensive production and life style to low-­carbon al-
                                                                                         ternatives, promoting more sustainable and equitable economic
                                                                                         growth across different populations. Concerning the impact of
5.3   |   Asymmetric MMQR Estimation Results                                             economic growth, the findings indicate a positive nexus with
                                                                                         emissions inequality. With coefficients increasing from 0.314
5.3.1   |   Asymmetric Impact of EC Shocks on CI                                         at the 0.10 quantile to 0.597 at the 0.90 quantile, GDP shows a
                                                                                         favorable and significant effect across all quantiles. This indi-
The key findings derived from the MMQR techniques are sum-                               cates that, especially in areas with greater inequality, economic
marized in Tables 6 and 7. In Model (1) of Table 6, a positive                           growth may make emissions inequality worse. This situation
shock in eco-­process innovation (ECOP) is shown to signifi-                             could be attributed to the unequal distribution of the benefits of
cantly reduce carbon emissions inequality at lower and median                            growth in such countries. This positive nexus suggests potential
quantiles (0.10 to 0.60), with coefficients ranging from −0.853 to                       trade-­offs between economic growth and environmental equity,
−0.625, all significant at the 1% level. However, the magnitude                          as posited by the Environmental Kuznets Curve (Grossman and

Sustainable Development, 2025                                                                                                                             9
                                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 6    |    Asymmetric impact of ECON on CI using MMQR.

                                                                                     Quantiles
 Variables              0.10              0.20              0.30           0.40         0.50         0.60          0.70          0.80            0.90
                                                                                     Model (1)
 ECON     +
                    −0.853***         −0.809***         −0.761***        −0.713***   −0.661***    −0.625***      −0.578**      −0.525**        −0.460
                      (0.248)           (0.227)           (0.210)         (0.203)     (0.205)       (0.214)       (0.231)       (0.258)        (0.299)
 GDP                   0.314            0.346*           0.380**          0.415**     0.452**      0.478**       0.512**        0.550**        0.597**
                      (0.220)           (0.201)           (0.187)         (0.180)     (0.182)       (0.189)       (0.205)       (0.229)        (0.266)
 ECI                −0.636***         −0.687***         −0.742***        −0.796***   −0.855***    −0.896***     −0.950***     −1.010***      −1.084***
                      (0.125)           (0.115)           (0.107)         (0.103)     (0.105)       (0.109)       (0.118)       (0.131)        (0.151)
 TO                  −0.209*          −0.247**          −0.287***        −0.328***   −0.372***    −0.403***     −0.443***     −0.487***      −0.542***
                      (0.120)           (0.109)           (0.102)         (0.098)     (0.099)       (0.103)       (0.112)       (0.125)        (0.144)
 GLO                   0.192             0.438             0.705          0.967**     1.255***     1.457***      1.718***      2.010***       2.370***
                      (0.529)           (0.487)           (0.454)         (0.441)     (0.446)       (0.463)       (0.502)       (0.556)        (0.638)
                                                                                     Model (2)
 ECON     −
                     −0.414**          −0.344*            −0.272          −0.171       0.095         0.223         0.289        0.372*         0.439**
                      (0.188)           (0.181)           (0.177)         (0.179)     (0.183)       (0.188)       (0.190)       (0.200)        (0.209)
 GDP                 0.911***          0.874***          0.835***        0.781***     0.640***     0.571***      0.536***       0.492**        0.456**
                      (0.180)           (0.172)           (0.166)         (0.162)     (0.165)       (0.174)       (0.180)       (0.191)        (0.201)
 ECI                 −0.363**         −0.431***         −0.501***        −0.599***   −0.858***    −0.982***     −1.047***     −1.127***      −1.192***
                      (0.169)           (0.162)           (0.159)         (0.162)     (0.166)       (0.170)       (0.170)       (0.180)        (0.188)
 TO                   −0.171           −0.193*          −0.215**         −0.247**    −0.330***    −0.371***     −0.391***     −0.417***      −0.438***
                      (0.109)           (0.104)           (0.100)         (0.098)     (0.100)       (0.105)       (0.109)       (0.115)        (0.121)
 GLO                   0.433             0.518             0.605           0.728      1.050**      1.205**       1.285**        1.386**        1.466**
                      (0.536)           (0.513)           (0.494)         (0.480)     (0.488)       (0.517)       (0.537)       (0.570)        (0.600)
Note: Standard errors in brackets. *p < 0.10, **p < 0.05, ***p < 0.01.


Krueger 1995). The findings further point out that economic                          diffusion, there will be intensified competitive pressures for
complexity significantly contributes to reducing emissions in-                       firms and households to adopt energy-­efficient practices, re-
equality across all quantiles, with coefficients increasing from                     ducing emission-­related inequalities in the long term. As sim-
−0.636 at the 0.10 quantile to −1.084 at the 0.90 quantile. This                     ilarly discussed in previous findings, trade plays a major role in
implies that with increased economic complexity, characterized                       the dispersion of green technologies and in reducing emissions
by diverse industries, advanced technologies, and favorable                          (Cobbold et al. 2024; Wang et al. 2024). Nevertheless, studies
trade, economies may be better equipped to adopt sustainable                         including (Obobisa 2023) show opposing views. Finally, the co-
technologies and reduce emissions. The mitigating effect of eco-                     efficient for globalization (GLO) is positive at varying significant
nomic complexity highlights the importance of implementing                           levels. These coefficients, ranging from 0.192 at 0.10 to 2.370 at
strategic trade policies and boosting domestic production capac-                     0.90 signify that the expansion and interlinkage of advanced
ities. This finding is supported by recent studies that link eco-                    nations (G7 nations in this case) in terms of economy, social-
nomic complexity to reduced emissions (Ren et al. 2025; Romero                       ization, and political elements, exacerbate disparities in CO2
and Gramkow 2021; Saqib and Dincă 2024). Concerning TO, a                            emissions per capita. One major reason for this is that GLO often
similar unfavorable impact on emissions inequality is observed,                      leads to economic growth, wider markets, and a general spike in
with varying levels of significance. The results imply that                          carbon-­intensive industries (Sultana et al. 2023). The elite, who
greater trade performance could help reduce disparities in the                       typically consume more goods and services via global networks
distribution of carbon emissions across countries, particularly                      and are associated with high carbon-­intensive lifestyles, benefit
in terms of access to climate change mitigation technologies. By                     the most. Additionally, for instance, wealthier nations or cities
facilitating the exchange of these technologies, trade can enable                    may intensify industrial activities due to globalization whereas
countries with fewer resources or even under-­developed indus-                       less developed ones may struggle to catch up. This disparity in
tries to adopt green innovations faster and cut down on emis-                        technological access and production capabilities can lead to an
sions in the end. Furthermore, through trade-­led technological                      exacerbation of emissions inequality, with the wealthiest of the

10                                                                                                                            Sustainable Development, 2025
                                                                                                                                                            10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 7    |    Asymmetric impact of ECOP on CI using MMQR.

                                                                                     Quantiles
 Variables              0.10              0.20              0.30           0.40         0.50         0.60          0.70          0.80         0.90
                                                                                     Model (3)
 ECOP    +
                    −0.539***         −0.528***         −0.518***        −0.508***   −0.488***    −0.481***     −0.474***    −0.467***     −0.454***
                      (0.099)           (0.091)           (0.085)         (0.080)     (0.078)      (0.080)       (0.083)       (0.087)       (0.095)
 GDP                  0.349*            0.373**          0.394**         0.417***    0.460***      0.475***      0.491***     0.506***      0.533***
                      (0.196)           (0.179)           (0.167)         (0.158)     (0.155)       (0.158)      (0.163)       (0.170)       (0.188)
 ECI                −1.099***         −1.142***         −1.180***        −1.221***   −1.299***    −1.326***     −1.353***     −1.381***    −1.430***
                      (0.188)           (0.172)           (0.161)         (0.153)     (0.149)       (0.152)      (0.157)       (0.164)       (0.181)
 TO                 −0.376***         −0.416***         −0.451***        −0.489***   −0.561***    −0.586***     −0.611***    −0.638***     −0.683***
                      (0.135)           (0.124)           (0.116)         (0.111)     (0.108)       (0.110)      (0.113)       (0.118)       (0.130)
 GLO                  1.390**          1.619***          1.821***        2.037***     2.452***     2.595***      2.740***     2.889***      3.147***
                      (0.662)           (0.610)           (0.571)         (0.546)     (0.534)      (0.540)       (0.555)       (0.581)       (0.640)
                                                                                     Model (4)
 ECOP    −
                      0.408**          0.413***          0.424***        0.432***     0.443***     0.451***      0.455***     0.460***      0.465***
                      (0.160)           (0.145)           (0.122)         (0.105)     (0.089)      (0.084)       (0.084)       (0.087)       (0.092)
 GDP                   0.275             0.299             0.342          0.377*      0.425**      0.459***      0.475***     0.497***      0.518***
                      (0.309)           (0.281)           (0.235)         (0.204)     (0.172)       (0.163)      (0.162)       (0.167)       (0.177)
 ECI                −0.862***         −0.906***         −0.987***        −1.051***   −1.140***    −1.203***     −1.234***     −1.274***     −1.314***
                      (0.262)           (0.240)           (0.202)         (0.176)     (0.149)      (0.140)       (0.139)       (0.143)       (0.151)
 TO                   −0.204            −0.239          −0.303**         −0.354***   −0.425***    −0.475***     −0.500***     −0.532***    −0.564***
                      (0.185)           (0.169)           (0.143)         (0.125)     (0.106)      (0.099)       (0.098)       (0.101)       (0.107)
 GLO                   0.111             0.339             0.749          1.079*      1.535***     1.857***      2.014***     2.219***      2.425***
                      (0.820)           (0.757)           (0.645)         (0.569)     (0.480)      (0.449)       (0.438)       (0.451)       (0.477)
Note: Standard errors in brackets. *p < 0.10, **p < 0.05, ***p < 0.01.


population expanding their carbon footprint more than others.                        heavy-­carbon practices and a discouragement for the adoption
Although the GLO-­emissions inequality nexus is still up for in-                     of clean technologies. Consequently, those wealthier or more in-
tensified debate, the globalization-­driven emissions paradox has                    dustrialized regions that contribute to high emissions will con-
been confirmed in many studies including (Sultana et al. 2023).                      tinue to benefit from their established high-­emission activities,
Nevertheless, some studies evidence that GLO has the potential                       while low-­income regions that often have fewer alternative ac-
to curtail emissions (Xiaoman et al. 2021). In all, this evidence-­                  cesses to new technologies will be left behind, unable to reduce
based diverse opinions are a call for further studies into this                      their emissions disparities. Conversely, less affluent groups reli-
complex nexus.                                                                       ant on carbon-­intensive practices may face increased exposure
                                                                                     to the adverse effects of innovation shortfalls. These findings are
In Model (2) of Table 6, the findings report that negative changes                   an amplifier of studies that discuss disparities in access to green
in ecological innovation reduce emissions inequality at varying                      technologies and environmental justice (Vaishnav 2023).
significant levels in the lower quantiles (from 0.10 to 0.40). Thus,
a decline in efforts, progress, or developments in environmen-                       Regarding the role of GDP, the findings indicate consistent
tally friendly technologies and practices, shrinks the disparity                     positive effects across different significant levels. However,
between high-­emitting groups (represented by wealthier pop-                         the magnitudes of the coefficients decline from 0.911 at the
ulations) and low-­emitting groups. However, the effect turns                        0.10 quantile to 0.456 at the 0.90 quantile, signaling that
positive and insignificant in the median quantiles and becomes                       while economic growth contributes to increasing emissions
positive and significant at 5% and 10% in the upper quantiles                        inequality, its effect is stronger in regions with low-­emission
(0.80 and 0.90). This suggests that negative shocks to ecologi-                      inequality. This amplified effect could possibly be because low
cal innovation aggravate emissions inequality in regions with                        emissions inequality regions may lag in technological adop-
existing high levels of such inequalities. This is possible be-                      tion, making the exacerbating effect of GDP growth more no-
cause, in such regions, there could be an existing preference for                    ticeable. Insight from this paper's GDP- ­emissions inequality

Sustainable Development, 2025                                                                                                                          11
                                                                                                                                             10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
correlation adds to the growing concerns about GDP and vari-          indicates that an increase in ecological innovation (i.e., more
ous forms of inequalities (Hou et al. 2024).                          patents in climate change mitigation technologies) reduces
                                                                      carbon emissions inequality. It could be inferred that a boost
The study also evidences that ECI adversely impacts emissions         in the domestic production or availability of these technologies
inequality significantly in all quantiles, suggesting that econo-     is associated with economies of scale and a reduction in their
mies with more sophisticated and diverse production structures        prices, enabling both the low-­income and wealthy sections
tend to have a more efficient allocation of resources, including      of the population to gain access, thereby, reducing emissions
those related to energy and emissions, leading to a balanced dis-     inequality. However, the scale of the coefficients dwindles in
tribution of emissions per capita. An observed trend indicates        the higher quantiles, indicating that while green innovation is
that the coefficients appreciate in magnitude in higher quantiles     effective across all levels of inequality, its impact is more pro-
(thus, from −0.363 in 0.10 to −1.192 in 0.90). Advanced indus-        nounced in regions with lower emissions inequality and rela-
tries often use cleaner technologies; hence, a greater equitable      tively weaker where high inequality already exists. This insight
distribution of emissions. This reduces per capita emissions          adds to the greater body of literature on the green innovation-­
even as production increases. Moreover, high-­ranked ECI econ-        emission reduction nexus (Aghion and Griffith 2024; Barbieri
omies may have stronger institutions and policies that ensure         et al. 2023; Hasna et al. 2023). Regarding negative changes
equitable access to cleaner production methods and energy-­           in ECOP, the study reports positive coefficients significant at
efficient technologies. This finding aligns with the broader liter-   5% and 1% across all quantiles, indicating that a reduction in
ature which links economic complexity to reduced greenhouse           the number of patents for climate change mitigation technolo-
gas emissions and enhanced environmental efficiency (Romero           gies exacerbates carbon emissions inequality in G7 countries.
and Gramkow 2021).                                                    This implies that a decline in green technological advance-
                                                                      ments leads to a greater concentration of emissions among
Further on, regarding the impact of TO, the findings point out        the wealthiest segment of the population. The reduced supply
adverse impacts across all quantiles, suggesting that econo-          or production of process technologies will mean that people
mies that are more integrated into global trade tend to have          will continue to engage in the consumption of “dirty energy”,
a more balanced distribution of per capita emissions. As ear-         leading to a continues emissions inequality since the wealthy
lier discussed, TO facilitates technology transfer and access         groups are high consumers. Moreover, a decline in eco-­
to energy-­efficient innovations. This will enable low-­income        innovation may increase the cost of such technologies, which
earners and less developed regions to equally obtain and adopt        will push most people, both the low-­income and the wealthy to
cleaner production methods, consequently bridging the emis-           consume more carbon-­intensive alternatives. Similarly, in this
sions gap between high and low-­emitting regions. As reported         case, since the affluent consume more than the other groups,
by earlier studies, trade can promote shifts from pollution-­         emissions inequality is inevitable. As a consequence, this
intensive industries to service-­based and cleaner manufac-           finding reinforces the argument of other studies that green
turing sectors, leading to a reduced and equal distribution           policies should include social equity and government subsidy
of emissions, and an improved environment in the long run             measures to boost production, and also cushion lower-­income
(Kyriakopoulou et al. 2023; Pata et al. 2023). Next, similar          groups in the adoption of clean technologies (Li et al. 2024;
to that of Model (1), globalization is indicated to have a pos-       Semet 2024; Zhao et al. 2024; Zolfagharinia et al. 2023). The
itive impact on emissions inequality. However, this positive          control variables exhibit consistent impacts on carbon emis-
effect is insignificant in the lower quantiles (0.10 to 0.40) but     sions inequality in both Models (3) and (4) and are similar to
turns significant at 5% from 0.50 to 0.90. Globalization can          those of Models (1) and (2). In both Models (3) and (4), GDP
increase such inequality by enabling the affluent to consume          is positive and significant, suggesting that more economic ac-
more energy-­intensive goods and services, including interna-         tivity is linked to a higher concentration of emissions among
tional travel, which significantly raises their carbon footprint.     the affluent. ECI, which is negative and significant, indicates
Additionally, GLO fosters capital flows and access to global          that economies with greater technological sophistication and
markets, allowing affluent individuals to invest in carbon-­          diversity have lower emissions inequality, most likely as a re-
heavy industries, further widening the emissions gap between          sult of the spread of cleaner technology. Additionally, TO has
the wealthy and the rest of the population.                           a negative effect, suggesting that increased global trade inte-
                                                                      gration lowers emissions concentrations, possibly through en-
In sum, the findings tell that whereas positive shocks in ECON        hanced access to green breakthroughs associated with trade
have an all-­through adverse effect on emissions inequality, ad-      as indicated in the literature. Lastly, Finally, GLO is positive
verse shocks have a rather complex structure which shrinks            and significant in both models, highlighting that increased
emissions inequality in lower quantiles but exacerbates it in         global integration tends to exacerbate emissions inequality.
higher quantiles, highlighting the disproportionate impact of         The conclusions from both models are graphically presented
declining green innovation on high-­inequality regions. These         in Figure 4.
findings are graphically represented in Figure 3.

                                                                      5.4   |   Robustness Checks
5.3.2   |   Asymmetric Impact of ECOP Shocks on CI
                                                (       )             To enhance the reliability of the primary econometric results,
The results for positive shock from ECOP ECOP+ are pre-               this study utilizes three stringent widely recognized estima-
sented in Model (3) of Table 7 where the coefficients are nega-       tion techniques: DOLS, FMOLS, and CCR. These methodol-
tive and statistically significant at 1% across all quantiles. This   ogies complement the primary analysis by addressing critical

12                                                                                                           Sustainable Development, 2025
                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License




FIGURE 3    |    MMQR coefficients visualization for Models (1) and (2).



econometric challenges, such as heteroskedasticity, serial cor-            main findings. The results derived from these alternative
relation, and endogeneity (Bergougui 2024b; Bergougui and                  estimation techniques, summarized in Table 8, align closely
Aldawsari 2024). While the MMQR approach (Machado and                      with the MMQR outcomes. The consistency of results across
Santos Silva 2019) effectively handles these issues, these ad-             diverse methodologies reinforces the validity and reliability of
ditional methods serve as robustness checks to validate the                the study's conclusions. In all three robustness tests, positive

Sustainable Development, 2025                                                                                                           13
                                                                                                                                                 10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License




FIGURE 4    |    MMQR coefficients visualization for Models (3) and (4).



shocks (ECON+ and ECOP+) are associated with reductions                    shocks (ECON− and ECOP−) lead to increases in inequality,
in emissions inequality, indicating that advances in environ-              suggesting that any decline in innovation exacerbates the dis-
mental technologies and climate change mitigation efforts                  parity. Regarding the control parameters, it is observed that
aid in balancing the distribution of CO2 . Conversely, negative            still, GDP and GLO remain positive in all three tests. Likewise,


14                                                                                                               Sustainable Development, 2025
                                                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 8    |    Robustness tests.                                        TABLE 8    |    (Continued)

             Model (1)       Model (2)       Model (3)    Model (4)                  Model (1)         Model (2)   Model (3)     Model (4)
                                Panel (1). DOLS results                   ECON   −
                                                                                                         0.390
 ECON+       −0.783***                                                                                  (0.279)
               (0.149)                                                    ECOP   +
                                                                                                                   −0.569***
 ECON   −
                                  0.406                                                                             (0.137)
                                 (0.408)                                  ECOP   −
                                                                                                                                  0.514***
 ECOP+                                       −0.610***                                                                             (0.090)
                                              (0.120)                     GDP          0.565***          0.186      0.428**        0.250*
 ECOP   −
                                                          0.548***                      (0.147)         (0.238)     (0.194)        (0.133)
                                                           (0.144)        ECI         −0.919***        −1.056***   −1.480***     −1.277***
 GDP          0.595***            0.111        0.301*       0.222                       (0.169)         (0.359)     (0.290)        (0.196)
               (0.194)           (0.298)      (0.162)      (0.199)        TO          −0.349***        −0.448*     −0.605***     −0.481***
 ECI         −0.977***          −1.010**     −1.537***    −1.359***                     (0.134)         (0.258)     (0.199)        (0.141)
               (0.222)           (0.457)      (0.252)      (0.297)        GLO           1.270*           1.008      2.540**       1.658**
 TO           −0.384**           −0.452      −0.683***    −0.524**                      (0.655)         (1.285)     (1.095)        (0.716)
               (0.172)           (0.309)      (0.167)      (0.204)
 GLO            1.429*            0.896       3.041***     1.860*
                                                                         ECI and TO continue to exhibit adverse effects. Additionally,
               (0.858)           (1.551)       (0.918)     (1.052)       the directions of the coefficients of these variables agree with
                            Panel (2). FMOLS results                     those of the MMQR technique.

 ECON   +
             −0.626***
               (0.091)                                                   5.5   |   Heterogeneous Bootstrap Panel Causality
                                                                         Test Results
 ECON−                            0.285
                                 (0.214)                                 In the concluding stage of the empirical analysis, the het-
                                                                         erogeneous panel bootstrap causality test developed by Xiao
 ECOP+                                       −0.541***                   et al. (2023) is adopted to identify the cause-­and-­effect relation-
                                              (0.125)                    ships among the variables. Insights from this section, presented
                                                                         in Table 9 indicate that unidirectional causalities exist between
 ECOP−                                                    0.490***       ECON+ and CI, and, GDP and CI. It is also discovered that bidi-
                                                           (0.085)       rectional causalities exist between ECON− and CI, ECOP+ and CI,
                                                                         ECOP− and CI, ECI and CI, and TO and CI. However, no causal-
 GDP          0.539***            0.187       0.430**      0.259*
                                                                         ity was found between GLO and CI. First, the unidirectional cau-
               (0.141)           (0.233)       (0.191)     (0.133)       sality from ECON+ and GDP to CI suggests that advancements
                                                                         in eco-­innovation and economic growth serve as major factors
 ECI         −0.901***          −1.000***    −1.433***    −1.241***
                                                                         driving emissions inequality in G7 nations, with no influence
               (0.165)           (0.340)      (0.274)      (0.187)       from CI impacting these variables. In contrast, the bidirectional
                                                                         causalities identified between ECON− and CI, as well as between
 TO          −0.354***           −0.451*     −0.585***    −0.472***
                                                                         both ECOP+ and ECOP− and CI, indicate two-­way relationships.
               (0.130)           (0.249)      (0.192)      (0.138)       That is, a slowdown in green innovation leads to an increase in
 GLO            1.191*            0.887       2.366**      1.559**       emissions inequality, which in turn undermines the incentives
                                                                         and ability to foster further eco-­innovation. Additionally, con-
               (0.642)           (1.235)      (1.026)      (0.693)       cerning the bidirectional link between ECI and TO with CI, in
                                Panel (3). CCR results                   practice, as economies become more diversified and technolog-
                                                                         ically advanced, and as they open up more to global markets,
 ECON   +
             −0.682***                                                   they foster cleaner production processes and technology spill-
               (0.104)                                                   overs, which tend to reduce emissions inequality. At the same
                                                                         time, lower emissions inequality may create a more favorable
                                                           (Continues)   environment for further technological innovation and enhanced




Sustainable Development, 2025                                                                                                                15
                                                                                                                                                        10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 9    |    Outcomes of bootstrap Granger non-­causality test.               pollution (Jain 2024). As a result, the benefits of technological
                                                                                 progress, such as cleaner air and reduced carbon footprints
                          HPJ
                                                                                 become more even among households. Another avenue is that
 Direction of             Wald                             Causality
                                                                                 increased advancements lead to reduced costs of these tech-
 causality              statistic            p              result
                                                                                 nologies, enabling both sides of the economic divide to gain
 ECOP+ → CI               6.7853         0.0336*               ←                 access, resulting in a bridge in emissions-­    related inequal-
                                                         Unidirectional          ities. The major economic implication is that advancements
 CI → ECOP+               3.6229          0.1634
                                                                                 in green technologies can create a virtuous cycle that not
 ECON− → CI               5.9978         0.0498*        ↔ Bidirectional          only improves environmental outcomes but also promotes
                                                                                 economic and technological growth inclusion. Furthermore,
 CI → ECON−               9.4810        0.0087**
                                                                                 lower emissions inequality can boost public health, reduce
 OI → CI                 10.1372         0.0063**       ↔ Bidirectional          ecological remedy costs, and potentially, stimulate further
                                                                                 investments in green R&D which will promote sustainable
 CI → OI                 13.7594         0.0010**
                                                                                 development.
 PI → CI                 13.3436         0.0013**       ↔ Bidirectional
 CI → PI                 10.4544         0.0054**                                In practice, these dynamics are already observable across
                                                                                 the G7. For instance, Germany and Japan (who are leaders
 GDP → CI                 0.5758          0.7498               →                 in process eco-­innovation) have achieved significant emis-
                                                         Unidirectional          sion reductions through investments in renewable energy and
 CI → GDP                15.2753        0.0005**
                                                                                 industrial energy-­  efficiency programs. Similarly, Canada's
 ECI → CI                15.1302        0.0005**        ↔ Bidirectional          Clean Technology Data Strategy and the UK's Green Finance
 CI → ECI                16.2329        0.0003**                                 Strategy demonstrate how public funding for low-­c arbon in-
                                                                                 novation can diffuse clean technologies to small and medium
 TO → CI                 17.2006        0.0002**        ↔ Bidirectional          enterprises, thereby narrowing emission gaps across indus-
 CI → TO                  6.8738         0.0322*                                 tries in this bloc (OECD 2024).

 GLO → CI                 0.0193          0.9904          No causality
                                                                                 On the other hand, negative shocks (ECON− and ECOP−) pro-
 CI → GLO                 0.9280          0.6288                                 duce adverse effects, further worsening emissions inequality.
                                                                                 First, negative shocks, which imply stunted production or dis-
Abbreviations: CI, Carbon Intensity; ECI, Energy Consumption Intensity;
ECON, Eco-­Innovation; ECOP, Process eco-­innovation; GDP, Economic Growth;      rupted supply of eco-­technologies, would lead to an increased
GLO, Globalization; OI, Organizational Innovation; PI, Product Innovation; TO,   reliance on pollution technologies and reduced environmental
Trade Openness.
                                                                                 quality. Since wealthy groups consume more products and ser-
                                                                                 vices than their counterparts, emissions inequality is bound to
                                                                                 increase. An inference from this finding is that adverse shocks
trade relationships, reinforcing economic diversification and TO.                to eco-­innovation not only impede the transition to cleaner
Lastly, no causality was found between GLO and CI.                               technologies but also exacerbate emissions inequality, with sig-
                                                                                 nificant economic repercussions. In this situation, a decline in
                                                                                 overall productivity and a deepening of socioeconomic dispar-
6   |   Discussion and Implications                                              ities, ultimately undermining long-­term economic growth be-
                                                                                 come inevitable.
This study explores the impact of ECON and ECOP on carbon
emissions inequality among G7 nations, using data from 1993                      Throughout the findings, the control parameters exhibit con-
to 2023. Its analysis employs the MMQR technique which offers                    sistent outcomes in both negative and positive shock scenar-
more reliable estimates in the presence of estimation deficien-                  ios of ECON and ECOP. Specifically, economic growth (GDP)
cies (Machado and Santos Silva 2019), as well as three other ro-                 invariably shows a positive and significant relationship with
bust econometric techniques (DOLS, FMOLS, and CCR). This                         emissions inequality, implying that increases in economic
paper further explores the predictive correlations amongst the                   activity, without corresponding environmental safeguards,
variables via the bootstrap Granger technique. To enable a vivid                 tend to concentrate emissions among the wealthiest. This
understanding of the correlations, two scenarios—instances                       finding resonates with the EKC hypothesis and some earlier
of positive and negative shocks—are analyzed for both ECON                       studies that link emissions to rising economic activities (Khan
and ECOP.                                                                        et al. 2024; Narayan et al. 2016). Nevertheless, some recent
                                                                                 studies evidence that this trend is undergoing a gradual trans-
The initial results from the MMQR point out that positive                        formation, particularly in G7 nations (Destek et al. 2020). For
shocks in both ECON and ECOP are associated with signifi-                        example, the UK, France, Germany, and Italy have shown par-
cant reductions in emissions inequality. In other words, ad-                     tial decoupling between GDP growth and carbon emissions
vancements in green technologies lead to a more equitable                        since 2015 due to stricter energy-­   efficiency standards and
distribution of emissions, suggesting that the benefits of clean                 green taxation reforms. While others strive to reach this mile-
technological progress extend across different sectors, thereby                  stone, the United States, however, still records high emissions
mitigating environmental disparities. Generally, these ad-                       inequality. This implies that in the U.S., wealthier groups may
vancements enable individuals and industries to adopt cleaner                    have far greater access to clean technologies such as electric
practices, easing the environmental burden caused by carbon                      vehicles, renewable energy, and energy-­efficient homes, while

16                                                                                                                      Sustainable Development, 2025
                                                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
lower-­income populations rely more on carbon-­intensive op-         investments in eco-­  innovation, ensuring that both process-­
tions. This uneven access widens emissions inequality, as the        specific and aggregate technological advancements are not
environmental and health burdens of pollution fall dispropor-        only incentivized but also accessible to all sectors of society.
tionately on poorer communities.                                     Regulators and policymakers should provide incentives such
                                                                     as tax credits and grants to firms that adopt eco-­friendly ini-
A similar positive influence is found for globalization (GLO),       tiatives. These incentives can reduce the cost and increase the
suggesting that increased global integration, in the absence of      availability of green technologies, reducing emissions inequal-
targeted environmental policies and robust government regula-        ity. Additionally, managers should enhance their emission dis-
tions, can drive up carbon consumption among the privileged          closure and sustainability reporting, supporting sustainable
and exacerbate emissions inequality. Meaning, globalization,         practices that have a positive impact on the environment. These
though beneficial for economic development and the spread of         practices would not only reduce emissions but also foster equi-
technology, could lead to the concentration of environmental         table economic growth by guaranteeing that the environmental
benefits in wealthier groups or nations. As discussed, this can      merits of technological progress are distributed across different
occur because the affluent have the resources to access global       socioeconomic groups.
markets and advanced, yet carbon-­heavy, consumption choices,
which add up to carbon leakage. Remedying this situation re-         The results also suggest that economic expansion and global-
quires multi-­layered policy responses, one of which would be        ization, in the absence of strong environmental policies, could
the adoption of carbon border tax initiatives—similar to the         exacerbate emissions inequality. Thus, a balanced approach is
EU's proposed Carbon Border Adjustment Mechanism (CBAM).             necessary, one that encourages economic development while in-
Such policies would impose tariffs on imports and services from      tegrating robust environmental safeguards. Governments should
regions with less stringent climate policies, thereby promoting      consider policies that promote green trade agreements and in-
cleaner production globally. This will cut emissions and, im-        dustry collaborations to further spread eco-­technologies across
portantly, bridge the emissions inequality gap. Additionally, in-    borders and reduce emissions inequality. Furthermore, fostering
dustry collaborations within and across borders can ensure that      economic complexity through enhanced R&D, education, and in-
green technologies become more available and reach all income        novation infrastructure can help reduce emissions inequality in
groups. In contrast, economic complexity (ECI) and TO (TO)           the long term. While the findings of this study offer important un-
exhibit negative coefficients, suggesting that more diversified,     derstanding of the connection between eco-­innovation and emis-
technologically advanced economies and those with greater            sions inequality, a number of limitations must be acknowledged.
integration into global markets experience lower emissions in-       First, the analysis relies on longitudinal data from 1990 to 2023,
equality. In the case of ECI, policies that strengthen innovation,   which may not capture more recent, dynamic shifts in the global
such as R&D investment, improving education, and promoting a         economy or technological advancements. Additionally, the study
robust financial sector will further curtail emissions inequality.   focuses exclusively on G7 nations, which may not fully represent
For TO, this study calls for the implementation of trade policies    the challenges and solutions applicable to non-­G7 countries or
that incorporate stringent environmental standards. It is also       emerging economies.
recommended that more consideration be given to establishing
green trade agreements to ensure the production, distribution,       Future research could broaden the scope of this study by includ-
and consumption of more eco-­sustainable products.                   ing a more diverse set of countries, particularly those outside the
                                                                     G7, to better understand how eco-­innovation influences emis-
                                                                     sions inequality in varying economic contexts. Additionally,
7   |   Concluding Remarks                                           expanding the analysis to incorporate emerging green technol-
                                                                     ogies, such as electric vehicles, renewable energy storage solu-
This study investigates the environmental dynamics and car-          tions, or climate adaptation technologies, would provide further
bon emissions inequality in the G7 countries from 1990 to            insights into how these innovations contribute to reducing emis-
2023, with a particular focus on the impact of eco-­innovation.      sions inequality across different regions and income groups.
To achieve this objective, we use the MMQR technique, as well
as three other robust econometric techniques (DOLS, FMOS,
and CCR). Our findings highlight the significant role of both
                                                                     Author Contributions
process-­specific (ECOP) and aggregate eco-­innovation (ECON)
in reducing emissions inequality, suggesting that advancements       Brahim Bergougui: conceptualization, methodology, formal analysis,
in green technologies can lead to a more equitable distribution      data curation, econometric modeling, writing – original draft preparation,
                                                                     visualization, and overall supervision. Buhari Doğan: writing – review
of emissions across different socioeconomic groups. In particu-
                                                                     and editing. Emmanuel Yamoah Cobbold: conceptual contributions,
lar, positive shocks in both ECOP and ECON lead to significant       interpretation of findings, policy discussion development, and writing –
reductions in emissions inequality, promoting environmental          review and editing. Hayet Soltani: writing – review and editing. Hamid
justice by facilitating access to cleaner technologies across all    Ghazi H Sulimany: funding acquisition and review and editing. Ehab
sectors. However, negative shocks to eco-­innovation exacerbate      Ebrahim Mohamed Ebrahim: contributions to the discussion and
emissions inequality, emphasizing the importance of uninter-         implications of the results. All authors have read and approved the final
                                                                     manuscript.
rupted progress in green technology innovation to avoid deep-
ening socioeconomic disparities.
                                                                     Acknowledgments
The policy implications of these findings are far-­reaching. First   The authors thank Taif University, Saudi Arabia, for supporting this
and foremost, governments in the G7 nations should prioritize        work through project number (TU-­DSPP-­2 024-­303). The article was


Sustainable Development, 2025                                                                                                               17
                                                                                                                                                                     10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
prepared within the framework of the Basic Research Program of the                Bergougui, B. 2024a. “Algeria's Pathway to COP28 and SDGs:
HSE University.                                                                   Asymmetric Impact of Environmental Technology, Energy Productivity,
                                                                                  and Material Resource Efficiency on Environmental Sustainability.”
                                                                                  Energy Strategy Reviews 55: 101541. https://​doi.​org/​10.​1016/j.​esr.​2 024.​
Funding
                                                                                  101541.
This research was funded by Taif University, Saudi Arabia, Project No.
                                                                                  Bergougui, B. 2024b. “Investigating the Relationships Among Green
(TU-­DSPP-­2 024-­303).
                                                                                  Technologies, Financial Development and Ecological Footprint
                                                                                  Levels in Algeria: Evidence From a Novel Fourier ARDL Approach.”
                                                                                  Sustainable Cities and Society 112: 105621. https://​doi.​org/​10.​1016/j.​scs.​
References                                                                        2024.​105621.
Afshan, S., I. Ozturk, and T. Yaqoob. 2022. “Facilitating Renewable               Bergougui, B. 2025. “Can Artificial Intelligence Mitigate Environmental
Energy Transition, Ecological Innovations and Stringent Environmental             Inequality? Evidence From Leading Robotic-­Driven Economies Using
Policies to Improve Ecological Sustainability: Evidence From MM-­QR               Quantile-­Based Methods.” Borsa Istanbul Review 25: 1316–1336. https://​
Method.” Renewable Energy 196: 151–160. https://​doi.​org/​10.​1016/j.​           doi.​org/​10.​1016/j.​bir.​2 025.​07.​012.
renene.​2 022.​0 6.​125.
                                                                                  Bergougui, B., and M. I. Aldawsari. 2024. “Asymmetric Impact of
Aghion, P., and R. Griffith. 2024. “Innovation and Inequalities.” Oxford          Patents on Green Technologies on Algeria's Ecological Future.” Journal
Open Economics 3, no. 1: i1002–i1005.                                             of Environmental Management 355: 120426. https://​doi.​org/​10.​1016/j.​
                                                                                  jenvm​an.​2 024.​120426.
Ahmad, M., P. Jiang, M. Murshed, et al. 2021. “Modelling the
Dynamic Linkages Between Eco-­Innovation, Urbanization, Economic                  Bergougui, B., O. Ben-­Salha, and S. M. Murshed. 2025. “How Income
Growth and Ecological Footprints for G7 Countries: Does Financial                 Inequality Drives Climate Inequality in the World's Largest Emitting
Globalization Matter?” Sustainable Cities and Society 70: 102881.                 Nations: Novel Evidence From Multivariate Quantile-­On-­Quantile and
https://​doi.​org/​10.​1016/j.​scs.​2 021.​102881.                                Wavelet Quantile Methods.” Journal of Cleaner Production 513: 145666.
                                                                                  https://​doi.​org/​10.​1016/j.​jclep​ro.​2 025.​145666.
Ahmed, A., G. S. Uddin, and K. Sohag. 2016. “Biomass Energy,
Technological Progress and the Environmental Kuznets Curve:                       Bergougui, B., R. H. Boudjana, S. Mehibel, and M. A. Zambrano-­
Evidence From Selected European Countries.” Biomass and Bioenergy                 Monserrate. 2024. “How Do Institutional Quality and Income
90: 202–208. https://​doi.​org/​10.​1016/j.​biomb​ioe.​2 016.​0 4.​0 04.          Asymmetrically Affect Carbon Emissions Inequality? A Quantile-­
                                                                                  On-­Q uantile Assessment for Six Major Global Emitters.” Journal of
Ahmed, K., M. U. Rehman, and I. Ozturk. 2017. “What Drives Carbon
                                                                                  Cleaner Production 483: 144215. https://​doi.​org/​10.​1016/j.​jclep​ro.​
Dioxide Emissions in the Long-­Run? Evidence From Selected South
                                                                                  2024.​144215.
Asian Countries.” Renewable and Sustainable Energy Reviews 70: 1142–
1153. https://​doi.​org/​10.​1016/j.​rser.​2 016.​12.​018.                        Bergougui, B., B. Doğan, S. Ghosh, and H. Ayad. 2024. “Impact of
                                                                                  Environmental Technology, Economic Complexity, and Geopolitical
Akram, R., R. L. Ibrahim, Z. Wang, T. S. Adebayo, and M. Irfan.
                                                                                  Risk on Carbon Emission Inequality in Developed and Developing
2023. “Neutralizing the Surging Emissions Amidst Natural Resource
                                                                                  Countries: Evidence From a PVAR-­  GMM Approach.” Environment,
Dependence, Eco-­    Innovation, and Green Energy in G7 Countries:
                                                                                  Development and Sustainability. https://​doi.​org/​10.​1007/​s1066​8-­​024-­​
Insights for Global Environmental Sustainability.” Journal of
                                                                                  05715​-­​x.
Environmental Management 344: 118560. https://​doi.​org/​10.​1016/j.​
jenvm​an.​2 023.​118560.                                                          Bergougui, B., S. Mehibel, and R. H. Boudjana. 2024. “Asymmetric
                                                                                  Nexus Between Green Technologies, Economic Policy Uncertainty,
Amin, M., S. Zhou, and A. Safi. 2022. “The Nexus Between
                                                                                  and Environmental Sustainability: Evidence From Algeria.” Journal
Consumption-­Based Carbon Emissions, Trade, Eco-­Innovation, and
                                                                                  of Environmental Management 360: 121172. https://​doi.​org/​10.​1016/j.​
Energy Productivity: Empirical Evidence From N-­          11 Economies.”
                                                                                  jenvm​an.​2 024.​121172.
Environmental Science and Pollution Research 29, no. 26: 39239–39248.
https://​doi.​org/​10.​1007/​s1135​6 -­​021-­​18327​-­​z.                         Blomquist, J., and J. Westerlund. 2013. “Testing Slope Homogeneity
                                                                                  in Large Panels With Serial Correlation.” Economics Letters 121, no. 3:
Antweiler, W., B. R. Copeland, and M. S. Taylor. 2001. “Is Free Trade
                                                                                  374–378.
Good for the Environment?” American Economic Review 91, no. 4: 877–
908. https://​doi.​org/​10.​1257/​aer.​91.4.​877.                                 Boyce, J. K. 1994. “Inequality as a Cause of Environmental Degradation.”
                                                                                  Ecological Economics 11, no. 3: 169–178. https://​doi.​org/​10.​1016/​0 921-­​
Awaworyi Churchill, S., J. Inekwe, R. Smyth, and X. Zhang. 2019.
                                                                                  8009(94)​9 0198​-­​8.
“R&D Intensity and Carbon Emissions in the G7: 1870–2014.” Energy
Economics 80: 30–37. https://​doi.​org/​10.​1016/j.​eneco.​2 018.​12.​020.        Chancel, L., and T. Piketty. 2015. “Carbon and Inequality: From Kyoto
                                                                                  to Paris. Paris School of Economics.” 48.
Aydin, M., T. Degirmenci, T. Gurdal, and H. Yavuz. 2023. “The Role
of Green Innovation in Achieving Environmental Sustainability in                  Chien, F., C. Hsu, Z. Andlib, M. I. Shah, T. Ajaz, and M. G. Genie.
European Union Countries: Testing the Environmental Kuznets Curve                 2022. “The Role of Solar Energy and Eco-­           Innovation in Reducing
Hypothesis.” Gondwana Research 118: 105–116. https://​doi.​org/​10.​              Environmental Degradation in China: Evidence From QARDL
1016/j.​gr.​2 023.​01.​013.                                                       Approach.” Integrated Environmental Assessment and Management 18,
                                                                                  no. 2: 555–571. https://​doi.​org/​10.​1002/​ieam.​4500.
Aye, G. C., and P. E. Edoja. 2017. “Effect of Economic Growth on CO2
Emission in Developing Countries: Evidence From a Dynamic Panel                   Cobbold, E. Y., Y. Li, and E. S. Obobisa. 2024. “Technology Transfer
Threshold Model.” Cogent Economics & Finance 5, no. 1: 1379239.                   and Innovation Through Trade; Assessing the Role of Low Carbon
https://​doi.​org/​10.​1080/​23322​039.​2 017.​1379239.                           Technologies Imports on Domestic Green Innovation.” Journal of
                                                                                  Technology Transfer 50, no. 4: 1785–1814.
Barbieri, N., D. Consoli, G. Marin, and F. Perruchas. 2023. “Green
Technology and Income Inequality: An Empirical Analysis of US Metro               Copeland, B. R., and M. S. Taylor. 2004. “Trade, Growth, and the
Areas.” Regional Studies 59, no. 1: 1–4.                                          Environment.” Journal of Economic Literature 42, no. 1: 7–71. https://​
                                                                                  doi.​org/​10.​1257/​0 0220​51047​73558047.
Ben Amara, D., and H. Chen. 2020. “A Mediation-­Moderation Model
of Environmental and Eco-­     Innovation Orientation for Sustainable             Costa, D. d. A., Y. Bayissa, M. D. Villas-­Boas, et al. 2024. “Water
Business Growth.” Environmental Science and Pollution Research 27,                Availability and Extreme Events Under Climate Change Scenarios in
no. 14: 16916–16928. https://​doi.​org/​10.​1007/​s1135​6 -­​020-­​08206​- ­​4.   an Experimental Watershed of the Brazilian Atlantic Forest.” Science


18                                                                                                                                Sustainable Development, 2025
                                                                                                                                                                          10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
of the Total Environment 946: 174417. https://​doi.​org/​10.​1016/j.​scito​tenv.​    Hou, A., A. Liu, and L. Chai. 2024. “Does Reducing Income Inequality
2024.​174417.                                                                        Promote the Decoupling of Economic Growth From Carbon Footprint?”
                                                                                     World Development 173: 106423.
Destek, M. A., M. Shahbaz, I. Okumus, S. Hammoudeh, and A. Sinha.
2020. “The Relationship Between Economic Growth and Carbon                           Im, K. S., M. H. Pesaran, and Y. Shin. 2003. “Testing for Unit Roots in
Emissions in G-­7 Countries: Evidence From Time-­Varying Parameters                  Heterogeneous Panels.” Journal of Econometrics 115, no. 1: 53–74.
With a Long History.” Environmental Science and Pollution Research 27:
                                                                                     Jain, H. 2024. “From Pollution to Progress: Groundbreaking Advances
29100–29117.
                                                                                     in Clean Technology Unveiled.” Innovation and Green Development 3,
Doğan, B., B. Saboori, and M. Can. 2019. “Does Economic Complexity                   no. 2: 100143.
Matter for Environmental Degradation? An Empirical Analysis for
                                                                                     Jauregui, I., A. Chiabai, and M. B. Neumann. 2026. “A Review on the
Different Stages of Development.” Environmental Science and Pollution
                                                                                     Effects of Climate Change and Pollution on Vibrio Infection Dynamics.”
Research 26, no. 31: 31900–31912. https://​doi.​org/​10.​1007/​s1135​6 -­​019-­​
                                                                                     Environmental Impact Assessment Review 116: 108126. https://​doi.​org/​
06333​-­​1.
                                                                                     10.​1016/j.​eiar.​2 025.​108126.
Dreher, A. 2006. “Does Globalization Affect Growth? Evidence From a
New Index of Globalization.” Applied Economics 38, no. 10: 1091–1110.                Jha, M. K., and M. Dev. 2024. “Impacts of Climate Change.” In Smart
                                                                                     Internet of Things for Environment and Healthcare, 139–159. Springer
Erdoğan, S., S. Yıldırım, D. Ç. Yıldırım, and A. Gedikli. 2020. “The                 Nature Switzerland. https://​doi.​org/​10.​1007/​978-­​3 -­​031-­​70102​-­​3 _​10.
Effects of Innovation on Sectoral Carbon Emissions: Evidence From
G20 Countries.” Journal of Environmental Management 267: 110637.                     Jorgenson, A., J. Schor, and X. Huang. 2017. “Income Inequality and
https://​doi.​org/​10.​1016/j.​jenvm​an.​2 020.​110637.                              Carbon Emissions in the United States: A State-­L evel Analysis, 1997–
                                                                                     2012.” Ecological Economics 134: 40–48. https://​doi.​org/​10.​1016/j.​ecole​
Fernández Fernández, Y., M. A. Fernández López, and B. Olmedillas                    con.​2 016.​12.​016.
Blanco. 2018. “Innovation for Sustainability: The Impact of R&D
Spending on CO2 Emissions.” Journal of Cleaner Production 172: 3459–                 Kahneman, D., and A. Tversky. 1979. “Prospect Theory: An Analysis of
3467. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 017.​11.​0 01.                      Decision Under Risk.” Econometrica 47, no. 2: 263–291. https://​doi.​org/​
                                                                                     10.​2307/​1914185.
Figge, L., K. Oebels, and A. Offermans. 2017. “The Effects of
Globalization on Ecological Footprints: An Empirical Analysis.”                      Kaldellis, J. K., K. J. Chalvatzis, and G. C. Spyropoulos. 2007.
Environment, Development and Sustainability 19, no. 3: 863–876. https://​            “Transboundary Air Pollution Balance in the New Integrated European
doi.​org/​10.​1007/​s1066​8-­​016-­​9769-­​8.                                        Environment.” Environmental Science & Policy 10, no. 7: 725–733.
                                                                                     https://​doi.​org/​10.​1016/j.​envsci.​2 007.​0 6.​0 02.
Fuso Nerini, F., B. Sovacool, N. Hughes, et al. 2019. “Connecting
Climate Action With Other Sustainable Development Goals.” Nature                     Kao, C. 1999. “Spurious Regression and Residual-­     Based Tests for
Sustainability 2, no. 8: 674–680. https://​doi.​org/​10.​1038/​s 4189​               Cointegration in Panel Data.” Journal of Econometrics 90: 1–44.
3-­​019-­​0334-­​y.                                                                  Khan, I., R. Zhong, H. Khan, Y. Dong, and F. M. Nuţă. 2024. “Examining
Gente, V., and G. Pattanaro. 2019. “The Place of Eco-­Innovation in the              the Relationship Between Technological Innovation, Economic Growth
Current Sustainability Debate.” Waste Management 88: 96–101. https://​               and Carbon Dioxide Emission: Dynamic Panel Data Evidence.”
doi.​org/​10.​1016/j.​wasman.​2 019.​03.​026.                                        Environment, Development and Sustainability 26: 18161–18180.

Griscom, B. W., J. Adams, P. W. Ellis, et al. 2017. “Natural Climate                 Khan, M. B., H. Saleem, M. S. Shabbir, and X. Huobao. 2022. “The
Solutions.” Proceedings of the National Academy of Sciences of the United            Effects of Globalization, Energy Consumption and Economic Growth
States of America 114, no. 44: 11645–11650. https://​doi.​org/​10.​1073/​            on Carbon Dioxide Emissions in South Asian Countries.” Energy &
pnas.​17104​65114​.                                                                  Environment 33, no. 1: 107–134. https://​doi.​org/​10.​1177/​0 9583​05X20​
                                                                                     986896.
Grossman, G. M., and A. B. Krueger. 1995. “Economic Growth and the
Environment*.” Quarterly Journal of Economics 110, no. 2: 353–377.                   Khan, M. K., J.-­Z . Teng, M. I. Khan, and M. O. Khan. 2019. “Impact
https://​doi.​org/​10.​2307/​2118443.                                                of Globalization, Economic Factors and Energy Consumption on CO2
                                                                                     Emissions in Pakistan.” Science of the Total Environment 688: 424–436.
Guo, J., L. Yang, and S. Cao. 2025. “Mitigating Risks of Natural and                 https://​doi.​org/​10.​1016/j.​scito​tenv.​2 019.​0 6.​0 65.
Human-­Made Disasters Caused by Excessive Urbanization.” Journal
of Chinese Architecture and Urbanism 7: 5320. https://​doi.​org/​10.​36922/​​        Kim, D.-­H., Y.-­B. Suen, and S.-­C. Lin. 2019. “Carbon Dioxide Emissions
jcau.​5320.                                                                          and Trade: Evidence From Disaggregate Trade Data.” Energy Economics
                                                                                     78: 13–28. https://​doi.​org/​10.​1016/j.​eneco.​2 018.​08.​019.
Haq, Z. U., U. Mehmood, S. Tariq, and A. Mariam. 2024. “The Impacts of
Globalization and GDP on CO2 Emissions: Do Technological Innovation                  Kinyar, A., and K. Bothongo. 2024. “The Impact of Renewable Energy,
and Renewable Energy Lower Some Burden in SAARC Countries.”                          Eco-­Innovation, and GDP Growth on CO2 Emissions: Pathways to the
Journal of the Knowledge Economy 15, no. 4: 15499–15522. https://​doi.​              UK'S Net Zero Target.” Journal of Environmental Management 368:
org/​10.​1007/​s1313​2-­​023-­​01704​-­​z.                                           122226. https://​doi.​org/​10.​1016/j.​jenvm​an.​2 024.​122226.

Hartmann, D., M. R. Guevara, C. Jara-­Figueroa, M. Aristarán, and C.                 Kyriakopoulou, D., G. Kyriacou, and N. Pearson. 2023. How Does Trade
A. Hidalgo. 2017. “Linking Economic Complexity, Institutions, and                    Contribute to Climate Change and How Can It Advance Climate Action?
Income Inequality.” World Development 93: 75–93. https://​doi.​org/​10.​             Business and Climate Change.
1016/j.​world​dev.​2 016.​12.​020.
                                                                                     Li, G., and W. Wei. 2021. “Financial Development, Openness, Innovation,
Hasna, Z., F. Jaumotte, and S. Pienknagura. 2023. How Green Innovation               Carbon Emissions, and Economic Growth in China.” Energy Economics
Can Stimulate Economies and Curb Emissions. IMF Blog.                                97: 105194. https://​doi.​org/​10.​1016/j.​eneco.​2 021.​105194.
Henriques, S. T., and K. J. Borowiecki. 2017. “The Drivers of Long-­                 Li, L., Y. Zhang, C.-­C. Hsu, N. T. Vinh, K. N. Tran, and T. Q. Ngo.
Run CO2 Emissions in Europe, North America and Japan Since 1800.”                    2023. “The Impact of Eco-­    Innovation and Economic Growth on
Energy Policy 101: 537–549. https://​doi.​org/​10.​1016/j.​enpol.​2 016.​11.​0 05.   Carbon Emission: Evidence Using Novel QARDL Approach.” Energy &
                                                                                     Environment 36, no. 5: 2493–2514. https://​doi.​org/​10.​1177/​0 9583​05X23​
Hong, M., C. Song, M. Kim, et al. 2025. “Realizing Climate Resilient
                                                                                     1184552.
Development Pathways in Forestry: A Focus on Carbon Management
in Republic of Korea.” Environmental Impact Assessment Review 110:                   Li, Q., U. S. Maqsood, R. M. A. Zahid, and W. Anwar. 2024. “Regulating
107665. https://​doi.​org/​10.​1016/j.​eiar.​2 024.​107665.                          CEO Pay and Green Innovation: Moderating Role of Social Capital and


Sustainable Development, 2025                                                                                                                                      19
                                                                                                                                                                       10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Government Subsidy.” Environmental Science and Pollution Research                    Sadiq, M., K. Y. Chau, N. T. T. Ha, T. T. H. Phan, T. Q. Ngo, and P. Q.
31, no. 34: 46163–46177. https://​doi.​org/​10.​1007/​s1135​6 -­​023-­​26641​-­​x.   Huy. 2024. “The Impact of Green Finance, Eco-­Innovation, Renewable
                                                                                     Energy and Carbon Taxes on CO2 Emissions in BRICS Countries:
Li, Y., N. Jia, X. Yu, N. Manning, X. Lan, and J. Liu. 2023. “Transboundary
                                                                                     Evidence From CS ARDL Estimation.” Geoscience Frontiers 15, no. 4:
Flows in the Metacoupled Anthropocene: Typology, Methods, and
                                                                                     101689.
Governance for Global Sustainability.” Ecology and Society 28, no. 3:
art19. https://​doi.​org/​10.​5751/​E S-­​14351​-­​280319.                           Sadiq, M., R. Shinwari, F. Wen, M. Usman, S. T. Hassan, and F.
                                                                                     Taghizadeh-­ Hesary. 2023. “Do Globalization and Nuclear Energy
Machado, J. A. F., and J. M. C. Santos Silva. 2019. “Quantiles via
                                                                                     Intensify the Environmental Costs in Top Nuclear Energy-­Consuming
Moments.” Journal of Econometrics 213, no. 1: 145–173. https://​doi.​org/​
                                                                                     Countries?” Progress in Nuclear Energy 156: 104533. https://​doi.​org/​10.​
10.​1016/j.​jecon​om.​2 019.​0 4.​0 09.
                                                                                     1016/j.​pnuce​ne.​2 022.​104533.
Mensah, C. N., X. Long, K. B. Boamah, I. A. Bediako, L. Dauda, and M.
                                                                                     Saqib, N., and G. Dincă. 2024. “Exploring the Asymmetric Impact
Salman. 2018. “The Effect of Innovation on CO2 Emissions of OCED
                                                                                     of Economic Complexity, FDI, and Green Technology on Carbon
Countries From 1990 to 2014.” Environmental Science and Pollution
                                                                                     Emissions: Policy Stringency for Clean-­Energy Investing Countries.”
Research 25, no. 29: 29678–29698. https://​doi.​org/​10.​1007/​s1135​
                                                                                     Geoscience Frontiers 15, no. 4: 101671.
6-­​018-­​2968-­​0.
                                                                                     Semet, R. 2024. “Coordinating Social Equity and Emissions: Challenges
Narayan, P. K., B. Saboori, and A. Soleymani. 2016. “Economic Growth                 in Carbon Tax Policy.” Energy Policy 185: 113954.
and Carbon Emissions.” Economic Modelling 53: 388–397.
                                                                                     Shahbaz, M., S. Khan, A. Ali, and M. Bhattacharya. 2017. “The Impact
Neagu, O., and M. C. Teodoru. 2019. “The Relationship Between                        of Globalization on CO2 Emissions in China.” Singapore Economic
Economic Complexity, Energy Consumption Structure and Greenhouse                     Review 62, no. 4: 929–957. https://​doi.​org/​10.​1142/​S 0217​59081​7400331.
Gas Emission: Heterogeneous Panel Evidence From the EU Countries.”
Sustainability 11, no. 2: 2. https://​doi.​org/​10.​3390/​su110​2 0497​.             Shin, Y., B. Yu, and M. Greenwood-­      Nimmo. 2014. “Modelling
                                                                                     Asymmetric Cointegration and Dynamic Multipliers in a Nonlinear
Obobisa, E. S. 2023. “An Econometric Study of Eco-­Innovation, Clean                 ARDL Framework.” In Festschrift in Honor of Peter Schmidt:
Energy, and Trade Openness Toward Carbon Neutrality and Sustainable                  Econometric Methods and Applications, edited by R. C. Sickles and W.
Development in OECD Countries.” Sustainable Development 32, no. 4:                   C. Horrace, 281–314. Springer New York. https://​doi.​org/​10.​1007/​978-­​1-­​
3075–3099.                                                                           4899-­​8008-­​3 _​9.
OECD. 2024. “Technology Development by Inventor Country.” In OECD                    Singh, S. 2021. “Energy Crisis and Climate Change: Global Concerns
Environment Statistics. OECD. https://​doi.​org/​10.​1787/​data-­​0 0760​- ­​en.     and Their Solutions.” In Energy: Crises, Challenges and Solutions, 1–17.
Oh, K.-­Y., and I. Bhuyan. 2018. “Trade Openness and CO2 Emissions:                  https://​doi.​org/​10.​1002/​97811​19741​503.​ch1.
Evidence of Bangladesh.” Asian Journal of Atmospheric Environment                    Sohag, K., M. Al Mamun, G. S. Uddin, and A. M. Ahmed. 2017. “Sectoral
12, no. 1: 30–36. https://​doi.​org/​10.​5572/​ajae.​2 018.​12.1.​030.               Output, Energy Use, and CO2 Emission in Middle-­Income Countries.”
Olanrewaju, V. O., M. Irfan, M. Altuntaş, E. B. Agyekum, S. Kamel,                   Environmental Science and Pollution Research 24, no. 10: 9754–9764.
and M. F. El-­Naggar. 2022. “Towards Sustainable Environment in G7                   https://​doi.​org/​10.​1007/​s1135​6 -­​017-­​8599-­​z.
Nations: The Role of Renewable Energy Consumption, Eco-­Innovation                   Sovacool, B., P. Newell, S. Carley, and J. Fanzo. 2022. “Equity,
and Trade Openness.” Frontiers in Environmental Science 10: 925822.                  Technological Innovation and Sustainable Behaviour in a Low-­Carbon
https://​doi.​org/​10.​3389/​fenvs.​2 022.​925822.                                   Future.” Nature Human Behaviour 6: 326–337. https://​doi.​org/​10.​1038/​
Ozturk, S., M. Cetin, and H. Demir. 2022. “Income Inequality and                     s4156​2- ­​021- ­​01257​-­​8.
CO2 Emissions: Nonlinear Evidence From Turkey.” Environment,                         Sultana, T., M. S. Hossain, L. C. Voumik, and A. Raihan. 2023. “Does
Development and Sustainability 24, no. 10: 11911–11928. https://​doi.​org/​          Globalization Escalate the Carbon Emissions ? Empirical Evidence
10.​1007/​s1066​8-­​021-­​01922​-­​y.                                                From Selected Next-­11 Countries.” Energy Reports 10: 86–98.
Pata, U. K., M. M. Dam, and F. Kaya. 2023. “How Effective Are                        Sun, H., L. Enna, A. Monney, D. K. Tran, E. Rasoulinezhad, and F.
Renewable Energy, Tourism, Trade Openness, and Foreign Direct                        Taghizadeh-­Hesary. 2020. “The Long-­Run Effects of Trade Openness
Investment on CO2 Emissions ? An EKC Analysis for ASEAN Countries.”                  on Carbon Emissions in Sub-­Saharan African Countries.” Energies 13,
Environmental Science and Pollution Research 30: 14821–14837.                        no. 20: 20. https://​doi.​org/​10.​3390/​en132​05295​.
Pedroni, P. 2004. “Panel Cointegration: Asymptotic and Finite Sample                 Sun, Y., F. Yesilada, Z. Andlib, and T. Ajaz. 2021. “The Role of Eco-­
Properties of Pooled Time Series Tests With an Application to the PPP                Innovation and Globalization Towards Carbon Neutrality in the USA.”
Hypothesis.” Econometric Theory 20: 597–625.                                         Journal of Environmental Management 299: 113568. https://​doi.​org/​10.​
Pesaran, M. H. 2007. “A Simple Panel Unit Root Test in the Presence                  1016/j.​jenvm​an.​2 021.​113568.
of Cross Section Dependence.” Journal of Applied Econometrics 22:                    Vaishnav, P. 2023. “Implications of Green Technologies for
265–312.                                                                             Environmental Justice.” Annual Review of Environment and Resources
                                                                                     48: 505–530.
Rahko, J., and A. A. Alola. 2024. “The Effects of Climate Change
Technology Spillovers on Carbon Emissions Across European                            Wang, Q., F. Zhang, and R. Li. 2024. “Free Trade and Carbon Emissions
Countries.” Journal of Environmental Management 370: 122972.                         Revisited: The Asymmetric Impacts of Trade Diversification and Trade
                                                                                     Openness.” Sustainable Development 32, no. 1: 876–901.
Rasheed, M., and J. Liu. 2024. “Unraveling Consumption-­Based Carbon
Dioxide Emissions: Sectoral Analysis and Temporal Dynamics in G7                     Wang, W., Y. Li, N. Lu, D. Wang, H. Jiang, and C. Zhang. 2020. “Does
Economies.” Natural Resources Forum. Portico. https://​doi.​org/​10.​1111/​          Increasing Carbon Emissions Lead to Accelerated Eco-­           Innovation?
1477-​8947.​12521​.                                                                  Empirical Evidence From China.” Journal of Cleaner Production 251:
                                                                                     119690. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 019.​119690.
Ren, Y., Y. Mo, and W. You. 2025. “Economic Complexity, CO2
Emissions, and the Mediating Roles of Energy Structure and Energy                    Westerlund, J. 2007. “Testing for Error Correction in Panel Data.”
Efficiency: A Spatial Panel Analysis.” Applied Economics 57, no. 1: 1–15.            Oxford Bulletin of Economics and Statistics 69: 709–748.
https://​doi.​org/​10.​1080/​0 0036​8 46.​2 024.​2302930.
                                                                                     Xiao, J., Y. Karavias, A. Juodis, V. Sarafidis, and J. Ditzen. 2023.
Romero, J. P., and C. Gramkow. 2021. “Economic Complexity and                        “Improved Tests for Granger Noncausality in Panel Data.” Stata Journal
Greenhouse Gas Emissions.” World Development 139: 105317.                            23, no. 1: 230–242. https://​doi.​org/​10.​1177/​15368​67X23​1162034.


20                                                                                                                                  Sustainable Development, 2025
                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70525 by Brahim Bergougui - Erasmus University Rotterdam Universiteitsbibliotheek , Wiley Online Library on [17/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Xiaoman, W., A. Majeed, D. G. Vasbieva, C. E. W. Yameogo, and N.
Hussain. 2021. “Natural Resources Abundance, Economic Globalization,
and Carbon Emissions: Advancing Sustainable Development Agenda.”
Sustainable Development 29, no. 5: 1037–1048.
Xu, C. 2020. “Determinants of Carbon Inequality in China From Static
and Dynamic Perspectives.” Journal of Cleaner Production 277: 123286.
https://​doi.​org/​10.​1016/j.​jclep​ro.​2 020.​123286.
Xu, C., B. Wang, J. Chen, Z. Shen, M. Song, and J. An. 2022. “Carbon
Inequality in China: Novel Drivers and Policy Driven Scenario
Analysis.” Energy Policy 170: 113259. https://​doi.​org/​10.​1016/j.​enpol.​
2022.​113259.
Yurtkuran, S. 2021. “The Effect of Agriculture, Renewable Energy
Production, and Globalization on CO2 Emissions in Turkey: A Bootstrap
ARDL Approach.” Renewable Energy 171: 1236–1245. https://​doi.​org/​
10.​1016/j.​renene.​2 021.​03.​0 09.
Zhang, S.-­H., J. Yang, and C. Feng. 2024. “Tracking Household Carbon
Inequality in China: Composition Effect or Coefficient Effect?” Journal
of Environmental Management 351: 119743. https://​doi.​org/​10.​1016/j.​
jenvm​an.​2 023.​119743.
Zhao, L., K. M. Chong, L.-­M. Gooi, and L. Yan. 2024. “Research on the
Impact of Government Fiscal Subsidies and Tax Incentive Mechanism
on the Output of Green Patents in Enterprises.” Finance Research
Letters 61: 104997.
Zolfagharinia, H., M. Zangiabadi, and M. Hafezi. 2023. “How Much
Is Enough ? Government Subsidies in Supporting Green Product
Development.” European Journal of Operational Research 309, no. 3:
1316–1333.




Sustainable Development, 2025                                                  21
