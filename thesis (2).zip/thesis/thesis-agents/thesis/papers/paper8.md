                                                                        Energy Strategy Reviews 51 (2024) 101281


                                                                        Contents lists available at ScienceDirect


                                                                      Energy Strategy Reviews
                                                                 journal homepage: www.elsevier.com/locate/esr




Moving toward environmental mitigation in Algeria: Asymmetric impact of
fossil fuel energy, renewable energy and technological innovation on
CO2 emissions
Brahim Bergougui a, b
a
    International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
b
    National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria




A R T I C L E I N F O                                          A B S T R A C T

Handling Editor: Dr. Mark Howells                              Algeria’s recent economic shifts have caused its macroeconomic data to exhibit an abnormal distribution,
                                                               requiring a nonlinear approach to examine the asymmetric impact of technological innovation (TI), fossil fuel
JEL classification:                                            energy (FFE), and renewable energy (RE) on CO2 emissions. This study employs the nonlinear autoregressive
C31                                                            distributed lag (NARDL) model to analyze the asymmetric impact of these factors on CO2 emissions. Further­
Q33
                                                               more, Quantile Autoregressive Distributed Lag (QARDL) and Quantile Granger Causality (QGC) approaches are
R11
                                                               employed for robustness checks. The NARDL results indicate that positive shocks in TI decrease CO2 emissions,
Keywords:
                                                               whereas negative shocks increase CO2 emissions. Positive shocks in RE also decrease CO2 emissions, while
CO2 emissions
                                                               negative shocks have no effect. In contrast, positive shocks in FFE increase CO2 emissions, but negative shocks
Technological innovation
Fossil fuel energy                                             have an even stronger effect, resulting in almost double CO2 emissions over time. These findings confirm the
Renewable energy                                               presence of asymmetry, as positive and negative shocks in regressors clearly influence CO2 emissions in Algeria.
NARDL                                                          Moreover, the results from the asymmetric causality analysis indicate that TI, RE, and FFE have a causal effect on
Algeria                                                        CO2 emissions in Algeria. These results are consistent with the findings from the QARDL and QGC approaches.
                                                               Therefore, it is crucial for Algeria to prioritize investment in sustainable technology and implement carbon-
                                                               neutral energy policies to reduce its reliance on fossil fuel and encourage the use of cleaner energy sources.
                                                               The shift towards a green energy sector requires policymakers to ensure that innovation aligns with development
                                                               objectives.




Credit author statement                                                                              meeting the energy needs of its growing population [16]. Indeed,
                                                                                                     Algeria has witnessed an unparalleled upsurge in CO2 emissions. In
    Brahim Bergougui: Conceptualization, Data curation, Investigation,                               particular, according to statistics from Ref. [17], Algeria’s CO2 emissions
Methodology, Software, Visualization, Writing - Original draft prepa­                                have more than doubled in the past 30 years, from about 65.35 million
ration, Writing - Reviewing and editing.                                                             tons in 1990 to 139.67 million tons in 2021. Recognizing the serious
                                                                                                     implications of CO2 emissions on biodiversity and human lives, such as
1. Introduction                                                                                      health problems, storms, droughts, floods, desertification, and land
                                                                                                     degradation [18].
    Over the last few decades, the planet has faced severe environmental                                To combat the deterioration in environmental quality, Algeria has
issues, particularly CO2 emissions, due to the actions of humans, such as                            engaged with various global frameworks. Algeria was one of the
burning fossil fuel for energy production and transportation, defores­                               developing countries that participated in the 2015 Paris Agreement,
tation, and industrial processes [1–8]. These emissions have been                                    pledging to reduce CO2 emissions by a minimum of 7 % by 2030 [19].
identified as the major contributors to greenhouse gas emissions, which                              Therefore, the Algerian government has implemented quite a few stra­
cause climate change and global warming [9–15]. As one of Africa’s                                   tegies to find concerted solutions to climate change and meet its emis­
largest three energy consumers and CO2 emitter, Algeria has been                                     sion reduction targets. One of these strategies that has gained
grappling with the challenge of reducing CO2 emissions while still                                   widespread acceptance is the promotion of TI to tackle environmental



      E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com.

https://doi.org/10.1016/j.esr.2023.101281
Received 27 August 2023; Received in revised form 9 November 2023; Accepted 26 November 2023
Available online 12 December 2023
2211-467X/© 2023 The Author. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui                                                                                                             Energy Strategy Reviews 51 (2024) 101281


issues [20]. In fact, Algeria has seen remarkable development in TI, as           more reliable results than conventional time series methods. Algerian
proved by the total of patents. According to the World Bank [21], the             policymakers can benefit from this approach when developing strategies
number of patents in Algeria has more than tripled, increasing from               to meet long-term energy demands while addressing CO2 emissions
around 235 in 1990 to 710 in 2015. This growth can be credited to the             across the country.
Algerian government’s emphasis on investing in information and com­                   The empirical findings show that positive shocks in TI significantly
munications technology, which likely played a role in fostering the rise          decreased CO2 emissions, whereas negative TI shocks increased emis­
in patent registrations. Measuring the success of TI activities in various        sions. Similarly, positive shocks in RE reduced CO2 emissions, but
industries often relies on the number of patent applications submitted.           negative RE shocks had no effect. In contrast, positive shocks in FFE
The increasing number of patents being filed for new technologies in the          triggered higher CO2 emissions. Even more strikingly, negative FFE
energy and environmental sectors suggests that these industries are               shocks nearly doubled the rise in CO2 emissions compared with positive
becoming more innovative, leading to the development of a more sus­               shocks. The Granger causality results also indicated that TI, RE, and FFE
tainable industrial structure [22]. Despite this, a comprehensive evalu­          cause CO2 emissions in Algeria. Although partially aligned with prior
ation of the literature at hand on the core factors that influence CO2            research, the results differed by indicating that positive and negative
emissions in Algeria indicates that almost no empirical study has                 shocks can impact CO2 emissions asymmetrically. Ignoring the
examined the effect of TI. Therefore, it is vital to assess the dynamic           nonlinear nature of these shocks could lead to misinterpretations. This
connection between TI and CO2 emissions in Algeria, and its curbing               knowledge can help Algeria develop an effective environmental policy
effects on other factors. Such a study would not only provide further             that considers these asymmetrical relationships.
insight into the relationship between TI and CO2 emissions, but also                  The remainder of the paper is structured in the following manner:
provide valuable references for the Algerian government in developing             Section 2 reviews the current literature on the relationship between FFE,
technological policies.                                                           RE, TI, and CO2 emissions. Section 3 explains the methodological
    The possible impact of TI, FFE, and RE on Algeria’s environment is            framework used to conduct the statistical analysis. Section 4 presents the
unclear. Although a few studies have examined the effects of FFE and RE           findings of the data analysis. Finally, Section 5 covers the conclusion,
on CO2 emissions, no study has yet explored the impact of TI in Algeria           limitations, and future research directions.
CO2 emissions. This is a significant gap in the literature because TI can
play a significant role in reducing CO2 emissions. Previous studies have          2. Literature review
used linear models on time series (VAR, ARDL, and VECM) and have
assumed that the impacts of positive and negative shocks are identical.               Previous research has indicated that achieving low CO2 emissions
However, the ecological benefits and costs of technology and energy               relies heavily on RE and TI, while FFE sources are the primary culprits
consumption can vary depending on the type of shock. Algeria’s econ­              for high CO2 emissions. Algeria, like other developing countries, often
omy has undergone significant changes in recent years, including abrupt           overuses energy resources to drive economic growth, resulting in sig­
shifts and industrial transformations. These changes have led to distinct         nificant environmental harm caused by excessive CO2 emissions.
phases and structural breaks in Algeria’s economy. To better understand           Consequently, Algeria’s economy faces the critical challenge of
the impact of TI, FFE, and RE on Algeria’s environment, it is important           balancing economic development with environmental preservation
to consider these breaks and policy shifts. Motivated by the analysis             [23]. Despite prior investigations into the effects of energy use and RE
mentioned above, this study seeks to bridge the existing research gap by          on CO2 emissions, the findings remain inconclusive. Therefore, addi­
addressing the following research queries, with TI, FFE, and RE serving           tional research is necessary to explore FFE, RE, and TI, to assist Algeria
as key independent variables in the empirical evaluation.                         in reaching their goal of lessening CO2 emissions. In this section, an
                                                                                  overview of the existing literature is provided, highlighting areas that
   (1) Does a positive (negative) shock in TI lead to a reduction (rise) in       require further investigation.
       CO2 emissions in Algeria?
   (2) Does a positive (negative) shock in FFE lead to a reduction (rise)         2.1. Technological innovation and CO2 emissions
       in CO2 emissions in Algeria?
   (3) Does a positive (negative) shock in RE lead to a reduction (rise) in           Technological innovation (TI) encompasses the creation of novel
       CO2 emissions in Algeria?                                                  technologies and the inventive application of occurring technologies.
                                                                                  This involves generating new concepts, developing and implementing
   To prevent bias from omitted variables, this study also includes GDP,          new patents, and modifying current production processes [24]. TI is
POP, FFE, and TR because of their significant impact on CO2 emissions.            perceived as a pivotal remedy for environmental challenges. It has the
The dynamic nonlinear autoregressive distributed lag (NARDL) model                potential to diminish carbon dioxide discharges through various stra­
was used to investigate these asymmetric relationships.                           tegies. These include sequestering and storage of carbon within the fossil
                                                                                  fuel infrastructure, carbon assimilation during the photosynthetic pro­
1.1. Study contribution                                                           cess in biomass systems, and employing energy storage devices in
                                                                                  electricity production. Furthermore, it can influence the effects of
   The current study makes numerous substantial contributions for                 diverse factors through assorted mechanisms [25]. For instance, it fa­
examining the relationship between energy consumption, TI, and CO2                cilitates the progress of renewable energy, improves energy efficiency,
emissions in the Algerian economy. (1) Unlike previous research that              promotes clean coal utilization, and advances the advancement of
primarily used linear models, this study employs the NARDL method­                electric cars [26]. The increasing advancement of TI has led to a growing
ology to investigate the possible asymmetric impacts of increases and             recognition among policymakers and researchers regarding its signifi­
decreases in TI, FFE, and RE on CO2 emissions. (2) It conducts the first          cance in reducing CO2 emissions [24,27,28]. A considerable number of
analysis of the role of TI on CO2 emissions in Algeria and reveals how TI         researchers have initiated investigations into the influence of TI on CO2
can affect CO2 emissions in diverse ways, suggesting implications for             emissions. In these studies, various commonly indicators are used to
policy design and implementation. (3) It considers the effects of both            measure the levels of TI, including research and development (R&D)
FFE and RE, rather than focusing on only one type of energy con­                  efforts, efficiency, and patent development [29]. Although the afore­
sumption, as prior work has done. This comprehensive approach pro­                mentioned studies unanimously acknowledge the positive role of TI in
vides additional evidence regarding which energy sources specifically             reducing CO2 emissions or enhancing environmental quality, there is
contribute to CO2 emissions. (4) It estimates the long-run asymmetric             contrasting research suggesting that it can lead to higher emissions [30].
cointegration among FFE, RE, TI, and CO2 emissions, which provides                conducted a study on Japan, which demonstrated that TI could stimulate

                                                                              2
B. Bergougui                                                                                                            Energy Strategy Reviews 51 (2024) 101281


CO2 emissions and result in a decline in environmental quality. Similarly        research in this area.
[31], discovered that negative shock to TI can increase CO2 emissions.
                                                                                 H2. A positive (negative) shock in renewable energy use decrease
Therefore, due to the lack of consensus among previous studies, further
                                                                                 (increase) CO2 emissions in Algeria.
research is necessary to better understand the impact of TI on CO2
emissions. Drawing from the literature reviewed above, the following
                                                                                 2.2.2. Fossil fuel energy consumption and CO2 emissions
hypothesis is proposed.
                                                                                     Fossil fuel combustion is a significant contributor to CO2 emissions.
H1. A positive (negative) shock in technological innovation decrease             This is supported by the findings of several studies, including [49],
(increase) CO2 emissions in Algeria.                                             which found that higher FFE in Malaysia is associated with increased
                                                                                 environmental emissions. Similarly [50], found that FFE is a noteworthy
                                                                                 contributor in the generation of CO2 emissions in the European Union
2.2. Energy consumption and CO2 emissions
                                                                                 [51]. found similar results in their study of 27 developed countries [52].
                                                                                 found a positive relationship between conventional energy consumption
2.2.1. Renewable energy consumption and CO2 emissions
                                                                                 and CO2 emissions in SAARC nations. In a recent study conducted by
    The transition to RE has been the subject of research since the 1970s
                                                                                 Ref. [53], it was discovered that negative shocks in FFE lead to an in­
oil crisis, as it has the potential to reduce CO2 emissions [32]. Envi­
                                                                                 crease in environmental pollution levels. Likewise, positive shocks in
ronmental sustainability necessitates a transition from conventional to
                                                                                 FFE also contribute to an increase in the ecological footprint eventually.
cleaner energy sources, as this can improve environmental quality
                                                                                 Additionally, multiple studies have found that increasing FFE is associ­
without compromising economic growth. Energy transition can promote
                                                                                 ated with higher CO2 emissions [54–56].
economic growth by making energy affordable, accessible, and efficient
                                                                                     Turning to studies that consider the Algerian case [57], investigated
for people at all income levels. It can also enhance environmental
                                                                                 the validity of the EKC hypothesis in Algeria. The outcomes of ARDL
quality by reducing CO2 emissions [33]. According to the United Nations
                                                                                 show that energy use and electricity consumption is noteworthy to in­
Environment Program’s emission gap report, decarbonization in the
                                                                                 fluence CO2 emission in the long run [16]. reached a similar conclusion
energy sector is the most pressing issue for achieving carbon neutrality
                                                                                 in their study. [48], also used the ARDL method to study the relationship
[34]. This is because the excessive use of fossil fuel energy has a sig­
                                                                                 between CO2 emissions, income, FFE, and RE in Algeria and found that
nificant social and environmental cost. Multiple studies have examined
                                                                                 FFE is a major contributor to CO2 emissions [18,58]. shared a similar
the relationship between RE and CO2 emissions, with findings suggest­
                                                                                 perspective regarding the negative impact of energy use on Algeria’s
ing a negative impact [35–40]. For example [41], investigated the
                                                                                 environmental quality, highlighting that energy use is the second most
causal relationship between CO2 emissions and nuclear energy con­
                                                                                 significant factor contributing to CO2 emissions.
sumption in 19 developing and developed countries. Their findings
showed that nuclear energy has a negative impact on CO2 emissions in             H3. A positive (negative) shock in fossil fuel energy increases CO2
the long run, but not in the short run. The effect of RE on CO2 emission         emissions in Algeria.
was examined by Ref. [42] in the context of South Africa. The study
found a 1 % increase in RE sources resulted in a smaller 2855 kt increase        2.3. Theoretical foundations: nexus between CO2 emissions and TI, FFE,
in CO2 emissions. According to Ref. [43], which analyzed 107 countries,          and RE factors
the effect of RE on CO2 emissions can be positive or negative, depending
on the income level of the country. Only higher-income countries were                The concept of net-zero CO2 emissions originated on a small Danish
found to experience a reduction in their emission levels with increases in       Island in 1997 [32] and has since gained global recognition. Numerous
RE for productive purposes. In a study conducted by Ref. [44], the               countries and organizations have now set their sights on achieving a
impact of renewable and FFE on ecological footprints in Turkey was               balance between CO2 emissions and removal from the environment
re-examined. The findings indicated that RE plays a significant role in          [59]. This pursuit of balance, also known as carbon neutrality, aims to
reducing the ecological footprint in the long run, as observed across all        achieve synergy between economic productivity and environmental
quantiles considered in the study. In another study conducted by                 preservation [60]. In recent decades, developing countries have un­
Ref. [45] who examined the dynamic relationship between RE and the               dergone significant economic expansion, frequently at the cost of the
environment in Turkey, found that an increase in the use of RE improves          environment, as they have relied heavily on fossil fuel [61]. Previous
environmental quality. A study published in Ref. [32], examined the              research indicates that economies tend to exhibit higher pollution levels
importance TI and RE in attaining carbon neutrality. The findings of the         during industrialization but may subsequently reduce emissions as they
study confirm that RE plays a crucial role in significantly reducing CO2         attain higher income levels [62]. Presently, numerous strategies are
emissions both in the short and long term. Additionally, the study re­           being implemented to foster economic growth without concomitant
veals that RE reduces CO2 emissions consistently, while TI exhibits a            increases in CO2 emissions. For instance, the aviation industry made a
U-shaped effect on CO2 emissions.                                                public commitment in 2013 to fully offset its carbon footprint by 2020.
    In Algeria, there are only a limited studies that have explored the          Around the same time, the 2015 Paris Climate Agreement set a global
effect of RE on CO2 emissions. The results of these studies have been            objective of limiting future temperature rise to 1.5◦ Celsius [63].
mixed, indicating the need for further research and analysis. Some               Advanced technologies such as renewable power generation and
studies may suggest that the adoption and utilization of RE sources in           enhanced equipment efficiency play a pivotal role in mitigating emis­
Algeria have led to a reduction in CO2 emissions. For instance, Bélaïd          sions. Nevertheless, studies examining the decarbonization potential of
and Youssef (2017) found that RE utilization has positive environmental          technological innovation and renewable energy yield mixed findings
effects and improves overall environmental quality. Similarly, Sahnoune          despite the theoretical arguments supporting both approaches. The
and Imessad [46] showed that the development of RE sources and the               concept of technological innovation was first introduced by Braun and
implementation of energy efficiency measures can significantly reduce            Wield [64], which pertains to techniques, activities, and products that
CO2 emissions and conserve fossil resources. Furthermore, Sari Hassoun           enhance the environment. Shortly after, the notion of Environmental
et al. [47] concluded that the use of RE sources can effectively reduce          Sound Technologies (ESTs) emerged [65], which was perceived to play a
CO2 emissions [18].found that energy usage was the second most sig­              crucial role in achieving carbon neutrality while promoting economic
nificant contributor to CO2 emissions [19]. found that RE has a negative         growth, thus providing a win-win solution for environmental protection
effect on CO2 emissions, as well as reducing CO2 emissions in the short          and economic growth [66]. As Porter’s theory contends, there exists a
term. However, Amri [48] found that RE had an insignificant impact on            theoretical association between technological innovation and CO2
CO2 emissions. These conflicting results highlight the need for further          emissions [67]. This theory posits that well-designed environmental

                                                                             3
B. Bergougui                                                                                                                         Energy Strategy Reviews 51 (2024) 101281


standards can stimulate innovation activities within firms that can                      Table 1
reduce CO2 emissions while enhancing production efficiency and                           Variable Details and data sources.
competitiveness. Moreover, green technology can also minimize the cost                    Variables         Symbols      Descriptions                 Units        Sources
of complying with environmental standards and provide an advanta­
                                                                                          carbon dioxide    CO2          This refers to the           Thousand     EIA
geous position for firms to scale up their production [68]. Energy con­                     emissions       emissions    release of carbon            metric ton   (2023)
sumption is a double-edged sword for environmental sustainability, with                                                  dioxide into the
both positive and negative consequences. On the one hand, it can be a                                                    atmosphere, primarily
driving force for sustainable economic growth and contribute to                                                          from the burning of
                                                                                                                         fossil fuels such as coal,
improved environmental quality. On the other hand, it may also result in                                                 oil, and gas.
heightened emissions of greenhouse gases, causing a significant threat to                 Fossil fuel       FFE          This refers to the use of    Kg of oil    EIA
ecological sustainability [53]. Therefore, it is imperative to compre­                      energy                       non-renewable energy         equivalent   (2023)
hensively evaluate the potential benefits and risks of energy deployment                                                 sources such as coal,
                                                                                                                         oil, and gas to generate
to ensure its sustainable use.
                                                                                                                         electricity, power
                                                                                                                         transportation, and
                                                                                                                         fuel industrial
2.4. Evaluation of the literature
                                                                                                                         processes.
                                                                                          Renewable         RE           This refers to the use of    Kg of oil    EIA
    The extant literature extensively scrutinizes the impact of TI, FFE,                    energy                       clean, renewable             equivalent   (2023)
and RE on CO2 emission. However, existing studies possess certain                                                        energy sources such as
limitations and gaps this research aims to address. First, previous work                                                 solar, wind, hydro, and
                                                                                                                         geothermal power to
predominantly focuses on specific countries, such as China and Turkey,
                                                                                                                         generate electricity
while neglecting others, particularly developing countries. Second, the                                                  and fuel
role of TI in influencing CO2 emissions in Algeria, the focal country of                                                 transportation.
this investigation, has not been considered. Third, prior studies have                    Technological     TI           Total patent                 People       WDI
                                                                                            Innovation                   applications (residents                   (2023)
relied on linear econometric models, as demonstrated by Bouznit and
                                                                                                                         and non-residents)
Pablo-Romero [57] and Elbadri et al. [19]. However, these models may                      Real per capita   GDP          Gross domestic product       Constant     WDI
not capture the nonlinear and asymmetric dynamics inherent in the                           GDP                          divided by midyear           2015 US$     (2023)
relationships between variables. Fourth, existing literature primarily                                                   population
employs aggregate energy consumption measures, such as total con­                         Trade openness    TR           Exports and imports of       Percent      WDI
                                                                                                                         goods and services (as                    (2023)
sumption or singular sources (FFE or RE) without distinguishing be­
                                                                                                                         a share of GDP).
tween energy types and their divergent environmental impacts. For                         Foreign direct    FDI          Investment net inflows       Percent      WDI
instance, Elbadri et al. [19] solely examined RE while Bouznit and                          investment                   divided by GDP                            (2023)
Pablo-Romero [57] and Chekouri et al. [18,58] used total consumption.                     Population        POP          The increase in the          Percent      WDI
                                                                                            growth                       number of individuals                     (2023)
    This paper contributes to academic knowledge by exploring the
                                                                                                                         living in a particular
asymmetric relationship between TI, FFE, and RE on CO2 emissions in                                                      area over a specific
Algeria using NARDL and asymmetric causality methods. These tech­                                                        period
niques allow us to examine how CO2 emissions respond differently to
                                                                                         Notes: USD denotes the United States Dollar, WDI symbolizes the World
positive and negative changes in TI, FFE, and RE. It also provides a more
                                                                                         Development Indicators, and EIA represents the U.S. Energy Information
nuanced analysis of energy use by distinguishing between FFE and RE to                   Administration publication.
identify the primary source responsible for CO2 emissions and provide                    Source: Author’s own construction based on WDI and EIA datasets.
suitable policy responses. As one of Africa’s major energy consumers
and carbon emitters, Algeria presents a notable case that remains                        ensures uniformity in measurement units and assists in normalizing
underexplored in these areas. Clarifying these linkages aims to offer                    outliers. This approach, as highlighted by Ref. [27] helps overcome
valuable insights into Algeria’s energy policy and sustainability efforts.               distributional properties and provides elasticities as the output.
                                                                                             Fig. 1 depicts the contrasting trends of CO2 emissions and techno­
3. Data and research methodology                                                         logical innovation in Algeria from 1990 to 2021. CO2 emissions have
                                                                                         soared from about 65.35 million tons in 1990 to 139.67 million tons in
3.1. Data                                                                                2021, indicating the deterioration of the composition of energy sources,
                                                                                         which is marked by the dominance of fossil fuel energy and the shortage
   The study aims to examine the impacts of TI, FFE, and RE on CO2                       of renewable energy. Conversely, TI has also increased significantly, as
emissions by controlling GDP, POP, FDI, and TR in Algeria. The dataset                   demonstrated by the number of patents, which surged from around 235
used in the study is provided by a variety of sources: The data for CO2                  in 1990 to 710 in 2015. This can be explained by the Algerian govern­
emissions, FFE, and RE are collected from U.S. Energy Information                        ment’s investment in information and communications technology,
Administration publication [17]. The data for TI, economic growth,                       which has encouraged patent activity.
trade, investment, and population are obtained from World Bank [21].
The dynamic model relies on quarterly data1 from 1980/Q1 to 2021/Q4
                                                                                         3.2. Methodology
(see Table 1). A logarithmic transformation was applied to all variables
prior to the empirical specification. This logarithmic transformation
                                                                                            This study’s methodology involves a series of steps (see Fig. 2)
                                                                                         designed to capture the asymmetric and long-run impact of TI, FFE, and
  1
                                                                                         REC on CO2 emissions in Algeria.
    To address the challenge of a shorter time span, the quadratic match-sum
approach was employed, following the methodology outlined by Refs. [9,28,
96,97]. This approach is advantageous as it adjusts for cyclical variations in the       3.3. Model specification
data and mitigates seasonality issues. By reducing point-to-point data varia­
tions, as explained by Shahbaz et al. [98], the quadratic match-sum approach                To assess nonlinear and asymmetric effects, the study utilized the
yields more reliable results and isolates the non-seasonal component of the              NARDL specification developed by Shin et al. [69] to analyze relation­
data.                                                                                    ships among key variables. This model is well-suited for situations where

                                                                                     4
B. Bergougui                                                                                                                     Energy Strategy Reviews 51 (2024) 101281




                          Fig. 1. CO2 emissions, technological innovation, fossil fuel energy, and renewable energy, trends in Algeria.


unexpected and undisclosed events occur, such as political changes,                 hidden cointegration, which identifies potential unseen cointegrating
financial crises in 2008, the COVID-19 pandemic, and other calamities.              relationships among integrated components of data series, as depicted in
These events can make linear approaches inadequate, as they are not                 the equation below:
designed to control such instability. The NARDL model allows us to
                                                                                    CO2t = f (TI + , TI − , FFE+ , FFE− , RE+ , RE− )                                (2)
account for short-term and long-term co-integration among dependent
and independent variables. This model also allows for accepting inte­                  Based on the approach developed Sun et al. [9], this study employs
gration orders of I(0), I(1), or mutually co-integrated, unlike other               their empirical specification to capture potential asymmetries involving
models that consider the integrated order of time series to be the same.            the selected variables:
    This paper examines the long-term asymmetric connections between
                                                                                    CO2t = β0 + β1 TI +         −          +         −        +         −
                                                                                                      t + β2 TI t + β3 FFE t + β4 FFEt + β5 REt + β6 RE t            (3)
TI, FFE, RE, and CO2 emissions while controlling for the impact of GDP
and population in Algeria. To simplify the model, only the core variables              Where the parameter βi is associated with the coefficient of long-run
are included in the following function.                                             and the asymmetric effect of TI, FFE, and RE. Positive changes in these
CO2t = α0 + α1 (TI)t + α2 (FFE)t + α3 (RE)t + μt                          (1)       variables are denoted as (TI+ , FFE+ , RE+ ), while negative changes are
                                                                                    represented as (TI− , FFE− , RE− ) respectively. The positive and negative
where CO2t, TIt, FFEt, and RECt represent the CO2 emissions, techno­                coefficients are calculated as the sum of the squared positive and
logical innovation, fossil fuel energy consumption, and renewable en­               negative changes in TI, FFE, and RE. In addition, per capita income,
ergy consumption, respectively in Algeria. The study applies the NARDL              population growth, investment, and trade are included as control vari­
model offered by Shin et al. [69] to determine the asymmetric rela­                 ables in the following manner:
tionship between all variables. This is done by considering the changes             CO2t = β0 + β1 TI +         −          +         −        +         −
                                                                                                      t + β2 TI t + β3 FFE t + β4 FFEt + β5 REt + β6 RE t
in both the dependent and independent variables.
                                                                                      + β8 GDPt + β8 POPt + β8 TRt + β8 FDIt + μt + εt                               (4)
    The motivation behind the NARDL model stems from the certainty
that variables are not necessarily required to possess hidden cointegra­
tion, and the impact of explanatory variables varies depending on pos­              4. Empirical results and discussion
itive and negative changes in both the long and short term. The NARDL
procedure offers a flexible approach to address these concerns, and it              4.1. Preliminary statistics
can be employed regardless of the order of integration of the time series.
Hatemi-J [70] and Granger and Yoon [71] introduced the concept of                       Table 2 presents a comprehensive description of the dataset’s


                                                                                5
B. Bergougui                                                                                 Energy Strategy Reviews 51 (2024) 101281




Fig. 2. Analysis flowcharts.
Source: Author’s own construction.


Table 2
Summary statistics.
                                 CO2     TI        FFE          RE         GDP      POP                 FDI                TR

  Mean                           4.556   1.489     22.938       14.835     2.039    0.418               0.163              2.634
  Median                         4.523   1.466     22.823       17.167     2.037    0.394               0.174              2.637
  Maximum                        4.721   1.704     23.540       18.687     2.089    0.629               0.559              2.958
  Minimum                        4.365   1.217     22.112       − 16.507   1.985    0.280               − 0.105            2.088
  Std. Dev.                      0.085   0.155     0.332        8.533      0.031    0.103               0.159              0.191
  Skewness                       0.357   − 0.064   0.125        − 3.274    0.029    0.706               0.483              − 0.734
  Kurtosis                       2.387   1.605     2.586        11.867     1.718    2.324               2.331              3.438
  Jarque-Bera                    6.193   13.728    1.638        850.537    11.521   17.136              9.660              16.413
  Jarque-Bera Probability        0.045   0.001     0.441        0.000      0.003    0.000               0.008              0.000
  Observations                   168     168       168          168        168      168                 168                168

Source: Author’s own estimates




                                                            6
B. Bergougui                                                                                                                          Energy Strategy Reviews 51 (2024) 101281


features. The mean values of CO2, TI, FFE, RE, GDP, POP, TR, and FDI                      This confirms the presence of co-integration among the variables in the
exceed their corresponding standard deviations, indicating an uneven                      model.
distribution in Algeria. Skewness statistics indicate that CO2, FFE, GDP,
POP, and FDI display a right-skewed distribution, while TI, RE, and TR                    4.5. Asymmetric NARDL empirical analysis
exhibit a right-skewed distribution. The Jarque-Bera (JB) [72] test sta­
tistics reject normality. This suggests that the sample data is not nor­                  4.5.1. Long-run asymmetric relationship
mally distributed.                                                                            Table 6 presents the outcomes of the NARDL model, which was
                                                                                          employed to determine the long-term coefficients for both positive and
4.2. Nonlinearity test                                                                    negative shocks. The findings reveal that a positive shock in TI reduces
                                                                                          emissions by 0.43 % in the long run, while a negative shock in TI leads to
   To check for any nonlinear patterns in the variables, the data was                     an increase in CO2 emissions by 0. 28 %. This suggests that TI has an
analyzed using the Brock, Dechert, and Scheinkman (BDS) [73] and                          asymmetric relationship with CO2 emissions, meaning that the impact of
Harvey et al. [74] nonlinearity tests. As shown in Table 3, the results of                a change in TI on CO2 emissions varies depending on the direction of the
both the BDS and Harvey et al. [74] tests indicate the presence of                        change.
nonlinearity among the variables.                                                             According to Table 6, a 1 % positive shock in FFE in Algeria leads to a
                                                                                          0.1 % increase in CO2 emissions. Conversely, a 1 % negative shock in
4.3. Unit root test                                                                       FFE results in a 0.18 % rise in CO2 emissions, indicating that a negative
                                                                                          shock has almost twice the impact of a positive shock. Therefore, both
    To assess the stationarity properties of the data, a battery of uni­                  positive and negative shocks in FFE appear to contribute to higher long-
variate unit root tests was employed, including the Augmented Dickey                      term CO2 emissions. According to the findings, the use of FFE contrib­
and Fuller (ADF) test, the Phillips and Perron (PP) test, and the Kwiat­                  utes to CO2 emissions. This is consistent with the research of several
kowski–Phillips–Schmidt–Shin (KPSS) test. The results are displayed in                    other studies, including those by Amri [48], Bélaïd and Youssef [16],
Table 4. Upon examining the outcomes of the ADF, PP, and KPSS tests                       and Chekouri et al. [18,58], which have all confirmed that the use of FFE
(panel a, Table 4), one can confirm that all variables are stationary at the              curses environmental quality in Algeria.
I(1) level.                                                                                   Regarding renewable energy, the findings indicate that a 1 % posi­
    Additionally, the Lagrange Multiplier structural break unit root test                 tive shock to RE mitigates CO2 emissions by 0.063 %, whereas negative
proposed by Lee and Strazicich (LS) [75] was employed further to check                    shocks to RE have an insignificant impact on CO2 emissions. These re­
the stationarity of the variables in the sample. The LS test has the                      sults indicate a negative link between RE and CO2 emissions, high­
advantage of detecting one or more structural breaks along with the unit                  lighting the vital role of RE in mitigating CO2 emissions. This implies
root decision. The results of the LS unit root test are displayed in panel                that policymakers should prioritize positive shocks in RE and their po­
(b) of Table 4. The LS unit root test indicated that all variables are sta­               tential benefits. On the other hand, they do not need to worry too much
tionary at the I(1) level.                                                                about negative shocks in RE, as they do not have a noticeable effect on
                                                                                          emissions. Moreover, it is important to note that positive shocks in RE
4.4. NARDL bounds test of cointegration                                                   have a superior effect on CO2 emissions, making them particularly
                                                                                          valuable for policy objectives aimed at creating a sustainable environ­
    To evaluate the existence of a long-run association among the vari­                   ment. For instance, if the Algerian government implements an annual
ables in the model, two methods were employed: the t-test, as described                   increase in RE as a policy measure, it will result in lower CO2 emissions.
by Banerjee et al. [76] and the F-test, as outlined by Pesaran et al. [77].               Decreasing RE and reversing this policy would have a minor impact on
The results of the co-integration analysis are presented in Table 5. The                  CO2 emissions. These studies typically assume a symmetric relationship
F-statistic and t-statistic, with values of 4.0027 and − 4.9170, respec­                  between RE and CO2 emissions, meaning that both increases and de­
tively, both exhibit significant statistical significance at the 1 % level.               creases in RE have the same impact on CO2 emissions. However, this

Table 3
Nonlinearity test results.
  Variables                     Dimensions                                                                                                                        Decisions

                                m=2                           m=3                 m=4                       m=5                        m=6

  CO2                           0.189***                      0.315***            0.400***                  0.458***                   0.499***                   Nonlinear
  TI                            0.190***                      0.317***            0.402***                  0.458***                   0.492***                   Nonlinear
  FFE                           0.192***                      0.323***            0.414***                  0.479***                   0.525***                   Nonlinear
  RE                            0.104***                      0.194***            0.271***                  0.336***                   0.391***                   Nonlinear
  GDP                           0.200***                      0.338***            0.431***                  0.491***                   0.530***                   Nonlinear
  POP                           0.202***                      0.345***            0.445***                  0.514***                   0.561***                   Nonlinear
  FDI                           0.169***                      0.279***            0.346***                  0.384***                   0.402***                   Nonlinear
  TRADE                         0.180***                      0.300***            0.376***                  0.421***                   0.445***                   Nonlinear

  Panel (b). Nonlinearity Harvey et al. (2008) test results
  Variables                    Statistics                                         Prob. value                                          Decisions

  CO2                           10.243                                            0.01531**                                            Nonlinear
  TI                            9.255                                             0.02654**                                            Nonlinear
  FFE                           13.475                                            0.00861***                                           Nonlinear
  RE                            14.546                                            0.00698***                                           Nonlinear
  GDP                           22.954                                            0.0000***                                            Nonlinear
  POP                           12.875                                            0.01123**                                            Nonlinear
  FDI                           15.254                                            0.00387***                                           Nonlinear
  TR                            11.985                                            0.02456**                                            Nonlinear

Notes: ***, **, and * denote statistical significance at the 1 %, 5 %, and 10 % levels, respectively, based on the rejection of the null hypothesis of linearity. The relevant
critical values for the Harvey et al. (2008) test are 7.78, 9.49, and 13.28 at the 1 %, 5 %, and 10 % levels, respectively.
Source: Author’s own estimates

                                                                                      7
B. Bergougui                                                                                                                                                    Energy Strategy Reviews 51 (2024) 101281


Table 4
Unit root tests results.
  Panel (a). Unit root tests without structural breaks

  Variables               ADF test                                             PP test                                                    KPSS test                                                Decision

                          At Level              At First Difference            At Level                 At First Difference               At Level                 At First Difference

  CO2                     − 2.4399              − 6.1855***                    − 2.7875*                − 5.7404***                       0.7685***                0.1292                          I(1)
  TI                      − 0.8852              − 3.6211***                    − 0.8799                 − 5.9254***                       1.0555***                0.1564                          I(1)
  FFE                     − 2.3043              − 3.6089***                    − 2.4499                 − 9.841***                        0.6876**                 0.127                           I(1)
  RE                      − 2.3315              − 3.6324***                    − 2.423                  − 9.6635***                       0.6596**                 0.1319                          I(1)
  GDP                     − 2.2707              − 7.1253***                    − 1.0509                 − 4.1786***                       1.0407***                0.2174                          I(1)
  POP                     − 3.6988***           − 9.9748***                    − 2.9582**               − 17.387***                       1.6001***                0.334                           I(1)
  FDI                     − 1.5636              − 4.2078***                    − 2.5163                 − 7.4403***                       0.8739***                0.1117                          I(1)
  TR                      − 1.4569              − 3.3947**                     − 1.4263                 − 5.5881***                       0.4132*                  0.1782                          I(1)

  Panel (b). unit root test with structural breaks

               At Level                                                                                        At First Difference

               Lee-Strazicich (LS)                                Test critical values                         Lee-Strazicich (LS)                                      Test critical values

               T-Stat         Break Points                        1%            5%             10 %            T-Stat          Break Points                             1%              5%              10 %

  CO2          − 3.72         (1984:Q1)         (2009:Q1)         − 6.28        − 5.72         − 5.41          − 7.98          (1984:Q2)             (2008:Q3)          − 6.28          − 5.72          − 5.41
  TI           − 2.21         (1992:Q3)         (2006:Q4)         − 6.41        − 5.81         − 5.54          − 7.26          (2001:Q2)             (2007:Q3)          − 6.23          − 5.71          − 5.38
  FFE          − 2.81         (1984:Q1)         (2004:Q4)         − 6.48        − 5.78         − 5.48          − 6.26          (1984:Q2)             (1991:Q2)          − 6.14          − 5.59          − 5.30
  RE           − 6.47         (1991:Q1)         (1995:Q1)         − 6.39        − 5.70         − 5.39          − 12.80         (1994:Q1)             (1998:Q2)          − 6.39          − 5.70          − 5.38
  GDP          − 1.34         (1994:Q1)         (2014:Q3)         − 6.28        − 5.72         − 5.41          − 6.34          (1994:Q1)             (2017:Q1)          − 6.28          − 5.72          − 5.41
  POP          − 1.85         (1986:Q3)         (2005:Q2)         − 6.48        − 5.78         − 5.48          − 16.23         (1985:Q4)             (2006:Q2)          − 6.48          − 5.78          − 5.47
  FDI          − 3.16         (1996:Q2)         (2011:Q4)         − 6.48        − 5.78         − 5.48          − 7.92          (2002:Q1)             (2009:Q2)          − 6.23          − 5.71          − 5.38
  TR           − 2.48         (1986:Q1)         (2008:Q3)         − 6.28        − 5.72         − 5.41          − 6.16          (1987:Q3)             (2017:Q3)          − 6.24          − 5.56          − 5.21

Notes: ***, **, and * denote statistical significance at the 1 %, 5 %, and 10 % levels, respectively.
Source: Author’s own estimates


Table 5                                                                                                  Table 6
Asymmetric co-integration and Wald test.                                                                 Estimations of long-run asymmetric relationship.
  Panel (a). Bounds test results for asymmetric cointegration test                                         Dependent variable = CO2

  F-Bounds test                                 T-Bounds test                                              Variables        Coefficient               Std. Error                 t-Statistic     Prob.

  Significance      Lower            Upper      Significance      Lower           Upper                    CO2t-1           − 0.43451***              0.0773                     − 5.62          0.000
  level             bound I          Bound      level             bound I(0)      Bound I(1)               TI positive      − 0.34399 ***             0.09614                    − 3.58          0.001
                                                                                                              t-1
                    (0)              I(1)                                                                                   0.28250 ***               0.09822                    2.88            0.005
                                                                                                           TIt-negative
                                                                                                                1
  10 %              1.83             2.94       10 %              − 2.57          − 3.86                   FFE positive     0.09727 ***               0.03433                    2.83            0.006
                                                                                                               t-1
  5%                2.06             3.24       5%                − 2.86          − 4.19                         negative
                                                                                                           FFE t-1          0.17942 *                 0.09938                    1.81            0.075
  1%                1.83             2.94       1%                − 2.57          − 3.86                                    − 0.063 *                 0.033                      − 1.92          0.059
                                                                                                           RE positive
                                                                                                              t-1
  F-statistic (FPSS) = 4.0027 ***             t-test (tBDM) = − -4.9170 ***                                    negative
                                                                                                           RE t-1           − 0.008                   0.045                      − 0.18          0.86
  Panel (b). Wald test for long-run and short-run asymmetry                                                GDP              8.7832                    7.7973                     1.1264          0.2622
  Variables          Long-run asymmetry                          Short-run asymmetry                       POP              0.0118                    0.0436                     0.2708          0.7870
                     F-           Probability                    F-statistic   Probability                 FDI              − 0.0039                  0.0125                     − 0.3105        0.7567
                     statistic                                                                             TR               − 0.0026                  0.0103                     − 0.2487        0.8040
  TI                19.01            0.000***                     0.073293        0.7870                   Model diagnostic test
  FFE               4.773            0.032**                      0.009362        0.9230                   Test description                           Test Statistics            Decision
  RE                5.974            0.016**                      0.086815        0.7687
                                                                                                           R2                                         0.7699                     Model denotes a solid fit
Notes: ***, **, and * denote statistical significance at the 1 %, 5 %, and 10 %                            Wald test                                  53.46 *** (0.000)          The existence of Long-
levels, respectively. tBDM represents the t-test introduced by Banerjee et al.                                                                                                   term asymmetry
(1998), while FPSS stands for the F-test proposed by Pesaran et al. (2001).                                Jarque–Bera                                0.016999 (0.9915)          Normality of the
Source: Author’s own estimates                                                                                                                                                   residuals
                                                                                                           Breusch-Godfrey Serial Correlation         3.955 (0.138)              Absence of
                                                                                                             LM Test (χ 2)                                                       autocorrelation.
research challenges this assumption and reveals an asymmetric rela­                                        Breusch/Pagan heteroskedasticity           0.638 (0.974)              Absence of
tionship that depends on the direction of change in RE. This finding                                         test (χ 2)                                                          Heteroscedasticity.
underscores the need to prioritize positive shocks to RE to achieve sig­                                   Ramsey RESET test (F)                      2.533 (0.115)              The specification is
                                                                                                                                                                                 consistent.
nificant reductions in emissions in Algeria.
                                                                                                           CUSUM                                                                 Stability Verified (see
    The NARDL model diagnostic tests presented in Table 6 reveal that                                                                                                            Fig. 2)
the model is stable and correctly specified. The Wald test found signif­                                   CUSUM sq                                                              Stability Verified (see
icant asymmetry in the model at a 1 % significance level, suggesting that                                                                                                        Fig. 3)
the positive and negative shocks of the regressors have different impacts                                Notes: *, **, and *** denote statistically significant at the 10 %, 5 %, and 1 %
on CO2 emissions. The Breusch-Godfrey LM test showed no serial cor­                                      levels, respectively.
relation, and the Breusch/Pagan test indicated no heteroscedasticity                                     Source: Author’s own estimates.
among variables. The Ramsey test confirmed that the model is correctly
specified. The CUSUM and CUSUMSQ tests are stability tests that assess
the stability of the model parameters over time. The CUSUM test plots
the cumulative sum of recursive residuals, and the CUSUMSQ test plots


                                                                                                   8
B. Bergougui                                                                                                                     Energy Strategy Reviews 51 (2024) 101281


                                                                                         test statistic of 11.325 being significant at the 1 % level. This suggests
                                                                                         negative changes in TI asymmetrically cause changes in CO2 levels.
                                                                                         Therefore, it can be concluded that TI plays a significant role in pre­
                                                                                         dicting CO2 emissions in Algeria. This conclusion is supported by the fact
                                                                                         that the adoption of TI can lead to the development of more efficient
                                                                                         energy technologies. This transition results in saving tons of
                                                                                         kilowatt-hours of electricity consumption and millions of tons of CO2
                                                                                         emissions [80]. The second finding indicates that FFE and CO2 emissions
                                                                                         have a one-way association. Moreover, the asymmetric causalities be­
                                                                                         tween FFE and CO2 emissions are not significant. When FFE is burned, it
                                                                                         unleashes significant amounts of CO2 and other harmful substances into
                                                                                         the air. These substances give rise to various environmental issues such
               Fig. 3. Cumulative sum of recursive residuals (CUSUM).                    as air pollution, acid rain, and climate change. The Algerian government
                                                                                         must implement measures that decrease the reliance on FFE and
                                                                                         encourage the growth of RE sources. These measures could include
                                                                                         providing financial incentives for RE initiatives, investing in the devel­
                                                                                         opment of innovative RE technologies, and improving energy efficiency.
                                                                                         This result supports the study by Magazzino et al. [81] on Russia. The
                                                                                         third result showed that RE and CO2 emissions have a one-way causal
                                                                                         relationship. In addition, the positive shocks from RE to CO2 emissions
                                                                                         have a one-way asymmetric causality. The key tenet of this investigation
                                                                                         is that RE contributes positively to the environment. Therefore, the
                                                                                         implementation of policies in Algeria to increase the demand for energy,
                                                                                         specifically from RE sources, will result in a decrease in CO2 emissions.

                                                                                         4.7. Robustness by QARDL and QGC approaches
     Fig. 4. Cumulative sum of squared recursive residuals (CUSUMSQ).
                                                                                             The study employed the quantile autoregressive distributed lag
the cumulative sum of squared recursive residuals. If the plots are within               (QARDL) and quantile granger causality (QGC) approaches to test the
the 5 % critical bands, the model is considered stable. In Figs. 3 and 4,                robustness of previous findings [82]. Table 8 shows the error correction
the CUSUM and CUSUMSQ plots are both within the critical bands,                          parameters, long-run and short-run coefficients across 11 quantiles
confirming the stability of the NARDL model.                                             (0.05–0.95), representing different pollution levels in Algeria.
                                                                                             The QARDL findings indicate that the long-run coefficient of TI ex­
                                                                                         hibits a negative relationship with CO2 emission at higher quantiles
4.6. Symmetric and asymmetric causality
                                                                                         (0.30–0.95) with a significance level of 1 %. However, the relationship is
                                                                                         insignificant at lower quantiles (0.05–0.2). Similarly, RE shows a
   Researchers have used the symmetric and asymmetric causality test
                                                                                         negative and significant association with CO2 emission at higher quan­
proposed by Hatemi-j [78] in environmental studies [13,79]. Table 7
                                                                                         tiles (0.50–0.95), though significance levels vary. At lower quantiles
presents the results of the bootstrap causality test, which evaluates for
                                                                                         (0.05–0.5), the relationship is not significant. Alternatively, the long-run
both symmetric and asymmetric causal relationships between the vari­
                                                                                         coefficient of FFE is positively and significantly associated with CO2
ables. The causal relationship between TI and CO2 emissions exhibits a
                                                                                         emission at normal to higher quantiles (0.40–0.95) with a 5 % signifi­
symmetric pattern, as evidenced by the significant Wald test statistic of
                                                                                         cance level. This implies that increased FFE contributes to environ­
3.814 at the 5 % level. Additionally, the analysis reveals an asymmetric
                                                                                         mental degradation at higher pollution levels, while its impact is
causal nexus from negative shocks in TI to CO2 emissions, with the Wald
                                                                                         insignificant at lower pollution levels.
                                                                                             The subsampling p-values in Table 9 show the quantile causality
Table 7
                                                                                         from TI, FFE, and RE to CO2 emissions. When all 11 quantiles are taken
Symmetric and asymmetric causality tests.
                                                                                         into account (see Table 9, first row), the results clearly indicate that TI,
  Panel A: Symmetric causality test                                                      FFE, and RE cause CO2 emissions. Moreover, TI causes CO2 emissions in
  Direction of        Wald test       Bootstrap CV   Bootstrap CV   Bootstrap CV         the lower, middle, and upper tails (10th, 30th, 50th, and 90th quantiles).
  causality                           10 %           5%             1%                   On the other hand, FFE causes CO2 emissions only in the upper tail
  TI ⇒ CO2            3.814**         2.174          4.527          9.796                (70th, 80th, and 90th quantiles). For RE, the analysis finds that quantile
  FFE⇒ CO2            5.912**         2.389          3.796          11.487               Granger causality is statistically significant across all quantiles except
  RE ⇒ CO2            12.44***        2.271          4.618          11.835               for three quantiles. (20th, 30th, and 60th). This means that RE causes
  Panel B: Asymmetric causality test                                                     CO2 emissions in 9 quantiles, mostly in the lower, middle, and upper
  Direction of     Wald test      Bootstrap CV       Bootstrap CV   Bootstrap CV         tails. The results of QARDL and QGC align with those obtained from the
    causality                     10 %               5%             1%
                                                                                         NARDL and asymmetric causality methods.
  TI+ ⇒ CO+2          2.454           2.488          4.094          7.553
  TI− ⇏ CO−2          11.325***       2.422          3.8            10.382               4.8. Discussion and implications
  FFE+→ CO+  2        2.111           3.675          2.522          10.037
  FFE− → CO−2         1.548           2.551          3.432          5.603
  RE → CO2
     +      +
                      10.302**        2.471          3.975          13.998                   This section will cover the results from the empirical analysis and
  RE− → CO−2          1.154           2.565          3.717          6.862                their significance in terms of empirical insights and policy implications.
Note: ⇒ and ⇏ signifies one-way causality or no causality, respectively. Critical        Three key findings will be highlighted. Firstly, the study demonstrates
values are indicated as CV for significance levels of *, **, and *** at 10 %, 5 %,       that any positive shocks to TI significantly decrease CO2 emissions in
and 1 %, correspondingly. The choice of the best lag is determined using the             Algeria, while negative shocks increase emissions levels. This is
Hatemi-J Criterion (HJC).                                                                consistent with prior research by many scholars [83,84] that concluded
Source: Author’s own estimates                                                           TI plays a role in lowering CO2 emissions. In Algeria, CO2 emissions tend

                                                                                     9
B. Bergougui                                                                                                                                     Energy Strategy Reviews 51 (2024) 101281


Table 8
QARDL results.
  Quantiles (τ)           Constant          ECM                Long-Run Coefficients estimates

                          α (τ)             ρ*                 ВTI(τ)             ВFFE(τ)              ВRE(τ)               ВGDP(τ)         ВPOP(τ)         ВFDI(τ)          ВTR(τ)

  0.05                    − 0.0613          − 0.0061           0.3249             − 0.0141             0.7649               0.0529          0.1539*         − 0.0561         0.1889
                          (0.2947)          (0.0179)           (0.9199)           (0.2729)             (1.3699)             (0.9019)        (0.0789)        (0.3599)         (2.2279)
  0.10                    − 0.4663**        0.0631             0.9409             − 0.0051             0.2919               0.8249          0.2049**        − 0.4511         2.6069*
                          (0.1787)          (0.0091)           (0.8719)           (0.2139)             (0.3549)             (0.5759)        (0.0699)        (0.3599)         (1.3149
  0.20                    0.3107            0.0171             0.5689             0.0069               0.4969               0.5559          0.2109**        − 0.4071         0.8489
                          (0.2607)          (0.0151)           (0.9199)           (0.1689)             (1.0329)             (1.1389)        (0.0639)        (0.4179)         (1.4929
  0.30                    0.3257            − 0.0491           − 0.9321***        0.0349               − 0.0431             0.2899          0.2179*         − 0.2861         0.4999
                          (0.2637)          (0.0041)           (0.1719)           (0.1509)             (0.3599)             (1.7129)        (0.1009)        (0.7549)         (2.2259
  0.40                    0.3077**          − 0.0531           − 0.3481***        0.0619**             − 0.1481             0.2389          0.1419          − 0.2251         0.5319
                          (0.1127)          (0.0081)           (0.0529)           (0.1169)             (0.3019)             (0.9759)        (0.0899)        (0.4489)         (1.5559
  0.50                    0.2147            − 0.0531           − 0.4601***        0.1039**             − 0.1051             − 0.0181        0.1439          − 0.1101         − 0.0041
                          (0.1357)          (0.0151)           (0.0559)           (0.0769)             (0.3059)             (0.7599)        (0.0889)        (0.3489)         (1.6049
  0.60                    0.2687*           − 0.0731**         − 0.3771***        0.1519***            − 0.152**            − 0.0231        0.1089          − 0.0691         0.0039
                          (0.1507)          (0.0121)           (0.0609)           (0.0589)             (0.076)              (0.3329)        (0.1019)        (0.1269)         (1.4469
  0.70                    0.2687            − 0.0751**         − 0.3811***        0.1689**             − 0.198**            − 0.0241        0.1039          − 0.0701         0.0039
                          (0.1647)          (0.0141)           (0.0169)           (0.0499)             (0.099)              (0.2829)        (0.0839)        (0.1259)         (1.3049
  0.80                    0.1837            − 0.0951***        − 0.3501***        0.2349***            − 0.326***           0.2819          0.1169          − 0.1361         1.9569
                          (0.2637)          (0.0101)           (0.0529)           (0.0299)             (0.065)              (0.3039)        (0.0969)        (0.0889)         (2.3139
  0.90                    0.2367            − 0.1511***        − 0.4361***        0.2499**             − 0.1981**           0.3889**        0.0069          − 0.1841**       4.9869**
                          (0.3037)          (0.0091)           (0.0639)           (0.0339)             (0.0519)             (0.1799)        (0.0729)        (0.0439)         (2.5319
  0.95                    − 0.1193          − 0.1541***        − 0.4481***        0.2619***            − 0.2691*            0.4889**        0.0259          − 0.2301**       6.3069**
                          (0.4457)          (0.0101)           (0.0659)           (0.0269)             (0.0939)             (0.2089)        (0.0779)        (0.0669)         (2.8419

Notes: *, **, and *** denote statistically significant at the 10 %, 5 %, and 1 % levels, respectively.
Source: Author’s own estimates



Table 9
QGC test results (subsampling p-values) from TI, FFE, and RE to CO2 emissions.
          Quantiles (τ)                           Δ(TI) to Δ(CO2)                                Δ(FFE) to Δ(CO2)                              Δ(RE) to Δ(CO2)

                                                  Lag (1)       Lag (2)        Lag (3)           Lag (1)        Lag (2)         Lag (3)        Lag (1)        Lag (2)       Lag (3)

          [0.05; 0.95]                            0.0032***     0.0379**       0.0379**          0.044**        0.0597          0.0246**       0.0047***      0.0047***     0.0091***

  1       0.05                                    0.129         0.1516         0.081             0.1657         0.1686          0.2219         0.0075***      0.0047***     0.0015***
  2       0.10                                    0.0047***     0.0047***      0.0379**          0.2547         0.5547          0.0738         0.3804         0.4708        0.7141
  3       0.20                                    0.0556        0.0527         0.0774            0.0612         0.1205          0.0555***      0.1177         0.1121        0.081
  4       0.30                                    0.0725        0.0471**       0.0163**          0.5047         0.1047          0.3055         0.0386**       0.033**       0.0487**
  5       0.40                                    0.1699        0.2687         0.3732            0.2207         0.3478          0.5962         0.1981         0.167         0.0099***
  6       0.50                                    0.0456**      0.0314**       0.0279**          0.4382         0.136           0.1394         0.0088***      0.0004***     0.33
  7       0.60                                    0.0738        0.0795         0.0566            0.054          0.054           0.2063         0.4411         0.8111        0.5315
  8       0.70                                    0.0569        0.054          0.1502            0.0088**       0.0456**        0.0674         0.0456**       0.0343**      0.0171
  9       0.80                                    0.0569        0.1134         0.1106            0.0812         0.0088***       0.0962         0.0145**       0.0088***     0.0009***
  10      0.90                                    0.0041***     0.0863         0.0495**          0.0194**       0.0755          0.0682         0.0053***      0.0053***     0.0099***
  11      0.95                                    0.2929        0.2105         0.0574            0.7038         0.4185          0.2293         0.2518         0.2066        0.0135**

  Summary of the QGC test results
  Quantiles                                       Subsampling P-Values                           Causality Findings
  All                                             Significant                                    TI, FFE, and RE cause CO2 emissions.
  10th, 30th, 50th, 90th                          Significant                                    TI causes CO2 emissions in lower, middle, and upper tail quantiles.
  70th, 80th, 90th                                Significant                                    FFE causes CO2 emissions in high tail quantiles.
  5th, 40th, 50th, 60th, 80th, 90th, 95th         Significant                                    RE causes CO2 emissions in lower, middle, and upper tail quantiles.

Notes: Δ(TI), Δ(FFE), Δ(RE), and Δ(CO2) represent the log-differences of technological innovation, fossil fuel energy, renewable energy, and carbon dioxide emissions,
respectively. Lag (1), Lag (2), and Lag (3) indicate the number of lags comprised for the dependent variable. *** and ** indicate rejection of the null hypothesis of no
Granger causality at the 1 % and 5 % levels of statistical significance, respectively.
Source: Author’s own estimates


to increase when TI decreases, and vice versa. This is because the                                technologies to extract more oil and gas can also contribute to increased
country relies on adopting existing innovations from other nations                                CO2 emissions [88]. However, this study contradicts the results of other
rather than creating its own, as discussed by Barro and Sala-i-Martin                             research that has suggested the opposite effect of TI on CO₂ emissions.
[85]. This can be attributed to its tendency to adopt pre-existing tech­                          For instance, Kartal and Pata [89] concluded that a TI can lead to an
nologies from other countries rather than fostering indigenous techno­                            upsurge in CO₂ emissions at higher quantiles. The reason behind these
logical innovations, which may lead to the adoption of environmentally                            discrepancies in the findings remains unclear. However, it is plausible
unfriendly technologies. As a result, any decline in TI could dispropor­                          that the difference is due to the different methodologies employed across
tionately contribute to higher CO2 emissions in Algeria. For instance, a                          the studies. For example, this study only considers the asymmetric
negative shock to TI could manifest in various forms, such as a reduction                         impact of TI on CO2 emissions, while other studies have considered the
in government investment in research and development, which could                                 symmetric impact.
result in a scarcity of new technologies and increased CO₂ emissions.                                 Secondly, the study found that positive and negative shocks to FFE
This scenario has been observed by Han et al. [86] in China and Petrović                         lead to a decreased in CO2 emissions, with negative shocks having
and Lobanov [87] in OECD countries. Besides, the use of new                                       nearly twice the impact. This is consistent with some previous studies


                                                                                            10
B. Bergougui                                                                                                              Energy Strategy Reviews 51 (2024) 101281


[84,90–92]. This is not surprising, given that Algeria’s economy is                  (4) Algerian authorities should carefully consider the asymmetric
heavily reliant on fossil fuel and an underdeveloped renewable energy                    relationship between these variables when assessing their impact.
sector [23]. Although Algeria has an abundant natural gas reserve,                       Positive and negative changes in TI, RE, and FFE yield varying
reducing the depletion of oil, coal, and natural gas would necessitate                   effects on CO2 emissions. Prioritizing the positive aspects of TI
importing low-quality oil from neighboring countries like Nigeria,                       and RE while addressing the negative consequences is crucial to
which would further harm the environment. As such, Algeria must                          achieve sustainable emission reduction strategies.
explore ways to reduce its reliance on FFE and increase its use of
renewable energy sources. This would not only improve its environ­                     By implementing these policy recommendations, Algeria can effec­
mental performance but also reduce CO2 emissions.                                  tively address its environmental challenges, reduce CO2 emissions, and
    Lastly, the current findings indicate that positive shock to RE has a          work towards a more sustainable future. Policymakers must prioritize
negative relationship with CO2 emissions, while positive shock does not            environmental sustainability and align TI with the country’s sustainable
have a noticeable effect. The findings of Kartal et al. [90,93] and Kartal         development goals to achieve these objectives.
& Pata [89] also showed similar results. According to these studies,
renewable energy sources produce zero to extremely low CO2 emissions               5. Conclusion, limitations, and future research
as they are derived from non-fossil resources, unlike traditional energy
sources, which help lower CO2 emissions. Moreover, Sahnoune and                    5.1. Conclusion
Imessad [46] showed that using RE reduces the CO2 emissions in
Algeria, and identified RE as an important factor to lower CO2 emissions              The objective of this study is to analyze the asymmetrical correlation
and support sustainable development. Similarly, Bélaïd and Youssef                between technological innovation (TI), fossil fuel (FFE), renewable en­
[16] and Sari Hassoun et al. [47] emphasized that an increase in RE has a          ergy (RE), and CO2 emissions in Algeria. This analysis is based on
significant impact on addressing technological barriers, such as limited           quarterly data spanning from 1980:Q1 to 2021:Q4, encompassing the
energy resources and inefficient infrastructure, in Algeria. Furthermore,          most recent data available. To investigate the relationships among these
due to the growing energy demand and its environmentally friendly                  variables, the study employs a nonlinear autoregressive distributed lag
nature, RE is projected to become the dominant energy source in the                (NARDL) approach and performs an analysis of asymmetric causality.
future. According to the International Renewable Energy Agency, RE                 Furthermore, for robustness checks, the study incorporates the use of
technologies offer the most cost-effective solution for achieving a 90 %           QARDL and QGC. The NARDL bound test confirms the existence of long-
reduction in CO2 emissions associated with energy use [83].                        term equilibrium relationships among TI, RE, FFE, and CO2 emissions in
    Based on the empirical results, the Algerian authorities should adopt          Algeria over the entire study period.
a number of policies to promote technology innovation, renewable en­                  The outcomes reveal that any positive shocks in TI significantly
ergy, and environmental protection. These policies should include.                 mitigate CO2 emissions by 0.343 %, while a negative shock increases the
                                                                                   emissions level by 0.282 %. Similarly, positive shocks in REC caused a
   (1) Algeria has set a target to generate 27 % of its electricity from RE        0.063 % reduction in CO2 emissions, while negative shocks have a
       sources by 2035, with a primary focus on solar power. To achieve            neutral effect on CO2 emission. In contrast, positive shocks in FFE trigger
       this, the government is partnering with foreign companies in                CO2 emissions by 0.0973 %. Strikingly, negative shocks have an even
       China, Germany, and the United States. It has launched a tender             more decisive effect, causing a nearly twofold rise (0.179 %) in CO2
       for a 1-GW solar energy project (includes the construction of five          emissions in the long run. Additionally, the findings from the symmetric
       power generation sites with a capacity ranging from 50 to 300               and asymmetric causality analysis reveal that TI, RE, and FFE cause CO2
       MW each). These efforts align with Algeria’s national renewable             emissions in Algeria. These findings are confirmed by the QARDL and
       energy program and the 2015 Paris Agreement, which targets 22               QGC approaches.
       GW of renewable energy generation by 2030 [94,95]. The gov­                    The results of this study partially align with the empirical research
       ernment should continue to prioritize the transition to a green             viewpoint, indicating that the estimated variables may show differences
       economy by substantially raising RE production and consump­                 in both positive and negative shocks. Ignoring the inherent nonlinear
       tion. It is also essential to promote and adopt new CO2                     nature of these shocks could lead to inaccurate conclusions. Algeria
       emission-reducing technologies without hindering economic                   could use these insights to develop a foundation for its environmental
       growth. The partnerships with foreign suppliers and the launch of           policy framework.
       solar energy projects are positive steps towards achieving these
       goals.                                                                      5.2. Limitations and future research
   (2) Considering the limited impact of technological innovation on
       reducing CO2 emissions, it is advisable for Algeria to promptly                While this study has made valuable contributions to existing litera­
       allocate public and private funds towards research and develop­             ture, it has also identified several limitations that could guide future
       ment. This investment should be directed towards enhancing                  research. Firstly, the study’s use of the total number of patents to
       energy efficiency, storage and power technologies, cross-cutting            represent technological innovation may not accurately reflect its envi­
       technologies, as well as the utilization of nuclear and renew­              ronmental impact, as it includes some non-environmentally friendly
       able energy. By decreasing reliance on FFE, the government can              patents. To address this, a better measure would be to focus on in­
       extract compensation from energy usage and TI.                              vestments in environmentally beneficial technologies. Unfortunately,
   (3) The electricity pricing structure in Algeria has maintained a rate          there is no such data available for Algeria. Hence, future research should
       of 2.2 dinar per kilowatt-hour (kWh) since 2005, equivalent to              consider this improved measure to gain a more precise understanding of
       approximately $0.027 per kWh. This pricing has positioned                   the relationship between green technology and environmental quality.
       Algeria as having one of the lowest costs for fossil fuel-derived           Secondly, this study only examined the effects of TI and FFE on Algeria’s
       energy among countries in the MENA over the past decade and                 CO2 emissions. It is crucial to recognize that the impact of TI and FFE on
       a half [16]. To reduce reliance on FFE and encourage polluters to           CO2 emissions in Algeria can have spatial implications that extend
       adopt greener technologies, the Algerian government should                  beyond its borders, as they can potentially affect neighboring countries
       implement carbon-neutral energy policies like cap-and-trade                 through international trade, investment, and other channels. Due to the
       systems and carbon taxes. The generated revenue can be allo­                limitations of the regression techniques employed, this study could not
       cated towards the funding of social welfare programs and the                account for these spatial effects. Future studies could potentially explore
       advancement of renewable energy projects.                                   the spatial impact of TI and FFE on African nations using panel spatial

                                                                              11
B. Bergougui                                                                                                                                   Energy Strategy Reviews 51 (2024) 101281


regression methodologies.                                                                           nonlinear quantile approaches, Environ. Sci. Pollut. Res. 29 (55) (2022)
                                                                                                    83824–83838, https://doi.org/10.1007/s11356-022-21715-8.
                                                                                                [8] B. Bergougui, S.M. Murshed, Aggregate and disaggregate impact of natural
Declaration of competing interest                                                                   resources on sustainable development: new evidence from the latest institutional
                                                                                                    data, Environ. Sustain. Indic. 20 (2023), 100302, https://doi.org/10.1016/j.
                                                                                                    indic.2023.100302.
    The authors declare that they have no known competing financial
                                                                                                [9] Y. Sun, A. Razzaq, H. Sun, M. Irfan, The asymmetric influence of renewable energy
interests or personal relationships that could have appeared to influence                           and green innovation on carbon neutrality in China: analysis from non-linear ARDL
the work reported in this paper.                                                                    model, Renew. Energy 193 (2022) 334–343, https://doi.org/10.1016/j.
                                                                                                    renene.2022.04.159.
                                                                                               [10] Y. Cheng, X. Yao, Carbon intensity reduction assessment of renewable energy
Data availability                                                                                   technology innovation in China: a panel data model with cross-section dependence
                                                                                                    and slope heterogeneity, Renew. Sustain. Energy Rev. 135 (2021), 110157,
    Data will be made available on request.                                                         https://doi.org/10.1016/j.rser.2020.110157.
                                                                                               [11] D. Kirikkaleli, E. Sofuoğlu, O. Ojekemi, Does patents on environmental
                                                                                                    technologies matter for the ecological footprint in the USA? Evidence from the
List of acronyms                                                                                    novel Fourier ARDL approach, Geosci. Front. 14 (4) (Jul. 2023), 101564, https://
                                                                                                    doi.org/10.1016/j.gsf.2023.101564.
                                                                                               [12] M.T. Kartal, S. Kılıç Depren, D. Kirikkaleli, Asymmetric effect of political stability
ADF    Augmented Dickey and Fuller                                                                  on production-based CO2 emissions in the UK: long-run evidence from nonlinear
ARDL   Autoregressive distributed lag                                                               ARDL and frequency domain causality, Environ. Sci. Pollut. Res. 30 (12) (2023)
BC     Breitung-Candelon                                                                            33886–33897, https://doi.org/10.1007/s11356-022-24550-z.
                                                                                               [13] Z. Mighri, M.I. AlSaggaf, Asymmetric impacts of renewable energy consumption
BDS    Brock, Dechert, and Scheinman
                                                                                                    and economic complexity on economic growth in Saudi Arabia: evidence from the
CO2    Carbon dioxide emissions                                                                     NARDL model, Environ. Sci. Pollut. Res. 30 (3) (2023) 7446–7473, https://doi.
CUSUM cumulative sum for recursive residuals                                                        org/10.1007/s11356-022-22718-1.
                                                                                               [14] Z. Mighri, S. Sarwar, S.A. Sarkodie, Impact of urbanization and expansion of forest
CUSUMSQ cumulative sum of squared for recursive residuals
                                                                                                    investment to mitigate CO2 emissions in China, Weather. Clim. Soc. 14 (3) (Jul.
FDI    Foreign direct investment                                                                    2022) 681–696, https://doi.org/10.1175/WCAS-D-21-0101.1.
FFE    Fossil fuel energy                                                                      [15] G. Aziz, Z. Mighri, Carbon dioxide emissions and forestry in China: a spatial panel
FFE    Negative shocks (fossil fuel energy consumption)                                             data approach, Sustainability 14 (19) (2022), https://doi.org/10.3390/
                                                                                                    su141912862.
FFE+   Positive shocks (fossil fuel energy consumption)                                        [16] F. Bélaïd, M. Youssef, Environmental degradation, renewable and non-renewable
GDP    Gross domestic product                                                                       electricity consumption, and economic growth: assessing the evidence from
HJC    Hatemi-J lag selection criterion                                                             Algeria, Energy Pol. 102 (2017) 277–287, https://doi.org/10.1016/j.
                                                                                                    enpol.2016.12.012.
KPSS   Kwiatkowski–Phillips–Schmidt–Shin                                                       [17] U.S. Eia, Energy Information Administration Publication, 2023, p. 2023.
JB     Jarque-Bera                                                                             [18] S.M. Chekouri, A. Chibi, M. Benbouziane, Examining the driving factors of CO2
LS     Lee-Strazicich                                                                               emissions using the STIRPAT model: the case of Algeria, Int. J. Sustain. Energy 39
                                                                                                    (10) (Nov. 2020) 927–940, https://doi.org/10.1080/14786451.2020.1770758.
NARDL Nonlinear autoregressive distributed lag                                                 [19] M. Elbadri, S. Bsikre, O. Alamari, M. Balcilar, Nexus between renewable energy
POP    Population growth                                                                            consumption, economic growth, and CO 2 emissions in Algeria: new evidence from
PP     Phillips and Perron                                                                          the Fourier-Bootstrap ARDL approach, Nat. Resour. Forum 47 (3) (Aug. 2023)
                                                                                                    393–412, https://doi.org/10.1111/1477-8947.12292.
QARDL Quantile autoregressive distributed lag
                                                                                               [20] M. Chaouachi, D. Balsalobre-Lorente, Environmental strategies for achieving a new
QGC    Quantile Granger causality                                                                   foreign direct investment golden decade in Algeria, Environ. Sci. Pollut. Res. 29
RE     Renewable energy                                                                             (25) (May 2022) 37660–37675, https://doi.org/10.1007/s11356-021-18149-z.
                                                                                               [21] WDI, World development indicators 2023. https://databank.worldbank.org/repo
REþ    Positive shocks (Renewable energy)
                                                                                                    rts.aspx?source=WorldDevelopmentIndicators, 2023.
RE     Negative shocks (Renewable energy)                                                      [22] S. Erdoğan, S. Yıldırım, D.Ç. Yıldırım, A. Gedikli, The effects of innovation on
TI     Technological innovation                                                                     sectoral carbon emissions: evidence from G20 countries, J. Environ. Manag. 267
TIþ    Positive shocks (Technological innovation)                                                   (2020), 110637, https://doi.org/10.1016/j.jenvman.2020.110637. Aug.
                                                                                               [23] A. Bouraiou, et al., Status of renewable energy potential and utilization in Algeria,
TI     Negative shocks (Technological innovation)                                                   J. Clean. Prod. 246 (2020), 119011, https://doi.org/10.1016/j.
TR     Trade openness                                                                               jclepro.2019.119011.
VAR    Vector autoregression                                                                   [24] N. Ahmad, L. Youjin, S. Žiković, Z. Belyaeva, The effects of technological
                                                                                                    innovation on sustainable development and environmental degradation: evidence
VECM   Vector error correction model                                                                from China, Technol. Soc. 72 (Feb. 2023), 102184, https://doi.org/10.1016/j.
                                                                                                    techsoc.2022.102184.
References                                                                                     [25] X. Pan, Y. Xiao, Z. Liu, Equilibrium or imbalance? Regional variations and
                                                                                                    evolutionary traits of two-way FDI coordination level in Yangtze River economic
                                                                                                    belt, Front. Environ. Sci. 10 (Aug) (2022), https://doi.org/10.3389/
 [1] C. Sulaiman, A.S. Abdul-Rahim, Can clean biomass energy use lower CO2 emissions
                                                                                                    fenvs.2022.970652.
     in African economies? Empirical evidence from dynamic long-run panel
                                                                                               [26] C. Cheng, X. Ren, K. Dong, X. Dong, Z. Wang, How does technological innovation
     framework, Environ. Sci. Pollut. Res. 27 (30) (2020) 37699–37708, https://doi.
                                                                                                    mitigate CO2 emissions in OECD countries? Heterogeneous analysis using panel
     org/10.1007/s11356-020-09866-y.
                                                                                                    quantile regression, J. Environ. Manag. 280 (2021), 111818, https://doi.org/
 [2] B. Li, N. Haneklaus, The role of renewable energy, fossil fuel consumption,
                                                                                                    10.1016/j.jenvman.2020.111818.
     urbanization and economic growth on CO2 emissions in China, Energy Rep. 7
                                                                                               [27] A. Razzaq, A. Sharif, S. Afshan, C.J. Li, Do climate technologies and recycling
     (2021) 783–791, https://doi.org/10.1016/j.egyr.2021.09.194.
                                                                                                    asymmetrically mitigate consumption-based carbon emissions in the United States?
 [3] U. Ali, Q. Guo, M.T. Kartal, Z. Nurgazina, Z.A. Khan, A. Sharif, The impact of
                                                                                                    New insights from Quantile ARDL, Technol. Forecast. Soc. Change 186 (Jan. 2023),
     renewable and non-renewable energy consumption on carbon emission intensity in
                                                                                                    122138, https://doi.org/10.1016/j.techfore.2022.122138.
     China: fresh evidence from novel dynamic ARDL simulations, J. Environ. Manag.
                                                                                               [28] M. Shahbaz, C. Raghutla, M. Song, H. Zameer, Z. Jiao, Public-private partnerships
     320 (2022), 115782, https://doi.org/10.1016/j.jenvman.2022.115782.
                                                                                                    investment in energy as new determinant of CO2 emissions: the role of
 [4] N. Amin, M.S. Shabbir, H. Song, M.U. Farrukh, S. Iqbal, K. Abbass, A step towards
                                                                                                    technological innovations in China, Energy Econ. 86 (2020), 104664, https://doi.
     environmental mitigation: do green technological innovation and institutional
                                                                                                    org/10.1016/j.eneco.2020.104664.
     quality make a difference? Technol. Forecast. Soc. Change 190 (May 2023),
                                                                                               [29] Y. Chen, C.-C. Lee, Does technological innovation reduce CO2 emissions?Cross-
     122413 https://doi.org/10.1016/j.techfore.2023.122413.
                                                                                                    country evidence, J. Clean. Prod. 263 (2020), 121550, https://doi.org/10.1016/j.
 [5] K. Ali, D. Jianguo, D. Kirikkaleli, J. Oláh, M. Altuntaş, Do green technological
                                                                                                    jclepro.2020.121550.
     innovation, financial development, economic policy uncertainty, and institutional
                                                                                               [30] T.S. Adebayo, D. Kirikkaleli, Impact of renewable energy consumption,
     quality matter for environmental sustainability? All Earth 35 (1) (Dec. 2023)
                                                                                                    globalization, and technological innovation on environmental degradation in
     82–101, https://doi.org/10.1080/27669645.2023.2200330.
                                                                                                    Japan: application of wavelet tools, Environ. Dev. Sustain. 23 (11) (Nov. 2021)
 [6] Ö. Depren, M.T. Kartal, F. Ayhan, S. Kılıç Depren, Heterogeneous impact of
                                                                                                    16057–16082, https://doi.org/10.1007/s10668-021-01322-2.
     environmental taxes on environmental quality: tax domain based evidence from
                                                                                               [31] M.M. Islam, M. Shahbaz, T. Sultana, Z. Wang, K. Sohag, S. Abbas, Changes in
     the nordic countries by nonparametric quantile approaches, J. Environ. Manag.
                                                                                                    environmental degradation parameters in Bangladesh: the role of net savings,
     329 (2023), 117031, https://doi.org/10.1016/j.jenvman.2022.117031.
                                                                                                    natural resource depletion, technological innovation, and democracy, J. Environ.
 [7] M.T. Kartal, U. Ali, Z. Nurgazina, Asymmetric effect of electricity consumption on
                                                                                                    Manag. 343 (2023), 118190, https://doi.org/10.1016/j.jenvman.2023.118190.
     CO2 emissions in the USA: analysis of end-user electricity consumption by


                                                                                          12
B. Bergougui                                                                                                                                      Energy Strategy Reviews 51 (2024) 101281

[32] P. Behera, A. Haldar, N. Sethi, Achieving carbon neutrality target in the emerging                Total Environ. 882 (2023), 163471, https://doi.org/10.1016/j.
     economies: role of renewable energy and green technology, Gondwana Res. 121                       scitotenv.2023.163471.
     (Sep. 2023) 16–32, https://doi.org/10.1016/j.gr.2023.03.028.                                 [57] M. Bouznit, M. del P. Pablo-Romero, CO2 emission and economic growth in
[33] X. Yuan, C.-W. Su, M. Umar, X. Shao, O.-R. Lobonţ, The race to zero emissions: can               Algeria, Energy Pol. 96 (Sep. 2016) 93–104, https://doi.org/10.1016/j.
     renewable energy be the path to carbon neutrality? J. Environ. Manag. 308 (2022),                 enpol.2016.05.036.
     114648 https://doi.org/10.1016/j.jenvman.2022.114648.                                        [58] S.M. Chekouri, A. Chibi, M. Benbouziane, Economic growth, carbon dioxide
[34] A. Olhoff, J.M. Christensen, Emissions Gap Report 2020, 2020.                                     emissions and energy consumption in Algeria: a wavelet coherence approach,
[35] T.S. Adebayo, S.D. Oladipupo, I. Adeshola, H. Rjoub, Wavelet analysis of impact of                World J. Sci. Technol. Sustain. Dev. 18 (2) (May 2021) 172–189, https://doi.org/
     renewable energy consumption and technological innovation on CO2 emissions:                       10.1108/WJSTSD-12-2020-0097.
     evidence from Portugal, Environ. Sci. Pollut. Res. 29 (16) (2022) 23887–23904,               [59] Z. Jia, B. Lin, How to achieve the first step of the carbon-neutrality 2060 target in
     https://doi.org/10.1007/s11356-021-17708-8.                                                       China: the coal substitution perspective, Energy 233 (2021), 121179, https://doi.
[36] K.R. Abbasi, F.F. Adedoyin, J. Abbas, K. Hussain, The impact of energy depletion                  org/10.1016/j.energy.2021.121179.
     and renewable energy on CO2 emissions in Thailand: fresh evidence from the novel             [60] A. Houlihan Wiberg, et al., A net zero emission concept analysis of a single-family
     dynamic ARDL simulation, Renew. Energy 180 (2021) 1439–1450, https://doi.                         house, Energy Build. 74 (2014) 101–110, https://doi.org/10.1016/j.
     org/10.1016/j.renene.2021.08.078.                                                                 enbuild.2014.01.037.
[37] A. Mujtaba, P.K. Jena, F.V. Bekun, P.K. Sahu, Symmetric and asymmetric impact of             [61] G.M. Grossman, A.B. Krueger, Environmental Impacts of a North American Free
     economic growth, capital formation, renewable and non-renewable energy                            Trade Agreement, National Bureau of Economic Research, Cambridge, MA, Nov,
     consumption on environment in OECD countries, Renew. Sustain. Energy Rev. 160                     1991, https://doi.org/10.3386/w3914.
     (2022), 112300, https://doi.org/10.1016/j.rser.2022.112300.                                  [62] G.M. Grossman, A.B. Krueger, Economic growth and the environment, Q. J. Econ.
[38] A. Rehman, H. Ma, I. Ozturk, M. Radulescu, Revealing the dynamic effects of fossil                110 (2) (May 1995) 353–377, https://doi.org/10.2307/2118443.
     fuel energy, nuclear energy, renewable energy, and carbon emissions on Pakistan’s            [63] UNFCC, Paris agreement, in: Report of the Conference of the Parties to the United
     economic growth, Environ. Sci. Pollut. Res. 29 (32) (2022) 48784–48794, https://                  Nations Framework Convention on Climate Change (21st Session, Retrived
     doi.org/10.1007/s11356-022-19317-5.                                                               December, HeinOnline, Paris, 2015, 2015, p. 2017. [Online]. Available: https://un
[39] N. Saqib, Asymmetric linkages between renewable energy, technological                             fccc.int/process-and-meetings/the-paris-agreement/the-paris-agreement.
     innovation, and carbon-dioxide emission in developed economies: non-linear                   [64] E. Braun, D. Wield, Regulation as a means for the social control of technology,
     ARDL analysis, Environ. Sci. Pollut. Res. 29 (40) (2022) 60744–60758, https://doi.                Technol. Anal. Strateg. Manag. 6 (3) (Jan. 1994) 259–272, https://doi.org/
     org/10.1007/s11356-022-20206-0.                                                                   10.1080/09537329408524171.
[40] Y. Cui, G. Aziz, S. Sarwar, R. Waheed, Z. Mighri, U. Shahzad, Reinvestigate the              [65] G. Verhoosel, Beyond the unsustainable rhetoric of sustainable development:
     significance of STRIPAT and extended STRIPAT: an inclusion of renewable energy                    transferring environmentally sound technologies, Geo. Int’l Envtl. L. Rev. 11
     and trade for gulf council countries, Energy Environ. (Jun. 2023), https://doi.org/               (1998) 49.
     10.1177/0958305X231181671, 0958305X231181671.                                                [66] B. Lin, R. Ma, Green technology innovations, urban innovation environment and
[41] N. Apergis, J.E. Payne, K. Menyah, Y. Wolde-Rufael, On the causal dynamics                        CO2 emission reduction in China: fresh evidence from a partially linear functional-
     between emissions, nuclear energy, renewable energy, and economic growth, Ecol.                   coefficient panel model, Technol. Forecast. Soc. Change 176 (Mar. 2022), 121434,
     Econ. 69 (11) (2010) 2255–2260, https://doi.org/10.1016/j.                                        https://doi.org/10.1016/j.techfore.2021.121434.
     ecolecon.2010.06.014.                                                                        [67] M.E. Porter, C. van der Linde, Toward a new conception of the environment-
[42] S.A. Sarkodie, S. Adams, Renewable energy, nuclear energy, and environmental                      competitiveness relationship, J. Econ. Perspect. 9 (4) (1995) 97–118, https://doi.
     pollution: accounting for political institutional quality in South Africa, Sci. Total             org/10.1257/jep.9.4.97.
     Environ. 643 (2018), https://doi.org/10.1016/j.scitotenv.2018.06.320.                        [68] P. Lanoie, J. Laurent-Lucchetti, N. Johnstone, S. Ambec, Environmental policy,
[43] K.H. Nguyen, M. Kakinaka, Renewable energy consumption, carbon emissions, and                     innovation and performance: new insights on the porter hypothesis, J. Econ.
     development stages: some evidence from panel cointegration analysis, Renew.                       Manag. Strat. 20 (3) (Sep. 2011) 803–842, https://doi.org/10.1111/j.1530-
     Energy 132 (2019) 1049–1057, https://doi.org/10.1016/j.renene.2018.08.069.                        9134.2011.00301.x.
[44] A. Sharif, O. Baris-Tuzemen, G. Uzuner, I. Ozturk, A. Sinha, Revisiting the role of          [69] Y. Shin, B. Yu, M. Greenwood-Nimmo, in: R.C. Sickles, W.C. Horrace (Eds.),
     renewable and non-renewable energy consumption on Turkey’s ecological                             Modelling Asymmetric Cointegration and Dynamic Multipliers in a Nonlinear
     footprint: evidence from Quantile ARDL approach, Sustain. Cities Soc. 57 (2020),                  ARDL Framework BT - Festschrift in Honor of Peter Schmidt: Econometric Methods
     102138, https://doi.org/10.1016/j.scs.2020.102138.                                                and Applications, Springer New York, New York, NY, 2014, pp. 281–314, https://
[45] S. Shan, S.Y. Genç, H.W. Kamran, G. Dinca, Role of green technology innovation                    doi.org/10.1007/978-1-4899-8008-3_9.
     and renewable energy in carbon neutrality: a sustainable investigation from                  [70] A. Hatemi-J, Hidden panel cointegration, J. King Saud Univ. Sci. 32 (1) (Jan. 2020)
     Turkey, J. Environ. Manag. 294 (Sep. 2021), 113004, https://doi.org/10.1016/j.                    507–510, https://doi.org/10.1016/j.jksus.2018.07.011.
     jenvman.2021.113004.                                                                         [71] C.W.J. Granger, G. Yoon, Hidden cointegration, SSRN Electron. J., Jan. (2002),
[46] F. Sahnoune, K. Imessad, Analysis and impact of the measures to mitigate climate                  https://doi.org/10.2139/ssrn.313831.
     change in Algeria, Energy Proc. 136 (2017) 495–500, https://doi.org/10.1016/J.               [72] C.M. Jarque, A.K. Bera, Efficient tests for normality, homoscedasticity and serial
     EGYPRO.2017.10.263.                                                                               independence of regression residuals, Econ. Lett. 6 (3) (1980) 255–259, https://
[47] S.E. Sari Hassoun, M. Mékidiche, M.S. Guellil, Examining the connection amongst                  doi.org/10.1016/0165-1765(80)90024-5.
     renewable energy, economic growth and carbon dioxide emissions in Algeria,                   [73] W.A. Broock, J.A. Scheinkman, W.D. Dechert, B. LeBaron, A test for independence
     Ekoist J. Econom. Stat. 14 (29) (2019) 199–223, https://doi.org/10.26650/                         based on the correlation dimension, Econom. Rev. 15 (3) (Jan. 1996) 197–235,
     ekoist.2018.14.29.0013. Jul.                                                                      https://doi.org/10.1080/07474939608800353.
[48] F. Amri, Carbon dioxide emissions, output, and energy consumption categories in              [74] D.I. Harvey, S.J. Leybourne, B. Xiao, A powerful test for linearity when the order of
     Algeria, Environ. Sci. Pollut. Res. 24 (17) (Jun. 2017) 14567–14578, https://doi.                 integration is unknown, Stud. Nonlinear Dynam. Econom. 12 (3) (2008).
     org/10.1007/s11356-017-8984-7.                                                               [75] J. Lee, M.C. Strazicich, Minimum Lagrange multiplier unit root test with two
[49] B. Saboori, J. Sulaiman, Environmental degradation, economic growth and energy                    structural breaks, Rev. Econ. Stat. 85 (4) (Nov. 2003) 1082–1089, https://doi.org/
     consumption: evidence of the environmental Kuznets curve in Malaysia, Energy                      10.1162/003465303772815961.
     Pol. 60 (2013) 892–905, https://doi.org/10.1016/j.enpol.2013.05.099.                         [76] A. Banerjee, J. Dolado, R. Mestre, Error-correction mechanism tests for
[50] E. Dogan, F. Seker, Determinants of CO2 emissions in the European Union: the role                 cointegration in a single-equation framework, J. Time Ser. Anal. 19 (3) (May 1998)
     of renewable and non-renewable energy, Renew. Energy 94 (2016) 429–439,                           267–283, https://doi.org/10.1111/1467-9892.00091.
     https://doi.org/10.1016/j.renene.2016.03.078.                                                [77] M.H. Pesaran, Y. Shin, R.J. Smith, Bounds testing approaches to the analysis of
[51] U. Al-Mulali, I. Ozturk, The investigation of environmental Kuznets curve                         level relationships, J. Appl. Econom. 16 (3) (May 2001) 289–326, https://doi.org/
     hypothesis in the advanced economies: the role of energy prices, Renew. Sustain.                  10.1002/jae.616.
     Energy Rev. 54 (2016) 1622–1631, https://doi.org/10.1016/j.rser.2015.10.131.                 [78] A. Hatemi-j, Asymmetric causality tests with an application, Empir. Econ. 43
[52] M.U. Rehman, M. Rashid, Energy consumption to environmental degradation, the                      (2012) 447–456.
     growth appetite in SAARC nations, Renew. Energy 111 (2017) 284–294, https://                 [79] K. Baz, et al., Asymmetric impact of energy consumption and economic growth on
     doi.org/10.1016/j.renene.2017.03.100.                                                             ecological footprint: using asymmetric and nonlinear approach, Sci. Total Environ.
[53] J. Wang, M. Usman, N. Saqib, M. Shahbaz, M.R. Hossain, Asymmetric                                 718 (2020), 137364, https://doi.org/10.1016/j.scitotenv.2020.137364.
     environmental performance under economic complexity, globalization and energy                [80] S. Matsumoto, H. Onuma, Measuring household ability to adopt new technology:
     consumption: evidence from the World’s largest economically complex economy,                      the case of light-emitting diodes (LEDs), J. Clean. Prod. 277 (2020), 123323,
     Energy 279 (2023), 128050, https://doi.org/10.1016/j.energy.2023.128050.                          https://doi.org/10.1016/j.jclepro.2020.123323.
[54] T.S. Adebayo, H. Rjoub, A new perspective into the impact of renewable and                   [81] C. Magazzino, M. Mele, C. Drago, S. Kuşkaya, C. Pozzi, U. Monarca, The trilemma
     nonrenewable energy consumption on environmental degradation in Argentina: a                      among CO2 emissions, energy use, and economic growth in Russia, Sci. Rep. 13 (1)
     time–frequency analysis, Environ. Sci. Pollut. Res. 29 (11) (2022) 16028–16044,                   (2023), 10225, https://doi.org/10.1038/s41598-023-37251-5.
     https://doi.org/10.1007/s11356-021-16897-6.                                                  [82] Z. Mighri, H. Ragoubi, S. Sarwar, Y. Wang, Quantile Granger causality between US
[55] F.V. Bekun, A.A. Alola, S.A. Sarkodie, Toward a sustainable environment: nexus                    stock market indices and precious metal prices, Res. Pol. 76 (Jun. 2022), 102595,
     between CO2 emissions, resource rent, renewable and nonrenewable energy in 16-                    https://doi.org/10.1016/j.resourpol.2022.102595.
     EU countries, Sci. Total Environ. 657 (2019) 1023–1029, https://doi.org/10.1016/             [83] T.S. Adebayo, S. Ullah, M.T. Kartal, K. Ali, U.K. Pata, M. Ağa, Endorsing sustainable
     j.scitotenv.2018.12.104.                                                                          development in BRICS: the role of technological innovation, renewable energy
[56] Q. Wang, C. Zhang, R. Li, Does renewable energy consumption improve                               consumption, and natural resources in limiting carbon emission, Sci. Total Environ.
     environmental efficiency in 121 countries? A matter of income inequality, Sci.                    859 (2023), 160181, https://doi.org/10.1016/j.scitotenv.2022.160181.




                                                                                             13
B. Bergougui                                                                                                                                          Energy Strategy Reviews 51 (2024) 101281

[84] U. Ali, et al., Heterogeneous impact of industrialization, foreign direct investments,                 linear approaches, Air Qual. Atmos. Heal. 16 (7) (2023) 1407–1417, https://doi.
     and technological innovation on carbon emissions intensity: evidence from                              org/10.1007/s11869-023-01351-y.
     Kingdom of Saudi Arabia, Appl. Energy 336 (2023), 120804, https://doi.org/                        [92] M. Imran, S. Ali, Y. Shahwan, J. Zhang, I.A. Al-Swiety, Analyzing the effects of
     10.1016/j.apenergy.2023.120804.                                                                        renewable and nonrenewable energy usage and technological innovation on
[85] R.J. Barro, X. Sala-i-Martin, Technological diffusion, convergence, and growth,                        environmental sustainability: evidence from QUAD economies, Sustainability 14
     J. Econ. Growth 2 (1) (1997) 1–26, https://doi.org/10.1023/A:1009746629269.                            (23) (2022), 15552, https://doi.org/10.3390/su142315552. Nov.
[86] L.M. Han, J.Q. You, J.N. Meng, Y.L. Fu, S.L. Wu, Empirical analysis of R&D                        [93] M.T. Kartal, S. Kılıç Depren, F. Ayhan, Ö. Depren, Impact of renewable and fossil
     spending, transport infrastructure development and CO2 emissions in China, Front.                      fuel energy consumption on environmental degradation: evidence from USA by
     Environ. Sci. 11 (2023) [Online]. Available: https://www.frontiersin.org/articl                        nonlinear approaches, Int. J. Sustain. Dev. World Ecol. 29 (8) (Nov. 2022)
     es/10.3389/fenvs.2023.1138876.                                                                         738–755, https://doi.org/10.1080/13504509.2022.2087115.
[87] P. Petrović, M.M. Lobanov, The impact of R&D expenditures on CO2 emissions:                      [94] B. Haddad, P. Díaz-Cuevas, P. Ferreira, A. Djebli, J.P. Pérez, Mapping concentrated
     evidence from sixteen OECD countries, J. Clean. Prod. 248 (2020), 119187,                              solar power site suitability in Algeria, Renew. Energy 168 (2021) 838–853, https://
     https://doi.org/10.1016/j.jclepro.2019.119187.                                                         doi.org/10.1016/j.renene.2020.12.081.
[88] A. Bolonkin, J. Friedlander, S. Neumann, Innovative unconventional oil extraction                 [95] S. Haddoum, H. Bennour, T. Ahmed Zaïd, Algerian energy policy: perspectives,
     technologies, Fuel Process. Technol. 124 (2014) 228–242, https://doi.org/                              barriers, and missed opportunities, Glob. Challenges 2 (8) (2018), https://doi.org/
     10.1016/j.fuproc.2014.01.024.                                                                          10.1002/gch2.201700134. Aug.
[89] M.T. Kartal, U.K. Pata, Impacts of renewable energy, trade globalization, and                     [96] M.T. Kartal, S.K. Depren, D. Kirikkaleli, Ö. Depren, U. Khan, Asymmetric and long-
     technological innovation on environmental development in China: evidence from                          run impact of political stability on consumption-based carbon dioxide emissions in
     various environmental indicators and novel quantile methods, Environ. Dev. 48                          Finland: evidence from nonlinear and Fourier-based approaches, J. Environ.
     (Dec. 2023), 100923, https://doi.org/10.1016/j.envdev.2023.100923.                                     Manag. 321 (2022), 116043, https://doi.org/10.1016/j.jenvman.2022.116043.
[90] M.T. Kartal, U.K. Pata, S. Kılıç Depren, Ö. Depren, Effects of possible changes in               [97] A. Razzaq, A. Sharif, P. Ahmad, K. Jermsittiparsert, Asymmetric role of tourism
     natural gas, nuclear, and coal energy consumption on CO2 emissions: evidence                           development and technology innovation on carbon dioxide emission reduction in
     from France under Russia’s gas supply cuts by dynamic ARDL simulations                                 the Chinese economy: fresh insights from QARDL approach, Sustain. Dev. 29 (1)
     approach, Appl. Energy 339 (2023), 120983, https://doi.org/10.1016/j.                                  (Jan. 2021) 176–193, https://doi.org/10.1002/sd.2139.
     apenergy.2023.120983.                                                                             [98] M. Shahbaz, M. Shafiullah, V.G. Papavassiliou, S. Hammoudeh, The CO2–growth
[91] S. Kılıç Depren, M.T. Kartal, D. Kirikkaleli, Ö. Depren, Effect of political stability on             nexus revisited: a nonparametric analysis for the G7 economies over nearly two
     environmental quality: long-run and asymmetric evidence from Iceland by non-                           centuries, Energy Econ. 65 (2017) 183–193, https://doi.org/10.1016/j.
                                                                                                            eneco.2017.05.007.




                                                                                                  14
