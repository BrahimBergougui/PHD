#!/usr/bin/env bash
# Summarise build/main.log into reports/build_report.md
cd "$(dirname "$0")/.."
LOG=build/main.log
R=reports/build_report.md
mkdir -p reports
pages=$(grep -oE "Output written on .* \(([0-9]+) pages" "$LOG" | grep -oE "[0-9]+ pages" | head -1)
ucite=$(grep -cE "Citation .* undefined" "$LOG" || true)
uref=$(grep -cE "Reference .* undefined" "$LOG" || true)
over=$(grep -c "Overfull" "$LOG" || true)
missing=$(for f in $(cut -d';' -f3 data/part2_papers.csv | tail -n +2); do [ -f "$f" ] || echo "$f"; done)
{
  echo "# Build report"
  echo "- Output: output/Memoire.pdf (${pages:-unknown})"
  echo "- Undefined citations: $ucite"
  echo "- Undefined references: $uref"
  echo "- Overfull boxes: $over"
  echo "- Missing Part Two PDFs: $(echo "$missing" | grep -c . || true)"
  [ -n "$missing" ] && echo "$missing" | sed 's/^/  - /'
  echo
  echo "## Undefined items"
  grep -E "(Citation|Reference) .* undefined" "$LOG" | sort -u | sed 's/^/- /' || true
} > "$R"
cat "$R"
