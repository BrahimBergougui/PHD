                                                                      Ecological Informatics 87 (2025) 103093


                                                                     Contents lists available at ScienceDirect


                                                                     Ecological Informatics
                                                           journal homepage: www.elsevier.com/locate/ecolinf




Towards eco-efficiency of OECD countries: How does environmental
governance restrain the destructive ecological effect of the excess use of
natural resources?
Brahim Bergougui a,b,c,*,1, Elma Satrovic d,1
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, Hague, the Netherlands
b
  College of Business & Economics, Qatar University, Doha, Qatar
c
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
d
  Department of International Trade and Logistics, Faculty of Economics, Administrative and Social Sciences, Hasan Kalyoncu University, Gaziantep, Türkiye




A R T I C L E I N F O                                      A B S T R A C T

Keywords:                                                  Developed economies face mounting environmental challenges from excessive resource consumption, but we
Excess use of natural resources                            lack clear evidence on how environmental policies can best address these issues. This study investigates how
Environmental governance                                   environmental governance shapes resource use and ecological efficiency across nine OECD countries from 1997
Overall eco-efficiency
                                                           to 2020. Our analysis reveals that stronger environmental policies significantly improve eco-efficiency: a 1 %
Services eco-efficiency
OECD
                                                           increase in environmental governance effectiveness enhances eco-efficiency by 0.65–0.95 %, with the strongest
                                                           effects observed in countries currently showing lower ecological efficiency. We find that increasing energy
                                                           transition efforts and research and development investment each contribute to improved eco-efficiency
                                                           (0.07–0.11 % and 0.19–0.35 % respectively), while excessive resource use reduces it by 0.07–0.03 %.
                                                           Notably, our study introduces a novel analytical approach by examining how environmental policies moderate
                                                           the negative impacts of resource overuse across different levels of ecological efficiency. This relationship proves
                                                           especially important for countries struggling with lower eco-efficiency, where strong environmental governance
                                                           can effectively offset the harmful effects of excessive resource consumption. These findings remain consistent
                                                           across multiple measures of eco-efficiency and trade indicators, offering robust evidence for policymakers. Our
                                                           research provides practical guidance for balancing economic development with environmental protection
                                                           through targeted policy interventions, particularly in resource-intensive economies working to improve their
                                                           ecological performance.




1. Introduction                                                                                  fertile lands, often leading to an excess use of natural resources (EUM)
                                                                                                 (OECD, 2009). The historical trajectory of OECD nations reveals a
    Over the past decades, Organisation for Economic Co-operation and                            nuanced narrative of economic progress that has increasingly con­
Development (OECD) countries have achieved substantial economic                                  fronted the ecological implications of intensive development. The eco­
growth and development through a complex interplay of resource uti­                              nomic growth in these countries has been paralleled by a growing
lization and environmental considerations. This expansion is primarily                           recognition of environmental concerns, prompting a comprehensive
rooted in the countries’ rich reserves of minerals, energy sources, and                          assessment of their eco-efficiency and sustainability over the long term



    Abbreviations: DI, Import Diversification Index; EIT, Economic Importance of International Trade; EPS, Environmental Policy Stringency; ETG, Environmental
Governance (Environmental Policy Stringency Index); EUM, Excess Use of Natural Resources; LEUM, Log of Excess Use of Natural Resources; LPRO, Log of GDP per
capita; LSEE, Log of Services Eco-Efficiency; LTEE, Log of Total Eco-Efficiency; LTRA, Log of Energy Transition; MACS, Moment Quantile Regression; OECD,
Organisation for Economic Co-operation and Development; PRO, Gross Domestic Product (GDP) per capita; RD, Research and Development intensity; RESR, Natural
Resources Rents; SEE, Services Eco-Efficiency; SVL, Services Value Added (used for Services Eco-Efficiency); TEE, Total Eco-Efficiency; TRA, Energy Transition; TRD,
Trade as a percentage of GDP; TRD, Trade (% of GDP); WB, World Bank.
 * Corresponding author at: International Institute of Social Studies (ISS), Erasmus University Rotterdam, Hague, the Netherlands.
    E-mail addresses: bergougui@iss.nl (B. Bergougui), elma.satrovic@hku.edu.tr (E. Satrovic).
  1
    Co-authors.

https://doi.org/10.1016/j.ecoinf.2025.103093
Received 28 October 2024; Received in revised form 23 February 2025; Accepted 23 February 2025
Available online 25 February 2025
1574-9541/© 2025 The Author(s). Published by Elsevier B.V. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui and E. Satrovic                                                                                                  Ecological Informatics 87 (2025) 103093


(OECD, 2024). This evolving perspective represents a significant shift              a crucial role in driving modern economic growth and managing EUM.
from earlier development models that prioritized economic expansion at              EPS has become essential for the transition to a green economy and is
the expense of environmental integrity. Regarding environmental per­                vital for environmental protection and avoiding future ecological di­
formance, OECD countries generally rank higher than developing na­                  sasters, significantly impacting these countries’ overall economic prog­
tions, but there is still considerable variation within the group.                  ress and eco-efficiency (Sohag et al., 2024). EPS in OECD countries
According to the environmental performance index in 2024, many                      encompasses both market and non-market-based approaches.
OECD countries rank in the top 20 out of 180 countries, with scores                 Market-based policies include taxes on economic externalities, such as
ranging from 60 to 80 out of 100, as shown in Fig. 1. However, some                 carbon emissions taxes, emissions-relevant trading strategies, and
OECD members still struggle with environmental issues, particularly                 deposit-refund procedures. Non-market-based environmental policies
related to greenhouse gas emissions and air quality. The OECD has                   consist of command-and-control tactics, including enforcement and
stressed the importance of transitioning to a green economy to boost                compliance measures. The prime objectives of the EPS are to address
economic growth while respecting environmental carrying capacity                    market failure, manage EUM, and galvanize sustainable economic
(OECD, 2019). The old paradigm of sacrificing the environment for                   development. EPS in OECD countries focus on mitigation policies, mainly
economic growth, often associated with EUM, is increasingly seen as                 promoting renewable/clean energies and energy efficiency through
outdated within these countries (Yıldız, 2023). This shift represents a             technological development. Environmental policies play a crucial role in
fundamental reconceptualization of economic development, moving                     moderating the impact of EUM on ecological efficiency, as highlighted by
beyond traditional extractive models to more sustainable approaches.                Sun et al. (2021). Their research suggests that well-designed policies can
Transitioning the economic and social development model towards a                   mitigate the negative effects of EUM and promote the integration of
green economy has emerged as a top priority for many OECD nations.                  sustainable practices.
This shift reflects the growing emphasis on sustainability and the need to              The literature indicates that the primary objective of eco-efficiency is
balance economic growth with environmental preservation (Doğan                     to optimize economic productivity while reducing environmental
et al., 2025). Green development initiatives have spread across in­                 impact and resource consumption (Fang et al., 2024). In OECD coun­
dustries as part of this ecological approach (Mamghaderi et al., 2023).             tries, eco-efficiency research has increasingly shifted from focusing
    The fundamental basis of the complex interaction between economic               solely on economic production to encompassing social services.
growth and environmental conservation is the significant correlation                Furthermore, there has been a transition from using two-dimensional
between a given area’s propensity for EUM and its influence on eco-                 resource and environmental metrics to incorporating three-
efficiency (Le et al., 2020). The excess use of minerals, forests, water            dimensional indicators that account for economic, social, and environ­
bodies, and fertile landforms the cornerstone of economic activity and              mental factors (OECD, 2008). However, assessments of human produc­
contributes to societal well-being in OECD nations. However, this very              tivity have often ignored fundamental aspects of human flourishing
excess that drives economic progress also introduces challenges related to          (Akpanke et al., 2024). While OECD countries generally maintain higher
maintaining ecological balance, adopting sustainable resource manage­               living standards compared to developing nations, balancing rapid eco­
ment practices, and adhering to environmental regulations (Chang et al.,            nomic and social development with environmental protection and
2024). Several OECD countries have faced what is known as the                       managing EUM remains a challenge. The ecological economic system in
“resource curse,” where EUM does not always lead to improved economic               these countries increasingly uses stage indicators, whereas GDP is still
performance and can even harm eco-efficiency (Bergougui and Murshed,                widely used as a final output by researchers (Chen et al., 2022; Yıldız,
2020, 2021, 2023; Liu et al., 2023; OECD, 2009). Eco-efficiency, as                 2024). Though improving human well-being is a key goal of sustainable
explained by and Bergougui (2024a) and Sun and Gao (2023a), refers to               development in OECD countries, there remains a persistent challenge in
how effectively ecological systems transform energy and materials into              ensuring that environmental protection measures and efforts to curb
biomass and other useful outputs. In the context of managing EUM within             EUM do not adversely affect the quality of life of citizens. Balancing
OECD countries, eco-efficiency often serves as a benchmark for assessing            sustainability with maintaining high living standards continues to be a
sustainable resource use (OECD, 2015). The relationship between EUM                 critical concern.
and eco-efficiency has been studied across various OECD settings. While                 The primary objective of this study is to examine how environmental
some research indicates that regions prone to EUM suffer from reduced               governance moderates the ecological impact of excessive natural
eco-efficiency, other studies, such as (Guo et al., 2024), argue that with          resource use on eco-efficiency across OECD countries. Specifically, the
technological advancements and sound governance, areas experiencing                 research aims to investigate the interplay between environmental pol­
EUM can achieve higher levels of eco-efficiency. The environmental                  icies, energy transition, research and development, and international
policy stringency (EPS) is profound in OECD member countries and plays              trade in driving eco-efficiency and achieving sustainable resource




Fig. 1. Overall environmental performance index scores for 180 countries in 2024.
Source: Yale Center for Environmental Law and Policy.

                                                                              2
B. Bergougui and E. Satrovic                                                                                               Ecological Informatics 87 (2025) 103093


management over the period 1997–2020. This objective is further                   impedes economic progress, and exacerbates environmental challenges.
delineated through the following key questions.                                   To address these issues, sustainable natural resource management is
                                                                                  essential to optimize resource use and alleviate resource constraint
 • How does the excessive use of natural resources influence eco-                 (Olawumi and Chan, 2018). Ahmad et al. (2020) examined how natural
   efficiency in OECD countries?                                                  resources influence environmental degradation in 22 emerging econo­
 • What roles do energy transition, research and development, and in­             mies, revealing that natural resources impact ecological footprints.
   ternational trade play in enhancing eco-efficiency?                            However, the study also highlighted that advanced technologies could
 • How does environmental governance moderate the negative                        restore natural resources and enhance ecological resilience. Erdoğan
   ecological effects of excessive use of natural resources on eco-               et al. (2021) investigated the position of natural resources in ecological
   efficiency, particularly in countries with lower eco-efficiency levels?        footprints across African countries from 1980 to 2016. Their findings
 • To what extent can alternative eco-efficiency indicators and different         indicated that inefficient resource utilization and poor environmental
   proxies for international trade validate the robustness of the                 governance significantly contributed to ecological footprints. In the case
   findings?                                                                      of China, He et al. (2022) demonstrated that oil revenues positively
                                                                                  influence environmental sustainability by mitigating greenhouse gas
    The novelty of this paper lies in its comprehensive examination of the        emissions. Conversely, natural resource rents found to intensify green­
relationship between natural resource use, eco-efficiency, and environ­           house gas emissions, presenting a dual challenge for sustainability.
mental governance in nine OECD countries over the period 1997–2020.               Xiaoman et al. (2021) analyzed the impact of natural resource on
This study makes several key contributions to the literature:                     environmental quality in Middle Eastern and North African (MENA)
                                                                                  countries. While natural resources was found to improve environmental
 • The paper addresses a significant gap in the existing literature by            quality, trade openness, urbanization and economic growth negatively
   investigating how effective environmental governance can mitigate              impacted ecological sustainability. Dong et al. (2018) investigated the
   the negative ecological impacts of EUM, a topic that has been                  interaction between China’s carbon emissions and renewable energy,
   underexplored in prior studies.                                                concluding that increased use of renewable energy and natural gas en­
 • The study employs moment quantile regression (MACS), offering a                hances environmental quality. Similarly, Umar et al. (2020) identified
   unique methodological approach that allows for a more nuanced                  key determinants of emissions, such as globalization and natural
   understanding of how variables like energy transition TRA, RD, and             resource use, and found that China’s economic expansion often extends
   international trade affect eco-efficiency across different quantiles of        at the cost of environmental sustainability. Their study provided evi­
   the distribution. This approach provides deeper insights than tradi­           dence that natural resource exploitation positively correlates with CO2
   tional methods, particularly in capturing heterogeneity in eco-                emissions and called for policy interventions to balance growth with
   efficiency across countries.                                                   environmental sustainability. Alfalih and Hadj (2022) used a Markov
 • The research highlights the moderating role of ETG in mitigating the           Regime        Switching     model      to    examine      the      natural
   detrimental effects of EUM on eco-efficiency. This is particularly             resource-environmental sustainability links in Saudi Arabia. They found
   important for countries with lower eco-efficiency, where ETG has a             that natural resource sustains sustainability under both maximal and
   more pronounced positive effect.                                               minimal environmental sustainability regimes. Similarly, Ali et al.
 • By incorporating robustness analyses, such as an alternative eco-              (2022a) assessed the dynamics between remittances, natural resource,
   efficiency indicator (services eco-efficiency), and using different            and economic expansion in Pakistan. They revealed that while resource
   proxies for international trade (import diversification index - DI), the       extraction and economic expansion negatively affected environmental
   paper enhances the validity of its findings and contributes a broader          quality, the role of technological innovation remained ambiguous.
   understanding of the dynamics influencing eco-efficiency.                      Interestingly, their findings suggested that natural resources could help
                                                                                  reduce CO2 emissions, contrasting with the widely observed trend of
    The rest of the paper is organized as follows. The second section             economic growth exacerbating emissions. In the GCC region, Majeed
offers a theoretical analysis of the relationship between natural resource        et al. (2021) explored the interplay between natural resource, economic
use, eco-efficiency, and environmental governance, while also outlining           globalization and energy consumption. Their results demonstrated that
the empirical methodology, including the use of MACS, and detailing the           a fossil fuel energy use and economic growth negatively affected envi­
data sources and variables used. The third section presents the empirical         ronmental quality. In contrast, renewable energy and resource abun­
results, followed by an in-depth discussion. The final section concludes          dance contributed positively, aligning with UN Sustainable
with the implications of the findings and offers recommendations for              Development Goal 13 (SDG-13).
policy and future research.
                                                                                  2.2. Environmental governance and eco-efficiency
2. Literature review
                                                                                      Environmental policies have long been recognized as essential tools
    This section carries out a comprehensive assessment of the empirical          for addressing environmental pollution, as market forces alone often fail
literature and theoretical background on the interplay among natural              to correct negative externalities caused by polluting activities. Govern­
resources, environmental governances, and eco-efficiency. To facilitate           ment interventions, therefore, play a critical role in mitigating these
a structured analysis, we have categorized the literature into the                externalities (Zheng et al., 2014). One prominent mechanism through
following subsections:                                                            which environmental policies influence environmental quality is the
                                                                                  direct cost channel. This channel operates by altering the financial in­
2.1. Natural resources and eco-efficiency                                         centives associated with polluting behaviors. Policies such as carbon
                                                                                  taxes or emission permits increase the costs of pollution-intensive ac­
   The perception of sustainable growth emphasizes achieving eco­                 tivities, encouraging firms to adopt cleaner production practices (Porter
nomic objectives while simultaneously preserving environmental and                and van der Linde, 1995). Stringent environmental policies, character­
social well-being. A critical facet of sustainable development lies in the        ized by higher pollutant prices or stricter emission limits, make polluting
responsible management and use of natural resources. Effective natural            less economically attractive and incentivize reductions in emissions
resource management plays a pivotal role in reducing ecological foot­             (Yirong, 2022). Conversely, lenient regulations can have the opposite
prints and fostering environmental stability (Kongbuamai et al., 2020).           effect, leading to increased pollution.
Excessive energy consumption, however, depletes natural resources,                    In addition to the direct cost mechanism, an indirect channel has been

                                                                              3
B. Bergougui and E. Satrovic                                                                                               Ecological Informatics 87 (2025) 103093


identified in the literature. This pathway emphasizes the place of envi­          eco-efficiency is quantified as the ratio between the total value-added
ronmental policies in stimulating innovation, particularly in clean and           (PRO) and ecological impact of human activities (ecological foot­
green technologies. Stricter environmental regulations increase the op­           print); whereas services eco-efficiency is the ratio between services
portunity cost of pollution, motivating firms to invest in cleaner tech­          value-added and ecological footprint. The utilization of the alternative
nologies. Strategies such as greater public expenditure on renewable              proxy for eco-efficiency (SEE) was driven by the fact that overall eco­
energy or supportive tariffs for renewable energy products lower the              nomic sectors and services could exhibit diverse impacts of the under­
cost of green innovations, further encouraging their adoption(K. Wang             lying independent variables to offer more substantial insights for policy
et al., 2020). Moreover, Johnstone et al. (2012) highlighted the                  makers.
importance of government demand for green technologies in driving                     Excess use of natural resources has been deemed essential determi­
innovation. Public awareness also plays a significant role, as stricter           nant of economic sophistication and ecological sustainability catching
policies can lead to increased consumer demand for green products                 the attention of academic community. Available literature scrutinizes the
(Ahmed, 2020).                                                                    two contrasting views on the EUM-environment nexus. As the first view,
    Despite these theoretical insights, the empirical evidence regarding          natural resources safeguard the supply of raw materials that are deemed
the impact of environmental regulations on environmental outcomes is              vital for global economic potential (Akram et al., 2023). However,
mixed. Many studies have examined the nexus between environmental                 resource-intensive countries might experience the faster rise of inputs in
policy stringency and environmental quality using the OECD Environ­               comparison with outputs that cause the decreasing returns to scale
mental Policy Stringency Index, a composite measure of market- and                impeding their sustainability efforts as the available resources will be
non-market-based regulations (Hille and Möbius, 2019). On one hand,              assigned to reduce the costs rather than to bolster environmental pro­
numerous studies have reported positive environmental impacts of                  tection (Bhowmik et al., 2024). The EUM accompanied with fluctuating
stricter regulations. For instance, Wang et al. (2020) demonstrated that          prices, poor environmental governance, and innovation reduction might
stringent policies improved air quality across 23 OECD countries, while           not only provoke the drop in economic potential but also intensify the
Ahmed (2020) found that environmental policy stringency reduced CO₂               ecological pressure (Danish and Ulucak, 2023). Furthermore, EUM
emissions and promoted clean technology innovation in 20 OECD                     extraction boosts air and water pollution, enhances energy intensity, and
countries. Similarly, Georgatzi et al. (2020) observed that environ­              consequently energy-related ecological problems (Ni et al., 2022). As the
mental policy stringency reduced transportation-related CO₂ emissions             second view, natural resources may play a vital role in boosting the
in 12 European countries and spurred environmental patenting activ­               ecological sustainability (Ullah et al., 2023a). The favourable ecological
ities. In BRICS nations, Wang et al. (2022) found that environmental              effect can be attributed to the fact that a positive correlation between
policy stringency facilitated renewable energy transitions, thereby               EUM and economic potential empowers countries to allocate the natural
reducing emissions.                                                               resources rents (RESR) towards the achievement of ecological sustain­
    On the other hand, a few studies have identified potential drawbacks          ability (Ahmad and Satrovic, 2024). In addition, natural resources rents
to stringent environmental policies. For example, Wolde-Rufael and                might facilitate economies to produce and consume eco-friendly goods
Mulat-Weldemeskel (2021) reported that EPS initially harmed envi­                 and services for ecological betterment (Villanthenkodath et al., 2024).
ronmental quality in seven emerging economies, with benefits emerging             Furthermore, EUM can ameliorate ecological sustainability by assigning
only after a threshold was reached. Their earlier study (2020) also               RESR to sustainable growth beneath the strong environmental gover­
highlighted the time-dependent nature of policy effectiveness in                  nance and research and development intensity (Khan et al., 2023; Shahid
BRIICTS countries. Furthermore, Yirong (2022) explored the asym­                  et al., 2024).
metric effects of environmental policy stringency, finding that both in­              The strict environmental governance is critical to defend ecological
creases and decreases in policy stringency could improve environmental            quality and sustainable development (Xie et al., 2023). To achieve these
quality in the world’s top five emitters, suggesting a complex, nonlinear         objectives, policy makers are determining and executing policies that
relationship.                                                                     will distract procedures harmful to the environment by putting a higher
                                                                                  price on such procedures. Herein, good environmental governance has
2.3. Theoretical background                                                       been thoroughly exerted as one of the critical policies to mitigate the
                                                                                  ecological pressure towards eco-sustainability (Ullah et al., 2023a). It
    This section establishes the economic intuitions linked up with the           opts to wipe out the side effects of economic potential i.e. environmental
nexus between eco-efficiency and the respective predictor variables               pollution by encouraging eco-innovation. As such, negative externalities
namely: extraordinary economic potential; energy transition; research             of PRO can hardly be restrained only by market forces spotlighting the
and development intensity; environmental governance; excess use of                criticality of government intervention through strict environmental
natural resources; and the economic importance of international trade.            policies. By imposing these policies, governments target to navigate
Beginning with the predicted variables, myriad of empirical studies               economies towards sustainable growth by abandoning practices that
embraces the measurement of ecological footprint, air pollution and               harm the environment (dirty industries) through preservation of natural
water pollution (AWP) to assess the major impacts of humans on the                resources and energy shift towards green sources (Bergougui and
environment (Ahmad and Satrovic, 2024; Danish and Ulucak, 2023;                   Aldawsari, 2024; Borowiec and Papież, 2024). Given the rising envi­
Khan et al., 2023; Musah et al., 2024; Yıldız et al., 2024). Ecological           ronmental concerns, governments should play an active role in curbing
footprint predominantly emphasizes the ecological impact to quantify              ecological pressure, as it is not uncommon that market forces alone fail
the consumption rate of natural resources, and the amount of waste                to assure the proper solution. In virtue of promoting innovation and
created. Similarly, AWP mainly focuses on the quantification of envi­             green energy, good ecological governance is fund effective in boosting
ronmental pollution with inadequate attention on the economy-                     the ecological and economic performance of business sector (Zou and
environment nexus. Against this backdrop, the current study estab­                Wang, 2024). Conversely, the execution of strict environmental policies
lishes on the two proxies for eco-efficiency as economics substantially           might incorporate additional costs which will offset the benefits of
relates with ecology. Herein, the improvement of ecological quality is            technological and efficiency betterments (Danish and Ulucak, 2023). In
deliberated to be a pragmatic path for economies to support the eco-              addition, uncertainty and disorder in national economies may obstruct
sustainability. Comprehending synchronously the ecological and eco­               environmental policies to achieve optimal performance. Xue et al.
nomic effect uncovers the efficiency of economic sector to utilize natural        (2022) further unfolded that ecological sustainability is grounded on the
assets and encourages it to pave way towards sustainable future by                reduction of policy-level disorder by establishing better communication
concentrating on activities that maintain the biocapacity and impairs             between economic agents. Considering the moderating impact of envi­
ecological footprint to revert to the state of biocapacity reserve. Overall       ronmental governance in the relationship between EUM and eco-

                                                                              4
B. Bergougui and E. Satrovic                                                                                                  Ecological Informatics 87 (2025) 103093


efficiency, good environmental governance presents a pragmatic tool for             research and development intensity. The transition to clean energy opts
the economic activity to enact sustainable practices in resources con­              for the facilitation of eco-efficiency and maintaining sustainable future.
sumption that will maintain ecological sustainability and advance the               This is since a set of policies embracing energy transition is needed to
efficient consumption of natural resources for the economic and envi­               facilitate green investments and clearance of dirty industries. Clean
ronmental targets (Ali et al., 2022b; Ullah et al., 2023a). Thus, strict            energy use is endeavouring the shift towards decarbonised economy and
environmental policies aim to boost the resource efficiency and pro­                flourishes the eco-efficiency against the ecological intensity (Jiang et al.,
ductivity to cut down the use of natural resources, hinder the ecological           2022; Ullah et al., 2023b; Yadav et al., 2023). By improving the
pressure, and increase value-added produced from these resources.                   ecological conditions, energy transition lays the foundation for the
    Although international trade is inevitable for the performance of               reduction of health spending, both private and public. Enabling an in­
national economies, the unfavourable ecological impacts are wide-                   clusive and equitable shift to clean energy provokes prosperous out­
ranging. Owing to the substantial rise in anthropogenic emissions                   comes for eco-efficiency as it relieves environmental pollution and paves
associated with international trade, broad range of studies were seeking            way towards climate change mitigation. On the other hand, the energy
to investigate the association between the economic importance of in­               shift might generate additional costs causing a firm turnover. As a
ternational trade (export + import (% GDP), and export/import diver­                consequence, energy transition might result in an unemployment rate
sification) and environment. A rise in commercial activity induces a                spike (Onwe et al., 2023). Research and development intensity might
boom in energy consumption which has a potential to reinforce the                   curtail the pollution attributable to the consumption patterns. With
ecological problems where the diversification of imports (DIM) is not an            digital transformation in place, research and development intensity
exception (Ahmad and Jabeen, 2024; Ahmad and Satrovic, 2023; Dai                    arose out as a feasible tool to alleviate ecological pressure and entail a
and Du, 2023). The severity of the DIM’s ecological impacts hinges on               net-zero transition. As an element of innovation, research and devel­
the economies’ level of income. As an illustration, a country may                   opment assists in ecosystem management to yield the sustainable use of
specialize in dirty industries in initial stages of economic emancipation           resources (Akram et al., 2023; Shahid et al., 2024; Ullah et al., 2023b). It
to use the advantages of the economies of scale that will not only boost            can also prompt the changing attitudes to motivate individuals to
profits and growth but also the energy consumption. As a consequence,               improve their waste management and diminish energy intensity for
initial stages of economic emancipation will amplify the ecological                 ecological sustainability. However, developing countries may witness
pressure. However, as the level of income increases, countries replace              the harmful environmental impact of research and development in­
dirty with clean industries to cut down the anthropogenic emissions.                tensity as it fosters industry dominated by dirty energy which may
Developed countries are also allocating significant resources to prevent            hinder the eco-efficiency targets of these countries (Chen et al., 2022;
ecological harm and obey environmental rules (Cheng et al., 2022;                   Onwe et al., 2023). If research and development intensity does not foster
Doğan et al., 2022). Accordingly, developed countries focus on the                 green tech, the economy is anticipated to face severe ecological
production that releases fewer anthropogenic emissions and import                   consequences.
goods with more pronounced adverse environmental impacts. Thus,
Madaleno et al. (2023) unfolded that DIM may encourage the ecological               2.4. Research gap
quality of developed countries. Developing countries however can attain
less expensive intermediate goods, and if these goods are pollution                     Despite significant progress in examining the dynamics of natural
intensive (i.e. crude oil, steel), the environment of these countries will be       resource use, environmental governance, and eco-efficiency, several
impaired (Dai and Du, 2023). International trade may amplify the                    critical gaps remain unaddressed in the existing literature.
ecological quality if the government imposes strict environmental pol­
icies. Otherwise, the uncertainty of environmental policies may jeop­                • First, while prior studies have explored the environmental impacts of
ardize the favourable ecological effect of DIM.                                        excessive natural resource use and eco-efficiency across various re­
    The association between extraordinary economic potential and                       gions, few have comprehensively analyzed the moderating role of
environment has been thoroughly scrutinized in the prior literature.                   environmental governance in mitigating these impacts, particularly
Pursuant to the formulation of environmental Kuznets curve (EKC),                      within the context of OECD countries.
Grossman and Krueger (1995) advocated that the developmental stage                   • Second, existing empirical analyses often employ traditional econo­
of growth is coupled with ecological pressure. With the scale effect in                metric methods that may overlook distributional effects. The appli­
place, extraordinary economic potential cuts down the ecological                       cation of moment quantile regression, which captures heterogeneity
quality. The notion is that in the early period of development, indus­                 across eco-efficiency quantiles, remains underutilized. This meth­
trialization dominates and escalates the energy use tending to magnify                 odological gap limits the understanding of how policy effectiveness
ecological deterioration. EKC paradigm further insinuates that once a                  varies across different eco-efficiency levels.
target wealth is secured, the technique effect comes on the scene abol­              • Third, although the link between international trade and environ­
ishing the harmful ecological impact of extraordinary economic poten­                  mental sustainability has been examined, the role of trade proxies,
tial. Subsequently, Grossman and Krueger (1995) opt for the concave                    such as the import diversification index, in shaping eco-efficiency
down (∩) nexus between PRO and ecological pressure. This research                      has received limited empirical attention. Considering trade’s dual
builds upon the environmental Kuznets curve (EKC) by incorporating                     role in fostering both economic growth and environmental stress,
additional explanatory variables such as energy transition, research and               more nuanced approaches are necessary.
development intensity, environmental governance, excess use of natural               • Fourth, current literature primarily focuses on singular eco-
resources, and twin facet of the economic importance of international                  efficiency indicators, often overlooking sector-specific impacts. The
trade. In addition, this study opts for the novel indicator of ecological              integration of an alternative eco-efficiency metric, such as services
quality namely overall eco-efficiency and services eco-efficiency and                  eco-efficiency, could provide deeper insights into sectoral dynamics.
scrutinizes the environmental governance-excess use of natural re­                   • Finally, while technological innovation and research and develop­
sources moderating impact.                                                             ment are recognized as key drivers of eco-efficiency, their interaction
    Ecological quality is reliant on PRO since economic development                    with environmental governance remains insufficiently explored.
necessitates the consumption of natural resources for the manufacturing                How R&D intensity might amplify or mitigate the ecological impact
process. Herein, in the early period of development, PRO jeopardizes                   of natural resource use under varying degrees of environmental
ecological quality but offsets these adverse impacts in the advanced                   governance warrants further investigation.
periods of development. Along with PRO, there are other variables that
predicted to influence eco-efficiency, such as energy transition and                   Addressing these gaps could advance the theoretical and empirical

                                                                                5
B. Bergougui and E. Satrovic                                                                                                    Ecological Informatics 87 (2025) 103093


understanding of sustainable resource management, offering valuable                   economic importance of international trade (trade/GDP) accessed from
policy recommendations for fostering eco-efficiency through enhanced                  the (WB, 2023). To delve into the impact of research and development
environmental governance frameworks.                                                  intensity on eco-efficiency, this study utilizes the gross domestic
                                                                                      spending on research and development (R&D)/GDP sourced from the
3. Methodology and data                                                               Organisation for Economic Co-operation and Development database
                                                                                      (OECD, 2023). This reliable source is also used to gather the balanced
3.1. Data definition                                                                  panel dataset on environmental policy stringency index as a proxy for
                                                                                      environmental governance (OECD, 2022). Finally, the second proxy for
    This study aspires to unriddle the puzzle on whether OECD countries               the economic importance of international trade (import diversification
would accomplish the eco-efficiency objectives by virtue of environ­                  index) is collected from the United Nations Conference on Trade and
mental governance scrutinizing the period from 1997 to 2020. The un­                  Development (UNCTAD, 2023). Descriptive statistics is further used to
derlying period of time is constructed to assure that each target country             assess the features of the underlying variables across OECD members
is measured every year between 1997 and 2020. For instance, the                       (see Table 2).
balanced panel dataset on services value added that provides a proxy for                   As per outcomes in Table 2, the mean overall eco-efficiency amounts
services eco-efficiency is provided from 1997 to 2022, at the same time               to 4905.22 for Canada, 6953.72 for France, 7284.99 for Germany,
ecological governance is last accessible in 2020. Table 2 lists the studied           6430.48 for Italy, and 6948.16 for Japan, whereas Korea, Spain, United
OECD members that are at the helm of the excess use of natural re­                    Kingdom, and United States report the following respective values of
sources (Hickel et al., 2022). As a response variable, this study adopts              TEE 4257.71, 5443.57, 8452.53, and 6004.08. Table 3 yields the results
the twin indicators of eco-efficiency to comprehend the ecological and                for the entire sample manifesting the average TEE value of 6297.83
economic impact of the various predictor variables on the overall eco-                (2015 US$/global hectare), whereas the average SEE value equals
efficiency and services eco-efficiency. The choice of the second indica­              4191.02 with United States, United Kingdom, Japan, Germany and
tor of eco-efficiency was grounded on the notion to ensure the robust­                France revealing the average values above the sample mean. United
ness and reliability of our findings. The calculation of the dependent                States ranked first in the extraordinary economic potential, whereas
variables is established on total economic value-added (GDP per capita                Korea yields the lowest average value. Considering the entire sample
in constant 2015 US$ - PRO) and services value-added (SVL). To achieve                average (Table 3), it can be noted that United States, United Kingdom,
the more substantive empirical findings, SVL is averaged on a per-capita              Germany and Canada are over-performing whereas the other countries
basis. After normalizing the SVL variable for the total population (POP),             are under-performing in terms of PRO. Maximum average research and
both PRO and SVL per-person gathered from the World Bank (WB, 2023)                   development intensity in Table 2 is reported for Korea whereas Spain
are divided by ecological footprint per capita sourced from Global                    holds on to its bottom position of the RD. Canada is the leader in energy
Footprint Network (GFN, 2022) to generate the twin features of eco-                   transition and excess use of natural resources whereas France holds to on
efficiency (ECEF) where:                                                              its top position of the environmental governance. The minimum average
⎧                                                                                     value of the environmental governance is unveiled for the United States,
                              PRO
⎪
⎪
⎪        TEE =                                                                        whereas the least responsible country for the excess use of natural re­
⎨                ecological footprint per capita
                                                                                      sources in the sample of selected OECD countries is Japan.
⎪
⎪      Services, value added/total population (POP)                                        Table 3 further displays the substantial standard deviations in
⎩ EE =
⎪
              ecological footprint per capita                                         particular for the indicator of eco-efficiency and PRO. The balanced
                                                                                      panel dataset divers from the normal distribution scrutinizing that
   Table 1 lists the variable and specifies sources and quantification.
                                                                                      environmental governance and trade (% of GDP) are left-tailed whereas
   Opting for the independent variables, this study scrutinizes the
                                                                                      all other variables are right-tailed insinuating a positive skewness co­
extraordinary economic potential of OECD members depending upon
                                                                                      efficient. Also, Table 3 manifests the bivariate correlation between the
the GDP per capita (constant 2015 US$), its quadratic term, energy
                                                                                      selected variables. According to the outcomes in Table 3, there is a
transition, excess use of natural resources, and the first proxy for the
                                                                                      strong positive linear relationship between TEE and ETG. The statisti­
                                                                                      cally significant positive coefficient is also provided between TEE and
Table 1                                                                               PRO as well as between TEE and RD. There is a significant negative
The details on variables.                                                             correlation between TEE and EUM, TEE and DI whereas the other cor­
  Name                                                    Code   Source
                                                                                      relation coefficients are not statistically significant. As far as the SEE is
                                                                                      scrutinized, Table 3 divulges the statistically significant positive corre­
  Extraordinary economic potential – gross domestic
                                                          PRO    WB (2023)            lation coefficient between SEE and PRO, TRA, ETG, and RD whereas the
    product - GDP per capita (constant 2015 US$)
  Energy transition – replacement of non-renewables                                   other coefficients are negative and significant.
    with renewables; the use of renewable energy (share   TRA    WB (2023)
    of total)                                                                         3.2. Empirical model
  Research and development intensity – gross domestic
                                                          RD     OECD (2023)
    spending on research and development (R&D)/GDP
  Environmental governance – environmental policy                                         This section establishes the economic intuitions linked up with the
                                                          ETG    OECD (2022)
    stringency index                                                                  nexus between eco-efficiency and the respective predictor variables
  Excess use of natural resources - total natural
                                                          EUM    WB (2023)
                                                                                      namely: extraordinary economic potential; energy transition; research
    resources rents (% of GDP)                                                        and development intensity; environmental governance; excess use of
  The economic importance of international trade (EIT)
    1 – trade (% of GDP)
                                                          TRD    WB (2023)            natural resources; and the economic importance of international trade.
  The economic importance of international trade 2                                    Beginning with the predicted variables, myriad of empirical studies
                                                          DI     UNCTAD (2023)
    –import diversification index                                                     embrace the measurement of ecological footprint, air pollution and water
                                                                 GFN (2022); WB       pollution (AWP) to assess the major impacts of humans on the environ­
  Overall eco-efficiency – PRO/ecological footprint per          (2023);
                                                          TEE                         ment (Ahmad and Satrovic, 2024; Danish and Ulucak, 2023; Khan et al.,
   capita (constant 2015 US$/global hectare)                     Author
                                                                 calculation          2023; Musah et al., 2024; Yıldız et al., 2024). Ecological footprint pre­
  Services eco-efficiency – services, value added                GFN (2022); WB       dominantly emphasizes the ecological impact to quantify the consump­
    (constant 2015 US$ - SVL)/total population (POP)/
                                                          SEE
                                                                 (2023);              tion rate of natural resources, and the amount of waste created. Similarly,
    ecological footprint per capita (constant 2015 US            Author               AWP mainly focuses on the quantification of environmental pollution
    $/global hectare)                                            calculation
                                                                                      with inadequate attention on the economy-environment nexus. Against

                                                                                  6
B. Bergougui and E. Satrovic                                                                                                 Ecological Informatics 87 (2025) 103093


Table 2
Descriptive statistics concerning individual countries.
  Unit of interest         Stat.        TEE               PRO         TRA           ETG          RD            EUM          TRD           DI             SEE

                           Mean         4905.22           40,938.75   21.77         2.29         1.82          2.65         68.41         0.22           3228.33
                           Stad. dev.   583.28            3019.73     0.59          1.01         0.12          1.43         6.61          0.01           459.60
                           Max          6043.72           45,113.10   23.85         3.61         2.02          5.56         82.77         0.23           4130.00
  Canada
                           Min          3995.95           33,861.10   21.13         0.72         1.61          0.33         58.47         0.20           2520.00
                           Skewness     0.150             − 0.781     1.836         − 0.481      0.121         0.448        0.674         − 0.200        0.184
                           Kurtosis     1.973             2.892       7.595         1.869        1.749         2.132        2.478         3.145          2.032
                           Mean         6953.72           35,391.27   11.44         3.21         2.16          0.05         56.38         0.18           4775.42
                           Stad. dev.   895.35            1956.24     2.50          1.10         0.07          0.01         4.82          0.03           705.67
                           Max          8654.02           38,832.00   16.87         4.89         2.28          0.07         64.44         0.21           6080.00
  France
                           Min          5588.49           30,650.70   8.52          1.47         2.02          0.03         48.03         0.14           3760.00
                           Skewness     0.434             − 0.639     0.591         − 0.329      − 0.163       0.234        − 0.011       − 0.223        0.361
                           Kurtosis     2.019             3.215       2.119         1.781        1.957         3.245        1.967         1.401          1.843
                           Mean         7284.99           37,886.39   10.06         2.73         2.67          0.12         74.35         0.16           4526.67
                           Stad. dev.   1164.76           3437.94     5.00          0.63         0.30          0.06         12.77         0.02           748.76
                           Max          9641.30           43,284.60   18.60         3.47         3.17          0.31         88.52         0.19           6140.00
  Germany
                           Min          5582.17           32,313.30   2.82          1.44         2.19          0.05         49.64         0.13           3360.00
                           Skewness     0.556             0.050       − 0.080       − 1.090      0.134         1.238        − 0.609       − 0.357        0.453
                           Kurtosis     2.174             1.652       1.677         2.713        1.770         4.494        1.954         2.385          2.324
                           Mean         6430.48           31,816.23   10.99         2.92         1.19          0.10         52.19         0.21           4132.50
                           Stad. dev.   704.70            1333.98     5.10          0.96         0.16          0.04         4.93          0.01           603.00
                           Max          7729.84           34,081.10   18.69         4.06         1.51          0.17         60.30         0.23           5350.00
  Italy
                           Min          5677.31           29,373.40   4.76          1.33         0.98          0.02         44.59         0.19           3460.00
                           Skewness     0.523             − 0.050     0.077         − 0.349      0.348         0.160        − 0.164       − 0.185        0.645
                           Kurtosis     1.707             1.891       1.360         1.520        1.835         2.456        1.840         1.882          1.972
                           Mean         6948.16           33,256.39   5.00          3.20         3.11          0.03         28.08         0.28           4748.33
                           Stad. dev.   881.59            1701.97     1.41          0.59         0.18          0.02         6.50          0.02           611.42
                           Max          9011.28           36,138.50   8.45          4.06         3.37          0.10         37.43         0.31           6010.00
  Japan
                           Min          5620.28           30,636.30   3.50          1.94         2.72          0.01         18.13         0.26           3730.00
                           Skewness     0.546             0.137       1.079         − 0.325      − 0.641       2.526        − 0.220       − 0.282        0.201
                           Kurtosis     2.630             1.885       3.009         2.253        2.283         8.257        1.564         2.337          2.318
                           Mean         4257.71           23,722.12   1.60          2.50         3.21          0.05         76.78         0.34           2357.50
                           Stad. dev.   731.12            5516.20     0.98          1.01         0.92          0.03         14.49         0.04           416.26
                           Max          5767.00           31,640.20   3.63          3.61         4.80          0.12         105.57        0.43           3250.00
  Korea
                           Min          2942.94           14,195.80   0.68          0.75         2.02          0.03         57.52         0.27           1610.00
                           Skewness     0.128             − 0.180     0.786         − 0.859      0.235         1.089        0.605         0.307          0.210
                           Kurtosis     2.110             1.807       2.053         2.048        1.616         2.971        2.316         2.893          2.198
                           Mean         5443.57           25,354.08   12.25         2.13         1.15          0.05         58.29         0.21           3525.42
                           Stad. dev.   989.15            1719.10     4.10          0.56         0.19          0.01         5.42          0.03           831.10
                           Max          6969.70           28,087.90   19.35         2.83         1.41          0.07         67.57         0.26           4750.00
  Spain
                           Min          4233.13           21,117.00   7.30          1.11         0.78          0.04         46.99         0.16           2550.00
                           Skewness     0.163             − 0.691     0.193         − 0.747      − 0.565       0.349        0.055         0.186          0.143
                           Kurtosis     1.335             3.263       1.376         2.085        2.001         2.019        2.266         2.087          1.300
                           Mean         8452.53           42,484.33   4.17          2.55         1.86          0.70         56.23         0.22           5832.92
                           Stad. dev.   1869.33           3050.23     3.81          0.97         0.44          0.29         4.99          0.03           1481.89
                           Max          12,271.73         47,491.60   13.50         3.86         2.93          1.34         64.13         0.30           8870.00
  United Kingdom
                           Min          6531.36           35,776.40   0.85          1.00         1.53          0.17         49.31         0.18           4160.00
                           Skewness     0.807             − 0.470     1.023         − 0.356      1.228         − 0.040      0.168         0.800          0.703
                           Kurtosis     2.251             2.744       2.855         1.751        3.000         2.594        1.659         3.875          2.149
                           Mean         6004.08           53,092.05   7.34          1.95         2.72          0.85         26.30         0.20           4592.08
                           Stad. dev.   1146.47           4334.34     2.11          0.71         0.24          0.40         2.78          0.01           913.65
                           Max          8279.26           60,698.00   11.16         3.03         3.47          1.93         30.84         0.22           6440.00
  United States
                           Min          4299.23           44,267.90   4.51          1.08         2.48          0.23         22.29         0.17           3270.00
                           Skewness     0.259             − 0.210     0.200         0.202        1.603         0.741        0.134         − 0.212        0.211
                           Kurtosis     1.887             2.363       1.663         1.545        5.597         3.578        1.749         1.957          1.868



this backdrop, the current study establishes on the two proxies for eco-                Excess use of natural resources has been deemed essential determi­
efficiency as economics substantially relates with ecology. Herein, the             nant of economic sophistication and ecological sustainability catching
improvement of ecological quality is deliberated to be a pragmatic path             the attention of academic community. Available literature scrutinizes
for economies to support the eco-sustainability. Comprehending syn­                 the two contrasting views on the EUM-environment nexus. As the first
chronously the ecological and economic effect uncovers the efficiency of            view, natural resources safeguard the supply of raw materials that are
economic sector to utilize natural assets and encourages it to pave way             deemed vital for global economic potential (Akram et al., 2023). How­
towards sustainable future by concentrating on activities that maintain             ever, resource-intensive countries might experience the faster rise of
the biocapacity and impairs ecological footprint to revert to the state of          inputs in comparison with outputs that cause the decreasing returns to
biocapacity reserve. Overall eco-efficiency is quantified as the ratio be­          scale impeding their sustainability efforts as the available resources will
tween the total value-added (PRO) and ecological impact of human ac­                be assigned to reduce the costs rather than to bolster environmental
tivities (ecological footprint); whereas services eco-efficiency is the ratio       protection (Bhowmik et al., 2024). The EUM accompanied with fluctu­
between services value-added and ecological footprint. The utilization of           ating prices, poor environmental governance, and innovation reduction
the alternative proxy for eco-efficiency (SEE) was driven by the fact that          might not only provoke the drop in economic potential but also intensify
overall economic sectors and services could exhibit diverse impacts of the          the ecological pressure (Danish and Ulucak, 2023). Furthermore, EUM
underlying independent variables to offer more substantial insights for             extraction boosts air and water pollution, enhances energy intensity,
policy makers.                                                                      and consequently energy-related ecological problems (Ni et al., 2022).


                                                                                7
B. Bergougui and E. Satrovic                                                                                                         Ecological Informatics 87 (2025) 103093


Table 3
Descriptive statistics concerning the overall sample and bivariate correlation.
  Stat./Var.          TEE             PRO               TRA              ETG               RD              EUM             TRD                 DI                SEE

  Mean                6297.83         35,993.51         9.40             2.61              2.21            0.51            55.22               0.22              4191.02
  Stad. dev.          1605.07         9081.00           6.45             0.95              0.82            0.95            18.73               0.06              1250.68
  Max                 12,271.73       60,698.00         23.85            4.89              4.80            5.56            105.57              0.43              8870.00
  Min                 2942.94         14,195.80         0.68             0.72              0.78            0.01            18.13               0.13              1610.00
  Skewness            0.744           0.336             0.566            − 0.235           0.449           3.031           − 0.074             1.064             0.621
  Kurtosis            4.287           3.140             2.263            2.259             2.947           12.861          2.748               3.995             4.150
  TEE                 1
                      0.423a
  PRO                                 1
                      0.000
                      0.108           0.195a
  TRA                                                   1
                      0.114           0.004
                      0.579a          0.083             0.225a
  ETG                                                                    1
                      0.000           0.222             0.001
                      0.141b          0.209a            − 0.307a         0.285a
  RD                                                                                       1
                      0.038           0.002             0.000            0.000
                      − 0.244a        0.374a            0.475a           − 0.241a          − 0.121c
  EUM                                                                                                      1
                      0.000           0.000             0.000            0.000             0.077
                      − 0.057         − 0.322a          0.289a           0.151b            − 0.007         0.114c
  TRD                                                                                                                      1
                      0.401           0.000             0.000            0.026             0.915           0.094
                      − 0.247a        − 0.427a          − 0.341a         0.112c            0.360a          − 0.108         0.036
  DI                                                                                                                                           1
                      0.000           0.000             0.000            0.099             0.000           0.113           0.597
                      0.971a          0.546a            0.126c           0.529a            0.129c          − 0.172b        − 0.217a            − 0.260a
  SEE                                                                                                                                                            1
                      0.000           0.000             0.065            0.000             0.058           0.011           0.001               0.000

Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %.


As the second view, natural resources may play a vital role in boosting                 Considering the moderating impact of environmental governance in the
the ecological sustainability (Ullah et al., 2023a). The favourable                     relationship between EUM and eco-efficiency, good environmental
ecological effect can be attributed to the fact that a positive correlation             governance presents a pragmatic tool for the economic activity to enact
between EUM and economic potential empowers countries to allocate                       sustainable practices in resources consumption that will maintain
the natural resources rents (RESR) towards the achievement of ecolog­                   ecological sustainability and advance the efficient consumption of nat­
ical sustainability (Ahmad and Satrovic, 2024). In addition, natural re­                ural resources for the economic and environmental targets (Ali et al.,
sources rents might facilitate economies to produce and consume eco-                    2022a; Ullah et al., 2023a). Thus, strict environmental policies aim to
friendly     goods     and    services    for    ecological      betterment             boost the resource efficiency and productivity to cut down the use of
(Villanthenkodath et al., 2024). Furthermore, EUM can ameliorate                        natural resources, hinder the ecological pressure, and increase value-
ecological sustainability by assigning RESR to sustainable growth                       added produced from these resources.
beneath the strong environmental governance and research and devel­                         Although international trade is inevitable for the performance of
opment intensity (Khan et al., 2023; Shahid et al., 2024).                              national economies, the unfavourable ecological impacts are wide-
    The strict environmental governance is critical to defend ecological                ranging. Owing to the substantial rise in anthropogenic emissions
quality and sustainable development (Xie et al., 2023). To achieve these                associated with international trade, broad range of studies were seeking
objectives, policy makers are determining and executing policies that                   to investigate the association between the economic importance of in­
will distract procedures harmful to the environment by putting a higher                 ternational trade (export + import (% GDP), and export/import diver­
price on such procedures. Herein, good environmental governance has                     sification) and environment. A rise in commercial activity induces a
been thoroughly exerted as one of the critical policies to mitigate the                 boom in energy consumption which has a potential to reinforce the
ecological pressure towards eco-sustainability (Ullah et al., 2023a). It                ecological problems where the diversification of imports (DIM) is not an
opts to wipe out the side effects of economic potential i.e. environmental              exception (Ahmad and Jabeen, 2024; Ahmad and Satrovic, 2023; Dai
pollution by encouraging eco-innovation. As such, negative externalities                and Du, 2023). The severity of the DIM’s ecological impacts hinges on
of PRO can hardly be restrained only by market forces spotlighting the                  the economies’ level of income. As an illustration, a country may
criticality of government intervention through strict environmental                     specialize in dirty industries in initial stages of economic emancipation
policies. By imposing these policies, governments target to navigate                    to use the advantages of the economies of scale that will not only boost
economies towards sustainable growth by abandoning practices that                       profits and growth but also the energy consumption. As a consequence,
harm the environment (dirty industries) through preservation of natural                 initial stages of economic emancipation will amplify the ecological
resources and energy shift towards green sources (Bergougui and                         pressure. However, as the level of income increases, countries replace
Aldawsari, 2024; Bergougui and Meziane, 2025; Borowiec and Papież,                     dirty with clean industries to cut down the anthropogenic emissions.
2024). Given the rising environmental concerns, governments should                      Developed countries are also allocating significant resources to prevent
play an active role in curbing ecological pressure, as it is not uncommon               ecological harm and obey environmental rules (Cheng et al., 2022;
that market forces alone fail to assure the proper solution. In virtue of               Doğan et al., 2022). Accordingly, developed countries focus on the
promoting innovation and green energy, good ecological governance is                    production that releases fewer anthropogenic emissions and import
fund effective in boosting the ecological and economic performance of                   goods with more pronounced adverse environmental impacts. Thus,
business sector (Zou and Wang, 2024). Conversely, the execution of                      Madaleno et al. (2023) unfolded that DIM may encourage the ecological
strict environmental policies might incorporate additional costs which                  quality of developed countries. Developing countries however can attain
will offset the benefits of technological and efficiency betterments                    less expensive intermediate goods, and if these goods are pollution
(Danish and Ulucak, 2023). In addition, uncertainty and disorder in                     intensive (i.e. crude oil, steel), the environment of these countries will be
national economies may obstruct environmental policies to achieve                       impaired (Dai and Du, 2023). International trade may amplify the
optimal performance. Xue et al. (2022) further unfolded that ecological                 ecological quality if the government imposes strict environmental pol­
sustainability is grounded on the reduction of policy-level disorder by                 icies. Otherwise, the uncertainty of environmental policies may jeop­
establishing better communication between economic agents.                              ardize the favourable ecological effect of DIM.

                                                                                    8
B. Bergougui and E. Satrovic                                                                                                  Ecological Informatics 87 (2025) 103093


    The association between extraordinary economic potential and                    all variables in Table 1 are adopted in this study as outlined by
environment has been thoroughly scrutinized in the prior literature.                (Bhowmik et al., 2024; Satrovic et al., 2024a). After the transformation,
Pursuant to the formulation of environmental Kuznets curve (EKC),                   the log-linear estimation equation of the eco-efficiency is formulated
Grossman and Krueger (1995) advocated that the developmental stage                  below (Eq. (2)):
of growth is coupled with ecological pressure. With the scale effect in
                                                                                    LECEFit = ω0 + ω1 LPROit + ω2 LPRO2it + ω3 LTRAit + ω4 LETGit
place, extraordinary economic potential cuts down the ecological                                                                                                 (2)
quality. The notion is that in the early period of development, indus­                         + ω5 LRDit + ω6 LEUMit + ω7 LEITit + εit
trialization dominates and escalates the energy use tending to magnify                 The coefficients ω1 − ω7 signal eco-efficiency assessments for the
ecological deterioration. EKC paradigm further insinuates that once a               underlying independent variables scrutinizing nine OECD members (i)
target wealth is secured, the technique effect comes on the scene abol­             during the period (t) from 1997 to 2020. An intercept is shown by ω0 ,
ishing the harmful ecological impact of extraordinary economic poten­               whereas the residual term is indicated by εit . The present study adopts
tial. Subsequently, Grossman and Krueger (1995) opt for the concave                 the two indicators of eco-efficiency (ECEF) namely overall eco-efficiency
down (∩) nexus between PRO and ecological pressure. This research                   (TEE) and services eco-efficiency (SEE). Term L connotes the natural log
builds upon the environmental Kuznets curve (EKC) by incorporating                  form of the variables. PRO, PRO2, TRA, ETG, RD, EUM, and EIT delineate
additional explanatory variables such as energy transition, research and            regressors namely: extraordinary economic potential, extraordinary
development intensity, environmental governance, excess use of natural              economic potential squared, energy transition, environmental gover­
resources, and twin facet of the economic importance of international               nance, research and development intensity, excess use of natural re­
trade. In addition, this study opts for the novel indicator of ecological           sources and the economic importance of international trade. Trade (% of
quality namely overall eco-efficiency and services eco-efficiency and               GDP) - TRD and import diversification index - DI are accustomed to
scrutinizes the environmental governance-excess use of natural re­                  measure the economic importance of international trade.
sources moderating impact.                                                             Emanating for the left-hand side of the Eq. (2), prior studies employ
    Ecological quality is reliant on PRO since economic development                 dozens of dependent variables such as greenhouse gasses emissions and
necessitates the consumption of natural resources for the manufacturing             ecological footprint to proxy the environment. However, these in­
process. Herein, in the early period of development, PRO jeopardizes                dicators are unsuccessful in opting for the economic aspect of eco- and
ecological quality but offsets these adverse impacts in the advanced                environmental sustainability indicators. To fill the void, this study
periods of development. Along with PRO, there are other variables that              hinges upon the two proxies for eco-efficiency namely overall and ser­
predicted to influence eco-efficiency, such as energy transition and                vices eco-efficiency (Ahmad and Jabeen, 2024; Apostu et al., 2023; Sun
research and development intensity. The transition to clean energy opts             and Gao, 2023b). As of the right-hand side of Eq. (2), myriads of studies
for the facilitation of eco-efficiency and maintaining sustainable future.          postulate the feasible direction on the eco-efficiency and its de­
This is since a set of policies embracing energy transition is needed to            terminants. In the first place, the concave down relationship between
facilitate green investments and clearance of dirty industries. Clean               PRO and environmental/ecological indicators is firmly established in
energy use is endeavouring the shift towards decarbonised economy and               previous empirical works (Borowiec and Papież, 2024; Madaleno et al.,
flourishes the eco-efficiency against the ecological intensity (Jiang et al.,       2023; Satrovic et al., 2024a; Xie et al., 2023). If certified, EKC phe­
2022; Ullah et al., 2023b; Yadav et al., 2023). By improving the                    nomenon insinuates that PRO reduces eco-efficiency in the early stages
ecological conditions, energy transition lays the foundation for the                of growth but furnishes the upswing in ecological quality at the later
reduction of health spending, both private and public. Enabling an in­
                                                                                    stages (i.e. ∂∂ECEF          ∂ECEFit
                                                                                                   PROit < 0 and ∂PRO2it > 0). Excess use of natural resources is
                                                                                                       it

clusive and equitable shift to clean energy provokes prosperous out­
                                                                                    considered a prominent feature to alleviate or ameliorate eco-efficiency
comes for eco-efficiency as it relieves environmental pollution and paves
way towards climate change mitigation. On the other hand, the energy                (i.e. ∂∂ECEF          ∂ECEFit
                                                                                            EUMit < 0 and ∂EUMit > 0). As for example, resource-intensive
                                                                                                 it


shift might generate additional costs causing a firm turnover. As a                 countries may encounter the decreasing returns to scale provoking the
consequence, energy transition might result in an unemployment rate                 alleviation of ecological patterns (Satrovic et al., 2024b). Similarly,
spike (Onwe et al., 2023). Research and development intensity might                 price variability, stagnation in innovation, and weak environmental
curtail the pollution attributable to the consumption patterns. With                management may initiate eco-unfriendly practices. By way of illustra­
digital transformation in place, research and development intensity                 tion (Danish and Ulucak, 2023; Ni et al., 2022) signal that weak envi­
arose out as a feasible tool to alleviate ecological pressure and entail a          ronmental management reinforces pollution associated with the
net-zero transition. As an element of innovation, research and devel­               extraction of natural resources and the intensification of fossil fuels. As
opment assists in ecosystem management to yield the sustainable use of              opposed to that, natural resources rents (RESR) may be a prominent
resources (Akram et al., 2023; Shahid et al., 2024; Ullah et al., 2023b). It        facet to ameliorate eco-efficiency as economically empowered countries
can also prompt the changing attitudes to motivate individuals to                   may direct more funds in helping protect eco-systems (Bhowmik et al.,
improve their waste management and diminish energy intensity for                    2024; Ullah et al., 2023a). In addition, RESR may encourage govern­
ecological sustainability. However, developing countries may witness                ments to direct investments in green innovation to bring eco-efficiency
the harmful environmental impact of research and development in­                    targets closer into view (Khan et al., 2023; Shahid et al., 2024).
tensity as it fosters industry dominated by dirty energy which may                  Strengthening environmental governance may establish an advanta­
hinder the eco-efficiency targets of these countries (Chen et al., 2022;            geous impact on eco-efficiency (i.e. ∂∂ECEF ETGit > 0) as projected by
                                                                                                                                    it


Onwe et al., 2023). If research and development intensity does not foster           (Borowiec and Papież, 2024; Ullah et al., 2023a; Xie et al., 2023; Zou
green tech, the economy is anticipated to face severe ecological                    and Wang, 2024). On the other hand, economic fluctuations may pre­
consequences.                                                                       vent the efficiency of environmental policies in reaching eco-efficiency
    Through the lens of the underlying associations among the studied               targets (i.e. ∂∂ECEF
                                                                                                    ETGit < 0) opting for the previous findings of (Danish and
                                                                                                        it

variables proposed in the preceding paragraphs, this research evaluates
                                                                                    Ulucak, 2023; Xue et al., 2022). International trade can lead to economic
the relationships between eco-efficiency and its determinants building
                                                                                    sophistication and better standard of living, but there are also the
upon the EKC theoretical framework. Our model follows the studies of
                                                                                    environmental impacts of expanded trade that need to be firmly
(Ahmad and Jabeen, 2024; Arjun and Mishra, 2024; Shi et al., 2024) and
                                                                                    considered. As suggested by (Ahmad and Jabeen, 2024; Cheng et al.,
is expressed by the following estimation equation as (Eq. (1)):
                                                                                    2022; Dai and Du, 2023) international trade might be one of the sub­
ECEF it = f(PROit , PRO2it , TRAit , ETGit , RDit , EUMit , EITit )      (1)        stantial determinants of ecological pressure (i.e. ∂∂ECEF
                                                                                                                                           EIT it < 0). This is
                                                                                                                                                 it



    To make sure that our dataset is uniform, the natural logarithms of             attributed to the upswing in energy consumption associated with

                                                                                9
B. Bergougui and E. Satrovic                                                                                                               Ecological Informatics 87 (2025) 103093


commercial activity. On the flip side, international trade is anticipated                           (               )− 1/2
                                                                                       ̂ ISH = N • 2k • (T − k − 1)
                                                                                              √̅̅̅̅                         (             )
to facilitate ecological quality (i.e. ∂∂ECEF
                                          EIT it > 0) as (Ahmad and Satrovic,
                                                it                                     ̂
                                                                                       Δ                                   • N− 1 • ̂
                                                                                                                                    S − 2k                                    (7)
                                                                                                         T+1
2023; Doğan et al., 2022; Madaleno et al., 2023) outlined the ecological
benefiting impact of EIT. This is since developed countries export                                                             ̂ ISH refers to the ISH and adjusted
                                                                                           Based on the (Eq. (6) and Eq. (7)), Δ
pollution by outsourcing their carbon intensity activities, and importing              ISH Pesaran (2007) test. The H0 endorses the homogeneous slopes,
eco-unfriendly commodities. In addition, international trade may                       whereas H1 posits that the underlying model encounters the heteroge­
encourage the circulation of green tech and more efficient production                  neous slopes. Under the assumptions of ISCR and ISH, there is a need to
methods propelling energy efficiency and efficient use of natural re­                  develop appropriate analytical approaches to cope with these issues. In
sources. According to the Jiang et al., 2022; Ullah et al., 2023b; Yadav               this vein, our study proposes the second generation stationarity test
et al., 2023) energy transition is projected to facilitate eco-efficiency (i.e.        (STE) by Pesaran (2007) as the reliance on the conventional tests may
∂ECEFit
∂TRAit > 0), while Onwe et al. (2023) established on the harmful effect of             yield the incorrect results. Cross-sectional Augmented Dickey-Fuller
energy transition on eco-efficiency such that (i.e. ∂∂ECEF                             (CADF) sets out as (Eq. (8)):
                                                      TRAit < 0). As far as
                                                           it


research and development intensity is considered, (Akram et al., 2023;                                                             n
                                                                                                                                   ∑
Shahid et al., 2024; Ullah et al., 2023b) support the view of favourable               ΔYit = ρi + ρi Yit− 1 + ρi Xt− 1 + ρi T +         ρij ΔYit− j + θit                    (8)
                                                                                                                                   j=1
ecological impacts of RD (i.e. ∂ECEF
                                 ∂RDit > 0). However, (Chen et al., 2022;
                                      it


Onwe et al., 2023) elaborated that research and development intensity                      Where Yit represents underlying panel dataset, the first difference of
might ameliorate ecological pressure (i.e. ∂ECEF                                       the variables is signified by Δ, while θit expresses the residual. STE test
                                            ∂RDit < 0).
                                                 it

                                                                                       established on CADF averages and can be econometrically articulated as
   Eq. (2) further looks into the interaction term of environmental
                                                                                       (Eq. (9)):
governance and natural resources to scrutinize the indirect impact of
EUM on overall and services eco-efficiency via the environmental                                    n
                                                                                                    ∑
                                                                                       STE = N− 1         CADF                                                                (9)
governance channel as proposed by Bhowmik et al. (2024). The model is
                                                                                                    i=1
specified as (Eq. (3)):
                                                                                           Next, this study utilizes the Westerlund (2005) cointegration test to
LECEFit = ω0 + ω1 LPROit + ω2 LPRO2it + ω3 LTRAit + ω4 LModit                          look into the long-run association between studied variables. Under the
                                                                           (3)
                 + ω5 LRDit + ω6 LEUMit + ω7 LEITit + εit                              H0, this test supposes no cointegration, whereas alternative hypothesis
                                                                                       presumes that eco-efficiency has a long-term nexus with the regressors.
   The interaction term is symbolized as Mod = ETG*EUM. Strength­
                                                                                       The second-generation cointegration (CTGT) test performs well if there
ening environmental governance may act in place of improving the
                                                                                       is the dependence of longitudinal data.
natural resources allocation, conservation of natural assests, and
                                                                                           Once ISCR and ISH issues are confirmed as well as the long-term
boosting the eco-friendly extracting practices. Herein, (Ali et al., 2022a;
                                                                                       association between the variables, our study establishes on Machado
Ullah et al., 2023a) elucidated the advantageous ecological impact of a
                    ∂ECEFit
                                                                                       and Silva (2019) estimation technique namely MACS. The choice of this
moderator (i.e. ∂(ETG             > 0).
                      it *EUMit )                                                      method was wheeled by the fact that conventional analytical techniques
                                                                                       provide average effects only and can potentially obtain overrated or
3.3. Methodology                                                                       underestimated predictions. In addition, these tests do not yield
                                                                                       consistent findings in the case of ISCR. Another advantage of MACS over
    Longitudinal data may face severe issues yielding inconsistent find­               traditional estimators is that it provides trustworthy findings under the
ings if neglected. To safeguard the unbiased estimates, the methodology                endogeneity problem and works well if the distribution deviates from
framework begins with detecting the cross-sectional dependence (ISCR)                  normal. It is eminent in addressing the nonlinearity problem and enables
and slope heterogeneity (ISH). Accordingly, to inspect whether our                     the assessment of location-related asymmetry. This method is also
dataset is independent across the investigative laboratory of nine OECD                effective if the estimated model establishes on the heterogenous slopes.
members, this study applies the Pesaran (2004) ISCR test which calcu­                  Further advantage of MACS stems from its ability to estimate regression
lates on the following equation (Eq. (4)):                                             coefficients at diverse conditional quantiles of overall and service eco-
         √̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅(
                                N− 1 ∑
                                     N
                                            )                                          efficiency. Given the variety of eco-efficiency indicators, MACS is
                 2T             ∑
                                                                                       capable to provide country-wise breakdown that might provide vital
ISCR =                                 ρ ij
                                       ̂                             (4)
           N(N − 1) i=1 j=i+1                                                          directions for the decisions makers. Contrary to traditional techniques,
                                                                                       MACS renders consistent findings in the case of non-normal distribution
   In Eq. (4), the period under examination is denoted by T, whereas the
                                                                                       of longitudinal data. Given these characteristics, MACS is proved to be
counties of interest are signalied by N. ̂ρ ij is the notion for bivariate
                                                                                       robust analytical framework as highly recommended by (Ullah et al.,
correlation which is shown below (Eq. (5)):
                                                                                       2023b; Shi et al., 2024; Bergougui et al., 2025). The MACS can be
                           T
                           ∑                                                           formulated as (Eq. (10)):
                                εit εjt
                          t=1
ρ ij = ̂ρ ji =
̂                                                                          (5)         QYit (τ|Xit ) = α(τ)ʹXit + βi , i = 1, …, N, t = 1, …, T                             (10)
                 ( T           )1 ( T            )1
                  ∑ 2           2  ∑              2
                         εit              ε2jt                                             In Eq. (10), Yit is the representation of overall and services eco-
                   t=1              t=1
                                                                                       efficiency (twin features of eco-efficiency); Xit stands for the re­
    The null hypothesis supposes that our balanced panel data are not                  gressors, namely LPRO, LPRO2, LTRA, LETG, LRD, LEUM, and LEIT. Un­
dependent across inspected countries, whereas the H1 is in conformity                  known parameters are symbolized by a(τ) while individual effects are
with the dependence of longitudinal data. Furthermore, this study looks                denoted by βi . Eq. (10) is supplemented with variables shown in Table 1
over the premise of slope homogeneity. Pursuing upon it, we establish                  to outline the augmented version of EKC theoretical framework
on the ISH test commenced by Pesaran (2007). Equations below provide                   following the studies of (Ahmad and Jabeen, 2024; Arjun and Mishra,
a mathematical expression of the test (Eq. (6) and Eq. (7)):                           2024; Shi et al., 2024). The formulation of the underlying models as
        √̅̅̅̅ √̅̅̅̅̅̅ (       )                                                        below (Model 1 – Eq. (11); Model 2 – Eq. (12); Model 3 – Eq. (13);
̂ ISH = N • 2k • N− 1 • ̂ S− k                                      (6)
Δ                                                                                      Models 4 – Eq. (14)):




                                                                                  10
B. Bergougui and E. Satrovic                                                                                                      Ecological Informatics 87 (2025) 103093


QLTEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LETGit                   homogeneous slope in support of the H1 postulating the heterogeneous
                                                                          (11)        slope. Both delta and adjusted delta statistics lead us to conclude that
                 + a5τ LRDit + a6τ LEUMit + a7τ LTRDit + βi
                                                                                      underlying models’ slopes manifest heterogeneity. The justification of
QLSEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LETGit                   these outcomes can be due to the variations in economic structures of
                                                                          (12)        the target OECD members. On the other hand, Table 4 furnishes the
                 + a5τ LRDit + a6τ LEUMit + a7τ LTRDit + βi
                                                                                      outcomes of Pesaran’ (2004) test endorsing the occurrence of ISCR. The
                                                                                      observed model specifications in Table 4 disapprove the H0 on inde­
QLTEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LModit
                                                                          (13)        pendent series across sections backing the H1 at the 1 % significance
                 + a5τ LRDit + a6τ LEUMit + a7τ LTRDit + βi                           levels. It discloses that vigorous shifts in overall and services eco-
                                                                                      efficiency, extraordinary economic potential, energy transition,
QLSEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LModit                   research and development intensity, environmental governance, excess
                                                                          (14)
                 + a5τ LRDit + a6τ LEUMit + a7τ LTRDit + βi                           use of natural resources, and the economic importance of international
                                                                                      trade in an OECD member are anticipated to alter other members
    In Eqs. (11–14), Mod = ETG*EUM.
    Robustness check is performed by applying the Driscoll-Kraay esti­                (Satrovic et al., 2024c). Given these findings it can be asserted that in the
                                                                                      time span between 1997 and 2020, OECD members undergo steadily
mator (ESDK) that empirically estimates the formulated models. This is a
trustworthy estimator if the sample is challenged by ISCR, autocorre­                 growing economic and financial interrelatedness. The unattended ISCR
                                                                                      and ISH concerns of longitudinal data may hinder the quality of dataset
lation, and heteroscedasticity issue. In addition, ESDK is a nonpara­
metric analytical framework flexible enough to utilize balanced or                    and furnish unsound results. Against this setting, this study uses the
                                                                                      methods allowed to cope with these issues going ahead with the second-
unbalanced longitudinal data. It is capable of estimating comprehensive
time dimensions and as such intensively used in studies to date (Arjun                generation stationary test (STE) summarized in Table 5.
                                                                                          As seen in Table 5, STE test scores are not reported significant for
and Mishra, 2024; Satrovic et al., 2024b). Besides, the soundness of our
findings further establishes on the alternative indicator of EIT. Models              natural logarithms of extraordinary economic potential, extraordinary
                                                                                      economic potential squared, eco-efficiency, energy transition, research
supplemented with the import diversification index (DI) follow the
augmented EKC paradigm (Ahmad and Jabeen, 2024; Arjun and Mishra,                     and development intensity, environmental governance, excess use of
                                                                                      natural resources, and the economic importance of international trade
2024; Shi et al., 2024) and are manifested as (Model 5 – Eq. (15); Model
6 – Eq. (16); Model 7 – Eq. (17); Models 8 – Eq. (18)):                               approving the assumption of non-stationarity at levels. For the first
                                                                                      difference form, the p values below 1 % guide us towards the refusal of
QLTEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LETGit                   null hypothesis giving support to H1 that assumes stationarity of the
                                                                          (15)
                 + a5τ LRDit + a6τ LEUMit + a7τ LDIit + βi                            inspected panel dataset. After affirming that the first differences are all
                                                                                      integrated of order one (i.e. I(1)), we apply the cointegration test as
QLSEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LETGit                   portrayed in Table 6.
                                                                          (16)            The Westerlund’s (2005) CTGT test assesses whether the proxies for
                 + a5τ LRDit + a6τ LEUMit + a7τ LDIit + βi
                                                                                      eco-efficiency converge to the long-term equilibrium. As seen in Table 6,
QLTEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LModit                   the null-hypothesis of no cointegration cannot be accepted given the
                                                                          (17)        statistically significant values of test statistics (p < 0.01). This offers the
                + a5τ LRDit + a6τ LEUMit + a7τ LDIit + βi
                                                                                      evidence that OECD members’ economy is apt to secure soundness in the
                                                                                      long-term after any vigorous shifts in the factors of eco-efficiency.
QLSEE (τ|Xit ) = a1τ LPROit + a2τ LPRO2it + a3τ LTRAit + a4τ LModit
                                                                          (18)        Herein, the outcomes of Westerlund’s (2005) CTGT test manifest the
                + a5τ LRDit + a6τ LEUMit + a7τ LDIit + βi                             cointegration linkage amid the studied variables.
  The next section furnishes empirical outcomes and showcases eco­
nomic interpretations.
                                                                                      4.2. Estimated outcomes and discussion

4. Empirical results
                                                                                          Given the cointegration association between our variables, this study
                                                                                      further assesses the regression coefficients. The outcomes of ESDK and
4.1. Feedback from pre-estimation analysis
                                                                                      MACS estimators are thereby furnished in Table 7 (quantiles 0.1, 0.3,
                                                                                      0.5, 0.7 and 0.9) and Fig. 2 (the remaining quantiles).
    It was essential to gauge the properties of the underlying variables
ahead of identifying the elasticity coefficients. In this respect, the un­
                                                                                      4.2.1. Extraordinary economic potential and eco-efficiency
derlying study considers the two most prevalent issues
                                                                                         As presented in Table 7 and Fig. 2, this study evaluates two types of
    accompanying longitudinal data, namely cross-sectional dependence
(ISCR) and slope heterogeneity (ISH). Table 4 furnishes the findings of
                                                                                      Table 5
Pesaran (2004) ISCR test and Pesaran (2007) ISH test.
                                                                                      Unit root approach.
    The findings of the ISH test in Table 4 portray the significant test
statistics (p < 0.01) to deny the null hypothesis theorizing the                       Variable                        URT (intercept & trend)

                                                                                                                       Level                           First difference
Table 4                                                                                LPRO                            − 2.533                         − 3.762a
Slope heterogeneity and cross-sectional dependence - outcomes.                         LPRO2                           − 2.519                         − 3.708a
  Stat./Model           Model 1        Model 2          Model 5       Model 6          LTRA                            − 2.213                         − 5.138a
                                                                                       LETG                            − 3.366                         − 5.349a
  Δ                     7.628a         7.625a           7.489a        7.410a           LRD                             − 1.957                         − 3.430a
                        0.000          0.000            0.000         0.000            LEUM                            − 2.546                         − 5.918a
  Δ adj.                9.649a         9.645a           9.473a        9.373a           LTRD                            − 1.255                         − 3.363a
                        0.000          0.000            0.000         0.000            LDI                             − 2.788                         − 4.895a
  ISCR                  5.856a         4.694a           4.346a        3.556a           LTEE                            − 3.140                         − 5.382a
                        0.000          0.000            0.000         0.000            LSEE                            − 3.277                         − 5.605a
                                                                                       LMod                            − 3.029                         − 5.959a
Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %; Δ captures
delta, and Mod = ETG*EUM.                                                             Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %.

                                                                                 11
B. Bergougui and E. Satrovic                                                                                                   Ecological Informatics 87 (2025) 103093


Table 6                                                                               (2023), Xie et al. (2023), and Borowiec and Papież (2024), who high­
Feedback on cointegration.                                                            lighted that income drives ecological sustainability while mitigating
  Test/Model                   Model 1   Model 2         Model 5       Model 6        ecological intensity at later stages of growth. Notably, Xie et al. (2023)
                                                                                      examined the ecological impact of economic growth among OECD
  Westerlund’s (2005)          6.038a    4.913a          6.908a        6.069a
                               0.000     0.000           0.000         0.000          members and found no evidence to validate the Environmental Kuznets
                                                                                      Curve (EKC) concept during the period from 1990 to 2020. Similarly,
Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %.
                                                                                      Ahmad and Jabeen (2024) concluded that economic growth signifi­
                                                                                      cantly enhances the eco-efficiency of European Union members in the
models—overall eco-efficiency (O-form models) and services eco-                       long run.
efficiency (S-form models)—as dependent variables. Both models are
analyzed with and without incorporating the joint effects of ETG and                  4.2.2. Energy transition and eco-efficiency
EUM. Table 7 illustrates that the two O-form models highlight a negative                  Our findings reveal that energy transition enhances the overall eco-
relationship between extraordinary economic potential and overall eco-                efficiency of OECD members, as evidenced by the O-form models. In the
efficiency. Simultaneously, a statistically significant positive association          model without a joint effect, the coefficient of LTRA is statistically sig­
between LPRO2 and the dependent variable is evident.                                  nificant and positive across the 0.1, 0.3, 0.5, 0.7, and 0.9 quantiles.
    An O-form model without moderation reveals a decreasing trend in                  Table 7 displays a decreasing trend while maintaining a positive rela­
the coefficients of LPRO, which are significant across OECD members                   tionship between LTEE and LTRA. The favourable ecological impact of
with low, medium, and high eco-efficiency. In contrast, the coefficients              energy transition can be attributed to its role in reducing the harmful
of LPRO2 are significantly positive at varying quantiles of overall eco-              pollutants emitted by fossil fuels as economies shift from non-renewable
efficiency, demonstrating an increasing trend. Similarly, an O-form                   to green energy sources. With stricter environmental regulations, eco-
model with moderation indicates a significantly negative relationship                 unfriendly businesses are incentivized to adopt eco-friendly in­
between LPRO and LTEE, while the coefficient of LPRO2 is positive and                 novations. Furthermore, energy transition encourages nations to ach­
significant. These coefficients substantiate a concave upward relation­               ieve energy efficiency, thus supporting reductions in industrial
ship between overall eco-efficiency and extraordinary economic                        greenhouse gas emissions (Bergougui, 2024b).
potential.                                                                                These findings align with Jiang et al. (2022), who concluded that a
    These findings reveal that extraordinary economic potential nega­                 swift transition to clean energy effectively reduces pollutants and im­
tively impacts overall eco-efficiency during early growth stages due to               proves eco-efficiency. Similarly, Bergougui (2024b), Bergougui et al.
composition and scale effects. However, as growth progresses, LPRO                    (2024), Bergougui (2024c), and Ullah et al. (2023b) highlighted that
fosters improvements in overall eco-efficiency due to the technique ef­               investments in renewable energy technologies bolster ecological sus­
fect. Extraordinary economic potential plays a pivotal role in overall                tainability in developed nations. Yadav et al. (2023) further underscored
eco-efficiency through its connection with natural resources. In align­               the environmental benefits of energy transition in mitigating anthro­
ment with Sustainable Development Goal (SDG) 12, PRO must be                          pogenic emissions and advancing climate change mitigation efforts.
decoupled from overexploitation and overuse of natural resources to                   Akpanke et al. (2024) found that renewable energy transformation
address ecological degradation.                                                       fosters sustainable structural development and alleviates ecological
    S-form models, with and without moderation, further support a U-                  stress. Akram et al. (2023) also reported that renewable energy plays a
type relationship between extraordinary economic potential and ser­                   pivotal role in replacing dirty energy sources, reducing the dominance of
vices eco-efficiency. This result aligns with findings from Madaleno et al.


Table 7
Feedback on elasticity coefficients (ESDK and MACS, LTEE and LSEE- response variables).
  Model                  Var./Quat.          ESDK                    0.1                 0.3                 0.5                 0.7                      0.9

  Model 1                   LPRO              − 9.414a               − 7.361a            − 8.429a            − 9.180a            − 10.232a                − 11.661a
                           LPRO2               0.471a                 0.369a              0.422a              0.459a               0.511a                    0.582a
                            LTRA               0.095b                 0.112a              0.103a              0.097a               0.088a                    0.076c
                            LETG               0.081a                 0.094a              0.087a              0.083a               0.076a                   0.067b
                             LRD               0.266a                  0.189              0.229a              0.258a               0.297a                   0.351b
                           LEUM               − 0.055a               − 0.077a            − 0.066a            − 0.058a             − 0.046a                  − 0.031
                            LTRD               0.182a                 0.213a              0.197a              0.186a               0.170a                    0.148c
  Model 2                   LPRO             − 10.056a               − 8.267a            − 9.174a            − 9.867a            − 10.851a                − 12.047a
                           LPRO2               0.495a                 0.404a              0.450a              0.485a               0.535a                    0.595a
                            LTRA               0.113b                 0.114a              0.114a              0.113a               0.113a                   0.112b
                            LETG               0.119a                 0.145a              0.132a              0.121a               0.107a                   0.089b
                             LRD               0.327a                 0.301b              0.314a              0.325a               0.339a                    0.357c
                           LEUM               − 0.058a               − 0.074a            − 0.066a            − 0.060a             − 0.051a                 − 0.040c
                            LTRD               0.185a                 0.204a              0.194a              0.187a               0.177a                    0.164c
  Model 3                   LPRO              − 9.414a               − 7.361a            − 8.429a            − 9.180a            − 10.232a                − 11.661a
                           LPRO2               0.471a                 0.369a              0.422a              0.459a               0.511a                    0.582a
                            LTRA               0.095a                 0.112a              0.103a              0.097a               0.088a                    0.076c
                            LMod               0.081a                 0.094a              0.087a              0.083a               0.076a                   0.067b
                             LRD               0.266a                  0.189              0.229a              0.258a               0.297a                   0.351b
                           LEUM               − 0.136a               − 0.171a            − 0.153a            − 0.140a             − 0.122a                 − 0.098a
                            LTRD               0.182a                 0.213a              0.197a              0.186a               0.170a                    0.148c
  Model 4                   LPRO             − 10.056a               − 8.267a            − 9.174a            − 9.867a            − 10.851a                − 12.047a
                           LPRO2               0.495a                 0.404a              0.450a              0.485a               0.535a                    0.595a
                            LTRA               0.113a                 0.114a              0.114a              0.113a               0.113a                   0.112b
                            LMod               0.119a                 0.145a              0.132a              0.121a               0.107a                   0.089b
                             LRD               0.327a                 0.301b              0.314a              0.325a               0.339a                    0.357c
                           LEUM               − 0.177a               − 0.220a            − 0.198a            − 0.182a             − 0.158a                 − 0.130a
                            LTRD               0.185a                 0.204a              0.194a              0.187a               0.177a                    0.164c

Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %; Mod = ETG*EUM; Quantiles (0.1–0.9).

                                                                                 12
B. Bergougui and E. Satrovic                                                                                              Ecological Informatics 87 (2025) 103093




                                         Fig. 2. Synopsis of MACS outcomes (LTEE and LSEE- response variables).


oil, coal, and natural gas in the global energy mix.                             discouraging resource-intensive economic activities. This divergence
    The S-form models, with and without moderation, corroborate the O-           highlights the complexity of the relationship between governance and
form model findings, confirming that energy transition improvements              eco-efficiency, warranting a closer examination of the contextual factors
act as an effective strategy to enhance the eco-efficiency of OECD               and underlying mechanisms. Danish and Ulucak (2023) explored the
members.                                                                         interactions between natural resource rents, economic growth, and
                                                                                 environmental technologies in the United States, highlighting that
4.2.3. Environmental governance and eco-efficiency                               stringent environmental policies could raise production costs, thereby
    The coefficient of environmental governance is both positive and             creating economic trade-offs for industries heavily reliant on natural
significant, with a decreasing trend in the O-form model without                 resource extraction. These findings suggest that the costs of transitioning
moderation, indicating that effective environmental governance im­               to environmentally sustainable practices might outweigh the perceived
proves overall eco-efficiency. Policymakers achieve this by imposing             benefits in the short term, particularly in economies with high resource
stringent environmental regulations to curb eco-unfriendly behavior              dependency. Increased costs could arise from compliance with stricter
among individuals and businesses. For instance, “stick” policy measures,         regulations, investments in cleaner technologies, or shifts in production
such as higher taxes on ecological damages, increase the costs of harmful        processes, all of which may reduce immediate economic efficiency.
practices. Consequently, environmental governance is a critical tool in          However, such short-term trade-offs do not necessarily negate the long-
managing eco-intensity to achieve OECD eco-efficiency objectives.                term benefits of environmental governance. As evidenced in this study,
    Effective ecological governance addresses the adverse environmental          the positive impacts of ETG on overall and services-related eco-effi­
impacts of economic activities by stimulating research and development           ciency (especially in the S-form model without moderation) may reflect
subsidies for green innovations. Its ultimate aim is to mitigate the             the ability of well-designed governance frameworks to align economic
environmental side effects of economic processes by promoting clean              incentives with environmental objectives over time. By fostering inno­
energy transition, sustainable resource extraction, and conservation             vation and promoting sustainable practices, these policies can reduce
practices. Since markets alone may not resolve rising ecological pres­           the environmental footprint of economic activities and enhance eco-
sures, governments play a crucial role in enhancing the eco-efficiency of        efficiency in the long run.
OECD members.                                                                        The divergence between this study’s findings and those of Danish
    Xie et al. (2023) provided similar evidence, demonstrating that              and Ulucak (2023) can be attributed to several contextual and meth­
environmental governance effectively reduces pollutant emissions in              odological factors. First, the differences in geographical and economic
OECD countries. Ullah et al. (2023a) emphasized the role of governance           contexts play a significant role; while Danish and Ulucak (2023) focus
in fostering ecological sustainability by supporting clean energy tran­          on the United States—a resource-rich, high-income country—this study
sitions. Similarly, Borowiec and Papież (2024) found that environmental         examines OECD members with varying levels of eco-efficiency and
governance is pivotal in addressing ecological deterioration. Zou and            governance structures, which can lead to differing outcomes. Second,
Wang (2024) highlighted that governance spurs ecological and eco­                the design and implementation of environmental policies matter
nomic improvements in firms via innovation and renewable energy                  significantly. Policies that impose strict regulations without offering
adoption.                                                                        incentives, such as subsidies or tax credits for adopting cleaner tech­
    While these results are consistent with many prior studies, they             nologies, may increase production costs and discourage compliance, as
diverge from Danish and Ulucak (2023), who argue that environmen­                observed in Danish and Ulucak (2023). Conversely, well-balanced pol­
tally friendly policies may increase production costs, potentially               icies that align economic incentives with environmental goals tend to

                                                                            13
B. Bergougui and E. Satrovic                                                                                               Ecological Informatics 87 (2025) 103093


enhance eco-efficiency. Third, the temporal dimension is critical; Danish         highlighted the destructive ecological impact of trade in the European
and Ulucak (2023) highlight short-term trade-offs associated with                 Union, where increased industrial activities fueled by trade exacerbate
governance, whereas this study may capture long-term benefits,                    ecological pressures. Both S-form models confirm the critical role of
including enhanced resource efficiency and innovation. Lastly, sectoral           trade in achieving service-related eco-efficiency goals for OECD
dynamics contribute to the discrepancies, as the S-form model in this             members.
study shows that service sectors, being less resource-intensive, adapt
more easily to governance policies compared to heavy industries, which            4.2.6. Excess use of natural resources (EUM) and eco-efficiency
may face higher transition costs. These factors collectively highlight the            The excess use of natural resources (EUM) hinders the achievement
need for tailored and context-sensitive environmental governance                  of overall and service-related eco-efficiency in OECD members, as evi­
strategies.                                                                       denced by the negative and statistically significant coefficients of LEUM
                                                                                  in models without moderation. The coefficients of EUM on total eco-
4.2.4. Research and development (R&D) intensity and eco-efficiency                efficiency (TEE) rise from − 0.077 % in the 10th quantile to − 0.031 %
    Research and development (R&D) intensity positively influences                in the 90th quantile. For service eco-efficiency (SEE), the coefficients
overall eco-efficiency in both O-form models, with and without                    increase from − 0.074 % to − 0.040 % over the same quantiles.
moderation. Table 7 and Fig. 2 show statistically significant and positive            These results align with Fang et al. (2024), who emphasized that
coefficients of R&D intensity across the 10th to 90th quantiles, revealing        over-reliance on natural resources contributes to ecological degradation.
an increasing trend of influence from lower to higher quantiles. This             Danish and Ulucak, 2023 and Ni et al. (2022) reported similar findings,
demonstrates that as countries improve their eco-efficiency levels, the           showing that lax environmental regulations, innovation deficits, and
contribution of R&D becomes increasingly impactful.                               unstable resource prices exacerbate environmental deterioration.
    The eco-efficiency benefits of R&D stem from its ability to drive             However, studies such as Ullah et al. (2023a) and Khan et al. (2023)
innovation, helping industries adopt cleaner production methods,                  suggested that natural resource rents could be utilized to protect the
reduce waste, and conserve energy. R&D also encourages the develop­               environment in economically stable countries.
ment of new materials and technologies that reduce dependency on
scarce resources. For example, Akram et al. (2023) demonstrated that              4.2.7. Joint impact of ETG and EUM on eco-efficiency
innovation is a viable means of addressing ecological challenges, such as             The interaction term of environmental governance (ETG) and
greenhouse gas emissions and the overexploitation of natural resources.           excessive natural resource use (EUM) reveals a positive and significant
Ullah et al. (2023b) further emphasized that innovation fosters cleaner           impact on overall and service-related eco-efficiency across all quantiles
energy transitions, supporting ecological sustainability. Similarly, Sha­         in both O-form and S-form models with moderation. The positive coef­
hid et al. (2024) highlighted that R&D has been pivotal in meeting                ficient suggests that robust environmental governance plays a crucial
China’s eco-efficiency targets, especially in renewable energy                    role in mitigating the negative ecological consequences associated with
technologies.                                                                     excessive natural resource use. This effect is particularly evident in
    In OECD countries, R&D initiatives have yielded notable eco-                  countries with lower levels of eco-efficiency, where governance mech­
efficiency improvements. For instance, Denmark’s investment in wind               anisms are vital to promoting sustainability.
energy R&D has positioned it as a global leader in renewable energy                   Environmental governance appears to enhance natural resource ef­
technologies. Germany’s “Energiewende” policy, underpinned by sub­                ficiency by enforcing policies and measures that curb overexploitation.
stantial R&D in solar and wind energy, has significantly reduced its              For instance, stringent regulations, such as carbon taxes, subsidies for
energy-related emissions. In the service sector, Sweden’s advancements            cleaner technologies, and incentives for resource-efficient practices,
in smart grid technologies and digital innovations have enhanced energy           could limit excessive resource extraction and encourage the adoption of
efficiency and resource utilization. These examples demonstrate the               sustainable alternatives. These mechanisms create a regulatory frame­
critical role of targeted R&D investments in addressing specific ecolog­          work that aligns economic activities with environmental goals, fostering
ical challenges and achieving eco-efficiency gains.                               eco-efficiency across sectors.
    The S-form models, with and without moderation, confirm these                     Previous studies align with these findings. For example, Ali et al.
findings, showing that R&D intensity reduces service-related eco-in­              (2022a) identified the moderating effects of environmental governance
tensity and enhances the eco-efficiency of OECD members. Service in­              in reducing ecological footprints, emphasizing its role in promoting
dustries, being less resource-intensive, often benefit more directly from         sustainable resource management. Similarly, Ullah et al. (2023b)
innovations in digitalization, logistics, and energy-efficient infrastruc­        demonstrated that stringent governance policies effectively limit the
ture. Policymakers can draw on these successful examples to prioritize            detrimental effects of resource overuse, highlighting the importance of
R&D funding and design policies that incentivize innovation tailored to           regulatory measures in achieving long-term environmental
both industrial and service sectors, thereby achieving long-term                  sustainability.
ecological sustainability.                                                            Moreover, the joint moderating effects underscore the significance of
                                                                                  integrating environmental governance with natural resource policies.
4.2.5. International trade and eco-efficiency                                     Countries with higher eco-efficiency levels may already benefit from
    Table 7 and Fig. 2 demonstrate that international trade, measured as          advanced governance frameworks, but the findings indicate that even in
a percentage of GDP, positively impacts overall eco-efficiency in the O-          resource-intensive economies, adopting stringent governance mecha­
form model without moderation. The findings indicate a significant and            nisms can facilitate the transition towards more sustainable practices. As
positive relationship between trade and eco-efficiency across quantiles,          outlined by SDG-12, ensuring sustainable production and consumption
though the effect decreases from lower to upper quantiles. Trade (% of            patterns requires targeted interventions, including regulatory oversight
GDP) reduces ecological intensity in OECD members, particularly in                and market-based incentives, to optimize resource use and reduce
countries with lower eco-efficiency levels.                                       environmental impacts.
    Dai and Du (2023) provided similar findings, showing that interna­                Finally, Table 8 provides a concise summary of all the key results,
tional trade enhances ecological sustainability when stringent environ­           consolidating the insights from both O-form and S-form models, and
mental policies are in place. Cheng et al. (2022) advocated that trade            highlighting the intricate relationships between extraordinary economic
facilitates a shift towards clean energy and sustainable resource utili­          potential, eco-efficiency, and their moderating factors.
zation. Ahmad and Satrovic (2023) observed that trade improves envi­
ronmental sustainability within the Group of Seven (G7) nations.
    However, contrasting evidence from Ahmad and Jabeen (2024)

                                                                             14
B. Bergougui and E. Satrovic                                                                                                             Ecological Informatics 87 (2025) 103093


Table 8                                                                                         builds upon the Driscoll-Kraay (ESDK) econometric technique. As seen
Summary of key trends.                                                                          in Tables 7 and A1, the O-form and S-form models without moderation
  Variable                     Impact on Eco-       Key Insight                                 suggest statistically significant and positive nexus amid energy transi­
                               Efficiency                                                       tion, research and development intensity, the economic importance of
  Extraordinary                Concave upward       Early stages: negative impact; later        international trade and environmental governance foster the overall and
    Economic Potential         (O-form), U-shaped   stages: positive impact due to              services eco-efficiency of OECD nations. Notably, a 1 % increase in en­
    (PRO)                      (S-form)             technique effect.                           ergy transition, matters for the rise of eco-efficiency by 0.095 % (Models
                                                    Shift to renewable energy reduces           1&3), 0.113 % (Models 2&4), 0.105 % (Models 5&7) and 0.118 %
  Energy Transition            Positive and
                                                    emissions and promotes eco-
    (LTRA)                     significant
                                                    friendly innovations.
                                                                                                (Models 6&8), respectively. The coefficient of ETG advocated that a 1 %
                                                    Stringent policies and green                rise of environmental governance, results in a 0.081 % (Model 1), 0.119
  Environmental                Positive and
                                                    innovation mitigate ecological              % (Model 2), 0.054 % (Model 5) and 0.083 % (Model 6) rise in eco-
    Governance (ETG)           significant
                                                    pressures.                                  efficiency in models without moderation. Given the coefficients of
                                                    Innovation drives waste
                                                                                                EUM, excess use of natural resources is responsible for the impediment
                               Positive and         management and energy
  RD Intensity
                               significant          conservation, enhancing eco-                of OECD’s eco-efficiency such that a 1 % rise in EUM reduces TEE and
                                                    efficiency.                                 SEE by 0.055 % (Model 1), 0.058 % (Model 2), 0.136 % (Model 3),
                               Positive and
                                                    Trade promotes sustainability               0.177 % (Model 4), 0.033 % (Model 5), 0.034 % (Model 6), 0.087 %
  International Trade                               when coupled with strong                    (Model 7), and 0.117 % (Model 8) respectively. The outcomes of
                               significant
                                                    environmental policies.
                                                    Over-reliance on natural resources
                                                                                                research and development intensity showed that RD matters for
  Excess Use of Natural        Negative and                                                     ecological betterment of OECD members. In the same vein, both proxies
                                                    exacerbates ecological
    Resources (EUM)            significant
                                                    degradation.                                for the economic importance of international trade insinuate the bene­
                               Positive and
                                                    Environmental governance                    ficial ecological impact of international trade in the context of OECD
  ETG-EUM Interaction                               mitigates the adverse effects of
                               significant                                                      nations. The models with moderation advocated that EUM matters for
                                                    excess natural resource use.
                                                                                                the improvement of overall and services eco-efficiency through the
                                                                                                ecological governance channel. The twin robustness check, based on the
4.3. Sensitivity analysis                                                                       supplementary regressor (Table A1 and Fig. A1) and alternative
                                                                                                econometric technique (Tables 7 and A1), render the support for our
4.3.1. Supplementary proxy: Import diversification index                                        main findings (Tables 7 and A1). Hence, it can be deduced that our main
    The sensitivity analysis of our main findings is grounded on the                            findings are plausible to develop policy implications for eco-efficient
deliberation of supplementary proxy for the economic importance of                              future of OECD members.
international trade namely, import diversification index in Table A1 and
Fig. A1. The O-form and S-form models without moderation reach the                              5. Conclusion, policy implications, limitations and
conclusion that energy transition, research and development intensity,                          recommendations for future research
and environmental governance matter in achieving the eco-efficiency
targets of OECD members. Our outcomes propose the U-type associa­                               5.1. Conclusion
tion between extraordinary economic potential and eco-efficiency such
that PRO facilitates the eco-intensity in the early stages of growth while                          This study contributes to the existing literature by examining the
it results in the improvements of eco-efficiency in the later stages. In line                   relationship between the excess use of natural resources, environmental
with our main findings, import diversification index encourages the eco-                        governance, and eco-efficiency in developed economies. Specifically, it
efficiency of the inspected sample. An explanation is that developed                            addresses a critical gap in the current research by investigating the po­
countries may accelerate the imports of dirty products to reduce                                tential mitigating effects of effective ETG on the ecological pressures
emission-intensive industries and energy-related anthropogenic emis­                            exerted by excess natural resource consumption. Employing MACS, this
sions. As such, import diversification takes a prominent role in tackling                       research analyzed data from nine OECD countries over the period
the environmental pressure of OECD members as proposed by (Doğan                               1997–2020. The findings reveal a nuanced relationship between
et al., 2022). In the same fashion, Madaleno et al. (2023) advocated the                        extraordinary economic potential (PRO) and eco-efficiency, character­
outcome that import eases the access to intermediate items which are                            ized by a concave upward pattern. Moreover, the study provides
responsible for ecological sustainability if harmonized with environ­                           empirical evidence that energy transition, ETG, research and develop­
mental regulations. The O-form and S-form models with moderation                                ment intensity, and the economic importance of international trade
express a positive and statistically significant coefficient of interaction                     positively influence eco-efficiency in the studied countries. Conversely,
terms, rendering the overall and services eco-efficiency enhancement                            EUM was found to negatively impact eco-efficiency, exacerbating
effect of EUM via the channel of environmental governance.                                      ecological pressures. Notably, the research demonstrates that ETG acts
    Despite that the investigated OECD members are among the most                               as a positive moderator on the relationship between EUM and eco-
industrialized countries globally, the present study fails to assess the                        efficiency, with this effect being more pronounced in less eco-efficient
impacts of various independent variables on the industrial eco-efficiency                       nations. The robustness of these results is confirmed through alterna­
in addition to service- and total eco-efficiency. This is due to the missing                    tive eco-efficiency measures (e.g., services eco-efficiency), an additional
values in industry (including construction), value added time-series for                        proxy for trade (import diversification index - DI), and alternative
the United States. It would be of vital importance to delve into the im­                        econometric methods. These findings underscore the importance of
pacts of independent variables on industrial eco-efficiency as boosted                          implementing robust environmental policies in OECD countries to pro­
industry encouraged by international trade lifts up the consumption of                          mote sustainable resource extraction and improve eco-efficiency.
materials from nature, and posits an adverse ecological impact. The
analysis of the determinants of industry eco-efficiency is outstandingly                        5.2. Policy implications
prominent as industry sector may exhibit the moderation impact of
environmental governance interaction with EUM dissimilar to the ser­                                The findings of this study, coupled with external data, underscore the
vice sector and provide a foundation for plausible policy directions.                           critical need for comprehensive environmental policies in OECD coun­
                                                                                                tries to enhance eco-efficiency while managing natural resource use.
4.3.2. Alternative econometric technique: Driscoll-Kraay (ESDK)                                 Accelerating energy transition should be a priority, as renewable energy
   Finally, to authenticate the findings of MACS estimator, this study                          sources have shown significant growth potential. According to the

                                                                                           15
B. Bergougui and E. Satrovic                                                                                                Ecological Informatics 87 (2025) 103093


International Energy Agency (IEA), renewable energy capacity additions             measures. Secondly, the impact of diverse national characteristics on
in OECD countries increased by 13 % in 2021, reaching almost 160 GW.               eco-efficiency, such as demographics, climate conditions, population
This trend aligns with our finding that energy transition positively im­           density, urbanization rates, and industrialization levels, warrants
pacts eco-efficiency. Environmental governance must be strengthened,               further investigation. These factors could reveal important contextual
considering that OECD countries collectively account for approximately             moderators of the main effects found in this study. Additionally, while
40 % of global CO2 emissions (WB, 2023). Our study shows that                      the research touched on energy transition, it could benefit from more
improved environmental governance positively moderates the impact of               explicit integration with other pressing global challenges like population
excess resource use on eco-efficiency, especially in less eco-efficient            growth, global warming, and economic development, providing a more
nations. Investment in research and development is crucial. OECD                   holistic view of eco-efficiency within sustainable development contexts.
data indicates that average R&D intensity (gross domestic expenditure              The study’s timeframe (1997–2020) may not capture very long-term
on R&D as a percentage of GDP) across OECD countries was 2.68 % in                 trends or recent developments, suggesting a need for longer longitudi­
2021. Countries should aim to meet or exceed this average, given our               nal studies and comparative analyses between OECD and non-OECD
finding that R&D intensity advances eco-efficiency. Policymakers                   countries. Future research should also evaluate the effectiveness of
should also consider the role of international trade in eco-efficiency. The        implemented environmental policies on eco-efficiency, potentially using
OECD reports that its members accounted for 61 % of global trade in                quasi-experimental designs. Sector-specific eco-efficiency dynamics and
2022. Trade policies should be crafted with environmental consider­                the role of specific technological innovations (e.g., AI, blockchain) in
ations in mind, potentially including eco-efficiency standards in trade            enhancing eco-efficiency are areas ripe for further exploration. Lastly,
agreements. Sustainable resource management is imperative, as the                  incorporating circular economy principles more fully into the eco-
global material footprint per capita in high-income countries was 26.3             efficiency framework and developing metrics that capture circularity
metric tons in 2019 (UN SDG Report 2022), far exceeding sustainable                alongside efficiency could provide valuable new perspectives. By
levels. Our study shows that excess use of natural resources negatively            addressing these limitations and pursuing these research directions,
impacts eco-efficiency, highlighting the need for waste-free extraction            future studies can build upon the current findings to offer a more
policies and circular economy approaches. To achieve long-term im­                 comprehensive understanding of eco-efficiency dynamics in developed
provements in eco-efficiency, policymakers should ensure policy con­               economies, crucial for informing evidence-based policies aimed at
sistency, foster international cooperation, and implement robust                   achieving sustainable development goals while effectively managing
monitoring systems. The OECD Better Life Index shows that 69 % of                  natural resource use.
people in OECD countries trust their national government, suggesting a
strong foundation for implementing these evidence-based policy rec­                CRediT authorship contribution statement
ommendations. By adopting these measures, OECD countries can make
significant strides towards balancing economic growth with ecological                  Brahim Bergougui: Writing – review & editing, Writing – original
sustainability, contributing to the achievement of the Sustainable                 draft, Visualization, Validation, Supervision, Formal analysis, Concep­
Development Goals (SDGs).                                                          tualization. Elma Satrovic: Writing – review & editing, Writing –
                                                                                   original draft, Visualization, Validation, Software, Methodology,
5.3. Limitations and recommendations for future research                           Investigation.

   This study, while providing valuable insights into eco-efficiency in
OECD countries, has several limitations that future research should                Declaration of competing interest
address. Firstly, the focus on specific variables may have overlooked
nuances in energy intensity and economic complexity types. Future                      The authors declare that they have no known competing financial
studies should explore various energy intensity metrics and economic               interests or personal relationships that could have appeared to influence
complexity indices to test the consistency of results across different             the work reported in this paper.



Appendix A. Appendix



Table A1
Feedback on robustness inspection (ESDK and MACS, LTEE and LSEE- response variables).

  Model                   Var./Quat        ESDK                 0.1                    0.3                 0.5                  0.7                       0.9

                                LPRO       − 7.989a             − 7.121a               − 7.638a            − 8.008a             − 8.326a                  − 8.937a
                               LPRO2        0.409a               0.365a                 0.391a              0.410a               0.426a                     0.457a
                                LTRA        0.105a               0.114a                 0.109a              0.105a               0.102a                    0.096b
  Model 5                       LETG        0.054a               0.056c                 0.055a              0.054a               0.054a                     0.052
                                 LRD        0.268a               0.279b                 0.272a              0.268a               0.264a                     0.256c
                               LEUM        − 0.033a             − 0.046a               − 0.038a            − 0.032a             − 0.027b                   − 0.017
                                 LDI        0.223a               0.257b                 0.237a              0.222a               0.210a                     0.186
                                LPRO       − 7.998a             − 6.980b               − 6.980b            − 7.943a             − 8.465a                  − 9.155a
                               LPRO2        0.404a               0.351b                 0.351b              0.401a               0.428a                     0.463a
                                LTRA        0.118a               0.109a                 0.109a              0.118a               0.122a                    0.128b
  Model 6                       LETG        0.083a               0.098a                 0.098a              0.084a               0.076a                     0.065
                                 LRD        0.337a               0.381b                 0.381b              0.340a               0.317a                     0.288
                               LEUM        − 0.034a             − 0.045b               − 0.045b            − 0.035a             − 0.029b                   − 0.021
                                 LDI        0.305a               0.336a                 0.336a              0.307a               0.291a                     0.270c
                                LPRO       − 7.989a             − 7.121a               − 7.638a            − 8.008a             − 8.326a                  − 8.937a
  Model 7                      LPRO2        0.409a               0.365a                 0.391a              0.410a               0.426a                     0.457a
                                LTRA        0.105a               0.114a                 0.109a              0.105a               0.102a                    0.096b
                                                                                                                                           (continued on next page)


                                                                              16
B. Bergougui and E. Satrovic                                                                                                                       Ecological Informatics 87 (2025) 103093

Table A1 (continued )
  Model                   Var./Quat                 ESDK                   0.1                       0.3                      0.5                       0.7                      0.9

                                LMod                 0.054a                 0.056c                    0.055a                   0.054a                    0.054a                    0.052
                                 LRD                 0.268a                 0.279b                    0.272a                   0.268a                    0.264a                   0.256c
                               LEUM                 − 0.087a               − 0.103a                  − 0.093a                 − 0.086a                  − 0.081a                 − 0.069c
                                 LDI                 0.223a                 0.257b                    0.237a                   0.222a                    0.210a                    0.186
                                LPRO                − 7.998a               − 6.980b                  − 7.544a                 − 7.943a                  − 8.465a                 − 9.155a
                               LPRO2                 0.404a                 0.351b                    0.380a                   0.401a                    0.428a                   0.463a
                                LTRA                 0.118a                 0.109a                    0.114a                   0.118a                    0.122a                   0.128b
  Model 8                       LMod                 0.083a                 0.098a                    0.090a                   0.084a                    0.076a                    0.065
                                 LRD                 0.337a                 0.381b                    0.357a                   0.340a                    0.317a                    0.288
                               LEUM                 − 0.117a               − 0.144a                  − 0.129a                 − 0.118a                  − 0.104a                 − 0.086c
                                 LDI                 0.305a                 0.336a                    0.319a                   0.307a                    0.291a                   0.270c
Note: p values underlined, a – p < 1 %; b – p < 5 %; c – p < 10 %; Mod = ETG*EUM; Quantiles (0.1–0.9).




                                       Fig. A1. Synopsis of MACS outcomes – robustness inspection (LTEE and LSEE- response variables).




Data availability                                                                               Akpanke, T.A., Deka, A., Ozdeser, H., Seraj, M., 2024. Ecological footprint in the OECD
                                                                                                     countries: do energy efficiency and renewable energy matter? Environ. Sci. Pollut.
                                                                                                     Res. 31 (10), 15289–15301. https://doi.org/10.1007/s11356-024-32151-1.
   The Stata code and datasets utilized in this study can be accessed                           Akram, R., Ibrahim, R.L., Wang, Z., Adebayo, T.S., Irfan, M., 2023. Neutralizing the
through the GitHub repository maintained by Brahim Bergougui,                                        surging emissions amidst natural resource dependence, eco-innovation, and green
                                                                                                     energy in G7 countries: insights for global environmental sustainability. J. Environ.
located at https://github.com/BrahimBergougui/data-and-code
                                                                                                     Manag. 344, 118560. https://doi.org/10.1016/j.jenvman.2023.118560.
                                                                                                Alfalih, A.A., Hadj, T.B., 2022. Financialization, natural resources rents and
References                                                                                           environmental sustainability dynamics in Saudi Arabia under high and low regimes.
                                                                                                     Res. Pol. https://doi.org/10.1016/j.resourpol.2022.102593.
                                                                                                Ali, K., Jianguo, D., Kirikkaleli, D., 2022a. Modeling the natural resources and financial
Ahmad, A., Jabeen, G., 2024. Relating economic openness and export diversification to
                                                                                                     inclusion on ecological footprint: the role of economic governance institutions.
   eco-efficiency: is green innovation critical? Int. J. Financ. Econ. https://doi.org/
                                                                                                     Evidence from ECOWAS economies. Res. Pol. 79, 103115. https://doi.org/10.1016/
   10.1002/ijfe.2825.
                                                                                                     j.resourpol.2022.103115.
Ahmad, M., Satrovic, E., 2023. How does monetary policy moderate the influence of
                                                                                                Ali, M., Kirikkaleli, D., Sharma, R., Altuntaş, M., 2022b. The nexus between remittances,
   economic complexity and technological innovation on environmental sustainability?
                                                                                                     natural resources, technological innovation, economic growth, and environmental
   The role of green central banking. Int. J. Financ. Econ. 1–28. https://doi.org/
                                                                                                     sustainability in Pakistan. Environ. Sci. Pollut. Res. 29. https://doi.org/10.1007/
   10.1002/ijfe.2872.
                                                                                                     s11356-022-21228-4.
Ahmad, M., Satrovic, E., 2024. Modeling natural resources for ecological sustainability.
                                                                                                Apostu, S.A. Valentina, Vasile, Mirela Panait, Sava, Valentin, 2023. Exploring the
   Gondwana Res. 126 (February 2024), 243–266. https://doi.org/10.1016/j.
                                                                                                     ecological efficiency as the path to resilience. Econ. Res. Ekonomska Istraživanja 36,
   gr.2023.09.015.
                                                                                                     2. https://doi.org/10.1080/1331677X.2022.2108476.
Ahmad, M., Jiang, P., Majeed, A., Umar, M., Khan, Z., Muhammad, S., 2020. The
                                                                                                Arjun, Mishra, B.R., 2024. Asymmetric role of environmental policy stringency,fiscal,
   dynamic impact of natural resources, technological innovations and economic
                                                                                                     and monetary policy on environmental sustainability: evidence from BRICS-T
   growth on ecological footprint: an advanced panel data estimation. Res. Policy 69,
                                                                                                     countries. Nat. Res. Forum 1–32. https://doi.org/10.1111/1477-8947.12434.
   101817. https://doi.org/10.1016/j.resourpol.2020.101817.
                                                                                                Bergougui, B., 2024a. Algeria’s pathway to COP28 and SDGs: asymmetric impact of
Ahmed, K., 2020. Environmental policy stringency, related technological change and
                                                                                                     environmental technology, energy productivity, and material resource efficiency on
   emissions inventory in 20 OECD countries. J. Environ. Manag. 274. https://doi.org/
                                                                                                     environmental sustainability. Energ. Strat. Rev. 55, 101541. https://doi.org/
   10.1016/j.jenvman.2020.111209.
                                                                                                     10.1016/j.esr.2024.101541.



                                                                                           17
B. Bergougui and E. Satrovic                                                                                                                            Ecological Informatics 87 (2025) 103093

Bergougui, B., 2024b. Investigating the relationships among green technologies,                     He, Y., Li, X., Huang, P., Wang, J., 2022. Exploring the road toward environmental
    financial development and ecological footprint levels in Algeria: evidence from a                    sustainability: natural resources, renewable energy consumption, economic growth,
    novel fourier ARDL approach. Sustain. Cities Soc. 112, 105621. https://doi.org/                      and greenhouse gas emissions. Sustainability 14. https://doi.org/10.3390/
    10.1016/j.scs.2024.105621.                                                                           su14031579.
Bergougui, B., 2024c. Moving toward environmental mitigation in Algeria: asymmetric                 Hickel, J., O’Neill, D.W., Fanning, A.L., H., 2022. Zoomkawala national responsibility for
    impact of fossil fuel energy, renewable energy and technological innovation on CO2                   ecological breakdown: a fair-shares assessment of resource use, 1970–2017. Lancet
    emissions. Energ. Strat. Rev. 51, 101281. https://doi.org/10.1016/j.                                 Planet Health 6, e342–e349. https://doi.org/10.1016/S2542-5196(22)00044-4.
    esr.2023.101281.                                                                                Hille, E., Möbius, P., 2019. Environmental policy, innovation, and productivity growth:
Bergougui, B., Aldawsari, M.I., 2024. Asymmetric impact of patents on green                              controlling the effects of regulation and endogeneity. Environ. Resour. Econ. 73.
    technologies on Algeria’s ecological future. J. Environ. Manag. 355, 120426.                         https://doi.org/10.1007/s10640-018-0300-6.
    https://doi.org/10.1016/j.jenvman.2024.120426.                                                  Jiang, S., Mentel, G., Shahzadi, I., Jebli, M.B., Iqbal, N., 2022. Renewable energy, trade
Bergougui, B., Meziane, S., 2025. Assessing the impact of green energy transition,                       diversification and environmental footprints: evidence for Asia-Pacific economic
    technological innovation, and natural resources on load capacity factor in Algeria:                  cooperation (APEC). Renew Energy 187, 874–886. https://doi.org/10.1016/j.
    evidence from dynamic autoregressive distributed lag simulations and machine                         renene.2021.12.134.
    learning validation. Sustainability 17 (5), 1815. https://doi.org/10.3390/                      Johnstone, N., Hascic, I., Poirier, J., Hemar, M., Michel, C., 2012. Environmental policy
    su17051815.                                                                                          stringency and technological innovation: evidence from survey data and patent
Bergougui, B., Murshed, S.M., 2020. New evidence on the oil-democracy nexus utilising                    counts. Appl. Econ. 44. https://doi.org/10.1080/00036846.2011.560110.
    the varieties of democracy data. Res. Policy 69, 101905. https://doi.org/10.1016/j.             Khan, Y., Hassan, T., Guiqin, H., Nabi, G., 2023. Analyzing the impact of natural
    resourpol.2020.101905.                                                                               resources and rule of law on sustainable environment: a proposed policy framework
Bergougui, B., Murshed, S.M., 2021. Revisiting the oil wealth-growth nexus: the role of                  for BRICS economies. Res. Policy 86 (Part A), 104070. https://doi.org/10.1016/j.
    economic norms in avoiding the oil curse. Extr. Ind. Soc. 8 (3), 100929. https://doi.                resourpol.2023.104070.
    org/10.1016/j.exis.2021.100929.                                                                 Kongbuamai, N., Bui, Q., Yousaf, H.M.A.U., Liu, Y., 2020. The impact of tourism and
Bergougui, B., Murshed, S.M., 2023. Aggregate and disaggregate impact of natural                         natural resources on the ecological footprint: a case study of ASEAN countries.
    resources on sustainable development: new evidence from the latest institutional                     Environ. Sci. Pollut. Res. 27.
    data. Environ. Sustain. Indic. 20, 100302. https://doi.org/10.1016/j.                           Le, T.-H., Le, H.-C., Taghizadeh-Hesary, F., 2020. Does financial inclusion impact CO2
    indic.2023.100302.                                                                                   emissions? Evidence from Asia. Financ. Res. Lett. 34, 101451. https://doi.org/
Bergougui, B., Mehibel, S., Boudjana, R.H., 2024. Asymmetric nexus between green                         10.1016/j.frl.2020.101451.
    technologies, economic policy uncertainty, and environmental sustainability:                    Liu, X., Yang, J., Bilan, Y., Shahzad, U., 2023. Resources curse hypothesis and COP26
    evidence from Algeria. J. Environ. Manag. 360, 121172. https://doi.org/10.1016/j.                    target: mineral and oil resources economies COVID-19 perspective. Res. Policy 83,
    jenvman.2024.121172.                                                                                 103687. https://doi.org/10.1016/j.resourpol.2023.103687.
Bergougui, B., Murshed, S.M., Shahbaz, M., Zambrano-Monserrate, M.A., Samour, A.,                   Machado, J.A.F., Silva, J.M.C.S., 2019. Quantiles via moments. J. Econ. 213, 145–173.
    Aldawsari, M.I., 2025. Towards secure energy systems: examining asymmetric                           https://doi.org/10.1016/j.jeconom.2019.04.00.
    impact of energy transition, environmental technology and digitalization on Chinese             Madaleno, M., Ahmed, Z., Doğan, B., Javeed, S., Vasa, L., 2023. The aptness of import-led
    city-level energy security. Renew. Energy 238, 121883. https://doi.org/10.1016/j.                    growth hypothesis for sustainable development in South Asia: do energy utilization
    renene.2024.121883.                                                                                  and natural resources matter? Res. Policy 86 (Part B), 104262. https://doi.org/
Bhowmik, R., Sharif, A., Anwar, A., Syed, Q.R., Cong, P.T., Ha, N.N., 2024. Does                         10.1016/j.resourpol.2023.104262.
    environmental policy stringency alter the natural resources-emissions nexus?                    Majeed, A., Wang, L., Zhang, X., Muniba, Kirikkaleli, D., 2021. Modeling the dynamic
    Evidence from G-7 countries. Geosci. Front. https://doi.org/10.1016/j.                               links among natural resources, economic globalization, disaggregated energy
    gsf.2024.101874, 101874.                                                                             consumption, and environmental quality: fresh evidence from GCC economies. Res.
Borowiec, J., Papież, M., 2024. Convergence of CO2 emissions in countries at different                  Policy 73. https://doi.org/10.1016/j.resourpol.2021.102204.
    stages of development. Do globalisation and environmental policies matter? Energy               Mamghaderi, M., Mamkhezri, J., Khezri, M., 2023. Assessing the environmental
    Policy 184 (January 2024), 113866. https://doi.org/10.1016/j.enpol.2023.113866.                      efficiency of OECD countries through the lens of ecological footprint indices.
Chang, G., Yasin, I., Naqvi, S.M.M.A., 2024. Environmental sustainability in OECD                        J. Environ. Manag. 338, 117796. https://doi.org/10.1016/j.jenvman.2023.117796.
    nations: the moderating impact of green innovation on urbanization and green                    Musah, M., Onifade, S.T., Satrovic, E., Nkyi, J.A., 2024. Assessing the palliative aspects of
    growth. Sustainability 16 (16), 7047. https://doi.org/10.3390/su16167047.                            green innovations in the non-linear tendencies of environmental sustainability-
Chen, F., Ahmad, S., Arshad, S., Ali, S., Rizwan, M., Hamzah Saleem, M., Driha, O.M.,                    financial globalization nexus among West African states. Geosci. Front. https://doi.
    Balsalobre-Lorente, D., 2022. Towards achieving eco-efficiency in top 10 polluted                    org/10.1016/j.gsf.2024.101893, 101893.
    countries: the role of green technology and natural resource rents. Gondwana Res.               Ni, X., et al., 2022. Natural resources volatility, renewable energy, R&D resources and
    110, 114–127. https://doi.org/10.1016/j.gr.2022.06.010.                                              environment: evidence from selected developed countries. Res. Policy 77, 102655.
Cheng, H., Liu, X., Xu, Z., 2022. Impact of carbon emission trading market on regional                   https://doi.org/10.1016/j.resourpol.2022.102655.
    urbanization: an empirical study based on a difference-in-differences model. Econ.              OECD, 2008. Eco-Efficiency. OECD Publishing, Paris. https://doi.org/10.1787/
    Anal. Lett. 1. https://doi.org/10.58567/eal01010003.                                                 9789264040304-en.
Dai, S., Du, X., 2023. Discovering the role of trade diversification, natural resources, and        OECD, 2009. Natural Resources and Pro-Poor Growth. OECD. https://doi.org/10.1787/
    environmental policy stringency on ecological sustainability in the BRICST region.                   9789264060258-en.
    Res. Policy 85 (Part B), 103868. https://doi.org/10.1016/j.resourpol.2023.103868.               OECD, 2015. Material Resources, Productivity and the Environment (OECD Green
Danish, R., Ulucak, M.A., 2023. Baloch an empirical approach to the nexus between                        Growth Studies). OECD. https://doi.org/10.1787/9789264190504-en.
    natural resources and environmental pollution: do economic policy and                           OECD, 2019. Addressing Industrial Air Pollution in Kazakhstan. OECD. https://doi.org/
    environmental-related technologies make any difference? Res. Policy 81, 103361.                      10.1787/0e04ea86-en.
    https://doi.org/10.1016/j.resourpol.2023.103361.                                                OECD, 2022. Organisation for Economic Co-operation and Development: The OECD
Doğan, B., Ferraz, D., Gupta, M., Huynh, T.L.D., Shahzadi, I., 2022. Exploring the effects              Environmental Policy Stringency Index. https://stats.oecd.org/Index.aspx?DataSet
    of import diversification on energy efficiency: evidence from the OECD economies                     Code=EPS (accessed 30.8.23).
    renew. Energy 189, 639–650. https://doi.org/10.1016/j.renene.2022.03.018.                       OECD, 2023. Organisation for Economic Co-operation and Development: Gross Domestic
Doğan, B, Khalfaoui, R, Bergougui, B., Ghosh, S., 2025. Unveiling the Impact of the                     Spending on R&D (Indicator). https://doi.org/10.1787/d8b068b4-en (accessed
    digital economy on the Interplay of energy transition environmental transformation,                  30.8.23).
    and renewable energy adoption. Res. Int. Bus. Financ. 102837. https://doi.org/                  OECD, 2024. OECD Environmental Performance Reviews: Chile 2024. OECD. https://
    10.1016/j.ribaf.2025.102837.                                                                         doi.org/10.1787/5bc65d36-en.
Dong, K., Sun, R., Dong, X., 2018. CO2 emissions, natural gas and renewables, economic              Olawumi, T.O., Chan, D.W.M., 2018. A scientometric review of global research on
    growth: assessing the evidence from China. Sci. Total Environ. https://doi.org/                      sustainability and sustainable development. J. Clean. Prod. 183. https://doi.org/
    10.1016/j.scitotenv.2018.05.322.                                                                     10.1016/j.jclepro.2018.02.162.
Erdoğan, S., Çakar, N.D., Ulucak, R., Kassouri, Y., 2021. The role of natural resources            Onwe, C., Bandyopadhyay, A., Hamid, I., Rej, S., Hossain, M.E., 2023. Environment
    abundance and dependence in achieving environmental sustainability: evidence                         sustainability through energy transition and globalization in G7 countries: what role
    from resource-based economies. Sustain. Dev. 29.                                                     does environmental tax play? Renew. Energy 218, 119302. https://doi.org/
Fang, X., Khalaf, O.I., Guanglei, W., Cristia, J.F.E., Almasabi, S., 2024. Exploring impact              10.1016/j.renene.2023.119302.
    of green finance and natural resources on eco-efficiency: case of China. Sci. Rep. 14           Pesaran, M.H., 2004. General diagnostic tests for cross section dependence in panels. In:
    (1), 20153. https://doi.org/10.1038/s41598-024-70993-4.                                              Cambridge Working Papers in Economics No. 0435. University of Cambridge,
Georgatzi, V.V., Stamboulis, Y., Vestikas, A., 2020. Examining the determinants of CO2                   Faculty of Economics.
    emissions caused by the transport sector: empirical evidence from 12 European                   Pesaran, M.H., 2007. A simple panel unit root test in the presence of cross-section
    countries. Econ. Anal. Pol. 65. https://doi.org/10.1016/j.eap.2019.11.003.                           dependence. J. Appl. Econ. 22 (2), 265–312.
GFN, 2022. Global footprint network: advancing the science of sustainability [WWW                   Porter, M.E., van der Linde, C., 1995. Toward a new conception of the environment-
    document]. In: Natl. Footpr. Biocapacity Accounts. URL. https://www.footpr                           competitiveness relationship. J. Econ. Perspect. 9 (4), 97–118. https://doi.org/
    intnetwork.org/resources/data (accessed 30.7.23).                                                    10.1257/jep.9.4.97.
Grossman, G.M., Krueger, A.B., 1995. Economic growth and the environment. Q. J. Econ.               Satrovic, E., Zafar, M.W., Suntraruk, P., 2024a. Achieving ecological sustainability in
    110 (2), 353–377.                                                                                    European Union: the role of fiscal decentralization and green innovation. J. Clean.
Guo, Y., Alnafrah, I., Hou, X., 2024. How natural resources and technological                            Prod. 445, 141316. https://doi.org/10.1016/j.jclepro.2024.141316.
    advancements affect environmental quality: Evidence from load capacity factor in N-             Satrovic, E., Gyamfi, B.A., Alola, A.A., Agozie, D.Q., 2024b. Ecological security and
    11 nations. Nat. Resour. Foru. https://doi.org/10.1111/1477-8947.12442.                              agricultural production in the Arab league: is financial development moderating the


                                                                                               18
B. Bergougui and E. Satrovic                                                                                                                            Ecological Informatics 87 (2025) 103093

     interaction? J. Environ. Manag. 363, 121376. https://doi.org/10.1016/j.                           Wang, W., Rehman, M.A., Fahad, S., 2022. The dynamic influence of renewable energy,
     jenvman.2024.121376.                                                                                   trade openness, and industrialization on the sustainable environment in G-7
Satrovic, E., Cetindas, A., Akben, I., Damrah, S., 2024c. Do natural resource dependence,                   economies. Renew. Energy 198, 484–491. https://doi.org/10.1016/j.
     economic growth and transport energy consumption accelerate ecological footprint                       renene.2022.08.067.
     in the most innovative countries? The moderating role of technological innovation.                WB, 2023. World Bank: World Development Indicators [WWW Document]. URL. https://
     Gondwana Res. 127, 116–130. https://doi.org/10.1016/j.gr.2023.04.008.                                  datacatalog.worldbank.org/search/dataset/0037712 (accessed 14.7.23).
Shahid, R., Shahid, H., Shijie, L., Jian, G., 2024. Developing nexus between economic                  Westerlund, J., 2005. New simple tests for panel cointegration. Econ. Rev. 24, 297–316.
     opening-up, environmental regulations, rent of natural resources, green innovation,                    https://doi.org/10.1080/07474930500243019.
     and environmental upgrading of China - empirical analysis using ARDL bound-                       Wolde-Rufael, Y., Mulat-Weldemeskel, E., 2021. Do environmental taxes and
     testing approach. Innov. Green Dev. 3 (1), 100088. https://doi.org/10.1016/j.                          environmental stringency policies reduce CO2 emissions? Evidence from 7 emerging
     igd.2023.100088.                                                                                       economies. Environ. Sci. Pollut. Res. 28. https://doi.org/10.1007/s11356-020-
Shi, Y., Li, J., Fang, Z., Li, Y., Hu, H., Nie, W., Meng, F., 2024. Probing the role of natural             11475-8.
     resources and urbanization towards ecological sustainability in BRICST economies.                 Xiaoman, W., Majeed, A., Vasbieva, D.G., et al., 2021. Natural resources abundance,
     Res. Policy 91, 104739. https://doi.org/10.1016/j.resourpol.2024.104739.                               economic globalization, and carbon emissions: Advancing sustainable development
Sohag, K., Husain, S., Soytas, U., 2024. Environmental policy stringency and ecological                     agenda. Sustain. Dev. 29, 1037–1048. https://doi.org/10.1002/sd.2192.
     footprint linkage: mitigation measures of renewable energy and innovation. Energy                 Xie, P., Xu, Y., Tan, X., Tan, Q., 2023. How does environmental policy stringency
     Econ. 136, 107721. https://doi.org/10.1016/j.eneco.2024.107721.                                        influence green innovation for environmental managements? J. Environ. Manag.
Sun, Y., Gao, J., 2023a. Natural resource endowment and its lmpact on ecological                            338, 117766. https://doi.org/10.1016/j.jenvman.2023.117766.
     efficiency. Res. Policy 87, 104272. https://doi.org/10.1016/j.                                    Xue, C., Shahbaz, M., Ahmed, Z., Ahmad, M., Sinha, A., 2022. Clean energy consumption,
     resourpol.2023.104272.                                                                                 economic growth, and environmental sustainability: what is the role of economic
Sun, Yi, Gao, J., 2023b. Natural resource endowment and its lmpact on ecological                            policy uncertainty? Renew. Energy 184, 899–907. https://doi.org/10.1016/j.
     efficiency. Res. Policy 87, 104272. https://doi.org/10.1016/j.                                         renene.2021.12.006.
     resourpol.2023.104272.                                                                            Yadav, M., Aneja, R., Ahmed, W., 2023. Do clean energy transition, environment
Sun, H., Edziah, B.K., Kporsu, A.K., Sarkodie, S.A., Taghizadeh-Hesary, F., 2021. Energy                    degradation, and energy efficiency influence health expenditure: empirical evidence
     efficiency: the role of technological innovation and knowledge spillover. Technol.                     from emerging countries. J. Clean. Prod. 428, 139355. https://doi.org/10.1016/j.
     Forecast. Soc. Chang. 167, 120659. https://doi.org/10.1016/j.                                          jclepro.2023.139355.
     techfore.2021.120659.                                                                             Yıldız, T.D., 2023. How can shares be increased for indigenous peoples in state rights
Ullah, S., Luo, R., Nadeem, M., Cifuentes-Faura, J., 2023a. Advancing sustainable growth                    paid by mining companies? An education incentive through direct contribution to
     and energy transition in the United States through the lens of green energy                            the people. Res. Policy 85, 103948. https://doi.org/10.1016/j.
     innovations, natural resources and environmental policy. Res. Policy 85, 103848.                       resourpol.2023.103948.
     https://doi.org/10.1016/j.resourpol.2023.103848.                                                  Yıldız, T.D., 2024. Considering the development levels of countries, contributions of
Ullah, S., Adebayo, T.S., Irfan, M., Abbas, S., 2023b. Environmental quality and energy                     mineral recovery from mining tailings and urban mining wastes to sustainability
     transition prospects for G-7 economies: the prominence of environment-related ICT                      criteria – A review. Res. Policy 99, 105399. https://doi.org/10.1016/j.
     innovations, financial and human development. J. Environ. Manag. 342, 118120.                          resourpol.2024.105399.
     https://doi.org/10.1016/j.jenvman.2023.118120.                                                    Yıldız, T.D., Güner, M.O., Kural, O., 2024. Effects of EU-compliant mining waste
Umar, M., Ji, X., Kirikkaleli, D., Shahbaz, M., Zhou, X., 2020. Environmental cost of                       regulation on Turkish mining sector: a review of characterization, classification,
     natural resources utilization and economic growth: can China shift some burden                         storage, management, recovery of mineral wastes. Res. Policy 90, 104836. https://
     through globalization for sustainable development? Sustain. Dev. 28. https://doi.                      doi.org/10.1016/j.resourpol.2024.104836.
     org/10.1002/sd.2116.                                                                              Yirong, Q., 2022. Does environmental policy stringency reduce CO2 emissions? Evidence
UNCTAD, 2023. United Nations Conference on Trade and Development.                                           from high-polluted economies? J. Clean. Prod. 341. https://doi.org/10.1016/j.
Villanthenkodath, M.A., Ansari, M.A., Balsalobre-Lorente, D., Satrovic, E., 2024. The                       jclepro.2022.130648.
     comprehensive impact of economic growth on environmental quality: insight                         Zheng, S., Kahn, M.E., Sun, W., Luo, D., 2014. Incentives for China’s urban mayors to
     established on material, carbon, and ecological footprint. Oper. Res. Forum. 5, 70.                    mitigate pollution externalities: the role of the central government and public
     https://doi.org/10.1007/s43069-024-00355-3.                                                            environmentalism. Reg. Sci. Urban Econ. 47. https://doi.org/10.1016/j.
Wang, K., Yan, M., Wang, Y., Chang, C.P., 2020. The impact of environmental policy                          regsciurbeco.2013.09.003.
     stringency on air quality. Atmos. Environ. 231. https://doi.org/10.1016/j.                        Zou, Y., Wang, M., 2024. Does environmental regulation improve energy transition
     atmosenv.2020.117522.                                                                                  performance in China? Environ. Impact Assess. Rev. 104 (January 2024), 107335.
                                                                                                            https://doi.org/10.1016/j.eiar.2023.107335.




                                                                                                  19
