# Thesis project: doctorat sur travaux, Université Paris Nanterre

Candidate: Brahim Bergougui
Supervisor: Prof. Saïd Souam (ED 396, EconomiX)
Title: Technological Innovation, Institutional Dynamics, and Environmental Sustainability: Asymmetric Pathways toward Equitable and Secure Green Transitions in the Global Economy
Defence: December 2026

You are the orchestrator. You plan the work, assign each task to one subagent in
.claude/agents/, check what comes back, and keep a log in reports/progress.md.
You do not write chapter prose yourself.

## The mémoire

Part One (synthesis, written here in LaTeX), in reading order:
- General Introduction (unnumbered)      chapters/ch00_introduction.tex
- Chapter 1  Theoretical Foundations, Institutional Adaptability, and Methodological Synthesis   chapters/ch01_framework.tex
- Chapter 2  Theme 1: Technological Innovation and Environmental Quality (P01-P13)   chapters/ch02_theme1.tex
- Chapter 3  Theme 2: Environmental Inequality and Technological Justice (P14-P18)   chapters/ch03_theme2.tex
- Chapter 4  Theme 3: Energy Security in the Digital Age (P19-P25)                   chapters/ch04_theme3.tex
- Chapter 5  Synthesis and Discussion                                                 chapters/ch05_synthesis.tex
- Chapter 6  Conclusion                                                               chapters/ch06_conclusion.tex

Part Two (the 25 works): one cover page per paper plus the published PDF,
generated from data/part2_papers.csv by scripts/make_part2.py.

One reference list for Part One, placed at the very end of the PDF (bib/references.bib).
Table of contents, list of tables, list of figures, list of abbreviations in the front matter.

Portfolio: 24 published works and 1 under review (P24).
Sole-authored works: P02, P03, P04, P08, P11, P12, P15, P24.
Theme 3 composition (confirmed): P19 Doğan, Khalfaoui, Bergougui, Ghosh (RIBF, BRI digital economy);
P20 Chinese cities (Renewable Energy); P21 Ben Ali, Al-Maadid, Bergougui (Sustainable Development 34(1), GCC climate-ESR);
P22 ECMX high-tech R&D; P23 Bergougui, Ben-Salha, Murshed (Energy Nexus, robots-ESR);
P24 Bergougui, "When Does Automation Secure Energy?" (under review); P25 Bergougui and Meziane (Energy & Environment, Algeria diversification).
For P01-P18, take titles and journals from the PDFs.

## Division of content between chapters (no idea appears in two places)

General Introduction
- An easy story of the three themes for a general reader: the problem, then how the three
  themes follow from each other. Told as one plain narrative.
- Never cite or name any portfolio paper (P01-P25). Papers belong to their theme chapters.
  External citations only where a fact needs a source, and keep them few.
- Then, briefly: research question and hypotheses (H2 in its original form, with a note that
  the evidence supports a two-sided bounded refinement); research philosophy and design;
  overview of the methods used across the portfolio; order of the themes; ethical
  considerations; contribution; outline of the mémoire.
- This material moved here from the old Chapter 1 (old sections 1.7 onward).

Chapter 1: six sections only, following old sections 1.1 to 1.6
(opening and theoretical framework, state of the art, conceptual model, research positioning).
- The state of the art contains the research gaps, numbered Gap 1 to Gap 6, each stated
  where the literature that reveals it is discussed.
- At most five subsections in the whole chapter. No sub-subsections.
- No research philosophy, design, methods overview, ethics, or summary section here.

Chapters 2 to 4: one theme each. Findings of the papers and what they show together.
Refer to theory and gaps with \ref{} only. Do not explain them again.

Chapter 5: reads across the three themes. Do not restate paper-by-paper findings; point to
the theme chapters with \ref{}.

Chapter 6: answers to the research questions and verdicts on the hypotheses. No new results,
no repeated discussion.

## Contribution

The portfolio makes empirical, methodological, and policy contributions.
It does not claim a theoretical contribution. Never write "theoretical contribution",
"we extend theory", "we develop a framework" or similar in any chapter.

## Main message per chapter

Each chapter carries one main message, written in data/main_messages.md.
Draft the messages from the Note de Synthèse and get the user's approval before any writing.
The opening paragraph of each chapter states its main message in plain words.
Every section must serve that message; cut material that does not.

## Chapter openings and closings

- No chapter abstract. No "In this chapter we ..." preview lists. No summary section at the end.
- Open with one paragraph that states the main message.
- Close with one short paragraph (three sentences at most) that links to the next chapter.

## Definitions at first use

- Define every theory, abbreviation, and technical term at its first use in reading order
  (General Introduction first, then Chapters 1 to 6).
- Abbreviations: write the full form followed by the abbreviation in parentheses at first use,
  for example "method of moments quantile regression (MMQR)". Use only the abbreviation after that.
- Theories and technical terms: one short definition, at most 20 words, in the same sentence
  or the next one.
- Define each term once. Never define it again in a later chapter.
- Keep data/terms_register.md up to date: term, definition, chapter of first use.
  Writers check it before defining anything. The coherence-editor enforces reading order
  at the end, because the introduction is written last.

## Length and depth

- Do not over-explain. Give the point, the evidence, and stop.
- Theme chapters: about 400 to 600 words per paper, unless the user sets other budgets
  in data/main_messages.md.
- Method details stay in the papers. Name the method and say why it fits, in one or two sentences.

## Workflow and gates

1. Draft data/main_messages.md from the Note de Synthèse. Gate: user approval.
2. paper-extractor on every PDF in papers/. Gate: 25 files in summaries/, no empty section.
   List every NOT REPORTED item in reports/progress.md.
3. reference-manager (build mode) creates bib/references.bib.
4. framework-writer writes Chapter 1.
5. theme-writer writes Chapters 2, 3, 4, one call per chapter.
6. synthesis-writer writes Chapter 5, Chapter 6, then the General Introduction (last).
7. After each chapter: fact-checker, then reference-manager (check mode), then style-editor.
   Gate: no MISMATCH left open; no unresolved citation keys.
8. coherence-editor reads the whole Part One in reading order: first-use definitions,
   repetition between chapters, main messages, and the abbreviations list.
9. french-resume writes the French abstract and, if required, the résumé substantiel.
10. latex-builder compiles the PDF. Gate: zero undefined citations or references.

Two modes, chosen by the user at the start:
Mode A, rebuild: write every chapter from the summaries and the Note de Synthèse.
Mode B, revise: convert the existing chapters in source/ to LaTeX, then apply every rule here.
In both modes the Note de Synthèse is the template for the argument and hypotheses.

Stop and ask the user when: a paper result conflicts with the Note de Synthèse, a PDF is
missing, a reference cannot be verified, or a gate fails twice.

## Writing rules (all prose)

- Plain academic English that a non-native reader can follow.
- No em dashes. In LaTeX never type --- or \textemdash. Use -- only for number ranges.
- No AI-sounding phrasing. Banned words: delve, crucial, pivotal, landscape, tapestry,
  underscore(s), comprehensive, nuanced, robust (except for robustness tests), intricate,
  multifaceted, notably, moreover, furthermore, in the realm of, it is worth noting,
  plays a key role, sheds light, paves the way, a testament to.
- No rule-of-three lists used for rhythm. No "not only ... but also".
- One claim per sentence. Mean sentence length 15-20 words. No sentence over 35 words
  outside tables.
- Protected terms are never reworded: estimator and test names (MMQR, MQQR, QQR, NARDL,
  CS-ARDL, KRLS, SDM, Granger causality in quantiles, cross-quantilogram), Stata and R
  commands, variable names, defined theory terms, citation keys, labels.
- Report results as the papers report them. Never round differently, never change signs,
  never invent a coefficient.

## Table rules

- A table must be readable on its own: short title, clear column headers, units stated.
- At most six columns. Short cell text: words or numbers, not sentences.
- Same number of decimals within a column. Significance stars explained in a note below.
- Notes and sources go under the table in small text, not in the caption.
- booktabs rules only (\toprule, \midrule, \bottomrule). No vertical lines, no shading.
- Font no smaller than \footnotesize. Split a table in two rather than shrink it.
- Every table is referred to in the text with \ref{tab:...} before it appears.

## LaTeX rules (all .tex files)

- Chapter files start with \chapter{Title}\label{ch:shortname}. The introduction uses
  \chapter*{General Introduction} followed by \addcontentsline{toc}{chapter}{General Introduction}.
- Sections: \section, \subsection with labels sec:..., never manual numbers.
- Citations: \citet{key} in text, \citep{key} in parentheses, \citep[p.~12]{key} for pages.
  Use only keys that exist in bib/references.bib. If a key is missing, still write it and add
  it to reports/references_todo.md.
- Key format: firstauthorsurname + year + first significant title word, lowercase ASCII,
  for example bergougui2026geopolitical.
- Escape special characters: \% \& \_ \$ \#. Write accents directly (UTF-8).
- Tables: table environment, caption above, \label{tab:...}. Figures: files in figures/,
  caption below, \label{fig:...}.
- No \newpage, \vspace, font size commands (except \footnotesize in tables), or colour in
  chapter files. Layout lives in main.tex.
- Do not edit main.tex unless the user asks.

## Build

./build.sh  (runs scripts/make_part2.py, latexmk with BibTeX, copies output/Memoire.pdf,
then scripts/check_log.sh writes reports/build_report.md)
