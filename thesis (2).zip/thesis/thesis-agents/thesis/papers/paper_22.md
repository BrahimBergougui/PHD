                                                            Energy Conversion and Management: X 30 (2026) 101598


                                                                     Contents lists available at ScienceDirect


                                                  Energy Conversion and Management: X
                                journal homepage: www.sciencedirect.com/journal/energy-conversion-and-management-x




When does high-tech research investment enable green energy transition?
Brahim Bergougui a,b,c,* , Sudeshna Ghosh d , Buhari Doğan g,h,i , Ahmed Samour e,
Rabindra Nepal f
a
  College of Business & Economics, Qatar University, Doha, Qatar
b
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
c
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
d
  Department of Economics, Scottish Church College, Kolkata, West Bengal, India
e
  Accounting Department, Dhofar University, Salalah, Sultanate of Oman
f
  School of Business, Faculty of Business and Law, University of Wollongong, Australia
g
  Institute for Statistical Studies and Economics of Knowledge, National Research University Higher School of Economics, Moscow, Russia
h
  Applied Science Research Center, Applied Science Private University, Amman, Jordan
i
  Western Caspian University, Economic Research Center (WCERC), Baku, Azerbaijan




A R T I C L E I N F O                                      A B S T R A C T

Keywords:                                                  The allocation of public budgets to research and development plays a vital role in advancing climate welfare and
Energy transition                                          facilitating the energy transition. Energy transition focuses on sustainable development goal − 7 (SDG-7). By
Research & development budgets                             discussing the importance of energy transition and research and development, the current study elaborates on
Institutional quality
                                                           the pathway to resilient energy. This study investigates the influence of public research and development budgets
Technological innovation
Economic complexity
                                                           on energy transition in 20 leading sophisticated economies over the period from 1995 to 2022. Using the method
High-tech industry                                         of moment quantile regression (MM-QR), the findings reveal a positive association between public renewable
Method of moments quantile regression                      energy R&D budgets and the Energy Transition Index (ETI) across all quantile distributions. The effect gets
                                                           weakened slightly at higher quantiles. While energy efficiency RD&D budgets demonstrate a positive association,
                                                           the results are statistically insignificant. Public spending on storage/other technologies and high-tech industry
                                                           demonstrates a negative impact in the lowest quantile, transforming to a positive and significant effect in higher
                                                           percentiles. The influence of control variables is further explored. Institutional quality and technological inno­
                                                           vation exert a positive and significant effect on energy transition across all quantiles, while economic complexity
                                                           demonstrates a negative impact, particularly pronounced in lower development stages. The study suggests that
                                                           governments within these leading economies should prioritize public R&D budgets, particularly for low-cost
                                                           renewable energy solutions across domestic, industrial, and transportation sectors. Furthermore, policies sug­
                                                           gestions is towards carbon-free electrification, electric vehicle adoption, and hydropower generation can
                                                           accelerate progress.




1. Introduction                                                                                   decarbonization has become increasingly urgent.
                                                                                                      Contemporary climate policy draws upon multiple intervention
    Energy transition represents a fundamental restructuring of global                            strategies, including afforestation programs, carbon capture technolo­
energy systems, moving away from fossil fuel dependence toward dec­                               gies, and comprehensive energy transition initiatives. Among these ap­
arbonized alternatives. This transformation sits at the heart of Sustain­                         proaches, energy transition occupies a particularly critical position
able Development Goal 7, which calls for universal access to affordable,                          given the intrinsic links between energy consumption patterns, carbon
reliable, and sustainable energy [1]. Beyond environmental concerns,                              emissions, and economic development trajectories [3]. Fossil fuel
the transition encompasses economic, institutional, and technological                             combustion remains the primary driver of anthropogenic greenhouse
dimensions that collectively shape pathways toward full decarbon­                                 gas emissions, making the shift toward renewable sources essential for
ization by century's end [2]. As climate change intensifies and natural                           meeting international climate commitments established through
resources face depletion pressures, the imperative for systematic                                 frameworks such as COP26 [4]. Understanding the mechanisms that


    * Corresponding author.
      E-mail address: bergougui@iss.nl (B. Bergougui).

https://doi.org/10.1016/j.ecmx.2026.101598
Received 20 April 2025; Received in revised form 13 January 2026; Accepted 19 January 2026
Available online 22 January 2026
2590-1745/© 2026 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                          Energy Conversion and Management: X 30 (2026) 101598


facilitate or impede this transition has consequently emerged as a pri­               This study addresses the identified empirical gap by systematically
ority for both policymakers and researchers.                                      investigating how public investment in environmental R&D influences
    Recent developments in clean energy technologies demonstrate                  energy transition across 20 sophisticated economies between 1995 and
considerable promise [5] Renewable energy deployment can potentially              2022. The selection of these particular countries reflects careful
reduce carbon dioxide emissions by up to 90 percent compared to                   consideration of data availability, sustained R&D commitment, and
conventional fossil fuel systems [6]. Recognition of this potential has           institutional capacity. These economies demonstrate sustained high
prompted numerous governments to implement strategic policies aimed               levels of public energy R&D investment as reported to the International
at accelerating clean energy adoption and fostering sustainable energy            Energy Agency, possess advanced technological and institutional infra­
sector growth. The International Energy Agency, alongside COP26                   structure, and provide complete data coverage across the study period.
participants, has emphasized the dual importance of improving energy              More specifically, the sample includes countries exhibiting sustained
efficiency and expanding low-carbon energy infrastructure. These                  IEA R&D reporting completeness with less than 5 percent missing values
commitments place particular responsibility on national governments to            across all categories, high per-capita public energy R&D investment
develop policy environments conducive to environmental welfare                    averaging USD 8.50 compared to a global mean of USD 1.20, and strong
enhancement through systematic reductions in carbon intensity.                    institutional-technological infrastructure enabling effective translation
    Within this policy landscape, public investment in research and               of research investments into transition outcomes. We acknowledge
development emerges as a potentially pivotal mechanism. Government                explicitly that findings derived from this sample apply most directly to
expenditure on environmental R&D budgets may serve as a catalyst for              high-capacity, high-R&D contexts and require cautious interpretation
technological breakthroughs that reduce transition costs and accelerate           when extrapolated to emerging or lower-income settings.
adoption timelines. The relationship between public R&D spending and                  The analytical framework addresses two central questions: What is
environmental outcomes has received theoretical attention, yet empir­             the effect of public R&D on energy transition? And does this effect vary
ical verification across diverse national contexts remains limited.               across countries at different stages of transition? To answer these
Examining how public research budgets translate into measurable                   questions, we employ the composite ETI proposed by [7], which cap­
progress along energy transition pathways offers valuable insights for            tures ETI dynamics through renewable and non-renewable components.
optimizing resource allocation and policy design.                                 We adopt the ETI values as reported in [7], and use it as the dependent
    Global trends in public energy R&D portfolios reveal significant              variable in a multivariate framework controlling for high-tech industrial
structural shifts. By 2018, worldwide public clean energy research and            development, economic complexity, institutional quality, technological
development reached approximately USD 12 billion. The composition of              innovation, and economic growth—factors that existing literature
this spending has evolved notably over the past decade. Nuclear energy            identifies as potentially influential for transition dynamics.
research, which comprised 34 percent of total public energy R&D in                    The inclusion of these control variables reflects their theoretical and
2008, declined to 25 percent by 2019. Simultaneously, combined in­                empirical relevance. High-tech industries, often sustained by R&D in­
vestments in energy efficiency and renewable energy technologies                  vestments, contribute to energy-efficient production methods and
expanded to approximately 34 percent of government research portfo­               structural economic transformation. Spillover effects from high-tech
lios by 2018, surpassing the share allocated to fossil fuel research. These       sectors enhance broader technological diffusion and support clean en­
patterns suggest a strategic reorientation of public research priorities          ergy adoption [8]). Economic complexity, measured through the Eco­
toward decarbonization objectives.                                                nomic Complexity Index, indicates a country's capacity for innovation
    Despite growing R&D investments and their anticipated effects on              and sophisticated production, with higher complexity generally associ­
energy system transformation, empirical evidence examining these re­              ated with improved energy efficiency and stronger transition potential
lationships across advanced economies remains notably absent. This gap            [9]. Structural change models in development economics emphasize
is particularly striking given that sophisticated economies—charac­               that sustained growth involves sectoral shifts from resource-intensive to
terized by substantial wealth, advanced technological capabilities, and           knowledge-intensive activities, a trajectory that aligns naturally with
high research intensity—represent contexts where R&D investments                  energy system transformation. Countries possessing industrial strengths
should theoretically yield the strongest transition outcomes. These               in engineering, manufacturing, or electronics can leverage these capa­
economies produce and export diverse arrays of complex, knowledge-                bilities to establish competitive advantages in renewable technologies.
intensive goods and services, reflecting high levels of economic                      Institutional quality represents another critical dimension. Robust
complexity and innovation capacity. Unlike economies dependent pri­               institutions reduce environmental externality costs and facilitate eco­
marily on raw material extraction or basic manufacturing, sophisticated           nomic activities through effective rule formulation and enforcement
economies demonstrate proven abilities to integrate advanced technol­             [10]. Institutional quality variations explain substantial cross-country
ogies, skilled human capital, and robust institutional frameworks. Such           differences in economic development levels. Weak institutional sys­
productive sophistication signals both resilience and adaptability in             tems impede technological progress and enable jurisdictional manipu­
responding to technological disruptions and shifting global demand                lation [11–13] . Conversely, strong political institutions enable
patterns.                                                                         governments to formulate coherent socio-economic policies, reduce
    The concept of economic complexity itself merits elaboration. Eco­            emissions effectively, and promote ETI . Institutions thus shape both
nomic complexity reflects the diversity and sophistication of productive          economic growth trajectories and environmental quality by facilitating
capabilities embedded within national industrial structures. It captures          renewable energy adoption [14]. From an institutional theory perspec­
not merely what countries produce, but the knowledge intensity and                tive, formal and informal rules govern societal behavior and decision-
coordination requirements underlying production processes. High-                  making processes. In energy contexts, governmental bodies, regulatory
complexity economies possess broader capability sets that facilitate              agencies, financial systems, and civil society organizations establish
branching into new technological domains, including renewable energy              frameworks that either enable or constrain low-carbon innovation.
and low-carbon industries. This structural foundation enhances inno­              These institutions influence market operations, shape public discourse,
vation potential and eases transitions toward novel production systems.           determine technological legitimacy, and help stabilize emerging energy
From an endogenous growth perspective, complex economies benefit                  regimes while dismantling carbon-intensive systems. Socio-technical
from dense networks connecting firms, research institutions, and com­             systems theory further illuminates how institutions interact with tech­
plementary sectors. These networks accelerate technological diffusion,            nology, culture, and infrastructure to form entrenched energy configu­
reduce adoption costs, and enable cross-sectoral knowledge spillovers             rations, with transitions occurring when economic, environmental, or
essential for breakthrough innovations in areas such as energy storage,           political pressures destabilize existing regimes and create space for
smart grid infrastructure, and advanced materials.                                niche innovations to scale.

                                                                              2
B. Bergougui et al.                                                                                        Energy Conversion and Management: X 30 (2026) 101598


    By integrating these multiple dimensions—public R&D budgets,                investment strategies require careful consideration, and technologies
high-tech industry development, economic complexity, institutional              and policies should be thoroughly evaluated.
quality, and technological innovation—this study provides a compre­                 Since renewable energy development remains in its relative infancy,
hensive assessment of energy transition drivers. The quantile regression        policymakers should devise appropriate strategies for transitioning to
methodology employed recognizes that R&D effects may vary substan­              clean energy. Santen and Anadon [21] argue that uncertainties are
tially across the energy transition distribution, with different mecha­         associated with renewable energy production. The optimal strategy for
nisms operating at early versus advanced transition stages. This                R&D investments involves judicious investment in emerging technolo­
approach reveals not merely whether R&D matters on average, but                 gies. In this context, Egli [22] considers the role of market prices as a
specifically when and where it exerts the strongest influence along             pivotal factor determining private investors' choices in renewable en­
transition pathways.                                                            ergy technology. Another critical issue in R&D investment concerns
    The findings offer actionable insights for policymakers navigating          technological advancement in crucial sectors for decarbonization, such
the complex landscape of climate and energy policy. Given that                  as the transport sector [23]. In summary, the literature highlights the
numerous regions currently pursue alternative energy sources and clean          need for synergies between R&D and energy transition. While existing
ETIs, research examining the efficacy of public R&D investments arrives         studies have emphasized the role of research and development budgets
at an opportune moment. Our results indicate that sustained public in­          for energy transition, the role of different categories of research budgets
vestment in renewable energy research and development correlates                and their relative importance remains underexplored. The current study
positively with measurable transition progress. Policy frameworks sup­          addresses this lacuna.
porting expanded public R&D funding should be complemented by
broader measures aligning high-tech industrial development and insti­           2.1.2. High-Tech industries and ETI
tutional quality with climate mitigation and sustainable development                A limited number of studies have explored the nexus between high-
objectives.                                                                     tech industries and energy [24,25]. Du et al. [24] explored the role of
    The remainder of this paper proceeds as follows. Section 2 reviews          high-tech industry and renewable energy consumption on consumption-
relevant literature on ETI determinants. Section 3 describes the meth­          based carbon dioxide emissions for the MINT countries. Results based on
odology, data sources, and variable construction. Section 4 presents            fully modified ordinary least squares (FMOLS), dynamic ordinary least
empirical findings and discusses their implications. Section 5 concludes        squares (DOLS), and the method of moments quantile regression
with policy recommendations and directions for future research.                 (MMQR) validate that high-tech industries increase carbon dioxide
                                                                                emissions while renewable energy availability mitigates emissions. In a
2. Literature Survey and theoretical framework                                  similar study, Wang et al. [25] explored how high-tech industries,
                                                                                financial globalization, and renewable energy affect the ecological
    This section presents an empirical discussion of the factors under­         footprint in G7 and E7 countries. Empirical outcomes from MMQR
lying this research, their relationships, and important features that           demonstrate that financial globalization and renewable energy nega­
contribute to a comprehensive analysis. This study synthesizes original         tively impact the ecological footprint. However, high-tech industries
discussions and findings that advance understanding of the current              significantly affect the ecological footprint, with the study concluding
research theme.                                                                 that environmental recovery remains a challenge for both developed
                                                                                and developing economies.
2.1. Literature Survey                                                              Liu et al. [26] explored the impact of R&D in high-tech industries on
                                                                                energy consumption in China using datasets from 1998 to 2016. The
2.1.1. Research and development and ETI                                         empirical outcomes demonstrate that the pharmaceutical industry has a
    The optimal pathway for achieving a transition to clean energy and          negative influence on energy consumption across all regions. Similarly,
the most effective strategies to amplify environmental and economic             Ghosh et al. [27] explored the effect of economic complexity, high-tech
benefits remain subjects of ongoing debate (). The literature has exam­         industries, renewable energy, natural resources, and financial global­
ined various aspects of the ETI process, with a critical focus on whether       ization on the environment for newly industrializing countries covering
investment in research and development serves as an enabling factor for         1990 to 2018. Long-run empirical results reveal that the expansion of
a smooth ETI trajectory.                                                        high-tech industries has significant environment welfare-enhancing ef­
    The pathway to energy transition is associated with substantial in­         fects. However, economic complexity and financial globalization
vestments in renewable energy production. Numerous studies document             increased emissions and ecological footprints in newly industrializing
that technical innovations provide significant stimulus for energy tran­        countries.
sition. A major driver of innovation is expenditure in Research and                 In a different vein, Rasool et al. [28] explored the impact of tech
Development (R&D), with public spending playing a pivotal role.                 industries, renewable energy, and urbanization on environmental
However, instances exist where public spending in R&D has led to                degradation in China for the period 1991 to 2015. Results based on
suboptimal resource allocation and market externalities. Against this           autoregressive distributed lag (ARDL) models and FMOLS show an in­
backdrop, policymakers must increasingly rely on market-driven factors          verse relationship between tech industry, renewable energy, urbaniza­
to promote R&D and technological innovation [15] observe an urgent              tion, and environmental degradation. Such findings indicate the need
need to formulate regulations preventing suboptimal energy manage­              for policy directions to increase budget spending on tech industries.
ment practices. Immense investments in R&D are unquestionably                   Likewise, Aziz et al. [29] examined the influence of tech industry and
needed during the transition from non-renewable to clean energy sys­            forest on environmental footprints in the presence of renewable energy
tems. Castrejon-Campos et al. [16] determined that investments in R&D           and urbanization for Saudi Arabia. Empirical results confirm the
constitute a major factor for transformation to clean energy.                   importance of tech industry and renewables in reducing environmental
    Furthermore, R&D and demonstration projects are pivotal tools in            footprints, renewing emphasis on building tech industries and
fostering technological development of energy sources [17]. Falcone             increasing the share of renewable energy.
et al. [18] argue that local stakeholders play an important role in
enabling R&D to impact energy transition. Polzin et al. [19] point out          2.1.3. Economic complexity and ETI
that to attain a decarbonized energy system, both private and public               Adekoya et al. [30] argued that the trajectory to renewable energy
sectors are imperative for advancing investment in R&D. Major R&D               transition depends on a country's economic complexity. Economic
decisions in the energy transition process should be considered from            complexity is commonly understood as knowledge productivity and
technical and interdisciplinary frameworks [20]. Additionally,                  production complexity [31], explaining the stock of knowledge and how

                                                                            3
B. Bergougui et al.                                                                                         Energy Conversion and Management: X 30 (2026) 101598


a nation's production capacity can be measured. The impact of economic          consumption and is effective in lowering carbon dioxide emission levels.
complexity on energy transition continues to yield mixed results. Bashir        In a different vein, Ahmad et al. [46] explored how institutional quality
et al. [32] argue that more complex economies possess sound knowledge           in the presence of economic complexity impacts the environment for
and productive capacities that can be leveraged to produce higher               emerging countries using data from 1984 to 2017. Findings underscore
technological goods that are energy-saving. Nonetheless, higher stages          that institutional quality helps mitigate ecological footprint, while
of economic complexity can lead to higher growth that may increase              renewable energy also decreases ecological footprint. The results
energy demand [33], potentially acting as an obstacle to energy effi­           confirm the importance of institutional quality for emerging countries'
ciency and energy transition.                                                   sustainable growth. Drawing from these empirical exercises, this study
    Sun et al. [34] explored the role of economic complexity and                includes institutional quality as a major explanatory factor.
renewable energy in reducing carbon emissions for the BRICS economies
using annual observations from 1995 to 2018. Results based on MMQR              2.1.5. Emerging technologies and ETI
document that economic complexity and renewable energy mitigate                     Recent research increasingly positions artificial intelligence (AI) and
carbon emissions, particularly at higher quantiles. For environmental           machine learning (ML) as general-purpose technologies that can mate­
sustainability, there is growing need for investments in innovations and        rially enhance the effectiveness and speed of energy transitions through
R&D development that improve economic complexity.                               multiple operational and innovation channels. At the system-operations
    Neagu [35] obtained that economic complexity leads to a decline in          level, AI improves the performance and reliability of renewable energy
non-renewable energy consumption and fosters the use of clean energy            systems by enabling predictive maintenance for wind and solar assets,
sources for 14 European countries. Rafique et al. [36] observed that            detecting anomalies in generation equipment, and reducing downtime
economic complexity drives energy transition and fosters clean energy           and lifecycle costs. At the grid level, AI supports real-time optimization
demand for E7 and G7 countries. In contrast, Alvarado et al. [37]               by improving dispatch decisions, congestion management, and
documented that economic complexity is related to a decline in clean            balancing variable renewable generation with flexible resources. In
energy consumption for 18 Latin American countries. Kazemzadeh et al.           parallel, AI-driven demand forecasting—using high-frequency con­
[38] explored the impact of income inequality and economic complexity           sumption data, weather signals, and mobility patterns—helps system
on ecological footprint for 25 countries covering 1970 to 2016. Empir­          operators anticipate load and integrate higher shares of intermittent
ical findings based on MMQR document that higher economic                       renewables without compromising reliability. These mechanisms align
complexity has a positive influence on ecological footprint.                    with the broader evidence that AI can strengthen renewable-energy
    Doğan et al. [39] added to the literature by exploring the impact of       transition outcomes and environmental sustainability pathways,
economic complexity, renewable energy, and population growth on                 including through finance–technology linkages and non-linear transi­
carbon emissions. Moreover, Alvarado et al. [40] explored how eco­              tion dynamics [47,48]).
nomic complexity impacts clean energy consumption for 16 Latin                      Beyond operational gains, the emerging literature suggests that AI-
American countries. Using quantile regression, Payne et al. [33] docu­          driven innovation can complement traditional R&D investments by
mented that expanding economic complexity enhances energy effi­                 accelerating the invention-to-deployment cycle and reducing clean-
ciency, further obtaining that economic complexity reduces energy and           technology diffusion frictions. Whereas conventional public R&D bud­
carbon intensity. Chu [41] explored the effect of economic complexity           gets primarily support upstream knowledge creation and experimenta­
on renewable energy for G7 countries. Results based on panel quantile           tion, AI can shorten iterative design cycles via automated discovery,
regression demonstrated an adverse relationship between economic                rapid prototyping, and learning-by-deployment effects—thereby
complexity and renewable energy at lower quantiles but a positive               potentially lowering deployment costs and improving adoption rates.
relationship at higher quantiles. The empirical observations demon­             Empirical studies linking AI innovation to improved carbon-emission
strate mixed outcomes, thereby renewing the scope for further research.         efficiency and sustainability performance reinforce the view that digi­
                                                                                tal innovation may act as a catalyst for the diffusion and scaling of low-
2.1.4. Institutional quality and ETI                                            carbon technologies rather than a substitute for R&D spending [49] .
    Saadaoui and Chtourou [42] explored the relationship between                Importantly, this suggests an interaction: the marginal returns to public
institutional quality, financial development, economic growth, and              R&D may be higher in contexts where AI capabilities are present to
renewable energy consumption in Tunisia for the period 1984 to 2017.            translate research outputs into scalable applications.
Results based on symmetric and asymmetric ARDL models document                      A complementary strand of scholarship emphasizes the nexus be­
that institutional quality and economic growth have a favorable impact          tween digital technologies, human capital, and sustainable transitions,
on renewable energy transition. In a similar study, Rahman and Sultana          arguing that AI’s benefits are contingent on institutional capacity, skills,
[43] investigated how institutional quality, economic growth, and ex­           and broader development conditions. Cross-country evidence indicates
ports impact renewable energy consumption in 19 emerging economies              that human capital can moderate the sustainability impacts of AI and
from 2002 to 2019. Results based on panel pooled mean group (PMG)               renewable energy, implying that digital adoption alone may not deliver
and ARDL methods document that institutional quality, economic                  transition gains without parallel investments in education, workforce
growth, and exports have positive and significant impacts on renewable          capabilities, and governance readiness [48] . In this regard, AI may also
energy consumption. The empirical results demonstrate that for better           contribute to equity dimensions of transition policy—such as alleviating
utilization of renewable energy, urgent focus on improving institutions         energy poverty via improved targeting and efficient resource alloca­
is needed.                                                                      tion—while simultaneously raising new challenges around digital di­
    Inglesi-Lotz [44] explored how institutional quality impacts renew­         vides and absorptive capacity .
able energy deployment in South Africa, obtaining that institutional                Overall, while our study focuses on public R&D budgets as policy
quality positively impacts the share of renewables. The study un­               instruments, the growing role of AI indicates that future research should
derscores the importance of institutional dynamics in reshaping South           examine interactions between traditional R&D funding and digital
Africa's energy landscape. Haldar and Sethi [45] explored how institu­          technology adoption in shaping energy transition outcomes. Positioning
tional quality moderates the impact of energy consumption on carbon             our R&D-centered analysis within this broader technological landscape
dioxide emissions in the presence of other macroeconomic factors such           not only clarifies the manuscript’s scope but also highlights a promising
as trade, capital formation, financial development, and population for          frontier: understanding when AI amplifies the effectiveness of R&D-led
39 developing countries from 1995 to 2017. Results based on mean                strategies and when constraints in human capital and institutions limit
group, augmented mean group, and common correlated effects mean                 these complementarities [49].
group estimation document that institutional quality moderates energy

                                                                            4
B. Bergougui et al.                                                                                             Energy Conversion and Management: X 30 (2026) 101598


2.2. Theoretical framework of the study                                             rights, and channel R&D effectiveness into deployment outcomes.
                                                                                    Strong institutions should positively affect ETI across all quantiles
   Building on innovation economics and energy transition theory, we                by: facilitating regulatory certainty for renewable investments,
develop mechanism-specific predictions for how each variable affects                enforcing carbon pricing and emissions standards, coordinating
ETI across quantiles:                                                               multi-stakeholder transition planning, and ensuring stable policy
                                                                                    frameworks that reduce investor risk.
 • Public Renewable Energy R&D (RDDREN): Cost-reduction and
   learning-by-doing mechanisms predict RDDREN should exhibit                       Fig. 1 summarizes the mechanism linking RD&D, technological
   positive effects across all ETI quantiles. Even advanced economies            change, and energy transition within a technology innovation cycle.
   require continuous innovation in next-generation renewable tech­                 Based on the above mechanisms, we propose the following
   nologies (floating offshore wind, perovskite solar cells, enhanced            hypotheses:
   geothermal systems). However, diminishing marginal returns are
   expected at higher quantiles because foundational renewable tech­              • H1a: Public renewable energy RD&D (RDDREN) is positively asso­
   nologies (onshore wind, crystalline silicon photovoltaics) have ach­             ciated with ETI across all quantiles.
   ieved commercialization and substantial cost reductions. At early              • H1b: The magnitude of the RDDREN effect declines at higher ETI
   transition stages (lower quantiles), public R&D yields substantial               quantiles (diminishing marginal returns).
   returns by overcoming initial deployment barriers—nascent supply               • H2: Storage and other technologies RD&D (RDD) is insignificant or
   chains, high capital costs, limited technical expertise, and regulatory          weak at lower quantiles (Q10–Q50) and becomes positive and sta­
   uncertainty. At advanced stages (upper quantiles), the marginal                  tistically significant at upper quantiles (Q60–Q90).
   impact of additional R&D declines as technologies mature and                   • H3: High-tech industry (HTI) is positively associated with ETI across
   private-sector incremental innovation dominates.                                 quantiles, with a stronger effect at higher ETI quantiles.
 • Storage and Other Technologies R&D (RDD): Energy storage                       • H4: Economic complexity (ECI) is negatively associated with ETI at
   technologies (batteries, pumped hydro, hydrogen storage, com­                    lower quantiles, and the effect attenuates toward zero or turns pos­
   pressed air) are infrastructure-complementary innovations: their                 itive at higher quantiles.
   effectiveness requires sophisticated grid management systems, real-            • H5: GDP per capita (Y) is negatively associated with ETI at higher
   time dispatch capabilities, demand-response mechanisms, and reg­                 quantiles, conditional on technological capacity and institutional
   ulatory frameworks allowing storage to participate in multiple value             quality.
   streams (energy arbitrage, frequency regulation, capacity firming).            • H6: Institutional quality (IQ) is positively associated with ETI across
   These enabling conditions are largely absent at early transition                 all quantiles.
   stages when renewable penetration remains below 20–25% and grid
   infrastructure remains optimized for baseload fossil generation. Only         2.3. Gaps in earlier studies
   after renewable deployment reaches sufficient scale does variable
   generation create binding flexibility constraints that make storage              The foregoing literature review reveals three distinct knowledge
   the critical enabling technology.                                             gaps that this study addresses:
 • High-Tech Industry (HTI): Technology spillover theory and
   absorptive capacity literature predict HTI enhances ETI through                • First, the measurement gap: Prior research typically employs sin­
   multiple channels: knowledge diffusion from advanced                             gle indicators—renewable energy share (%), carbon intensity (CO2/
   manufacturing to energy sectors, human capital accumulation in                   GDP), or fossil fuel dependence—that capture only one dimension of
   engineering and technical fields, and sophisticated production ca­               energy transition. These measures fail to account for simultaneous
   pabilities enabling domestic clean technology manufacturing. These               shifts within both nonrenewable categories and renewable cate­
   spillover effects should strengthen at higher quantiles where energy             gories. Our composite ETI addresses this limitation by incorporating
   transition requires complex system integration—smart grids,                      weighted indices for both nonrenewable transition and renewable
   vehicle-to-grid systems, sector coupling—that leverages advanced                 transition components, providing a comprehensive measure of
   industrial capabilities.                                                         progress along the entire energy ladder.
 • Economic Complexity (ECI): We propose a non-monotonic rela­                    • Second, the policy-instrument gap: Existing studies examine
   tionship reflecting path-dependence in industrial structure. At early            aggregate 'R&D spending' or 'innovation investment' without dis­
   ETI stages (lower quantiles), high economic complexity may lock                  aggregating by technology target or deployment stage. This obscures
   countries into energy-intensive industrial structures (chemicals,                which specific R&D allocations—renewables, efficiency, or stor­
   primary metals, heavy machinery) that create transition resistance               age—drive transition outcomes and prevents targeted policy guid­
   through sunk capital, employment concentration, and political                    ance. The use of three distinct IEA R&D budget categories (RDDREN
   economy constraints. As transition advances (higher quantiles), the              for renewables, RDDREF for efficiency, RDD for storage and other
   same diversified capabilities that initially created lock-in enable              technologies) addresses this granularity gap and enables identifica­
   adaptation to clean technology sectors through industrial reconver­              tion of technology-specific effectiveness patterns.
   sion, workforce retraining, and capability recombination.                      • Third, the heterogeneity gap: Conventional panel estimators (OLS,
 • GDP per capita (Y): Controlling for technology (HTI, TI) and in­                 fixed effects, random effects) estimate mean effects, implicitly
   stitutions (IQ), we predict potential negative GDP effects at higher             assuming homogeneous R&D impacts across all transition stages.
   quantiles due to consumption rebound mechanisms and carbon                       This ignores the reality that early-stage and advanced-stage econo­
   leakage through trade. Wealthy economies at advanced transition                  mies face fundamentally different deployment barriers, technology
   stages may experience: (a) income-driven consumption growth                      readiness levels, and infrastructure constraints. The Method of Mo­
   (larger homes, vehicle ownership, energy-intensive services) that                ments Quantile Regression (MMQR) framework reveals quantile-
   offsets efficiency gains, and (b) displacement of energy-intensive               specific effects, showing where and when R&D investments are
   production to trading partners while maintaining consumption of                  most effective along the transition distribution.
   embodied carbon through imports.
 • Institutional Quality (IQ): New institutional economics frames in­              By addressing these three gaps simultaneously, this study provides a
   stitutions as enabling conditions that reduce transaction costs,              more nuanced understanding of how different types of public energy
   enforce environmental regulations, protect intellectual property              R&D investments facilitate energy transition at different stages of

                                                                             5
B. Bergougui et al.                                                                                           Energy Conversion and Management: X 30 (2026) 101598




                                                Fig. 1. Conceptual Framework- Technology Innovation Cycle.


development. This framework transforms research from documenting                   b > a to reflect the preference for renewable energy development over
average relationships to identifying actionable sequencing and targeting           nonrenewable substitution. This approach captures the actual supply-
strategies for policymakers.                                                       side transition of energy consumption, complementing other indices
                                                                                   such as the World Economic Forum’s ETI, which primarily focuses on
3. Methodology and data                                                            policy and demand-side readiness [7]. For full methodological details,
                                                                                   including exact weights and normalization procedures, readers are
3.1. Data                                                                          referred to Hu et al. [7]. In this study, we use their published ETI series
                                                                                   directly, matched to our sample countries and the 1995–2022 period.
   The present study evaluates the influence of public Research &                  This ensures consistency with established measures while allowing our
Development (R&D) budgets for environmental protection, high-tech                  analysis to focus on the effects of disaggregated R&D budgets and
industry (HTI), economic complexity (ECI), institutional quality (IQ),             quantile-level heterogeneity.
technological innovation (TI), and economic growth (Y) on the ETI in 20                 The data on public R&D budgets, specifically Public Renewable
leading complex economies from 1995 to 2022. The data on ETI, rep­                 Energy R&D Budgets (RDDREN), Energy Efficiency R&D Budgets
resenting a country’s progress in transitioning from non-renewable to              (RDDREF), and Budgeted Funds for Power Storage Plus Other Tech­
renewable energy sources, were obtained from British Petroleum (BP,                nologies (RDD), were retrieved from the International Energy Agency
2024) and constructed using the methodology proposed by Hu et al. [7].             [50]. These variables are measured in US dollars per capita.
   Energy Transition Index: Energy transition refers to two comple­                     For control variables, information regarding HTI, which quantifies
mentary processes: (a) the shift from dirtier to cleaner energy solutions,         the value added by high-tech industries within the manufacturing sector
and (b) the shift from less efficient to more efficient energy solutions. In       (% of manufacturing value added), was obtained from the World
essence, energy transition reflects a nation’s movement up the energy              Development Indicators . Economic complexity (ECI), representing the
ladder. Energy consumption occurs through two broad categories:                    level of economic complexity within a country, was sourced from the
nonrenewable and renewable energy sources, each consisting of diverse              observatory of economic complexity. Technological innovation (TI),
components. Nonrenewable energy includes coal, crude oil, natural gas,             quantified by the total number of patents granted, and Economic growth
and nuclear energy, while renewable energy comprises biofuels, solar,              (Y), represented by GDP per capita (constant 2015 US dollars), were also
hydro, geothermal, and wind. A country that shifts its energy con­                 sourced from WDI [51]
sumption toward cleaner and more efficient sources is considered to be                  Institutional Quality (IQ) is constructed using six Worldwide
achieving energy transition.                                                       Governance Indicators (WGI) from the World Bank [52]: Control of
   In this study, the ETI is directly adopted from Hu et al. [7], who              Corruption, Government Effectiveness, Political Stability and Absence of
construct the index using British Petroleum (BP) Statistical Review en­            Violence, Regulatory Quality, Rule of Law, and Voice and Account­
ergy consumption data via a three-stage weighted aggregation                       ability. To assign objective weights to each dimension, we employ an
procedure:                                                                         entropy weighting method, which determines indicator importance
                                                                                   based on information content (cross-country variation) rather than
 • Stage 1 – Nonrenewable Energy Transition (NRT): Measures                        imposing arbitrary equal weights.
   progression among nonrenewable sources by assigning higher                           The entropy weighting procedure proceeds as follows:
   weights to energy types with lower carbon content. Nuclear energy                    Step 1 – Normalization: Each governance indicator Xijt for country i
   receives the highest weight, while coal receives the lowest, capturing          in year t is normalized to the [0,1] scale using min–max normalization
   movement toward cleaner nonrenewable energy within the fossil­                  across the full panel:
   –nuclear category.                                                                                   ( )
 • Stage 2 – Renewable Energy Transition (RT): Measures progres­                              Xijt − min Xjt
                                                                                                      i
                                                                                   Xijt =
                                                                                     *
                                                                                               ( )         ( )
   sion among renewable sources by assigning higher weights to sour­                      max Xjt − min Xjt
                                                                                            i          i
   ces with greater energy efficiency and emissions reduction potential.
   Wind and solar receive the highest weights, while biofuels receive              Step 2 – Proportion calculation: For each indicator j, the proportion
   the lowest, reflecting technological advancement within the renew­              for country i in year t is computed as:
   able sector.
 • Stage 3 – Composite ETI: The overall ETI for country i at time t is                     Xijt
                                                                                             *
                                                                                   pijt = ∑N *
   calculated as the weighted geometric mean of NRT and RT:                                i=1 Xijt
         √̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅
          a NRTi,t + b RTi,t
ETIi,t =                                                                           Step 3 – Entropy computation: The entropy of indicator j is calculated
                   a+b                                                             as:
where a and b are the respective weights assigned to NRT and RT, with


                                                                               6
B. Bergougui et al.                                                                                                      Energy Conversion and Management: X 30 (2026) 101598

           N ∑
           ∑ T                    ( )                                                Table 1
Ej = − k                   pijt ln pijt                                              Variables and their explanation.
               i=1   t=1
                                                                                       Variables                    Notations      Definition                          Sources
where k = 1/ln(N × T) is a normalization constant ensuring 0 ≤ Ej ≤ 1.                 Energy Transition            ETI            Measures a country’s progress       BP [53] (
    Step 4 – Divergence and weights: The divergence (information                         Index                                     in transitioning from non-
utility) of indicator j is defined as:                                                                                             renewable to renewable
                                                                                                                                   energy sources.
dj = 1 − E j                                                                           Public Renewable             RDDREN         Budgetary allocations for R&D       IEA [50]
                                                                                         Energy R&D                                activities focused on               (2024)
                                                                                                                                   renewable energy sources (US
Higher divergence indicates greater discriminatory power across coun­
                                                                                                                                   $ per capita).
tries. The objective weight for each indicator is then:                                Energy Efficiency R&D        RDDREF         Allocations for technologies        IEA [54]
                                                                                                                                   improving energy efficiency
          dj
w j = ∑6                                                                                                                           (US$ per capita).
          j=1 dj                                                                       Budgeted Funds for           RDD            R&D funds for energy storage        IEA [54]
                                                                                         Power Storage Plus                        solutions and other relevant
                                                                                         Other Technologies                        technologies (US$ per capita).
Step 5 – Composite index: The institutional quality index for country i
                                                                                       High-Tech Industry           HTI            Value added by high-tech            WDI [51]
in year t is obtained as:                                                                                                          industries within the
         6                                                                                                                         manufacturing sector (% of
         ∑
IQit =              *
               wj ⋅Xijt                                                                                                            manufacturing value added).
         j=1
                                                                                       Economic Complexity          ECI            Measures the level of               OECE
                                                                                                                                   economic complexity within a        [55]
                                                                                                                                   country.
Over the full sample period (1995–2022) for all 20 countries, the                      Institutional Quality        IQ             Index constructed using six         WDI [56]
average weights assigned to each governance dimension are as follows:                    Index                                     indicators: control of
Control of Corruption receives 0.18, reflecting the greatest cross-country                                                         corruption, government
variation; Government Effectiveness and Regulatory Quality each                                                                    effectiveness, political
                                                                                                                                   stability, regulatory quality,
receive 0.17, indicating strong and comparable discriminatory power;
                                                                                                                                   rule of law, and voice and
Rule of Law receives 0.19, slightly higher than the others, highlighting                                                           accountability. Weighted
its critical role as an institutional foundation; Political Stability receives                                                     using an entropy method.
0.15, reflecting moderate variation; and Voice and Accountability re­                  Technological                TI             Quantified by the total             WDI [56]
                                                                                         Innovation                                number of patents granted.
ceives 0.14, the lowest weight, indicating relative homogeneity across
                                                                                       Economic Growth              Y              GDP per capita (constant 2015       WDI [56]
the sample. This balanced distribution of weights (ranging from 0.14 to                                                            US dollars).
0.19) confirms that the composite index captures multiple dimensions of
institutional quality rather than being dominated by any single gover­               Note: All monetary variables are expressed in natural logarithms (Ln). To
                                                                                     accommodate zero values while applying the logarithmic transformation, we
nance aspect. The variables and their explanations are displayed in
                                                                                     use the standard adjustment ln(x + 1) for variables that include zeros. BP, IEA,
Table 1.
                                                                                     OEC, and WDI refer to British Petroleum, International Energy Agency, Obser­
    The data nature is described through the descriptive statistics pre­             vatory of Economic Complexity, and World Development Indicators,
sented in Table 2, which summarize the distributional properties of all              respectively.
variables employed in the econometric analysis. An examination of the
skewness and kurtosis statistics reveals substantial non-normality across
                                                                                         Model (1)
the indicators. The high values of skewness and kurtosis provide quan­
titative evidence that the variables deviate significantly from normal               ETIi,t =βi + α1 RDDRENi,t + α2 HTI i,t + α3 ECI i,t + α4 IQ i,t + α5 TI i,t + α6 Yi,t + μi,t
distributions. This finding, further supported visually by Fig. 2, indicates                                                                                                     (1)
that the ordinary least squares (OLS) method may not be suitable for the
                                                                                         Model (2)
analysis.
                                                                                     ETIi,t =βi + α1 RDDREFi,t + α2 HTI i,t + α3 ECI i,t + α4 IQ i,t + α5 TI i,t + α6 Yi,t + μi,t
                                                                                                                                                                                 (2)
3.2. Model specification
                                                                                         Model (3)
   The study investigates the effects of the core independent variables
                                                                                     ETIi,t = βi + α1 RDDi,t + α2 HTI i,t + α3 ECI i,t + α4 IQ i,t + α5 TI i,t + α6 Yi,t + μi,t
(public R&D budgets) on the Energy ETI across 20 major economies.
Specifically, the models aim to explore the following research questions:                                                                                                        (3)

                                                                                     Where i and t represent the 20 major complex economies and year,
   (i). How do the levels of public renewable energy research, devel­
                                                                                     respectively. The explanatory variables include public R&D budget
        opment, and demonstration budgets impact the shift towards
                                                                                     components (RDDREN, RDDREF, and RDD), High-tech industry (HTI),
        renewable energy sources in these economies?
                                                                                     Economic complexity (ECI), Institutional quality index (IQ), Techno­
  (ii). How do the levels of energy research, development, and
                                                                                     logical Innovation (TI), Economic growth (Y). α1 − α6 are the estimated
        demonstration budgets for energy efficiency influence the tran­
                                                                                     parameters.
        sition towards renewable energy sources in these economies?
 (iii). How do the budgeted funds for power storage and other tech­
        nologies affect the shift towards renewable energy sources in                3.3. Methodology
        these economies?
                                                                                        Our econometric strategy combines cointegration diagnostics with
    Additionally, the models consider the role of high-technology                    quantile regression estimation in a logically coherent framework:
manufacturing industries and other controlling factors. The multivar­                   Stage 1: Preliminary diagnostics
iate frameworks designed to assess the impact of each public R&D                        We begin by conducting slope homogeneity tests and cross-sectional
budget component (RDDREN, RDDREF, and RDD) on the ETI are                            dependence (CD) diagnostics to assess the presence of parameter het­
formally represented as follows:                                                     erogeneity across countries and contemporaneous correlation among

                                                                                 7
B. Bergougui et al.                                                                                             Energy Conversion and Management: X 30 (2026) 101598


Table 2
Summary statistics.
                      Mean         Std. Dev.         Min.                Max.                Skew.             Kurt.            Shapiro-Wilk test           Prob.

  ETI                 14.673       1.516             10.602              18.793              − 0.166           2.220            5.414                       0.000
  RDDREN               1.486       0.844              0.000               5.458                0.861           4.710            6.676                       0.000
  RDDREF               1.484       0.847              0.000               5.097                0.254           3.097            4.622                       0.000
  RDD                  0.886       0.650              0.000               4.193                1.061           5.502            7.552                       0.000
  HTI                 24.051       1.284             20.954              26.216              − 0.341           2.495            5.483                       0.000
  ECI                  1.627       0.404              0.764               2.859                0.515           2.999            5.066                       0.000
  IQ                   1.244       0.440              0.362               1.992              − 0.266           1.857            7.234                       0.000
  TI                   8.704       2.104              4.533              13.340                0.640           2.556            7.829                       0.000
  Y                   10.351       0.582              8.636              11.486              − 0.795           2.976            8.073                       0.000

Source: Author's compilation




                                                            Fig. 2. Binary-relation scatter plots.


panel units. These preliminary tests inform the appropriate choice of                   Stage 6: Causality Testing
subsequent estimation techniques.                                                       Finally, we conduct Dumitrescu-Hurlin panel Granger causality tests
    Stage 2: Unit root Testing                                                      to establish the directional causal relationships between public renew­
    Given evidence of cross-sectional dependence, we employ second-                 able energy RD&D expenditures, institutional quality, technological
generation panel unit root tests that explicitly account for cross-                 innovation, economic complexity, and energy transition outcomes.
country correlations to examine the stationarity properties of all vari­                Fig. 3 presents a schematic illustration of this comprehensive
ables and avoid spurious regression problems.                                       methodological framework, depicting the sequential progression of
    Stage 3: Cointegration analysis                                                 empirical procedures employed in this study.
    We apply the Westerlund [57] error correction-based panel cointe­
gration test to investigate the existence of long-run equilibrium re­               3.3.1. CD and unit root tests
lationships among energy transition, public renewable energy RD&D                        Prior to evaluating the relationships among the variables of interest,
budgets, institutional quality, technological innovation, economic                  it is crucial to address the potential issue of cross-sectional dependence.
complexity, and other covariates. This approach is robust to cross-                 Failing to account for cross-sectional dependence in empirical panel
sectional dependence and parameter heterogeneity.                                   models can lead to invalid findings. To overcome this challenge, the
    Stage 4: Primary estimation                                                     study employed the cross-sectional dependence test. The structure of
    The core empirical analysis utilizes the Method of Moments Quantile             this cross-sectional test is presented below.
                                                                                                √̅̅̅̅̅̅̅̅̅̅̅̅(∑                  )
Regression (MMQR) framework to estimate the quantile-specific effects                    CD = . N(N− 2T         n− 1 ∑N
                                                                                                          1)    i=1 . K =i+1 pIK   N(0, 1)I, K = 1, 2, 3, ⋯⋯⋯N(4).
of RD&D investments and other determinants on energy transition
across the entire conditional distribution. This technique captures het­                In Equation 4, i and T represent the cross-sections and time di­
erogeneous impacts at different stages of energy transition development             mensions, respectively. To address the issue of slope heterogeneity, the
while controlling for country fixed effects and potential endogeneity.              study employed the slope heterogeneity (SH) test. In this test, the null
    Stage 5: Robustness checks                                                      hypothesis (H0) implies homogeneous slopes, while the alternative hy­
    To validate the consistency and reliability of our primary MMQR                 pothesis (H1) suggests heterogeneous slopes. The slope heterogeneity
findings, we perform robustness analyses using alternative CD-robust                test is formulated in Equations (5) and (6) as follows:
                                                                                                        (       )
panel estimators, including Driscoll-Kraay standard errors (ESDK),
                                                                                    ̃ SH = (N)2 (2k)− 2 1 ̃
                                                                                               1      1
panel-corrected standard errors (PCSE), System GMM (to address dy­                  Δ                      S− k                                          (5)
                                                                                                         N
namic endogeneity), and Powell's fixed-effects quantile regression
(FEQR). These complementary methods provide mean-based and                                       (            )− 1 (         )
                                                                                    ̃ ASH = (N)2 2k(T − k − 1
                                                                                               1                 2 1
quantile-specific estimates for comparison while accounting for cross-              Δ                                ̃S − 2k                                    (6)
                                                                                                    T+1             N
sectional dependence and mixed integration orders.


                                                                                8
B. Bergougui et al.                                                                                                         Energy Conversion and Management: X 30 (2026) 101598




                                                                      Fig. 3. Methodology flowchart.


To assess the stationarity of the variables, the study employed the Cross-                energy transition development. This limitation is particularly salient
Sectional Augmented Im–Pesaran–Shin (CIPS) and Covariate                                  when analyzing energy transition pathways, as the drivers of renewable
Augmented Dickey-Fuller (CADF) tests. These stationarity tests are                        energy adoption may operate through distinct mechanisms at early
preferred over “first-generation” unit root tests because CIPS and CADF                   versus advanced stages of transition. Moreover, mean-based estimators
account for cross-sectional dependence and heterogeneity problems.                        are sensitive to outliers and can produce biased estimates in the presence
The CIPS value was obtained by taking the average of CADF values using                    of unobserved country-specific heterogeneity [58].
the following equation:                                                                       To overcome these methodological constraints, we employ panel
                                                                                          quantile regression to examine how public renewable energy RD&D
        n
̂ = 1                                                                                     budgets and other determinants influence the entire conditional distri­
       ∑
CIPS       CADFi                                                                (7)
     N i=1                                                                                bution of energy transition across our sample of 20 sophisticated econ­
                                                                                          omies. Quantile regression provides inherent robustness to extreme
The null hypothesis (H0) in the CIPS and CADF tests postulates that the                   values and imposes minimal distributional assumptions. However,
variables under investigation are non-stationary and not significantly                    standard panel quantile techniques remain susceptible to bias from time-
integrated. Conversely, the alternative hypothesis (H1) stipulates that                   invariant unobserved heterogeneity and potential endogeneity among
the variables are stationary and significantly integrated..                               explanatory variables. The Method-of-Moments Panel Quantile Regres­
                                                                                          sion (MMQR) framework developed by Machado and Santos Silva [59]
3.3.2. Co-integration test                                                                addresses these econometric challenges by explicitly modeling both
    To investigate the presence of long-run relationships among the                       location and scale shifts in the conditional distribution. MMQR accom­
research variables, the study employs Westerlund [57] cointegration                       modates asymmetric covariate effects, controls for country-level fixed
test. Unlike the first-generation cointegration assessments, Westerlund's                 effects, and delivers consistent quantile-specific estimates under main­
cointegration test accounts for slope heterogeneity and cross-sectional                   tained moment conditions—even when regressors exhibit endogeneity.
dependence. The formulation of this test is as follows:                                   These properties make MMQR particularly appropriate for investigating
                                                                                          complex, nonlinear relationships between RD&D investments and en­
                                        pi               pi
                 (                   ) ∑                 ∑
                                                                                          ergy transition across heterogeneous development stages.
ΔYit = τi dt + αi Yit− 1 − βʹi Xit− 1 +    αij ΔYit− j +    Yij ΔXit− j + εit   (8)
                                         j=1              j=0                                 Formally, the general panel quantile regression model is specified as:
                                                                                          Yit = ∂i + Xit θ + (ρi + z it λ) ∪it                                              (9)
In the given formulation, i represents the cross-sections, and t denotes
the time period. dt is deterministic components, τi depicts the parame­                   Where(ρi + z it λ > 0) = 1, and ∂i , θ, ρi , andλ are the estimated parameters.
ters vector and αi represents the error correction parameter.
                                                                                          Likewise, in (∂i , ρi ), i = 1 …., n, represents the fixed effects, which
                                                                                          capture individual-specific factors influencing the dependent variable at
3.2.3. Method of Moments quantile regression (MMQR) approach
                                                                                          quantile τ, z is a differentiable transformation of the linear combination,
    Energy transition indicators often exhibit non-normal distributional
                                                                                          which can be structured as follows:
properties—including excess kurtosis, heavy tails, and significant                               ( )
skewness—that violate the Gaussian assumptions underlying classical                       δj = δj Ẋ , j = 1, ⋯⋯.k                                                  (10)
linear regression models. Conventional panel estimation methods
focused exclusively on conditional means capture only average effects,                    Where ∪it is unrelated to Xit and is utilized in a manner that is “consistent
potentially obscuring substantial heterogeneity across different levels of


                                                                                      9
B. Bergougui et al.                                                                                                Energy Conversion and Management: X 30 (2026) 101598


with meeting moment conditions that do not require stringent hetero­              Table 4
geneity.” In the context of quantile analysis, the following equation will        Heterogeneity slope test outcomes.
be used for empirical estimation:                                                  Model                                     ̂
                                                                                                                             Δ                                ̂ Adj
                                                                                                                                                              Δ
    ( )
     T                                                                             Model (1)                                 3.438***                         4.067***
QT         = (∂i + δi q(T )) + Xit θ + δit λq(T )                    (11)
     Xit                                                                           Model (2)                                 4.129***                         4.885***
                                                                                   Model (3)                                 4.353***                         5.353***
In the provided equation, Xit denotes the explanatory variables in this           Note. *** means significant at the 1% level.
study and Yit is the ETI. Therefore, the Q T is expressed as
                 ∑∑
follows:Minq = t i pT (Rit − (δi + δit λ)q)
    Finally, to analyze causal relationships between the variables, this          Table 5
study utilizes the [60] this test is advantageous because it addresses            Cointegration test outcomes.
potential issues arising from heterogeneity (variations) in the relation­          Statistic        Value              Z-value            P-value     Robust P-value
ships between the variables [61].                                                  Model (1)
                                                                                   Gt                − 3.110             2.998            0.001       0.000
4. Empirical results                                                               Ga                − 3.574             5.513            1.000       0.100
                                                                                   Pt                − 9.784             0.233            0.408       0.000
                                                                                   Pa                − 3.271             3.440            1.000       0.200
4.1. CD, SH, unit root, and cointegration test findings                            Model (2)
                                                                                   Gt                 − 3.791          − 5.983            0.000       0.000
    Before proceeding to formal empirical analysis of this work, we use            Ga                 − 3.264            5.679            1.000       0.600
some statistical assessments to check the stationary, heterogeneity, and           Pt               − 10.759           − 1.050            0.147       0.000
                                                                                   Pa                 − 2.781            3.691            1.000       0.400
cross-sectional issues. We use CSD, heterogeneity slope tests, CIPS, and
                                                                                   Model (3)
CADF tests to achieve this. According to the findings of the CSD test              Gt                 − 2.967          − 2.370            0.009       0.000
(Table 3), the variables are cross-sectionally dependent in tested econ­           Ga                 − 3.345            5.636            1.000       0.300
omies. Heterogeneity slope test outcomes (Table 4) reveal that slope               Pt               − 11.184           − 1.406            0.080       0.000
                                                                                   Pa                 − 3.037            3.560            1.000       0.300
coefficients of the focused variables are heterogeneous, given that the
estimated variables are highly significant at a one percent level, indi­          Source: Author's compilation
cating that we must use the second-generation techniques of unit roots
to overcome this issue. The findings of second-generation CIPS and                    First, the MMQR analysis (model 1) shows that public renewable
CADF assessments (Table 3) display a mixed order of integration among             energy research, development, and demonstration (RDD) budgets posi­
the selected variables, i.e., some variables are stationary at level. In          tively affect the energy transition across all quantiles. The elasticity
contrast, others are stationary at the first difference.                          declines from 0.354 at the 10th quantile to 0.211 at the 90th quantile,
    In the next stage, the study evaluated the co-integration issue to            indicating that public RDD continues to drive renewable deployment but
ascertain the long-term linkage among energy transition and its focused           its marginal impact is stronger at earlier stages of the transition and
determinants. In this way, we evaluated co-integration using Westerlund           diminishes as countries advance. MMQR (model 2) finds that RDD
assessment. According to Westerlund outcomes (Table 5), 2 out of 4 test           budgets for energy efficiency are positive but statistically insignificant
statistics substantiate that long-term co-movement exists among energy            across the 10th–90th quantiles, suggesting these RDD expenditures do
transition adaptation and its focused determinants in all employed                not meaningfully affect the measured energy transition within our
models.                                                                           sample. MMQR (model 3) reveals that budgeted funds for power-storage
                                                                                  and related technologies have heterogeneous effects: they exert limited
4.2. Main findings of the MMQR approach                                           impact at lower quantiles but become positive and significant from the
                                                                                  60th to the 90th quantiles. Specifically, a 1% increase in budgeted funds
    Following the preliminary statistical assessments, the long-run link          for power storage and related technologies is associated with a
among public renewable energy research development and demonstra­                 0.104–0.178% increase in the energy transition at these upper quantiles.
tion budgets, energy research development and demonstration budgets                   These empirical quantile patterns admit theory-based mechanism
for energy efficiency, budgeted funds for power storage plus other                interpretations. (1) RDDREN declining effects: the decline in elasticity
technologies, high-tech industry, economic complexity, institutional              from 0.354 (10th) to 0.211 (90th) is consistent with diminishing mar­
quality index, technological innovation, economic growth are estimated            ginal returns to renewable R&D as countries move along the transition
using MMQR approach. Table 6 reports the findings of the MMQR                     pathway. At early transition stages (lower ETI quantiles), renewable
analysis.                                                                         technologies face high deployment barriers—nascent supply chains,


Table 3
CDS, CIPS, and CADF Tests Outcomes.
                      Cross-Sectional Dependence Test                                 Unit Root Tests
  Variables           CDS                                                             CIPS                                              CADF
                      Model 1                Model 2          Model 3                 I(0)                      I(1)                    I(0)              I(1)

  ETI                 33.57***                 29.02***       2041.40***              − 4.463 ***               − 6.158***              − 2.839***        − 4.661***
  RDDREN              479.31***                /              /                       − 3.121***                − 5.783***              − 2.456***        − 4.588***
  RDDREF              /                        1882.51***     /                       − 3.195***                − 5.452***              − 2.525***        − 4.032***
  RDD                 /                        /              1306.25***              − 2.834***                − 5.472***              − 2.569***        − 4.078***
  HTI                 1459.04***               1327.73***     1555.53***              − 4.013***                − 5.905***              − 2.664***        − 4.963***
  ECI                 1096.18***               1234.84***     1679.65***              − 1.498                   − 4.070***              − 1.283           − 2.787***
  IQ                  546.09***                499.45***      473.25***               − 3.860***                − 5.996***              − 2.698***        − 4.701***
  TI                  14824.70***              22145.69***    19331.48***             − 2.044                   − 3.346***              − 1.526           − 2.647***
  Y                   2109.51***               2531.92***     2041.40***              − 1.501                   − 3.731***              − 1.882           − 2.780***

Note. *** means significant at the 1% level.
Source: Author's compilation

                                                                             10
B. Bergougui et al.                                                                                               Energy Conversion and Management: X 30 (2026) 101598


Table 6
The Outcomes of MMQR.
  Variables           Quantiles
                      0.10         0.20            0.30             0.40              0.50           0.60             0.70              0.80             0.90

  Model (1)
  RDDREN                0.354***     0.330***        0.311***         0.295***          0.281***       0.265***         0.252***          0.234***         0.211***
  ​                    [0.064]      [0.055]         [0.049]          [0.046]           [0.045]        [0.046]          [0.048]           [0.053]          [0.061]
  HTI                   0.101*       0.109**         0.116***         0.121***          0.127***       0.132***         0.137***          0.143***         0.152***
  ​                    [0.054]      [0.046]         [0.041]          [0.039]           [0.038]        [0.039]          [0.041]           [0.045]          [0.052]
  ECI                 − 0.298*     − 0.229         − 0.175          − 0.129           − 0.086        − 0.042          − 0.001             0.05             0.117
  ​                    [0.169]      [0.145]         [0.130]          [0.123]           [0.120]        [0.122]          [0.128]           [0.140]          [0.163]
  IQ                    0.401        0.364*          0.335*           0.310*            0.287          0.263            0.241             0.214            0.177
  ​                    [0.249]      [0.213]         [0.191]          [0.180]           [0.175]        [0.178]          [0.187]           [0.206]          [0.239]
  TI                    0.046        0.057           0.067*           0.074**           0.082**        0.089***         0.096***          0.105***         0.116***
  ​                    [0.046]      [0.039]         [0.035]          [0.033]           [0.032]        [0.033]          [0.035]           [0.038]          [0.044]
  Y                   − 0.069      − 0.154         − 0.221          − 0.278           − 0.331**      − 0.386**        − 0.435**         − 0.499**        − 0.582**
  ​                    [0.236]      [0.202]         [0.182]          [0.171]           [0.167]        [0.170]          [0.178]           [0.196]          [0.227]
  Model (2)
  RDDREF                0.059        0.049           0.042            0.035             0.029          0.022            0.016             0.009          − 0.002
  ​                    [0.055]      [0.047]         [0.043]          [0.040]           [0.039]        [0.039]          [0.041]           [0.045]          [0.053]
  HTI                   0.068        0.086*          0.100**          0.114***          0.125***       0.137***         0.150***          0.162***         0.182***
  ​                    [0.056]      [0.049]         [0.044]          [0.041]           [0.040]        [0.041]          [0.043]           [0.046]          [0.055]
  ECI                 − 0.437**    − 0.364**       − 0.305**        − 0.246*          − 0.200        − 0.149          − 0.094           − 0.041            0.043
  ​                    [0.178]      [0.154]         [0.139]          [0.130]           [0.126]        [0.128]          [0.135]           [0.146]          [0.172]
  IQ                    0.492*       0.460**         0.435**          0.410**           0.390**        0.368*           0.344*            0.322            0.286
  ​                    [0.262]      [0.227]         [0.205]          [0.191]           [0.186]        [0.188]          [0.199]           [0.216]          [0.253]
  TI                    0.047        0.064           0.078**          0.091**           0.102***       0.114***         0.127***          0.139***         0.159***
  ​                    [0.049]      [0.042]         [0.038]          [0.036]           [0.035]        [0.035]          [0.037]           [0.040]          [0.047]
  Y                     0.286        0.144           0.029          − 0.084           − 0.174        − 0.274          − 0.381*          − 0.483**        − 0.646**
  ​                    [0.261]      [0.227]         [0.205]          [0.191]           [0.186]        [0.188]          [0.199]           [0.215]          [0.252]
  Model (3)
  RDD                 − 0.011        0.016           0.041            0.066             0.083          0.104*           0.126**           0.148**          0.178**
  ​                    [0.074]      [0.064]         [0.058]          [0.054]           [0.052]        [0.053]          [0.056]           [0.061]          [0.071]
  HTI                   0.066        0.081*          0.096**          0.110***          0.120***       0.132***         0.144***          0.157***         0.174***
  ​                    [0.055]      [0.048]         [0.043]          [0.040]           [0.039]        [0.039]          [0.042]           [0.045]          [0.052]
  ECI                 − 0.470***   − 0.398***      − 0.330**        − 0.264**         − 0.219*       − 0.164          − 0.106           − 0.048            0.033
  ​                    [0.171]      [0.150]         [0.135]          [0.125]           [0.122]        [0.124]          [0.131]           [0.142]          [0.165]
  IQ                    0.504*       0.476**         0.450**          0.424**           0.407**        0.385**          0.363*            0.341            0.309
  ​                    [0.264]      [0.231]         [0.207]          [0.192]           [0.188]        [0.190]          [0.201]           [0.219]          [0.254]
  TI                    0.058        0.069*          0.080**          0.090***          0.098***       0.106***         0.116***          0.125***         0.138***
  ​                    [0.047]      [0.041]         [0.037]          [0.034]           [0.033]        [0.034]          [0.036]           [0.039]          [0.045]
  Y                     0.330        0.182           0.045          − 0.091           − 0.183        − 0.296          − 0.415**         − 0.532**        − 0.699***
  ​                    [0.255]      [0.224]         [0.202]          [0.186]           [0.182]        [0.185]          [0.195]           [0.212]          [0.246]

Note. Standard errors in brackets. * p < 0.10, ** p < 0.05, *** p < 0.01.
Source: Author's compilation


elevated costs, and limited infrastructure—and public R&D produces                    positively impacted by high-tech industry, and the impact increases
substantial returns by lowering costs and creating knowledge spillovers.              from lower to higher quantiles. The coefficient for high-tech industry is
At advanced stages (upper ETI quantiles), foundational technologies                   consistently positive across all the model, with its magnitude increasing
(solar PV, onshore wind) have largely been commercialized and inte­                   lower quantile to higher quantile. This suggests that higher renewable
grated into grids, so additional public R&D yields smaller marginal                   energy transition is associated with greater high-tech industry, and this
gains. This pattern accords with innovation-diffusion theory: early                   effect strengthens at higher quantiles. In addition, the outcomes show
public investment catalyzes deployment, while mature technologies rely                that institutional quality index coefficients are positive and significant
more on private optimization and incremental improvements. (2) RDD                    across low, medium, and upper quantiles. These findings suggest that
threshold effects: the shift from insignificant effects at lower quantiles            institutional quality positively affects the energy transition in the
(0.10–0.50) to positive, significant effects at upper quantiles (0.60–0.90;           context of the top 20 sophisticated economies. Besides, the outcomes
elasticities 0.104–0.178) supports the infrastructure-complementarity                 demonstrate that technological innovation positively affects energy
hypothesis (see Section 2.6). Energy-storage R&D (batteries, pumped                   transition from lower to higher quantiles. Conversely, the findings show
hydro, hydrogen) requires sophisticated grid management, real-time                    that economic complexity negatively and significantly impacts energy
dispatch, and regulatory frameworks that typically exist only in coun­                transition at low quantiles. While economic complexity coefficients have
tries with advanced transition infrastructure. At early ETI stages, storage           an insignificant impact at medium and upper quantiles. These findings
R&D returns are limited because deployment is constrained by missing                  suggest that 20 sophisticated economies failed to use economic
complementary infrastructure; at advanced stages, storage becomes a                   complexity in promoting the energy transition.
critical enabler of variable renewable integration, making storage R&D                    The findings from MMQR (models 1, 2, and 3) show that economic
highly productive. These mechanism-based interpretations move the                     growth coefficients are negative, which eventually means that economic
quantile patterns beyond description to theoretically grounded empir­                 growth will have a destructive role towards energy transition. The
ical insights and imply clear sequencing for policy: scale storage R&D                findings were significant at the higher quantiles. These findings lead to
after foundational renewable deployment and grid modernization have                   the understanding that when economic growth has an increment, that
created the necessary enabling conditions..                                           will lead to a significant decline in the energy transition.
    The findings of control variables (high-tech industry, economic                       The MMQR outcomes are further illustrated in Figs. 4,5 and 6, of­
complexity, institutional quality index, technological innovation, eco­               fering a graphical representation of variable behavior across quantiles
nomic growth) in three tested models show that energy transition is                   for a more comprehensive understanding. Fig. 4 shows that public

                                                                                 11
B. Bergougui et al.                                                                                       Energy Conversion and Management: X 30 (2026) 101598




                                                         Fig. 4. MMQR estimates for Model 1.




                                                         Fig. 5. MMQR estimates for Model 2.


renewable energy research development and demonstration budgets                 RDDREF, RDD) and energy transition. Besides, these figures affirm the
impose a more severe effect on renewable energy transition at lower             positive link between high-tech industry, institutional quality index,
quantiles than the higher quantiles. The findings affirm the positive           technological innovation, and energy transition. In addition, the find­
renewable energy research development and demonstration budgets                 ings affirm the adverse link between economic growth, economic
across all quantiles, though with a slight decline in magnitude as              complexity, and energy transition in the tested economies.
quantiles increase. Besides, Fig. 5 suggests that energy research devel­
opment and demonstration budgets for energy efficiency have limited             4.3. Robustness check
effect on renewable energy across all quantiles. While Fig. 6 shows that
budgeted funds for power storage plus other technologies promote                   To confirm the MMQR results, the study employs ESDK, PCSE, Sys­
renewable energy at higher quantiles. However, these figures affirm the         tem GMM, and Powell's FEQR as robustness checks (Table 7), addressing
positive link between research & development budgets (RDDREN,                   cross-sectional dependence, endogeneity, and heterogeneous effects

                                                                           12
B. Bergougui et al.                                                                                                           Energy Conversion and Management: X 30 (2026) 101598




                                                                        Fig. 6. MMQR estimates for Model 3.



Table 7
The Outcomes of Robustness Check.
  Panel A. Mean Estimators
                                  Panel-Corrected Standard Errors                  Driscoll-Kraay Standard Errors                     System GMM
                                  Model (1)         Model (2)       Model (3)      Model (1)        Model (2)       Model (3)         Model (1)       Model (2)       Model (3)

  RDDREN                          0.475***          —               —              0.601***        —                —                 0.768*          —               —
  ​                               (9.05)            ​               ​              (5.86)          ​                ​                 (1.84)          ​               ​
  RDDREF                          —                 0.035           —              —               0.029            —                 —               0.493           —
  ​                               ​                 (0.74)          ​              ​               (0.43)           ​                 ​               (1.49)          ​
  RDD (storage/other)             —                 —               0.117*         —               —                0.410**           —               —               0.426**
  ​                               ​                 ​               (1.68)         ​               ​                (2.64)            ​               ​               (2.67)
  Controls                        Yes                 Yes           Yes            Yes             Yes              Yes               Yes             Yes             Yes
  Obs.                            560                 560           560            560             560              560               540             540             540
  Number of countries             20                  20            20             20              20               20                20              20              20
  R-squared                       0.9680              0.9790        0.9784         0.6954          0.583            0.6366            /               /               /
  Lagged ETI included             /                   /             /              /               /                /                 Yes             Yes             Yes
  Number of instruments           /                   /             /              /               /                /                 14              14              14
  Hansen p-value                  /                   /             /              /               /                /                 0.503           0.988           1.000
  AR(2) test p-value              /                   /             /              /               /                /                 0.413           0.398           0.873
  Panel B. Powell's (2016) fixed-effects quantile regression
  Variables                       Quantile
                                  0.10                0.20          0.30           0.40            0.50             0.60              0.70            0.80            0.90
  Model (1)
  RDDREN                          0.354***            0.330***      0.311***       0.295***        0.281***         0.265***          0.252***        0.234***        0.211**
  ​                               (0.087)             (0.067)       (0.055)        (0.048)         (0.045)          (0.048)           (0.054)         (0.065)         (0.084)
    Obs.                          560                 560           560            560             560              560               560             560             560
    Controls                      yes                 yes           yes            yes             yes              yes               yes             yes             yes
    Model (2)
    RDDREF                        0.059               0.049         0.042          0.035           0.029            0.022             0.016           0.009           − 0.002
    ​                             (0.073)             (0.058)       (0.048)        (0.041)         (0.039)          (0.041)           (0.047)         (0.056)         (0.073)
      Obs.                        560                 560           560            560             560              560               560             560             560
      Controls                    yes                 yes           yes            yes             yes              yes               yes             yes             yes
      Model (3)
      RDD                         − 0.011             0.016         0.041          0.066           0.083            0.104*            0.126**         0.148*          0.178*
      ​                           (0.098)             (0.079)       (0.065)        (0.055)         (0.052)          (0.055)           (0.064)         (0.076)         (0.097)
        Obs.                      560                 560           560            560             560              560               560             560             560
        Controls                  yes                 yes           yes            yes             yes              yes               yes             yes             yes

Notes: Standard errors in parentheses. * p < 0.10, ** p < 0.05, *** p < 0.01. All mean estimators include controls (GDP per capita, ECI, IQ, HTI) and country and year
fixed effects. For System GMM, instruments collapsed; AR(2) tests the null hypothesis of no second-order serial correlation. The Hansen J-test examines the null
hypothesis of instrument validity (over-identifying restrictions).




                                                                                          13
B. Bergougui et al.                                                                                                 Energy Conversion and Management: X 30 (2026) 101598


across quantiles. The results reaffirm that RDDREN positively influences                    HTI does not provide statistically significant information for fore­
energy transition across all models and quantiles, with effects slightly                    casting ETI.
declining at higher quantiles. RDDREF generally shows positive but                       4. ECI exhibits bidirectional Granger causality with ETI, suggesting
insignificant effects, indicating limited impact on the transition in most                  mutual predictive precedence: past ETI values help forecast ECI and
specifications. Total RD&D budgets (RDD) are consistently positive and                      vice versa.
increasingly significant at higher quantiles. Overall, these robustness                  5. IQ, TI, and Y each demonstrate unidirectional Granger causality from
checks support the main findings, confirming that RD&D budgets play a                       ETI, implying that prior energy transition progress contains infor­
critical role in promoting energy transition despite methodological                         mation useful for anticipating changes in these variables, but the
challenges.                                                                                 reverse predictive effect is weak or statistically insignificant.

                                                                                             Overall, the D-H panel analysis confirms and complements the
4.4. Panel causality results
                                                                                         MMQR results by showing that public R&D (especially for renewable
                                                                                         energy), ETI, and economic complexity are key variables with predictive
    We next examine the predictive relationships among ETI, RDDREN,
                                                                                         informational content for the energy transition. Importantly, these re­
RDDREF, HTI, ECI, IQ, TI, and Y using the Dumitrescu–Hurlin (D-H)
                                                                                         sults should be interpreted as evidence of directional information flows
panel Granger causality test. This approach identifies whether past
                                                                                         rather than definitive causal mechanisms: Granger causality identifies
values of one variable contain information that helps forecast another
                                                                                         temporal precedence in forecasting but does not establish structural
variable, without implying structural causality. The results are reported
                                                                                         causation
in Table 8.
    The findings indicate the following patterns of predictive
precedence:                                                                              5. Discussion


1. RDDREN exhibits unidirectional Granger causality to ETI, meaning                          This study examines how different public R&D budget types relate to
   that past RDDREN budgets contain information useful for forecasting                   national energy transition outcomes among 20 data-rich, high-capacity
   the energy transition. ETI, however, does not Granger-cause                           economies. Using MMQR and several robustness checks, the main
   RDDREN. This result is consistent with the notion that public in­                     empirical messages are as follows. First, public renewable R&D consis­
   vestment in renewable R&D supports the energy transition, partic­                     tently supports the energy transition across the ETI distribution, though
   ularly in early and intermediate stages.                                              the elasticity attenuates as countries move to higher ETI quantiles. This
2. RDDREF also shows one-way predictive precedence toward ETI,                           is consistent with theory: early public investment addresses binding
   while ETI does not Granger-cause RDDREF, suggesting that historical                   initial barriers (costs, supply chains, demonstration), while later stages
   RDDREF expenditures contain information relevant for forecasting                      rely more on private adaptation and incremental innovation. Second,
   energy transition outcomes.                                                           energy-efficiency R&D does not display a robust effect on our aggregate
3. HTI displays unidirectional Granger causality from ETI, indicating                    ETI measure; coefficients are small and statistically insignificant across
   that ETI developments can help predict innovation activity, but past                  quantiles. This may reflect measurement aggregation (ETI construction)
                                                                                         or that efficiency R&D yields benefit that are not fully captured by the
                                                                                         ETI index used here. Third, budgeted funds for power storage and
Table 8
                                                                                         related technologies behave heterogeneously: they are negligible or
Dumitrescu-Hurlin Panel Granger Causality Analysis.
                                                                                         slightly negative at low quantiles and become clearly positive and sig­
  Null Hypothesis (H0)     W-Stat    Zbar-       P-value     Decision                    nificant at upper quantiles. This pattern supports the infrastructure-
                                     Stat
                                                                                         complementarity hypothesis: storage R&D is most productive after
  RDDREN does not          2.1407     3.6072     0.0003*     Unidirectional              foundational renewable deployment and grid modernization have sup­
    Granger-cause ETI                                        causality
                                                                                         plied the complementary systems (smart grids, market dispatch, regu­
  ETI does not Granger-    0.6933    − 0.9697    0.3322      (RDDREN → ETI)
    cause RDDREN                                                                         latory frameworks) necessary for large-scale variable renewable
  RDDREF does not          1.8928     2.8233     0.0048*     Unidirectional              integration. Fourth, high-tech industry robustly and positively affects
    Granger-cause ETI                                        causality                   ETI across all quantiles, with effects strengthening from lower to higher
  ETI does not Granger-    0.6975    − 0.9567    0.3387      (RDDREF → ETI)              quantiles. This indicates that technological capability and advanced
    cause RDDREF
  HTI does not Granger-    1.5031     1.5910     0.1116      Unidirectional
                                                                                         manufacturing foster the transition through spillovers, skilled labor, and
    cause ETI                                                causality                   faster technology adoption—effects that become more important as
  ETI does not Granger-    2.9114     6.0443     0.0000*     (ETI → HTI)                 systems integration complexity increases. Fifth, economic complexity
    cause HTI                                                                            exerts a negative, statistically significant effect at low quantiles but is
  ECI does not Granger-    2.3092     4.1401     0.0000*     Bidirectional
                                                                                         generally insignificant at medium and upper quantiles. This may reflect
    cause ETI                                                causality
  ETI does not Granger-    1.8036     2.5413     0.0110**    (ECI ↔ ETI)                 that in earlier transition stages, more complex production structures
    cause ECI                                                                            elevate energy demand concentrated in fossil-dependent sectors; as
  IQ does not Granger-     1.1913     0.6049     0.5452      Unidirectional              transitions advance, complexity can be decoupled from fossil intensity.
    cause ETI                                                causality                   Sixth, institutional quality and trade/technology proxies tend to support
  ETI does not Granger-    1.6278     1.9852     0.0471**    (ETI → IQ)
    cause IQ
                                                                                         the transition, while economic growth shows negative associa­
  TI does not Granger-     2.5739     4.9772     0.0000*     Unidirectional              tions—significant mainly at higher quantiles—suggesting that growth
    cause ETI                                                causality                   trajectories in these advanced economies are not automatically aligned
  ETI does not Granger-    1.3907     1.2356     0.2166      (TI → ETI)                  with faster aggregate transition as measured by ETI.
    cause TI
                                                                                             Overall, the MMQR results provide a nuanced picture: public
  Y does not Granger-      3.5896     8.1889     0.0000*     Unidirectional
    cause ETI                                                causality                   renewable R&D and high-tech capacity are broadly supportive of the
  ETI does not Granger-    1.0004     0.0012     0.9991      (Y → ETI)                   transition; storage R&D is conditional on advanced infrastructure;
    cause Y                                                                              energy-efficiency R&D shows no clear aggregate effect in this sample;
Note: Decisions are based on conventional significance levels (α = 0.10, 0.05,           and the roles of complexity and growth vary across transition stages.
0.01). Unidirectional causality indicates that one variable Granger-causes the           These findings have clear policy implications for sequencing R&D in­
other but not vice versa. Bidirectional causality indicates predictive precedence        vestments and pairing them with infrastructure, market, and governance
in both directions.                                                                      reforms to maximize transition outcomes.

                                                                                    14
B. Bergougui et al.                                                                                            Energy Conversion and Management: X 30 (2026) 101598


6. Concluding Remarks                                                              elasticities ranging from 0.104 to 0.178. This indicates that storage R&D
                                                                                   should not be front-loaded in early transition stages. Instead, it should be
6.1. Conclusion                                                                    scaled once renewable penetration and system readiness reach threshold
                                                                                   levels—practically, an ETI of around 16 or a variable renewable share of
    The public budget on research and development is of crucial                    25–30%. Storage R&D is most effective when paired with complemen­
importance for climate welfare and energy transition. The current study            tary investments, including smart-grid infrastructure, real-time pricing
has explored how research and development impact energy transition                 mechanisms, enhanced interconnection capacity, and regulatory
for 20 leading sophisticated economies. The period of analysis runs from           frameworks that allow storage to participate in energy and ancillary-
1995 to 2022. Three model specifications have been utilized in the study           services markets. Funding should emphasize system-integration
based on three components of public budget on research and develop­                research alongside technology innovation to maximize productivity.
ment. These include public renewable energy research, development                      Although energy efficiency R&D (RDDREF) shows insignificant ef­
and demonstration, energy research, development and demonstration                  fects across quantiles, this should not be interpreted as a failure of ef­
budget for energy efficiency and budgeted funds for power storage and              ficiency investments. Rather, it signals the presence of diffusion barriers
other technologies.                                                                that limit the translation of R&D into measurable transition outcomes.
    The findings based on method of moment quantile regression doc­                Policies should complement efficiency R&D with binding standards such
uments that in the context of model 1, public renewable energy research            as building codes and appliance regulations, financial instruments to
development and demonstration budget positively affect energy transi­              support retrofits, and behavioral interventions to mitigate rebound ef­
tion across all quantiles. In the context of model 2, the findings                 fects. Such an approach ensures that efficiency R&D contributes to
demonstrate that energy research development and demonstration                     actual energy savings and transition progress, even if aggregate statis­
budgets for energy efficiency are positively associated with energy                tical signals are weak.
transition across the quantiles. Nonetheless the results are insignificant.            For advanced economies with ETI scores above 17, policy emphasis
Further in the context of model 3 the results show that the effects of the         should shift toward next-generation technologies and system integra­
budgeted funds for power storage plus other technologies on energy                 tion. Investments in offshore and floating wind, green hydrogen, long-
transition is negative in higher quantiles.                                        duration storage, and advanced power electronics can drive further
    The analysis demonstrates important results as far as the impact of            decarbonization. Scaling, manufacturing competitiveness, and demon­
the control variables like high-tech industry, economic complexity,                stration projects are particularly important to de-risk private-sector in­
institutional quality index, technological innovation and economic                 vestment and accelerate commercialization.
growth is concerned. In the context of the three model specifications,                 Finally, effective sequencing of R&D must be supported by fiscal,
energy transition is negatively impacted by high-tech industries. The              institutional, and innovation instruments. Green R&D tax credits,
impact rises as one move from the lower to the higher quantiles. How­              particularly refundable or enhanced credits for startups and SMEs, can
ever, the impact of institutional quality index is positive and significant        reduce the financial risks associated with long-term research. Public-
across low, medium and upper quantiles. Such results indicate that                 private innovation labs and shared testbeds can bridge the gap be­
institutional quality has a positive impact on energy transition for the           tween academic research and commercial deployment, while directing
top 20 sophisticated economies. Likewise, the results document that                funding toward high-impact priority technologies ensures that limited
technological innovation positively affects energy transition. In contrary         resources are concentrated on areas with the greatest decarbonization
the findings show that economic complexity negatively and significantly            potential. Adaptive evaluation of R&D programs, together with atten­
affects energy transition across the lower quantiles.                              tion to equity and just-transition criteria, will ensure sustainable and
    In sum, the findings confirm that more research and development                socially inclusive outcomes. By aligning R&D investment with stage-
budgets can positively expand technological innovation and energy                  specific needs, infrastructure readiness, and complementary policies,
conservation and improve energy efficiency. Such practices make the                governments can maximize the effectiveness of public research budgets
energy mix cleaner. Hence research and development budgets enable to               in driving the energy transition..
attain sustainable development goals by decreasing energy intensity and
enhancing green energy mix. The study highlights the importance of the             6.3. Limitations and future research directions
research and development budgets in energy conservation and low
carbon energy transition. The findings allow us to infer that research and             This study delivers robust evidence on the R&D–energy transition
development budgets will enhance green energy use and enable the top               nexus for 20 high-capacity economies, but several limitations temper the
20 sophisticated economies to move towards low-carbon energy                       generalizability of our conclusions and point to productive avenues for
transition.                                                                        further work.

6.2. Policy implications                                                            • Sample selection and external validity. Our sample was chosen for
                                                                                      IEA R&D reporting completeness and investment magnitude,
    The MMQR results suggest that R&D policy should be tailored to a                  yielding a set dominated by OECD and advanced Asian economies
country’s stage of energy transition, as the returns to specific types of             with strong innovation systems and institutional capacity. While this
R&D vary across ETI quantiles. For early-stage economies with lower                   enhances internal validity for data-rich settings, caution is warranted
ETI scores (approximately ETI < 15), public renewable energy R&D                      in extrapolating results to low- and middle-income countries or
(RDDREN) exhibits the strongest effects, with elasticities of 0.354 at the            economies with limited absorptive capacity. R&D effectiveness likely
10th quantile compared to 0.211 at the 90th quantile. This implies that               depends on complementary factors (human capital, infrastructure,
governments should prioritize investments in cost reduction and                       regulation) that vary across development stages; future studies
deployment of mature, high-impact technologies such as utility-scale                  should test heterogeneity across income groups and institutional
solar PV, onshore wind, and distributed generation. Complementing                     thresholds.
R&D with deployment support, including competitive auctions, targeted               • Omitted policy variables. Although models control for high-tech
subsidies, and grid connection priorities, can accelerate the translation             presence, economic complexity, institutional quality, innovation,
of research into installed capacity and measurable ETI gains.                         and GDP, important policy instruments remain unobserved—carbon
    Storage R&D presents a different sequencing challenge. The analysis               pricing, fossil-fuel subsidy levels, feed-in tariffs, renewable man­
shows that its impact is insignificant at lower ETI quantiles (Q10–Q50)               dates, grid investment, market liberalization, and exposure to
but becomes strongly positive at higher quantiles (Q60–Q90), with                     geopolitical shocks. If these correlate with R&D budgets, omitted-

                                                                              15
B. Bergougui et al.                                                                                                         Energy Conversion and Management: X 30 (2026) 101598


   variable bias may arise. Future research should integrate policy-                            capacity effects; (ii) integrating comprehensive policy and market-
   stringency and market-design measures to better isolate indepen­                             structure indicators to deconfound R&D impacts; (iii) estimating
   dent R&D effects.                                                                            nonlinear and threshold models to detect takeoff and diminishing
 • Measurement and index construction. The Energy Transition                                    returns; (iv) refining temporal specifications (distributed lags, R&D
   Index (ETI) uses a fixed weighting scheme based on carbon intensity                          stock); (v) developing quantile cointegration methods for heteroge­
   and efficiency benchmarks. Alternative weighting (equal weights,                             neous panels; (vi) assessing spatial spillovers of R&D across neigh­
   PCA, country-specific weights) or disaggregated, technology-specific                         bors; and (vii) examining interactions with electricity-market
   measures could change country rankings and coefficient estimates.                            liberalization.
   Robustness checks across ETI constructions and analyses focused on
   individual technologies (e.g., solar, wind, storage) would reduce                             Addressing these limitations will produce more nuanced, context-
   aggregation bias.                                                                         sensitive policy guidance on how R&D investments can most effec­
 • Methodological limits. Our strategy—panel cointegration at the                            tively support decarbonisation.
   mean followed by quantile-specific estimation—offers useful insights
   but rests on assumptions about the existence and interpretation of                        CRediT authorship contribution statement
   quantile-level cointegrating relationships. Formal quantile cointe­
   gration techniques for heterogeneous panels remain underdevel­                               Brahim Bergougui: Writing – review & editing, Writing – original
   oped; methodological advances would strengthen inference that                             draft, Validation, Software, Methodology, Conceptualization. Sudeshna
   quantile coefficients reflect heterogeneous long-run elasticities.                        Ghosh: Writing – review & editing, Writing – original draft. Buhari
 • Temporal dynamics and lag structures. R&D impacts manifest                                Doğan: Writing – review & editing, Writing – original draft, Supervi­
   over long, technology-dependent horizons. Our 28-year panel pro­                          sion. Ahmed Samour: Writing – review & editing, Methodology.
   vides temporal depth, but current specifications capture reduced-                         Rabindra Nepal: Writing – review & editing, Writing – original draft.
   form effects rather than explicit distributed lags or cumulative
   R&D stocks. Future work should model distributed lags, cumulative                         Declaration of competing interest
   R&D capital, and technology-specific gestation periods to better
   trace temporal pathways from research to deployment.                                          The authors declare that they have no known competing financial
 • Infrastructure and sectoral detail. Explicit modeling of energy                           interests or personal relationships that could have appeared to influence
   infrastructure (transmission, storage, smart grids, EV charging) and                      the work reported in this paper.
   sectoral analyses by energy source would clarify complementarities
   between R&D and deployment and identify which R&D domains                                 Acknowledgement
   most effectively accelerate specific technologies.
 • Priority extensions. High-value directions include: (i) expanding to                         The article was prepared within the framework of the Basic Research
   middle- and low-income contexts to test threshold and absorptive-                         Program of the HSE University.



Appendix

Appendix A

                                               Austria                            Hungary                          Slovak Republic

                                               Belgium                            Ireland                          Spain
                                               Czech Republic                     Italy                            Sweden
                                               Denmark                            Japan                            Switzerland
                                               Finland                            Korea                            United Kingdom
                                               France                             Netherlands                      United States
                                               Germany                            Poland                           ​




Data availability                                                                            [4] Nunes LJR. The Rising Threat of Atmospheric CO2: A Review on the Causes,
                                                                                                 Impacts, and Mitigation Strategies. Environments 2023;10(4):66. https://doi.org/
                                                                                                 10.3390/environments10040066.
    Data will be made available on request.                                                  [5] Bergougui B, Boudjana RH, Mehibel S, Ben-Salha O, Zambrano-Monserrate MA.
                                                                                                 Assessing the asymmetric effects of clean and dirty energy budgets on load capacity
                                                                                                 factor: Evidence from top investing countries. Journal of Environmental
References
                                                                                                 Management 2025;395:127823. https://doi.org/10.1016/j.jenvman.2025.127823.
                                                                                             [6] Yuan X, Su CW, Umar M, Shao X, LOBONŢ OR. The race to zero emissions: Can
 [1] Jayachandran M, Gatla RK, Rao KP, Rao GS, Mohammed S, Milyani AH, Azhari AA,                renewable energy be the path to carbon neutrality? Journal of Environmental
     Kalaiarasy C, Geetha S. Challenges in achieving sustainable development goal 7:             Management 2022;308:114648. https://doi.org/10.1016/j.jenvman.2022.114648.
     Affordable and clean energy in light of nascent technologies. Sustainable Energy        [7] Hu K, Sinha A, Tan Z, Shah MI, Abbas S. Achieving energy transition in OECD
     Technologies and Assessments 2022;53:102692. https://doi.org/10.1016/j.                     economies: Discovering the moderating roles of environmental governance. Renew
     seta.2022.102692.                                                                           Sustain Energy Rev 2022;168:112808. https://doi.org/10.1016/j.
 [2] Vatalis KI, Avlogiaris G, Tsalis TA. Just transition pathways of energy                     rser.2022.112808.
     decarbonization under the global environmental changes. Journal of                      [8] Lee H, Kim H, Choi DG, Koo Y. The impact of technology learning and spillovers
     Environmental Management 2022;309:114713. https://doi.org/10.1016/j.                        between emission-intensive industries on climate policy performance based on an
     jenvman.2022.114713.                                                                        industrial energy system model. Energy Strategy Reviews 2022;43:100898.
 [3] van den Bergh J, Castro J, Drews S, Exadaktylos F, Foramitti J, Klein F, Konc T,            https://doi.org/10.1016/j.esr.2022.100898.
     Savin I. Designing an effective climate-policy mix: accounting for instrument           [9] Doğan B, Driha OM, Balsalobre Lorente D, Shahzad U. The mitigating effects of
     synergy. Climate Policy 2021;21(6):745–64. https://doi.org/10.1080/                         economic complexity and renewable energy on carbon emissions in developed
     14693062.2021.1907276.                                                                      countries. Sustainable Development 2021;29:1–12. https://doi.org/10.1002/
                                                                                                 sd.2125.




                                                                                        16
B. Bergougui et al.                                                                                                            Energy Conversion and Management: X 30 (2026) 101598

[10] Opeyemi A, Uchenna E, Simplice A, Evans O. Renewable energy, trade                             Empirical evidence from the RCEP countries. Renew Energy 2022;184:541–50.
     performance and the conditional role of finance and institutional capacity in sub-             https://doi.org/10.1016/j.renene.2021.11.102.
     Sahara African countries. Energy Policy 2019;132:490–8. https://doi.org/                  [33] Payne JE, Truong HHD, Chu LK, Doğan B, Ghosh S. The effect of economic
     10.1016/j.enpol.2019.06.012.                                                                   complexity and energy security on measures of energy efficiency: evidence from
[11] Acemoglu D, Robinson J. The Role of Institutions in Growth and Development.                    panel quantile analysis. Energy Policy 2023;177:113547. https://doi.org/10.1016/
     Review of Economics and Institutions 2010;1(2). https://doi.org/10.5202/rei.                   j.enpol.2023.113547.
     v1i2.14.                                                                                  [34] Sun, Y., Bao, Q., Siao-Yun, W., ul Islam, M., & Razzaq, A. (2022). Renewable
[12] Bergougui B, Murshed SM. Revisiting the oil wealth-growth nexus: The role of                   energy transition and environmental sustainability through economic complexity
     economic norms in avoiding the oil curse. Extractive Industries and Society 2021;8             in BRICS countries: Fresh insights from novel Method of Moments Quantile
     (3):100929. https://doi.org/10.1016/j.exis.2021.100929.                                        regression. Renewable Energy, 184, 1165–1176. https://doi.org/10.1016/j.
[13] Bergougui B, Murshed SM. A sectoral analysis of institutional quality and foreign              renene.2021.12.003.
     direct investment in Mena countries: does sector type matter? Review of World             [35] Neagu O. The link between economic complexity and carbon emissions in the
     Economics 2023;159(4):987–1012. https://doi.org/10.1007/s10290-022-00486-x.                    European Union countries: a model based on the Environmental Kuznets Curve
[14] Olaniyi CO, Al-Faryan MAS, Ogbaro EO. Do institutional quality and its threshold               (EKC) approach. Article 4753 Sustainability 2019;11(17). https://doi.org/
     matter in the sensitivity of the renewable energy transition to financial                      10.3390/su11174753.
     development? New empirical perspectives. International Journal of Finance &               [36] Rafique MZ, Doğan B, Husain S, Huang S, Shahzad U. Role of economic complexity
     Economics 2025;30(1):5–43. https://doi.org/10.1002/ijfe.2900.                                  to induce renewable energy: Contextual evidence from G7 and E7 countries. Int J
[15] Magazzino C, Falcone PM. Assessing the relationship among waste generation,                    Green Energy 2021;18(7):745–54. https://doi.org/10.1080/
     wealth, and GHG emissions in Switzerland: some policy proposals for the                        15435075.2021.1880912.
     optimization of the municipal solid waste in a circular economy perspective.              [37] Alvarado R, Tillaguango B, Toledo E. Renewable energy, R&D, and economic
     J Clean Prod 2022;351:131555. https://doi.org/10.1016/j.jclepro.2022.131555.                   complexity: New evidence for Latin America using quantile regressions. In: Azar C,
[16] Castrejon-Campos O, Aye L, Hui FKP, Vaz-Serra P. Economic and environmental                    Kamal SH, editors. Design, Analysis, and Applications of Renewable Energy Systems.
     impacts of public investment in clean energy RD&D. Energy Policy 2022;168:                     Academic Press; 2021. p. 185–97. https://doi.org/10.1016/B978-0-12-824555-
     113134. https://doi.org/10.1016/j.enpol.2022.113134.                                           2.00013-7.
[17] Fertig E. Rare breakthroughs vs. incremental development in R&D strategy for an           [38] Kazemzadeh E, Fuinhas JA, Koengkan M. The impact of income inequality and
     early-stage energy technology. Energy Policy 2018;123:711–21. https://doi.org/                 economic complexity on ecological footprint: an analysis covering a long-time
     10.1016/j.enpol.2018.08.019.                                                                   span. J Environ Econ Policy 2022;11(2):133–53. https://doi.org/10.1080/
[18] Falcone PM, Imbert E, Sica E, Morone P. Towards a bioenergy transition in Italy?               21606544.2021.1930188.
     Exploring regional stakeholder perspectives towards the Gela and Porto Marghera           [39] Doğan B, Driha OM, Balsalobre Lorente D, Shahzad U. The mitigating effects of
     biorefineries. Energy Res Soc Sci 2021;80:102238. https://doi.org/10.1016/j.                   economic complexity and renewable energy on carbon emissions in developed
     erss.2021.102238.                                                                              countries. Sustain Dev 2021;29(1):1–12. https://doi.org/10.1002/sd.2125.
[19] Polzin F, Sanders M, Serebriakova A. Finance in global transition scenarios:              [40] Alvarado R, Ortiz C, Ponce P, Toledo E. Renewable energy consumption, human
     Mapping investments by technology into finance needs by source. Energy Econ                    capital index, and economic complexity in 16 Latin American countries: evidence
     2021;99:105281. https://doi.org/10.1016/j.eneco.2021.105281.                                   using threshold regressions. In: Shahbaz M, Tiwari AK, Sinha A, editors. Energy-
[20] Child M, Koskinen O, Linnanen L, Breyer C. Sustainability guardrails for energy                Growth Nexus in an Era of Globalization. Elsevier; 2022. p. 287–310. https://doi.
     scenarios of the global energy transition. Renew Sustain Energy Rev 2018;91:                   org/10.1016/B978-0-12-824440-1.00001-1.
     321–34. https://doi.org/10.1016/j.rser.2018.03.079.                                       [41] Chu LK. The role of energy security and economic complexity in renewable energy
[21] Santen NR, Anadon LD. Balancing solar PV deployment and RD&D: a                                development: evidence from G7 countries. Environ Sci Pollut Res 2023;30(19):
     comprehensive framework for managing innovation uncertainty in electricity                     56073–93. https://doi.org/10.1007/s11356-023-26208-w.
     technology investment planning. Renew Sustain Energy Rev 2016;60:560–9.                   [42] Saadaoui H, Chtourou N. Do institutional quality, financial development, and
     https://doi.org/10.1016/j.rser.2015.12.272.                                                    economic growth improve renewable energy transition? some evidence from
[22] Egli F. Renewable energy investment risk: an investigation of changes over time                Tunisia. J Knowl Econ 2023;14(3):2927–58. https://doi.org/10.1007/s13132-022-
     and the underlying drivers. Energy Policy 2020;140:111428. https://doi.org/                    00999-8.
     10.1016/j.enpol.2020.111428.                                                              [43] Rahman MM, Sultana N. Impacts of institutional quality, economic growth, and
[23] Zhang C, Yan J, You F. Critical metal requirement for clean energy transition: a               exports on renewable energy: Emerging countries perspective. Renew Energy
     quantitative review on the case of transportation electrification. Adv Appl Energy             2022;189:938–51. https://doi.org/10.1016/j.renene.2022.03.034.
     2023;9:100116. https://doi.org/10.1016/j.adapen.2022.100116.                              [44] Inglesi-Lotz R. Exploring the impact of institutional quality to South Africa's
[24] Du L, Jiang H, Adebayo TS, Awosusi AA, Razzaq A. Asymmetric effects of high-tech               transition to renewables. Article 2291433 Energy Sources Part B 2024;19(1).
     industry and renewable energy on consumption-based carbon emissions in MINT                    https://doi.org/10.1080/15567249.2023.2291433.
     countries. Renew Energy 2022;196:1269–80. https://doi.org/10.1016/j.                      [45] Haldar A, Sethi N. Effect of institutional quality and renewable energy
     renene.2022.07.028.                                                                            consumption on CO2 emissions: an empirical investigation for developing
[25] Wang Z, Chen H, Teng YP. Role of greener energies, high tech-industries and                    countries. Environ Sci Pollut Res 2021;28(12):15485–503. https://doi.org/
     financial expansion for ecological footprints: Implications from sustainable                   10.1007/s11356-020-11532-2.
     development perspective. Renew Energy 2023;202:1424–35. https://doi.org/                  [46] Ahmad M, Ahmed Z, Majeed A, Huang B. An environmental impact assessment of
     10.1016/j.renene.2022.12.039.                                                                  economic complexity and energy consumption: does institutional quality make a
[26] Liu Y, Huang X, Chen W. The dynamic effect of high-tech industries' R&D                        difference? Environ Impact Assess Rev 2021;89:106603. https://doi.org/10.1016/
     investment on energy consumption. Article 4090 Sustainability 2019;11(15).                     j.eiar.2021.106603.
     https://doi.org/10.3390/su11154090.                                                       [47] Wang Q, Zhang S, Li R. Artificial intelligence in the renewable energy transition:
[27] Ghosh S, Adebayo TS, Abbas S, Doğan B, Sarkodie SA. Harnessing the roles of                   the critical role of financial development. Renew Sustain Energy Rev 2026;226:
     renewable energy, high tech industries, and financial globalization for                        116280. https://doi.org/10.1016/j.rser.2025.116280.
     environmental sustainability: evidence from newly industrialized economies. Nat           [48] Zhang C, Li R, Wang Q. Artificial intelligence and sustainable development: a
     Res Forum 2023;48(1):5–38. https://doi.org/10.1111/1477-8947.12356.                            global nonlinear analysis of the moderating roles of human capital and renewable
[28] Rasool SF, Zaman S, Jehan N, Chin T, Khan S, uz Zaman Q. Investigating the role of             energy. Renew Sustain Energy Rev 2026;228:116574. https://doi.org/10.1016/j.
     the tech industry, renewable energy, and urbanization in sustainable environment:              rser.2025.116574.
     Policy directions in the context of developing economies. Technol Forecast Soc            [49] Zhang F, Li R, Wang Q. How does AI technology innovation drive carbon emission
     Chang 2022;183:121935. https://doi.org/10.1016/j.techfore.2022.121935.                         efficiency? a machine learning-based meta-frontier analysis across 75 countries.
[29] Aziz G, Sarwar S, Nawaz K, Waheed R, Khan MS. Influence of tech-industry, natural              Sustain Dev 2025;2025. https://doi.org/10.1002/sd.70312.
     resources, renewable energy and urbanization towards environment footprints: a            [50] IEA (2024).World Energy Outlook 2024. https://www.iea.org/reports/world-ene
     fresh evidence of Saudi Arabia. Resour Policy 2023;83:103553. https://doi.org/                 rgy-outlook-2024.
     10.1016/j.resourpol.2023.103553.                                                          [51] WDI (2024). World Development Indicators. https://databank.worldbank.or
[30] Adekoya OB, Kenku OT, Oliyide JA, Al-Faryan MAS, Ogunjemilua OD. Does                          g/reports.aspx?source=2&series=IT.CEL.SETS.P2&country=WLD.
     economic complexity drive energy efficiency and renewable energy transition?              [52] Kaufmann, D., & Kraay, A. (2024). The worldwide governance indicators:
     Energy 2023;278:127712. https://doi.org/10.1016/j.energy.2023.127712.                          Methodology and 2024 update. Available at SSRN 5154675. https://dx.doi.org/1
[31] Chu LK, Hoang DP. How does economic complexity influence income inequality?                    0.2139/ssrn.5154675.
     New evidence from international data. Economic Analysis and Policy 2020;68:               [53] BP (2024) Energy Outlook, https://www.bp.com/content/dam/bp/business-sites
     44–57. https://doi.org/10.1016/j.eap.2020.08.004.                                              /en/global/corporate/pdfs/energy-economics/energy-outlook/bp-energy-outlook-
[32] Bashir MF, Benjiang MA, Hussain HI, Shahbaz M, Koca K, Shahzadi I. Evaluating                  2024.pdf.
     environmental commitments to COP21 and the role of economic complexity,                   [54] Vatalis KI, Avlogiaris G, Tsalis TА. Just transition pathways of energy
     renewable energy, financial development, urbanization, and energy innovation:                  decarbonization under the global environmental changes. Journal of




                                                                                          17
B. Bergougui et al.                                                                                                             Energy Conversion and Management: X 30 (2026) 101598

     Environmental Management 2022;309:114713. https://doi.org/10.1016/j.                        [59] Machado JA, Silva JS. Quantiles via moments. J Econ 2019;213(1):145–73.
     jenvman.2022.114713.                                                                             https://doi.org/10.1016/j.jeconom.2019.04.009.
[55] OEC (2024). Data Availability. https://oec.world/en/data-availability.                      [60] Dumitrescu EI, Hurlin C. Testing for Granger non-causality in heterogeneous
[56] Yoshino N, Rasoulinezhad E, Taghizadeh-Hesary F. Economic impacts of carbon                      panels. Econ Model 2012;29(4):1450–60. https://doi.org/10.1016/j.
     tax in a general equilibrium framework: Empirical study of Japan. JEAPM 2021;23                  econmod.2012.02.014.
     (1–2):2250014. https://doi.org/10.1142/S1464333222500144.                                   [61] Chovancová J, Zambrano-Monserrate MA, Bergougui B, Ahakwa I, Dam MM.
[57] Westerlund J. Testing for error correction in panel data. Oxf Bull Econ Stat 2007;69             Global determinants of methane emissions in OECD countries: a dynamic panel
     (6):709–48. https://doi.org/10.1111/j.1468-0084.2007.00477.x.                                    approach. Research in Globalization 2024;9:100232. https://doi.org/10.1016/j.
[58] Koenker R, Bassett G. Regression Quantiles. Econometrica 1978;46(1):33. https://                 resglo.2024.100232.
     doi.org/10.2307/1913643.




                                                                                            18
