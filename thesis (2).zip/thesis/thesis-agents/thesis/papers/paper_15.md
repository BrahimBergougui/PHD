                                                                                  Borsa Istanbul Review 25 (2025) 1316–1336


                                                                               Contents lists available at ScienceDirect


                                                                                Borsa Istanbul Review
                                            journal homepage: www.elsevier.com/journals/borsa-istanbul-review/2214-8450




Can artificial intelligence mitigate environmental inequality? Evidence
from leading robotic-driven economies using quantile-based methods
Brahim Bergougui a,b,c
a
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
b
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
c
  College of Business & Economics, Qatar University, Doha, Qatar




A R T I C L E I N F O                                                  A B S T R A C T

Keywords:                                                              The rapid integration of AI into global economies raises critical questions about its environmental impact,
AI                                                                     especially concerning the equitable distribution of carbon emissions. This aspect of climate justice remains
Environmental inequality                                               largely unexplored. Existing literature extensively examines AI’s aggregate environmental impacts; however, it
Carbon emissions inequality
                                                                       largely overlooks the differential effects across emission quantiles and their implications for environmental
MQQR
Robotics-driven economies
                                                                       inequality. This oversight creates a significant research gap. This study addresses this critical void by investi­
                                                                       gating the dynamic relationship between AI adoption and carbon emissions inequality (CEI) across ten tech­
                                                                       nologically advanced economies from 2000 to 2023, employing a novel multivariate quantile-on-quantile
                                                                       regression (MQQR) methodology that captures nonlinear dependencies and heterogeneous effects across the
                                                                       entire distribution of environmental inequality. The empirical findings reveal stark heterogeneity across nations
                                                                       and quantile distributions, demonstrating the complex, non-uniform nature of AI’s environmental equity im­
                                                                       plications. European economies exhibit a three-phase trajectory: early AI adoption increases emissions
                                                                       inequality; mid-level adoption stabilizes it; and advanced integration reduces it, particularly in Denmark, France,
                                                                       and Sweden. Germany displays persistent positive effects across all quantiles. Among Asian economies, Japan
                                                                       and Singapore transition from initial increases to reductions in emissions inequality at higher quantiles, while
                                                                       Korea shows consistently positive effects. China presents an oscillating pattern, and the United States exhibits
                                                                       alternating effects across different quantiles. These results underscore the double-edged role of AI in environ­
                                                                       mental equity, revealing that the relationship between technological advancement and climate justice is neither
                                                                       universal nor linear. The findings provide crucial insights for policymakers, emphasizing the need for quantile-
                                                                       specific, country-tailored AI governance strategies that account for national developmental stages and distri­
                                                                       butional impacts to ensure AI-driven transformation contributes to environmental justice objectives.




    Abbreviation                             Full Form                                                                           Abbreviation                               Full Form

    AI                                       Artificial Intelligence                                                             OLS                                        Ordinary Least Squares
    CEI                                      Carbon Emissions Inequality                                                         QR                                         Quantile Regression
    MQQR                                     Multivariate Quantile-on-Quantile Regression                                        BDS                                        Broock–Dechert–Scheinkman Test
    IVQR                                     Instrumental Variable Quantile Regression                                           QADF                                       Quantile-Augmented Dickey-Fuller Test
    MQR                                      Multivariate Quantile Regression                                                    BQQR                                       Bivariate Quantile-on-Quantile Regression
    KRLS                                     Kernel-Based Regularized Least Squares                                              ARDL                                       Autoregressive Distributed Lag
    GDP                                      Gross Domestic Product                                                              WID                                        World Inequality Database
    EC                                       Energy Consumption                                                                  IFR                                        International Federation of Robotics
    POP                                      Population                                                                          KS                                         Kolmogorov–Smirnov
    FDI                                      Foreign Direct Investment                                                           ​                                          ​




      E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com.

https://doi.org/10.1016/j.bir.2025.07.012
Received 29 June 2025; Received in revised form 23 July 2025; Accepted 23 July 2025
Available online 26 July 2025
2214-8450/Copyright © 2025 Borsa İstanbul Anonim Şirketi. Published by Elsevier B.V. This is an open access article under the CC BY-NC-ND license (http://creativecommons.org/licenses/by-nc-nd/4.0/).
B. Bergougui                                                                                                                  Borsa Istanbul Review 25 (2025) 1316–1336


                                                                                        projected to reach US$53.7 billion by 2030. In addition, China’s robust
                                                                                        AI industry— Defined by an industry value of 500 billion yuan and a
1. Introduction                                                                         network exceeding 4300 enterprises— it has developed a comprehen­
                                                                                        sive AI ecosystem that includes upwards of 2.8 million 5G base stations
    Climate change is the defining crisis of the century and demands                    and 2500 digital workshops, leading to notable increases in production
immediate, concerted action. Robust evidence shows that anthropogenic                   efficiency and significant reductions in carbon emissions (Zhao et al.,
greenhouse-gas emissions have triggered unprecedented warming and                       2024). Beyond manufacturing, AI is revolutionizing the energy sec­
disrupted Earth’s natural processes (Berti et al., 2025; Li et al., 2025b;              tor—from production and distribution to consumption. This shift ad­
Mirasgedis et al., 2024). Addressing this challenge necessitates a drastic              vances the global transition to renewable energy and drives broader
reduction in carbon emissions across all sectors of the global economy                  industrial upgrading (Dong et al., 2024; Wang et al., 2023). As the
(Al-Qubati et al., 2024; Lin et al., 2025; Sirin et al., 2025). Crucially, the          integration of AI-powered robotics accelerates, its far-reaching impli­
urgency of climate action is inseparable from principles of environ­                    cations for global economic structures and sustainability are poised to
mental equity and justice. Contemporary research increasingly high­                     intensify, marking a new era of technological innovation and efficiency
lights how the impacts of climate change and environmental                              (Cone and Lambert 2019). Concurrently, academic literature has begun
degradation are not borne equally across societies. Vulnerable pop­                     to investigate the potential of AI to enhance energy efficiency and lower
ulations, often those with the least resources and who have contributed                 overall carbon emissions through innovations in building management,
the least to climate change, disproportionately experience the adverse                  renewable energy optimization, smart grid development, and sustain­
health, economic, and social effects of a changing climate (Pearse et al.,              able agriculture (Liu et al., 2024, 2025). However, training large AI
2025). Therefore, effective climate solutions must not only focus on                    models and operating data centers consume vast amounts of energy,
reducing emissions but also ensure a just and equitable transition to a                 raising serious environmental concerns (Niu et al., 2025). Furthermore,
sustainable future (Yang et al., 2025).                                                 there is growing apprehension that the proliferation of AI and robotics
    Carbon-emission inequality (CEI)—the uneven distribution of CO2                     may exacerbate income disparities, thereby influencing the broader
emissions across socioeconomic groups and regions—lies at the heart of                  socio-economic landscape (Liu and Liang 2025).
environmental inequality (Chancel 2022). This inequality manifests in                       While the manufacturing and energy sectors represent the most
stark disparities, with the wealthiest segments of the global population                visible arenas of AI transformation, the technology’s pervasive influence
emitting significantly more CO2 than their less affluent counterparts.                  extends across virtually every dimension of modern economic activity,
According to analyses by the World Inequality Database, alongside                       creating complex webs of interconnected environmental and social
research from Oxfam and the Stockholm Environment Institute, the top                    sectors. AI is reshaping industries such as healthcare, finance, and
10 % of earners worldwide generate nearly half of all                                   transportation with profound economic implications. In healthcare, AI is
consumption-based CO2 emissions, whereas the bottom 50 % produce                        revolutionizing diagnostics, personalized medicine, and operational ef­
only about 12 % (Bergougui et al., 2025; Chancel et al., 2022).This                     ficiency, potentially reducing costs and improving patient outcomes
uneven distribution exacerbates the environmental burdens faced by                      (Alowais et al., 2023; Topol 2019). However, the high costs of imple­
low-income populations and countries, hindering global sustainability                   mentation and the need for specialized skills may limit access, particu­
efforts. Moreover, research indicates that within-country carbon                        larly in underfunded systems, raising equity concerns. In finance,
inequality is also significant and, in many cases, surpasses the inequality             AI-driven algorithms enhance trading, risk management, and customer
observed between countries (Islam 2024; Pastor et al., 2024). The con­                  service, delivering significant economic benefits but also introducing
sequences of carbon emission inequality are profound. Climate change                    risks of market instability and job displacement (Buchanan 2019; Jones
impacts, such as extreme weather events, food and water scarcity, and                   2023). The transportation sector is shifting towards autonomous vehi­
health crises, disproportionately affect marginalized communities and                   cles and AI-optimized logistics, promising reduced emissions and
developing nations, who often lack the resources to adapt to these                      improved safety but requiring substantial infrastructure investments
changes. This creates a cycle of vulnerability, where those least                       and regulatory adaptations (Litman 2017). Across these sectors, AI
responsible for the climate crisis bear the heaviest burden of its conse­               drives economic growth and innovation but also poses challenges, such
quences. Addressing carbon emission inequality is therefore not only a                  as workforce displacement and the need for reskilling programs to
matter of justice but also a prerequisite for achieving effective and                   ensure inclusive economic benefits (Acemoglu & Restrepo, 2018). The
lasting global sustainability (Ma et al., 2025).                                        dual nature of AI adoption underscores the necessity of strategic policies
    Concurrently, AI-driven technologies and robotics are transforming                  to maximize its advantages while mitigating its disruptions. Techno­
multiple economic sectors (Zhang 2023). Recent industry analyses                        logical advancement, particularly through AI, plays a critical role in
reveal that the industrial robotics market, valued at US$87.1 billion in                shaping environmental outcomes, offering both opportunities and
2024, is anticipated to expand to US$162.7 billion by the decade’s                      challenges. AI can optimize resource use, reduce waste, and enhance
end—corresponding to an annual compound growth rate of 11.0 %.                          energy efficiency across various applications. For instance, AI-powered
Articulated robotic systems alone are projected to reach US$69.5 billion                smart grids improve energy supply-demand balance, integrating re­
by 2030, while cylindrical systems will also enjoy robust growth. This                  newables and reducing fossil fuel reliance (Li et al., 2025c). In agricul­
growth is primarily driven by breakthroughs in machine learning,                        ture, precision farming techniques enabled by AI minimize water and
especially through the development of deep neural architectures and                     fertilizer use, shrinking environmental footprints (Padhiary et al., 2024).
advanced language understanding models, which not only revolutionize                    However, the environmental costs of AI infrastructure are significant.
manufacturing processes but also facilitate rapid post-pandemic eco­                    Training large AI models and operating data centers is energy-intensive,
nomic recovery by swiftly adapting to emerging challenges and de­                       contributing to carbon emissions (Strubell et al., 2020). This tension
mands (Koley 2022). Furthermore, AI’s integration into industrial                       highlights the need for sustainable AI development practices, such as
robotics underpins substantial efficiency gains, cost reductions, and the               energy-efficient algorithms and renewable-powered data centers, to
modernization of traditional manufacturing practices. By enabling the                   ensure that technological progress aligns with environmental goals. The
development of novel products, services, and markets, AI has emerged as                 intersection of digital transformation and environmental justice frame­
a pivotal force in enhancing productivity and fostering innovation                      works reveals AI’s potential to address environmental inequalities while
(Zhang et al., 2025). This technological momentum is evident in the                     also posing risks of exacerbating disparities. AI can improve access to
geographic disparities observed in market deployment; for instance, the                 clean energy, monitor pollution in underserved communities, and sup­
American market currently represents US$10.3 billion, while the Chi­                    port data-driven policies that prioritize vulnerable populations
nese market, growing at an impressive annual rate of 14.0 %, is                         (Awogbemi et al., 2024). Yet, the digital divide threatens to widen

                                                                                 1317
B. Bergougui                                                                                                               Borsa Istanbul Review 25 (2025) 1316–1336


existing gaps, as marginalized communities may lack the infrastructure                  economic conditions. The anticipated results suggest that AI’s impact
and skills to leverage AI advancements (Capraro et al., 2024; Robinson                  on environmental inequality will exhibit variability contingent upon
et al., 2015). Inclusive policies—ensuring equitable technology access,                 AI integration levels, with the MQQR technique elucidating these
supporting capacity-building, and integrating diverse voices into AI                    variations across various economic indicators.
development—are essential to harness AI’s potential for environmental                 • Focus on leading AI nations: This study strategically examines the
justice and prevent it from deepening social and environmental                          premier AI-driven nations—China, Denmark, France, Germany,
inequities.                                                                             Italy, Japan, Singapore, South Korea, Sweden, and the United
    Despite extensive research on robotics and carbon emissions indi­                   States—recognized for their technological innovation leadership.
vidually, a significant gap exists in the academic literature, specifically             These countries, as early adopters and extensive implementers of AI
examining the complex relationship between increasing AI and robotics                   in industrial robotics and related technologies, constitute ideal sub­
integration in economies and its direct impact on carbon emission                       jects for assessing AI’s environmental inequality impacts. Advanced
inequality. Extant research predominantly addresses carbon emissions                    AI adoption in these nations significantly influences waste genera­
and associated inequalities in isolation, frequently neglecting the                     tion, resource consumption, and energy efficiency—critical factors in
transformative potential of AI and robotics in both understanding and                   environmental inequality evaluation. Moreover, economic and
addressing inequality drivers. There is an urgent need to investigate the               technological decisions by these AI-leading nations have extensive
mechanisms linking AI and robotics adoption to changes in carbon                        implications, influencing neighboring countries and entire regions.
emission inequality in robotics-driven economies. This study therefore                  By studying these nations, this research investigates their function as
investigates how robotics integration influences carbon-emission                        catalysts for regional environmental inequality. The study addi­
inequality. Specifically, this research endeavors to address the                        tionally considers the complex interconnectedness between these
following research question:                                                            nations’ AI sectors, creating network effects amenable to MQQR
    To what extent does adopting industrial robotics accelerate or                      analysis.
impede efforts to reduce environmental inequality?                                    • Finally, the research acknowledges the dynamic nature of AI-
    This investigation conducts a comprehensive analysis of AI’s impact                 environmental inequality relationships, accounting for variations
on environmental equity—operationalized through carbon emission                         in industrialization, economic development, and technological stra­
inequality—in the ten leading countries in robotics-driven industrial                   tegies through nation-specific analyses. This comprehensive
development: China, Denmark, France, Germany, Italy, Japan,                             approach establishes a robust foundation for future studies exploring
Singapore, South Korea, Sweden, and the United States. The study em­                    AI’s impact on environmental inequality across diverse economic
ploys high-frequency monthly data and uses non-linear approaches for                    contexts.
time-, frequency-, and quantile-based empirical analyses tailored to each
national context. The findings indicate heterogeneous effects of AI on                   The paper is structured as follows: Section 2 provides a compre­
carbon emission inequality across temporal dimensions, frequencies,                  hensive review of the literature on energy systems and artificial intel­
quantiles, and nations. This research addresses a significant gap in                 ligence. Section 3 specifies the research design and methodological
environmental literature, as no prior investigations have examined the               framework. Section 4 presents the data analysis, detailing empirical
quantile-level impacts of AI on environmental equity in leading robotics-            results and robustness checks. Section 5 discusses the implications of
driven economies, thus providing novel insights into this critical                   these findings, and Section 6 concludes with a summary of key insights
domain.                                                                              and offers policy recommendations derived from the study.
    This study introduces several key innovations:
                                                                                     2. Theoretical foundations
 • Pioneering analysis of robotics and environmental inequality: This
   study is among the first to systematically examine how industrial                     Prior to implementing econometric techniques to investigate the link
   robots influence environmental inequality today. By offering a novel              between artificial intelligence and disparities in carbon emissions, it is
   perspective on AI’s potential to address environmental equity chal­               essential to first lay out the underlying theoretical framework that
   lenges, this study enhances understanding of AI’s role in tackling                supports the ensuing empirical analysis. This framework conceptualizes
   broader socioeconomic issues. Through cross-country comparative                   AI’s impact on CEI through four interconnected theoretical mechanisms
   analysis, this research contributes to both environmental economics               that evolve dynamically across different adoption phases.
   and AI literature while providing robust empirical evidence to                        Productivity and sectoral shifts. Industrial robots—the most con­
   inform policy formulation. To the best of current knowledge, no                   crete embodiment of AI in manufacturing—revolutionize production by
   previous studies have specifically analyzed AI’s impact on environ­               automating routine, labor-intensive tasks; improving precision; and
   mental inequality.                                                                minimizing material waste (Boyd and Holton 2017; John et al., 2022).
 • Innovative methodology: This investigation employs MQQR method,                   These systems leverage real-time monitoring, predictive analytics, and
   a sophisticated analytical approach that extends beyond traditional               autonomous decision-making to detect inefficiencies and optimize
   methodologies such as OLS and standard quantile regression in                     resource utilization beyond human capabilities. In capital-intensive in­
   examining AI-environmental equity relationships. MQQR accom­                      dustries such as automotive manufacturing, petrochemicals, and heavy
   modates country-specific conditions by analyzing the full conditional             machinery, sizable upfront investments in robotics are feasible, enabling
   distribution, not merely mean effects. This approach enables                      early adopters to sharply reduce per-unit energy use and emissions. Such
   nuanced understanding of how AI’s impact on environmental equity                  firms gain significant competitive advantages, scaling output at lower
   varies according to a country’s emissions profile and industrializa­              marginal cost and widening the gap between their emission intensities
   tion level. Furthermore, the MQQR method effectively captures non-                and those of smaller, less technologically advanced competitors. This
   linear and asymmetric relationships frequently present in                         creates a two-tier industry structure in which advanced sectors rapidly
   socioeconomic-environmental interactions. This granular analysis                  improve productivity while traditional, labor-intensive sectors lag
   facilitates development of targeted policy recommendations cali­                  behind, exacerbating CEI (Zhang et al., 2022). Over time, however,
   brated to each nation’s specific context. The study also diverges from            equipment costs decline through economies of scale and technology
   conventional approaches by utilizing MQQR to explore both positive                commoditization, and modular robotics solutions become available to
   and negative impacts of AI on environmental inequality across                     mid-sized firms. Knowledge spillovers—driven by research consortia,
   different data quantiles—particularly relevant given the likelihood               professional networks, and consultancy services—accelerate the
   that AI-environmental inequality relationships are modulated by                   learning curve for late adopters. Simultaneously, government policies

                                                                              1318
B. Bergougui                                                                                                             Borsa Istanbul Review 25 (2025) 1316–1336


and international cooperation mechanisms facilitate technology transfer            projects, precision agriculture, and smart logistics. Through these
and capacity building in developing regions (Seo et al., 2019). Pub­               channels, infrastructure improvements converge across regions, align­
lic–private partnerships emerge to underwrite financing and deliver                ing emission-reduction opportunities and narrowing CEI over the long
technical assistance, lowering barriers for under-resourced firms. As a            run.
result, a broader array of producers can integrate AI-driven automation                Governance, policy, and equity considerations: The distribu­
into their processes, converging productivity levels and enabling cleaner          tional outcome of AI’s efficiency and productivity gains ultimately de­
production methods (Zai and Lazar 2024). This diffusion of best prac­              pends on governance frameworks and policy incentives that shape
tices ultimately narrows CEI by reducing the disparity in emission in­             deployment patterns (Wang and Feng 2022). Without robust oversight,
tensities across firms and regions.                                                market-driven AI diffusion gravitates toward profit-maximizing but
    Energy efficiency and system optimization. AI’s impact on energy               carbon-intensive applications—such as automated extractive operations
systems constitutes a second, potent channel for CEI dynamics. Smart-              or high-frequency financial trading—reinforcing existing socioeconomic
grid management, predictive maintenance, and dynamic demand fore­                  and environmental inequities (Foluke Ekundayo, 2024). Negative ex­
casting are among the AI-powered applications that unlock substantial              ternalities, including the high energy demands of data centers and
energy-utilization improvements (Muniandi et al., 2024; Solanki et al.,            electronic-waste generation, further burden vulnerable communities
2022). Machine-learning algorithms analyze large volumes of data­                  (Katal et al., 2023). Conversely, comprehensive AI governance frame­
—from smart meters, weather forecasts, and historical consumption                  works—exemplified by the OECD AI Principles (OECD, 2019) and the
patterns—to optimize load balancing in real time, integrate variable               European Union’s AI Act—mandate environmental and social impact
renewable resources smoothly, and coordinate distributed energy re­                assessments, transparency requirements, and equity safeguards. These
sources. Predictive-maintenance models process sensor signals and                  policies steer AI innovation toward low-carbon, high-social-benefit use
performance metrics to anticipate equipment failures, avoiding the                 cases. When coupled with targeted incentives—such as carbon-pricing
energy-intensive shutdowns and corrective actions associated with                  mechanisms that reward AI-driven emissions reductions, green pro­
breakdowns (Li et al., 2025a). In the initial rollout phase, only large            curement policies that create market pull for clean-tech solutions, and
utilities and energy-intensive manufacturers—those with advanced                   tax credits for AI-enabled renewable installations in underserved
sensor networks, high-speed connectivity, and sophisticated control                regions—they transform AI diffusion into a strategic lever for social and
centers—can capture these efficiency gains. The resulting energy-saving            environmental justice. International cooperation and climate-finance
and emissions-reduction benefits accrue disproportionately to regions              programs also play a critical role, funding AI-driven sustainable devel­
with modern infrastructure, deepening regional CEI as less-developed               opment projects in low-income countries and supporting capacity
areas remain dependent on legacy grids and inefficient equipment.                  building for equitable technology governance.
Over time, the development of AI-as-a-service platforms, supportive                    Bringing these mechanisms together, the effect of AI on emissions
regulatory policies (for example, subsidies for smart meters and grid              inequality follows a clear trajectory: in the early diffusion stages, AI’s
upgrades), and international technology-transfer initiatives extends ac­           advantages accrue mainly to the most technologically advanced firms
cess to smaller utilities and end users (Chen et al., 2023; Saber­                 and regions, driving a net increase in CEI. As adoption pro­
iKamarposhti et al., 2024). As AI solutions become cloud-based and                 gresses—fueled by falling costs, spillovers of expertise, broader infra­
standardized, the need for extensive local infrastructure investments              structure deployment, and targeted equity policies—AI’s productivity
diminishes. Decentralized renewable energy systems—such as micro­                  and efficiency gains extend to a wider set of stakeholders. This widening
grids optimized through AI—become economically viable for rural                    access fosters convergence in emission intensities and ultimately re­
communities and developing countries. Mature, system-wide AI                       verses the initial trend, producing a net reduction in CEI. This dynamic,
orchestration then enables virtual power plants and peer-to-peer energy            stage-based framework gives rise to two core hypotheses and informs
exchanges, ensuring that efficiency gains and the attendant emissions              the design of MQQR approach:
reductions are distributed widely rather than confined to early-adopter
regions (Alam et al., 2024). This convergence in energy intensity con­              • H1: In the initial phase of AI adoption, greater AI integration exac­
tributes directly to a reduction in CEI across geographic areas.                      erbates carbon-emissions inequality.
    Investment flows and infrastructure upgrades. Early-stage AI                    • H2: In the mature phase of AI adoption, further AI integration con­
investments follow existing infrastructure strengths, creating spatial                tributes to reductions in carbon-emissions inequality.
clustering in regions with robust ICT ecosystems, established robotics
clusters, and a skilled workforce (Borland and Coelli 2017; Camaréna                 By mapping these channels and their distributional effects, the
2020). Agglomeration effects—co-located research institutions, sup­                framework establishes a solid foundation for exploring the heteroge­
porting industries, and knowledge networks—lower investment risks                  neous AI–CEI dynamics; Fig. 1 presents a consolidated theoretical model
and catalyze further capital inflows (Audi et al., 2021). As a result,             that visually integrates these hypotheses.
wealthier regions experience rapid infrastructure modernization,
including upgraded manufacturing facilities, advanced power grids, and             3. Data and method
intelligent transportation systems (Hassan et al., 2024). These de­
velopments accelerate emissions reductions locally while leaving pe­               3.1. Baseline model design
ripheral regions with outdated equipment and poor connectivity,
thereby widening regional CEI. As diffusion progresses into a mature                 Building on recent theory and evidence, we specify the baseline
phase, public–private partnerships, climate-finance mechanisms, and                model as follows:
technology spillovers facilitate broader infrastructure upgrades. Tech­
                                                                                   CEI = f(AI, GDP, POP, FDI, EC)                                             (1)
nology incubators and university spin-offs carry AI expertise beyond
core hubs, while cloud-based platforms and modular robotic solutions               in Equation (1), ’CEI’ stands for carbon emissions inequality, ’AI’ is the
reduce cost and complexity (Kruger and Steyn 2024). Government                     primary independent variable (Artificial Intelligence), and ’GDP’ (Gross
interventions—targeted subsidies, concessional lending, and regulatory             Domestic Product), ’POP’ (population), ’FDI’ (Foreign Direct Invest­
frameworks that incentivize private-sector participation in underserved            ment), and ’EC’ (energy consumption) are control factors. This func­
areas—further encourage equitable deployment. International devel­                 tional specification captures the relationship between technological
opment organizations provide capacity-building programs and                        advancement, economic factors, and environmental inequality
technology-transfer       agreements      that    enable     rural     or          outcomes.
resource-constrained regions to implement AI-enhanced renewable

                                                                            1319
B. Bergougui                                                                                                              Borsa Istanbul Review 25 (2025) 1316–1336




                                                               Fig. 1. Analytical framework.


3.1.1. Theoretical justification for control variables                                  economic outputs into emissions, particularly through the combus­
    The selection of these variables is grounded in established theoretical             tion of fossil fuels. Moreover, energy consumption patterns differ
frameworks linking economic development, technological progress, and                    across income groups; lower-income households are more likely to
environmental outcomes. Carbon emissions inequality serves as the                       depend on inexpensive, high-emission energy sources, whereas
dependent variable, representing the differential distribution of carbon                higher-income groups typically engage in energy-intensive con­
footprints across socioeconomic strata within each studied country. This                sumption, especially in the realm of luxury goods. Neglecting to
measure aligns with contemporary conceptualizations of environmental                    incorporate energy consumption into empirical specifications can
inequality that emphasize distributional fairness of both environmental                 produce distorted inferences, since higher energy use may concur­
benefits and burdens (Chancel, 2022). Artificial Intelligence (AI),                     rently signify broad economic expansion and unequal availability of
operationalized through measures of industrial robot density, consti­                   clean-energy technologies. Therefore, including energy-use as a
tutes the primary independent variable of interest. Following Bergougui                 control variable is crucial for disentangling the unique effect of in­
et al. (2024a, b), the analysis hypothesizes that AI implementation may                 come distribution on emissions (Bergougui, 2024a; Stern 2007).
influence carbon emissions inequality through multiple pathways,                      • Population: Demographic factors, particularly population size,
including productivity enhancements, manufacturing process trans­                       significantly mediate the relationship between income inequality
formations, and energy consumption patterns.                                            and carbon emissions. A larger population inherently generates
    The control variables address potential confounding factors identi­                 higher total emissions due to the increased demand for energy, while
fied in previous research:                                                              population density can further amplify emissions through urban
                                                                                        congestion and heightened resource competition. Additionally, re­
 • GDP: Gross Domestic Product (GDP) serves as a fundamental indi­                      gions with larger populations often experience greater income dis­
   cator of economic activity that shapes both income disparities and                   parities because of uneven resource distribution. Excluding
   carbon emissions profiles. As a measure of overall economic scale,                   population metrics from the analysis may erroneously attribute
   GDP influences energy demand and consumption behaviors. Econ­                        variations in emissions solely to income inequality, when de­
   omies with higher GDP levels often experience elevated carbon                        mographic pressures play a substantial role. By incorporating pop­
   emissions due to intensified industrial activity, urban expansion, and               ulation controls, researchers can more accurately discern per capita
   higher consumption of luxury goods. Concurrently, economic growth                    effects and the underlying drivers of environmental outcomes (Apeti
   can exacerbate income inequality through mechanisms such as                          et al., 2025; O’Neill et al., 2010).
   capital accumulation, even as it facilitates the transition toward                 • Foreign Direct Investment (FDI) captures the effects of interna­
   cleaner technologies. Omitting GDP from analyses risks conflating                    tional capital flows, which may influence environmental outcomes
   changes in carbon emissions and income disparity with broader                        through technology transfer, regulatory interactions, and industrial
   economic dynamics. For example, an increase in GDP may simulta­                      composition effects (Pastor et al., 2024).
   neously signal greater reliance on fossil fuels and a concentration of
   wealth, thereby necessitating the inclusion of GDP as a control var­
                                                                                     3.2. Data and variable overview
   iable to properly disentangle these effects (Huang 2024).
 • Energy Consumption: Energy consumption operates as the direct
                                                                                     3.2.1. Sample selection and data sources
   conduit through which economic activity results in carbon emis­
                                                                                        This study investigates the impact of AI on CEI in leading AI-adopting
   sions. While GDP provides a broad measure of economic activity,
                                                                                     nations, particularly those with substantial AI integration in their in­
   energy use specifically captures the physical processes that convert
                                                                                     dustrial sectors. Covering the period from 2000 to 2023, the analysis is

                                                                              1320
B. Bergougui                                                                                                                      Borsa Istanbul Review 25 (2025) 1316–1336


constrained by AI data availability, which ends in 2020. To ensure                          or virtual environment against a set of human-defined goals." This
consistency with other variables, missing values from 2020 to 2023 are                      comprehensive definition includes both physical automation systems
estimated using interpolation. The data for this research is sourced                        and software-driven intelligence applications. The empirical literature
primarily from the International Federation of Robotics (IFR), the World                    employs three primary methodologies for quantifying AI development,
Inequality Database (WID), and the World Bank. The study focuses on                         each with distinct advantages and limitations:
two key variables—AI and CEI1—along with control variables such as
GDP per capita, population, foreign direct investment (FDI), and energy                      • Social fixed-asset investment in IT and software industries
use, as detailed in Table 1.                                                                   (Borland and Coelli 2017) captures aggregate investment flows to­
                                                                                               ward information and communication technologies. However, this
3.2.2. Dependent variable                                                                      broad measure fails to differentiate between traditional IT infra­
    CEI is the outcome variable under investigation. Past research has                         structure investments and cutting-edge AI technologies, potentially
largely contrasted CEI between advanced and emerging economies and                             overestimating AI-specific expenditures while including unrelated
even across various regions, yet the disparities within individual coun­                       technological upgrades.
tries remain just as critical (Ma et al., 2025). Although higher carbon                      • Total Factor Productivity (TFP) (Autor & Salomons, 2018) serves
emissions are often associated with improved living conditions, this does                      as an indirect indicator of technological advancement by measuring
not guarantee that the benefits are shared evenly among all citizens. In                       output growth not attributable to input increases. While TFP cap­
reality, poorer and marginalized populations frequently endure the                             tures productivity improvements, it conflates AI effects with tradi­
worst effects of environmental degradation and climate change (Piketty                         tional automation, process innovations, and other technological
and Chancel 2015). Ensuring that both the advantages and burdens of                            developments, making it impossible to isolate AI-specific contribu­
emissions are more fairly allocated is essential for achieving social eq­                      tions to economic performance.
uity. To quantify this inequality, this research utilizes the average car­                   • Stock of industrial robots (Acemoglu & Restrepo, 2020) provides a
bon emissions per capita of the top decile of emitters within each nation                      direct measure of AI implementation through physical automation
as a representative metric (Chancel 2022).                                                     systems. The International Federation of Robotics (IFR) publishes
                                                                                               comprehensive annual data on robot installations and active stock,
3.2.3. Independent variable                                                                    disaggregated by country and industry sectors, enabling systematic
    The core independent variable in this study captures AI development                        cross-national analysis.
through the stock of industrial robots. Following the OECD (2019)
definition, AI encompasses "machine-based systems that can take                                 The selection of industrial robot stock as an AI proxy reflects both
actions—predictions, recommendations, or decisions—that affect a real                       theoretical considerations and practical constraints. Industrial robots
                                                                                            represent one of the most mature and widely deployed AI applications in
                                                                                            the global economy, embodying sophisticated artificial intelligence
Table 1                                                                                     through advanced sensing, decision-making algorithms, and adaptive
The list of variables.                                                                      control systems. Their adoption reflects underlying improvements in AI
  Code     Variable Name    Description             Measurement             Source          technologies, including machine learning capabilities, computer vision,
                                                                                            and autonomous navigation systems (Liu et al., 2020). Furthermore,
  CEI      Carbon           Disparity in carbon     The mean individual     WID
           Emissions        emissions between       carbon dioxide          (2025)          robot deployment provides a tangible measure of AI integration that
           Inequality       income groups           emissions                               demonstrates technological maturity and cost-competitiveness. The
                                                    attributable to the                     penetration of industrial robots across manufacturing sectors indicates
                                                    highest decile of the
                                                                                            successful AI implementation at scale, offering observable evidence of
                                                    wealth distribution
  AI       Artificial       Level of industrial     Total number of         IFR             technological advancement that can be consistently measured across
           Intelligence     AI integration          active industrial       (2019)          different economic contexts. A critical factor influencing this variable
                                                    robots                                  selection was data accessibility. The IFR database provides the most
  GDP      Economic         Country’s level of      Real gross domestic     WDI             comprehensive and standardized cross-national dataset available for
           Growth           economic                product per capita,     (2025)
                                                                                            AI-related technology adoption, covering robot stock and installation
                            development             expressed in constant
                                                    2015 US dollars                         data across the ten study economies with consistent reporting standards
  EC       Energy           Energy Demand           Aggregate per-          WDI             and temporal coverage. This dataset enables robust empirical analysis
           Consumption      Density                 person energy           (2025)          while maintaining comparability across diverse economic structures and
                                                    utilization,
                                                                                            developmental stages.
                                                    quantified in
                                                    kilowatt-hours.
  POP      Population       Country’s               Total population        WDI             3.3. Econometric method
                            population size                                 (2025)
  FDI      Foreign Direct   International capital   Net inflows as % of     WDI                 This section describes the econometric methodologies employed to
           Investment       inflows impacting       GDP                     (2025)
                            technology and
                                                                                            examine the empirical relationships between CEI and AI over the period
                            emissions                                                       from January 2000 to December 2023. Given the time-series nature of
                            distribution                                                    the data, a series of preliminary tests were conducted to ensure the
                                                                                            variables met the necessary conditions for accurate analysis. First, a unit
                                                                                            root test was performed to determine the integration order of the vari­
                                                                                            ables. Stationarity was assessed using the quantile Augmented Dick­
                                                                                            ey–Fuller (ADF) test, a modern approach for evaluating the stability of
  1                                                                                         time-series data. Additionally, the Broock-Dechert-Scheinkman (BDS)
    To ensure that the temporal granularity of the carbon inequality series
                                                                                            test, as proposed by (Broock et al., 1996), was applied to detect
matched that of the income inequality data, values for the missing years
2019–2023 were interpolated. This procedure—mirroring the approach of                       non-linear patterns in the data. This step is crucial because identifying
Chancel and Piketty (2015), who similarly bridged gaps in carbon inequality                 non-linearity informs the choice of an appropriate modeling framework.
records—yielded a continuous dataset, thereby enabling a rigorous examina­                  If non-linearity is present, an asymmetric model must be employed to
tion of how disparities in carbon emissions co-vary with income inequality over             account for such complexities. Failing to address non-linearity can lead
the specified interval.                                                                     to biased and unreliable estimates. The overall modeling framework is

                                                                                     1321
B. Bergougui                                                                                                                          Borsa Istanbul Review 25 (2025) 1316–1336


illustrated in Fig. 2, providing a visual representation of the analytical            across individual quantile levels. For example, AI’s effect on CEI may
approach adopted in this study.                                                       vary across emission quantiles—reducing emissions in high-pollution
    This study introduces the MQQR method, an advanced econometric                    economies while having neutral or inverse effects in cleaner systems.
framework designed to investigate the complex relationship between                    By incorporating moderating variables like energy consumption, The
artificial intelligence and CEI in leading AI-driven nations. By incorpo­             MQQR framework delineates the combined impact of these variables,
rating controls for GDP, POP, FDI, and EC, the MQQR approach ad­                      furnishing decision-makers with nuanced understanding of AI–climate
dresses both asymmetries in data distribution and the limitations of                  interactions within particular contexts. The formal representation of this
traditional econometric techniques. Building on foundational work by                  association is provided in Equation (2):
(Sim and Zhou 2015; Xie and Tang 2022), MQQR extends univariate and                                      ∑             ∑
bivariate quantile methods into a robust multivariate nonparametric                   CEIt = βγ (AIt ) +  n
                                                                                                            αγ (Ut ) +  n
                                                                                                                          λγ (AIt *Ut ) + εγ                 (2)
framework, as advanced by (Alola et al., 2023; Özkan et al., 2023).
                                                                                      where CEI denotes carbon-emission inequality, AI denotes artificial in­
3.3.1. Advantages of the MQQR methodology                                             telligence, and U represents the set of n unspecified matrices. Incorpo­
                                                                                      rating the control variables into Equation (2), the equation can be
 • Multivariate quantile analysis: In contrast to classical quantile                  reformulated as follows:
   regression—which assesses how the central tendency of a single                            (
                                                                                                   ∑
                                                                                                          )
                                                                                                                 ∑
   predictor influences specific quantiles of the response varia­                     CEIt = βγ + n τγ Ut AIt +      n
                                                                                                                       αγ (Ut ) + εγ                       (3)
   ble—multivariate quantile analysis explores the joint impact of
   multiple covariates across the full spectrum of the outcome’s con­                                      ∑
   ditional distribution, MQQR evaluates interactions between quan­                   CEIt = ργ (AIt ) +         n
                                                                                                                     αγ (Ut ) + εγ                                           (4)
   tiles of both independent (e.g., AI, GDP, FDI) and dependent (CEI)
   variables. This multivariate extension mitigates omitted variable                  Since the function ργ (.) is unknown due to the undefined moderating
   bias—a key limitation of bivariate quantile-quantile regression                    effects, the dependence between the γ-quantile of CEI and the τ-quantile
   (BQQR) highlighted by (Ashley et al., 1980)—by capturing the joint                 of AI is explored. The first-order Taylor expansion of ργ (.) is:
   influence of multiple factors. For instance, MQQR simultaneously
                                                                                      ργ (AIt ) ≈ ργ (AIτ ) + ργ (AIτ )(AIt − AIτ )                                          (5)
                                                                                                                     ʹ
   models how AI adoption interacts with GDP, POP, FDI, and EC to
   shape CEI quantiles, offering a holistic view of these                                Equation (7) demonstrates that the functions ρ (AIt ) and ρ (AI ) are
                                                                                                                                                     γ             γʹ   τ

   interdependencies.                                                                 indexed by both γ and τ, while AIτ is indexed solely by τ. Additionally,
 • Enhanced precision via nonlinear approximation: MQQR employs a                     the first-order Taylor expansion of λγ shows that both λγ (Uτ ) and λγ (Uτ )
                                                                                                                                                                         ʹ

   quadratic nonlinear approximation for parameter transformations,                   are similarly indexed by γ and τ. ργ (AIt ) and ργ (AIτ ) can be alternatively
                                                                                                                                          ʹ

   diverging from the linear approximations used in prior studies (Alola              expressed as δ0 (γ, τ) and δ1 (γ, τ), which are embedded functions of βγ and
   et al., 2023). Drawing on (Fan and Gijbels 1992), this technique                   λγ Ut . Replacing these into Equation (4) results in:
   reduces estimation bias without inflating variance, improving model                                                           ∑
   fit accuracy. The nonlinear approach is particularly adept at tracing              CEIt = δ0 (γ, τ) + δ1 (γ, τ)(AIt − AIτ ) +    α(γ)(Ut ) + εγ               (6)
                                                                                                                                  n
   the curvature of relationships between variables, which is critical in
   environmental-economic systems where AI’s impact on CEI may                           equation (8) can be represented as (*) except for εγ , which signifies
   follow non-uniform patterns across quantiles.                                      the γth quantile of the CEI movement, and conditional on the τth quantile
 • Adaptive bandwidth selection: To address arbitrary parameteriza­                   of AI. In this case, δ0 and δ1 are indexed by γ and τ. and the full tail
   tion issues in earlier works (Xie et al., 2024), MQQR integrates a                 correlation is captured by (*). This (*) part of the equation also considers
   data-driven bandwidth selection mechanism (Özkan et al., 2023).                   uncertainty factors, leading to equation (8), which can be rewritten as:
   This adaptive technique adjusts window widths based on local data                  CEIt = β0 (γ, τ) + β1 (γ, τ)(AIt − AIτ )
   characteristics, enhancing robustness against outliers and external                  ∑                                                 ∑                                  (7)
   shocks. By dynamically responding to data volatility, the method                   +     a
                                                                                              {θ0 (γ, τ) + θ1 (γ, τ)(Ut AIt − Uτ AIτ )} +  n
                                                                                                                                             α(γ)(Ut ) + εγ
   minimizes prediction errors and ensures stable estimators, a signifi­                  This equation can also be denoted as (*) except for εγ . The optimi­
   cant improvement over fixed-bandwidth model.                                       zation problem for this equation is given by:

3.3.2. Methodological innovation and application                                      min {β0 , β1 , θ0 , θ1 }                                                               (8)
    Within the MQQR approach, the carbon inequality is characterized
by its γ-quantile, with that quantile modeled as a function of AI and a set
of control variables—namely GDP, population, FDI and energy con­
sumption. This feature outline facilitates isolating intricate relationships




                                                        Fig. 2. Flowchart of empirical analysis steps.

                                                                               1322
B. Bergougui                                                                                                                               Borsa Istanbul Review 25 (2025) 1316–1336

∑                                              ∑
   ϑγ 〈CEIt − β0 − β1 ( AI
                         ̂t − AI  ̂ )−
                                       τ
                                                        {θ0 − θ1 (Ut AI
                                                                              γ
                                                                     ̂t − Uγ AI
                                                                             ̂ )}                   patterns. In the CEI, Singapore stands out with the highest mean
    q                                               n
                   (                 )                                                              inequality level, trailed by the United States and Korea, while China
  ∑                  Dq ( ̂
                          AI t ) − γ                                                                records the lowest average disparity. Singapore and the United States
+      α (γ)(Ut )〉K
     n                     h                                                                        show positive skewness—reflecting frequent moderate shifts punctuated
                                                                                                    by extreme jumps—whereas most other countries exhibit negative
                  τ                        γ
Here, AI      ̂ , Ut AI
         ̂t , AI     ̂t , and Uγ AI
                                 ̂ denote the estimated values for AIt , AIτ ,                      skewness, suggesting heavier lower tails in their inequality distributions.
Ut AIt , and Uτ AIτ , respectively. To address this optimization problem, a                         The majority of CEI distributions are characterized by kurtosis below the
solution for ϑ is necessary. Considering the localized effect of the τ                              Gaussian benchmark, though a handful (including Germany and
quantile of AI, a Gaussian kernel K(⋅) is applied to determine the weight                           Denmark) are leptokurtic. As with AI, Jarque–Bera results universally
   ̂ τ within its domain, with bandwidth h set accordingly. The dif­
of AI                                                                                               reject normality, highlighting the irregular, non-Gaussian dynamics of
                                   τ                                                                emissions inequality. These distributional insights—marked cross-
                ̂t and AI
ference between AI     ̂ is represented by:
                                                                                                    country ranking differences, asymmetric tails, and confirmed non-nor­
               1∑q                                                                                  mality—motivate the use of robust, tail-sensitive estimation methods (e.
Dq ( AI
     ̂t ) =          I( AI
                        ̂ b < AI
                              ̂t )                                                     (9)
               q b=1                                                                                g., quantile regression model) in the core analysis. Furthermore, Mul­
                                                                                                    ticollinearity is evaluated by computing Variance Inflation Factors
4. Empirical findings                                                                               (VIFs) for AI and CEI across ten countries. The VIF measures how much
                                                                                                    the variance of an estimated coefficient is amplified by correlations
4.1. Initial empirical analysis                                                                     among the independent variables. Drawing on thresholds proposed by
                                                                                                    Neter et al. (1996), values above 5 indicate problematic collinearity that
   Before undertaking the core analysis, an initial evaluation of the                               can inflate standard errors and bias parameter estimates. As reported in
logarithmically transformed monthly series is carried out.                                          Table 2, all VIFs in the model fall well below this cutoff, with the largest
                                                                                                    being 4.22. This confirms that multicollinearity does not compromise
4.1.1. Descriptive statistics and distributional properties                                         the results, and the coefficient estimates remain robust.
    Table 2 reports the descriptive statistics and distributional di­
agnostics for both AI adoption and CEI across the ten advanced                                      4.1.2. Quantile-quantile normality assessment
economies.                                                                                              Quantile regression techniques necessitate confirmation of
    For the AI, Japan registers the highest average level, followed closely                         normality. Accordingly, QQ plots were generated to compare each
by the United States and Germany, while Denmark exhibits the lowest                                 variable’s observed quantiles with those expected under a normal dis­
average adoption. Japan and France display right-skewed distribution­                               tribution. As shown in Fig. 3, these plots reveal significant departures
s—indicative of occasional large advances in AI activity—whereas the                                from normality at various points across all datasets. Such irregularities
remaining economies show slight left-skewness or near-symmetry. Most                                point to the data’s complex nature and suggest that the underlying re­
economies exhibit platykurtic or mesokurtic shapes, but a few (notably                              lationships may be skewed. This asymmetry calls into question the
Japan and Italy) show excess kurtosis, pointing to heavier tails. Across                            effectiveness of traditional, mean-focused regression models and sup­
all countries, the Jarque–Bera tests decisively reject normality, under­                            ports the use of quantile-based methods to capture the intricate dy­
scoring persistent deviations from Gaussian behavior in AI diffusion                                namics more accurately at play.



Table 2
Descriptive statistics and distributional properties for CEI and AI.
  Panel A. AI

  Economy                 Descriptive statistics                                                       Distributional properties                             Multicollinearity test

                          Mean                  S.D                  Min.           Max.               Skewness              Kurtosis    JB Stats            VIF

  China                   8.518                 1.841                4.364          10.279             − 0.706               2.219       31.232***           1.817
  Germany                 9.514                 0.282                8.936          9.944              − 0.177               1.968       14.294***           1.871
  Denmark                 5.873                 0.482                4.778          6.484              − 0.621               2.249       25.261***           1.461
  France                  7.972                 0.248                7.452          8.544              0.410                 2.977       8.070***            1.931
  Italy                   8.569                 0.207                8.093          9.032              0.264                 3.001       3.347***            1.311
  Japan                   10.262                0.136                10.08          10.645             0.984                 3.579       50.457***           4.211
  Korea, Rep.             9.330                 0.797                8.060          10.513             − 0.034               1.551       25.262***           4.061
  Singapore               6.577                 0.738                5.653          7.894              0.556                 1.741       33.872***           1.301
  Sweden                  6.762                 0.281                6.262          7.203              − 0.038               1.768       18.292***           1.351
  United States           9.701                 0.404                8.921          10.341             − 0.161               1.969       13.996***           1.421

  Panel B. CEI

  Economy                  Descriptive statistics                                                     Distributional properties                                Multicollinearity test

                           Mean                S.D.                 Min.            Max.              Skewness               Kurtosis    JB Stats              VIF

  China                    1.111               0.271                0.575           1.523             − 0.513                2.041       23.665***             1.530
  Germany                  1.333               0.123                0.940           1.447             − 1.664                4.752       169.672***            1.584
  Denmark                  1.266               0.146                0.845           1.459             − 1.082                3.542       59.670***             1.174
  France                   1.132               0.098                0.964           1.260             − 0.171                1.455       30.043***             1.644
  Italy                    1.181               0.121                0.953           1.337             − 0.147                1.578       25.314***             1.024
  Japan                    1.438               0.066                1.288           1.522             − 0.635                2.317       24.987***             4.114
  Korea, Rep.              1.515               0.094                1.278           1.654             − 0.552                2.300       20.522***             3.774
  Singapore                2.278               0.104                2.141           2.646             1.345                  4.828       126.933***            1.014
  Sweden                   1.176               0.057                1.073           1.294             0.181                  2.127       10.720***             1.064
  United States            1.884               0.114                1.653           2.063             0.037                  1.986       12.407***             1.134

Note. Significance levels of 1% is denoted by ***. Skewness and kurtosis values describe the data distribution, while the Jarque-Bera test assesses normality of the
model’s parameters.

                                                                                             1323
B. Bergougui                                                                                                             Borsa Istanbul Review 25 (2025) 1316–1336




                                                                   Fig. 3. QQ plots.


4.1.3. Linearity test                                                              assesses stationarity across the conditional segmentation of the series.
    The summary statistics initially suggest that the relationships among          Conventional unit-root procedures, while informative, may fail to cap­
the variables may not be strictly linear. To test this formally, the               ture distributional heterogeneity in temporal dynamics. To address this
Brock–Dechert–Scheinkman (BDS) test of linearity (Broock et al., 1996)             limitation, QADF methodology is employed (Adebayo & Özkan, 2024),
is applied, a method commonly employed in recent studies (Bergougui                executing tests at nineteen quantiles (τ = 0.05, 0.10, …, 0.95) as per Li
2024b, 2024c, 2025b; Bergougui et al., 2024a). As shown in Table 3, the            et al. (2015). By scrutinizing individual segments of the distribution in
BDS results provide robust evidence of nonlinearity for each series                depth, one can uncover pockets of non-stationarity that conventional
throughout the sample period. This outcome supports the decision to                tests often miss. Fig. 4 visually presents the QADF test statistics across
utilize the MQQR framework in the subsequent analysis.                             the entire quantile range, providing deep insights into the stationarity
                                                                                   properties of the dataset. The findings confirm that All series become
4.1.4. QADF results                                                                stationary once differenced once, and their stability remains uniform
   Prior to conducting the focal empirical investigation, this study               across the entire conditional distribution.


                                                                            1324
B. Bergougui                                                                                                                  Borsa Istanbul Review 25 (2025) 1316–1336


Table 3
Linearity test results.
  Economy                  Variable              D.2                  D.3                   D.4                 D.5                  D.6                   Decision

  Germany                  CEI                   0.0000               0.0000                0.0000              0.0000               0.0000                Nonlinear
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  China                    CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Denmark                  CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  France                   CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Italy                    CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Japan                    CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Korea, Rep.              CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Singapore                CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  Sweden                   CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000
  USA                      CEI                   0.0000               0.0000                0.0000              0.0000               0.0000
                           AI                    0.0000               0.0000                0.0000              0.0000               0.0000




Fig. 4. QADF outcomes
Note: The green, blue, and red lines in the figures represent the critical values of − 2.58, − 2.89, and − 3.49, corresponding to the 10 %, 5 %, and 1 % significance
levels, respectively.


4.2. MQQR outcomes                                                                     through slope coefficients ρ1(θ, τ), demonstrating how the θth AI
                                                                                       quantile affects the τth CEI quantile. The analysis uncovers distinct
    The MQQR methodology reveals diverse patterns in how AI adoption                   patterns across different country groups:
influences CEI across ten nations. Fig. 5 illustrates these relationships


                                                                                1325
B. Bergougui                                                                                                                    Borsa Istanbul Review 25 (2025) 1316–1336




Fig. 5. MQQR estimations of the slope coefficient
Note: This three-dimensional plot illustrates the computed slope coefficients positioned on the vertical z-axis. The horizontal y-axis displays CEI quantiles, whereas
the x-axis depicts AI quantiles. The color spectrum presented on the right panel indicates coefficient magnitudes, transitioning from blue (lower values) to red (higher
values). Intense red coloration reflects robust positive connections between AI and CEI, while intense blue demonstrates substantial negative associations. Moderate
red tones indicate weaker positive links, and softer blue shades reveal mild inverse connections between AI and CEI. This multidimensional visualization captures the
strength and directional nature of AI-CEI interactions across different quantile scenarios.




                                                                                 1326
B. Bergougui                                                                                                               Borsa Istanbul Review 25 (2025) 1316–1336


4.2.1. First pattern - European nations (Germany, France, Sweden, Italy,               implying that emissions inequality begins to rise. This shift could be
Denmark)                                                                               due to the disproportionate adoption of AI in high-emissions sectors,
                                                                                       exacerbating inequality. As AI continues to spread through the
 • Early Integration (AI quantiles 0.05-0.4): These nations show a                     middle quantiles (0.4–0.8), the negative impact returns, suggesting
   strong positive correlation between AI and CEI, with Germany and                    that AI may be increasingly effective in optimizing emissions re­
   France exhibiting particularly high positive impacts. This suggests                 ductions. Finally, at the highest AI adoption levels (0.85–0.95), the
   initial AI adoption may temporarily increase carbon emissions                       relationship becomes positive again, potentially reflecting the
   inequality, possibly due to: (a) Uneven Technological Adoption: The                 increased energy consumption and complexity associated with more
   early integration of AI often favors industries and sectors that are                advanced AI applications, which may disproportionately benefit
   already well-developed, such as manufacturing and high-tech in­                     certain industries over others.
   dustries, which may disproportionately contribute to higher emis­                 • The USA shows a distinctive AI-CEI trajectory. At lower quantiles
   sions. (b) Initial Infrastructure Adjustments: The adoption of AI in                (0.05–0.3), the impact of AI on CEI is positive, suggesting that early
   energy and industrial systems can initially lead to inefficiencies and              AI adoption leads to increased emissions inequality. However, as AI
   disruptions, exacerbating emissions inequality during the early                     adoption continues into the middle-low quantiles (0.35–0.4), the
   phase of implementation. (c) Learning Curve in Optimization: AI                     relationship shifts to negative, indicating a reduction in emissions
   systems typically require a period of optimization before they begin                inequality. This is followed by a return to positive impact at middle
   to reduce inefficiencies in energy use or carbon emissions, and this                quantiles (0.45–0.65), and a final shift to a negative relationship at
   adjustment phase may temporarily increase emissions inequality.                     the very high quantiles (0.9–0.95). This fluctuating pattern suggests
 • Middle Range (AI quantiles 0.45-0.65): During this phase, most Eu­                  that the USA experiences both positive and negative impacts of AI on
   ropean nations maintain a positive but moderate relationship be­                    emissions inequality, likely due to a mix of advanced AI applications
   tween AI and CEI, indicating a transitional period where AI’s impact                in energy-intensive industries and the country’s diverse economic
   on emissions inequality remains positive but begins to stabilize.                   sectors.
 • Advanced Integration (AI quantiles 0.85-0.95): At high AI adoption
   levels, these nations generally experience a negative correlation with              This analysis reveals that while AI’s impact on carbon emissions
   CEI, particularly evident in Denmark, France, and Sweden at the                  inequality varies significantly across nations and adoption levels, most
   0.9–0.95 quantiles. This suggests that at mature stages of AI inte­              advanced economies show a trend toward reduced emissions inequality
   gration, technology helps reduce carbon emissions inequality. The                at higher levels of AI integration, suggesting that mature AI imple­
   advanced AI systems in these countries are likely to contribute to               mentation may ultimately contribute to more equitable carbon emis­
   improved energy management, optimized resource allocation, and                   sions distributions.
   better regulation of emissions, leading to more equitable carbon
   emissions distributions. This phase underscores the potential of AI to           4.3. Addressing endogeneity concerns
   significantly enhance sustainability outcomes when fully integrated
   into energy systems and industrial practices. Germany maintains a                    The adoption of AI is subject to significant endogeneity challenges,
   positive impact even at high quantiles (0.85–0.95), possibly due to              primarily due to reverse causality. Higher AI integration not only fosters
   its industrial AI focus (e.g., Industry 4.0) optimizing production ef­           innovation in climate technologies and reshapes industrial practices—­
   ficiency without addressing distributional equity.                               thereby influencing carbon emissions inequality—but is also shaped by
                                                                                    broader global technological advancements. This bidirectional rela­
4.2.2. Second pattern - Asian nations (Japan, Singapore, Korea)                     tionship creates a feedback loop, making it difficult to establish clear
                                                                                    causal links between AI adoption and environmental outcomes. The
 • Japan and Singapore show similar patterns: positive impact on CEI at             instrumental variable quantile regression method developed by Cher­
   lower quantiles (0.05–0.4), followed by varying effects in middle                nozhukov and Hansen (2008) and later advanced by Kaplan and Sun
   quantiles, and ultimately a negative impact at higher quantiles                  (2017) is employed to address these concerns. Prior research (Wang
   (0.7–0.95), suggesting AI eventually helps reduce emissions                      et al., 2024; Zhao et al., 2024) has underscored the necessity of cor­
   inequality. This indicates that at more advanced levels of AI inte­              recting for AI adoption endogeneity to prevent biased estimates of its
   gration, these nations begin to realize the benefits of AI in reducing           impact on CO2 emissions inequality. This approach relies on selecting
   emissions inequality, likely through better energy efficiency, cleaner           instruments that are strongly correlated with domestic AI adoption
   technologies, and more equitable resource distribution in the energy             while remaining exogenous to carbon emissions inequality. In the
   sector.                                                                          baseline specification, lagged AI adoption serves as an instrument.
 • In contrast, Korea shows a consistently positive relationship between            Historical levels of AI integration capture the persistence of technolog­
   AI and CEI across all quantiles. The particularly strong effects at the          ical diffusion, making them strong predictors of current adoption trends.
   lower quantiles (0.05–0.1) suggest that AI adoption in Korea may                 Crucially, lagged values are exogenous to present-day emissions distri­
   initially exacerbate emissions inequality. This could be due to factors          butions, thereby addressing concerns related to simultaneity and reverse
   such as rapid industrialization, energy-intensive AI applications, and           causality. Following (Bergougui, 2025a; Cao et al., 2025; Tao et al.,
   an uneven distribution of technological benefits across sectors. The             2024), Lagged AI adoption is incorporated as an instrumental variable
   lack of a transition to a negative impact at higher AI adoption levels           within the IVQR framework. While AI adoption has the potential to
   indicates that Korea may still be in the early or transitional phase of          contribute to emissions reductions and facilitate energy transitions—a
   AI adoption, where the full potential of AI to reduce emissions                  dynamic that may engender a bidirectional causal relationship with
   inequality has yet to materialize.                                               environmental pressures—the employment of lagged variables enables
                                                                                    the isolation of variation that is not confounded by contemporaneous
4.2.3. Unique cases                                                                 environmental factors. Given that carbon emissions inequality is pre­
                                                                                    dominantly influenced by industry-specific technological choices and
 • China exhibits a particularly complex AI-CEI relationship. At the                patterns of energy consumption, this instrumental approach provides a
   very low quantiles (0.05–0.1), the impact of AI on CEI is negative,              rigorous identification strategy. Correcting for endogeneity in this
   suggesting that initial AI adoption may reduce emissions inequality              manner yields more reliable estimates of the causal impact of AI adop­
   in certain sectors. However, as AI adoption progresses through the               tion on CO2 emissions inequality.
   low-middle quantiles (0.15–0.3), the relationship turns positive,                    Building upon this solid methodological foundation, the empirical

                                                                             1327
B. Bergougui                                                                                                               Borsa Istanbul Review 25 (2025) 1316–1336




Fig. 6. IVQR estimations of the slope coefficient
Note: The red solid line represents Two-Stage Least Squares (2SLS) coefficient estimates, while the blue dotted line shows IVQR coefficient estimates with 95 %
confidence intervals across different quantiles.



results visualized in Fig. 6 reveal heterogeneous effects across different           4.4. Robustness analysis
national contexts that are robust to endogeneity corrections. In China, a
consistently positive relationship between AI adoption and CEI across all            4.4.1. KRLS results
quantiles is observed, aligning with the main results. Germany exhibits a                To validate the MQQR findings, the KRLS method is employed,
more nuanced pattern, with positive effects concentrated in low to                   following the framework established by Hainmueller & Hazlett (2014),
middle quantiles—consistent with the MQQR findings (Fig. 5)—but                      to elucidate potential nonlinear relationships. The KRLS-derived
transitioning to negative effects at higher quantiles. Denmark demon­                average marginal effects, documented in Table 5, exhibit statistical
strates similar patterns at upper quantiles, while other analyzed coun­              significance at the 0.01 level. The model demonstrates exceptional
tries maintain relatively consistent effects across their distributions.             predictive capacity across all ten nations under examination, with co­
These results show that AI’s impact on carbon-emission inequality varies             efficient of determination (R2) values surpassing 0.90 uniformly. This
by quantile—sometimes widening and sometimes narrowing dis­                          empirical evidence suggests that Artificial Intelligence adoption ac­
parities—and that this pattern holds even after controlling for                      counts for more than 90 % of the variation in CEI, underscoring its
endogeneity.                                                                         robust predictive efficacy for CEI outcomes. Furthermore, an examina­
    The validity of the instrumental variable approach is confirmed                  tion of the marginal effects at the first (25th), second (50th), and third
through comprehensive diagnostic testing presented in Table 4. First-                (75th) quartiles provides additional support for the presence of a
stage F-statistics assess instrument strength; values above 10 indicate              nonlinear conditional relationship. The patterns observed in both
that weak-instrument bias is unlikely. The Kolmogorov-Smirnov (KS)                   average marginal effects and quartile-specific effects exhibit strong
statistic tests the exogeneity assumption by evaluating whether the in­              concordance with the MQQR estimates, thus substantiating the robust­
struments are correlated with the error term in the structural equation;             ness of the primary findings.
when the KS statistic falls below the 95 % critical value, the null hy­
pothesis of exogeneity cannot be rejected, confirming that the in­                   4.4.2. Multivariate quantile regression (MQR)
struments satisfy the orthogonality condition. Panel A demonstrates that                 A comparative analysis was conducted to evaluate the concordance
all First-Stage F-statistics across quantiles for each of the ten countries          between MQQR and MQR estimates. As depicted in Fig. 7, the findings
significantly exceed the critical threshold of 10, confirming instrument             from the MQQR analysis are substantiated by a strong alignment be­
strength and mitigating weak instrument concerns. Panel B shows that                 tween the average MQQR slope estimates and the MQR values across
the KS statistics consistently fall below their respective 95 % critical             different countries. This consistency underscores a statistically signifi­
values, supporting the exogeneity of the instruments. These diagnostic               cant inverse relationship between AI and CEI under conditions of high AI
results collectively validate that the instrumental variables meet both              adoption. Furthermore, the magnitude of the coefficients indicates that
the relevance and exogeneity requirements, providing confidence in the               the impact of AI on CEI is markedly stronger in countries such as Japan
causal interpretation of the findings.                                               and Singapore, while the effect is less pronounced in other nations. It is
                                                                                     noteworthy that all assessments employ consistent methodologies,
                                                                                     resulting in analogous analytical outcomes.



                                                                              1328
B. Bergougui                                                                                                                                                Borsa Istanbul Review 25 (2025) 1316–1336


Table 4
Instrument strength and exogeneity test results.
  Panel A: Instrument Strength test (First-Stage F-Statistics)

                    Quantile             0.1               0.2                0.3            0.4               0.5                   0.6                  0.7            0.8             0.9

  China             F-statistics         250895.4          84804.05           149216.7       147862.8          29782.45              66325.45             104703.5       102234.8        130247.8
  Germany           F-statistics         28041.98          20111.26           18172.39       18929.18          14902.51              16933.49             26388.83       21876.36        36140.66
  Denmark           F-statistics         13641.98          5711.262           3772.391       4529.179          502.512               2533.491             11988.83       7476.36         21740.66
  France            F-statistics         78024.52          150195.4           162427         135683.7          141243.8              147710.6             139564.6       157102.3        107691.6
  Italy             F-statistics         12241.98          4311.262           2372.391       3129.179          − 897.488             1133.491             10588.83       6076.36         20340.66
  Japan             F-statistics         43041.98          35111.26           33172.39       33929.18          29902.51              31933.49             41388.83       36876.36        51140.66
  Korea             F-statistics         12409.98          4479.262           2540.391       3297.179          − 729.488             1301.491             10756.83       6244.36         20508.66
  Singapore         F-statistics         76792.52          148963.4           161195         134451.7          140011.8              146478.6             138332.6       155870.3        106459.6
  Sweden            F-statistics         11009.98          3079.262           1140.391       1897.179          − 2129.49             − 98.509             9356.83        4844.36         19108.66
  USA               F-statistics         41809.98          33879.26           31940.39       32697.18          28670.51              30701.49             40156.83       35644.36        49908.66

  Panel B: Exogeneity test (KS Statistic)

                          Quantile             0.1               0.2                0.3            0.4               0.5                   0.6                  0.7         0.8             0.9

  China                   KS Stat              0.2923            0.0253             0.0453         0.0313            0.0293                0.0253               0.0283      0.0213          0.0743
                          95 % CV              2.5233            2.3143             2.5263         4.3883            2.5513                3.1983               2.6543      2.9853          1.8963
  Germany                 KS Stat              0.0733            0.0873             0.0243         0.0923            0.6823                0.2623               1.5883      0.1573          0.0493
                          95 % CV              2.8323            2.4203             2.5833         2.3383            1.9153                2.1693               3.3423      2.1573          1.8783
  Denmark                 KS Stat              0.0333            0.1043             0.0993         0.1303            0.0753                0.0343               0.5883      0.8813          0.1173
                          95 % CV              1.9193            2.0853             2.1273         2.5853            1.9043                1.5753               1.9243      1.6733          2.4483
  France                  KS Stat              0.1983            0.0473             0.9293         0.0573            0.0443                0.1093               0.3063      0.0813          0.9703
                          95 % CV              1.7833            1.9053             2.0283         2.7853            2.0583                2.7303               1.8503      2.3053          2.2163
  Italy                   KS Stat              0.0883            0.0233             0.2253         0.0533            1.5533                0.0813               0.1523      0.3193          4.8103
                          95 % CV              2.3743            2.6103             1.6083         1.9433            1.8933                2.3053               1.7883      1.8023          1.8033
  Japan                   KS Stat              0.3653            0.3403             0.0823         1.2023            0.0543                0.0593               0.8813      0.4973          0.0253
                          95 % CV              1.8223            2.0563             1.9343         1.9623            1.9383                1.9293               1.6733      2.8413          2.4123
  Korea, Rep.             KS Stat              0.5053            0.2383             0.2583         0.2443            0.2423                0.2383               0.2413      0.2343          0.2873
                          95 % CV              2.7363            2.5273             2.7393         4.6013            2.7643                3.4113               2.8673      3.1983          2.1093
  Singapore               KS Stat              0.2863            0.3003             0.2373         0.3053            0.8953                0.4753               1.8013      0.3703          0.2623
                          95 % CV              3.0453            2.6333             2.7963         2.5513            2.1283                2.3823               3.5553      2.3703          2.0913
  Sweden                  KS Stat              0.2463            0.3173             0.3123         0.3433            0.2883                0.2473               0.8013      1.0943          0.3303
                          95 % CV              2.1323            2.2983             2.3403         2.7983            2.1173                1.7883               2.1373      1.8863          2.6613
  United States           KS Stat              0.4113            0.2603             1.1423         0.2703            0.2573                0.3223               0.5193      0.2943          1.1833
                          95 % CV              1.9963            2.1183             2.2413         2.9983            2.2713                2.9433               2.0633      2.5183          2.4293




Table 5
KRLS average marginal effects of AI on CEI.
  Economy                      Average                  S.E.              t                        P>t                     P25                      P50                  P75                   R2

  China                        0.019                    0.001             26.122                   0.000                   − 0.013                  0.017                0.052                 0.996
  Germany                      − 0.127                  0.007             − 17.347                 0.000                   − 0.200                  − 0.144              − 0.081               0.994
  Denmark                      − 0.035                  0.002             − 14.063                 0.000                   − 0.072                  − 0.044              0.004                 0.996
  France                       0.045                    0.006             7.795                    0.000                   0.006                    0.040                0.102                 0.994
  Italy                        − 0.137                  0.004             − 35.884                 0.000                   − 0.213                  − 0.171              − 0.058               0.997
  Japan                        0.199                    0.007             29.008                   0.000                   0.020                    0.270                0.318                 0.995
  Korea                        0.042                    0.005             7.750                    0.000                   − 0.012                  0.071                0.090                 0.961
  Singapore                    0.094                    0.010             9.124                    0.000                   − 0.002                  0.048                0.171                 0.914
  Sweden                       − 0.109                  0.006             − 17.133                 0.000                   − 0.221                  − 0.162              0.082                 0.981
  United States                − 0.057                  0.003             − 19.581                 0.000                   − 0.092                  − 0.074              − 0.034               0.993

Note: S.E. Standard error.


5. Discussion of outcomes                                                                                • China – In China the quantile analysis shows a mixed pattern: early
                                                                                                           AI adoption initially reduces CEI (negative correlation at low quan­
    The relationship between AI adoption and CEI exhibits distinct pat­                                    tiles), but higher AI maturity is associated with rising CEI. This de­
terns across national contexts, each molded by specific industrial con­                                    viation likely reflects China’s heavy industrial structure and energy
figurations, energy mixes, and environmental policy environments.                                          mix. Coal still dominates China’s power supply (~56 % of energy
Quantile regression results—presented in Fig. 5 and summarized in                                          mix)2 and industry (steel, cement, manufacturing) remains carbon-
Fig. 8—demonstrate that high levels of AI adoption are associated with                                     intensive (Li et al., 2020). Early AI-driven efficiency gains in
reduced CEI in approximately 70 percent of the countries analyzed.                                         manufacturing may lower emissions for wealthier regions, but as AI
These findings corroborate earlier work (Ma et al., 2025) on AI’s ca­                                      spreads its net effect can increase total output (and thus emissions)
pacity to mitigate carbon inequality and further reveal that its effects                                   faster than equitable benefits accrue. Inadequate environmental
vary nonlinearly across the distribution. The mechanisms driving these                                     regulation in rapidly developing regions may also mean AI boosts
outcomes depend critically on factors such as sectoral composition, the                                    production (and emissions) among high-income producers without
proportion of renewable versus fossil-fuel energy, and the stringency of                                   proportionally reducing emissions elsewhere. These dynamics
climate regulations. The following country-by-country review explores
how AI maturity interacts with each nation’s unique industrial and en­
ergy profile.                                                                                          2
                                                                                                         See “The Carbon Brief Profile: China.” Available at: https://interactive.carb
                                                                                                     onbrief.org/the-carbon-brief-profile-china/index.html.

                                                                                              1329
B. Bergougui                                                                                                                 Borsa Istanbul Review 25 (2025) 1316–1336




Fig. 7. Comparing MQQR and MQR estimates of AI’s Impact on CEI
Note: The red solid line represents the average MQQR estimates of AI effects across various CEI quantiles, while the blue solid line shows conventional
MQR estimates.




      contrast with the general pattern of AI-enabled decarbonization                       coal (Lund et al., 2022). Yet its economy is also small and wealthy
      observed in many advanced economies.                                                  with significant manufacturing exports (pharmaceuticals, machin­
                                                                                            ery) and high per-capita consumption (Smith et al., 2019). In prac­
 • Germany – Germany exhibits a persistently positive AI–CEI rela­                          tice, early AI uptake may have been driven by high-income industrial
   tionship across all adoption levels (AI increases CEI), a clear devia­                   and tech sectors, temporarily widening emissions gaps (rich users
   tion. Although Germany is a leader in renewables (phasing out coal                       scale up operations). Once AI is mature, however, Denmark’s green
   and nuclear under the Energiewende), its industrial sector still ac­                     infrastructure allows AI-driven optimization (smart grids, efficient
   counts for ~23 % of emissions.3 German industry (automotive, ma­                         industry) to significantly reduce emissions inequality. This pattern
   chinery, chemicals) is highly automated and resource intensive                           deviates from the general uniform decrease of CEI with AI, empha­
   (Rottner and von Graevenitz 2024). If AI deployment so far has been                      sizing how a highly renewable grid and small economy can invert
   concentrated in advanced manufacturing and high-income urban                             early-AI effects.
   sectors, it may simply amplify productivity (and consumption)                          • France – Like Denmark (and Italy), France’s early/middle AI phases
   without immediately improving equity in emissions. In other words,                       have a positive CEI correlation (AI seems to widen the gap), while
   AI may enable high emitters (wealthy firms or regions) to increase                       mature AI adoption yields a negative effect on CEI. France’s elec­
   output before significant energy savings take hold. This countertrend                    tricity is ~66 % nuclear, giving it a very low-carbon power mix. Its
   could also reflect Germany’s strong export orientation and rebound                       industrial base (aerospace, auto, agri-food) is significant but over­
   from recent energy crises: firms have relied on high-carbon fuels (e.g.                  shadowed by services (Le-Boulch et al., 2024). Early AI deployment
   coal imports in 2022) to sustain production (Denisenko 2022). In                         by wealthy industries or urban centers may initially increase emis­
   sum, despite Germany’s green policy framework, the initial AI in­                        sions through higher energy use or consumption, especially if in­
   fluence appears to exacerbate emissions inequality – a departure                         novations target production rather than efficiency. But as AI
   from the global trend of AI reducing carbon intensity.                                   matures, its integration with France’s clean grid and strict environ­
 • Denmark – Denmark shows a positive AI–CEI correlation at low and                         mental regulations (EU carbon caps, carbon tax) allows net re­
   middle adoption (AI adoption initially raises CEI) but flips to a                        ductions in emissions inequality. The initial deviation could also
   negative correlation at high adoption. Denmark’s energy profile is                       stem from uneven regional development (Paris vs. rural areas) and a
   highly decarbonized – over 82 % of its electricity comes from re­                        temporary surge in digital consumption that precedes full deploy­
   newables (wind, biomass, solar)– and it has aggressively phased out                      ment of efficiency gains.
                                                                                          • Italy – Italy mirrors the France/Denmark pattern: AI initially cor­
                                                                                            relates with higher CEI, then lower CEI at high adoption. Italy’s
  3
    Heavy industry remains a major source of Germany’s greenhouse gas
emissions, posing significant challenges to decarbonization efforts. Despite
ambitious climate targets, emission reductions are constrained by the structural
dependence on fossil fuels and the burden of high energy costs in industrial
sectors. See: Clean Energy Wire.

                                                                                   1330
B. Bergougui                                                                                                                Borsa Istanbul Review 25 (2025) 1316–1336




                                     Fig. 8. AI and CEI relationship: Quantile-based analysis across different countries.


   energy mix still relies on gas (38 %) and oil (36 %) with limited coal,             energy-intensive sectors and elevated energy consumption in
   and renewables/other forms share ~24 % 4. Its industrial north                      affluent urban areas (Tokyo/Kansai), raising CEI. Later, as AI ma­
   (machinery, automotive) contrasts with an agricultural south. The                   tures, its use in robotics and process optimization (Japan being a
   initial positive AI–CEI effect may arise because wealthy northern                   leader in industrial automation) begins to yield efficiency gains and
   industries or urban households ramp up AI-driven activity (industrial               carbon savings (Wang et al., 2025). This transition is facilitated by
   automation, smart logistics) that increases total emissions before                  Japan’s progressive climate policies and promotion of
   efficiency improvements dominate. Italy’s moderate environmental                    energy-efficient technology. Thus, the deviation – positive at low AI –
   policies (relative to Northern Europe) and delayed renewable                        is due to Japan’s legacy energy mix and the sequencing of AI de­
   expansion may also delay the benefits of AI-driven optimization                     ployments, while the eventual negative high-quantile relationship
   (Esposito and Romagnoli 2023). In the mature adoption stage,                        follows once AI-driven innovation meshes with long-term decar­
   however, continued expansion of solar/wind and regulatory efforts                   bonization plans.
   (EU targets, incentives for efficiency) allow AI to realize carbon cuts           • South Korea – South Korea exhibits AI-driven increases in CEI at all
   more fully, inverting the early trend.                                              adoption levels, opposite to the norm. Its industrial landscape
 • Japan – Japan shows a similar profile: AI increases CEI at low                      (semiconductors, ships, steel, petrochemicals) is resource-intensive,
   quantiles, mixed at intermediate, and decreases CEI at the highest                  and the power sector still heavily uses coal and nuclear (renew­
   quantiles. Japan’s economy is high-tech with major manufacturing                    ables are only ~10 % of power)5. Rapid AI expansion in electronics
   (automobiles, electronics, semiconductors) but its energy mix is still              and data centers has boosted electricity demand, and with the cur­
   reliant on fossil fuels (since the 2011 nuclear shutdown) (IEA 2025a).              rent energy mix, this has raised emissions predominantly in affluent
   Early on, AI adoption may have fueled production in                                 industrial regions. Korea’s relatively modest carbon pricing and



  4                                                                                   5
    See,   https://www.trade.gov/country-commercial-guides/italy-natural-g               See, https://ieefa.org/resources/south-koreas-11th-power-plan-makes-part
as-renewable-energy                                                                 ial-progress-towards-decarbonization

                                                                             1331
B. Bergougui                                                                                                                 Borsa Istanbul Review 25 (2025) 1316–1336


   ongoing emphasis on growth mean these emissions are not fully                       framework not only addresses potential endogeneity but also enriches
   offset by AI efficiencies yet. In short, AI has so far reinforced existing          understanding of how AI adoption influences CEI across diverse eco­
   inequalities in South Korea, likely because deployment is concen­                   nomic landscapes. The analysis uncovers distinct patterns in the inter­
   trated in large conglomerates and urban centers without sufficient                  play between AI adoption and CEI across ten leading nations. Among
   policy to channel AI toward decarbonization.                                        European countries such as Germany, France, Sweden, Italy, and
 • Singapore – Singapore’s pattern is like Japan and France: early AI                  Denmark, a three-phase trajectory is observed. In the early stages (AI
   increases CEI, while mature AI correlates with lower CEI. Singa­                    quantiles 0.05–0.4), a strong positive association indicates that the
   pore’s climate is hot and humid, demand for cooling is high, and its                initial integration of AI tends to exacerbate emissions inequality, likely
   electricity is 94.3 % natural gas (Liddle et al., 2020). Being a                    due to uneven technological dissemination, infrastructural adjustments,
   high-income city-state, early AI adoption (in finance, tech, industry)              and the inherent learning curve. As these nations progress to the middle
   has increased energy use (data centers, services) and thus tempo­                   quantiles (0.45–0.65), the relationship moderates, suggesting a transi­
   rarily raised emissions inequality. However, Singapore also has                     tional period where the disruptive impacts begin to stabilize. At
   strong sustainability policies (carbon tax, smart-nation initiatives)               advanced integration levels (AI quantiles 0.85–0.95), a marked negative
   and is investing heavily in solar (including floating PV) and imported              correlation emerges—particularly in Denmark, France, and Swe­
   renewables (Loh and Bellam 2024). At higher AI levels, these factors                den—signifying that mature AI systems contribute to a more equitable
   allow AI-driven smart energy systems and efficiency measures (e.g.,                 distribution of carbon emissions through enhanced energy management
   smart grids, building management) to narrow emissions gaps. The                     and resource optimization. Notably, Germany exhibits a persistent
   initial deviation reflects Singapore’s lack of domestic low-carbon                  positive effect even at high adoption levels, possibly reflecting its
   energy and very high per-capita consumption, whereas later prog­                    distinctive focus on industrial AI within the framework of Industry 4.0.
   ress shows how targeted technology integration can yield equity                     Asian economies display varying trajectories. Japan and Singapore
   gains.                                                                              follow a pattern where the initial positive impact on CEI at lower
 • Sweden – Sweden stands out for having negative AI–CEI correlation                   quantiles eventually shifts to a negative influence at higher quantiles,
   at mature adoption (AI reduces CEI) despite some early positive ef­                 implying that advanced stages of AI integration facilitate reductions in
   fects. Sweden’s electricity is overwhelmingly zero-carbon (hydro,                   emissions inequality. In contrast, Korea maintains a consistently positive
   nuclear, growing wind) (IEA 2025b) and it has very high carbon                      relationship across all quantiles, suggesting that the benefits of AI in
   prices and strict climate policy. Still, its high-income population and             mitigating emissions inequality remain unrealized, perhaps due to rapid
   industrial sectors (paper, steel, automotive) can see early AI use raise            industrial expansion and energy-intensive applications. The relationship
   emissions through increased consumption. However, Sweden’s                          in other major economies is similarly multifaceted. China presents a
   comprehensive energy transition – district heating, bioenergy,                      particularly complex scenario, with AI’s impact on CEI oscillating be­
   renewable electricity – means that once AI adoption is advanced, it                 tween negative and positive effects at different adoption stages. The
   almost uniformly lowers CEI (as demonstrated by the analysis). In                   United States, meanwhile, demonstrates an alternating pattern that re­
   fact, Sweden’s strong welfare system and emphasis on social equity                  flects the heterogeneity of its economic sectors and varied applications
   may also help distribute AI’s benefits (Park and Humphry 2019).                     of AI technology. Overall, the findings reveal that in approximately 70 %
   This combination of a clean energy base and equitable policies likely               of the examined economies, more mature levels of AI implementation
   explains why Sweden aligns with the general global pattern (AI →                    are associated with lower carbon emissions inequality—a conclusion
   lower CEI) more fully than many peers.                                              that aligns with data from the World Economic Forum’s Global AI Index
 • United States – The U.S. exhibits a mixed pattern: AI is initially                  2024, which documents significant reductions in carbon inequality due
   associated with higher CEI at lower quantiles (positive correlation)                to AI-driven innovations. By enhancing energy efficiency and opera­
   and lower CEI at high quantiles (negative correlation). The U.S.                    tional precision, AI, particularly through the deployment of industrial
   economy is very large and diverse: significant fossil fuel use in                   robotics, appears capable of narrowing the gap in carbon emissions
   transport and power, but also vast IT and services sectors (Adebayo                 among diverse income groups. This study thus positions artificial in­
   et al., 2023). Wealthier Americans and large corporations have been                 telligence not only as an engine of economic progress but also as a
   early AI adopters (data centers, automation) which has increased                    transformative instrument for advancing environmental equity. The
   energy demand, while AI efficiencies have yet to fully penetrate                    asymmetric and context-specific dynamics uncovered by the research
   (Khogali and Mekid 2023). Over time, however, AI applications in                    underscore the need for nuanced, adaptive policy frameworks. As na­
   grid management, manufacturing and energy efficiency are expected                   tions progress through various stages of AI integration, it becomes
   to kick in. The turn in sign at high quantiles likely reflects im­                  crucial to implement tailored interventions that mitigate the short-term
   provements in renewable capacity (solar and wind grew ~20 %                         risks of increased emissions inequality while fostering long-term sus­
   annually) and technology (smart grids, EVs) that come online at                     tainability and equitable outcomes.
   scale, enabling AI to start reducing overall emissions inequality as
   adoption matures. The initial positive deviation is due to the U.S.’s               6.2. Policy recommendations
   high consumption patterns and varied policy landscape; the eventual
   negative slope matches the broader trend of mature AI deployment                        This study uncovers a nuanced, dual-edged dynamic between AI
   aiding carbon equity.                                                               adoption and carbon-emissions inequality: AI can both promote envi­
                                                                                       ronmental equity and exacerbate existing disparities. Three interlocking
6. Conclusion and policy recommendations                                               factors—AI’s maturity, regional economic structures, and the regulatory
                                                                                       environment—dictate which outcome prevails. On one hand, AI-enabled
6.1. Conclusion                                                                        optimizations in energy grids and industrial processes offer unprece­
                                                                                       dented opportunities to narrow emissions gaps. On the other hand, AI’s
   In an era defined by rapid technological progress and growing                       high-power demands, uneven geographic rollout, and potential job
environmental concerns, this study delves into the intricate relationship              displacements introduce new equity challenges requiring sophisticated
between industrial robotics and environmental inequality from 1980/                    policy responses. Robust governance is vital. The OECD AI Principles
M1 to 2023/M12. By harnessing advanced quantile-based techni­                          (2019) emphasize transparency, accountability, and human-centered
ques—including MQQR and IVQR—complemented by robustness tests                          design, ensuring that AI deployment aligns with broader social objec­
with MQR and KRLS, the research captures the non-linear dynamics that                  tives. Complementing these guidelines, the EU AI Act adopts a risk-based
unfold across different distribution levels. This comprehensive                        approach—mandating rigorous impact assessments and embedding

                                                                                1332
B. Bergougui                                                                                                            Borsa Istanbul Review 25 (2025) 1316–1336


equity safeguards into regulation. Together, these frameworks provide                 deployment in areas like manufacturing, ensuring displaced workers
the institutional foundation for integrating carbon-equity metrics                    move into green tech roles.
directly into national AI strategies. Building on these international               • Italy – Italy’s recommendations should combine EU-level initiatives
standards, tailored policy portfolios are needed to reflect each country’s            with national action. The government could tie Next Generation EU
unique AI adoption trajectory and emissions profile. Key interventions                funds to AI projects that reduce CEI (for instance, smart
include progressive carbon pricing that accounts for AI’s energy in­                  manufacturing in the industrial north and energy-efficient retrofits in
tensity, targeted subsidies for clean-tech innovation, comprehensive                  buildings). A progressive carbon tax on AI-fueled emissions (e.g.,
workforce transition programs, and regulatory mandates to ensure                      higher rates for oil and gas usage in automated systems) would help
equitable AI deployment across sectors and regions. The following sec­                internalize environmental costs. The Italian Climate Decree could
tion presents ten country-specific packages that leverage these tools to              require AI impact analyses for large infrastructure projects (such as
harness AI’s equity-enhancing potential while mitigating its risks.                   high-speed rail or ports). In agriculture and tourism (key Italian
                                                                                      sectors), promoting AI-driven efficiency (precision agriculture, smart
 • China – Given that mature AI adoption currently correlates with                    airports) could help counteract urban AI inequalities. Finally, na­
   higher CEI, Chinese policy should steer AI toward emissions-                       tional policies should encourage more renewables (solar and wind)
   reducing applications. This could involve differentiated carbon                    in the south, ensuring that AI-driven digital growth does not leave
   pricing that raises the cost of fossil-based AI deployments and sub­               regions behind.
   sidies for AI in clean tech (e.g., smart grids, carbon capture). Regu­           • Japan – Japan’s policy should leverage its technical expertise to
   lations should require emissions reporting in AI-intensive industries,             keep AI carbon-positive. Carbon pricing in Japan could be made
   holding companies accountable for their climate impacts. China can                 more progressive, raising rates on industrial energy use while giving
   strengthen its industrial policy by promoting AI for resource effi­                rebates for AI-powered clean-tech innovation. Government grants
   ciency in steel, cement, and power (e.g., AI-controlled carbon cap­                and public procurement could favor AI systems that improve effi­
   ture, grid stability). Technology transfer programs (possibly                      ciency in sectors like transport (e.g., AI-optimized rail networks) and
   South–South cooperation) can help spread low-carbon AI in­                         housing (smart energy management). To address the early CEI rise,
   novations to lagging provinces. In combination, these measures align               Japan should fund transitional workforce programs for energy-sector
   AI incentives with China’s “dual carbon” goals, ensuring that AI-                  workers and incentivize AI firms to invest in rural or declining areas.
   driven growth does not exacerbate regional inequalities.                           The existing Society 5.0 initiative can explicitly incorporate carbon
 • Germany – Germany must integrate AI strategies into its Ener­                      equity: for example, requiring AI research institutes to partner with
   giewende. For example, AI innovation grants and tax incentives                     local communities on smart-grid or hydrogen projects. Such mea­
   should favor projects that demonstrably lower CEI, such as AI-                     sures would help ensure AI deployment supports Japan’s net-zero
   managed renewable energy balancing, smart manufacturing that                       targets without leaving parts of society worse off.
   reduces waste, or AI-driven carbon capture. Stronger EU ETS link­                • South Korea – South Korea faces the toughest challenge, as AI
   ages (e.g., adjusting free allocations in heavy industries based on AI-            currently worsens CEI. Policies must urgently redirect AI into low-
   driven emissions performance) could ensure high-emitters pay for                   carbon channels. This could include strict emission standards for
   AI-induced inequality. National programs (like carbon contracts for                data centers and semiconductor fabs (e.g., only operating with
   difference) could finance AI R&D in traditionally lagging sectors (e.              renewable electricity) and incentives for on-site renewables. The
   g., energy-intensive manufacturing). Germany should also mandate                   new “Energy Trifecta” reforms should integrate AI by funding digital
   CEI impact assessments for large AI deployments and promote                        technologies in wind/solar (predictive maintenance, grid balancing).
   transparent data on AI and emissions. By explicitly tying AI funding               Government R&D can prioritize AI in carbon-intensive industries
   to climate targets (for instance, requiring AI systems to improve                  (steel, petrochemicals) to improve processes or develop new mate­
   energy efficiency by a set percentage), policymakers can reverse the               rials. Korea should also expand carbon trading to the corporate level,
   current trend of AI increasing CEI.                                                making companies pay for AI-driven emissions and use revenues to
 • Denmark – Danish policy should capitalize on its renewable grid.                   fund distributed solar/wind in underdeveloped regions. Interna­
   Early-AI policies could include incentives for AI in energy flexibility            tionally, Korea can adopt partnership programs (e.g., with ASEAN
   (e.g., smart demand response) to mitigate the initial CEI rise. Carbon             neighbors) to share best practices for AI decarbonization.
   taxation is already strong in Denmark; it should be adjusted pro­                • Singapore – Singapore’s policies must mitigate AI’s initial CEI spike
   gressively to ensure that any high-emitting AI applications (such as               while capitalizing on its clean-tech ambitions. Singapore already has
   energy-hungry data centers) face higher marginal costs. Investments                a carbon tax; this could be made more progressive by increasing rates
   in rural broadband and education would spread AI benefits beyond                   on power used by high-energy AI facilities (data centers, chip fabs).
   urban centers, preventing regional disparities. Denmark’s Green                    The government should prioritize green power purchases for major
   Energy Council could host AI-for-decarbonization testbeds, sharing                 AI projects and continue investing in offshore and floating solar
   best practices internationally. Importantly, as AI matures, policies               (target 2 GW by 2030). Urban planning must integrate AI: for
   should encourage its use in sectors like heating and transport (e.g.,              example, mandating energy-performance contracts for AI-integrated
   AI-managed district heating, electrified public transit) to reinforce              buildings. Socially, subsidies or tax credits for AI-driven energy
   the observed late-stage reductions in CEI.                                         savings in lower-income housing can narrow equity gaps. Singa­
 • France – France should align AI with its low-carbon energy system.                 pore’s Smart Nation initiative could require CEI reporting for AI
   Existing structures (e.g., the nuclear fleet) could benefit from AI                services (like smart transportation apps) to ensure transparency.
   maintenance and optimization, so public funding for AI in grid                     Finally, given Singapore’s leadership in tech, it can export its AI-
   management should be expanded. Policies could impose high-                         smart city models (smart grids, congestion pricing) as part of inter­
   territorial prices or taxes on emissions for AI-driven projects in                 national climate cooperation.
   high-inequality sectors (transport, heating), using revenues to sup­             • Sweden – Sweden’s success suggests a policy focus on scaling and
   port energy retrofits in poorer regions. France’s national AI strategy             exporting best practices. Domestically, maintain high carbon prices
   could include a mandate that AI startups evaluate carbon impact as                 and continue support for AI in renewables (the government already
   part of their licensing. Furthermore, carbon contracts for industrial              funds AI4Energy projects). Encourage cross-sector AI collaboration
   AI projects (e.g., AI in factory automation) could require concrete                (for example, between automotive firms and utilities on smart
   emissions targets. To address the early-phase increase in CEI, tran­               charging) to sustain CEI gains. Internationally, Sweden can host
   sitional assistance (retraining programs) should accompany AI                      policy laboratories and share its AI governance model (integrating

                                                                             1333
B. Bergougui                                                                                                                                         Borsa Istanbul Review 25 (2025) 1316–1336


   carbon equity) with other nations via EU forums or bilateral aid.                                     novel time-frequency approaches. Journal of Environmental Management, 328, Article
                                                                                                         116987. https://doi.org/10.1016/j.jenvman.2022.116987
   Given Sweden’s holistic approach, policymakers should continue to
                                                                                                     Adebayo, T. S., & Özkan, O. (2024). Evaluating the role of financial globalization and oil
   emphasize social equity in tech (ensuring universal digital access,                                   consumption on ecological quality: A new perspective from quantile-on-quantile
   funding education in green AI) to keep the CEI downward trend                                         granger causality. Heliyon, 10, Article e24636. https://doi.org/10.1016/j.
   robust.                                                                                               heliyon.2024.e24636
                                                                                                     Al-Qubati, A., Zhang, L., & Forkel, M. (2024). Urban and peri-urban agriculture under
 • United States – – U.S. policy should harness AI’s scale while safe­                                   climate change: A review on carbon emissions and sequestration. Sustainable Cities
   guarding equity. Federal initiatives (like the Inflation Reduction Act                                and Society, 115, Article 105830. https://doi.org/10.1016/j.scs.2024.105830
   and CHIPS Act) can explicitly favor AI R&D with carbon-saving                                     Alam, K. S., Kaif, A. M. A. D., & Das, S. K. (2024). A blockchain-based optimal peer-to-
                                                                                                         peer energy trading framework for decentralized energy management with in a
   outcomes (e.g., smart-grid technology, AI in precision agriculture).                                  virtual power plant: Lab scale studies and large scale proposal. Applied Energy, 365,
   A combination of cap-and-trade expansion (or a carbon price) and                                      Article 123243. https://doi.org/10.1016/j.apenergy.2024.123243
   targeted tax credits for clean AI (such as deploying AI for methane                               Alola, A. A., Özkan, O., & Usman, O. (2023). Examining crude oil price outlook amidst
                                                                                                         substitute energy price and household energy expenditure in the USA: A novel
   leak detection) would align incentives. Since state policies vary                                     nonparametric multivariate qqr approach. Energy Economics, 120, Article 106613.
   widely, the federal government could incentivize CEI impact as­                                       https://doi.org/10.1016/j.eneco.2023.106613
   sessments for any AI project receiving public funds. To counteract                                Alowais, S. A., Alghamdi, S. S., Alsuhebany, N., et al. (2023). Revolutionizing healthcare:
                                                                                                         The role of artificial intelligence in clinical practice. BMC Medical Education, 23, 689.
   early inequalities, workforce development programs in hard-hit                                        https://doi.org/10.1186/s12909-023-04698-z
   sectors (energy, manufacturing) are critical. By embedding carbon                                 Apeti, A. E., Bambe, B. W. W., Edoh, E. D., & Ly, A. (2025). Wealth inequality and carbon
   metrics into AI funding and regulation, U.S. policy can ensure that as                                inequality. Ecological Economy, 227, Article 108406. https://doi.org/10.1016/j.
                                                                                                         ecolecon.2024.108406
   AI adoption matures, it contributes to both growth and a fair
                                                                                                     Ashley, R., Granger, C. W. J., & Schmalensee, R. (1980). Advertising and aggregate
   reduction in carbon emissions.                                                                        consumption: An analysis of causality. Econometrica, 48, 1149. https://doi.org/
                                                                                                         10.2307/1912176
                                                                                                     Audi, M., Ali, A., & Roussel, Y. (2021). Aggregate and disaggregate natural resources
6.3. Limitations and future research Directions                                                          agglomeration and foreign direct investment in France. International Journal of
                                                                                                         Economics and Financial Issues, 11, 147–156. https://doi.org/10.32479/ijefi.10869
                                                                                                     Autor, D., & Salomons, A. (2018). Is automation labor-displacing? Productivity growth,
    While this study provides critical insights into AI’s relationship with                              employment, and the labor share. National Bureau of Economic Research.
CEI, several limitations warrant further exploration. Geographically, the                            Awogbemi, O., Kallon, DV Von, & Kumar, K. S. (2024). Contributions of artificial
focus on ten technologically advanced nations limits generalizability to                                 intelligence and digitization in achieving clean and affordable energy. Intell Syst with
                                                                                                         Appl, 22, Article 200389. https://doi.org/10.1016/j.iswa.2024.200389
diverse economies, including emerging markets in the Global South,                                   Bergougui, B. (2024a). Moving toward environmental mitigation in Algeria: Asymmetric
resource-dependent states, and regions with unique energy systems (e.                                    impact of fossil fuel energy, renewable energy and technological innovation on CO2
g., Middle Eastern oil exporters). Future research should expand to G-20                                 emissions. Energy Strategy Reviews, 51, Article 101281. https://doi.org/10.1016/j.
                                                                                                         esr.2023.101281
economies, BRICS nations, and the European Union to capture varied                                   Bergougui, B. (2024b). Algeria’s pathway to COP28 and SDGs: Asymmetric impact of
policy environments and structural conditions.                                                           environmental technology, energy productivity, and material resource efficiency on
    Data aggregation at the national level obscures intra-country dy­                                    environmental sustainability. Energy Strategy Reviews, 55, Article 101541. https://
                                                                                                         doi.org/10.1016/j.esr.2024.101541
namics, such as urban-rural divides in AI access or sector-specific
                                                                                                     Bergougui, B. (2024c). Investigating the relationships among green technologies,
emission patterns. Firm-level analyses, particularly in industries like                                  financial development and ecological footprint levels in Algeria: Evidence from a
manufacturing and logistics, could reveal how micro-level AI adoption                                    novel Fourier ARDL approach. Sustainable Cities and Society, 112, Article 105621.
                                                                                                         https://doi.org/10.1016/j.scs.2024.105621
strategies influence CEI. Similarly, spatial econometric models—applied
                                                                                                     Bergougui, B. (2025a). Industrial robots for a sustainable future: Uncovering the
to subnational data from China’s provinces or U.S. states—could un­                                      asymmetric effects of AI on ecological quality in G7 economies. Technology in Society.
cover regional spillover effects and geographic interdependencies in AI-                                 , Article 103021. https://doi.org/10.1016/j.techsoc.2025.103021
driven emissions.                                                                                    Bergougui, B. (2025b). Circular Pathways to Sustainability: Asymmetric Impacts of the
                                                                                                         Circular Economy on the EU’s Capacity Load Factor. Land, 14(6), 1216. https://doi.
    Methodologically, while MQQR and IVQR techniques capture non-                                        org/10.3390/land14061216
linear relationships, they face constraints in modeling temporal dy­                                 Bergougui, B., Ben-Salha, O., & Murshed, S. M. (2025). How income inequality drives
namics and interaction effects. Future studies could integrate quantile                                  climate inequality in the world’s largest emitting nations: Novel evidence from
                                                                                                         multivariate quantile-on-quantile and wavelet quantile methods. Journal of Cleaner
ARDL models to explore long-term relationships between AI and CEI,                                       Production. , Article 145666. https://doi.org/10.1016/j.jclepro.2025.145666
alongside machine learning tools to handle high-dimensional datasets.                                Bergougui, B., Boudjana, R. H., Mehibel, S., & Zambrano-Monserrate, M. A. (2024a).
Spatial econometric approaches, though challenging in cross-national                                     How do institutional quality and income asymmetrically affect carbon emissions
                                                                                                         inequality? A quantile-on-quantile assessment for six major global emitters. Journal
contexts, are critical for understanding how AI adoption in one region                                   of Cleaner Production. , Article 144215. https://doi.org/10.1016/j.
impacts neighboring areas’ emissions profiles.                                                           jclepro.2024.144215
    Finally, the ethical dimensions of AI-driven environmental gover­                                Bergougui, B., Doğan, B., Ghosh, S., & Ayad, H. (2024b). Impact of environmental
                                                                                                         technology, economic complexity, and geopolitical risk on carbon emission
nance remain underexplored. Questions of accountability for algo­
                                                                                                         inequality in developed and developing countries: Evidence from a PVAR-GMM
rithmic bias in emissions tracking, equity in AI’s labor market impacts,                                 approach. Environment, Development and Sustainability. https://doi.org/10.1007/
and the geopolitical implications of technology-driven climate strategies                                s10668-024-05715-x
                                                                                                     Berti, K., Bienvenido-Huertas, D., Rubio-Bellido, C., & Romero-Recuero, I. (2025).
require interdisciplinary scrutiny. Addressing these gaps will ensure AI
                                                                                                         Changing climate in Italian cities and Italian building regulations: Analysis focused
becomes a force for both ecological sustainability and social justice.                                   on future climate change scenarios. Urban Climate, 61, Article 102408. https://doi.
                                                                                                         org/10.1016/j.uclim.2025.102408
                                                                                                     Borland, J., & Coelli, M. (2017). Are robots taking our jobs? The Australian Economic
Authorship contribution statement                                                                        Review, 50, 377–397. https://doi.org/10.1111/1467-8462.12245
                                                                                                     Boyd, R., & Holton, R. J. (2017). Technology, innovation, employment and power: Does
   [1] Brahim Bergougui: estimation, methodology, editing, supervi­                                      robotics and artificial intelligence really mean social transformation? Journal of
                                                                                                         Sociology, 54, 331–345. https://doi.org/10.1177/1440783317726591
sion, conceptualization, abstract, discussion, data curation, conclusion.
                                                                                                     Broock, W. A., Scheinkman, J. A., Dechert, W. D., & LeBaron, B. (1996). A test for
                                                                                                         independence based on the correlation dimension. Econometric Reviews, 15,
References                                                                                               197–235. https://doi.org/10.1080/07474939608800353
                                                                                                     Buchanan, B. G. (2019). Artificial intelligence in finance.
                                                                                                     Camaréna, S. (2020). Artificial intelligence in the design of the transitions to sustainable
Acemoglu, D., & Restrepo, P. (2018). The race between man and machine: Implications
                                                                                                         food systems. Journal of Cleaner Production, 271, Article 122574. https://doi.org/
   of technology for growth, factor shares, and employment. The American Economic
                                                                                                         10.1016/j.jclepro.2020.122574
   Review, 108, 1488–1542. https://doi.org/10.1257/aer.20160696
                                                                                                     Cao, Q., Chi, C., & Shan, J. (2025). Can artificial intelligence technology reduce carbon
Acemoglu, D., & Restrepo, P. (2020). Robots and jobs: Evidence from US labor markets.
                                                                                                         emissions? A global perspective. Energy Economics, 143, Article 108285. https://doi.
   Journal of Political Economy, 128, 2188–2244. https://doi.org/10.1086/705716
                                                                                                         org/10.1016/j.eneco.2025.108285
Adebayo, T. S., Kartal, M. T., & Ullah, S. (2023). Role of hydroelectricity and natural gas
   consumption on environmental sustainability in the United States: Evidence from


                                                                                              1334
B. Bergougui                                                                                                                                           Borsa Istanbul Review 25 (2025) 1316–1336

Capraro, V., Lentsch, A., Acemoglu, D., et al. (2024). The impact of generative artificial             Liddle, B., Loi, T. S. A., Owen, A. D., & Tao, J. (2020). Evaluating consumption and cost
     intelligence on socioeconomic inequalities and policy making. PNAS Nexus, 3,                           savings from new air-conditioner purchases: The case of Singapore. Energy Policy,
     Article pgae191. https://doi.org/10.1093/pnasnexus/pgae191                                             145, Article 111722. https://doi.org/10.1016/j.enpol.2020.111722
Chancel, L. (2022). Global carbon inequality over 1990–2019. Nature Sustainability, 5,                 Lin, T.-Y., Chiu, Y., Chen, C.-H., & Ji, L. (2025). Renewable energy consumption
     931–938. https://doi.org/10.1038/s41893-022-00955-z                                                    efficiency, greenhouse gas emission efficiency, and climate change in Europe.
Chancel, L., Piketty, T., Saez, E., et al. (2022). Global inequality report 2022. World                     Geoenergy Science and Engineering, 247, Article 213665. https://doi.org/10.1016/j.
     Inequal Lab, 1–236.                                                                                    geoen.2025.213665
Chen, Z., Amani, A. M., Yu, X., & Jalili, M. (2023). Control and optimisation of power                 Litman, T. (2017). Autonomous vehicle implementation predictions.
     grids using smart meter data: A review. Sensors, 23, 2118. https://doi.org/10.3390/               Liu, J., Chang, H., Forrest, J. Y.-L., & Yang, B. (2020). Influence of artificial intelligence
     s23042118                                                                                              on technological innovation: Evidence from the panel data of China’s manufacturing
Chernozhukov, V., & Hansen, C. (2008). Instrumental variable quantile regression: A                         sectors. Technological Forecasting and Social Change, 158, Article 120142. https://doi.
     robust inference approach. Journal of Econometrics, 142, 379–398. https://doi.org/                     org/10.1016/j.techfore.2020.120142
     10.1016/j.jeconom.2007.06.005                                                                     Liu, F., & Liang, C. (2025). Analyzing wealth distribution effects of artificial intelligence:
Cone, E., & Lambert, J. (2019). How robots change the world.                                                A dynamic stochastic general equilibrium approach. Heliyon, 11, Article e41943.
Denisenko, K. S. (2022). The performance of the German chemical industry through the                        https://doi.org/10.1016/j.heliyon.2025.e41943
     prism of geopolitical instability. Mezhdunarodnaja jekonomika (The World Econ,                    Liu, L., Rasool, Z., Ali, S., et al. (2024). Robots for sustainability: Evaluating ecological
     918–925. https://doi.org/10.33920/vne-04-2212-07                                                       footprints in leading AI-driven industrial nations. Technology in Society, 76, Article
Dong, M., Wang, G., & Han, X. (2024). Impacts of artificial intelligence on carbon                          102460. https://doi.org/10.1016/j.techsoc.2024.102460
     emissions in China, in terms of artificial intelligence type and regional differences.            Liu, J., Shen, H., Chen, J., et al. (2025). Artificial intelligence and carbon emissions:
     Sustainable Cities and Society. , Article 105682. https://doi.org/10.1016/j.                           Mediating role of energy efficiency, factor market allocation and industrial structure.
     scs.2024.105682                                                                                        Energies, 18.
Ekundayo, F. (2024). Economic implications of AI-driven financial markets: Challenges                  Loh, J. R., & Bellam, S. (2024). Towards net zero: Evaluating energy security in
     and opportunities in big data integration. Int J Sci Res Arch, 13, 1500–1515. https://                 Singapore using system dynamics modelling. Applied Energy, 358, Article 122537.
     doi.org/10.30574/ijsra.2024.13.2.2311                                                                  https://doi.org/10.1016/j.apenergy.2023.122537
Esposito, L., & Romagnoli, G. (2023). Overview of policy and market dynamics for the                   Lund, H., Thellufsen, J. Z., Sorknæs, P., et al. (2022). Smart energy Denmark. A
     deployment of renewable energy sources in Italy: Current status and future                             consistent and detailed strategy for a fully decarbonized society. Renewable and
     prospects. Heliyon, 9, Article e17406. https://doi.org/10.1016/j.heliyon.2023.                         Sustainable Energy Reviews, 168, Article 112777. https://doi.org/10.1016/j.
     e17406                                                                                                 rser.2022.112777
Fan, J., & Gijbels, I. (1992). Variable bandwidth and local linear regression smoothers.               Ma, D., Zhu, Y., & Lee, C.-C. (2025). The impact of artificial intelligence on carbon
     Annals of Statistics, 2008–2036.                                                                       emissions inequality: Evidence from China cities. Applied Economics, 1–16. https://
Hainmueller, J., & Hazlett, C. (2014). Kernel regularized least Squares: Reducing                           doi.org/10.1080/00036846.2025.2449621
     misspecification bias with a flexible and interpretable machine learning approach.                Mirasgedis, S., Cabeza, L. F., & Vérez, D. (2024). Contribution of buildings climate
     Political Analysis, 22, 143–168. https://doi.org/10.1093/pan/mpt019                                    change mitigation options to sustainable development. Sustainable Cities and Society,
Hassan, T. H., Tatiana, A., Palei, T., et al. (2024). Enhancing regional well-being: An                     106, Article 105355. https://doi.org/10.1016/j.scs.2024.105355
     assessment of how infrastructure investments affect gross territorial product.                    Muniandi, B., Maurya, P. K., Bhavani, C. H., et al. (2024). AI-driven energy management
     J Infrastructure, Policy Dev, 8, 7865. https://doi.org/10.24294/jipd.v8i11.7865                        systems for smart buildings. Power System Technology, 48, 322–337.
Huang, X. (2024). Harness the Co-benefit and avoid the trade-off: The complex                          Neter, J., Kutner, M. H., Nachtsheim, C. J., & Wasserman, W. (1996). Applied linear
     relationship between income inequality and carbon dioxide emissions. Social Forces,                    statistical models.
     103, 403–428. https://doi.org/10.1093/sf/soae074                                                  Niu, X., Lin, C., He, S., & Yang, Y. (2025). Artificial intelligence and enterprise pollution
IEA. (2025a). Japan – energy mix. Profile: IEA Ctry.                                                        emissions: From the perspective of energy transition. Energy Economics, 144, Article
IEA. (2025b). Energy system of Sweden. IEA ctries. Reg.                                                     108349. https://doi.org/10.1016/j.eneco.2025.108349
Islam, M. S. (2024). Rethinking climate justice: Insights from environmental sociology.                OECD. (2019). Artificial intelligence in society. OECD.
     Climate, 12.                                                                                      O’Neill, B. C., Dalton, M., Fuchs, R., et al. (2010). Global demographic trends and future
John, N., Wesseling, J. H., Worrell, E., & Hekkert, M. (2022). How key-enabling                             carbon emissions. Proceedings of the National Academy of Sciences, 107,
     technologies’ regimes influence sociotechnical transitions: The impact of artificial                   17521–17526. https://doi.org/10.1073/pnas.1004581107
     intelligence on decarbonization in the steel industry. Journal of Cleaner Production,             Özkan, O., Saleem, F., & Sharif, A. (2023). Evaluating the impact of technological
     370, Article 133624. https://doi.org/10.1016/j.jclepro.2022.133624                                     innovation and energy efficiency on load capacity factor: Empirical analysis of India.
Jones, E. (2023). Digital disruption: Artificial intelligence and international trade policy.               Environmental Science & Pollution Research, 31, 5610–5624. https://doi.org/
     Oxford Review of Economic Policy, 39, 70–84. https://doi.org/10.1093/oxrep/                            10.1007/s11356-023-31233-w
     grac049                                                                                           Padhiary, M., Saha, D., Kumar, R., et al. (2024). Enhancing precision agriculture: A
Kaplan, D. M., & Sun, Y. (2017). Smoothed estimating equations for instrumental                             comprehensive review of machine learning and AI vision applications in all-terrain
     variables quantile regression. Econometric Theory, 33, 105–157. https://doi.org/                       vehicle for farm automation. Smart Agric Technol, 8, Article 100483. https://doi.org/
     10.1017/S0266466615000408                                                                              10.1016/j.atech.2024.100483
Katal, A., Dahiya, S., & Choudhury, T. (2023). Energy efficiency in cloud computing data               Park, S., & Humphry, J. (2019). Exclusion by design: Intersections of social, digital and
     centers: A survey on software technologies. Cluster Computing, 26, 1845–1875.                          data exclusion. Information. Communications Society, 22, 934–953. https://doi.org/
     https://doi.org/10.1007/s10586-022-03713-0                                                             10.1080/1369118X.2019.1606266
Khogali, H. O., & Mekid, S. (2023). The blended future of automation and AI: Examining                 Pastor, M., Cha, J. M., Méndez, M., & Morello-Frosch, R. (2024). California dreaming:
     some long-term societal and ethical impact features. Technology in Society, 73, Article                Why environmental justice is integral to the success of climate change policy.
     102232. https://doi.org/10.1016/j.techsoc.2023.102232                                                  Proceedings of the National Academy of Sciences, 121, Article e2310073121. https://
Koley, S. (2022). Exploring social value prospects of Australia’s construction industry                     doi.org/10.1073/pnas.2310073121
     towards the aboriginal communities, under COVID-19 recovery efforts. International                Pearse, R., Schlosberg, D., Rickards, L., et al. (2025). Compounding barriers to
     Journal of Engineering Trends and Technology, 70, 227–251.                                             environmental justice. Local Environment, 1–16. https://doi.org/10.1080/
Kruger, S., & Steyn, A. A. (2024). Developing breakthrough innovation capabilities in                       13549839.2025.2471005
     university ecosystems: A case study from South Africa. Technological Forecasting and              Piketty, T., & Chancel, L. (2015). Carbon and inequality : From kyoto to paris. Paris Sch
     Social Change, 198, Article 123002. https://doi.org/10.1016/j.                                         Econ, 48pp.
     techfore.2023.123002                                                                              Robinson, L., Cotten, S. R., Ono, H., et al. (2015). Digital inequalities and why they
Le-Boulch, D., Morisset, V., Jobard, Z., et al. (2024). Life cycle assessment of nuclear                    matter. Information, Communication & Society, 18, 569–582. https://doi.org/
     power in France: EDF case study. EPJ Nucl Sci Technol, 10, 8. https://doi.org/                         10.1080/1369118X.2015.1012532
     10.1051/epjn/2024005                                                                              Rottner, E., & von Graevenitz, K. (2024). What drives carbon emissions in German
Li, G., Li, Y., & Tsai, C.-L. (2015). Quantile correlations and quantile autoregressive                     manufacturing: Scale, technique or composition? Environmental and Resource
     modeling. Journal of the American Statistical Association, 110, 246–261. https://doi.                  Economics, 87, 2521–2542. https://doi.org/10.1007/s10640-024-00894-7
     org/10.1080/01621459.2014.892007                                                                  SaberiKamarposhti, M., Kamyab, H., Krishnan, S., et al. (2024). A comprehensive review
Li, Y., Liu, L., Zhang, T., et al. (2025b). Climate change and human activities drive the                   of AI-enhanced smart grid integration for hydrogen energy: Advances, challenges,
     warm-season rooftop solar photovoltaic potential in the Chinese Chengdu-                               and future prospects. International Journal of Hydrogen Energy, 67, 1009–1025.
     Chongqing urban agglomeration. Sustainable Cities and Society, 119, Article 106110.                    https://doi.org/10.1016/j.ijhydene.2024.01.129
     https://doi.org/10.1016/j.scs.2024.106110                                                         Seo, J., Paik, J., & Yim, M. (2019). Modular reconfigurable robotics. Annu Rev Control
Li, D., Qi, Z., Zhou, Y., & Elchalakani, M. (2025a). Machine learning applications in                       Robot Auton Syst, 2, 63–88.
     building energy systems: Review and prospects. Buildings, 15, 648. https://doi.org/               Sim, N., & Zhou, H. (2015). Oil prices, US stock return, and the dependence between
     10.3390/buildings15040648                                                                              their quantiles. Journal of Banking & Finance, 55, 1–8. https://doi.org/10.1016/j.
Li, Z., Xing, Y., Shao, X., et al. (2025c). Transitioning the energy landscape: AI’s role in                jbankfin.2015.01.013
     shifting from fossil fuels to renewable energy. Energy Economics. , Article 108729.               Sirin, D., Hoffmann, P., & Scheffran, J. (2025). Lifestyle changes for climate mitigation in
     https://doi.org/10.1016/j.eneco.2025.108729                                                            cities and their relationship to urban health and well-being: A literature review.
Li, J., Zhang, Y., Tian, Y., et al. (2020). Reduction of carbon emissions from China’s coal-                Sustainable Cities and Society, 119, Article 106069. https://doi.org/10.1016/j.
     fired power industry: Insights from the province-level data. Journal of Cleaner                        scs.2024.106069
     Production, 242, Article 118518. https://doi.org/10.1016/j.jclepro.2019.118518                    Smith, D., Hermansen, M., & Malthe-Thagaard, S. (2019). The potential economic impact of
                                                                                                            Brexit on Denmark.


                                                                                                1335
B. Bergougui                                                                                                                                           Borsa Istanbul Review 25 (2025) 1316–1336

Solanki, P., Baldaniya, D., Jogani, D., et al. (2022). Artificial intelligence: New age of              Xie, Q., Jiang, Y., Jia, N., & Wang, H. (2024). Asymmetric impact of oil structural shocks
    transformation in petroleum upstream. Pet Res, 7, 106–114. https://doi.org/                              on non-ferrous metals supply chains: A groundbreaking multidimensional quantile-
    10.1016/j.ptlrs.2021.07.002                                                                              on-quantile regression. International Review of Financial Analysis, 96, Article 103607.
Stern, N. (2007). The economics of climate change: The stern review. Population and                          https://doi.org/10.1016/j.irfa.2024.103607
    Development Review, 32.                                                                             Xie, Q., & Tang, G. (2022). Do market conditions interfere with the transmission of
Strubell, E., Ganesh, A., & McCallum, A. (2020). Energy and policy considerations for                        uncertainty from oil market to stock market? Evidence from a modified quantile-on-
    modern deep learning research. Proceedings of the AAAI conference on artificial                          quantile approach. Energy Economics, 114, Article 106250. https://doi.org/10.1016/
    intelligence, 13693–13696.                                                                               j.eneco.2022.106250
Tao, W., Weng, S., Chen, X., et al. (2024). Artificial intelligence-driven transformations              Yang, S., He, X., Jiang, Q., & Wang, J. (2025). Path to environmental justice: How does
    in low-carbon energy structure: Evidence from China. Energy Economics, 136, Article                      the digital economy narrow environmental inequality? Energy, 322, Article 135598.
    107719. https://doi.org/10.1016/j.eneco.2024.107719                                                      https://doi.org/10.1016/j.energy.2025.135598
Topol, E. J. (2019). High-performance medicine: The convergence of human and                            Zai, P. V., & Lazar, A.-M.-V. (2024). Innovating through public–private partnership. Arch
    artificial intelligence. Nature Medicine, 25, 44–56. https://doi.org/10.1038/s41591-                     Bus Res, 12, 70–84. https://doi.org/10.14738/abr.1210.17727
    018-0300-7                                                                                          Zhang, Z. (2023). The impact of the artificial intelligence industry on the number and
Wang, M., & Feng, C. (2022). Tracking the inequalities of global per capita carbon                           structure of employments in the digital economy environment. Technological
    emissions from perspectives of technological and economic gaps. Journal of                               Forecasting and Social Change, 197, Article 122881. https://doi.org/10.1016/j.
    Environmental Management, 315, Article 115144. https://doi.org/10.1016/j.                                techfore.2023.122881
    jenvman.2022.115144                                                                                 Zhang, X., Liu, P., & Zhu, H. (2022). The impact of industrial intelligence on energy
Wang, Q., Li, Y., & Li, R. (2025). Integrating artificial intelligence in energy transition: A               intensity: Evidence from China. Sustainability, 14.
    comprehensive review. Energy Strategy Reviews, 57, Article 101600. https://doi.org/                 Zhang, G., Ma, S., Zheng, M., et al. (2025). Impact of digitization and artificial
    10.1016/j.esr.2024.101600                                                                                intelligence on carbon emissions considering variable interaction and heterogeneity:
Wang, J., Wang, W., Liu, Y., & Wu, H. (2023). Can industrial robots reduce carbon                            An interpretable deep learning modeling framework. Sustainable Cities and Society,
    emissions? Based on the perspective of energy rebound effect and labor factor flow in                    125, Article 106333. https://doi.org/10.1016/j.scs.2025.106333
    China. Technology in Society, 72, Article 102208. https://doi.org/10.1016/j.                        Zhao, C., Li, Y., Liu, Z., & Ma, X. (2024). Artificial intelligence and carbon emissions
    techsoc.2023.102208                                                                                      inequality: Evidence from industrial robot application. Journal of Cleaner Production,
Wang, Q., Zhang, F., Li, R., & Sun, J. (2024). Does artificial intelligence promote energy                   438, Article 140817. https://doi.org/10.1016/j.jclepro.2024.140817
    transition and curb carbon emissions? The role of trade openness. Journal of Cleaner
    Production, 447, Article 141298. https://doi.org/10.1016/j.jclepro.2024.141298




                                                                                                 1336
