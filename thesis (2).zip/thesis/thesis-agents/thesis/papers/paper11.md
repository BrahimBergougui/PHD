                                                                        Energy Strategy Reviews 55 (2024) 101541


                                                                        Contents lists available at ScienceDirect


                                                                      Energy Strategy Reviews
                                                                 journal homepage: www.elsevier.com/locate/esr




Algeria’s pathway to COP28 and SDGs: Asymmetric impact of
environmental technology, energy productivity, and material resource
efficiency on environmental sustainability
Brahim Bergougui a,b
a
    International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
b
    National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria




A R T I C L E I N F O                                          A B S T R A C T

Handling editor: Mark Howells                                  This study examines the asymmetric effects of material resource efficiency (MRE), energy productivity (EP), and
                                                               environmental technology (ENT) on environmental sustainability (ES) in Algeria from 1990/Q1 to 2022/Q4.
Keywords:                                                      Using a nonlinear autoregressive distributed lag model (NARDL), we find that both positive and negative shocks
Environmental technology                                       to both MRE and ENT contribute to ES, highlighting their effectiveness. Interestingly, positive EP shocks have a
Energy productivity
                                                               stronger mitigating effect compared to negative shocks. This suggests a magnified benefit during periods of ef­
Material resource efficiency
                                                               ficiency gains. Additionally, asymmetric causality analysis verifies a causal link between MRE, EP, ENT, and ES.
Environmental sustainability
Fourier NARDL                                                  Given these results, it is recommended that Algerian policymakers should prioritize investments in MRE and ENT
                                                               while emphasizing policies that enhance EP due to its magnified benefit on ES. Asymmetric policy responses for
                                                               green practices alongside alignment with SDGs 7, 8, 12 and COP-28 objectives will optimize Algeria’s ES.




1. Introduction                                                                                      resource management, SDG-8 and SDG-12 address resource efficiency
                                                                                                     and sustainability. SDG-8 aims to decouple economic growth from
    The escalating issue of environmental pollution, a prominent                                     environmental degradation by continuously improving resource effi­
concern since the 1970s [1], has impelled international organizations to                             ciency across consumption and production practices by 2030. On the
establish frameworks for achieving global environmental sustainability.                              other hand, SDG-12 emphasizes the judicious use and long-term pres­
While the European Union (EU) has set a target of achieving carbon                                   ervation of natural resources by the same target date [4]. The vital role
neutrality by 2050, the 28th Conference of the Parties to the United                                 of natural resources in driving economic progress is widely acknowl­
Nations Framework Convention on Climate Change (COP28) empha­                                        edged [5,6]. However, within the SDGs framework, the environmental
sized the urgency of carbon neutrality through a global call to action.                              dimension holds paramount importance, as it underpins the sustain­
Combating climate change necessitates a multifaceted approach,                                       ability of both social and economic aspects. Fig. 1 provides a summary of
encompassing both the increased use of renewable energy sources and                                  the aforementioned information.
enhancing energy efficiency. A significant outcome of COP28 was the                                      The burgeoning field of environmental technology (ENT) presents
"Global Renewables and Energy Efficiency Pledge," led by the EU. This                                itself as a critical response to the escalating environmental challenges of
pledge sets ambitious global targets: doubling the annual rate of energy                             the past few decades [7]. Its core tenet lies in the transformative po­
efficiency improvements from 2 % to 4 % by 2030 and tripling the                                     tential of shifting the global economy from dependence on traditional
installed capacity of renewable energy to at least 11 TW (TW) by the                                 fossil fuels towards renewable energy sources [8]. ENT can be concep­
same year [2]. Further reinforcing these goals, the United Nations (UN)                              tualized as a synergistic framework encompassing novel ideas, knowl­
established a comprehensive framework through its Sustainable Devel­                                 edge, and practices that propel green economic development and
opment Goals (SDGs) [3]. SDG-7 and SDG-9 specifically target a sub­                                  facilitate the transition toward a sustainable energy landscape [9].
stantial increase in the share of renewable energy within the global                                 Across diverse economic sectors, ENT fosters the development of
energy mix by 2030. These goals incentivize research and development                                 groundbreaking processes, technologies, and organizational ap­
(R&D) efforts in energy-efficient technologies, facilitating the smooth                              proaches, propelling environmental progress [10]. Recent studies
transition to renewable energy sources. Recognizing the critical role of                             highlight the immense potential of ENT to significantly curb carbon


      E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com.

https://doi.org/10.1016/j.esr.2024.101541
Received 30 May 2024; Received in revised form 6 July 2024; Accepted 20 September 2024
Available online 23 September 2024
2211-467X/© 2024 The Author. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui                                                                                                             Energy Strategy Reviews 55 (2024) 101541




Fig. 1. The synergy between COP28 and SDGs in driving energy productivity
and material resource efficiency.


emissions within innovation-driven economic sectors such as electricity
generation, natural resource management, building construction, and
transportation [11]. In this context, achieving environmental sustain­
ability hinges on the development of technologies that optimize material
resource efficiency (MRE) and energy productivity (EP). Furthermore,
the deployment of clean energy technologies fosters environmental
sustainability by enhancing the efficiency and efficacy of renewable
energy resources [12].
    A range of factors influence the quality of the environment, neces­
sitating a thorough assessment of environmental factors. Previous                Fig. 3. The share of the top four carbon dioxide emitters in Africa (2022).
research on the determinants of environmental sustainability in Algeria
has examined variables including, economic growth, technological                significance, particularly for developing nations like Algeria. Their sig­
innovation, energy consumption, and trade openness. However, there is           nificance stems from their role as the foundation for industrial activity
a gap in the literature regarding the consideration of MRE and EP, which        and the production of essential goods and services. Raw materials are
could potentially have a significant impact on environmental                    intricately linked to three key domains: industry (e.g., non-energy ma­
sustainability.                                                                 terials), technological advancement (e.g., smartphones), and environ­
    EP serves as a key metric for gauging the efficiency with which             mental sustainability (e.g., clean technologies. Consequently, MRE, a
economic output is generated relative to energy consumption. Defined            metric that gauges production levels relative to (raw) material con­
as the ratio of gross domestic product to gross energy use within a             sumption, offers valuable insights into the pursuit of a green growth-
specific calendar year, EP reflects the economic value derived from each        oriented economic model [16]. The growing concern over climate
unit of energy employed. Gross energy use encompasses the total                 change, particularly greenhouse gas emissions, has heightened the
amount of energy products necessary to satisfy all energy demands               importance of environmental sustainability and MRE for many countries
within a defined geographic area [13]. In essence, EP quantifies the            [17]. Implementing MRE principles fosters sustainable production and
effectiveness of energy utilization. It also captures the decoupling phe­       consumption patterns. These patterns promote resource efficiency,
nomenon; whereby economic growth can occur independent of esca­                 minimize reliance on natural resources and fossil fuels, optimize waste
lating energy consumption. This decoupling holds significant                    management practices, and ultimately enhance environmental sustain­
environmental implications. Enhanced EP directly translates to energy           ability [18]. However, MRE policies alone are insufficient to guarantee a
savings, leading to a reduction in overall energy consumption [14].             sustainable environment. ENT and EP play a complementary role in
Lower energy consumption demonstrably mitigates environmental                   achieving environmental sustainability by supplementing MRE strate­
pollution across various domains, thereby contributing to improved              gies [12]. Algeria could leverage this comprehensive approach to sup­
environmental sustainability. It is noteworthy that EP is a central             port its national goal of carbon neutrality by 2030.
component of research and development (R&D) expenditures directed                   Algeria ranks as one of the top three emitters of carbon dioxide in
toward innovative energy technologies [3]. Fig. 2 portrays the diverse          Africa, following South Africa and Egypt. This positioning makes Algeria
R&D expenditures associated with energy technologies (see Fig. 3).              a significant contributor to Africa’s overall CO2 emissions, exceeding
    The global raw materials sector holds substantial economic                  5.5 %, as seen in 3. The nation’s rapid economic growth and a




                                          Fig. 2. Categories of energy technology RD&D budgets. Sources [15].

                                                                            2
B. Bergougui                                                                                                              Energy Strategy Reviews 55 (2024) 101541


corresponding surge in energy consumption are identified as the pri­                 reducing emissions remains a subject of ongoing debate [27]. Simi­
mary drivers of these emissions [19]. From an environmental sustain­                 larly, theoretical frameworks such as Porter and van der Linde’s
ability standpoint, Algeria’s current position is concerning. The nation’s           hypothesis [28] posit that well-designed environmental regulations
environmental sustainability falls below desired benchmarks. Conse­                  can stimulate the development and adoption of ENT. One potential
quently, a critical research area is the exploration of factors that influ­          unintended consequence of ENT implementation is the increase in
ence environmental sustainability in Algeria.                                        manufacturing capacity required to meet its demands. While this can
   This study offers three key contributions to the existing literature.             benefit exporting countries by reducing domestic emissions, it may
                                                                                     simultaneously lead to a transfer of those emissions to importing
 • First, it investigates the previously unexplored roles of MRE and EP              nations [27]. International collaboration emerges as a promising
   in mitigating environmental damage specific to Algeria. This                      avenue for maximizing the impact of ENT, with the potential to
   research unveils the multifaceted impacts of these factors on carbon              accelerate the development and deployment of these solutions across
   emissions, providing policymakers and stakeholders with crucial                   borders [29].
   information regarding potential outcomes and areas for targeted                 • Second, MRE significantly enables emissions reductions through
   interventions to optimize environmental sustainability.                           sustainable practices across sectors. Energy-intensive industries can
 • Second, it posits that advancements in MRE, EP, and ENT are                       adopt energy-saving technologies to lower consumption and emis­
   fundamental to achieving the goals outlined in COP-28 and SDGs-7                  sions. Improved material efficiency and waste reduction also
   and 12. By leveraging these three variables, the study demon­                     decrease manufacturing’s carbon footprint, enhancing sustainabil­
   strates how the application of ENT fosters increased EP and MRE,                  ity. In agriculture, efficient practices like precision agriculture
   ultimately leading to an enhancement in environmental                             minimize emissions from land use changes, deforestation, and fer­
   sustainability.                                                                   tilizers. Further, efficient transportation options like mass transit and
 • Third, unlike prior studies that primarily relied on linear models, this          electric vehicles reduce supply chain emissions [20,30,31].
   research employs the innovative NARDL methodology to delve into                 • Third, EP is critical to reducing fossil fuel reliance and achieving
   the potential asymmetric effects of both positive and negative                    sustainability alongside renewable, clean resources. Heightened
   changes in MRE, EP, and ENT on environmental sustainability. By                   productivity facilitates managing energy use, executing pollution
   quantifying the potential influence of these factors, the study offers            reduction, and raising economic output. It signifies total production
   valuable insights to guide decision-making processes aimed at pro­                based on per-unit inputs. More productive methods use less energy
   moting a more ecologically sound and sustainable future for Algeria               for optimal output, resulting in fewer emissions. Thus, EP is expected
   and beyond.                                                                       to inversely affect carbon dioxide emissions [31,32].

    The article is organized as follows. Section 2 provides a review of the           Realizing MRE, EP, and ENT’s full potential requires systemic
relevant literature. Section 3 details the data and model employed in the         changes and supportive policies. Governments can implement carbon
study. The results and discussion are presented in Section 4. Finally,            pricing, renewable incentives, and efficiency regulations to create
Section 5 concludes the paper with policy recommendations.                        favourable conditions for businesses and consumers to adopt green
                                                                                  technologies. International agreements like the Paris Agreement are
2. Literature review                                                              critical for addressing global challenges, enabling technology transfer
                                                                                  and cooperation to accelerate worldwide progress toward net-zero
    Existing research examines two related areas: improvements in EP,             emissions [33]. Public awareness and engagement drive demand for
MRE, and environmental sustainability; and the leveraging of ENT to               sustainable products and services, motivating companies to innovate
achieve net-zero emissions. Within the first area, prior studies under­           and invest in green solutions.
score optimizing energy and resource use while decreasing environ­                    In summary, MRE, EP, and ENT provide multifaceted transmission
mental harms, mainly cutting greenhouse gas releases and shifting to              channels that interconnect to promote sustainable, low-carbon prac­
cleaner energy [20]. The second area focuses on the crucial role of ENT           tices, directly reducing emissions and driving transformative changes
in achieving net-zero emissions through the adoption of eco-friendly              across sectors. Backed by appropriate policy frameworks and societal
technologies and practices. This area explores how ENT, specifically              involvement, these channels hold the key to achieving ambitious net-
intellectual property protecting environmentally sound technologies,              zero emissions goals, paving the way for a greener and more sustain­
can accelerate the transition towards a low-carbon economy [21].                  able future [34].

2.1. Theoretical underpinnings                                                    2.2. Environmental facet of material resource efficiency

   MRE, EP, and ENT are pivotal in influencing transmission channels                  The imperative for achieving net-zero emissions and mitigating
that enable net-zero emissions [20].                                              climate change necessitates a multifaceted approach, with MRE playing
                                                                                  a leading role. A growing body of research, including studies by Refs.
 • First, the concept of ENT, often used interchangeably with "green              [12,20], highlights the decoupling potential of resource efficiency
   technology," encompasses a diverse array of innovative solutions               strategies. An earlier study by Ref. [35] sought to explain the relation­
   designed to address pressing environmental challenges. These ad­               ship between MRE and the environment in the United Kingdom.
   vancements hold significant promise in mitigating energy con­                  Employing an environmentally extended input-output model within an
   sumption, reducing pollution levels, and ultimately fostering a more           experimental framework analysing production and consumption sys­
   sustainable future [22]. A primary focus of ENT lies in enhancing              tems, the research provides an examination of MRE dimensions of
   energy efficiency and facilitating a transition towards clean energy           greenhouse gas discharges. The study’s conclusions indicate that policy
   sources, including solar, wind, biomass, and hydropower [23]. This             interventions centred on the consumption facet of MRE could yield more
   shift away from traditional fossil fuels offers a powerful tool for            savings compared to production aspects, especially considering the
   combating environmental degradation [24]. However, the trajectory              study’s suggestions for curbing GHG emissions in the United Kingdom
   of ENT implementation is not without complexities. While seminal               by 2050. Similarly [36], applied a novel multi-regional modelling
   work by Braun and Wield [25] established the theoretical founda­               framework to produce MRE projections for 2050. Regarding the envi­
   tions for ENT, and subsequent studies have suggested potential                 ronmental consequences of resource use, they estimate that under
   economic advantages [26], the actual effectiveness of ENT in                   existing trends, global resource extraction will rise by 119 % and

                                                                              3
B. Bergougui                                                                                                              Energy Strategy Reviews 55 (2024) 101541


greenhouse gas emissions by 41 % from 2015 to 2050, driven by the                indicate that while raising EP can contribute to lower CO2 emissions in
doubling of global economic activity. Whereas in terms of resource ef­           the long run, the mitigation effects only materialize over longer time
ficiency as a pro-growth pro-environment policy, they find that                  horizons. In contrast, the authors find increasing adoption of renewables
enhancing resource efficiency could lower resource extraction by up to           leads to more immediate emissions reductions. This distinction in
28 % and greenhouse gas emissions by 15–20 % in 2050, relative to                timescales of impact highlights an important consideration for policy­
existing trends, while increasing near-term economic growth by USD 2.4           makers balancing different sustainability options – EP can support
trillion in 2050. Furthermore [37], employed the case of Austria to              critical decarbonization goals, but it needs patience. This study gives
demonstrate the relationship between MRE usage and CO2 emissions                 detailed information to guide clean energy technology and efficiency
from 2000 to 2015. The study adopted the consumption-based sectoral              policies for emissions reduction. A unique empirical analysis of the
index decomposition approach for a multi-regional setting using an               relationship between EP and CO2 emissions at the provincial level in
input-output approach. Based on this remarkable finding, the authors             China was undertaken by Ref. [44]. Employing panel data on 29 Chinese
conclude that Austria’s extant MRE strategies appear to entail implicit          provinces during 1995–2012, the authors’ econometric results provide
risks of pollution leakage, indicating a narrow window for declining CO2         evidence that across all regions of China, improvements in EP over time
discharges and resource exploitation. While enhancements in MRE                  have contributed to statistically significant reductions in CO2 emissions.
among service industries may engender greater CO2 mitigation poten­              Examining a panel of 66 developing countries [45], provided evidence
tial, concomitant economic growth could undermine such progress in               that enhancing EP can curb CO2 emissions in developing economy
the Austrian context per the study’s inferences. A recent study by               contexts. Utilizing quantile panel regression techniques, the authors
Ref. [12] examined how Finland aims to achieve a circular economy by             further demonstrated the heterogeneous impacts of EP advances on
reducing its dependence on fossil fuels and reaching zero emissions by           emission mitigation. Their estimates indicate that improving EP leads to
2035. Using long-term estimators from 1990 to 2020, they showed that             relatively greater emissions reductions in developing nations with
an increase of 1 % in MRE results in a decline of 61–70 % in greenhouse          higher per capita carbon dioxide levels. This finding highlights the
gas emissions. An additional investigation [16], discussed the impact of         outsized value of policies targeted at EP enhancements, particularly for
MRE, export intensification, and environmental technologies on green­            developing countries on more emission-intensive development paths
house gas emissions across five Scandinavian countries from 1990 to              [46]. demonstrated EP’s substantial emissions reduction effects in G-7
2019. Their analysis unveils that heightening MRE application curtails           nations over 1996–2017, also linked to enhancing technological inno­
greenhouse gas volumes, indicating that Scandinavian nations boast an            vation. Similarly, recent analyses focused on major developing economy
efficacious raw MRE profile. Employing a non-linear Autoregressive               groups found advancing EP lowers CO2 emissions in N-11 countries [47]
Distributed Lag (ARDL) approach, a study by Ref. [31] investigated the           as well as lessening environmental deterioration across China over
asymmetric effects of MRE on environmental sustainability in Germany             1991–2017 [48]. Examining specific countries like Greece and Morocco,
between 1995 and 2020. Their analysis revealed that positive shocks to           scholars further revealed the significant emissions mitigation impacts of
MRE deployment led to a decrease in pollution levels in the long run.            increasing EP [49,50]. At the same time, research on OECD countries
Conversely, negative shocks (decreases in MRE) resulted in increased             emphasized that while critical, EP should be considered alongside
pollution levels. Similarly, research by Ref. [38] utilized advanced             complementary policy tools like environmental taxes, renewable energy
econometric techniques to assess the impact of MRE on environmental              expansion, and ENT support to most effectively combat emissions [51].
sustainability in Japan from 1990Q1 to 2020Q4. Their findings mirrored           Adding nuance [52], spotlighted the importance of macro-financial
those of [31], indicating that positive MRE shocks mitigated environ­            stability conditions in unlocking EP’s emissions-reduction potential in
mental degradation, while negative shocks exacerbated it. Employing a            Bulgaria. Collectively, this expanding literature underscores rising EP’s
time-varying causal approach [39], investigated this relationship in             viability as a lever across varied developed and developing economies to
Malaysia, highlighting the significance of resource efficiency in reducing       achieve urgent decarbonization and sustainability goals.
CO2 emissions. This finding aligns with the research of [40] who
examined G7 countries using common correlated effects mean group                 2.4. Environmental facet of technology
and augmented mean group methodologies. Their work, echoing the
emphasis on reducing CO2 emissions at COP26 and COP27, underlines                    Environmental technology, which is essential for low-carbon tran­
the importance of resource efficiency in achieving environmental sus­            sitions, has attracted several of scholarly attention in the context of
tainability. Furthermore [41], conducted a comprehensive study in                climate change, innovation, and decarbonization [53]. define an ENT as
Germany utilizing quarterly data from 1974 to 2019. Their Wavelet                a patent that relates to an invention that protects the environment or
Quantile-on-Quantile Regression (WQQR) analysis examined the impact              conserves resources. Green environmental-related technologies are
of resource efficiency, along with renewable energy research and                 commonly used as measures of ENT, which seeks to minimize environ­
development (R&D) expenditures and green technologies, on environ­               mental harm and optimize resource use. Two main research areas can be
mental sustainability. The findings demonstrated a negative association          distinguished in the literature on ENT and carbon emissions. The first
between resource efficiency and energy-based carbon intensity, signi­            one investigates the relationship between the total number of ENT and
fying its positive contribution to environmental sustainability goals.           the emission trends. The second one focuses on the specific ENT types
                                                                                 and their diffusion and emission reduction outcomes. This paper will
2.3. Environmental facet of energy productivity                                  provide an overview of these two types of studies.
                                                                                     With regard to the overall outcome of ENT on the environment, most
    While numerous studies have examined the impact of energy con­               experts agree that ENT enhances environmental sustainability. Among
sumption on CO2 emissions, there has been comparatively little research          them [54], employed a Method of Moments Quantile Regression
exploring the relationship between EP and CO2 emissions. More                    (MMQR) to examine the influence of ENT on environmental sustain­
research focused specifically on the connections between EP improve­             ability in resource-rich countries from 2000 to 2021. They found that
ments and CO2 mitigation is still needed. EP denotes any alterations that        ENT reduces CO2 emissions and enhances energy transition. Similarly
lead to a decrease in the energy needed to produce one unit of a good or         [55] constructed a green technology index based on renewable energy
service. Enhancing EP can diminish energy consumption in economic                and clean technology indicators and a Paris Climate Agreement (PCA)
activities [42].                                                                 index based on the Standard & Poor’s Net Zero Paris Climate Agreement
    Taking a comparative approach across 36 countries globally [43],             Sustainability Screening Index. They applied a wavelet-based quanti­
empirically assessed the relative environmental impacts of expanding             le-on-quantile regression method to investigate the link between the two
renewable energy versus enhancing EP. Their econometric estimates                indices. Their results demonstrate that ENT has a positive impact on

                                                                             4
B. Bergougui                                                                                                                Energy Strategy Reviews 55 (2024) 101541


achieving PCA goals, suggesting that green technologies can serve as               2.5. Critical evaluation of existing literature
drivers in reaching the objectives outlined in the Paris Agreement. Using
UK data from 1995 to 2019 [56], employed the Bootstrapping Rolling                    The extant literature provides a comprehensive examination of the
Window technique to assess how ENT contributes to ecological sus­                  implications of MRE, EP, and ENT on environmental sustainability.
tainability and energy transition. They reported that ENT hurts                    However, a critical evaluation of the extant literature reveals short­
ecological footprints and has a positive effect on energy transition. In the       comings that necessitate further investigation.
case of China [57], gathered data from 30 provinces from 2007 to 2019
and examined the influence of green technology innovation on carbon                 • Methodological Approaches: prior studies have relied heavily on
intensity using a nonlinear spatial Durbin model. They found that the                 traditional econometric models such as FMOLS, DOLS, CCR, and
local impact of green technology innovation on carbon intensity exhibits              ARDL, as exemplified by Bergougui [106] and Bergougui et al. [105].
a significant “inverted-U″ pattern, meaning that green technology                     These methods often assume linearity and symmetric relationships
innovation initially increases carbon emissions, but later decreases them             between variables. Deviations from these assumptions, such as
after reaching a certain level [58]. employed a panel dataset of Asian                non-linearity or asymmetries, can lead to inaccurate results.
economies to estimate the effect of ENT advancements on environ­                      Furthermore, these models might not fully capture the dynamic na­
mental sustainability, as measured by ecological footprints, using the                ture of time series data, particularly when dealing with structural
STIRPAT model in Indonesia over the period 1995–2020. A Quantile                      breaks or seasonal variations. This limitation could result in an
Autoregressive Distributed Lag Model was applied. The findings indi­                  incomplete understanding of the evolving relationship between
cated the positive contribution of ENT advancement to environmental                   environmental technology, energy productivity, and sustainability.
sustainability across the entire range of quantiles (0.05–0.90) in both the         • Geographic Focus: Previous studies primarily concentrate on
short- and long-term [59]. used the method of moments quantile                        developed countries, such as Finland [71], Germany [31], and
regression to account for non-linearity in the OECD panel from 1990 to                Ireland [72]. This focus overlooks the unique context of developing
2019 and examined how ENT impacts ecological footprints. They re­                     countries, particularly Algeria, which presents a compelling case
ported that ENT enhances environmental sustainability. In the context of              study for further exploration.
Algeria [19], employed total patent application data within a Non-linear            • Algerian Context: The specific influence of MRE and EP in shaping
Autoregressive Distributed Lag (NARDL) model to demonstrate that                      environmental sustainability within the Algerian context, the focal
innovation is associated with a significant reduction in CO2 emissions.               point of this study, has not been sufficiently explored.
Similarly [8], utilized NARDL modelling and data on ENT applications                • Implementation of Goals: Although the expansion of MRE, EP, and
to highlight the substantial decrease in ecological footprint attributable            ENT is acknowledged as crucial for meeting the targets set by COP-28
to ENT.                                                                               and SDGs 7 and 12, a significant research gap exists regarding the
    Besides the studies on overall ENT and CO2 emissions, the link be­                Algerian government’s strategies for implementing these variables to
tween particular ENT and CO2 emissions has attracted increasing                       achieve these targets.
attention from researchers, such as eco-innovation, clean energy inno­              • Addressing the gaps: This study aims to overcome these limitations
vation, and sustainable technology innovation. The majority of these                  by examining the asymmetric relationships between MRE, EP, and
studies have employed the data of specific patents as an indicator of                 ENT and their impact on environmental sustainability in Algeria,
innovation and their research approaches and outcomes have their                      employing Nonlinear Autoregressive Distributed Lag (NARDL) and
distinct features [60]. measured environmental innovation using patents               asymmetric causality methods. These advanced techniques allow for
for environmental technologies across 27 EU countries. They found                     the analysis of how pollution levels respond differently to positive
environmental innovation reduces emissions, while general innovation                  and negative changes in MRE, EP, and ENT. The study suggests that
does not [61]. identified a rebound effect for environmental in­                      improvements in these variables are essential for achieving the goals
novation’s impact on emissions in 15 EU countries using an autore­                    outlined in COP-28 and SDGs 7 and 12. By leveraging these three
gressive distributed lag model. Environmental innovations mitigate                    variables, the research illustrates how the application of ENT fosters
emissions in the long term but briefly increase them in the short term.               increased EP and MRE, eventually leading to enhanced environ­
Analysing energy innovation in China with spatial econometric model­                  mental sustainability in Algeria. As Algeria is a significant energy
ling [62], determined renewable energy technologies reduce emissions,                 consumer and carbon emitter in Africa, this research provides valu­
but fossil fuel technologies do not. They also found differences in impact            able insights into the country’s energy policy and sustainability
across regions. Similar to environmental and energy innovations, green                efforts.
technology innovation is also considered closely tied to CO2 emissions.
However, its role in global emission mitigation and carbon neutrality is           3. Data and research methodology
debated. Some studies demonstrate ENT reduces emissions, using
methods like cross-sectional augmented autoregressive distributed lag                  Within this part, we outline the variables used for model estimation
modelling in Thailand [63] and STIRPAT modelling in Turkey [64].                   and detail the techniques used to fulfil the study’s goal. The primary
Others highlight reciprocal causality between ENT and lowered emis­                objective is to examine the causal and asymmetric impacts of EP, MRE,
sions in the G7 [65] or ENT’s key role in OECD emission cuts [66]. By              and ENT on Algeria’s environmental sustainability from 1990Q1 to
using bootstrap autoregressive distributed lag tests in Malaysia [67],             2022Q4 while accounting for economic growth, and trade openness. The
determined ENT correlates with fewer emissions in both the short and               present study utilizes the NARDL model as the primary estimator, which
long term.                                                                         has several advantageous features compared to other techniques [8,19].
    However, some studies report mixed effects. Evaluating cities in               In line with the main objective of the study, the following equation is
China [68], reported ENT improves carbon performance overall via in­               estimated:
dustrial structural shifts and foreign direct investment, but some
                                                                                   CO2 = f(MRE, EP, ENT, GDP, TO)                                               (1)
sub-categories increase emissions [69]. identified significant long-run
mitigation but insignificant short-term effects in the next eleven                 where.
(N-11) economies. Utilizing panel data for G7 countries [70], revealed
asymmetric periodic relationships - recessions dampen ENT’s emission                • Carbon Dioxide Emissions (CO2): This measure represents the
benefits while economic recoveries enhance them.                                      metric tons of carbon dioxide emitted per person in a given year.
                                                                                      (Source: Global Carbon Project)


                                                                               5
B. Bergougui                                                                                                            Energy Strategy Reviews 55 (2024) 101541


 • Material Resource Efficiency (MRE): This indicator reflects how               Fig. 4 exemplifies the overall study design.
   efficiently a nation uses its resources to generate economic output.              As a preliminary diagnostic, this study implements the BDS (Brock-
   Following the methodology of Wang et al. [62], MRE is calculated by           Dechert-Scheinkman) test to examine the linearity properties of the CO2,
   dividing Algeria’s Gross Domestic Product (GDP) by its material               MRE, EP, ENT, GDP, and TO time series. Under the null hypothesis, the
   footprint. (Source: Author calculations)                                      variables exhibit linear independence. The presence of nonlinearity
 • Energy Productivity (EP): This metric is determined by dividing a             suggests substantial inefficiency may permeate estimates from linear
   country’s total economic output (measured by Gross Domestic                   models. Thus, detecting nonlinear dynamics justifies employing more
   Product or GDP) by the total energy consumed within its economy. It           robust techniques, including Fourier ADL cointegration (FADLC),
   indicates how much economic value is generated per unit of energy             nonlinear autoregressive distributed lag (NARDL), and gradual shift
   used. (Sources: Our World in Data, World Development Indicators               causality (GSC) tests, over conventional linear estimators.
   2023, and author calculations).                                                   After assessing the results from the BDS test, unit root analysis is
 • Environmental Technology (ENT): This metric represents the                    conducted using both the augmented Dickey-Fuller test, with and
   number of green technology patents. These patents cover inventions            without structural breaks and the Zivot-Andrews breakpoint unit root
   that protect innovations promoting environmental sustainability,              test. Evaluating stationarity enables appropriate specification of the
   enhancing energy efficiency, and developing eco-friendly solutions.           order of integration for each series in subsequent modelling procedures.
   (Source: OECD 2023)                                                               This study employs the FADLC proposed by Banerjee et al. [73],
 • Gross Domestic Product (GDP): This indicator measures the GDP per             using Gallant’s [74] flexible Fourier function form. Unlike traditional
   capita in constant 2015 international dollars. It reflects the economic       cointegration tests which suffer power loss in the presence of unknown
   output per person in a country, adjusted for purchasing power parity.         structural breaks, the FADLC test overcomes this limitation through the
   (Source: World Development Indicators 2023)                                   use of Fourier terms. Furthermore, by incorporating dummy variables
 • Trade Openness (TO): This measure is calculated as the sum of ex­             for structural changes, the test avoids power distortions [38]. Another
   ports and imports of goods and services, expressed as a percentage of         advantage of FADLC is improved performance with smaller samples
   GDP. It indicates the degree of a country’s integration into the global       compared to the VECM. Under the FADLC null hypothesis, there is no
   economy. (Source: World Development Indicators 2023)                          cointegrating relationship; the alternative is that a cointegrating rela­
                                                                                 tionship exists [38].
   The aim is to test the hypotheses that MRE, EP, and ENT are signif­
icant positive predictors of environmental sustainability in the Algerian
context. For empirical analysis, the conceptual model is converted into          3.1. Justification for NARDL model selection
the following regression form:
                                                                                     In addition to the FADLC test, our study investigates the potential for
CO2t = α0 + α1 (MRE)t + α2 (EP)t + α3 (ENT)t + α3 (GDP)t + α3 (TO)t + μt         asymmetric relationships between ENT, MRE, EP, and environmental
                                                                       (2)       sustainability. As these relationships might be influenced by external
    The natural logarithm is applied to each variable in the analysis.           shocks or exhibit complex dynamics, linear cointegration techniques
                                                                                 like ARDL, FMOLS, and DOLS may not be suitable. The NARDL




                                                               Fig. 4. Analysis flowcharts.

                                                                             6
B. Bergougui                                                                                                                Energy Strategy Reviews 55 (2024) 101541


framework offers several advantages that address these limitations.                4.1. Preliminary test

 • Non-linearity accommodation: NARDL can flexibly capture non-                    4.1.1. Descriptive statistics
   linear relationships within the data. This is crucial because the                   Table 1 presents a comprehensive description of the dataset’s fea­
   impact of ENT, MRE, and EP on environmental sustainability might                tures. The mean values of CO2, MRE, EP, ENT, GDP, and TO exceed their
   not be linear.                                                                  corresponding standard deviations, indicating an uneven distribution in
 • Asymmetry Analysis: NARDL allows us to distinguish between the                  Algeria. Skewness statistics indicate that CO2, MRE, and EP display a
   short-run and long-run effects of positive and negative changes in the          right-skewed distribution, while ENT, GDP, and TO exhibit a left-skewed
   variables [75]. This is important because the impact of, for example,           distribution. The Jarque-Bera test statistics reject normality. This sug­
   an increase in ENT might differ from the impact of a decrease,                  gests that the sample data is not normally distributed.
   especially in the context of sustainability.                                        To visually assess normality, quantile-quantile plots (Q-Q plots) were
 • Robustness and integration order flexibility: Compared to alter­                employed. Ideally, in a normally distributed dataset, the Q-Q plot should
   native models like VECM, NARDL exhibits greater robustness and                  approximate a diagonal line. However, as illustrated in Fig. 5, the points
   avoids limitations associated with the integration order of the data            deviate significantly from this linearity, signifying non-normality. This
   series [76]. This flexibility allows for a smoother analysis regardless         non-normality applies to both the dependent variable (CO2 emissions)
   of whether the variables are stationary at level (I(0)) or first differ­        and the independent variables. Consequently, the traditional ARDL
   ence (I(1)).                                                                    model becomes unsuitable due to its inability to handle the complexities
                                                                                   associated with non-normal data during estimation. Applying the ARDL
    By incorporating the NARDL bounds procedure proposed by Shin                   model under such circumstances can lead to biased results. Therefore,
et al. [77], we can investigate cointegration within this asymmetric               the NARDL approach is adopted as it is better equipped to address po­
framework. This approach provides a more comprehensive under­                      tential nonlinearities within the data.
standing of the complex interactions between the variables in our study.               The binary-relation scatter plot in Fig. 6 reveals some interesting
    To strengthen the robustness of our NARDL findings, we employed                patterns. We observe a negative correlation between CO2 emissions and
several complementary analyses. (i) alternative estimation techniques:             MRE, EP, and ENT. In simpler terms, increased adoption of these factors
The model is re-estimated using established cointegration techniques               seems to be associated with improved environmental sustainability. On
like FMOLS and CCR. Comparing these results with the NARDL model                   the other hand, the plot shows a positive correlation between GDP and
reinforces the validity of the core findings. (ii) substitute dependent            CO2 emissions. This indicates that higher levels of economic activity, as
variable: The impact on the results is assessed by using an alternative            measured by GDP, are linked to higher levels of CO2 emissions.
measure for the dependent variable (e.g., ecological footprint). This
ensures conclusions are not specific to the chosen measurement. (iii)              4.1.2. Nonlinearity test
control variable sensitivity: the model is re-estimated without any                   To validate nonlinearities in the data, the BDS test is implemented.
control variables, followed by estimations including two additional                As shown in Table 2, the significant BDS statistics indicate the presence
control variables. This verifies that the control variables are not solely         of nonlinear. Accordingly, solely using linear models risks biased esti­
driving the observed relationships. addition of other control variables.           mates. Detecting these nonlinear properties justifies applying nonlinear
    The econometric studies have demonstrated that the conventional                approaches to examine the long-run relationships between CO2, MRE,
Toda-Yamamoto causality test does not require pre-testing for cointe­              EP, ENT, GDP, and TO in the analysis.
gration [38]. The GSC procedure developed by Ref. [78] extends this
technique using Gallant’s [74] flexible Fourier specification to integrate         4.1.3. Unit root test
smooth structural shifts. This Fourier-based Toda-Yamamoto approach                    Before estimating the NARDL model, it is imperative to verify that
introduces Fourier terms in the causality equation to account for po­              none of the variables are integrated of order two (I(2)) via unit root tests.
tential structural breaks [78]. Additionally, the GSC test circumvents             Thus, the current study implements Augmented Dickey-Fuller (ADF)
shortcomings related to assuming unexpected regime changes. To vali­               tests both with and without structural breaks, as reported in Table 3.
date the GSC results, this study utilizes the nonparametric [79] asym­                 The findings indicate that while all variables exhibit nonstationary
metry causality test.                                                              and contain a unit root, taking first differences renders CO2, RE, EP,
                                                                                   ENT, GDP, and TO stationary. This confirms that none of the time series
4. Empirical results                                                               are I(2), enabling investigation of the asymmetric impacts of EP, MRE,
                                                                                   and ENT on environmental sustainability in Algeria through NARDL,
   Consistent with the main research objectives, this study investigates           along with FADLC and GYC tests, while controlling for GDP and TO.
the impacts of MRE, EP, and ENT on environmental sustainability in
Algeria from 1990Q1 to 2022Q4, controlling for economic growth and
                                                                                   4.2. NARDL bounds test of cointegration
trade openness. Prior to analysis, it is critical to test for nonlinearities
and understand the time series properties of the data. This enables
                                                                                      To examine the existence of a long-run relationship among the var­
appropriate estimator selection and model specification.
                                                                                   iables in the model, the current study implements the FADLC test of

Table 1
Descriptive statistics.
                           CO2                    MRE                    EP                       ENT                      GDP                        TO

  Mean                     17.12068               4.820433               6.724619                 4.607756                 6.780985                   2.628617
  Median                   17.06411               4.817696               6.700977                 4.524118                 6.792671                   2.635401
  Maximum                  17.62811               5.238994               6.893322                 5.429209                 6.968366                   2.958014
  Minimum                  16.70175               4.464047               6.584656                 3.388882                 6.552606                   2.088161
  Std. Dev.                0.287645               0.204805               0.097157                 0.647303                 0.133979                   0.196520
  Skewness                 0.452989               0.319812               0.289198                 − 0.245847               − 0.165303                 − 0.681174
  Kurtosis                 1.824282               2.316554               1.725754                 1.546147                 1.534247                   3.277526
  Jarque-Bera              13.95302               5.549380               12.40222                 14.91786                 14.29897                   12.24242
  Probability              0.000934               0.062369               0.002027                 0.000576                 0.000785                   0.002196


                                                                               7
B. Bergougui                                                                                                              Energy Strategy Reviews 55 (2024) 101541




                                               Fig. 5. The normal quantile-quantile plot for all variables.




                                                          Fig. 6. Binary-relation scatter plots.


Banerjee et al. [73] as well as the bounds test for cointegration in the        series is rejected, indicating the presence of a long-run linkage between
NARDL framework. The results of the FADLC test for the estimated                CO2, RE, EP, ENT, GDP, and TO in the case of Algeria. The outcome of
model are reported in Table 4.                                                  the NARDL bounds test provides upholding evidence for the FADLC
   An optimal frequency of two is detected, with the test statistic             results, as the F-statistic of 5.972448 is statistically significant at the 1 %
exceeding the 1 % critical values of Banerjee et al. [73] in absolute           level.
value. Thus, the null hypothesis of no cointegration among the time


                                                                            8
B. Bergougui                                                                                                                                 Energy Strategy Reviews 55 (2024) 101541


Table 2
Nonlinearity BDS test results.
  Variables                   Dimensions                                                                                                                                  Decisions

                              m=2                           m=3                        m=4                            m=5                      m=6

  CO2                         0.195***                      0.328***                   0.419***                       0.482***                 0.527***                   Nonlinear
  MRE                         0.184***                      0.305***                   0.384***                       0.432***                 0.461***                   Nonlinear
  EP                          0.192***                      0.322***                   0.407***                       0.462***                 0.497***                   Nonlinear
  ENT                         0.192***                      0.322***                   0.409***                       0.467***                 0.504***                   Nonlinear
  GDP                         0.200***                      0.337***                   0.430***                       0.494***                 0.537***                   Nonlinear
  TO                          0.180***                      0.301***                   0.377***                       0.423***                 0.448***                   Nonlinear

Notes: ***, **, and * denote statistical significance at the 1 %, 5 %, and 10 % levels, respectively, based on the rejection of the null hypothesis of linearity.


Table 3                                                                                       Table 5
Unit root test without/with a breakpoint.                                                     NARDL long run results.
  Variable              ADF without Break Point              ADF with Break Point                 Dependent variable = CO2

  At level                                                                                        Variables         Coefficient     Std. Error            t-Statistic    Prob.

  CO2                   1.2755                               − 2.573084 (2004Q1)                  CO2t-1            − 1.151447***   0.204530              − 5.629725     0.0000
  MRE                   − 0.3732                             − 3.606034 (2005Q1)                  MRE positive      − 0.152508*     0.077107              − 1.977860     0.0540
                                                                                                      t-1
  EP                    0.5171                               − 2.921315 (2011Q1)                         negative   − 0.113289**    0.046963              − 2.412279     0.0199
                                                                                                  MREt-1
  ENT                   0.1822                               − 6.676178 (2001Q1)
                                                                                                  EP positive       − 0.248019***   0.080441              − 3.083248     0.0035
  GDP                   0.8122                               − 3.578558 (2001Q1)                     t-1

  TO                    0.8266                               − 3.861973 (1987Q4)
                                                                                                       negative
                                                                                                  EP t-1            0.105981        0.106991              0.990564       0.3271
                                                                                                  ENT positive      − 0.074645**    0.028188              − 2.648079     0.0111
  At first difference                                                                                 t-1
                                                                                                  ENT t-1
                                                                                                         negative   − 0.053334*     0.030873              − 1.727557     0.0908
  D.CO2                 − 2.109**                            − 7.621671 *** (2010Q1)                                1.108991***     0.244933              4.527722       0.0000
                                                                                                  GDP positive
                                                                                                      t -1
  D.MRE                 − 3.332***                           − 6.386998 *** (1986Q1)
                                                                                                  GDP t-1
                                                                                                         negative   1.506676***     0.346731              4.345375       0.0001
  D.EP                  − 2.1811**                           − 7.457773 *** (1988Q1)
  D.ENT                 − 3.4687***                          − 8.012951 *** (2002Q1)              TO positive       − 0.159603***   0.051469              − 3.100951     0.0033
                                                                                                     t -1
  D.GDP                 − 2.1049**                           − 5.969005 *** (1988Q1)                   negative
                                                                                                  TO t-1            0.283900***     0.068431              4.148704       0.0001
  D.TO                  − 4.4297***                          − 6.942305 *** (1986Q1)
                                                                                                  Model diagnostic test
Note: “*, **, and *** denote statistically significant at the 10 %, 5 %, and 1 %                  Test description                  Test Statistics       Decision
levels, respectively”.                                                                             2
                                                                                                  R                                 0.944973              Model denotes a solid fit
                                                                                                  Wald test                         34.76 *** (0.000)     The existence of Long-
                                                                                                                                                          term asymmetry
Table 4                                                                                           Jarque–Bera                       1.442 (0.4862)        Normality of the residuals
FADLC and NARDL bounds tests.                                                                     Serial correlation (Breusch-      3.955 (0.138)         Absence of
                                                                                                    Godfrey LM)Test                                       autocorrelation.
  FADLC test result
                                                                                                  Heteroscedasticity (Breusch-      0.699 (0.974)         Absence of
  Model                               Test statistic   Optimal            Min AIC                   Pagan) test                                           Heteroscedasticity.
                                                       frequency                                  Ramsey RESET test (F)             2.533 (0.115)         The specification is
                                                                                                                                                          consistent.
  CO2 = f (MRE, EP, ENT, GDP,         − 3.054236       2                  − 4.643911
   TO)                                                                                        Notes: *, **, and *** denote statistically significant at the 10 %, 5 %, and 1 %
  NARDL bound test result             ​                ​                  ​                   levels, respectively.
  Model                               F-statistics     K                  ​
  CO2 = f (MRE, EP, ENT, GDP,         5.972448         10                 ​
   TO)                                                                                        inverse relationship between EP and CO2 emissions, underscoring the
                                                                                              crucial role of EP in mitigating CO2 emissions. This suggests policy­
Note: The critical values from Banerjee et al. [73] are employed as the bench­
                                                                                              makers should prioritize harnessing the potential benefits of positive EP
mark for determining statistical significance.
                                                                                              shocks rather than negative ones, which have negligible effects on
                                                                                              emissions. Moreover, it is noteworthy that positive EP shocks exhibit
4.3. Asymmetric ARDL empirical analysis
                                                                                              superior CO2 mitigation capabilities, rendering them particularly valu­
                                                                                              able for policy objectives aimed at fostering a sustainable environment.
    Following the validation of the co-integration among the variables,
                                                                                              For example, implementing an annual increase in EP as a policy measure
we now investigate the asymmetric effects of RE, EP, ENT, GDP, and TO
                                                                                              in Algeria would curb CO2 emissions while decreasing EP and reversing
on CO2 using the NARDL technique. The long-run estimates of the
                                                                                              this policy would only minimally impact emissions. This highlights the
NARDL model are presented in Table 5. As shown in Table 5, a positive
                                                                                              necessity to leverage positive EP shocks to achieve substantial re­
shock of 1 % in MRE in Algeria reduces CO2 emissions by 0.15 %. On the
                                                                                              ductions in Algerian emissions. In summary, asymmetrical analysis re­
other hand, a negative shock of 1 % in MRE decreases CO2 emissions by
                                                                                              veals a strategic emphasis on positive EP shocks offers greater emissions
just 0.11 %, implying a positive shock’s impact is roughly 1.5 times that
                                                                                              mitigation potential than negative shocks within the Algerian context.
of a negative one. Thus, both positive and negative MRE shocks appear
                                                                                              This finding proves the empirical results of [71,72,75,81].
to lower long-term CO2 emissions, though positive shocks have a greater
                                                                                                  The regression results demonstrated that ENT reduces CO2 emis­
effect. The results indicate that the utilization of MRE reduces CO2
                                                                                              sions, with the coefficients being negative and significant at the 1 %
emissions. This is in line with the findings of several previous studies,
                                                                                              level. Specifically, a 1 % increase in ENT decreases CO2 by 0.0746 %,
such as [31,38,80] which have all verified that the application of MRE
                                                                                              while a 1 % decrease in ENT declines CO2 by 0.0533 %. This suggests
enhances environmental sustainability.
                                                                                              ENT could serve as an effective policy tool to mitigate Algeria’s envi­
    Regarding EP, the results demonstrate that a 1 % positive shock to EP
                                                                                              ronmental degradation, consistent with previous studies by Refs. [19,26,
reduces CO2 emissions by 0.248 %, while negative EP shocks have an
                                                                                              82].
insignificant impact on CO2 emissions. These findings indicate an
                                                                                                  The estimated positive and negative gross domestic product (GDP)


                                                                                          9
B. Bergougui                                                                                                                          Energy Strategy Reviews 55 (2024) 101541


shocks revealed a 1 % increase in economic growth boosts CO2 emis­                           Granger causes CO2 emissions. Overall, both symmetric and asymmetric
sions by 1.1 %, while a 1 % negative shock to growth increases emissions                     causal analyses underscore the influential causal effects of MRE, EP,
by 1.5 %. This highlights that rising GDP has a substantial impact on the                    ENT, and trade openness on Algerian CO2 emissions over time.
environment, with unsustainable resource consumption worsening at­
mospheric sustainability and escalating pollution. As countries indus­                       4.5. Sensitive analysis
trialize further, focusing on more sectors expands energy demands and
emissions. Our findings align [83–86] in conclusion GDP has a positive,                          This section examines the reliability of the key findings presented in
considerable effect on environmental degradation.                                            Table 5 through a series of multifaceted analyses, detailed in Table 7. We
    Finally, the results show that the coefficient estimates of trade                        investigate the potential influence of methodological decisions by
openness with positive shock (negative shock) have a negative effect                         employing various approaches (FMOLS and CCR). Additionally, we
(positive effect) on CO2 emissions, implying that increasing (decreasing)                    examine the sensitivity of the results to the chosen dependent variable
trade openness is related to a better (worse) environment in Algeria.                        and the inclusion of control variables. The baseline results from Table 5
These findings contradict the "pollution haven" hypothesis and suggest                       are conveniently replicated in the first column of Table 7 to facilitate
that trade liberalization, when coupled with appropriate environmental                       comparison with the robustness checks.
regulations, can contribute to emissions reduction. The results echo the                         To address concerns about endogeneity and serial correlation, we
conclusions of recent studies suggesting a negative association between                      employed alternative estimation approaches – FMOLS and CCR –
trade openness and environmental degradation [87,88].                                        (Table 7, Columns 2–3). These approaches yielded results that were
    The diagnostic examinations of the NARDL model provided in                               generally consistent with our initial findings in terms of direction and
Table 5 indicate the model is well-specified and stable. The Wald test                       significance, with a few exceptions (e.g., negative EP shock turning
detected significant asymmetry at the 1 % level, implying positive and                       positive under the CCR approach). We further investigated the depen­
negative shocks of the variables have differential effects on CO2 emis­                      dence of our findings on the chosen dependent variable. Utilizing the
sions. Tests for serial correlation (Breusch-Godfrey LM) and hetero­                         natural log of ecological footprint as a substitute measure (Table 7,
scedasticity (Breusch-Pagan) were insignificant. Additionally, the                           Column 4) revealed similar coefficient magnitudes to the original re­
Ramsey regression specification test confirmed the model is properly                         sults. However, a previously insignificant positive effect of negative
specified. In summary, the NARDL model passed all diagnostic checks                          shocks in EP on emissions became significant with this alternative
for stability, asymmetry, residual correlations, error variance, and                         measure. Finally, we assessed the sensitivity of the results to the inclu­
appropriate functional form.                                                                 sion of control variables by re-estimating the model without them
                                                                                             (Table 7, Column 5). The overall coefficient magnitudes remained
4.4. Symmetric and asymmetric causality                                                      largely unchanged. However, one previously significant positive effect
                                                                                             of negative shocks in ENT on emissions became insignificant when
    Numerous studies have used the symmetric GSC test developed by                           control variables were excluded. Overall, the core results demonstrate
Nazlioglu et al. [78] and the asymmetric causality approach proposed by                      resilience across a series of robustness checks employing various esti­
Hatemi-j [79] in environmental research (e.g., Refs. [38,89,90]. Panel A                     mation approaches and model configurations. This bolsters our confi­
of Table 6 reports the GSC results, indicating MRE, EP, and ENT Granger                      dence in the validity of the key findings.
cause CO2 emissions in Algeria, highlighting their critical role in driving
environmental degradation. Panel B’s asymmetric causality test results                       5. Discussion and policy implications
corroborate the GSC outcomes and further reveal trade openness
                                                                                                 This section delves into the key empirical insights gleaned from the
Table 6                                                                                      analysis, drawing upon Fig. 7 for visual representation. Three main
Symmetric and asymmetric causality tests.                                                    findings will be highlighted, each offering valuable insights and poten­
                                                                                             tial policy implications that will be explored in detail.
  Panel A: Fourier symmetric gradual shift causality test [78]
                                                                                                 Firstly, the study shows both positive and negative MRE shocks
  Direction of        K                p                  F-stat         Bootstrap p-        substantially reduce Algerian emissions. Several factors drive the CO2
  causality                                                              value
                                                                                             decline when efficiency rises: (i) Efficiency gains in oil and gas production:
  MRE ⇒ CO2           4.000000         3.000000           10.61089       0.031303            A significant portion of Algeria’s emissions originates from its oil and
  EP ⇒ CO2            5.000000         6.000000           12.49183       0.028636
                                                                                             gas sector. Increased efficiency in the extraction, processing, and con­
  ENT ⇒ CO2           4.000000         3.000000           8.271763       0.082115
  GDP ⇏ CO2           1.000000         3.000000           0.280061       0.596661            sumption of these resources directly curtails carbon emissions.
  TO ⇏ CO2            2.000000         4.000000           0.105001       0.948854            Upgrading equipment plays a crucial role in achieving these efficiency
  Panel B: Asymmetric causality test [79]
                                                                                             gains [91,92]. (ii) Economic growth with decoupled emissions: Improved
                                                                                             MRE allows for economic expansion without a proportional rise in en­
  Direction of        Wald test        Bootstrap CV       Bootstrap CV   Bootstrap CV
                                                                                             ergy requirements and emissions. This is achieved by enabling greater
    causality                          10 %               5%             1%
                                                                                             economic output per unit of resource input. Additionally, MRE facili­
  RE+ ⇏ CO+ 2         2.9753           3.0093             4.6153         8.0743              tates the adoption of less emission-intensive technologies and capital
  RE− ⇒ CO2−          11.8463***       2.9433             4.3213         10.9033
  EP+ ⇒ CO+           78.0593***       52.4843            17.5453        11.3963
                                                                                             assets, while promoting a shift towards renewable energy sources. This
           2
  EP− ⇏ CO−2          0.6003           11.6403            7.6793         5.5353              decoupling of economic growth from emissions growth is crucial for
  ENT ⇒ CO+
      +
              2       10.8233***       2.9923             4.4963         14.5193             sustainable development [93,94]. (iii) Reduced methane emissions from
  ENT-⇏ CO−2          1.6753           3.0863             4.2383         7.3833              waste: MRE advancements can lead to reductions in material waste
  GDP+⇏ CO2   +
                      2.1583           10.6333            7.0683         5.2893
                                                                                             generation. This translates to lower methane emissions from landfills
  GDP-⇏ CO−2          1.3043           21.6173            8.2863         5.0363
  TO+⇏ CO2+           1.1233           10.6703            6.9203         5.3983              and other waste sources, as methane is a potent greenhouse gas with a
  TO-⇒ CO−2           13.0043**        26.2643            9.5253         5.1433              significant contribution to global warming. Improved efficiency can
                                                                                             mitigate the climate impact of waste streams by curtailing material
Note: ⇒ and ⇏ indicates one-way causality or no causality, respectively. Initial
maximum lags k and p were set to 5 and 12 before optimal k and p were chosen                 waste and associated methane releases [95,96].
by the Akaike Information Criterion. Bootstrap p-values were computed using                      Secondly, the analysis also reveals an interesting asymmetry in the
1000 resamples. Critical values (CV) denote significance at 10 %, 5 %, and 1 %               relationship between EP shocks and CO2 emissions in Algeria. Positive
for _, *, and ***, respectively. The optimal lag was selected based on the Hatemi-           shocks to EP, signifying increased output per unit of energy input, are
J Criterion (HJC).                                                                           associated with a negative impact on CO2 emissions, meaning they lead

                                                                                        10
B. Bergougui                                                                                                                              Energy Strategy Reviews 55 (2024) 101541


Table 7
Sensitive analysis outcomes.
  Variables          Baseline results             Alternative estimation       Ecological footprint as an alternative dependent   Excluding control          Additional
                     Using CO2 as the dependent   methods                      variable                                           variables                  Variables
                     variable
                                                  FMOLS         CCR

                     (1)                          (2)           (3)            (4)                                                (5)                        (6)

  MRE positive       − 0.153*                     − 0.249**     − 0.728**      − 0.021***                                         − 0.137**                  − 0.269***
          t -1
  MREt-1
          negative   − 0.113**                    − 0.189***    − 0.438**      − 0.017*                                           − 0.097*                   − 0.529*
  EP positive        − 0.248***                   − 0.344**     − 0.475***     − 0.030**                                          − 0.232**                  − 0.364***
     t -1
     negative
  EP t-1             0.106                        0.019*        0.089          − 0.005**                                          0.122                      − 0.019
  ENT positive       − 0.075**                    − 0.171*      − 0.454**      − 0.013***                                         − 0.059**                  − 0.191***
         t -1
  ENT t-1
         negative    − 0.053*                     − 0.149**     − 0.514        − 0.081***                                         − 0.037                    − 0.169**
  GDP positive       1.109***                     1.513***      2.048***       0.205**                                            /                          0.993***
         t-1
  GDP t-1
         negative    1.507***                     1.411**       1.072***       − 0.445                                            /                          1.391***
      positive
  TO t-1             − 0.160***                   − 0.256***    − 0.844***     − 0.022***                                         /                          − 0.276**
      negative
  TO t-1             0.284***                     0.188**       1.150***       0.023**                                            /                          0.168*
  EPU positive       /                            /             /              /                                                  /                          0.877
        t -1
        negative
  EPU t-1            /                            /             /              /                                                  /                          − 1.275*
  PS positive        /                            /             /              /                                                  /                          − 0.392**
     t-1
     negative
  PS t-1             /                            /             /              /                                                  /                          − 0.052

Note. EPI: Economic Policy Uncertainty. PS: Political Stability.




                                                                    Fig. 7. Summary of empirical findings.


to reductions. However, negative shocks to EP do not exhibit a signifi­                       sustainable energy sources, reducing fossil fuel dependence and emis­
cant effect on emissions. These findings align with previous research by                      sions. Mechanisms for emissions reduction with increased ENT: (i)
Refs. [31,38,97] who identified similar asymmetric relationships be­                          Development of sustainable energy sources: ENT enables the creation of
tween EP and emissions. As EP represents useful economic output ob­                           new, sustainable energy sources, fostering a reduction in dependence on
tained per unit of energy input, higher productivity reduces pollution in                     fossil fuels and their associated emissions. (ii) Discoveries in green tech­
the hydrocarbon Algerian economy for several reasons: (i) Reduced en­                         nology: Increased ENT investment leads to discoveries of novel envi­
ergy waste and emissions: Higher EP translates to less wasted energy                          ronmentally friendly energy technologies, promoting efficient land use
during production processes. This directly reduces emissions associated                       and consumption through green manufacturing practices. This com­
with fossil fuel combustion. (ii) Cost savings and emission reduction in­                     bined effect contributes to a decrease in CO2 emissions [98]. (iii) Ex­
centives: Improvements in EP lead to cost savings for companies. These                        amples of successful implementation: Countries like Germany, France,
savings can incentivize further reductions in energy consumption and                          Japan, and the USA showcase successful applications of ENT advance­
associated CO2 emissions. (iii) Exporting refined products for enhanced                       ments like flue-gas desulfurization, nuclear energy, and electric vehicles.
economic growth and emission decoupling: For oil-exporting nations like                       These technologies demonstrably enhance environmental sustainability
Algeria, increased EP allows for the export of higher-value refined                           by curbing greenhouse gas emissions [99,100]. These findings support
products instead of raw crude oil. This can boost economic growth                             existing research by Refs. [82,101–104] which highlight the positive
without a proportional increase in emissions.                                                 role of ENT and related technologies in reducing emissions.
    Third, ENT’s dampening impact suggests higher ENT patents are                                 Based on the empirical results, the Algerian authorities should adopt
associated with enhanced environmental sustainability. This aligns with                       a number of policies to promote material resource efficiency (MRE),
expectations, as ENT in clean, eco-friendly processes can develop new,                        energy productivity (EP), and environmental technology (ENT) in order


                                                                                         11
B. Bergougui                                                                                                             Energy Strategy Reviews 55 (2024) 101541


to enhance environmental sustainability. The key policy implications              sources. SDG-12, responsible consumption and production, underscores
are as follows.                                                                   the importance of decoupling economic growth from environmental
                                                                                  degradation by continuously improving resource utilization throughout
 1 Prioritizing material resource efficiency: The analysis suggests that          consumption and production cycles by 2030. Similarly, SDG-12 em­
   enhancing material resource efficiency offers a significant pathway            phasizes the need for sustainable resource management by 2030. The
   for Algeria to meet its COP28 goals, particularly given the high               study’s findings demonstrate that increased ENT and expanded EP in
   material intensity and emissions associated with its economy. Cur­             Algeria have a positive impact on the country’s environmental sustain­
   rent climate policies often overlook emissions from material pro­              ability. These outcomes directly contribute to achieving the targets
   duction relative to land use changes. Therefore, Algerian authorities          outlined in SDGs 7 and 9. Furthermore, the link between improved
   should adopt the following policies:                                           resource efficiency and enhanced environmental sustainability in
   ➢ Enhance resource use in homes: By 2050, Algeria could substan­               Algeria aligns with the goals of COP-28 and SDGs 8 and 12.
      tially reduce emissions through policies that promote more effi­
      cient resource use in homes, minimize the use of residential                6. Conclusion, limitations, and future research
      building materials, and improve recycling practices.
   ➢ Shift to renewable energy: Transitioning to renewable energy pro­            6.1. Conclusion
      duction, which demands lower materials compared to fossil fuels,
      offers considerable potential for CO2 mitigation. Implementing                  The objective of this study is to analyse the asymmetric relationships
      these policies will help Algeria make significant strides toward            between ENT, EP, MRE, and environmental sustainability in Algeria
      achieving its COP28 goals and promoting sustainable develop­                using quarterly data from 1990:Q1 to 2022:Q4. By employing a
      ment through a comprehensive approach that addresses both                   nonlinear autoregressive distributed lag (NARDL) approach and ana­
      energy and material efficiency.                                             lysing asymmetric bootstrap causality, the study uncovered nuanced
 2 Leveraging energy productivity for sustainability: The findings                dynamics among these variables that traditional linear models may
   highlight the critical role of energy efficiency and sustainable con­          overlook. The NARDL methodology proved crucial in capturing the
   sumption practices in converting energy productivity gains into                nonlinear and asymmetric effects of MRE, EP, and ENT on environ­
   environmental benefits for Algeria. To enhance the country’s envi­             mental sustainability, particularly in the face of unforeseen events that
   ronmental sustainability, the following policy strategies are                  could disrupt these relationships. Additionally, the study utilized the
   recommended:                                                                   CCR method for robustness checks. The NARDL bound test confirms the
   ➢ Invest in energy efficiency technologies: Government initiatives that        existence of long-term equilibrium relationships among MRE, EP, ENT,
      promote the adoption of energy-efficient technologies and prac­             and environmental sustainability in Algeria over the entire study period.
      tices can significantly reduce energy waste and associated                      The outcomes of the long-run estimates reveal interesting asym­
      emissions.                                                                  metric effects. Positive shocks (increases) in MRE and EP lead to re­
   ➢ Incentivize sustainable consumption: Policies that encourage                 ductions in CO2 emissions, with a stronger mitigating effect observed for
      responsible energy consumption by businesses and households                 positive MRE shocks. Conversely, negative shocks in these variables
      can further contribute to reductions in overall CO2 emissions.              have a dampened impact or no significant effect on emissions. These
   ➢ Promote research and development (R&D): Increased investment in              findings support the effectiveness of MRE and EP improvements in
      R&D focused on innovative energy solutions that enhance effi­               mitigating environmental pollution. Similarly, both positive and nega­
      ciency and sustainability can help Algeria capitalize on the pos­           tive shocks in ENT contribute to a decrease in CO2 emissions, high­
      itive environmental effects of increased energy productivity and            lighting the potential of Algeria’s green initiatives in fostering
      achieve its sustainable development goals.                                  sustainable industrial practices. However, the analysis of the control
 3 Aligning environmental technology with sustainability goals: The               variable reveals that positive and negative shocks in GDP increase CO2
   study underscores the importance of aligning advancements in                   emissions. While Positive shock in trade is associated with a decrease in
   environmental technology with Algeria’s environmental sustain­                 emissions, negative shock (decreased trade) leads to an increase. Addi­
   ability goals. Policymakers should consider the following actions:             tionally, the findings from the symmetric and asymmetric causality
   ➢ Monitoring and strategic planning: Closely monitor trends in ENT             analysis reveal that MRE, EP, and ENT cause CO2 emissions in Algeria.
      development within Algeria. Develop proactive strategies to                 These findings are confirmed by employing alternative estimation
      leverage both positive and negative fluctuations in ENT to ach­             methods (FMOLS and CCR) and model specifications. These findings
      ieve environmental objectives. For example, a surge in green                resonate with the notion that the impact of these variables on environ­
      technology patents could be complemented by government in­                  mental sustainability can diverge depending on the direction of the
      vestment in infrastructure to support large-scale adoption.                 shock (positive or negative). Ignoring these nonlinearities could lead to
   ➢ Incentivizing green technology: Implement policies that incentivize          erroneous policy decisions.
      Algerian companies to invest in the development and adoption of
      environmentally friendly technologies. This could involve grants,           6.2. Limitations and future research
      tax breaks, and facilitated access to green technology expertise.
   ➢ Strategic alignment for sustainability: Foster a strategic alignment            While the current investigation has made noteworthy additions to
      between advancements in ENT and Algeria’s pursuit of environ­               the extant literature, it has also highlighted certain limitations that
      mental sustainability. This ensures that new technologies are               could serve as guideposts for future scholarly pursuits.
      developed and implemented with a focus on achieving long-term
      environmental goals.                                                           (i) The scarcity of data constrained the timeframe examined.
                                                                                         Although the decision to transform the data from annual to
    In tandem with Algeria’s efforts, international initiatives like the                 quarterly frequencies mitigated this limitation to some extent, the
UN’s SDGs and COP-28 emphasize environmental well-being. Several of                      accessibility of sufficient annual data would have been the
these objectives, particularly those focusing on affordable and clean                    optimal scenario.
energy (SDG-7) and industry, innovation, and infrastructure (SDG-9),                (ii) The study focused solely on EP as a representative of energy
aim for a substantial increase in renewable energy use by 2030. Addi­                    technology research and development (R&D) budgets. The
tionally, these goals promote research and development (R&D) in en­                      inability to assess the effectiveness of different R&D budget types,
ergy efficiency technologies to expedite the transition to renewable                     due to data limitations for the Algeria case, weakens the

                                                                             12
B. Bergougui                                                                                                                                Energy Strategy Reviews 55 (2024) 101541


        robustness of the findings. Analyzing various R&D categories                               sustainable development: moderating role of knowledge absorptive capacity,
                                                                                                   J. Clean. Prod. 411 (Jul. 2023) 137262, https://doi.org/10.1016/j.
        could pinpoint which ones have a more considerable influence on
                                                                                                   jclepro.2023.137262.
        lowering air pollution. Future research should incorporate these                      [11] Q. Jiang, Z.U. Rahman, X. Zhang, M.S. Islam, An assessment of the effect of green
        categories to gain a clearer understanding of the link between                             innovation, income, and energy use on consumption-based CO2 emissions:
        energy technology R&D investments and environmental                                        empirical evidence from emerging nations BRICS, J. Clean. Prod. 365 (Sep. 2022)
                                                                                                   132636, https://doi.org/10.1016/j.jclepro.2022.132636.
        sustainability.                                                                       [12] A.A. Alola, T.S. Adebayo, The potency of resource efficiency and environmental
  (iii) The study solely evaluated the impact of ENT on Algeria’s carbon                           technologies in carbon neutrality target for Finland, J. Clean. Prod. 389 (Feb.
        emissions. It is crucial to acknowledge that ENT’s influence on                            2023) 136127, https://doi.org/10.1016/j.jclepro.2023.136127.
                                                                                              [13] IEA, International Energy Agency, 2023 [Online]. Available: https://www.iea.
        Algeria’s carbon emissions may have wider geographical impli­                              org/data-and-statistics/data-product/energy-efficiency-indicators-highlights#h
        cations. International trade, investment, and other channels can                           ighlights.
        potentially transmit these effects to neighbouring countries. The                     [14] P. Ponce, S.A.R. Khan, A causal link between renewable energy, energy efficiency,
                                                                                                   property rights, and CO2 emissions in developed countries: a road map for
        regression techniques employed in this study were unable to ac­                            environmental sustainability, Environ. Sci. Pollut. Res. 28 (28) (2021)
        count for these spatial influences. Future studies could potentially                       37804–37817, https://doi.org/10.1007/s11356-021-12465-0.
        utilize panel spatial regression methodologies to explore the                         [15] IEA, Statistics Report Energy Technology RD&D Budgets, 2020, p. 16 [Online].
                                                                                                   Available: https://webstore.iea.org/energy-technology-rdd-budgets-2020-over
        geographical impact of ENT on African nations.                                             view.
  (iv) The study’s single-country focus on Algeria, employing time-                           [16] A.A. Alola, T.S. Adebayo, Are green resource productivity and environmental
        series methods, inherently assumes a similar air sustainability-                           technologies the face of environmental sustainability in the Nordic region?
                                                                                                   Sustain. Dev. 31 (2) (Apr. 2023) 760–772, https://doi.org/10.1002/sd.2417.
        determining function across all global economies. Future
                                                                                              [17] A.A. Awosusi, T.S. Adebayo, M. Altuntaş, E.B. Agyekum, H.M. Zawbaa, S. Kamel,
        research can address this limitation by conducting panel data                              The dynamic impact of biomass and natural resources on ecological footprint in
        analysis using data from Arab countries. This approach could                               BRICS economies: a quantile regression evidence, Energy Rep. 8 (2022)
        incorporate the unobserved, heterogeneous characteristics                                  1979–1994, https://doi.org/10.1016/j.egyr.2022.01.022.
                                                                                              [18] L. Wang, X.V. Vo, M. Shahbaz, A. Ak, Globalization and carbon emissions: is there
        unique to each regional country within the analysis.                                       any role of agriculture value-added, financial development, and natural resource
                                                                                                   rent in the aftermath of COP21? J. Environ. Manage. 268 (2020) 110712 https://
                                                                                                   doi.org/10.1016/j.jenvman.2020.110712.
Credit author statement
                                                                                              [19] B. Bergougui, Moving toward environmental mitigation in Algeria: asymmetric
                                                                                                   impact of fossil fuel energy, renewable energy and technological innovation on
    Brahim Bergougui: Conceptualization, Data curation, Investigation,                             CO2 emissions, Energy Strateg. Rev. 51 (Jan. 2024) 101281, https://doi.org/
                                                                                                   10.1016/j.esr.2023.101281.
Methodology, Software, Visualization, Writing - Original draft prepa­
                                                                                              [20] W. Tang, L. Mai, M. Li, Green innovation and resource efficiency to meet net-zero
ration, Writing - Reviewing and editing.                                                           emission, Resour. Policy 86 (Oct. 2023) 104231, https://doi.org/10.1016/j.
                                                                                                   resourpol.2023.104231.
                                                                                              [21] D. Acemoglu, P. Aghion, L. Bursztyn, D. Hemous, The environment and directed
Declaration of competing interest                                                                  technical change, Am. Econ. Rev. 102 (1) (Feb. 2012) 131–166, https://doi.org/
                                                                                                   10.1257/aer.102.1.131.
                                                                                              [22] B. Doğan, S. Ghosh, D.P. Hoang, L.K. Chu, Are economic complexity and eco-
    The authors declare that they have no known competing financial                                innovation mutually exclusive to control energy demand and environmental
interests or personal relationships that could have appeared to influence                          quality in E7 and G7 countries? Technol. Soc. 68 (Feb. 2022) 101867 https://doi.
the work reported in this paper.                                                                   org/10.1016/j.techsoc.2022.101867.
                                                                                              [23] S.R. Paramati, U. Shahzad, B. Doğan, The role of environmental technology for
                                                                                                   energy demand and energy efficiency: evidence from OECD countries, Renew.
Data availability                                                                                  Sustain. Energy Rev. 153 (2022) 111735, https://doi.org/10.1016/j.
                                                                                                   rser.2021.111735.
                                                                                              [24] S. Ahmed, K. Ahmed, M. Ismail, Predictive analysis of CO2 emissions and the role
    Data will be made available on request.
                                                                                                   of environmental technology, energy use and economic output: evidence from
                                                                                                   emerging economies, Air Qual. Atmos. Heal. 13 (9) (2020) 1035–1044, https://
References                                                                                         doi.org/10.1007/s11869-020-00855-1.
                                                                                              [25] E. Braun, D. Wield, Regulation as a means for the social control of technology,
                                                                                                   Technol. Anal. Strateg. Manag. 6 (3) (Jan. 1994) 259–272, https://doi.org/
  [1] N. Saqib, M. Usman, I. Ozturk, A. Sharif, Harnessing the synergistic impacts of
                                                                                                   10.1080/09537329408524171.
      environmental innovations, financial development, green growth, and ecological
                                                                                              [26] B. Lin, R. Ma, Green technology innovations, urban innovation environment and
      footprint through the lens of SDGs policies for countries exhibiting high
                                                                                                   CO2 emission reduction in China: fresh evidence from a partially linear
      ecological footprints, Energy Pol. 184 (Jan. 2024) 113863, https://doi.org/
                                                                                                   functional-coefficient panel model, Technol. Forecast. Soc. Change 176 (Mar.
      10.1016/j.enpol.2023.113863.
                                                                                                   2022) 121434, https://doi.org/10.1016/j.techfore.2021.121434.
  [2] P. Arora, COP28: ambitions, realities, and future, Environ. Sustain 7 (1) (2024)
                                                                                              [27] M. Hussain, G.M. Mir, M. Usman, C. Ye, S. Mansoor, Analysing the role of
      107–113, https://doi.org/10.1007/s42398-024-00304-0.
                                                                                                   environment-related technologies and carbon emissions in emerging economies: a
  [3] M. Aydin, A. Erdem, Analyzing the impact of resource productivity, energy
                                                                                                   step towards sustainable development, Environ. Technol. 43 (3) (Jan. 2022)
      productivity, and renewable energy consumption on environmental quality in EU
                                                                                                   367–375, https://doi.org/10.1080/09593330.2020.1788171.
      countries: the moderating role of productivity, Resour. Policy 89 (Feb. 2024)
                                                                                              [28] M.E. Porter, C. van der Linde, Toward a new conception of the environment-
      104613, https://doi.org/10.1016/j.resourpol.2023.104613.
                                                                                                   competitiveness relationship, J. Econ. Perspect. 9 (4) (1995) 97–118, https://doi.
  [4] UNPD, United nations development programme, (UNDP). https://www.undp.
                                                                                                   org/10.1257/jep.9.4.97.
      org/sustainable-development-goals, 2024.
                                                                                              [29] R. Ulucak Danish, S.U.-D. Khan, Determinants of the ecological footprint: role of
  [5] S. Chen, M.S. Hassan, A. Latif, A. Rafay, H. Mahmood, X. Xu, Investigating
                                                                                                   renewable energy, natural resources, and urbanization, Sustain. Cities Soc. 54
      resource curse/blessing hypothesis: an empirical insights from Luxembourg, The
                                                                                                   (2020) 101996, https://doi.org/10.1016/j.scs.2019.101996.
      Netherlands, and Portugal economies, Resour. Policy 83 (Jun. 2023) 103647,
                                                                                              [30] Q. Ding, S.I. Khattak, M. Ahmad, Towards sustainable production and
      https://doi.org/10.1016/j.resourpol.2023.103647.
                                                                                                   consumption: assessing the impact of energy productivity and eco-innovation on
  [6] B. Bergougui, S.M. Murshed, Aggregate and disaggregate impact of natural
                                                                                                   consumption-based carbon dioxide emissions (CCO2) in G-7 nations, Sustain.
      resources on sustainable development: new evidence from the latest institutional
                                                                                                   Prod. Consum. 27 (2021) 254–268, https://doi.org/10.1016/j.spc.2020.11.004.
      data, Environ. Sustain. Indic. 20 (Dec. 2023) 100302, https://doi.org/10.1016/j.
                                                                                              [31] D. Kirikkaleli, M. Ali, Resource efficiency, energy productivity, and
      indic.2023.100302.
                                                                                                   environmental sustainability in Germany, Environ. Dev. Sustain. (Nov. 2023),
  [7] Y. Yang, G. Subhani, Sakina, Y. Zhou, Natural resource and energy efficiency in
                                                                                                   https://doi.org/10.1007/s10668-023-04132-w.
      BRICS countries: can green innovation capabilities really change the game?
                                                                                              [32] R. Nataly Echevarria Huaman, T. Xiu Jun, Energy related CO2 emissions and the
      Gondwana Res. (Apr. 2024) https://doi.org/10.1016/j.gr.2024.03.014.
                                                                                                   progress on CCS projects: a review, Renew. Sustain. Energy Rev. 31 (2014)
  [8] B. Bergougui, M.I. Aldawsari, Asymmetric impact of patents on green
                                                                                                   368–385, https://doi.org/10.1016/j.rser.2013.12.002.
      technologies on Algeria’s Ecological Future, J. Environ. Manage. 355 (Mar. 2024)
                                                                                              [33] UNFCC, Paris agreement, in: Report of the Conference of the Parties to the United
      120426, https://doi.org/10.1016/j.jenvman.2024.120426.
                                                                                                   Nations Framework Convention on Climate Change (21st Session, 2015: Paris),
  [9] S. Karimi Takalo, H. Sayyadi Tooranloo, Z. Shahabaldini parizi, Green
                                                                                                   HeinOnline, 2015, p. 2017. Retrived December, [Online]. Available: https://un
      innovation: a systematic literature review, J. Clean. Prod. 279 (Jan. 2021)
                                                                                                   fccc.int/process-and-meetings/the-paris-agreement/the-paris-agreement.
      122474, https://doi.org/10.1016/j.jclepro.2020.122474.
                                                                                              [34] H.-H. Wu, in: H.-H. Wu, W.-Y. Liu, M.C. Huang (Eds.), Moving toward Net-Zero
 [10] Q. Fan, J. Abbas, Y. Zhong, P.S. Pawar, N.A. Adam, G. Bin Alarif, Role of
                                                                                                   Emission Society: with Special Reference to the Recent Law and Policy
      organizational and environmental factors in firm green innovation and


                                                                                         13
B. Bergougui                                                                                                                                  Energy Strategy Reviews 55 (2024) 101541

      Development in Some Selected Countries BT - Moving toward Net-Zero Carbon                      window approach, Sustain. Dev. 31 (1) (Feb. 2023) 393–414, https://doi.org/
      Society: Challenges and Opportunities, Springer International Publishing, Cham,                10.1002/sd.2399.
      2023, pp. 151–169, https://doi.org/10.1007/978-3-031-24545-9_10.                          [57] H. Chen, J. Yi, A. Chen, D. Peng, J. Yang, Green technology innovation and CO2
 [35] J. Barrett, K. Scott, Link between climate change mitigation and resource                      emission in China: evidence from a spatial-temporal analysis and a nonlinear
      efficiency: a UK case study, Glob. Environ. Chang. 22 (1) (Feb. 2012) 299–307,                 spatial durbin model, Energy Pol. 172 (2023) 113338, https://doi.org/10.1016/j.
      https://doi.org/10.1016/j.gloenvcha.2011.11.003.                                               enpol.2022.113338.
 [36] S. Hatfield-Dodds, et al., Assessing global resource use and greenhouse emissions         [58] F. Chien, C.-C. Hsu, M. Moslehpour, M. Sadiq, B. Tufail, T.Q. Ngo, A step toward
      to 2050, with ambitious resource efficiency and climate mitigation policies,                   sustainable development: the nexus of environmental sustainability,
      J. Clean. Prod. 144 (Feb. 2017) 403–414, https://doi.org/10.1016/j.                            technological advancement and green finance: evidence from Indonesia, Environ.
      jclepro.2016.12.170.                                                                           Dev. Sustain. (2023), https://doi.org/10.1007/s10668-023-03424-5.
 [37] B. Plank, N. Eisenmenger, A. Schaffartzik, Do material efficiency improvements            [59] J. Liao, X. Liu, X. Zhou, N.R. Tursunova, Analyzing the role of renewable energy
      backfire?: insights from an index decomposition analysis about the link between                transition and industrialization on ecological sustainability: can green innovation
      CO 2 emissions and material use for Austria, J. Ind. Ecol. 25 (2) (Apr. 2021)                  matter in OECD countries, Renew. Energy 204 (2023) 141–151, https://doi.org/
      511–522, https://doi.org/10.1111/jiec.13076.                                                   10.1016/j.renene.2022.12.089.
 [38] D. Kirikkaleli, Resource efficiency, energy productivity, and environmental               [60] D. Töbelmann, T. Wendler, The impact of environmental innovation on carbon
      quality in Japan, Resour. Policy 85 (Aug. 2023) 104006, https://doi.org/                       dioxide emissions, J. Clean. Prod. 244 (Jan. 2020) 118787, https://doi.org/
      10.1016/j.resourpol.2023.104006.                                                               10.1016/j.jclepro.2019.118787.
 [39] A.A. Awosusi, B.S. Eweade, O.S. Ojekemi, Analyzing the environmental role of              [61] M. Mongo, F. Belaïd, B. Ramdani, The effects of environmental innovations on
      resource efficiency, economic globalization, and biomass usage in Malaysia: a                  CO2 emissions: empirical evidence from Europe, Environ. Sci. Policy 118 (Apr.
      time-varying causal approach, Environ. Dev. Sustain. (2024), https://doi.org/                  2021) 1–9, https://doi.org/10.1016/j.envsci.2020.12.004.
      10.1007/s10668-024-05196-y.                                                               [62] Z. Wang, Y. Zhu, Do energy technology innovations contribute to CO2 emissions
 [40] D. Kirikkaleli, M. Umar, Do resource efficiency and energy productivity matter for             abatement? A spatial perspective, Sci. Total Environ. 726 (Jul. 2020) 138574,
      environmental sustainability in G7, Energy Environ. (Jun. 2024), https://doi.org/              https://doi.org/10.1016/j.scitotenv.2020.138574.
      10.1177/0958305X241260073, 0958305X241260073.                                             [63] X.-G. Yue, Y. Liao, S. Zheng, X. Shao, J. Gao, The role of green innovation and
 [41] O. Ozkan, B.S. Eweade, O. Usman, Assessing the impact of resource efficiency,                  tourism towards carbon neutrality in Thailand: evidence from bootstrap ADRL
      renewable energy R& D spending, and green technologies on environmental                        approach, J. Environ. Manage. 292 (2021) 112778, https://doi.org/10.1016/j.
      sustainability in Germany: evidence from a Wavelet Quantile-on-Quantile                        jenvman.2021.112778.
      Regression, J. Clean. Prod. 450 (Apr. 2024) 141992, https://doi.org/10.1016/j.            [64] S. Shan, S.Y. Genç, H.W. Kamran, G. Dinca, Role of green technology innovation
      jclepro.2024.141992.                                                                           and renewable energy in carbon neutrality: a sustainable investigation from
 [42] A.C. Kerkhof, H.C. Moll, E. Drissen, H.C. Wilting, Taxation of multiple greenhouse             Turkey, J. Environ. Manage. 294 (Sep. 2021) 113004, https://doi.org/10.1016/j.
      gases and the effects on income distribution: a case study of The Netherlands,                 jenvman.2021.113004.
      Ecol. Econ. 67 (2) (2008) 318–326, https://doi.org/10.1016/j.                             [65] L. Qin, D. Kirikkaleli, Y. Hou, X. Miao, M. Tufail, Carbon neutrality target for G7
      ecolecon.2007.12.015.                                                                          economies: examining the role of environmental policy, green innovation and
 [43] F.C. Özbuğday, B.C. Erbas, How effective are energy efficiency and renewable                 composite risk index, J. Environ. Manage. 295 (2021) 113119, https://doi.org/
      energy in curbing CO2 emissions in the long run? A heterogeneous panel data                    10.1016/j.jenvman.2021.113119.
      analysis, Energy 82 (Mar. 2015) 734–745, https://doi.org/10.1016/j.                       [66] S.R. Paramati, D. Mo, R. Huang, The role of financial deepening and green
      energy.2015.01.084.                                                                            technology on carbon emissions: evidence from major OECD economies, Financ.
 [44] S.-C. Xu, Z.-X. He, R.-Y. Long, W.-X. Shen, S.-B. Ji, Q.-B. Chen, Impacts of                   Res. Lett. 41 (2021) 101794, https://doi.org/10.1016/j.frl.2020.101794.
      economic growth and urbanization on CO2 emissions: regional differences in                [67] N.M. Suki, N.M. Suki, S. Afshan, A. Sharif, M.S. Meo, The paradigms of
      China based on panel estimation, Reg. Environ. Chang. 16 (3) (2016) 777–787,                   technological innovation and renewables as a panacea for sustainable
      https://doi.org/10.1007/s10113-015-0795-0.                                                     development: a pathway of going green, Renew. Energy 181 (2022) 1431–1439,
 [45] R. Akram, F. Chen, F. Khalid, Z. Ye, M.T. Majeed, Heterogeneous effects of energy              https://doi.org/10.1016/j.renene.2021.09.121.
      efficiency and renewable energy on carbon emissions: evidence from developing             [68] L. Xu, M.T. Fan, L.L. Yang, S. Shao, Heterogeneous green innovations and carbon
      countries, J. Clean. Prod. 247 (Feb) (2020), https://doi.org/10.1016/j.                        emission performance: evidence at China’s city level, ENERGY Econ 99 (Jul.
      jclepro.2019.119122.                                                                           2021), https://doi.org/10.1016/j.eneco.2021.105269.
 [46] S. Wahab, X. Zhang, A. Safi, Z. Wahab, M. Amin, Does energy productivity and              [69] X. Shao, Y. Zhong, W. Liu, R.Y.M. Li, Modeling the effect of green technology
      technological innovation limit trade-adjusted carbon emissions? Econ. Res.                     innovation and renewable energy on carbon neutrality in N-11 countries?
      Istraživanja 34 (1) (Jan. 2021) 1896–1912, https://doi.org/10.1080/                           Evidence from advance panel estimations, J. Environ. Manage. 296 (4) (Oct.
      1331677X.2020.1860111.                                                                         2021) 113189, https://doi.org/10.1016/j.jenvman.2021.113189.
 [47] M. Amin, S. Zhou, A. Safi, The nexus between consumption-based carbon                     [70] S.I. Khattak, M. Ahmad, Z. ul Haq, G. Shaofu, J. Hang, On the goals of sustainable
      emissions, trade, eco-innovation, and energy productivity: empirical evidence                  production and the conditions of environmental sustainability: does cyclical
      from N-11 economies, Environ. Sci. Pollut. Res. 29 (26) (2022) 39239–39248,                    innovation in green and sustainable technologies determine carbon dioxide
      https://doi.org/10.1007/s11356-021-18327-z.                                                    emissions in G-7 economies, Sustain. Prod. Consum. 29 (Jan. 2022) 406–420,
 [48] P. Xie, F. Jamaani, Does green innovation, energy productivity and                             https://doi.org/10.1016/j.spc.2021.10.022.
      environmental taxes limit carbon emissions in developed economies: implications           [71] D. Kirikkaleli, J.K. Sowah, The asymmetric and long run effect of energy
      for sustainable development, Struct. Chang. Econ. Dyn. 63 (2022) 66–78, https://               productivity on quality of environment in Finland, J. Clean. Prod. 383 (2023)
      doi.org/10.1016/j.strueco.2022.09.002.                                                         135285, https://doi.org/10.1016/j.jclepro.2022.135285.
 [49] M.O. Oyebanji, D. Kirikkaleli, Energy productivity and environmental                      [72] D. Kirikkaleli, J. Karmoh Sowah, K. Addai, The asymmetric and long-run effect of
      deregulation: the case of Greece, Environ. Sci. Pollut. Res. 29 (55) (2022)                    energy productivity on environmental quality in Ireland, Environ. Sci. Pollut. Res.
      82772–82784, https://doi.org/10.1007/s11356-022-21590-3.                                       30 (13) (2023) 37691–37705, https://doi.org/10.1007/s11356-022-24832-6.
 [50] X. Zhang, et al., The impact of energy intensity, energy productivity and natural         [73] P. Banerjee, V. Arčabić, H. Lee, Fourier ADL cointegration test to approximate
      resource rents on carbon emissions in Morocco, Sustainability 15 (8) (2023),                   smooth breaks with new evidence from Crude Oil Market, Econ. Model. 67 (2017)
      https://doi.org/10.3390/su15086720.                                                            114–124, https://doi.org/10.1016/j.econmod.2016.11.004.
 [51] X. Zhang, X. Shi, Y. Khan, T. Hassan, M. Marie, Carbon neutrality challenge:              [74] A.R. Gallant, On the bias in flexible functional forms and an essentially unbiased
      analyse the role of energy productivity, renewable energy, and collaboration in                form. The fourier flexible form, J. Econom. 15 (2) (1981) 211–245, https://doi.
      climate mitigation technology in OECD economies, Sustainability 15 (4) (2023),                 org/10.1016/0304-4076(81)90115-9.
      https://doi.org/10.3390/su15043447.                                                       [75] D. Kirikkaleli, J.K. Sowah, K. Addai, M. Altuntaş, Energy productivity and
 [52] D. Kirikkaleli, K. Addai, R.A. Castanho, Energy productivity, financial stability,             environmental quality in Sweden: evidence from Fourier and non-linear based
      and environmental degradation in an Eastern European country: evidence from                    approaches, Geol. J. 58 (9) (Sep. 2023) 3452–3465, https://doi.org/10.1002/
      novel Fourier approaches, Heliyon 9 (7) (Jul. 2023) e18073, https://doi.org/                   gj.4684.
      10.1016/j.heliyon.2023.e18073.                                                            [76] F. Ayhan, M.T. Kartal, S. Kılıç Depren, Ö. Depren, Asymmetric effect of economic
 [53] M. Favot, L. Vesnic, R. Priore, A. Bincoletto, F. Morea, Green patents and green               policy uncertainty, political stability, energy consumption, and economic growth
      codes: how different methodologies lead to different results, Resour. Conserv.                 on CO2 emissions: evidence from G-7 countries, Environ. Sci. Pollut. Res. 30 (16)
      Recycl. Adv. 18 (Oct. 2023) 200132, https://doi.org/10.1016/j.                                 (2023) 47422–47437, https://doi.org/10.1007/s11356-023-25665-7.
      rcradv.2023.200132.                                                                       [77] Y. Shin, B. Yu, M. Greenwood-Nimmo, in: R.C. Sickles, W.C. Horrace (Eds.),
 [54] Z. Lv, L. Chen, S.A. Ali, I. Muda, A. Alromaihi, J.Y. Boltayev, Financial                      Modelling Asymmetric Cointegration and Dynamic Multipliers in a Nonlinear
      technologies, green technologies and natural resource nexus with sustainable                   ARDL Framework BT - Festschrift in Honor of Peter Schmidt: Econometric
      development goals: evidence from resource abundant economies using MMQR                        Methods and Applications, Springer New York, New York, NY, 2014,
      estimation, Resour. Policy 89 (2024) 104649, https://doi.org/10.1016/j.                        pp. 281–314, https://doi.org/10.1007/978-1-4899-8008-3_9.
      resourpol.2024.104649.                                                                    [78] S. Nazlioglu, N.A. Gormus, U. Soytas, Oil prices and real estate investment trusts
 [55] T. Li, X.-G. Yue, M. Qin, D. Norena-Chavez, Towards Paris Climate Agreement                    (REITs): gradual-shift causality and volatility transmission analysis, Energy Econ.
      goals: the essential role of green finance and green technology, Energy Econ. 129              60 (2016) 168–175, https://doi.org/10.1016/j.eneco.2016.09.009.
      (2024) 107273, https://doi.org/10.1016/j.eneco.2023.107273.                               [79] A. Hatemi-j, Asymmetric causality tests with an application, Empir. Econ. 43
 [56] M. Ramzan, U. Razi, M.U. Quddoos, T.S. Adebayo, Do green innovation and                        (2012) 447–456.
      financial globalization contribute to the ecological sustainability and energy
      transition in the United Kingdom? Policy insights from a bootstrap rolling


                                                                                           14
B. Bergougui                                                                                                                                      Energy Strategy Reviews 55 (2024) 101541

 [80] D. Kirikkaleli, R.A. Castanho, R. Deniz Özbay, S. Yilmaz Genc, Z. Ahmed, Does                    Advances in Green Energies and Materials Technology, Springer Singapore,
      resource efficiency matter for environmental quality in Canada? Front. Environ.                   Singapore, 2021, pp. 57–62.
      Sci. 11 (Sep) (2023) https://doi.org/10.3389/fenvs.2023.1276632.                             [94] F.Z. Nouasria, B. Oussama, A. Karar, An Analysis of Hydrogen Production from
 [81] J.K. Sowah, S.Y. Genc, R.A. Castanho, G. Couto, M. Altuntas, D. Kirikkaleli, The                  Renewable and Sustainable Energy Resources in Algeria, Springer Berlin
      asymmetric and symmetric effect of energy productivity on environmental                           Heidelberg, Berlin, Heidelberg, 2023, pp. 1–16, https://doi.org/10.1007/698_
      quality in the era of industry 4.0: empirical evidence from Portugal, Sustainability              2023_1027.
      15 (5) (2023), https://doi.org/10.3390/su15054096.                                           [95] B.T. Eddine, M.M. Salah, Solid waste as renewable source of energy: current and
 [82] C. Jiakui, J. Abbas, H. Najam, J. Liu, J. Abbas, Green technological innovation,                  future possibility in Algeria, Int. J. Energy Environ. Eng. 3 (1) (2012) 17, https://
      green finance, and financial development and their role in green total factor                     doi.org/10.1186/2251-6832-3-17.
      productivity: empirical insights from China, J. Clean. Prod. 382 (Jan. 2023)                 [96] M. Cordella, F. Alfieri, J. Sanfelix, S. Donatello, R. Kaps, O. Wolf, Improving
      135131, https://doi.org/10.1016/j.jclepro.2022.135131.                                            material efficiency in the life cycle of products: a review of EU Ecolabel criteria,
 [83] M.A. Nasir, T.L. Duc Huynh, H.T. Xuan Tram, Role of financial development,                        Int. J. Life Cycle Assess. 25 (5) (2020) 921–935, https://doi.org/10.1007/
      economic growth & foreign direct investment in driving climate change: a case of                  s11367-019-01608-8.
      emerging ASEAN, J. Environ. Manage. 242 (2019) 131–141, https://doi.org/                     [97] B. Mahapatra, M. Irfan, Asymmetric impacts of energy efficiency on carbon
      10.1016/j.jenvman.2019.03.112.                                                                    emissions: a comparative analysis between developed and developing economies,
 [84] H. Zhang, Y. Shao, X. Han, H.-L. Chang, A road towards ecological development                     Energy 227 (2021) 120485, https://doi.org/10.1016/j.energy.2021.120485.
      in China: the nexus between green investment, natural resources, green                       [98] M. Ibrahim, X.V. Vo, Exploring the relationships among innovation, financial
      technology innovation, and economic growth, Resour. Policy 77 (2022) 102746,                      sector development and environmental pollution in selected industrialized
      https://doi.org/10.1016/j.resourpol.2022.102746.                                                  countries, J. Environ. Manage. 284 (Apr. 2021) 112057, https://doi.org/
 [85] M. Hussain, E. Dogan, The role of institutional quality and environment-related                   10.1016/j.jenvman.2021.112057.
      technologies in environmental degradation for BRICS, J. Clean. Prod. 304 (2021)              [99] D. Kirikkaleli, E. Sofuoğlu, O. Ojekemi, Does patents on environmental
      127059, https://doi.org/10.1016/j.jclepro.2021.127059.                                            technologies matter for the ecological footprint in the USA? Evidence from the
 [86] M.B. Hasan, J. Wieloch, M.S. Ali, S. Zikovic, G.S. Uddin, A new answer to the old                 novel Fourier ARDL approach, Geosci. Front. 14 (4) (Jul. 2023) 101564, https://
      question of the environmental Kuznets Curve (EKC). Does it work for BRICS                         doi.org/10.1016/j.gsf.2023.101564.
      countries? Resour. Policy 87 (2023) 104332 https://doi.org/10.1016/j.                       [100] M. Ahmad, P. Jiang, A. Majeed, M. Umar, Z. Khan, S. Muhammad, The dynamic
      resourpol.2023.104332.                                                                            impact of natural resources, technological innovations and economic growth on
 [87] Q. Wang, F. Zhang, R. Li, Free trade and carbon emissions revisited: the                          ecological footprint: an advanced panel data estimation, Resour. Policy 69 (2020)
      asymmetric impacts of trade diversification and trade openness, Sustain. Dev. n/a                 101817, https://doi.org/10.1016/j.resourpol.2020.101817.
      (n/a) (Aug. 2023), https://doi.org/10.1002/sd.2703.                                         [101] U. Habiba, C. Xinbang, S. Ali, Investigating the impact of financial development
 [88] M.C. Udeagha, M.C. Breitenbach, On the asymmetric effects of trade openness on                    on carbon emissions: does the use of renewable energy and green technology
      CO2 emissions in SADC with a nonlinear ARDL approach, Discov. Sustain. 4 (1)                      really contribute to achieving low-carbon economies? Gondwana Res. 121 (2023)
      (2023) 2, https://doi.org/10.1007/s43621-022-00117-3.                                             472–485, https://doi.org/10.1016/j.gr.2023.05.013.
 [89] Z. Mighri, M.I. AlSaggaf, Asymmetric impacts of renewable energy consumption                [102] R. Agrawal, S. Agrawal, A. Samadhiya, A. Kumar, S. Luthra, V. Jain, Adoption of
      and economic complexity on economic growth in Saudi Arabia: evidence from the                     green finance and green innovation for achieving circularity: an exploratory
      NARDL model, Environ. Sci. Pollut. Res. 30 (3) (Jan. 2023) 7446–7473, https://                    review and future directions, Geosci. Front. (Jul. 2023) 101669, https://doi.org/
      doi.org/10.1007/s11356-022-22718-1.                                                               10.1016/j.gsf.2023.101669.
 [90] K. Baz, et al., Asymmetric impact of energy consumption and economic growth on              [103] P. Behera, A. Haldar, N. Sethi, Achieving carbon neutrality target in the emerging
      ecological footprint: using asymmetric and nonlinear approach, Sci. Total                         economies: role of renewable energy and green technology, Gondwana Res. 121
      Environ. 718 (May 2020) 137364, https://doi.org/10.1016/j.                                        (Sep. 2023) 16–32, https://doi.org/10.1016/j.gr.2023.03.028.
      scitotenv.2020.137364.                                                                      [104] A. Razzaq, A. Sharif, S. Afshan, C.J. Li, Do climate technologies and recycling
 [91] K. Sakhraoui, A.K. Awopone, C. von Hirschhausen, N. Kebir, R. Agadi, Toward a                     asymmetrically mitigate consumption-based carbon emissions in the United
      systemic approach to energy transformation in Algeria, Euro-Mediterranean J.                      States? New insights from Quantile ARDL, Technol. Forecast. Soc. Change 186
      Environ. Integr. 8 (2) (2023) 365–379, https://doi.org/10.1007/s41207-023-                        (PA) (Jan. 2023) 122138, https://doi.org/10.1016/j.techfore.2022.122138.
      00367-1.                                                                                    [105] B. Bergougui, S. Mehibel, R.H. Boudjana, Asymmetric nexus between green
 [92] S. Ahlem, A. Zina, in: M. El Amine Abdelli, M. Shahbaz (Eds.), Analysis of the                    technologies, economic policy uncertainty, and environmental sustainability:
      Indicators of Environmental Performance in Algeria BT - Digital Economy, Energy                   Evidence from Algeria, J. Environ. Manag. 360 (2024) 121172, https://doi.org/
      and Sustainability: Opportunities and Challenges, Springer International                          10.1016/j.jenvman.2024.121172.
      Publishing, Cham, 2023, pp. 65–93, https://doi.org/10.1007/978-3-031-22382-                 [106] B. Bergougui, Investigating the relationships among green technologies, financial
      2_5.                                                                                              development and ecological footprint levels in Algeria: Evidence from a novel
 [93] N. Meftah, Z. labidine Mahri, in: Y. Chiba, A. Tlemçani, A. Smaili (Eds.), Algerian               Fourier ARDL approach, Sustain. Cities Soc. 112 (2024) 105621, https://doi.org/
      Energy Building Policy in the Context of Sustainable Development by 2030 BT -                     10.1016/j.scs.2024.105621.




                                                                                             15
