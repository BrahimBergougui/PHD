                                                                   Journal of Cleaner Production 483 (2024) 144215


                                                                       Contents lists available at ScienceDirect


                                                              Journal of Cleaner Production
                                                            journal homepage: www.elsevier.com/locate/jclepro




How do institutional quality and income asymmetrically affect carbon
emissions inequality? A quantile-on-quantile assessment for six major
global emitters
Brahim Bergougui a,b,* , Reda Hamza Boudjana c , Samer Mehibel c ,
Manuel A. Zambrano-Monserrate d
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
b
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
c
  Centre de Recherche en Economie Appliquée pour le Développement (CREAD), Alger, Algeria
d
  Universidad Espíritu Santo, Samborondón, Ecuador




A R T I C L E I N F O                                        A B S T R A C T

Handling Editor: Yutao Wang                                  Carbon emissions inequality (CE-I) represents a significant obstacle to achieving sustainable development and
                                                             social equity, highlighting the unequal distribution of environmental burdens and benefits among nations. To
Keywords:                                                    address this issue effectively, it is important to consider how institutional factors and economic conditions
Institutional quality                                        contribute to these disparities. This paper investigates the asymmetric impact of institutional quality (IQ) and
Income
                                                             income on CE-I, employing a Quantile-on-Quantile Regression (QQR) approach applied to six major global
Carbon emissions inequality
                                                             emitters—China, the United States, Germany, India, Russia, and Japan—from 1995 to 2019. The QQR method
QQR
                                                             enables a detailed examination of how these relationships vary across different quantiles of the data, providing
                                                             insights beyond those of traditional regression models. The findings reveal a non-linear relationship in which
                                                             improvements in IQ generally decrease CE-I, particularly in contexts of weak governance; however, diminishing
                                                             returns are observed at higher IQ levels. Income exhibits an inverted U-shaped effect on CE-I, where economic
                                                             growth initially increases emissions inequality but moderates it at higher income levels. Robustness checks
                                                             employing quantile Granger causality tests, quantile regression, and Kernel-based regularized least squares
                                                             demonstrate that both IQ and income levels play significant roles in shaping CE-I patterns. Based on these
                                                             findings, specific policy actions are recommended: in contexts of weak governance, policies should prioritize
                                                             strengthening IQ to reduce CE-I, while in high-income countries, efforts should focus on promoting equitable
                                                             income distribution to manage the growth-inequality relationship. Targeted interventions are essential to
                                                             ensuring both environmental sustainability and social justice in reducing CE-I.



List of acronyms                                                                                     (continued )
                                                                                                      Acronym                          Meaning
    Acronym                                      Meaning
                                                                                                      QR                               Quantile Regression
    AI                                           Artificial Intelligence                              QQR                              Quantile-on-Quantile Regression
    CE-I                                         Carbon Emissions Inequalities                        UN                               United Nations
    CO₂                                          Carbon Dioxide Emissions                             WDI                              World Development Indicators
    GDP                                          Gross Domestic Product                               WGI                              Worldwide Governance Indicators
    IQ                                           Institutional Quality                                WID                              World Inequality Database
    JB                                           Jarque-Bera
    KRLS                                         Kernel-Based Regularized Least Squares
    OLS                                          Ordinary Least Squares
                                                               (continued on next column)



  * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands.
    E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com (B. Bergougui), boudjana_reda@hotmail.fr (R.H. Boudjana), samer.mehibel@gmail.com
(S. Mehibel), manuelzambranom@uees.edu.ec (M.A. Zambrano-Monserrate).

https://doi.org/10.1016/j.jclepro.2024.144215
Received 23 August 2024; Received in revised form 31 October 2024; Accepted 11 November 2024
Available online 15 November 2024
0959-6526/© 2024 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                                    Journal of Cleaner Production 483 (2024) 144215


1. Introduction                                                                      about 9.7 tCO2. The average footprint of a person in Australia and a
                                                                                     member of Mexico’s top 10% were also similar (Arora et al., 2023).
    The current reality of climate change has led to numerous negative                   Interest in examining the relationship between IQ and environmental
impacts on human societies, particularly through natural disasters,                  quality has grown in recent decades (Azam et al., 2021). Ostrom (1998)
emphasizing the urgent need for mitigation (Becker et al., 2023).                    argued that IQ reflects the structure and effectiveness of governments
Reducing carbon emissions is at the core of this challenge. Additionally,            and is influenced by policies within an environmental regulatory
carbon emissions inequality (CE-I) is crucial for achieving carbon                   framework. Lovei and Weiss (1998) demonstrated that institutional and
neutrality, addressing not only environmental outcomes but also equity               administrative settings facilitate and support environmental policies at
(Chancel, 2022; Dong et al., 2023; Wang et al., 2022a,b). CE-I refers to             all stages—formulation, implementation, and monitoring. Iacobuță and
differences in emissions across socioeconomic groups, highlighting the               Gagea (2010) suggested that weak institutional functioning, rather than
uneven distribution of wealth and responsibilities in mitigating emis-               a lack of resources, is the main obstacle to achieving sustainable
sions (Cheng et al., 2021; Wu and Chen, 2023; Zhao et al., 2023a,b,c).               development. Effective institutions can implement policies that reduce
Connolly et al. (2022) note that higher-income individuals tend to have              emissions and promote environmental protection (Ali et al., 2019;
larger carbon footprints due to increased consumption of                             Haldar and Sethi, 2021). Conversely, poor IQ, often marked by cor-
energy-intensive activities.                                                         ruption and legal breakdowns, tends to worsen environmental degra-
    The impacts of CE-I are harmful, as they place the burden of climate             dation (Abid, 2016; Teng et al., 2021). Panayotou (1997) suggested that
change on those who have contributed the least. A small percentage of                a country’s ability to address environmental degradation depends
the population is responsible for a large share of emissions (Han et al.,            largely on the quality of its institutions and policies, regardless of its
2020; Zhou et al., 2022). Vulnerable communities suffer most from                    economic development level. High-income countries can anticipate
climate impacts despite minimal contributions, worsening existing in-                environmental improvements if IQ is strong, and effective policies are in
equalities (Chen et al., 2019; Wang et al., 2022a,b). Addressing CE-I is             place.
essential for a fair distribution of the costs and benefits of climate action,           While much research has explored the impact of IQ on emissions
fostering a sustainable society (Zhao et al., 2023a,b,c). This involves              reduction, the link between institutional quality, income, and CE-I re-
reducing inequalities by improving living standards for lower-income                 mains underexamined. This study seeks to fill that gap by addressing two
groups while curbing excessive consumption by the wealthy. In prac-                  key questions: Can institutional quality help reduce CE-I? Does income
tice, it means reducing emissions from affluent individuals while                    exacerbate these disparities? Furthermore, what are the mechanisms
ensuring fair access to clean technologies for less affluent populations.            that govern the interaction between institutional quality, income, and
    Recent statistics illustrate disparities in global carbon emissions. In          CE-I?
2019, according to the United Nations Development Program (UNDP),                        To answer these questions, the study examines data from the six
the top 10% of polluters, about 771 million people, were responsible for             largest global emitters—the United States, China, Japan, Germany,
around 48% of all global emissions, averaging 31 tons of CO2 per person              India, and Russia—over the period from 2000 to 2019, providing a
per year. Meanwhile, the bottom 50%, approximately 3.8 billion people,               deeper understanding of the dynamics involved. This is the first
contributed just 12% of emissions, averaging 1.6 tons per person (WID,               comprehensive study to establish causal links between IQ, income, and
2023). Individuals in high-income countries emit over thirty times more              CE-I. While previous studies have examined other contributing factors,
carbon per capita than those in low-income nations. High-income                      the crucial roles of IQ and income have been largely overlooked.
countries, representing 15.4% of the global population, contribute                       The study also introduces the Quantile-on-Quantile Regression
34% of global emissions, whereas low-income countries, with 8.8% of                  (QQR) approach to explore relationships between IQ, income, and CE-I.
the population, are responsible for only 0.6% (WID, 2023).                           QQR allows examination of how these relationships change across
    Data from the WID (2023) show that top earners in different coun-                different segments of the data distribution, providing a more nuanced
tries produce varying levels of CO2 emissions due to diverse consump-                analysis than traditional models.
tion habits. Within the top 1% income group, a person in the United                      Lastly, the study focuses on six key global emitters: the United States,
States had an annual CO2 footprint of 228.6 tCO2, while those in                     China, Japan, Germany, India, and Russia, which together account for
Australia and Saudi Arabia had footprints of 182.1 tCO2 and 197.9                    two-thirds of the world’s income. Their diverse resources, energy con-
tCO2, respectively (Arora et al., 2023). In 2019, the richest 1% in                  sumption, and development strategies provide key insights into the
Canada, Russia, and China also had significant CO2 footprints,                       drivers of CE-I.
exceeding 100 tCO2 annually. In contrast, the top 1% in South Africa,                    The paper is structured into five sections. Section two provides a
the EU, Japan, Mexico, the UK, and Turkey emitted between 60 and 85                  review of the existing literature on IQ and income in relation to CE-I.
tCO2 per year.                                                                       Section three outlines the dataset and methodology. Section four pre-
    The richest 1% in developing countries had significantly lower                   sents the findings and discussion. Lastly, the final section offers a sum-
emissions—around one-sixth of their counterparts in the United States.               mary of the key conclusions and policy implications.
For instance, the top 1% in Brazil, Argentina, India, and the ASEAN
region had emissions of 38.8 tCO2, 34.6 tCO2, 31.7 tCO2, and 37.6                    2. Literature review
tCO2, respectively (WID, 2023). These countries also had the lowest
GDP per capita among those analyzed, highlighting regional and eco-                  2.1. Inequalities in carbon emissions measurement
nomic inequities in emissions among wealthy groups.
    When comparing average per capita CO2 emissions with those of the                    The measurement of global carbon emissions inequality (CE-I) can be
top 10% income earners in developing and industrialized nations,                     approached using two primary methodologies: bottom-up and top-down
additional insights emerge. In 2019, an individual in the top 10% in-                techniques. Bottom-up approaches derive macro-level estimates from
come bracket in India had a carbon footprint of 7.4 tCO2, lower than                 micro-level data, such as household consumption surveys. Researchers
that of an average person in industrialized countries like the United                like Bruckner et al. (2022), Hubacek et al. (2017), and Oswald et al.
States, Canada, Australia, Japan, and Saudi Arabia. In developing                    (2020) have used this strategy, incorporating extensive datasets from
countries like Argentina, Brazil, and other ASEAN nations, the emissions             sources like the World Bank Global Consumption Database. These data
of the richest 10% were comparable to or lower than those of average                 are then integrated into Environmental Multi-Regional Input-Output
earners in high-income countries. Specifically, the top 10% in Argentina             models (EMRIOs) to estimate energy consumption or emissions per
emitted 38%–65% less CO2 than average earners in countries like the                  consumer group. While this approach provides accurate quantification
United States, Saudi Arabia, and Australia, with an average footprint of             of individual-level CE-I, its data-intensive nature limits its ability to

                                                                                 2
B. Bergougui et al.                                                                                                   Journal of Cleaner Production 483 (2024) 144215


analyze the evolution of global emissions over time. Additionally, it may           polluting industries, stimulate the development of energy-saving prod-
underestimate consumption among the wealthiest due to misreporting                  ucts, and facilitate the adoption of pollution-reducing technologies.
and sampling biases.                                                                Corruption exerts both direct and indirect impacts on the environment.
    Top-down approaches model CE-I using elasticity parameters along                Direct effects result from violations of environmental laws and regula-
with income or consumption inequality distributions. Studies by Chak-               tions, while indirect effects stem from corruption’s influence on per
ravarty et al. (2009), Chancel and Piketty (2015), Kartha et al. (2020),            capita income levels, thereby affecting environmental conditions
and Semieniuk and Yakovenko (2020) have adopted this method to                      (Welsch, 2004). Corruption also impacts the sustainability of the three
generate estimates based on patterns from micro-level data. However,                bottom lines—social, economic, and environmental—making it chal-
the accuracy of these estimates at the country level is often limited due           lenging to adopt eco-friendly practices and cleaner technologies
to the reliance on a single elasticity parameter for all nations. Both ap-          (Silvestre et al., 2018). Nevertheless, political inefficiencies and
proaches also face challenges in accounting for emissions related to                bureaucratic hurdles are identified as distorting factors that undermine
investments.                                                                        environmental governance (Welsch, 2004).
    Recent research developments in CE-I, such as Chen et al. (2024),                   The empirical literature suggests that the relationship between IQ
focus on CO2 emissions inequality within the top 10% income bracket,                and carbon emissions remains contentious. Phuc Canh et al. 2019, Sal-
revealing that higher-income individuals emit significantly more CO2                man et al. (2019), and Shahbaz et al. (2019) highlight the role of
and underscoring the need to address the behaviors of affluent house-               effective environmental regulations in promoting sustainability. Salman
holds. Studies on international trade highlight that developing countries           et al. (2019) specifically examined the impact of IQ on CO2 emissions in
often bear a disproportionate share of environmental costs (Wang et al.,            Thailand, South Korea, and Indonesia, concluding that high-quality IQ
2022a,b), particularly in sectors like information and communication                contributes to reducing emissions. Similarly, Khan & Rana (2021), in
technology (ICT) (Zhou et al., 2022). Regional disparities also exist, with         their study of 41 Asian economies, found that IQ supports CO2 emission
greater CE-I in wealthier eastern regions (Mi et al., 2020).                        reduction. Stef et al. (2023) also provide relevant insights for a larger
    Demographic factors affect CE-I. Zheng et al. (2022) and Liu and                sample. Furthermore, studies by Ali et al. (2019), Wawrzyniak and
Zhang (2022) noted increasing emissions from elderly populations in                 Doryń (2020) and Haldar and Sethi (2021) have demonstrated that
China and the impact of urbanization on emission patterns.                          improved institutional efficiency leads to lower greenhouse gas emis-
Country-specific studies provide further insights: in the United States,            sions in emerging and developing nations. However, other research in-
Starr et al. (2023) found that political factors exacerbate CE-I, with              dicates that a weak institutional framework fosters economic
racial disparities affecting climate interventions. In China, Liao et al.           inefficiencies and degrades environmental quality. Recent studies un-
(2023) reported improvements in CE-I over time, with regional varia-                derscore the positive impact of IQ on CO2 emissions in developing na-
tions in household carbon footprints and converging urban-rural emis-               tions (Chhabra et al., 2023). Azam et al. (2021) highlighted significant
sion disparities. A cross-country analysis by Zheng et al. (2023)                   increases in carbon emissions attributable to IQ, a finding echoed by
identified contrasting emission trends and corporate innovation be-                 Teng et al. (2021). Abid (2016), in examining specific components of IQ,
tween developed and developing nations.                                             found that while legal and regulatory quality tends to increase carbon
                                                                                    emissions, corruption control, political stability, efficiency, democratic
                                                                                    governance, and governance effectiveness contribute to reducing carbon
2.2. Institutional quality and carbon emissions                                     emissions. Akhbari and Nejati (2019) later suggested that corruption’s
                                                                                    impact on environmental quality may be minimal in both affluent and
    The effectiveness of institutions in overseeing and implementing                developing nations. Therefore, establishing a robust institutional
policies determines both their quality and efficacy. The level of external          framework appears crucial for addressing the escalating greenhouse gas
influence and corruption within these IQ significantly impacts their                emissions.
operational efficiency. Various criteria are utilized to assess IQ, and legal           Another approach to IQ has been explored in various studies (Qader
mechanisms are employed to address and prevent infractions. Economic                and Cek, 2024; Durrah et al., 2024; Zhang et al., 2024), where artificial
policies are formulated, strengthened, and implemented by these IQ,                 intelligence (AI) is examined across different sectors and domains. These
wielding considerable influence over national growth (Udemba, 2021).                studies highlight the added value AI brings to institutions that have
Additionally, Abid et al. (2015) found that developing nations often                implemented it. In addition, several empirical studies (Wang et al.,
maintain less stringent environmental regulations, underscoring how                 2023a,b,c, 2024a,b,c; Wang et al., 2024a,b,c; Zhao et al., 2024) further
political considerations can hinder high environmental standards                    support these findings. Wang et al. 2024a,b,c specifically differentiate
(Ibrahim and Law, 2016). Institutions tainted by corruption or under                between the direct and indirect effects of AI on carbon emissions.
political control are prone to poor policy execution. Corrupt practices             Regarding the direct impact (Gureev et al., 2020; Heidarpanah et al.,
facilitated by weak and dishonest IQ include bribery, regulatory evasion,           2023; Khan et al., 2023; Wang et al., 2023a,b,c), Verendel (2023)
tax avoidance, procedural shortcuts, and penalty circumvention. The                 identifies two primary ways AI affects carbon emissions. First, AI en-
emphasis on economic growth, sometimes at the expense of environ-                   hances manufacturing processes through its advanced perception and
mental degradation, underscores the pivotal role of IQ in shaping                   learning capabilities, as observed in both corporate and political sectors.
developmental outcomes (Udemba, 2021). In sum, legal regulations and                Second, from a supply and demand perspective, AI utilizes large data
institutional procedures play a crucial role in shaping environmental               platforms to better understand customer needs and market trends,
outcomes. The relationship between these entities is underscored by the             enabling more efficient management of business operations.
"Porter hypothesis," which posits that stringent regulations spur the                   As for the indirect impact (Fankhauser and Jotzo, 2017; Abdulov,
development of pollution-reducing technologies, thereby fostering                   2020; Qi et al., 2023; Wang et al., 2023a,b,c), three channels emerge.
competitive advantages. Ultimately, this approach aims to mitigate                  First, AI optimizes supply chains by reducing transportation costs and
negative environmental externalities and enhance overall growth effi-               energy consumption (Qi et al., 2023; Wang et al., 2023a,b,c). Second, AI
ciency (Zhang et al., 2018). According to Zhang et al. (2018), regula-              drives economic growth by fostering innovation, creating new busi-
tions have four primary effects on the environment: they reduce the                 nesses, and enhancing competitiveness, all of which help shift reliance
consumption of non-renewable resources, raise entry barriers for highly




                                                                                3
B. Bergougui et al.                                                                                                 Journal of Cleaner Production 483 (2024) 144215


away from carbon-intensive industries, facilitating a successful transi-          et al., 2023) has explored the relationship between CO2 emissions and
tion (Yang et al., 2021a). Third, trade liberalization, enabled by AI             income, particularly income inequality. These studies have examined
technology, promotes international cooperation and information                    the mechanisms through which income disparities influence CO2
sharing. This can lead to more sustainable practices, ultimately                  emissions, proposed plausible explanations for this relationship, and
impacting environmental challenges like carbon emissions (Wang et al.,            established a theoretical and methodological foundation for future
2024a,b,c).                                                                       research on the subject (Wang et al., 2024a,b,c). However, Wang et al.
    Whether assessing IQ through AI adoption or other methods, the                (2024a,b,c) note that the majority of this research overlooks the influ-
development of human capital remains crucial for effectiveness                    ence of other socio-economic factors, focusing solely on the direct link
(Appiah-Twum and Long, 2023). In their study on achieving environ-                between income inequality and CO2 emissions. Despite this gap, some
mental efficiency convergence across Asia Pacific countries, Appiah-T-            scholars, such as Liu et al. (2020), have addressed the issue by consid-
wum and Long (2023) utilized a metafrontier super epsilon-based model             ering the relationship between IQ and CO2 emissions in five major
(EBM) to demonstrate that environmental efficiency can be improved                economies: China, India, Japan, Russia, and the USA. They found that
through human capital, alongside other factors such as trade competi-             improvements in political stability, voice, and accountability reduce
tiveness, which showed mixed effects on environmental efficiency for              CO2 emissions in these countries. Liu et al. (2020) also implicitly sug-
the last. Furthermore, Ghimire et al. (2024) emphasized the role of               gested that IQ reduces CO2 emissions by fostering economic growth,
research and innovation in advancing the digital economy, particularly            and, consequently, affecting income levels.
in their study on the impact of the Digital Silk Road and innovation                  When narrowing the focus to IQ, particularly "corruption," a
heterogeneity in 29 countries, using a PSM-DID model. Ghimire et al.              consensus emerges among scholars (Tran, 2021; Dong et al., 2022; Zhao
(2024) concluded that the Digital Silk Road initiative (DSR) serves as a          et al., 2023a,b,c) on the dual—direct and indirect—impact of corruption
catalyst for increasing productivity. On their part, Luo et al. (2020)            on the environment. In this context, Wang et al. (2024a,b,c) argue that
utilized a panel quantile regression to study the convergence of CO2              the academic community has largely neglected the indirect mechanisms
emissions across China’s east, middle and west regions to provide pol-            through which corruption affects both income inequality and carbon
icymakers with enough evidence to establish a targeted environmental              reduction. To date, little research has addressed this issue in depth.
policy. By comparing the heterogeneous effects of endogenous and                  Among the limited studies, Welsch (2004) found that corruption directly
foreign innovation on CO2 emissions convergence in China provinces,               increases environmental pollution and indirectly harms the environ-
Luo et al. (2020) found that the east of China achieved the highest rate of       ment by reducing per capita income. Welsch (2004)’s estimates sug-
convergence and both endogenous and foreign innovation exert a                    gested that the indirect effects of corruption on the environment are
negative impact on CO2 emissions in the country.                                  more significant at lower income levels. Following in Welsch’s footsteps,
                                                                                  Cole (2007) explored these mechanisms further, discovering that cor-
2.3. Income and carbon emissions                                                  ruption not only has direct environmental consequences but also indi-
                                                                                  rectly hampers environmental outcomes by lowering income. Similarly,
    Research on the relationship between income and CE-I has focused              Effah et al. (2017), studying developing countries, demonstrated how
primarily on household-level data. Hubacek et al. (2017), Wiedenhofer             corruption exacerbates economic inequality, echoing Welsch’s earlier
et al. (2017), Liu et al. (2019), and Huang et al. (2022) examined how            findings.
income distribution affects emissions, providing important insights.                  In their analysis of BRICS nations, Wang et al. (2018) showed that
Wiedenhofer et al. (2017) found that in China, 19% of emissions are               corruption significantly alters the relationship between income levels
generated by the top 5% of earners, while Liu et al. (2019) reported that         and CO2 emissions. This occurs either by reducing average income or
the wealthiest 40% are responsible for 58% of total emissions. Huang              increasing pollution at a given income level. Sehrawat and Singh (2021)
et al. (2022) highlighted that in Japan, variations in household carbon           extended this research by analyzing the impact of wealth inequality and
footprints drive CE-I, indicating a strong link between income inequality         corruption on energy efficiency and economic growth in BRICS coun-
and emissions. On a global scale, Hubacek et al. (2017) estimated that in         tries. Their panel data regression results indicated that economic
2010, the richest 10% accounted for 36% of global greenhouse gas                  inequality increases when corruption is lower and decreases with im-
emissions, compared to 15% from the bottom 50%.                                   provements in energy efficiency.
    Sommer and Kratena (2017) observed a decoupling effect in 27 EU
countries, where the top income group’s share of income (45%) was                 2.5. Research gaps
higher than its share of the carbon footprint (37%), while the bottom
income group’s share of income (6%) was lower than its carbon foot-                   Although the existing literature has extensively explored the impact
print share (8%). Seriño and Klasen (2015) identified an inverse                 of IQ and income on CE-I, this study aims to address several gaps and
U-shaped relationship between income and emissions, suggesting a                  limitations identified in earlier research. The following sections examine
turning point beyond current income levels. Wiedenhofer et al. (2017)             how this paper’s contribution enhances understanding of these issues,
noted that consumption differences result in uneven carbon footprints             providing more detailed insights compared to previous work. Based on a
between rich and poor households in China. Ivanova and Wood (2020)                review of the literature, the following research gaps have been
studied carbon disparity in 26 EU countries, linking household carbon             identified:
footprints to socially desired outcomes.                                              First, most existing research has focused on the relationship between
    Studies by Mi et al. (2020), Sun et al. (2021), and Feng et al. (2021)        income and overall CO2 emissions, without examining the specific
further explored the connection between household footprints and in-              mechanisms through which income affects CE-I. While some studies
come levels, showing how income disparities influence emissions and               have included income as a control variable (e.g., Bergougui et al., 2024;
affect climate mitigation efforts.                                                Zhao et al., 2024), there is a lack of comprehensive analysis of its direct
                                                                                  impact on CE-I.
2.4. Institutional quality, income and carbon emissions                               Second, the current literature primarily investigates the link between
                                                                                  IQ and carbon emissions, but not specifically CE-I. There is a significant
    Most of the available literature (Safar, 2022; Andersson, 2023; Zhang         gap in understanding the mechanisms through which IQ influences CE-I.




                                                                              4
B. Bergougui et al.                                                                                                                Journal of Cleaner Production 483 (2024) 144215


Table 1                                                                               between the quantiles of dependent and independent variables, quantile
Details of the variables.                                                             regression provides a deeper understanding of how the distributional
  Variable            Abr.     Position      Measurement              Source          characteristics of one variable affect the entire distribution of another
                                                                                      (Xiao, 2012). Furthermore, quantile regression methods surpass tradi-
  Carbon              CE I     Dependent     Average per capita
    emissions                  variable      emissions of the top
                                                                      WID             tional linear regression, which requires specific assumptions about the
    inequality                               10% wealthier            (2023)          distribution of errors. In contrast, quantile regression does not rely on
  Institutional       IQ       Explanatory   Arithmetic mean of the   WGI             such assumptions, offering greater flexibility. Additionally, when
    quality index              variable      worldwide governance     (2024)          dealing with patterned datasets, skewed distributions, or outliers,
                                             indicators.
  Income              income   Explanatory   Per capita gross         WDI
                                                                                      quantile regression estimates are more robust than those obtained from
                               variable      domestic product         (2024)          linear regression (Benoit & Van den Poel, 2009). This robustness is
                                             (constant 2015 US                        particularly relevant in our study, where capturing heterogeneous ef-
                                             Dollar)                                  fects across the distribution of carbon emissions inequality (CE-I) is
                                                                                      crucial.
                                                                                          Moreover, Sim and Zhou (2015) suggested that the interaction be-
Studies have addressed related issues, such as the moderating role of IQ
                                                                                      tween two variables may vary at different stages of their distributions.
on carbon emissions (Khan et al., 2022) and the combined impact of
                                                                                      To address this, they introduced a nonparametric method called
income inequality and IQ on CO2 emissions in developing countries
                                                                                      Quantile-on-Quantile Regression (QQR), which examines the relation-
(Yang et al., 2022), but have not directly examined the IQ-CEI
                                                                                      ship between the quantiles of a dependent variable and an independent
relationship.
                                                                                      variable. However, the issue of endogeneity becomes more pronounced
    Third, traditional regression methods, such as simple QR and OLS,
                                                                                      when using a bivariate model due to omitted variable bias. To address
have been predominantly used in previous research. These methods may
                                                                                      this problem, Alola et al. (2023) proposed a nonparametric modeling
not fully capture the complexity of the relationships between variables
                                                                                      technique employing multivariate quantile-on-quantile regression. This
across different parts of the data distribution. The use of more advanced
                                                                                      method is part of the quantile-based approaches advocated by scholars
techniques, such as QQR, which considers the entire distribution and
                                                                                      such as Kartal (2022), Ulussever et al. (2023), Kartal (2023), and Kartal
addresses issues related to asymmetric data, has been limited in this field
                                                                                      (2024), and has been shown to provide reliable and meaningful results.
of study. To the best of the available knowledge, no previous study has
                                                                                          Examining the impact of IQ and income on CE-I in the six largest
utilized QQR to analyze the combined impact of IQ and income on CE-I.
                                                                                      carbon emitting countries. First consider the following nonparametric
This represents a notable gap in the literature, as QQR can provide more
                                                                                      quantile regression equation for the θ-quantile of the carbon inequality
detailed insights into these relationships across different quantiles of the
                                                                                      (CE It ) as a function of institutional quality (IQt ) and income (incomet )
variables involved.
                                                                                      as:
3. Methods                                                                            CE It = β1 θ (IQt ) + β2 θ (income) + εθt                                               (1)

3.1. Data source                                                                      where Cit explains CE-I index of a country in a given period t, IQt rep-
                                                                                      resents the institutional quality index in the given period t, θ is the θ th
   The current research employs quarterly1 data spanning from the first               quantile on the distribution of CE-I index; the residual term εθt θ has a
quarter of 1995 to the third quarter of 2019, focusing on the top six CO2-            zero θ-quantile; β1 θ describes the impact of IQ on CE-I; and β2 θ repre-
emitting countries: the USA, China, Japan, Germany, India, and Russia.                sents the impact of income on the CE-I. Since no information is available
The research focuses on three primary variables (see Table 1): the CE-I,              on the relationship between CE-I and IQ, β1 θ and β2 θ are assumed to be
IQ index, and the logarithm of GDP per capita. The data for the CE-I is               unknown functions.
sourced from the World Inequality Database (WID, 2023), the IQ index is                   To examine the connection between the θ-quantile of the CE-I index
obtained from the Worldwide Governance Indicators (WGI, 2024), and                    on the one hand and the τ1 -quantile of institutional quality (IQτ1 ) and
the income data is derived from the World Development Indicators
                                                                                      (incomeτ2 ) on the other. The unknown functions βθ (.) and αθ (.) by
(WDI, 2024).
                                                                                      employing a first-order Taylor expansion in the vicinity of (IQτ1 ) and
                                                                                      (incomeτ2 ), respectively, as follow:
3.2. Quantile-based models                                                                                            ʹ
                                                                                      β1 θ (IQt ) ≈ β1 θ (IQτ1 ) + β1 θ (IQτ1 )(IQt − IQτ1 )                                  (2)
    In many statistical applications, economic relationships are often too                                                             ʹ
complex to be adequately captured by examining only a few moments.                    β2 θ (incomet ) ≈ β2 θ (incomeτ2 ) + β2 θ (incomeτ2 )(incomet − incomeτ2 )              (3)
Important aspects of the relationships between random variables may                                                                                                       ʹ
                                                                                      A distinctive feature of Eq. (3) is that its parameters, β1 θ (IQτ1 ) , β1 θ (IQτ1 )
remain hidden if analyzed solely through simple conditional mean
                                                                                                                 θʹ
analysis (Bergougui et al., 2024).                                                    , β2 (incomeτ2 ) and β2 (incomeτ2 ) are doubly indexed by both indexes: θ,
                                                                                             θ

    Quantile regression-based methods offer a complementary approach                  τ1 and θ, τ2 . This indexing arises because IQτ1 , the τ1 -quantile of IQ and
for investigating these relationships. By exploring the interdependencies             incomeτ2 the τ2 -quantile of income depend solely on τ1 and τ2 , respec-
                                                                                                                                   ʹ
                                                                                      tively. Since β1 θ (IQτ1 ) and β1 θ (IQτ1 ), as well as β2 θ (incomeτ2 ) and
                                                                                        θʹ
                                                                                      β2 (incomeτ2 ) are functions of θ and IQτ1 , and θ and incomeτ2 , respec-
  1
     This study uses quarterly data, converted from annual data via the               tively, given that IQτ1 and incomeτ2 are function of τ1 and τ2 ,respec-
quadratic match-sum approach, for several reasons. First, converting annual                                                                 ʹ
                                                                                      tively. This implies that β1 θ (IQτ1 ) and β1 θ (IQτ1 ) are function of θ and τ1 ,
data to quarterly increased observations, allowing for more robust analysis.                                              θʹ
Second, the quadratic match-sum method adjusts for cyclical variations,               while β2 θ (incomeτ2 ) and β2 (incomeτ2 ) are function of θ and τ2 .from this
                                                                                                                               ʹ
providing a more accurate trend representation, crucial for economic variables.       perspective β1 θ (IQτ1 ) and β1 θ (IQτ1 ) can be redefined as β0 (θ, τ1 ) and
Third, it mitigates seasonality issues, offering a clearer view of underlying                                                                             ʹ
                                                                                      β11 (θ, τ1 ) respectively, and β2 θ (incomeτ2 ) and β2 θ (incomeτ2 ) can be
patterns. Additionally, as noted by Bergougui (2024c), it reduces data varia-
                                                                                      redefined as β0 (θ, τ2 ) and β21 (θ, τ2 ) ,respectively.
tions and isolates non-seasonal components, focusing on long-term trends. The
                                                                                          From this perspective, Eq. (2) and Eq. (3) are rewrite as:
methodology follows established peer-reviewed studies (Bergougui, 2024a,
2024b; Bergougui et al., 2024; Bergougui and Aldawsari, 2024) to ensure               βθ (IQt ) ≈ β0 (θ, τ1 ) + β11 (θ, τ1 )(IQt − IQτ1 )                                     (4)
reliability.

                                                                                  5
B. Bergougui et al.                                                                                                                                                                  Journal of Cleaner Production 483 (2024) 144215


                                                                                                                                             more conveniently, the distance of the empirical distribution function
βθ (incomet ) ≈ β0 (θ, τ2 ) + β21 (θ, τ2 )(incomet − incomeτ2 )                                                               (5)
                                                                                                                                             from τ1 , where τ1 is the value of the distribution function that corre-
and substitute Eq. (4) and Eq. (4) into Eq. (3) to obtain                                                                                    sponds with IQ
                                                                                                                                                          ̂ t .
                                                                                                                                                             τ1




CE It = β0 (θ, τ1 , τ2 ) + β11 (θ, τ1 )(IQt − IQτ1 ) + β21 (θ, τ2 )(incomet − incomeτ2 ) +εθt
        ⏟̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅⏞⏞̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅⏟
                                                                                                                                                                                                                                 (6)
                                                                     (*)




                                                                                                                                                               n
                                                                                                                                                            1 ∑
   The part (*) of Eq. (6) captures the overall dependance structure                                                                         Fn ( IQ
                                                                                                                                                  ̂t ) =          I( ̂
                                                                                                                                                                     IQk < IQ
                                                                                                                                                                           ̂t )
                                                                                                                                                            n k=1
between CE I and both IQ and income by capturing the dependence
between their respective distributions.                                                                                                         Similarly, a Gaussian kernel K(.) is employed to weight the obser-
   To estimate Eq. (6), IQt is substituted with its estimated counterpart                                                                    vations in the vicinity of income
                                                                                                                                                                           ̂ t τ2 , again using bandwidth h. These
IQ
 ̂t and incomet with its estimated counterpart income    ̂ t . Similarly,
                                                                                                                                             weights are inversely related to the distance between income
                                                                                                                                                                                                       ̂ t and
replace IQt τ1 with its estimated counterpart IQ
                                               ̂ t
                                                   τ1
                                                      and incomet τ2 with its                                                                incomet or more conveniently, the distance of the empirical distribu-
                                                                                                                                                ̂   τ2

estimated counterpart incomê t τ2 .                                                                                                         tion function from τ2 , where τ2 is the value of the distribution function




                     n                                                                                                                                 (                   )
                     ∑                                                                                                                                     Fn ( IQ
                                                                                                                                                                ̂t ) − τ
    MINβ0 ,β11              ρθ [CEI t − β0 − β11 (θ, τ1 )(IQt − IQτ1 ) − β21 (θ, τ2 )(incomet − incomeτ2 )]K
                      i=1
                                                                                                                                                                  h
                                                                                           (                                                                                                                                     (7)
                 n
                 ∑                                                                                 ̂ t ) − τ)
                                                                                             F ( income
MINβ0 ,β21     ρθ [CEI t − β0 − β11 (θ, τ1 )(IQt − IQ ) − β21 (θ, τ2 )(incomet − income )]K n
                                                                                  τ1                                                        τ2

           i=1
                                                                                                     h




                                                                                                                                             that corresponds with income
                                                                                                                                                                      ̂ t τ2 .
                                                                                                                                                                     n
    to obtain the estimates β0 (θ, τ1 , τ2 ), β11 (θ, τ1 ), β21 (θ, τ2 ) where the                                                                  ̂ t)=1
                                                                                                                                                                     ∑
                                                                                                                                             Fn ( income                   I( income
                                                                                                                                                                                ̂ k < income
                                                                                                                                                                                        ̂ t)                                     (8)
function ρθ is the tilted absolute value function that gives the θ-condi-                                                                                n           k=1
tional quantile of CE It as the solution. The focus is on the marginal
                                                                                                                                                 The selection of bandwidth in nonparametric estimation is critical as
effect exerted locally by both the τ1 -quantiles of IQ and the τ2 - quantiles
                                                                                                                                             it balances variance and bias. The rule-of-thumb method is commonly
of income. First, Gaussian kernel K(.) is employed to weight the obser-
                                                                                                                                             used for determining optimal bandwidth, assuming a Gaussian under-
vations in the vicinity of IQ
                            ̂ t , with the bandwidth denoted by h. These
                               τ1
                                                                                                                                             lying density. In this study, a plugin bandwidth of h = 0.05 is used, as
                                                       ̂t and IQ
weights are inversely related to the distance between IQ       ̂ t
                                                                   τ1
                                                                      or                                                                     recommended by Sim and Zhou (2015). A smaller bandwidth reduces


Table 2
Descriptive statistics.
   Country                        Variable                      Mean                      Median                       Min                       Max                 SD            Skewness           Kurtosis            JB-Prob

   China                          CE-I                          19.81                     17.63                        8.03                      34.99               9.17          0.10               1.32                0.00
                                  IQ                            − 0.77                    − 0.79                       − 0.99                    − 0.46              0.13          0.61               2.68                0.03
                                  Income                        2.07                      2.04                         1.27                      2.59                0.22          − 0.26             3.82                0.13

   USA                            CE-I                          71.32                     72.46                        42.19                     91.56               9.08          − 0.45             3.33                0.13
                                  IQ                            1.95                      1.91                         1.19                      2.43                0.21          − 0.45             3.94                0.02
                                  Income                        2.71                      2.71                         1.64                      3.33                0.20          − 1.29             11.46               0.00

   Germany                        CE-I                          36.57                     36.97                        23.3                      46.89               3.41          − 0.53             5.47                0.00
                                  IQ                            2.23                      2.26                         1.29                      2.69                0.18          − 1.52             9.63                0.00
                                  Income                        2.63                      2.62                         1.58                      3.23                0.19          − 1.37             11.51               0.00

   India                          CE-I                          5.54                      4.89                         2.97                      9.27                1.99          0.34               − 0.28              0.00
                                  IQ                            − 0.35                    − 0.32                       − 0.54                    − 0.20              0.09          − 0.28             1.80                0.02
                                  Income                        1.74                      1.72                         1.04                      2.14                0.16          − 0.59             6.10                0.00

   Russia                         CE-I                          37.54                     36.88                        26.83                     52.26               5.49          0.11               2.54                0.58
                                  IQ                            − 1.09                    − 1.10                       − 1.37                    − 0.70              0.11          0.26               3.88                0.10
                                  Income                        2.22                      2.22                         1.38                      2.78                0.18          − 0.61             8.10                0.00

   Japan                          CE-I                          39.61                     39.98                        24.63                     51.49               3.73          − 0.52             6.31                0.00
                                  IQ                            1.18                      1.17                         0.69                      1.45                0.14          − 0.32             2.99                0.41
                                  Income                        10.4                      10.41                        6.27                      12.77               0.78          − 1.38             11.82               0.00

Notes: SD: Standard Deviation. JB-Prob: Jarque-Bera Probability.

                                                                                                                                       6
B. Bergougui et al.                                                                                                   Journal of Cleaner Production 483 (2024) 144215


bias but increases variance, while a larger bandwidth has the opposite            Fig. 1).
effect. The Gaussian kernel function assigns weights based on proximity,              To investigate the relationship between CE-I, IQ, and income for the
and the chosen bandwidth controls this trade-off. Achieving an optimal            top five CO2-emitting countries, a QQR approach was employed. Fig. 2
balance is essential for accurate estimates.                                      presents the slope coefficients β11 (θ, τ1 ), representing the influence of
                                                                                  the θ th quantile of CE-I on the τth quantile of IQ (and vice versa), while
4. Results and discussion                                                         Fig. 3 depicts the slope coefficients β21 (θ, τ2 ), reflecting the impact of the
                                                                                  θ th quantile of CE-I on the τth quantile of income (and vice versa) across
4.1. Empirical results                                                            these five countries (China, USA, Germany, India, and Russia). This al-
                                                                                  lows for the examination of how changes in one variable at a particular
4.1.1. Descriptive statistics                                                     point in its distribution affect another variable at a different point in its
    The descriptive statistics for CE-I, IQ, and income are presented in          distribution.
Table 2. Among the countries analyzed, the United States exhibits the
highest average CE-I value at 71.32, Japan, Russia, Germany, China, and              (a) IQ impact on CE-I
India follow with respective average values of 39.61, 37.54, 36.57,
19.81, and 5.54, positioning them second, third, fourth, fifth, and sixth.           The analysis identifies heterogeneous patterns in the impact of IQ on
Furthermore, it is observed that the United States records the highest            CE-I across the six countries.
maximum CE-I value and India the lowest, as well as the highest and
lowest minimum values within the sample studied.                                   • China shows a consistently positive marginal effect of IQ on CE-I
    Furthermore, All the countries exhibit positive skewness, except for             across all quantiles of the IQ distribution. This effect is most pro-
the USA, Germany and Japan. Additionally, the kurtosis values are                    nounced at the lower quantiles (0.05–0.15), decreases around the
below 3 for China, India, and Russia. However, the JB test and p-value               median quantiles, and continues to decline at higher quantile levels.
for this set of countries indicate that the null hypothesis of normal dis-           This suggests that improvements in IQ have a greater effect on
tribution is rejected, suggesting non-normality in the dataset for the               reducing CE-I when IQ is initially low.
studied countries, with the exception of the USA and Russia.                       • The United States displays a positive and relatively strong marginal
    For IQ, Germany has the highest average IQ at 2.23, while Russia has             influence of IQ at the lower and middle quantiles, which starts to
the lowest at − 1.09. The USA, Japan, India, and China have average                  decrease sharply at higher quantiles (0.70–0.95). This indicates
values of 1.95,1.18, − 0.35, and − 0.77, ranking them third, fourth, fifth           diminishing returns, where the impact of institutional improvements
and sixth respectively. Also, Table 2 reports that Germany recorded the              on CE-I becomes less significant as IQ reaches higher levels.
highest maximum value, whereas Russia recorded the lowest maximum                  • Germany demonstrates a strong and positive relationship between
value among the studied countries. The datasets for the USA, Germany,                IQ and CE-I at the lower quantiles (0.05–0.40), which gradually di-
Japan and India are negatively skewed, while they are positively skewed              minishes in magnitude across the distribution, reaching its lowest
for China and Russia. The kurtosis values for China and India are less               impact at the higher quantiles. This suggests that institutional im-
than 3, whereas the kurtosis values for the USA, Germany, Japan and                  provements have the most significant impact on reducing CE-I when
Russia are above 3.                                                                  IQ is relatively low.
    However, the JB test and p-value for this set of nations suggest that          • India presents a unique pattern, with the marginal impact of IQ on
the null hypothesis of normal distribution for the dataset is rejected for           CE-I initially negative at lower quantiles (0.05–0.30). However, this
all countries except for Russia and Japan.                                           impact gradually increases and becomes positive at the median and
    The descriptive statistics analysis of the income variable reveals that          higher quantiles. This indicates a complex relationship where initial
the USA has the highest mean value, while India has the lowest average               improvements in IQ may exacerbate CE-I, but further enhancements
value. The USA recorded the highest value at 3.23, while India recorded              contribute to reducing inequality.
the lowest at 1.04. The datasets for all the studied countries are nega-           • Russia exhibits a positive and robust impact of IQ on CE-I at the
tively skewed, and the kurtosis values for all the countries are above 3.            lower and middle quantiles. However, there is a notable decline in
                                                                                     this relationship from the 0.65th quantile to the 0.80th quantile,
4.1.2. Quantile-on-quantile results                                                  where the positive impact reverses to become negative, reaching its
    The assessment of the descriptive statistics revealed several key                minimum value at the highest quantile. This suggests a non-linear
characteristics of the data series, including non-normality and heavy                relationship in which very high levels of IQ may actually lead to
tails relationships. Due to these attributes, a quantile regression frame-           increased CE-I.
work was deemed the most suitable analytical approach, as it effectively           • Japan shows a pronounced negative effect of IQ at the lower
captures the asymmetric effects of the independent variables (IQ and                 quantiles, peaking at the 25th quantile. After this point, the negative
income) across different quantiles of the dependent variable (CE-I) (see             effect gradually weakens and turns positive at the 60th quantile. This
                                                                                     positive effect continues to strengthen, peaking at the 80th quantile,
                                                                                     before declining and becoming negative again at the 90th and 95th
                                                                                     quantiles. This pattern suggests that while IQ may initially hinder
                                                                                     progress at lower levels, it becomes beneficial as IQ improves, up to a
                                                                                     point where the positive influence starts to diminish and eventually
                                                                                     turns negative at the highest levels.

                                                                                      These findings indicate that country-specific patterns are shaped by
                                                                                  differing institutional and cultural contexts. In China, the United States,
                                                                                  and Germany, improvements in IQ have the greatest effect when IQ is
                                                                                  initially low, but the impact diminishes as IQ advances, suggesting that
                                                                                  early-stage interventions are most effective. This aligns with Udemba
                                                                                  (2021), who emphasized the role of IQ in shaping developmental out-
                                                                                  comes, particularly in the early stages. In contrast, India and Russia
Fig. 1. Annual per capita CO2 emissions of the top 1% (in tCO2).                  display more complex, non-linear relationships: in India, IQ improve-
Source. Arora et al. (2023).                                                      ments initially appear to worsen CE-I before eventually contributing to

                                                                              7
B. Bergougui et al.                                                                                              Journal of Cleaner Production 483 (2024) 144215




                                                    Fig. 2. QQR estimates of the impact of IQ on CE-I.


reductions, likely due to transitional disruptions, consistent with Welsch       context-specific policy approaches.
(2004), who discusses the impact of political inefficiencies and corrup-
tion on environmental governance. In Russia, very high IQ levels might             (b) Income impact on CE-I
even increase CE-I, highlighting the challenges of achieving equity
under advanced governance structures, potentially due to persistent                 The analysis also reveals diverse patterns of income’s impact on CE-I
corruption or weak regulatory quality (Abid, 2016). Japan’s fluctuating          across the six countries.
pattern may be linked to cultural factors that emphasize collective
welfare and strict regulatory compliance, where initial institutional ri-         • In China, the impact of income on CE-I is positive and relatively
gidity might hinder progress, but later adaptations prove beneficial                strong at medium quantiles but sharply decreases at higher quantiles
(Zhang et al., 2018; Ahmed et al., 2022). These findings suggest that               (0.80–0.95). This suggests that income growth has a stronger effect
while strengthening IQ is generally beneficial, the effectiveness of such           on increasing CE-I at middle-income levels, with diminishing effects
improvements depends on each country’s starting conditions and                      at higher income levels.
broader socio-cultural environment, emphasizing the need for tailored,


                                                                             8
B. Bergougui et al.                                                                                              Journal of Cleaner Production 483 (2024) 144215




                                                  Fig. 3. QQR estimates of the impact of income on CE-I.


 • The United States exhibits a negative marginal influence of income              exhibiting an inverted U-shape pattern. This implies that income
   on CE-I in the lower income quantiles (0.05–0.40) but shows an                  growth has the strongest effect on increasing CE-I at middle-income
   increasing trend. The effect becomes positive, albeit weak, in the              levels.
   middle quantiles and progressively strengthens in the upper quan-             • Russia shows a similar pattern to India, with income demonstrating a
   tiles (0.70–0.95). This indicates that income growth may initially              positive effect across all quantiles. This effect is particularly strong
   reduce CE-I but eventually contributes to its increase, particularly at         and stable at the lower and middle quantiles but sharply declines
   higher income levels.                                                           towards the extreme right tail (0.65–0.95). This suggests that income
 • Germany displays a gradual increase in the marginal effect of income            growth consistently contributes to increased CE-I, with the effect
   on CE-I, with a strong negative impact at the lower and median                  moderating at very high-income levels.
   quantiles (0.05–0.55), eventually becoming positive and relatively            • In Japan, the marginal effect of income on CE-I is positive. At mod-
   strong at higher quantiles of income. This suggests a transition point          erate income levels (between the 25th and 45th quantiles), the
   where income growth shifts from reducing to increasing CE-I.                    positive effect is most pronounced, indicating that CE-I increases
 • India presents a positive effect of income on CE-I, with a pronounced           with income within this range. However, at the lower and higher
   impact at middle quantiles and a weaker impact at the extremes,                 ends of the income distribution (the extreme tails), the effect


                                                                             9
B. Bergougui et al.                                                                                                    Journal of Cleaner Production 483 (2024) 144215


    diminishes, suggesting that income disparities have a less significant        and median quantiles but increases it at higher levels, implying a shift in
    impact on CE-I. This inverted U-shape pattern implies that the rela-          the relationship as economic growth progresses. This aligns with the
    tionship between income and CE-I is not linear but instead varies             findings of Seriño and Klasen (2015) on the inverse U-shaped relation-
    across different income levels.                                               ship between income and CO2 emissions.
                                                                                       India and Russia both exhibit an inverted U-shaped effect, with in-
    The subsequent findings on the impact of income on carbon emis-               come significantly increasing CE-I at middle-income levels while
sions inequality (CE-I) reveal diverse country-specific patterns that             moderating at the extremes. This suggests a consistent pattern where the
reflect varying economic and socio-cultural dynamics. In China, income            impact of income growth is most pronounced in the middle-income
growth significantly increases CE-I at middle-income levels, but this             range, reflecting the observations of Liu et al. (2019) regarding the
influence diminishes at higher income levels, suggesting that the effect          distributional effects of income in emerging economies. Japan, mean-
of rising income on inequality weakens as the economy advances. This is           while, displays a similar inverted U-shaped relationship, with more
consistent with the findings of Wiedenhofer et al. (2017), who observed           pronounced effects at moderate income levels. This indicates a
the concentration of emissions among the wealthiest income groups.                non-linear relationship where income disparities have a lesser impact at
    In the United States, income initially reduces CE-I at lower quantiles        the lower and higher ends of the distribution, consistent with Huang
but contributes to an increase at higher income levels, indicating that           et al. (2022), who noted that variations in household carbon footprints
economic growth may initially promote emissions equity but eventually             drive emissions inequality.
exacerbate disparities. This trend is also highlighted by Starr et al.                 These findings suggest that the relationship between income and CE-
(2023) who discussed how economic factors can aggravate inequality.               I is context-dependent, with variations reflecting each country’s unique
Germany shows a transition point, where income reduces CE-I at lower              economic structure and broader socio-cultural factors. Tailored policy


Table 3
Quantiles Granger causality results.
  Country             China              USA                   Germany                  India                   Russia                       Japan

  Quantile            IQ⇨      Income⇨   IQ⇨      Income⇨      IQ⇨       Income⇨        IQ⇨       Income⇨       IQ⇨          Income⇨         IQ⇨        Income⇨
                      CE-I     CE-I      CE-I     CE-I         CE-I      CE-I           CE-I      CE-I          CE-I         CE-I            CE-I       CE-I

  ALL                 0,01     0,04      0,015    0,015        0,015     0,015          0,015     0,015         0,015        0,030           0,01       0,01
    QUANTILES
  0.05                0,01     0,01      0,015    0,015        0,015     0,015          0,015     0,015         0,015        0,015           0,01       0,03
  0.1                 0,01     0,01      0,015    0,015        0,015     0,015          0,015     0,015         0,015        0,015           0,01       0,01
  0.15                0,01     0,01      0,015    0,015        0,015     0,015          0,015     0,015         0,015        0,015           0,01       0,01
  0.2                 0,01     0,01      0,015    0,015        0,015     0,015          0,030     0,015         0,015        0,463           0,01       0,01
  0.25                0,45     0,33      0,239    0,015        0,239     0,448          0,254     0,015         0,418        0,209           0,24       0,01
  0.3                 0,01     0,39      0,015    0,030        0,015     0,015          0,313     0,209         0,015        0,030           0,01       0,15
  0.35                0,01     0,36      0,015    0,015        0,015     0,015          0,090     0,060         0,015        0,104           0,01       0,01
  0.4                 0,04     0,04      0,015    0,015        0,015     0,134          0,373     0,015         0,015        0,299           0,01       0,01
  0.45                0,45     0,48      0,448    0,164        0,448     0,134          0,224     0,299         0,433        0,313           0,45       0,10
  0.5                 0,07     0,15      0,075    0,657        0,075     0,418          0,627     0,836         0,090        0,224           0,07       0,27
  0.55                0,10     0,12      0,119    0,119        0,104     0,149          0,448     0,015         0,090        0,075           0,06       0,10
  0.6                 0,01     0,21      0,015    0,149        0,015     0,015          0,015     0,015         0,015        0,030           0,01       0,01
  0.65                0,03     0,03      0,015    0,015        0,015     0,015          0,015     0,015         0,030        0,045           0,01       0,04
  0.7                 0,01     0,21      0,015    0,015        0,015     0,015          0,373     0,015         0,015        0,030           0,01       0,01
  0.75                0,01     0,43      0,015    0,015        0,015     0,015          0,030     0,015         0,015        0,015           0,01       0,01
  0.8                 0,01     0,01      0,015    0,015        0,015     0,015          0,119     0,015         0,015        0,015           0,01       0,01
  0.85                0,01     0,01      0,015    0,015        0,015     0,015          0,030     0,015         0,015        0,015           0,01       0,01
  0.9                 0,01     0,01      0,015    0,015        0,015     0,015          0,015     0,015         0,015        0,015           0,01       0,01
  0.95                0,04     0,06      0,045    0,090        0,045     0,164          0,194     0,060         0,045        0,328           0,04       0,15

  Country             China              USA                   Germany                   India                  Russia                       Japan

  Quantile            CE-I ⇨   CE-I ⇨    CE-I ⇨   CE-I ⇨       CE-I ⇨    CE-I ⇨          CE-I ⇨   CE-I ⇨        CE-I ⇨       CE-I ⇨          CE-I ⇨     CE-I ⇨
                      IQ       Income    IQ       Income       IQ        Income          IQ       Income        IQ           Income          IQ         Income

  ALL                 0,04     0,01      0,01     0,01         0,01      0,01            0,01     0,01          0,01         0,01            0,01       0,01
    QUANTILES
  0.05                0,01     0,01      0,01     0,01         0,01      0,01            0,01     0,01          0,01         0,01            0,01       0,01
  0.1                 0,01     0,01      0,01     0,01         0,01      0,01            0,01     0,01          0,01         0,01            0,01       0,01
  0.15                0,01     0,01      0,01     0,01         0,01      0,01            0,01     0,01          0,01         0,01            0,01       0,01
  0.2                 0,01     0,01      0,01     0,01         0,01      0,01            0,03     0,01          0,01         0,01            0,01       0,01
  0.25                0,01     0,42      0,48     0,24         0,01      0,24            0,25     0,22          0,46         0,46            0,03       0,24
  0.3                 0,01     0,01      0,03     0,01         0,01      0,01            0,31     0,01          0,24         0,01            0,01       0,01
  0.35                0,49     0,01      0,01     0,01         0,01      0,01            0,09     0,01          0,07         0,01            0,01       0,01
  0.4                 0,30     0,04      0,04     0,01         0,07      0,01            0,37     0,04          0,06         0,01            0,04       0,01
  0.45                0,22     0,45      0,06     0,45         0,36      0,45            0,22     0,45          0,16         0,43            0,51       0,45
  0.5                 0,58     0,07      1,00     0,07         0,73      0,07            0,63     0,07          0,51         0,09            0,79       0,07
  0.55                0,30     0,10      0,06     0,12         0,10      0,10            0,45     0,15          0,22         0,09            0,03       0,06
  0.6                 0,01     0,01      0,01     0,01         0,01      0,01            0,01     0,01          0,28         0,01            0,01       0,01
  0.65                0,46     0,03      0,01     0,01         0,03      0,01            0,01     0,03          0,01         0,03            0,04       0,01
  0.7                 0,03     0,01      0,01     0,01         0,01      0,01            0,37     0,01          0,01         0,01            0,01       0,01
  0.75                0,01     0,01      0,01     0,01         0,01      0,01            0,03     0,01          0,01         0,01            0,01       0,01
  0.8                 0,01     0,01      0,01     0,01         0,01      0,01            0,12     0,01          0,01         0,01            0,01       0,01
  0.85                0,01     0,01      0,01     0,01         0,01      0,01            0,03     0,01          0,01         0,01            0,01       0,01
  0.9                 0,01     0,01      0,07     0,01         0,01      0,01            0,01     0,01          0,01         0,01            0,01       0,01
  0.95                0,06     0,04      0,12     0,04         0,01      0,04            0,19     0,04          0,03         0,04            0,01       0,04

Note: Values Correspond to p-values.

                                                                             10
B. Bergougui et al.                                                                                                      Journal of Cleaner Production 483 (2024) 144215


measures are necessary to address these differences effectively, partic-           4.1.4. Kernel-based regularized least squares (KRLS) results
ularly by focusing on reducing emissions inequality among middle-                     The KRLS approach, proposed by (Hainmueller and Hazlett, 2014), is
income populations, where the impact of growth appears strongest.                  employed to evaluate the prediction power of the regressors through the
                                                                                   use of pointwise derivatives. Unlike traditional econometric methods,
4.1.3. Quantiles Granger causality results                                         KRLS offers the advantage of minimizing misspecification bias.
    A comprehensive understanding of the relationship between CE-I,                Following (Sarkodie and Owusu, 2020; Usman et al., 2024), the model is
IQ, and income levels is crucial for addressing sustainability chal-               specified as follow:
lenges related to climate change. Granger causality analysis allows for
                                                                                   CEI = β0 + β1 income + β2 IQ + ε                                                 (9)
determining whether past values of one variable can predict future
values of another, revealing temporal relationships and feedback                   In this context, β0 denotes the intercept, while, β1 and β2 represent the
mechanisms that are valuable for both theoretical and applied research.            slope coefficients associated with income and institutional quality (IQ),
In this context, Troster et al. (2018) introduced the Granger quantile             respectively. The term ε represents the error term.
non-causality test, which provides a more detailed analysis compared to                The findings from the average marginal effects of the Kernel Regu-
the classic Granger test by examining multiple quantiles. This approach            larized Least Squares (KRLS) analysis, as shown in Table 4, indicate that
captures asymmetric causal effects and avoids splitting samples, thereby           the model is statistically significant at the 1% level. The model’s pre-
preserving temporal dependence and sample size. The quantile causality             dictive accuracy for the six countries under study exceeds 0.75, implying
test helps confirm the predictive power of regressors on the conditional           that IQ and income account for more than 75% of the variance in CE_I.
distribution of the dependent variable. This paper uses the quantile               This suggests that institutional quality and income serve as strong pre-
causality test to examine causal interactions between CE-I, IQ, and in-            dictors of CE_I. Moreover, the evaluation of the heterogeneity in the
come in various economies, analyzing p-values from 19 quantiles                    marginal effects, reported at the 25th, 50th, and 75th percentiles,
ranging from the 5th to 95th percentile. This methodology allows for the           further supports the existence of a nonlinear conditional relationship
detection of both linear and nonlinear causal effects across the distri-           within the model. The pattern of the average marginal effects, along
bution, providing a deeper perspective on the relationships between the            with those at the specified percentiles, aligns with the QQR results
variables. The results are presented in Table 3.                                   previously discussed.
    In the case of China, the analysis shows a bidirectional causal rela-
tionship between IQ and CE-I, with the null hypothesis of no causality             4.1.5. Robustness analysis
from IQ to CE-I being rejected at most quantiles except for the 25th,                  To assess the validity of the QQR approach, a simple comparison was
45th, and 55th. The causality from CE-I to IQ is not rejected in the               made between the estimated coefficients from QR and the τ-averaged
middle quantiles (35th to 55th). Similarly, a bidirectional relationship           coefficients from the QQR model. The QR models are defined as
between income and CE-I is observed at average quantiles, highlighting             following:
interdependence between these variables in China.
    In the United States, a bidirectional relationship between IQ and CE-I                             1∑ ̂
                                                                                   γ 1 (θ) ≡ β̂
                                                                                              11 (θ) =      β (θ, τ1 )                                            (10)
is confirmed across most quantiles, except the 25th and 55th. Further-                                 T τ1 11
more, income causes CE-I at extreme quantiles, while no causality is
observed in the middle quantiles (45th to 60th). Feedback relationships                                1∑ ̂
                                                                                   γ 2 (θ) ≡ β̂
                                                                                              21 (θ) =      β (θ, τ2 )                                            (11)
between income, IQ, and CE-I are also noted in the average quantiles.                                  T τ2 21
For Germany, a feedback effect is observed across all quantiles for
causality from CE-I to IQ, except in the middle quantile range (45th to            Where γ 1 (θ) and γ2 (θ) denoted the effect coefficients of the traditional
55th), and a similar pattern is seen between income and CE-I, except in            quantile regression of the variables Inst and income on CE I respectively.
the middle quantiles.                                                              T represents the number of quantiles of the grid τ . Figs. 4 and 5 show the
    In the case of India, a bidirectional causality between IQ and CE-I is         results of quantile regression and averaged QQR effect parameters that
identified on average, though the null hypothesis of no causality holds at         quantify the influence of IQ and income on CE-I. The averaged QQR
specific quantiles, particularly between the 25th and 30th, and in the             parameters closely align with the quantile regression estimates for both
middle quantiles (40th to 55th). Similar findings apply to the relation-           IQ and income. These Figs offer a straightforward validation of the QQR
ship between income and CE-I, indicating that the dependence between               method employed in the previous section, demonstrating that the main
these variables may vary significantly across different parts of the dis-          characteristics of the traditional quantile regression model can be
tribution. For Russia, the overall results suggest interdependence be-             replicated by summarizing the detailed information found in the QQR
tween IQ, income, and CE-I, though the null hypothesis of no causality             estimates. The results from the quantile regression align consistently
holds for certain quantiles, such as the 25th, 30th, and the middle                with those obtained from the QQR estimates for both models.
quantiles. This implies that the predictability between these variables is
not homogeneous across all levels of the distribution.

Table 4
KRLS average marginal effects.
                      CE I        Average          SE                t                   P>t             P25              P50                P75              R

  China               income      27,91            2,16              12,875              0,00            3,38             24,89              48,29            93,69%
                      IQ          13,41            3,12              4288                0,00            − 20,93          5,1                42,48
  USA                 income      − 11,7322        4,30913           − 2723              0,01            − 36,94          − 17,14            25,43            75,85%
                      IQ          49,0645          4105              11,952              0,00            − 1378           64,66              90,4
  Germany             income      − 2,58127        1,62072           − 1593              0,01            − 7,67           − 2378             − 0,26           80,23%
                      IQ          14,8746          1,65021           9014                0,00            10,77            15,46              19,10
  India               income      9,12883          0,934512          9769                0,00            4,25             7,88               14,69            81,54%
                      IQ          4,45929          1,84149           2422                0,02            − 4,16           1,93               14,48
  Russia              income      33,5644          2426              13,835              0,00            21,26            35,58              48,6             79,55%
                      IQ          17,4123          3,43266           5073                0,00            − 0,88           20,35              38,7
  Japan               income      4,09957          0,449987          9,11                0,00            2,19             3,90               6,15             78,73%
                      IQ          − 3,24822        2,1437            − 1515              0,03            − 25,84          − 1,74             17,54


                                                                              11
B. Bergougui et al.                                                                                                Journal of Cleaner Production 483 (2024) 144215




                                      Fig. 4. Comparative analysis of IQ Effects on CE-I using QQR and QR methods.


4.2. Discussion                                                                  levels (Abid et al., 2015). The strong positive effect of income on CE-I at
                                                                                 middle-income levels, followed by a decreasing impact at higher quan-
    The aim of this paper was to investigate the relationship between IQ,        tiles, reflects the inverted U-shaped relationship described by Seriño and
income, and CE-I using a quantile-on-quantile regression approach for            Klasen (2015), which indicates that income growth initially exacerbates
the top six CO2-emitting countries. Below, the main findings for each            CE-I before potentially moderating at higher levels.
country are discussed.                                                               In the United States, the positive and strong effect of IQ at lower and
    China presents an asymmetric relationship between IQ and CE-I. The           middle quantiles, followed by a decline at higher quantiles, suggests that
consistently positive effect of IQ at lower quantiles suggests that im-          initial improvements in IQ can significantly reduce CE-I, but this effect
provements in IQ are particularly effective in reducing CE-I when                diminishes as IQ reaches higher levels. This pattern aligns with findings
starting conditions are poor. This aligns with the literature emphasizing        from Salman et al. (2019), who observed that while improvements in IQ
the role of effective IQ in managing environmental issues (Udemba,               can effectively reduce CE-I, their impact diminishes at higher levels of
2021). However, the diminishing effect at higher quantiles indicates that        quality. The negative impact of income on CE-I at lower quantiles, which
further improvements may have less impact on CE-I as IQ advances. This           transitions to a positive effect at higher levels, underscores the litera-
finding is consistent with the general understanding that institutional          ture’s findings on how income disparities exacerbate CE-I, particularly
improvements are crucial, but their marginal benefits decrease at higher         in high-income contexts (Starr et al., 2023).


                                                                            12
B. Bergougui et al.                                                                                                 Journal of Cleaner Production 483 (2024) 144215




                                    Fig. 5. Comparative analysis of income effects on CE-I using QQR and QR methods.


    Germany shows a positive relationship between IQ and CE-I at lower            regional and demographic disparities in emissions. The inverted
quantiles, which diminishes at higher quantiles, suggesting that insti-           U-shaped effect of income on CE-I, with a pronounced impact at
tutional improvements are most effective in reducing CE-I when the                middle-income levels, supports Huang et al. (2022) and Mi et al. (2020),
initial quality is low. This supports Zhang et al. (2018), who highlight          indicating that income growth initially exacerbates CE-I before poten-
the importance of IQ in managing environmental outcomes. The gradual              tially moderating at higher levels.
shift from a negative to a positive impact of income on CE-I at higher                Russia shows a strong positive impact of IQ on CE-I at lower and
quantiles is consistent with the Environmental Kuznets Curve (EKC)                middle quantiles, followed by a notable decline and reversal at higher
theory discussed by Chen et al. (2022), suggesting that while income              quantiles. This non-linear relationship suggests that while improve-
growth initially reduces CE-I, it eventually contributes to higher in-            ments in IQ can initially reduce CE-I, very high levels may contribute to
equalities. In India, the initially negative impact of IQ on CE-I at lower        increased inequalities. This finding is consistent with Azam et al. (2021)
quantiles, transitioning to a positive effect at median and higher quan-          and Chhabra et al. (2023), who emphasize the importance of managing
tiles, suggests a complex dynamic where initial institutional shortcom-           IQ to avoid negative effects at higher levels. The stable positive impact of
ings might exacerbate inequalities before ultimately reducing them. This          income on CE-I across quantiles, with a decline at extreme levels, aligns
aligns with Zheng et al. (2022) and Liu and Zhang (2022), who noted               with Hubacek et al. (2017) and Wiedenhofer et al. (2017), indicating


                                                                             13
B. Bergougui et al.                                                                                                   Journal of Cleaner Production 483 (2024) 144215


that income growth consistently contributes to CE-I, though its impact              findings of Chen et al. (2021), regulatory measures associated with
may diminish at very high levels.                                                   large-scale events, like the Nanjing Youth Olympic Games, can tempo-
   In Japan, the pronounced negative effect of IQ at lower quantiles,               rarily improve environmental efficiency, indicating that similar targeted
which turns positive at higher quantiles, reflects a complex relationship           policy actions could benefit emission reduction efforts in the United
where initial institutional deficiencies hinder progress, but improve-              States.
ments become beneficial as quality enhances. This pattern supports                       In Germany, it is essential to prioritize improvements in IQ at local
Zhang et al. (2018) and Asongu and Odhiambo 2020a. The inverted                     levels and address the tipping point where income growth begins to
U-shaped effect of income on CE-I, with a significant impact at moderate            increase CE-I. Policies should support municipalities in developing
levels, mirrors findings from Wiedenhofer et al. (2017) and Mi et al.               sustainable infrastructure, such as subsidies for energy-efficient retro-
(2020a), suggesting that income disparities significantly influence CE-I,           fitting of public and private buildings. It is also crucial to foster
particularly at middle-income levels.                                               collaboration between the public and private sectors to develop
                                                                                    renewable energy and low-emission projects, with a particular focus on
5. Conclusion, policy caveats, and future research                                  citizen participation in the ownership of these projects, which can
                                                                                    generate community-level income and reduce inequalities.
5.1. Conclusion                                                                          For India, managing the initial negative impact of IQ on CE-I requires
                                                                                    enhancing transparency and administrative efficiency through the
    This paper identified an asymmetric interaction between IQ, income              digitization of government services and reducing the bureaucracy that
levels, and CE-I across different countries. In general, improvements in            hinders effective policy implementation. Furthermore, to manage the
IQ are highly effective at reducing CE-I, particularly when initial con-            inverted U-shaped effect of income growth CE-I, equitable access to
ditions are poor. However, as IQ improves, its marginal benefits tend to            economic opportunities should be promoted through education and
diminish, illustrating a non-linear relationship. This pattern is evident in        training programs focused on green jobs, facilitating a transition to a
several countries, including China, the United States, and Germany,                 sustainable economy. Providing incentives for the adoption of clean
where initial gains from improved IQ are significant but become less                technologies in the agricultural and manufacturing sectors, where a
impactful as institutional development advances. Additionally, the ef-              large portion of the workforce is concentrated, will also be key to
fect of income on CE-I often follows an inverted U-shaped curve, where              reducing disparities.
income growth initially exacerbates CE-I before potentially moderating                   In Russia, managing the non-linear relationship between IQ and CE-I
at higher levels.                                                                   requires specific policies to improve institutional efficiency at lower and
    In contrast, countries like India, Russia, and Japan display more               middle levels, while avoiding adverse effects that could arise at very
complex interactions between IQ and CE-I. In India, initial institutional           high institutional levels. Enhancing government transparency through
deficiencies can worsen inequalities before improvements become                     public audits and citizen participation in environmental decision-
beneficial. Russia exhibits a non-linear relationship, where IQ reduces             making, especially in resource-rich regions where emissions inequality
CE-I at lower quantiles but can increase inequalities at very high levels.          is often more pronounced, is recommended. Policies to promote income
Japan’s pattern, characterized by an initial negative effect of IQ that             equality should include economic diversification and the development
becomes positive at higher levels, underscores the importance of                    of sustainable sectors beyond the reliance on extractive industries,
achieving high IQ for effective environmental management.                           accompanied by wealth redistribution programs through progressive
                                                                                    taxation.
5.2. Policy Caveats                                                                      In Japan, optimizing IQ to maximize reductions in CE-I is crucial.
                                                                                    This could be achieved by promoting more rigorous accountability
    Next, country-specific policy recommendations are proposed based                standards for local authorities in relation to meeting emission reduction
on the main findings. In China, it is crucial to focus policies on                  targets, as well as encouraging cooperation between municipal gov-
enhancing IQ at local and regional levels to effectively reduce CE-I. This          ernments and the private sector for the implementation of clean energy
could be achieved through training and professionalization programs for             projects. To address the inverted U-shaped effect of income disparities,
local officials to promote efficient and transparent environmental                  sustainable economic growth that benefits all segments of society should
management, as well as creating performance evaluation systems that                 be promoted, including incentives for small and medium enterprises to
reward sustainable practices. Additionally, to mitigate the impact of               adopt energy-efficient practices, which would help reduce the unequal
income growth on increasing inequalities, especially at middle-income               burden of carbon emissions. Implementing comprehensive environ-
levels, subsidies and tax incentives for companies adopting clean pro-              mental regulations and supporting green innovation, as observed during
duction practices and low-carbon technologies are recommended. Pro-                 the Nanjing Youth Olympic Games (Chen et al., 2021), could help ach-
gressive environmental regulations and sustainable economic growth                  ieve a more equitable distribution of carbon emissions.
strategies can also help address these issues. As highlighted by (Luo
et al., 2023), green innovation could serve as an effective approach to             5.3. Limitations and future Scope of study
reducing environmental pollution. Fostering green innovation, such as
promoting eco-friendly patents and supporting research and develop-                     This study has some limitations that should be considered. Firstly,
ment (R&D) in clean technologies, will strengthen China’s capacity to               the analysis primarily relies on aggregate country-level data, which may
reduce carbon emissions effectively.                                                overlook certain regional variations in IQ and income levels. Future
    In the United States, policies should target improvements in IQ at              research could incorporate subnational data to capture local dynamics
lower and middle levels to effectively reduce CE-I. This includes                   more effectively. Secondly, while the study focuses on IQ and income as
decentralizing regulatory power to local governments, allowing for                  key drivers of CE-I, it may not include all relevant factors, such as cul-
more agile responses tailored to specific regional conditions. Reforms              tural influences and technological advancements. Including these fac-
should include incentives to build capacity in municipal governments,               tors in future research could provide a broader understanding of CE-I.
particularly in vulnerable communities. Moreover, to address the                    Additionally, the absence of data from smaller emitter countries might
income-carbon emissions inequality nexus, it is necessary to strengthen             limit the generalizability of the findings. Including these countries in
environmental justice programs, ensuring that low-income communities                future studies could help determine whether the observed patterns apply
do not suffer disproportionately from industrial emissions. Incentives for          to different economic and institutional contexts. Similarly, potential
installing green technologies, such as solar panels in low-income resi-             measurement challenges in assessing IQ may introduce some limita-
dential areas, could help mitigate these inequalities. According to the             tions, but using a variety of measures or indices could improve accuracy

                                                                               14
B. Bergougui et al.                                                                                                                            Journal of Cleaner Production 483 (2024) 144215


in future research.                                                                                 Bergougui, B., 2024c. Moving toward environmental mitigation in Algeria: asymmetric
                                                                                                        impact of fossil fuel energy, renewable energy and technological innovation on CO2
                                                                                                        emissions. Energy Strategy Reviews 51, 101281. https://doi.org/10.1016/j.
CRediT authorship contribution statement                                                                esr.2023.101281.
                                                                                                    Bergougui, B., Aldawsari, M.I., 2024. Asymmetric impact of patents on green
                                                                                                        technologies on Algeria’s Ecological Future. Journal of Environmental Management
   Brahim Bergougui: Writing – review & editing, Writing – original
                                                                                                        355, 120426. https://doi.org/10.1016/j.jenvman.2024.120426.
draft, Supervision, Methodology, Investigation, Conceptualization.                                  Bergougui, B., Doğan, B., Ghosh, S., Ayad, H., 2024. Impact of Environmental
Reda Hamza Boudjana: Writing – original draft, Visualization, Meth-                                     Technology, Economic Complexity, and Geopolitical Risk on Carbon Emission
odology, Investigation. Samer Mehibel: Writing – original draft, Vali-                                  Inequality in Developed and Developing Countries: Evidence from a PVAR-GMM
                                                                                                        Approach. Environment, Development and Sustainability.
dation, Investigation, Conceptualization. Manuel A. Zambrano-                                       Bergougui, B., Mehibel, S., Boudjana, R.H., 2024. Asymmetric nexus between green
Monserrate: Writing – original draft, Validation, Formal analysis,                                      technologies, economic policy uncertainty, and environmental sustainability:
Conceptualization.                                                                                      evidence from Algeria. Journal of Environmental Management 360, 121172. https://
                                                                                                        doi.org/10.1016/j.jenvman.2024.121172.
                                                                                                    Bergougui, B., Murshed, S.M., Shahbaz, M., Zambrano-Monserrate, M.A., Samour, A.,
Declaration of competing interest                                                                       Aldawsari, M.I., 2024. Towards Secure Energy Systems: Examining Asymmetric
                                                                                                        Impact of Energy Transition, Environmental Technology and Digitalization on
                                                                                                        Chinese City-level Energy Security. Renewable Energy 121883. https://doi.org/10
    The authors declare that they have no known competing financial                                     .1016/j.renene.2024.121883.
interests or personal relationships that could have appeared to influence                           Bruckner, B., Hubacek, K., Shan, Y., Zhong, H., Feng, K., 2022. Impacts of poverty
the work reported in this paper.                                                                        alleviation on national and global carbon emissions. Nature Sustainability 5 (4),
                                                                                                        311–320. https://doi.org/10.1038/s41893-021-00842-z.
                                                                                                    Chakravarty, S., Chikkatur, A., De Coninck, H., Pacala, S., Socolow, R., Tavoni, M., 2009.
Data availability                                                                                       Sharing global CO2 emission reductions among one billion high emitters.
                                                                                                        Proceedings of the National Academy of Sciences 106 (29), 11884–11888.
                                                                                                    Chancel, L., 2022. Global carbon inequality over 1990–2019. Nature Sustainability 5
    Data will be made available on request.                                                             (11), 931–938. https://doi.org/10.1038/s41893-022-00955-z.
                                                                                                    Chancel, L., Piketty, T., 2015. Carbon and Inequality: from Kyoto to Paris Trends in the
References                                                                                              Global Inequality of Carbon Emissions (1998-2013) & Prospects for an Equitable
                                                                                                        Adaptation Fund World Inequality Lab.
                                                                                                    Chen, L., Gozgor, G., Lau, C.K.M., Mahalik, M.K., Rather, K.N., Soliman, A.M., 2024. The
Abdulov, R., 2020. Artificial intelligence as an important factor of sustainable and Crisis-
                                                                                                        impact of geopolitical risk on CO2 emissions inequality: evidence from 38 developed
     Free economic growth. Procedia Computer Science 169, 468–472. https://doi.org/
                                                                                                        and developing economies. Journal of Environmental Management 349, 119345.
     10.1016/J.PROCS.2020.02.223.
                                                                                                        https://doi.org/10.1016/J.JENVMAN.2023.119345.
Abid, K., Gholami, R., Choate, P., Nagaratnam, B.H., 2015. A review on cement
                                                                                                    Chen, L., Xu, L., Yang, Z., 2019. Inequality of industrial carbon emissions of the urban
     degradation under CO2-rich environment of sequestration projects. J. Nat. Gas Sci.
                                                                                                        agglomeration and its peripheral cities: a case in the Pearl River Delta, China.
     Eng. 27, 1149–1157. https://doi.org/10.1016/J.JNGSE.2015.09.061.
                                                                                                        Renewable and Sustainable Energy Reviews 109, 438–447. https://doi.org/
Abid, M., 2016. Impact of economic, financial, and institutional factors on CO2
                                                                                                        10.1016/J.RSER.2019.04.010.
     emissions: evidence from Sub-Saharan Africa economies. Util. Pol. 41, 85–94.
                                                                                                    Chen, Z., Hao, X., Zhou, M., 2022. Does institutional quality affect air pollution?
     https://doi.org/10.1016/J.JUP.2016.06.009.
                                                                                                        Environmental Science and Pollution Research 29 (19), 28317–28338. https://doi.
Ahmed, Z., Cary, M., Ali, S., Murshed, M., Ullah, H., Mahmood, H., 2022. Moving toward
                                                                                                        org/10.1007/s11356-021-17934-0.
     a green revolution in Japan: symmetric and asymmetric relationships among clean
                                                                                                    Chen, Y., Long, X., Salman, M., 2021. Did the 2014 Nanjing Youth Olympic Games
     energy technology development investments, economic growth, and CO2 emissions.
                                                                                                        enhance environmental efficiency? New evidence from a quasi-natural experiment.
     Energy Environ. 33 (7), 1417–1440.
                                                                                                        Energy Policy 159, 112581.
Akhbari, R., Nejati, M., 2019. The effect of corruption on carbon emissions in developed
                                                                                                    Cheng, S., Fan, W., Zhang, J., Wang, N., Meng, F., Liu, G., 2021. Multi-sectoral
     and developing countries: empirical investigation of a claim. Heliyon 5 (9), e02516.
                                                                                                        determinants of carbon emission inequality in Chinese clustering cities. Energy 214,
     https://doi.org/10.1016/J.HELIYON.2019.E02516.
                                                                                                        118944. https://doi.org/10.1016/J.ENERGY.2020.118944.
Ali, H.S., Zeqiraj, V., Lin, W.L., Law, S.H., Yusop, Z., Bare, U.A.A., Chin, L., 2019. Does
                                                                                                    Chhabra, M., Giri, A.K., Kumar, A., 2023. Do trade openness and institutional quality
     quality institutions promote environmental quality? Environmental Science and
                                                                                                        contribute to carbon emission reduction? Evidence from BRICS countries.
     Pollution Research 26 (11), 10446–10456. https://doi.org/10.1007/s11356-019-
                                                                                                        Environmental Science and Pollution Research 30 (17), 50986–51002. https://doi.
     04670-9.
                                                                                                        org/10.1007/s11356-023-25789-w.
Alola, A.A., Özkan, O., Usman, O., 2023. Examining crude oil price outlook amidst
                                                                                                    Cole, M.A., 2007. Corruption, income and the environment: an empirical analysis.
     substitute energy price and household energy expenditure in the USA: A novel
                                                                                                        Ecological Economics 62 (3–4), 637–647. https://doi.org/10.1016/J.
     nonparametric multivariate QQR approach. Energy Econ. 120, 106613. https://doi.
                                                                                                        ECOLECON.2006.08.003.
     org/10.1016/J.ENECO.2023.106613.
                                                                                                    Connolly, M., Shan, Y., Bruckner, B., Li, R., Hubacek, K., 2022. Urban and rural carbon
Andersson, F.N.G., 2023. Income inequality and carbon emissions in the United States
                                                                                                        footprints in developing countries. Environmental Research Letters 17 (8), 84005.
     1929–2019. Ecological Economics 204, 107633. https://doi.org/10.1016/J.
                                                                                                        https://doi.org/10.1088/1748-9326/ac7c2a.
     ECOLECON.2022.107633.
                                                                                                    Dong, B., Chen, Y., Fan, C., 2022. Local corruption and dividend policy: evidence from
Appiah-Twum, F., Long, X., 2023. Human capital, trade competitiveness and
                                                                                                        China. Finance Research Letters 47, 102698. https://doi.org/10.1016/J.
     environmental efficiency convergence across Asia Pacific countries. Environmental
                                                                                                        FRL.2022.102698.
     and Resource Economics 85 (1), 109–132. https://doi.org/10.1007/s10640-023-
                                                                                                    Dong, K., Ni, G., Taghizadeh-Hesary, F., Zhao, C., 2023. Does smart transportation
     00758-6.
                                                                                                        matter in inhibiting carbon inequality? Energy Economics 126, 106952. https://doi.
Arora, C., Das, P., Chaturvedi, V., 2023. The Emissions Divide: Inequity across Countries
                                                                                                        org/10.1016/J.ENECO.2023.106952.
     and Income Classes. Council on Energy, New Delhi. Environment, and Water.
                                                                                                    Durrah, O., Tawfik, O.I., Aldhmour, F.M., 2024. The use of artificial intelligence in
Asongu, S.A., Odhiambo, N.M., 2020a. Governance, CO2 emissions and inclusive human
                                                                                                        enhancing the quality of decisions in healthcare institutions. Artificial intelligence,
     development in sub-Saharan Africa. Energy Exploration & Exploitation 38 (1),
                                                                                                        Big data, blockchain and 5G for the digital Transformation of the Healthcare
     18–36. https://doi.org/10.1177/0144598719835594.
                                                                                                        Industry: a Movement toward more Resilient and inclusive. Societies 189–203.
Azam, M., Liu, L., Ahmad, N., 2021. Impact of institutional quality on environment and
                                                                                                        https://doi.org/10.1016/B978-0-443-21598-8.00017-8.
     energy consumption: evidence from developing world. Environment, Development
                                                                                                    Effah, E., Pärn, E., Chan, A., Owusu-Manu, D.-G., Edwards, D., Darko, A., 2017. Corrupt
     and Sustainability 23 (2), 1646–1667. https://doi.org/10.1007/s10668-020-00644-
                                                                                                        practices in the Construction Industry: survey of Ghanaian experience. Journal of
     x.
                                                                                                        Management in Engineering 33, 05017006. https://doi.org/10.1061/(ASCE)
Becker, M., Karpytchev, M., Hu, A., 2023. Increased exposure of coastal cities to sea-level
                                                                                                        ME.1943-5479.0000555.
     rise due to internal climate variability. Nature Climate Change 13 (4), 367–374.
                                                                                                    Fankhauser, S., Jotzo, F., 2017. Economic growth and development with low-carbon
     https://doi.org/10.1038/s41558-023-01603-w.
                                                                                                        energy. Wiley Interdisciplinary Reviews: Climate Change 9, e495. https://doi.org/
Benoit, D.F., Van den Poel, D., 2009. Benefits of quantile regression for the analysis of
                                                                                                        10.1002/wcc.495.
     customer lifetime value in a contractual setting: an application in financial services.
                                                                                                    Feng, K., Hubacek, K., Song, K., 2021. Household carbon inequality in the U.S. Journal of
     Expert Systems with Applications 36 (7), 10475–10484. https://doi.org/10.1016/j.
                                                                                                        Cleaner Production 278, 123994. https://doi.org/10.1016/J.
     eswa.2009.01.031.
                                                                                                        JCLEPRO.2020.123994.
Bergougui, B., 2024a. Algeria’s pathway to COP28 and SDGs: asymmetric impact of
                                                                                                    Ghimire, A., Ali, S., Long, X., Chen, L., Sun, J., 2024. Effect of Digital Silk Road and
     environmental technology, energy productivity, and material resource efficiency on
                                                                                                        innovation heterogeneity on digital economy growth across 29 countries: new
     environmental sustainability. Energy Strategy Reviews 55, 101541. https://doi.org/
                                                                                                        evidence from PSM-DID. Technological Forecasting and Social Change 198, 122987.
     10.1016/j.esr.2024.101541.
                                                                                                        https://doi.org/10.1016/J.TECHFORE.2023.122987.
Bergougui, B., 2024b. Investigating the relationships among green technologies,
                                                                                                    Gureev, P.M., Degtyareva, V.V., Prokhorova, I.S., 2020. National features of forming a
     financial development and ecological footprint levels in Algeria: evidence from a
                                                                                                        digital economy in Russia. In: Popkova, E.G., Sergi, B.S. (Eds.), Artificial Intelligence:
     novel Fourier ARDL approach. Sustainable Cities and Society 112, 105621. https://
     doi.org/10.1016/j.scs.2024.105621.


                                                                                               15
B. Bergougui et al.                                                                                                                                Journal of Cleaner Production 483 (2024) 144215

     Anthropogenic Nature vs. Social Origin. Springer International Publishing,                         Panayotou, T., 1997. Demystifying the environmental Kuznets curve: turning a black box
     pp. 13–20.                                                                                              into a policy tool. Environment and Development Economics 2 (4), 465–484. http://
Hainmueller, J., Hazlett, C., 2014. Kernel regularized least squares: reducing                               www.jstor.org/stable/44379189.
     misspecification bias with a flexible and interpretable machine learning approach.                 Phuc Canh, N., Schinckus, C., Thanh, S.D., 2019. Do economic openness and institutional
     Political Analysis 22 (2), 143–168.                                                                     quality influence patents? Evidence from GMM systems estimates. International
Haldar, A., Sethi, N., 2021. Effect of institutional quality and renewable energy                            Economics 157, 134–169. https://doi.org/10.1016/J.INTECO.2018.10.002.
     consumption on CO2 emissions− an empirical investigation for developing countries.                 Qader, K.S., Cek, K., 2024. Influence of blockchain and artificial intelligence on audit
     Environmental Science and Pollution Research 28 (12), 15485–15503. https://doi.                         quality: evidence from Turkey. Heliyon 10 (9), e30166. https://doi.org/10.1016/J.
     org/10.1007/s11356-020-11532-2.                                                                         HELIYON.2024.E30166.
Han, M., Lao, J., Yao, Q., Zhang, B., Meng, J., 2020. Carbon inequality and economic                    Qi, B., Shen, Y., Xu, T., 2023. An artificial-intelligence-enabled sustainable supply chain
     development across the Belt and Road regions. Journal of Environmental                                  model for B2C E-commerce business in the international trade. Technological
     Management 262, 110250.                                                                                 Forecasting and Social Change 191, 122491. https://doi.org/10.1016/J.
Heidarpanah, M., Hooshyaripor, F., Fazeli, M., 2023. Daily electricity price forecasting                     TECHFORE.2023.122491.
     using artificial intelligence models in the Iranian electricity market. Energy 263,                Safar, W., 2022. Income inequality and CO2 emissions in France: does income inequality
     126011. https://doi.org/10.1016/J.ENERGY.2022.126011.                                                   indicator matter? Journal of Cleaner Production 370, 133457. https://doi.org/
Huang, Y., Shigetomi, Y., Matsumoto, K., 2022. Evaluating carbon inequality by                               10.1016/J.JCLEPRO.2022.133457.
     household type and Income level across prefectures in Japan. Sustainable Cities and                Salman, M., Long, X., Dauda, L., Mensah, C.N., 2019. The impact of institutional quality
     Society 87, 104236. https://doi.org/10.1016/J.SCS.2022.104236.                                          on economic growth and carbon emissions: evidence from Indonesia, South Korea
Hubacek, K., Baiocchi, G., Feng, K., Muñoz Castillo, R., Sun, L., Xue, J., 2017. Global                     and Thailand. Journal of Cleaner Production 241, 118331. https://doi.org/10.1016/
     carbon inequality. Energy, Ecology and Environment 2 (6), 361–369. https://doi.                         j.jclepro.2019.118331.
     org/10.1007/s40974-017-0072-9.                                                                     Sarkodie, S.A., Owusu, P.A., 2020. How to apply the novel dynamic ARDL simulations
Iacobuță, A.-O., Hatmanu Gagea, M., 2010. Institutional quality, economic freedom and                       (dynardl) and Kernel-based regularized least squares (krls). MethodsX 7, 101160. htt
     sustainable development. A comparative analysis of EU countries. Revista                                ps://doi.org/10.1016/J.MEX.2020.101160.
     Economică 3, 252–260.                                                                             Sehrawat, M., Singh, S.K., 2021. Do corruption and income inequality play Spoilsport in
Ibrahim, M.H., Law, S.H., 2016. Institutional quality and CO2 emission–trade relations:                      the energy efficiency-growth relationship in BRICS countries? Journal of
     evidence from sub-Saharan Africa. South African Journal of Economics 84 (2),                            Quantitative Economics 19 (4), 727–746. https://doi.org/10.1007/s40953-021-
     323–340. https://doi.org/10.1111/saje.12095.                                                            00244-0.
Ivanova, D., Wood, R., 2020. The unequal distribution of household carbon footprints in                 Semieniuk, G., Yakovenko, V.M., 2020. Historical evolution of global inequality in
     Europe and its link to sustainability. Global Sustainability 3. https://doi.org/                        carbon emissions and footprints versus redistributive scenarios. Journal of Cleaner
     10.1017/sus.2020.12.                                                                                    Production 264, 121420. https://doi.org/10.1016/J.JCLEPRO.2020.121420.
Kartal, M.T., 2022. The role of consumption of energy, fossil sources, nuclear energy, and              Seriño, M. N. V, & Klasen, S. (2015). Estimation and Determinants of the Philippines’
     renewable energy on environmental degradation in top five carbon producing                              Household Carbon Footprint. The Developing Economies, 53(1), 44–62. https://doi.
     countries. Renewable Energy 184, 871–880. https://doi.org/10.1016/J.                                    org/10.1111/deve.12065.
     RENENE.2021.12.022.                                                                                Shahbaz, M., Balsalobre, D., Shahzad, S.J.H., 2019. The influencing factors of CO2
Kartal, M.T., 2023. Production-based disaggregated analysis of energy consumption and                        emissions and the role of Biomass energy consumption: statistical experience from G-
     CO2 emission nexus: evidence from the USA by novel dynamic ARDL simulation                              7 countries. Environmental Modeling & Assessment 24 (2), 143–161. https://doi.
     approach. Environmental Science and Pollution Research 30 (3), 6864–6874.                               org/10.1007/s10666-018-9620-8.
     https://doi.org/10.1007/s11356-022-22714-5.                                                        Silvestre, B.S., Monteiro, M.S., Viana, F.L.E., de Sousa-Filho, J.M., 2018. Challenges for
Kartal, M.T., 2024. Impact of environmental tax on ensuring environmental quality:                           sustainable supply chain management: when stakeholder collaboration becomes
     quantile-based evidence from G7 countries. Journal of Cleaner Production 440,                           conducive to corruption. Journal of Cleaner Production 194, 766–776. https://doi.
     140874. https://doi.org/10.1016/J.JCLEPRO.2024.140874.                                                  org/10.1016/J.JCLEPRO.2018.05.127.
Kartha, S., Kemp-Benedict, E., Ghosh, E., Nazareth, A., Gore, T., 2020. The Carbon                      Sim, N., Zhou, H., 2015. Oil prices, US stock return, and the dependence between their
     Inequality Era: an assessment of the global distribution of consumption emissions                       quantiles. Journal of Banking & Finance 55, 1–8. https://doi.org/10.1016/J.
     among individuals from 1990 to 2015 and beyond. https://api.semanticscholar.org                         JBANKFIN.2015.01.013.
     /CorpusID:221855445.                                                                               Sommer, M., Kratena, K., 2017. The carbon footprint of European households and
Khan, A.A., Laghari, A.A., Li, P., Dootio, M.A., Karim, S., 2023. The collaborative role of                  income distribution. Ecological Economics 136, 62–72. https://doi.org/10.1016/J.
     blockchain, artificial intelligence, and industrial internet of things in digitalization of             ECOLECON.2016.12.008.
     small and medium-size enterprises. Scientific Reports 13 (1), 1656. https://doi.org/               Starr, J., Nicolson, C., Ash, M., Markowitz, E.M., Moran, D., 2023. Assessing U.S.
     10.1038/s41598-023-28707-9.                                                                             consumers’ carbon footprints reveals outsized impact of the top 1. Ecological
Khan, H., Weili, L., Khan, I., 2022. Institutional quality, financial development and the                    Economics 205, 107698. doi:10.1016/J.ECOLECON.2022.107698.
     influence of environmental factors on carbon emissions: evidence from a global                     Stef, N., Başağaoğlu, H., Chakraborty, D., Ben Jabeur, S., 2023. Does institutional quality
     perspective. Environmental Science and Pollution Research 29 (9), 13356–13368.                          affect CO2 emissions? Evidence from explainable artificial intelligence models.
     https://doi.org/10.1007/s11356-021-16626-z.                                                             Energy Economics 124, 106822. https://doi.org/10.1016/J.ENECO.2023.106822.
Khan, M., Rana, A.T., 2021. Institutional quality and CO2 emission–output relations: the                Sun, M., Chen, G., Xu, X., Zhang, L., Hubacek, K., Wang, Y., 2021. Reducing carbon
     case of Asian countries. Journal of Environmental Management 279, 111569.                               footprint inequality of household consumption in rural areas: analysis from five
     https://doi.org/10.1016/J.JENVMAN.2020.111569.                                                          representative provinces in China. Environmental Science & Technology 55 (17),
Liu, X., Latif, K., Latif, Z., Li, N., 2020. Relationship between economic growth and CO2                    11511–11520. https://doi.org/10.1021/acs.est.1c01374.
     emissions: does governance matter? Environmental Science and Pollution Research                    Teng, J.-Z., Khan, M.K., Khan, M.I., Chishti, M.Z., Khan, M.O., 2021. Effect of foreign
     27 (14), 17221–17228. https://doi.org/10.1007/s11356-020-08142-3.                                       direct investment on CO2 emission with the role of globalization, institutional
Liu, X., Song, J., Wang, H., Wang, S., 2019. Indirect carbon emissions of urban                              quality with pooled mean group panel ARDL. Environmental Science and Pollution
     households in China: patterns, determinants and inequality. Journal of Cleaner                          Research 28 (5), 5271–5282. https://doi.org/10.1007/s11356-020-10823-y.
     Production 241, 118335.                                                                            Tran, Q.T., 2021. Local corruption and dividend policy: evidence from Vietnam.
Liu, G., Zhang, F., 2022. China’s carbon inequality of households: Perspectives of the                       Economic Analysis and Policy 70, 195–205. https://doi.org/10.1016/J.
     aging society and urban-rural gaps. Resources, Conservation and Recycling 185,                          EAP.2021.02.011.
     106449. https://doi.org/10.1016/j.resconrec.2022.106449.                                           Troster, V., Shahbaz, M., Uddin, G.S., 2018. Renewable energy, oil prices, and economic
Lovei, M., Weiss, C., 1998. Environmental Management and Institutions in OECD                                activity: a Granger-causality in quantiles analysis. Energy Economics 70, 440–452.
     Countries: Lessons from Experience, vol. 391. World Bank Publications.                                  https://doi.org/10.1016/j.eneco.2018.01.029.
Luo, Y., Lu, Z., Long, X., 2020. Heterogeneous effects of endogenous and foreign                        Udemba, E.N., 2021. Mitigating environmental degradation with institutional quality
     innovation on CO2 emissions stochastic convergence across China. Energy                                 and foreign direct investment (FDI): new evidence from asymmetric approach.
     Economics 91, 104893. https://doi.org/10.1016/J.ENECO.2020.104893.                                      Environmental Science and Pollution Research 28 (32), 43669–43683. https://doi.
Luo, Y., Wang, Q., Long, X., Yan, Z., Salman, M., Wu, C., 2023. Green innovation and SO2                     org/10.1007/s11356-021-13805-w.
     emissions: Dynamic threshold effect of human capital. Business Strategy and the                    Ulussever, T., Kartal, M.T., Kılıç Depren, S., 2023. Effect of income, energy consumption,
     Environment 32 (1), 499–515.                                                                            energy prices, political stability, and geopolitical risk on the environment: evidence
Mi, Z., Zheng, J., Meng, J., Ou, J., Hubacek, K., Liu, Z., Coffman, D., Stern, N., Liang, S.,                from GCC countries by novel quantile-based methods. Energy & Environment,
     Wei, Y.-M., 2020. Economic development and converging household carbon                                  0958305X231190351. https://doi.org/10.1177/0958305X231190351.
     footprints in China. Nature Sustainability 3 (7), 529–537. https://doi.org/10.103                  Usman, O., Ozkan, O., Ike, G.N., 2024. Global evidence of multi-dimensional asymmetric
     8/s41893-020-0504-y.                                                                                    effect of energy storage innovations on environmental quality: Delineating the role
Ostrom, E., 1998. A behavioral approach to the Rational Choice theory of collective                          of natural resources, nuclear energy and oil consumption. Journal of Cleaner
     action: Presidential address, American political Science association, 1997. The                         Production 451, 142070. https://doi.org/10.1016/J.JCLEPRO.2024.142070.
     American Political Science Review 92 (1), 1–22. https://doi.org/10.2307/2585925.                   Verendel, V., 2023. Tracking artificial intelligence in climate inventions with patent
Oswald, Y., Owen, A., Steinberger, J.K., 2020. Large inequality in international and                         data. Nature Climate Change 13 (1), 40–47. https://doi.org/10.1038/s41558-022-
     intranational energy footprints between income groups and across consumption                            01536-w.
     categories. Nature Energy 5 (3), 231–239. https://doi.org/10.1038/s41560-020-                      Wang, K., Cui, Y., Zhang, H., Shi, X., Xue, J., Yuan, Z., 2022a. Household carbon
     0579-8.                                                                                                 footprints inequality in China: drivers, components and dynamics. Energy Economics
                                                                                                             115, 106334. https://doi.org/10.1016/J.ENECO.2022.106334.




                                                                                                   16
B. Bergougui et al.                                                                                                                       Journal of Cleaner Production 483 (2024) 144215

Wang, Q., Ge, Y., Li, R., 2023a. Does improving economic efficiency reduce ecological            Xiao, Z., 2012. 9 - time series quantile regressions. In: Subba Rao, T., Subba Rao, S.,
   footprint? The role of financial development, renewable energy, and                               Rao, C.R. B.T.-H. of S. (Eds.), Time Series Analysis: Methods and Applications, vol.
   industrialization. Energy & Environment, 0958305X231183914. https://doi.org/                      30. Elsevier, pp. 213–257. https://doi.org/10.1016/B978-0-444-53858-1.00009-0.
   10.1177/0958305X231183914.                                                                    Yang, B., Ali, M., Hashmi, S.H., Jahanger, A., 2022. Do income inequality and
Wang, Q., Sun, T., Li, R., 2023b. Does artificial intelligence promote green innovation?             institutional quality affect CO2 emissions in developing economies? Environmental
   An assessment based on direct, indirect, spillover, and heterogeneity effects. Energy             Science and Pollution Research 29 (28), 42720–42741. https://doi.org/10.1007/
   & Environment, 0958305X231220520. https://doi.org/10.1177/                                        s11356-021-18278-5.
   0958305X231220520.                                                                            Yang, D.-X., Wu, B.-B., Tong, J.-Y., 2021a. Dynamics and causality of oil price shocks on
Wang, Q., Yang, Z., Li, R., 2024a. Impact of income inequality on carbon emissions: a                commodities: quantile-on-quantile and causality-in-quantiles methods. Resources
   matter of corruption governance. Environmental Science and Pollution Research 31                  Policy 74, 102246. https://doi.org/10.1016/j.resourpol.2021.102246.
   (4), 5173–5189. https://doi.org/10.1007/s11356-023-31190-4.                                   Zhang, H., Ding, Y., Niu, J., Jung, S., 2024. How artificial intelligence affects
Wang, Q., Zhang, F., Li, R., 2024b. Artificial intelligence and sustainable development              international industrial transfer — evidence from industrial robot application.
   during urbanization: Perspectives on AI R&D innovation, AI infrastructure, and AI                 Journal of Asian Economics 95, 101815. https://doi.org/10.1016/J.
   market advantage. Sustainable Development. https://doi.org/10.1002/sd.3150 n/a                    ASIECO.2024.101815.
   (n/a).                                                                                        Zhang, M., Liu, J., Liu, L., Zhou, D., 2023. Inequality in urban household energy
Wang, Q., Zhang, F., Li, R., Sun, J., 2024c. Does artificial intelligence promote energy             consumption for 30 Chinese provinces. Energy Policy 172, 113326. https://doi.org/
   transition and curb carbon emissions? The role of trade openness. Journal of Cleaner              10.1016/J.ENPOL.2022.113326.
   Production 447, 141298. https://doi.org/10.1016/J.JCLEPRO.2024.141298.                        Zhang, H., Zhu, Z., Fan, Y., 2018. The impact of environmental regulation on the
Wang, Y., Xiong, S., Ma, X., 2022b. Carbon inequality in global trade: evidence from the             coordinated development of environment and economy in China. Natural Hazards
   mismatch between embodied carbon emissions and value added. Ecological                            91 (2), 473–489. https://doi.org/10.1007/s11069-017-3137-3.
   Economics 195 (C), S092180092200060X. https://EconPapers.repec.org/RePEc:eee:                 Zhao, C., Jia, R., Dong, K., 2023a. Does financial inclusion achieve the dual dividends of
   ecolec:v:195:y:2022:i:c:s092180092200060x.                                                        narrowing carbon inequality within cities and between cities? Empirical evidence
Wang, Z., Danish, Zhang, B., Wang, B., 2018. The moderating role of corruption between               from China. Technological Forecasting and Social Change 195, 122774. https://doi.
   economic growth and CO2 emissions: evidence from BRICS economies. Energy 148,                     org/10.1016/J.TECHFORE.2023.122774.
   506–513. https://doi.org/10.1016/J.ENERGY.2018.01.167.                                        Zhao, C., Li, Y., Liu, Z., Ma, X., 2024. Artificial intelligence and carbon emissions
Wang, Z., Deng, Y., Zhou, S., Wu, Z., 2023c. Achieving sustainable development goal 9: a             inequality: evidence from industrial robot application. Journal of Cleaner Production
   study of enterprise resource optimization based on artificial intelligence algorithms.            438, 140817. https://doi.org/10.1016/J.JCLEPRO.2024.140817.
   Resources Policy 80, 103212. https://doi.org/10.1016/J.                                       Zhao, C., Wang, J., Dong, K., Dong, X., 2023b. A blessing or a curse? Can digital economy
   RESOURPOL.2022.103212.                                                                            development narrow carbon inequality in China? Carbon Neutrality 2 (1), 15.
Wawrzyniak, D., Doryń, W., 2020. Does the quality of institutions modify the economic               https://doi.org/10.1007/s43979-023-00056-6.
   growth-carbon dioxide emissions nexus? Evidence from a group of emerging and                  Zhao, J., Shen, J., Yan, J., Yang, X., Hao, Y., Ran, Q., 2023c. Corruption, market
   developing countries. Economic Research-Ekonomska Istraživanja 33 (1), 124–144.                  segmentation and haze pollution: empirical evidence from China. Journal of
   https://doi.org/10.1080/1331677X.2019.1708770.                                                    Environmental Planning and Management 66 (3), 642–664. https://doi.org/
Welsch, H., 2004. Corruption, growth, and the environment: a cross-country analysis.                 10.1080/09640568.2021.2001316.
   Environment and Development Economics 9 (5), 663–693. http://www.jstor.org/                   Zheng, H., Long, Y., Wood, R., Moran, D., Zhang, Z., Meng, J., Feng, K., Hertwich, E.,
   stable/44379268.                                                                                  Guan, D., 2022. Ageing society in developed countries challenges carbon mitigation.
Wiedenhofer, D., Guan, D., Liu, Z., Meng, J., Zhang, N., Wei, Y.-M., 2017. Unequal                   Nature Climate Change 12 (3), 241–248. https://doi.org/10.1038/s41558-022
   household carbon footprints in China. Nature Climate Change 7 (1), 75–80. https://                -01302-y.
   doi.org/10.1038/nclimate3165.                                                                 Zheng, H., Wood, R., Moran, D., Feng, K., Tisserant, A., Jiang, M., Hertwich, E.G., 2023.
Wu, S., Chen, Z.M., 2023. Carbon inequality in China: evidence from city-level data.                 Rising carbon inequality and its driving factors from 2005 to 2015. Global
   China Economic Review 78, 101940. https://doi.org/10.1016/J.                                      Environmental Change 82, 102704. https://doi.org/10.1016/J.
   CHIECO.2023.101940.                                                                               GLOENVCHA.2023.102704.
WID, 2023. World inequality Database. https://wid.world/.                                        Zhou, X., Hang, Y., Zhou, D., Ang, B.W., Wang, Q., Su, B., Zhou, P., 2022. Carbon-
                                                                                                     economic inequality in global ICT trade. IScience 25 (12), 105604. https://doi.org/
                                                                                                     10.1016/J.ISCI.2022.105604.




                                                                                            17
