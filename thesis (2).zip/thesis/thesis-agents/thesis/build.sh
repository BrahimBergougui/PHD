#!/usr/bin/env bash
# Build the mémoire PDF. Output: output/Memoire.pdf
set -e
cd "$(dirname "$0")"
python3 scripts/make_part2.py
latexmk main.tex || true
if [ ! -f build/main.pdf ]; then echo "Build failed: see build/main.log"; exit 1; fi
mkdir -p output && cp build/main.pdf output/Memoire.pdf
bash scripts/check_log.sh
