# Terms register (one row per term, defined once, at first use in reading order)

| Term | Abbreviation | Definition (max 20 words) | First used in |
|---|---|---|---|
