                                                           Journal of Environmental Management 355 (2024) 120426


                                                                    Contents lists available at ScienceDirect


                                                  Journal of Environmental Management
                                                         journal homepage: www.elsevier.com/locate/jenvman


Research article

Asymmetric impact of patents on green technologies on Algeria’s
Ecological Future
Brahim Bergougui a, b, *, Mohammed Ibrahim Aldawsari c
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
b
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
c
  Department of Education Policy and Economics, Education College, Taibah University, Medina, Saudi Arabia




A R T I C L E I N F O                                      A B S T R A C T

Handling Editor: Lixiao Zhang                              This study examines how patents on green technologies impact Algeria’s ecological footprint from 1990 to 2022
                                                           while controlling for economic growth and energy consumption. The objectives are to analyze the asymmetric
JEL classification:                                        effects of positive and negative shocks in these drivers on ecological footprint and provide policy insights on
C31                                                        leveraging innovations and growth while minimizing environmental harm. Given recent major structural shifts in
Q33
                                                           Algeria’s economy, time series data exhibits nonlinear dynamics. To accommodate this nonlinearity, the study
R11
                                                           employs an innovative nonlinear autoregressive distributed lag approach. The findings indicate that an upsurge
Keywords:
                                                           in green technologies (termed as a positive shock) significantly reduces the ecological footprint, thereby
Ecological footprint
                                                           enhancing ecological sustainability. Interestingly, a decline in green technologies (termed as a negative shock)
Patents on green technologies
Economic growth                                            also contributes to reducing the ecological footprint. This highlights the crucial role of clean technologies in
Energy consumption                                         mitigating ecological damage in both scenarios. Conversely, a positive shock in economic growth increases
NARDL                                                      ecological footprint, underscoring the imperative for environmentally friendly policies in tandem with economic
Algeria                                                    expansion. Negative shocks, however, have minimal impact. In a similar vein, positive shock in energy con­
                                                           sumption increases ecological footprint, underlining the importance of transitioning towards cleaner energy
                                                           sources. Negative shock has a smaller but still noticeable effect. The results confirm asymmetric impacts, with
                                                           positive and negative changes in the drivers affecting Algeria’s ecological footprint differently. To ensure long-
                                                           term economic and ecological stability, Algeria should prioritize eco-innovation and green technology devel­
                                                           opment. This will reduce dependence on fossil fuels and create new, sustainable industries.


                                                                                                poised to be a platform that underscores the importance of collective
                                                                                                action and international cooperation in addressing these pressing envi­
1. Introduction                                                                                 ronmental issues (Epule et al., 2021; Boudalia et al., 2022). Despite
                                                                                                being one of Africa’s major contributors to greenhouse gas emissions,
    The Glasgow Climate Change Conference (COP26) is a pivotal global                           Algeria faces a unique challenge as its economic growth heavily relies on
gathering aimed at addressing and mitigating the pressing issue of                              oil exports (Elbadri et al., 2023).
climate change. With the ambitious goal of curbing carbon emissions to                              The increasing concerns surrounding climate change underscore the
keep global warming below 3 ◦ C, COP26 holds immense significance in                            urgency of comprehending the reasons behind and the methods for
the battle against climate change (Adedoyin et al., 2023; Gyamfi et al.,                        implementing environmentally advantageous solutions. The green
2023; Bergougui and Murshed, 2023). This study provides an insightful                           technology ethos includes energy conservation, waste minimization,
overview of the COP26 conference, emphasizing its relevance in the                              pollution avoidance, and the use of renewable energy sources (Wang
fight against climate change, specifically focusing on Algeria’s note­                          et al., 2021, 2023b; Razzaq et al., 2023). Green technology strives to
worthy contributions to the international effort. Climate change is an                          establish equilibrium between the two opposing approaches, as opposed
escalating global concern, and its impacts are being felt in every corner                       to the conventional technologies that heavily depend on fossil fuels and
of the world, including Algeria. The North African nation grapples with                         result in substantial greenhouse gas emissions. Embracing green tech­
challenges such as desertification, water scarcity, and rising tempera­                         nology yields multiple advantages in the battle against global warming.
tures, all of which pose significant environmental threats. COP26 is


    * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands.
      E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com (B. Bergougui), mdawsari@taibahu.edu.sa (M.I. Aldawsari).

https://doi.org/10.1016/j.jenvman.2024.120426
Received 10 December 2023; Received in revised form 29 January 2024; Accepted 16 February 2024
Available online 28 February 2024
0301-4797/© 2024 The Authors. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui and M.I. Aldawsari                                                                            Journal of Environmental Management 355 (2024) 120426



   List of acronyms                                                              GDP       Gross domestic product
                                                                                 GDP +     Positive shocks (Gross domestic product)
   ARDL   Autoregressive distributed lag                                         GDP       Negative shocks (Gross domestic product)
   BDS    Brock, Dechert, and Scheinman                                          HJC       Hatemi-J lag selection criterion
   CCR    canonical cointegrating regression                                     JB        Jarque-Bera
   CO2    Carbon dioxide emissions                                               LS        Lee-Strazicich
   COP26 Glasgow Climate Change Conference                                       NARDL     Nonlinear autoregressive distributed lag
   CUSUM cumulative sum for recursive residuals                                  POGT      Patents on green technologies
   CUSUMSQ cumulative sum of squared for recursive residuals                     POGT +    Positive shocks (Patents on green technologies)
   DOLS   dynamic ordinary least squares                                         POGT      Negative shocks (Patents on green technologies)
   EC     Energy consumption                                                     USD       United States Dollar
   EC +   Positive shocks (Energy consumption)                                   VAR       Vector autoregression
   EC     Negative shocks (Energy consumption)                                   VECM      Vector error correction model
   EIA    U.S. Energy Information Administration publication                     WDI       World Development Indicators
   FMOLS fully modified ordinary least squares



A notable benefit is the substantial reduction in greenhouse gas emis­             [1] To evaluate whether a positive (negative) shock in green tech­
sions. Transitioning from fossil fuels to renewable energy sources such as             nologies leads to a reduction (rise) in ecological footprint levels in
solar, wind, and hydropower is a significant way to reduce carbon di­                  Algeria.
oxide emissions (Javed et al., 2023b; Saqib and Dincă, 2023). Green               [2] To evaluate whether a positive (negative) shock in energy con­
technology      also   promotes       resource   conservation    through               sumption leads to a reduction (rise) in ecological footprint levels
energy-efficient buildings, reducing energy demand (Javed et al.,                      in Algeria.
2023a). Furthermore, there may be financial advantages to using green              [3] To evaluate whether a positive (negative) shock in economic
technologies. As a result of the shift toward more sustainable behaviors,              growth leads to a reduction (rise) in ecological footprint levels in
jobs in industries such as renewable energy production and eco-product                 Algeria.
manufacturing have become available (Xie et al., 2022; Jiakui et al.,
2023). Similarly, the inadequacy of recycling centers and trash man­                Incorporating these three facets - green technology, energy use, and
agement infrastructure may impede the spread of environmentally                  economic growth - is essential to provide an integrated and unbiased
beneficial waste management practices. Deficits in policymaking and a            understanding of the key determinants of Algeria’s environmental and
general need for more understanding of the benefits of green technology          ecological footprint.
impede its spread. Governments should enact legislation that encour­                The current study provides significant contributions toward
ages, regulates, and subsidizes the deployment of clean technologies.            exploring the relationship among POGT, GDP, EC, and EF in the Algerian
The public must know the importance of green technology for societal             economy.
change (Hina et al., 2022; Anuardo et al., 2022). Green technology is
being prioritized as a strategy for combating climate change by gov­              • Firstly, This study employs the nonlinear autoregressive distributed
ernments worldwide. Many governments have implemented state, fed­                   lag (NARDL) model to analyze the asymmetric drivers of the
eral, and global laws to encourage broad use. For example, many local               ecological footprint in Algeria over time. The NARDL framework
governments provide financial incentives, such as tax exemptions, for               confers several advantages that address the limitations of conven­
constructing energy-efficient constructions. National governments                   tional linear approaches used in similar econometric analyses. (i)
develop renewable portfolio standards to ensure enough electricity is               Capturing nonlinearities and asymmetries: the technique can capture
generated from sustainable resources. International agreements like the             both short-run and long-run asymmetries and nonlinearities through
Paris Agreement attempt to reduce global warming by encouraging                     partial sum decompositions of positive and negative changes in
governments to limit carbon emissions. Businesses and people are                    explanatory variables. This allows for examining the differential
frequently pushed to adopt greener practices, such as building renew­               impacts of increasing and decreasing trends. (ii) Accommodating
able energy systems or switching to more energy-efficient products,                 stationarity heterogeneity: the NARDL remains applicable to datasets
through tax credits and other financial incentives (Furuoka, 2017).                 mixing stationary and non-stationary time series by applying bounds
Green technology is an essential instrument in the fight against climate            testing (Pesaran et al., 2001). (iii) Efficient estimation: The NARDL
change since it provides sustainable alternatives to existing approaches.           model leverages ordinary least squares for parameter estimation.
Economic benefits such as employment creation and cost savings are                  This technique offers the significant advantage of being computa­
only two examples of how this benefits the planet. Renewable energy,                tionally efficient and straightforward compared to alternative
energy-efficient buildings, electric vehicles, and waste management                 methodologies, contributing to the overall robustness and accessi­
systems are just a few examples of many businesses (Cantera et al.,                 bility of empirical analysis. Given Algeria’s macroeconomy has un­
2022). However, several challenges must be overcome before green                    dergone major structural shifts in recent decades, accounting for
technology can be deployed broadly. These include prohibitively high
initial expenses, insufficient infrastructure support, regulatory de­
ficiencies, and a need for more public awareness. Only the government
can give help and incentives for implementing sustainable practices
(Wang et al., 2021). Investment in the study, development, and use of
revolutionary green technologies is critical to create a self-sustaining
future. Green technology adoption on a large scale has the potential to
have a significant impact on climate change mitigation and human
civilization’s long-term security. Motivated by the analysis mentioned
above, the objectives of this study are:

                                                                             2
B. Bergougui and M.I. Aldawsari                                                                                      Journal of Environmental Management 355 (2024) 120426


   evolutions in asymmetric1 and potentially nonlinear relationships                      revealed that green technologies, economic growth, and energy con­
   between factors like green technologies, economic growth, energy                       sumption influenced the ecological footprint in Algeria. Although
   use, and ecological footprints is essential. The NARDL framework is                    partially consistent with prior research, the results differed by suggest­
   better equipped to capture these nuances compared to methods used                      ing that positive and negative shocks could have asymmetric effects on
   in extant analyses of the country’s sustainability outlook.                            the ecological footprint. The nonlinear nature of these shocks could
 • Secondly, this study incorporates ecological footprint as a more                       result in misinterpretations if ignored. This knowledge could assist
   comprehensive and multi-faceted indicator of ecological degradation                    Algeria in developing an effective ecological policy that considers these
   compared to the prevailing use of carbon dioxide emissions in the                      asymmetric relationships.
   literature on Algeria. While CO2 emissions provide insights into at­                       The study is organized as follows: Section 2 reviews the relevant
   mosphere dynamics, it fails to account for broader pollution factors                   literature on the relationship between ecological and footprint green
   related to land, soil, water, and forests that determine the overshoot                 technologies, economic growth, and energy consumption. Section 3
   of regenerative ecosystems. On the other hand, the ecological foot­                    describes the methodology used to estimate the NARDL and Granger
   print methodology developed by (Wackernagel and Rees, 1998) of­                        causality models. Section 4 reports and discusses the empirical results.
   fers a holistic gauge of sustainability by synthesizing various facets                 Section 5 concludes the research and provides some limitations and
   including cropland, pasture, built infrastructure, fishing stores, and                 directions for future research.
   carbon absorption capacity that constrain a population’s means of
   subsistence. By incorporating ecological footprint as the key envi­                    2. Literature review
   ronmental metric instead of leaner measures like CO2 emissions, this
   study provides a fuller and more nuanced assessment of the multi­                         According to the existing literature, low levels of ecological footprint
   dimensional stresses degrading Algeria’s ecological well-being. The                    depend largely on the adoption of green technologies (Nyiwul, 2017,
   footprint lens acknowledges that sustainability challenges encom­                      2021; Kihombo et al., 2021), whereas high levels of carbon footprint are
   pass more than just climate change or industrial emissions in isola­                   driven by energy consumption and economic growth (Ahmad et al.,
   tion. Algeria faces rising threats related to biodiversity, habitat loss,              2020a). Algeria, as a developing country, tends to exploit its energy
   land degradation, and intensive water usage. As such, this analysis                    resources for economic development, which leads to considerable
   delivers a comprehensive picture of environmental damage while                         ecological damage due to its high carbon footprint. Thus, Algeria’s
   revealing synergies and trade-offs between economic, technological,                    economy is confronted with the crucial challenge of reconciling eco­
   and ecological trajectories. The ecological footprint indicator choice                 nomic growth and ecological sustainability (Bergougui, 2024). Investi­
   is a major value-add in contextualizing the complex forces jeopard­                    gating green technologies, energy consumption, and economic growth
   izing Algeria’s journey towards a green transition in line with its                    through further research is vital to provide policymakers with the tools
   commitments under the Sustainable Development Goals.                                   needed to help Algeria achieve its ecological footprint reduction goals.
 • Thirdly, this study represents the first analysis of the impact of pat­                This section reviews existing literature and identifies key research gaps
   ents on green technologies on ecological footprint in Algeria, shed­                   that could inform effective policy decisions.
   ding light on the varied ways in which green technologies can
   influence ecological footprint. These findings not only contribute                     2.1. Studies on the impact of green technologies on ecological
   valuable knowledge to the understanding of the relationship be­                        sustainability
   tween green technologies and ecological outcomes but also carry
   significant implications for the design and implementation of pol­                         Green technologies have gained attention from policymakers and
   icies aimed at promoting clean technology and sustainable                              researchers as a way to lower the ecological footprints of human activ­
   development.                                                                           ities. Kirikkaleli et al. (2023b) supported this idea by investigating the
 • Fourthly, this study assesses the asymmetric cointegration dynamics                    relationship between ecological footprints and environmental technol­
   in both the long and short run among green technologies, economic                      ogy patents in the USA from 1970 to 2018. The authors employed a
   growth, energy consumption, and ecological footprint. This meth­                       Fourier ARDL approach to analyze the association and found that green
   odology offers results that are more robust and dependable                             technologies significantly predict and reduce long-term ecological
   compared to conventional time series methods. Using such an                            footprint depletion in the USA. To enforce this argument, Chunling et al.
   approach will have significant benefits for Algerian policymakers as                   (2021) used ARDL to examine the connection between ecological foot­
   a valuable tool to develop strategies that effectively balance long-                   prints and green technologies in the case of Pakistan using data from the
   term energy needs while addressing the country’s overall carbon                        period between 1992 and 2018, revealing innovation increases EF.
   footprint.                                                                             Similarly, the work by Chu (2022) used the advanced panel quantile
                                                                                          method to examine the connection between ecological footprints and
    The results of the empirical analysis indicate that the ecological                    green technologies in the 27 OECD nations. The main findings reveal
footprint was significantly reduced by both positive and negative shocks                  that innovation has an impact on EF. Analogously, the study of Rout
in green technologies, whereas positive shock in economic expansion                       et al. (2022) explores the connection between ecological footprints and
increased ecological footprint levels, although negative shocks had no                    green technologies in Southeast Asian nations. The results from the
impact. Moreover, energy consumption led to an increase in the                            ARDL method demonstrate that green technologies reduce the ecolog­
ecological footprint, with a positive shock approximately two-fold the                    ical footprint. Recently, Aydin et al. (2024) studied the effect of envi­
effect compared to a negative shock. The Granger causality tests also                     ronmental technologies on environmental sustainability, measured by
                                                                                          the ratio of biocapacity to EF, in ten European countries from 1990 to
                                                                                          2019. They used a common correlated effects mean group (CCEMG)
 1
                                                                                          estimator model and revealed that environmental technologies enhance
    Asymmetry can occur for several reasons. For instance, technological
                                                                                          environmental quality. Likewise, Saqib et al. (2024) and Xia and Liu
innovation aimed at improving energy efficiency is more likely to result in a
                                                                                          (2024) agreed that environmental technologies improve ecological
decrease in CO2 emissions than innovation that does not focus on energy effi­
ciency (Ullah et al., 2021; Kirikkaleli et al., 2023a). Additionally, the impact of       outcomes. Despite the prevailing evidence on positive green technolo­
energy consumption on CO2 emissions is likely to be different in developed                gies impacts, some studies suggest no significant ecological footprint
countries than in developing countries. This is because developed countries               effects. Using an advanced panel data model for the period 1994–2018,
tend to have higher levels of energy consumption and pollution than developing            Bozatli and Akca (2023) found OECD countries showed no statistically
countries (Sharif et al., 2019; Razzaq et al., 2021b).                                    significant environmental technologies impact on EF. Similarly, Destek

                                                                                      3
B. Bergougui and M.I. Aldawsari                                                                                Journal of Environmental Management 355 (2024) 120426


and Manga (2021) scrutinized the connection between ecological foot­                environmental degradation using CO2 emissions as a proxy for evalu­
prints and green technologies in the case of the BEM nations utilizing              ating environmental quality. Some of these studies include Lacheheb
data from 1995 to 2016. The author used second-generation panel data                et al. (2015), Bouznit and Pablo-Romero (2016), Elbadri et al. (2023),
to inspect the association. The findings showed that green technologies             and Bergougui (2024). However, only a few studies have utilized the
do not influence EF.                                                                ecological footprint as an environmental indicator to assess the factors
    A possible reason for the inconsistent results on how green tech­               impacting the environment in Algeria. The initial study was conducted
nologies affect ecological footprints is the variation in the availability of       by Rahmane et al. (2021), who established a positive correlation be­
funds for environmental technology projects that can lower ecological               tween primary energy intensity and the ecological footprint in Algeria
footprint levels. Ahmed et al. (2021) point out that the USA has not                over the period 1970–2017. The second study by Boukhelkhal (2022)
invested enough in renewable energy and clean technology programs.                  explored the relationship between economic growth, and the ecological
As a result, the use and spread of these technologies are not high enough           footprint in Algeria from 1980 to 2017 using the ARDL approach, and it
to significantly reduce emissions or ecological damage compared to                  was discovered that economic growth has increased the ecological
economic growth in the US economy. In contrast, studies that report                 footprint. Chaouachi and Balsalobre-Lorente (2022) utilized an ARDL
footprint reductions from green innovation usually involve countries                econometric approach from 1975 to 2014, with their findings indicating
that have a long history of supporting and prioritizing cleantech (Saqib            that per capita economic growth increases the ecological footprint.
et al., 2024). The degree of government involvement and access to re­               Shehzad et al. (2022) arrived at a similar conclusion in their study.
sources for environmental technology initiatives could account for the              Chekouri et al. (2023) also expressed a similar viewpoint regarding the
different ecological outcomes. A comparative analysis of public budget              negative impact of GDP on Algeria’s ecological quality.
allocations could help identify the minimum level of funding needed to
enable impactful adoption.                                                          2.3. Theoretical mechanism

2.2. Studies on other factors affecting ecological sustainability                       Within the realm of technological innovation, specifically the inno­
                                                                                    vation of manufacturing and production processes, (Acemoglu et al.,
    Ecological indicators such as ecological footprint and biocapacity              2012) propose a dual categorization of technologies: “dirty” and
have been widely used in recent research to assess environmental per­               “green”. Dirty technologies represent those that worsen environmental
formance and sustainability (Shahzad et al., 2021). Ecological footprint,           burdens and pollution, while green technologies encompass innovations
as a comprehensive and communicable metric that measures human                      that positively impact the environment and offer solutions to pollution
environmental impact and economic-ecological linkages (Rafique et al.,              challenges. The World Intellectual Property Organization publishes the
2022), has been extensively utilized for examining the causes of resource           “IPC Green Inventory” to identify clean technologies based on the IPC
depletion and degradation. This section surveys the prior empirical                 classification (León et al., 2017). This inventory includes classifications
literature that has employed the ecological footprint as an indicator of            such as alternative energy production, transportation, energy conser­
ecological sustainability. Special focus is given to studies that include           vation, and nuclear power generation. These classifications can be
economic growth and energy consumption as determinants that affect                  interpreted as influencing channels through which green technologies
the dynamics of ecological footprint.                                               may affect carbon footprint, as illustrated in Fig. 1. Firstly, green tech­
    In a recent study conducted in the USA, Zafar et al. (2019) discovered          nologies can indirectly impact ecological footprint through improve­
that economic growth and energy consumption contribute to an increase               ments in energy efficiency. (Shabir et al., 2023) observe a reduction in
in the country’s ecological footprint. Similarly, Khan et al. (2021) also           energy intensity in industrial sectors across seventeen OECD countries
investigated the impact of energy consumption and growth on the                     due to green patents, suggesting that enhanced energy efficiency can
ecological footprint in the USA and found a positive relationship be­               curtail carbon footprint. Secondly, the structure of energy consumption
tween growth and non-renewable energy consumption with the                          has the potential to function as a noteworthy influencing pathway, with
ecological footprint. Awodumi and Adewuyi (2020) examined the in­                   green technologies potentially lowering the cost of clean energy and
fluence of Biomass and economic growth on the ecological footprint in               increasing the proportion of clean energy in the overall energy con­
BRICS economies between 1992 and 2018 using the methods of mo­                      sumption structure (Aydin and Degirmenci, 2023). This shift to renew­
ments quantile regression. Their findings indicated that economic                   able energy sources is recognized as a more environmentally friendly
growth raises the ecological footprint, while biomass energy utilization            alternative to fossil energy (Kazemzadeh et al., 2023). Thirdly, green
reduces it. When studying the effect of income and renewable energy on              technologies can stimulate the upgrading of industrial structures by
the ecological footprint, Danish et al. (2019) confirmed the Environ­               fostering the development of low-pollution and environmentally sound
mental Kuznets Curve for BRICS countries when utilizing the ecological              industries (Yu et al., 2023). Lastly, end-of-pipe treatments, such as
footprint as a measure of environmental degradation. Ahmad et al.                   carbon capture, utilization, and storage, are identified as significant
(2020a,b) explored a group of 22 emerging economies and analyzed the                contributors to the reduction of carbon footprint (Hammar and Löfgren
relationship between economic growth and the ecological footprint from              2010; Sun et al., 2023).
1984 to 2016, finding that economic growth expands the ecological
footprint. Similarly, Gupta et al. (2022) in a more recent study found              2.4. Evaluation of the literature
that energy consumption degrades environmental quality in
Bangladesh. Using the ARDL approach, Hassan and Mhlanga (2023)                          While existing literature has extensively examined the impacts of
observed in Pakistan that economic growth increases the ecological                  green technology, energy consumption, and economic growth on
footprint. Wang et al. (2022) analyzed the connection between ecolog­               ecological degradation, certain limitations and gaps prevail:
ical footprint and economic development in 166 provinces, using data                    Firstly, the existing literature has primarily focused on specific
from 1990 to 2015. They used a second-generation econometric meth­                  developed economies such as the USA and Finland, overlooking the
odological framework to analyze this connection, finding that economic              sustainability challenges faced by developing countries. Despite Alge­
development positively affects EF. (Sahoo and Sethi, 2022) examined                 ria’s carbon-intensive, resource-centered economy, there is a significant
the impact of economic growth on ecological footprint and air quality in            absence of research investigations in this context, highlighting the
Newly Industrialized Countries (NICs) from 1990 to 2017. The results                critical need for such studies.
reveal that economic growth increases the ecological footprint in NICs in               Second, the role of green technologies in influencing the ecological
the long run. Turning to studies that consider the Algerian case, there             footprint in Algeria has not been adequately considered. Previous
have been numerous studies examining the factors influencing                        studies have only used the total number of patents to represent

                                                                                4
B. Bergougui and M.I. Aldawsari                                                                                      Journal of Environmental Management 355 (2024) 120426




Fig. 1. The influencing channels of green technologies on improving ecological sustainability. (For interpretation of the references to colour in this figure legend, the
reader is referred to the Web version of this article.)


technological innovation (Bergougui, 2024), which may not accurately                     2022/Q4 (see Table 1). All variables are log-transformed before the
reflect its ecological impact, as it includes some non-environmentally                   empirical analysis. This log transformation ensures consistency in
friendly patents.                                                                        measurement units and helps in normalizing outliers. This method, as
    Third, prior studies have relied on linear econometric models, which                 noted by (Razzaq et al., 2023), helps address distributional issues and
may not capture the nonlinear and asymmetric dynamics inherent in the                    provides elasticities as the output.
relationships between variables, as proved by (Elbadri et al., 2023).                        Fig. 2 depicts the divergent trajectories of Algeria’s ecological foot­
    Fourth, most studies focused on carbon dioxide emissions as a proxy                  print and green technology patent activity from 1990 to 2022. Ecolog­
for atmospheric changes, but they neglected the wider environmental                      ical footprint, representing a proxy for ecological degradation, soars
impacts on land, soil, water, and forests that cause the ecological                      rapidly from 35 million global hectares in 1990 to unsustainable levels
overshot of natural systems. Thus, a more holistic measure, such as the                  surpassing 105 million hectares by 2022. This signals worsening energy-
ecological footprint, is needed to fill this gap.                                        linked ecological stresses with continued reliance on pollutive fossil
    This research advances the scholarly literature by investigating the                 fuels lacking commensurate adoption of clean renewables. In contrast,
asymmetric nexus among key determinants and ecological footprint in                      green technologies denoted by patented inventions exhibit exponential
Algeria employing NARDL and asymmetric causality approaches. These                       growth from a baseline of 24 climate-aligned technologies in 1990 to
methods enable the scrutiny of how the ecological footprint responds                     over 245 by 2015. The initial surge in green patents aligned with
individually to positive and negative changes in green technologies,                     Algeria’s push into information and communication technologies, a
energy consumption, and economic growth. It also assesses ecological                     sector known to foster patent activity and support green tech ventures
footprint as a more inclusive indicator of environmental degradation,                    coupled with knowledge economy policies stimulating intellectual
beyond merely CO2 emissions. This study adopts a more refined proxy of                   property activity.
total patents on technological innovation termed green technologies
which entails only investments in eco-friendly technologies. As one of
the leading energy consumers and carbon emitters in Africa, Algeria
constitutes a significant case that warrants further exploration in these                Table 1
domains. Elucidating these associations intends to provide useful im­                    Data source and description.
plications for Algeria’s energy strategy and sustainability initiatives.                  Data                Code      Description                          Source of data

                                                                                          Ecological          EF        It quantifies human impact on        Global
3. Data and methodology                                                                     footprint                   the environment in land and          Footprint
                                                                                                                        water, indicating resource           Network
                                                                                                                        sustainability and waste             (2023)
3.1. Data
                                                                                                                        absorption measured in global
                                                                                                                        hectare per person
    The objective of this study is to investigate the effects of POGT, GDP,               Patents on green    POGT      Green technology patents             OECD statistics
and EC on EF in Algeria. The data sources for the study are diverse:                        technologies                encompass inventions                 (2023)
ecological footprint per person data from Global Footprint Network                                                      safeguarding innovations that
                                                                                                                        advance environmental
(2023) and EC data obtained from a U.S. Energy Information Adminis­
                                                                                                                        sustainability, energy efficiency,
tration publication (EIA, 2023). POGT data are collected from OECD                                                      and eco-friendly solutions.
statistics (2023), and GDP data are sourced from the World Bank (WDI,                     GDP per capita      GDP       Gross domestic product (GDP)         WDI (2023)
2023). The dynamic model uses quarterly data2 from 1990/Q1 to                                                           per capita (constant 2015
                                                                                                                        international $)
                                                                                          Energy              EC        Energy consumption is the            EIA (2023)
                                                                                            consumption                 aggregate quantity of energy
  2
    To account for the limited time period, a quadratic match-sum technique                                             needed for a specific process,
                                                                                                                        typically measured in kilograms
was used as described by (Shahbaz et al., 2020; Razzaq et al., 2021a; Sun et al.,
                                                                                                                        of oil equivalent
2022; Kartal et al., 2022). This method helps adjust for cyclical fluctuations and
mitigate seasonality effects. As Shahbaz et al.(2017) explained, by minimizing           Notes. WDI indicates the World Development Indicators, USD represents the
point-to-point variability, the quadratic match-sum approach provides more               United States Dollar, and EIA signifies U.S. Energy Information Administration
robust results and isolates the non-seasonal aspects of the data.                        publication. The natural logarithm was applied to all variables.

                                                                                     5
B. Bergougui and M.I. Aldawsari                                                                                   Journal of Environmental Management 355 (2024) 120426




Fig. 2. Ecological footprint and patents on green technologies trends in Algeria. (For interpretation of the references to colour in this figure legend, the reader is
referred to the Web version of this article.)




                                                                    Fig. 3. Analysis flowcharts.

                                                                                  6
B. Bergougui and M.I. Aldawsari                                                                                       Journal of Environmental Management 355 (2024) 120426


3.2. Justifications for variable selection                                         Such events can limit the adequacy of linear approaches, as they are not
                                                                                   designed to account for this instability. The NARDL enables controlling
    This study examined how green technologies influence the ecological            for short-run and long-run cointegration across dependent and inde­
footprint in Algeria while accounting for the effects of economic growth           pendent variables. It also permits the inclusion of variables with
and energy consumption. First, the selection of dependent, explanatory,            differing integration orders of I(0), I(1), or mutual cointegration, unlike
and control variables is grounded in recent literature evidencing ties             other models that assume equivalent integration orders. This analysis
between environmental sustainability measures (Shabir et al., 2023;                examines the long-run asymmetric relationships among POGT, GDP, EC,
Bergougui, 2024). Second, in theory, growing concerns about global                 and EF in Algeria. To simplify, the variables are incorporated in the
warming and ecological degradation have led to increased ecological                following function:
footprints, posing significant challenges for communities and nations
                                                                                   EFt = α0 + α1 (POGT)t + α2 (GDP)t + α3 (EC)t + μt + εt                                     (1)
(Guliyev, 2024). Theoretically, various factors contribute to ecological
footprints with green technologies playing a crucial role. Green tech­                 In this analysis, EFt, POGTt, GDPt, and ECt represent ecological
nologies can reduce the ecological footprint by providing solutions for            footprint, patents on green technologies, economic growth, and energy
sectors that harm the environment (Behera et al., 2023). Therefore,                consumption in Algeria over time t, respectively. POGT enhances
some recent research (Bozatli and Akca, 2023; Habiba et al., 2023)                 ecological sustainability, as measured by lower footprint EFt, if α1 < 0.
showed that green technologies can improve environmental quality.                  Conversely, α1 > 0 implies green technology advancement abandons
According to the Environmental Kuznets Curve (EKC) theory, (Grossman               atmospheric wellbeing by increasing EFt. Hypothesizing α2 > 0 suggests
and Krueger, 1991) they described how economic growth affects                      that GDP growth degrades sustainability by exerting positive pressure
ecological quality in any economy. (Javed et al., 2023b; Kirikkaleli               on the footprint. Postulating α3 > 0 indicates that energy consumption
et al., 2023b) claimed that economic growth is the main factor, and                intensifies ecological damage through a higher footprint, while α3 <
increasing economic activities may damage the environmental quality.               0 suggests declining footprints alongside energy consumption.
Similarly, energy consumption is also a key determinant of ecological                  The NARDL framework developed by (Shin et al., 2014) is used to
footprint. The use of fossil fuels for energy leads to an increase in carbon       determine the asymmetric relationships between the variables by ac­
footprint (Wang et al., 2023a). It was also noted that energy policy plays         counting for changes in the independent and dependent variables. The
a role in both reducing environmental deterioration and creating sus­              NARDL model is advantageous because it does not require variables to
tainable jobs, which are enabled by green growth in the context of                 exhibit hidden co-integration. Additionally, it can capture differing
sustainable development (Saqib et al., 2023). The rapid pace of eco­               impacts of explanatory variables based on positive and negative changes
nomic growth and energy use has directly or indirectly caused several              in both the short and long run. As (Hatemi-J 2020; Granger and Yoon,
threats to biodiversity, such as water scarcity, food insecurity, ecological       2002) discussed, the flexible NARDL approach can identify potential
degradation, and environmental pollution (Sharif et al., 2020). Based on           unobserved cointegrating relationships among integrated data compo­
these assumptions and reviews, the variables were selected and their               nents, regardless of time series integration order, as shown:
relationship in Algeria was explored.
                                                                                   EFt = f (POGT + , POGT − , GDP+ , GDP− , EC+ , EC− )                                       (2)
3.3. Methodology                                                                       Drawing on the methodology proposed by Sun et al. (2022), this
                                                                                   study applies their empirical framework to assess potential asymmetries
    Fig. 3 provides a graphical overview of the step-by-step econometric           related to the chosen variables:
approach implemented in this research investigation, encompassing
vital and systematic analyses. To commence the analysis, time series               EFt = β0 + β1 POGT +              −            +            −           +
                                                                                                      t− 1 + β2 POGT t− 1 + β3 GDPt− 1 + β4 GDPt− 1 + β5 ECt− 1

data on all variables is compiled from reputable international databases             + β6 EC−t− 1 + εt
for the period 1990 to 2022. Next, preliminary analyses are conducted                                                                                                         (3)
including normality assessments to verify dataset distributions, nonlin­
earity tests like the BDS metrics to confirm asymmetric relationships,             where β represents the coefficient for the long run and asymmetric effect
and unit root tests to check stationarity parameters for model validity.           of POGT, GDP, and EC, the positive chocks in these variables are denoted
Preliminary evidence points to the presence of nonlinearities and unit             as (POGT+, GDP+, and EC+). In contrast, negative chocks are repre­
root properties within suitable bounds, prompting the selection of the             sented as (POGT− , GDP− , and EC− ). The positive and negative co­
Nonlinear Autoregressive Distributed Lag (NARDL) approach. This                    efficients are calculated as the aggregate of the squared negative and
powerful technique is uniquely equipped to capture these nuances in the            positive chocks in POGT, GDP, and EC. The model is further re-
data and unveil the intricate relationships between the variables. Spe­            configured through the incorporation of the nonlinear NARDL frame­
cifically, the NARDL bounds testing approach proposed by Pesaran et al.            work and is expressed in Equation (4).
(2001) evaluates cointegration linkages between the factors. Subse­
                                                                                   ΔEFt = β0 + β1 POGT +              −            +            −            +
                                                                                                       t− 1 + β2 POGT t− 1 + β3 GDPt− 1 + β4 GDPt− 1 + β5 EC t− 1
quently, the asymmetric NARDL model formulated by Shin et al. (2014)
is employed to estimate both the short and long-run impacts of positive                               ∑                    ∑                       ∑
                                                                                                      t                    t                       t
                                                                                     + β6 EC−t− 1 +         θ1 ΔEFt− i +         θ2 ΔPOGT +
                                                                                                                                          t− 1 +         θ3 ΔPOGT −t− 1
and negative shocks to the variables on ecological degradation as                                     i=1                  i=1                     i=1
measured. To further illuminate causal relationships, Hatemi-J’s sym­                    ∑
                                                                                         t                     ∑
                                                                                                               t                       ∑
                                                                                                                                       t                    ∑
                                                                                                                                                            t

metric and asymmetric causality tests are employed. Finally, as sensi­               +         θ4 ΔGDP+
                                                                                                      t− 1 +          θ5 ΔGDP−t− 1 +         θ6 ΔEC+
                                                                                                                                                   t− 1 +         θ7 ΔEC−t− 1 + εt
tivity analysis, alternative estimation methods (FMOLS, DOLS, and CCR)                   i=1                    i=1                    i=1                  i=1

are employed, the dependent variable is substituted, and all control                                                                                                          (4)
variables are dropped to validate the baseline NARDL results (see Fig. 3).            When estimating the asymmetric short-run relationships, including
                                                                                   an error correction term (ECT) is critical for enabling equilibrium
3.4. Model specification                                                           adjustment dynamics. The ECT allows the model to converge to its long-
                                                                                   run equilibrium path following short-run divergences across periods.
    To evaluate nonlinear and asymmetric effects, this research uses the           Thus, the model is further augmented to include the ECT, formally
nonlinear autoregressive distributed lag (NARDL) framework developed               expressed in Equation (5).
by (Shin et al., 2014). The NARDL is well-suited for analyzing re­
lationships among variables when unexpected or unreported events like
political changes, financial crises, pandemics, and other shocks occur.

                                                                               7
B. Bergougui and M.I. Aldawsari                                                                                                      Journal of Environmental Management 355 (2024) 120426


ΔEFt = β0 + β1 POGT +              −            +            −           +
                    t− 1 + β2 POGT t− 1 + β3 GDPt− 1 + β4 GDPt− 1 + β5 ECt− 1
                                                                                                         ecological footprint, suggesting that higher levels of economic activity
                   ∑
                   t                    ∑
                                        t                         ∑
                                                                  t                                      and energy consumption are linked to higher ecological footprint.
  + β6 EC−t− 1 +         θ1 ΔEFt− i +          θ2 ΔPOGT +
                                                        t− 1 +          θ3 ΔPOGT −t− 1
                   i=1                   i=1                      i=1                                    4.1.1. Nonlinear test
      ∑                       ∑                       ∑                    ∑                                 To assess the potential nonlinearity in EF, POGT, GDP, and EC, this
      t                       t                       t                    t
  +         θ4 ΔGDP+
                   t− 1 +           θ5 ΔGDP−t− 1 +          θ6 ΔEC+
                                                                  t− 1 +         θ7 ΔEC−t− 1
      i=1                     i=1                     i=1                  i=1
                                                                                                         study applied the augmented Broock et al. (1996) test. Table 3 reports
                                                                                                         the results of the BDS test. The null hypothesis is that the variable has a
  + αECT + εt
                                                                                                         linear distribution (if the BDS statistic value is lower than critical values
                                                                                               (5)
                                                                                                         in dimensions), while the alternative hypothesis is that the variable has a
where, the + and - notation in Equations (4) and (5) represent positive                                  nonlinear distribution (if the Z Statistic value is higher than critical
and negative changes in the regressor variables, respectively. The long-                                 values in dimensions). The results show that the Z statistical values for
run regressor coefficients are denoted by β, while the short-run co­                                     all variables are significantly lower than the critical values at the 1%
efficients are denoted by θ. ECT symbolizes the error correction term,                                   significance level, suggesting the rejection of the null hypothesis and
with its coefficient represented by α.                                                                   providing evidence for nonlinear dynamics in the relationships being
    Following the implementation of the NARDL framework, diagnostic                                      examined.
tests are conducted to validate the validity of the model results. The
diagnostics evaluate the appropriateness of the model specification and                                  4.1.2. Stationarity test
assess issues related to autocorrelation, heteroscedasticity, and                                            Before conducting the NARDL analysis, the stationarity properties of
normality of residuals that could undermine the credibility of the                                       the data were examined using the Lagrange Multiplier (LM) structural
findings.                                                                                                break unit root test proposed by Lee and Strazicich (LS) (2003). This test
                                                                                                         effectively detects potential structural breaks while testing for unit
4. Empirical results and discussion                                                                      roots. To clarify, The null hypothesis of the test is that there is a unit root
                                                                                                         with a two-structural break, while the alternative hypothesis is that
4.1. Preliminary tests                                                                                   there is no unit root with a two-structural break. Table 4 presents the LS
                                                                                                         unit root test results. Table 4 presents the results of the LS unit root test.
    Table 2 provides a comprehensive summary of the dataset charac­                                      Within the 99% confidence level, no evidence supports the rejection of
teristics. The mean values for EF, POGT, GDP, and EC exceed their                                        the null hypothesis of a unit root at the I(0) level for any of the variables.
respective standard deviations, implying uneven distributions in                                         This is further confirmed by the T-statistics reported for EF, POGT, GDP,
Algeria. Skewness statistics reveal right-skewed distributions for EF and                                and EC (− 4.72, − 2.38, − 5.58, and − 6.64, respectively), which exceed
EC, while POGT and GDP display left-skewed distributions. The Jarque-                                    the critical values (− 6.23, − 6.41, − 6.12, and − 6.39, respectively) at the
Bera test statistics reject normality, with all variables having probability                             1% level. However, the test results indicate stationarity at the I(1) level
values supporting the rejection of the null hypothesis of normality,                                     when the variables are differenced once. The identified structural breaks
signifying the sample data are not normally distributed. Quantile-                                       within the LS model may be attributable to events such as global
quantile plots (Q-Q plots) were utilized to visually evaluate normality.                                 financial crises and globalization surges. The presence of these structural
Q-Q plots are valuable graphical tools for testing sample normality                                      changes underscores the suitability of the NARDL model. This model
(Cheng et al., 2021). When a variable follows a normal distribution, the                                 capably captures potential non-linear relationships between the inde­
scatterplot forms a diagonal line. However, the Q-Q plots in Fig. 5                                      pendent variables and the EF variable, even in the presence of structural
illustrate that the points do not align on a straight line, denoting                                     breaks.
non-normality. The Q-Q plot and normality test results for carbon di­
oxide emissions indicate non-normal data. Consequently, the traditional                                  4.2. NARDL bounds test of cointegration
autoregressive distributed lag (ARDL) model is unsuitable for this data,
as it cannot account for the complexities of non-normal data during                                          To evaluate the presence of a long-run equilibrium relationship
estimation. Applying the ARDL model to non-normally distributed data                                     amongst the variables encompassed within the model framework, two
can produce biased estimates. Therefore, employing the NARDL                                             distinct methodological techniques were employed: the t-test proposed
approach is critical for effectively handling potential nonlinearities in                                by (Banerjee et al., 1998) and the F-test intended by (Pesaran et al.,
the data (Cheng et al., 2021; Sun et al., 2022).                                                         2001). The results from Table 5 indicate that the F-statistic of the bounds
    As depicted in Fig. 4, the variables of interest exhibit a correlation                               test (5.7365) exceeds the critical values at the 99 % confidence level.
pattern. A negative correlation is observed between ecological footprint                                 Hence, the null hypothesis of no level relationship is rejected. Addi­
and green technologies, indicating that higher adoption of green tech­                                   tionally, the obtained T-statistics (− 5.5738) surpasses the chosen critical
nologies is associated with a lower ecological footprint. Conversely, the                                values at the 99% confidence level, resulting in a rejection of the null
control variables GDP and energy use display a positive correlation with                                 hypothesis of no cointegrating association between the dependent var­
                                                                                                         iable and explanatory variables. Consequently, a significant long-term
                                                                                                         relationship between EF and its determinants is inferred, which
Table 2                                                                                                  cannot be ignored.
Summary statistics (After logarithm).
                         EF                    POGT              GDP                  EC                 4.3. Asymmetric ARDL empirical analysis
  Mean                   0.465469              1.054896          2.044255             0.948534
  Median                 0.454387              1.083748          2.060321             0.942406               Once the nonlinear cointegration among the variables has been
  Maximum                0.631855              1.490925          2.088666             1.019735           established, the following task involves estimating the coefficient esti­
  Minimum                0.301019              0.484554          1.984735             0.888438           mates for both the short and long run. This estimation process will
  Std. Dev.              0.103993              0.211692          0.035127             0.041115
  Skewness               0.072046              − 0.48875         − 0.34507            0.321746
                                                                                                         enable the analysis of the effects of both positive and negative shocks in
  Kurtosis               1.447337              2.867161          1.510328             1.682264           POGT, GDP, and EC on EF.
  Jarque-Bera            13.37338              5.352266          14.82481             11.82781
  Probability            0.001247              0.068829          0.000604             0.002702           4.3.1. Long-run asymmetric relationship
  Observations           132                   132               132                  132
                                                                                                            The results of the NARDL analysis, presented in Table 6, indicate a
Note. Author’s estimates.                                                                                long-run asymmetric relationship between POGT and EF in Algeria.

                                                                                                     8
B. Bergougui and M.I. Aldawsari                                                                             Journal of Environmental Management 355 (2024) 120426




                                                            Fig. 4. Correlation heatmap.




                                             Fig. 5. The normal quantile-quantile plot for all variables.


Table 6 shows that a positive shock of 1% in POGT leads to a 1.055%           Therefore, both positive and negative shocks in POGT contribute to the
decrease in EF, while a negative shock of 1% in POGT results in a             mitigation of ecological degradation in the long run. Regarding eco­
0.787% reduction in EF. This implies that positive shocks have a more         nomic growth (GDP), the empirical results show that the ecological
pronounced impact than negative shocks on lowering EF levels.                 footprint is positively and asymmetrically related to GDP in Algeria.


                                                                          9
B. Bergougui and M.I. Aldawsari                                                                                                  Journal of Environmental Management 355 (2024) 120426


Table 3
Results of nonlinear BDS test.
  Variables           Dimensions                                                                                                              Results

                      m=2                        m=3                      m=4                      m=5                m=6

  EF                  0.198502***                0.335117***              0.428627***              0.492171***        0.536366***             Rejecting the null hypothesis of linearity
  POGT                0.148719***                0.236504***              0.284548***              0.306975***        0.315456***
  GDP                 0.199475***                0.33622***               0.429974***              0.493962***        0.537479***
  EC                  0.193676***                0.323638***              0.410363***              0.467582***        0.505694***

Notes. The notation ***, **, and * signifies statistical significance at the 1%, 5%, and 10% levels, respectively.



Table 4
Unit root test with structural breaks.
                              At Level

                              Lee-Strazicich (LS)                                                                      Test critical values

                              T-Stat                       Break Points                                                1%                     5%                                 10%

  EF                          − 4.72                       (1996:Q3)                          (2011:Q3)                − 6.23                 − 5.59                             − 5.31
  POGT                        − 2.38                       (1992:Q3)                          (2006:Q4)                − 6.41                 − 5.81                             − 5.54
  GDP                         − 5.58                       (1999:Q3)                          (2005:Q3)                − 6.12                 − 5.46                             − 5.15
  EC                          − 6.64                       (1991:Q1)                          (1995:Q1)                − 6.39                 − 5.70                             − 5.39

                              At First Difference
                                                           Lee-Strazicich (LS)                                                                Test critical values
                              T-Stat                       Break Points                                                1%                     5%                                 10%

  D.(EF)                      − 6.05**                     (2008:Q1)                          (2009:Q4)                − 6.13                 − 5.44                             − 5.18
  D.(POGT)                    − 9.22***                    (2003:Q3)                          (2006:Q2)                − 6.13                 − 5.44                             − 5.18
  D.(GDP)                     − 5.37*                      (2003:Q3)                          (2019:Q1)                − 6.23                 − 5.59                             − 5.30
  D.(EC)                      − 8.86***                    (1994:Q1)                          (1998:Q2)                − 5.85                 − 5.34                             − 5.07

Notes. The notation ***, **, and * signifies statistical significance at the 1%, 5%, and 10% levels, respectively.


                                                                                                    aware of the trade-off between economic growth and ecological sus­
Table 5
                                                                                                    tainability and should consider the destructive ecological consequences
Asymmetric cointegration.
                                                                                                    of positive shocks in GDP. Conversely, they should not be overly con­
  F-Bounds test                                   T-Bounds test                                     cerned about the ecological impact of negative shocks in GDP, as they
  Significance      Lower           Upper         Significance     Lower          Upper             have a negligible effect on the ecological footprint. Regarding energy
  level             bound I         Bound I       level            bound I        Bound I           consumption, the findings indicate that both positive and negative
                    (0)             (1)                            (0)            (1)               shocks to energy consumption have a significant and positive impact on
  10%                 1.99       2.94             10%                − 2.57       − 3.86            the ecological footprint in Algeria. Specifically, a 1% increase in energy
  5%                  2.27       3.28             5%                 − 2.86       − 4.19            consumption leads to a 0.559% increase in ecological footprint, while a
  1%                  2.88       3.99             1%                 − 2.57       − 3.86
                                                                                                    1% decrease in energy consumption results in a 0.475% increase in
  F-statistic (FPSS) = 5.7365***                  t-test (tBDM) = -5.5738***
                                                                                                    ecological footprint. This implies that positive shocks to energy con­
Notes. *, **, and *** indicate 10%, 5%, and 1% significance levels, respectively.                   sumption have a stronger effect on ecological footprint than negative
The tBDM refers to the t-test developed by Banerjee et al. (1998), while the FPSS                   shocks.
stands for the F-test proposed by Pesaran et al. (2001).

                                                                                                    4.3.2. Short run asymmetric relationship
                                                                                                        The results presented in Table 7 indicate that the relationship be­
Table 6
Long-run asymmetric effects: Estimation results.                                                    tween the independent variables and EF remains consistent over both
                                                                                                    the short-run and long-run periods. However, there are differences in the
  Dependent variable = EF
                                                                                                    magnitude of the parameters and their significance levels. In the case of
  Variables                              Coefficient                             Std. Error         the variable POGT, a positive shock is associated with a decrease in
  EFt-1                                  0.148288***                             0.033587           carbon emissions by − 0.0118%, but this effect is not statistically sig­
  POGT positive
       t-1
                                         − 1.055727***                           0.255492           nificant for negative shocks. This suggests that an increase in POGT may
  POGTt-negative
         1
                                         − 0.786851***                           0.075335           reduce EF in the short run. However, GDP has a significant effect on EF
  GDP positive
      t-1
                                         0.182556**                              0.087430           in the short run, regardless of whether there is a positive or negative
  GDP negative
      t-1
                                         0.020895                                0.033929           shock. This implies that changes in economic growth have an immediate
  EC positive
     t-1
                                         0.559821***                             0.133893           impact on the increase of EF. Similarly, EC has a significant effect on EF
  EC negative
     t-1
                                         0.475333***                             0.107972           in the short run. A 1% upsurge in EC led to a 2.7033% increase in EF.
Notes. *, **, and *** denote statistically significant at the 10%, 5%, and 1%
                                                                                                    However, a 1% decline in EC resulted in 2.5306% spurs in EF; both are
levels, respectively.                                                                               significant at a 1% level.
                                                                                                        The post-diagnostic tests conducted on the NARDL model, as shown
                                                                                                    in Table 7, demonstrate that the model is stable and properly specified.
Specifically, a 1% positive shock in GDP leads to a 0.183% rise in
                                                                                                    The Wald test indicates significant asymmetry in the model, suggesting
ecological footprint. However, a negative shock in GDP does not affect
                                                                                                    that positive and negative shocks of the regressors have varying impacts
the ecological footprint significantly. This suggests that GDP is a key
                                                                                                    on EF. The Breusch-Godfrey LM test reveals no serial correlation, and the
driver of ecological footprint and that increasing GDP worsens the
                                                                                                    Breusch/Pagan test indicates no heteroscedasticity among variables.
environmental conditions in Algeria. Therefore, policymakers should be
                                                                                                    The Ramsey test confirms the correct specification of the model. The

                                                                                              10
B. Bergougui and M.I. Aldawsari                                                                                             Journal of Environmental Management 355 (2024) 120426


Table 7                                                                                   Table 8
Estimations of short-run asymmetric relationship.                                         Results of causality tests.
  Dependent variable = EF                                                                   Panel A: results of the Symmetric causality test

  Variables                         Coefficient       Std. Error                            Direction of        Wald test       Bootstrap CV     Bootstrap CV     Bootstrap CV
                                                                                            causality                           10%              5%               1%
  COINTEQ*                          − 0.204713***     0.047119
  POGT positive                     − 0.011707**      0.004766                              POGT ⇒ EF           11.894***       2.78645          5.13945          10.40845
       t-1
  POGTt-negative                    0.003943          0.004838                              GDP⇒ EF             5.912**         3.00145          4.40845          12.09945
                                                                                            EC ⇒ EF             12.94***        2.88345          5.23045          12.44745
         1
  GDP positive                      0.142650**        0.067313
      t-1
  GDP negative                      0.717076***       0.232292                              Panel B: results of the Asymmetric causality test
      t-1
                                    2.703263***       0.128919                              Direction of         Wald test    Bootstrap CV       Bootstrap CV     Bootstrap CV
  EC positive
     t-1
                                                                                              causality                       10%                5%               1%
  EC negative                       2.530638***       0.132377
     t-1
                                                                                            POGT + ⇒ EF þ       12.355***       3.10045          4.70645          8.16545
  Model diagnostic test                                                                     POGT - ⇒ EF -       10.976**        3.03445          4.41245          10.99445
  Test description                  Test Statistics   Results                               GDP þ⇏ EF þ         3.099           4.28745          3.13445          10.64945
  R2                                0.953724          Model denotes a solid fit             GDP -⇏ EF -         2.787           3.16345          4.04445          6.21545
  Wald test                         53.46 ***         The existence of Long-term            EC + ⇒EF þ          11.902**        3.08345          4.58745          14.61045
                                    (0.000)           asymmetry                             EC - ⇏ EF -         2.174           3.17745          4.32945          7.47445
  Jarque–Bera                       0.6029            Normality of the residuals
                                                                                          Note: ⇒ denotes a one-way causal relationship while ⇏ indicates no causal
                                    (0.7398)
                                                                                          relationship. Critical values (CV) are shown for significant levels of 10% (*), 5%
  Breusch-Godfrey Serial            1.4615            Absence of autocorrelation.
    Correlation LM Test (χ 2)       (0.2361)                                              (**), and 1% (***).
  Breusch/Pagan                     1.0717            Absence of
    heteroskedasticity test (χ 2)   (0.3899)          Heteroscedasticity.                 inference that POGT is an important predictor of EF in Algeria aligns
  Ramsey RESET test (F)             0.02918           The specification is
                                                                                          with the concept that POGT can contribute to the advancement of more
                                    (0.8647)          consistent.
                                                                                          effective resource technologies. This shift saves thousands of
Notes. The symbols *, **, and *** are used to indicate statistical significance at        kilowatt-hours of electricity usage and millions of tons of carbon emis­
the 10%, 5%, and 1% levels, respectively.                                                 sions (Matsumoto and Onuma, 2020). The second finding reveals that
                                                                                          there is a one-way symmetric relationship between EC and EF.
stability of the model parameters over time is evaluated by the CUSUM                     Furthermore, there is a one-way asymmetric causality from positive
and CUSUMSQ tests. The CUSUM test plots the cumulative sum of the                         shocks in EC to EF. This means that increasing energy consumption from
residuals. The CUSUMSQ test plots the cumulative sum of the squared                       fossil fuel burning leads to heightened emissions and pollution, exac­
residuals. The model is considered stable if the plots stay within the 95%                erbating issues like climate change. This highlights the need for Algeria
confidence interval. Fig. 6 shows that both the CUSUM and CUSUMSQ                         to transition away from reliance on fossil fuels and toward renewable
plots are inside the intervals, confirming the stability of the NARDL                     energy sources. Potential policies include financial incentives for
model used in this study.                                                                 renewable energy initiatives, investing in innovative renewable tech­
                                                                                          nologies, and improving energy efficiency. These steps could reduce
                                                                                          Algeria’s ecological footprint by decreasing fossil fuel dependence,
4.4. Symmetric and asymmetric causality                                                   aligning with recommendations for other fossil fuel-reliant nations like
                                                                                          Russia (Magazzino et al., 2023). The third result shows that there is a
    The bootstrap causality test by (Hatemi, 2012) which has been                         one-way causal link between GDP and EF. However, the asymmetric
applied in many environmental studies (Baz et al., 2020; Mighri and                       causal links between GDP and EF are insignificant. This reinforces that
AlSaggaf, 2023), is used to examine the symmetric and asymmetric                          GDP currently contributes negatively to ecological sustainability in
causality between the variables. Table 8 shows the results of this test.                  Algeria. Pursuing green growth policies to shift Algeria’s economic
The Wald test statistic of 11.894 at the 1% level indicates a symmetric                   development toward sustainability could help decouple GDP growth
causal relationship between POGT and EF levels. The test also reveals an                  from ecological degradation and reduce the nation’s overall ecological
asymmetric causal link from positive and negative shocks in POGT to EF                    footprint.
levels, with the Wald test statistic of 11.325 and 10.976 being significant
at the 1% and 5% levels, respectively. This implies that POGT affects EF
levels differently, depending on whether it increases or decreases. The




                                                                      Fig. 6. Cusum and CUSUMSQ

                                                                                     11
B. Bergougui and M.I. Aldawsari                                                                                     Journal of Environmental Management 355 (2024) 120426


4.5. Sensitivity analysis                                                             minimizing waste, energy efficiency measures contribute to a significant
                                                                                      reduction in greenhouse gas emissions (Jordaan et al., 2017; Wang and
    This section examines the robustness of the baseline results through              Zhu, 2020); (ii) The development of eco-friendly products and services
several sensitivity analyses reported in Table 9. Specifically, alternative           or the application of carbon capture and storage technologies can
estimation methods (FMOLS, DOLS, and CCR) are employed, the                           mitigate the negative effects of climate change. These strategies have
dependent variable is substituted, and all control variables are dropped.             been supported by previous studies and practical applications, such as
To facilitate comparison, Table 7 baseline results are replicated in Col­             (Wilberforce et al., 2021; Hoxha et al., 2023; Shu et al., 2023; Ramos
umn 1 of Table 9.                                                                     et al., 2024), which have found that they can lower ecological footprint
    The alternative estimation methods of FMOLS, DOLS, and CCR cor­                   levels. Hence, it is vital to integrate green technologies into Algeria’s
rect for endogeneity and serial correlation. As shown in Columns 2–4 of               innovation strategies. Moreover, the advancement of green technologies
Table 9, these methods yield results consistent with the NARDL long-run               in cleaner and more eco-friendly processes can facilitate the exploration
estimates in Column 1 in terms of sign and significance. The one                      of new renewable energy sources. This can reduce the dependence on
exception is that GDP loses statistical significance under FMOLS. Over­               fossil fuels and decrease environmental degradation. The improvement
all, the long-run NARDL estimates with ecological footprint as the                    of green technologies can also foster the development of new energy
dependent variable prove robust. Substituting the dependent variable                  solutions and promote efficient land use and consumption through green
with the natural log of global hectare does not substantially alter the               manufacturing, ultimately leading to a decline in ecological footprint
main results either, as seen in Column 5 of Table 9. The coefficients                 levels (Xu and Lin, 2018; Ibrahim and Vo, 2021). Examples from
remain similar except for two changes: the previously insignificant                   (Ahmad et al., 2020b) illustrate how Germany and France use flue-gas
positive effect of negative GDP shocks on ecological footprint becomes                desulfurization tools and nuclear energy, respectively, to enhance
significant while retaining its positive sign. Finally, dropping all control          environmental quality by lowering greenhouse gas emissions. Similarly,
variables in the NARDL model also leaves the effect of green technolo­                Japan employs both nuclear energy and flue-gas desulfurization tools to
gies on ecological footprint consistent with the baseline, as shown in                improve environmental quality. Furthermore, as noted by (Kirikkaleli
Column 6 of Table 9. This provides further evidence of the robustness of              et al., 2023b), the USA is actively pursuing its green strategy, which
the core results.                                                                     includes efforts to decarbonize transportation, promote electric vehicles,
    In summary, the baseline findings hold up well against a set of                   and implement various renewable energy technologies, collectively
sensitivity tests using alternative estimators and specifications. This               contributing to environmental sustainability commitments. The
strengthens confidence in the main conclusions.                                       observed mitigating effect of green technologies on ecological footprint
                                                                                      is consistent with the findings of several studies conducted by various
5. Discussion                                                                         researchers, such as (Chishti and Sinha, 2022; Javed et al., 2023b;
                                                                                      Behera et al., 2023).
    The discussion section dives deeper into the findings of the out­                     Secondly, the empirical analysis revealed that a positive shock to
comes, juxtaposing them with the stated objectives and offering theo­                 economic growth leads to an acceleration in ecological footprint,
retical and/or empirical justifications for their significance.                       whereas a negative shock does not have any impact. Several factors can
    Firstly, the study demonstrates that any positive or negative shocks              account for this increase in ecological footprint in resource-abundant
to green technologies significantly decrease ecological footprint levels in           economies such as Algeria: (i) Economic growth raises energy de­
Algeria. This aligns with the Report on Climate Change (Pengue et al.,                mand, especially for cheap, abundant fossil fuels like oil and gas.
2023), which recommends radical changes in various aspects of society,                Consequentially, carbon footprint and ecological degradation intensify,
such as switching to low-carbon technologies like renewable energy.                   similar to how oil price rises increased carbon emissions in other oil-rich
Studies indicate that using green technologies can lower greenhouse gas               regions (Hassan and Mhlanga, 2023). (ii) Economic shocks also scale up
emissions, shrink the ecological footprint, encourage efficient land use              consumption of other natural capital like land, water, and forests. This
and consumption through green production, and support environmental                   diminishes biocapacity and biodiversity, aligning with Hassan and
sustainability goals. Furthermore, the use of green products and services             Mhlanga’s (2023) study of asymmetric oil price effects on the ecological
or the implementation of carbon capture and storage technologies can                  footprint of key African oil producers. Similar findings are presented by
help lessen the harm of climate change. To further illuminate this phe­               Elbadri et al. (2023), Bouznit and Pablo-Romero (2016), and Lacheheb
nomenon, the discussion explores two plausible explanations: (i) The                  et al. (2015).
adoption of green technologies that facilitate more efficient energy                      Thirdly, the study found that positive and negative shocks to energy
usage and can reduce ecological footprint levels. Enhancing energy ef­                consumption led to an increase in ecological footprint, with positive
ficiency not only helps in decreasing direct emissions resulting from                 shocks having nearly twice the impact, This is consistent with some
fossil fuel combustion but also indirect emissions stemming from elec­                previous studies (Kartal et al., 2023). This is not surprising, given that
tricity generation processes. By optimizing energy consumption and                    Algeria’s economy is highly dependent on fossil fuels and has a low


Table 9
Sensitivity analysis results.
  Variables           Baseline results   Alternative estimation methods                       Substitution of the dependent variable      Dropping all control variables

                                         FMOLS             DOLS            CCR

                      (1)                (2)               (3)             (4)                (5)                                         (6)

  POGT positive       − 1.055***         − 0.942***        − 0.622**       − 0.602***         − 1.368***                                  − 0.458**
          t-1
  POGTt-negative      − 0.786***         − 0.712**         − 0.582***      − 0.308**          − 0.999**                                   − 0.247***
            1
  GDP positive        0.182**            0.408***          0.963*          0.418**            0.395*                                      /
        t-1
  GDP negative        0.020              0.188*            0.739           0.198**            0.154**                                     /
        t-1
  EC positive         0.559***           0.988***          0.978***        0.938***           0.593**                                     /
     t-1
  EC negative         0.475***           0.798**           0.583**         0.908***           0.573*                                      /
     t-1

Note: The symbols *, **, and *** show the significance levels of 10%, 5%, and 1%, respectively. FMOLS stands for fully modified ordinary least squares; DOLS stands
for dynamic ordinary least squares; CCR stands for canonical cointegrating regression.

                                                                                 12
B. Bergougui and M.I. Aldawsari                                                                               Journal of Environmental Management 355 (2024) 120426


share of renewable energy sources (Bouraiou et al., 2020). Although                the innate nonlinear character of these shocks could produce erroneous
Algeria has abundant natural gas resources, which can reduce the                   inferences. Algeria could leverage these understandings to construct a
depletion of oil and coal, it still needs to import low-quality oil from           basis for its environmental policy system.
neighboring countries such as Nigeria, which can worsen the environ­
mental situation. Therefore, Algeria should seek to diversify its energy           6.2. Policy implication
mix and increase its utilization of renewable energy sources. This would
not only enhance its environmental performance but also lower its                      The study’s discoveries hold substantial relevance not only for
ecological footprint levels. To achieve this goal, the Algerian govern­            shaping economic policies within Algeria but also bear global implica­
ment should implement effective policies to monitor and manage the                 tions for industries, regions, and policymakers. To underscore the
fluctuations in fossil fuel energy levels and to encourage the adoption of         broader significance, the following recommendations are put forth:
low-carbon alternatives such as public transportation and carbon pric­                 Firstly, to reduce ecological footprints, Algeria must invest in green
ing. These strategies are also consistent with the Report on Climate               innovations like renewable energy sources (e.g. wind and solar power)
Change (Wei et al., 2022), which recommends implementing policies                  and technologies that improve energy efficiency. Algeria should elimi­
and technological solutions to reduce carbon emissions and promote the             nate fossil fuel subsidies and replace them with support for low-carbon
use of renewable energy sources. These results are consistent with the             technology, making renewables more cost-competitive. Furthermore,
existing literature that shows that energy use is the main determinant of          Algeria should increase energy efficiency requirements for new build­
ecological degradation in Algeria in the long run (Amri (2017), Awo­               ings and appliances by leveraging green technologies, helping cut global
dumi and Adewuyi (2020), Bélaïd and Youssef (2017), and Chekouri                  energy use and emissions. Additionally, Algeria must raise public
et al. (2020, 2021)). Similar results have been reported for other                 awareness of climate change and the need for emissions reductions to
countries such as Argentina (Adebayo and Rjoub, 2022), Vietnam (Tang               generate political backing for these reforms. Based on this study’s
and Tan, 2015), Turkey (Shan et al., 2021), and Bangladesh (Islam et al.,          findings, Algeria should consider tightening environmental regulations
2023). These studies confirm that the use of energy hurts ecological               to cut carbon footprints. Stricter laws targeting both fossil fuel produc­
sustainability.                                                                    tion and consumption may be needed. However, stricter rules tend to
                                                                                   reduce emissions more effectively in wealthier nations with slower
6. Conclusion and policy implications                                              economic growth, as they can better afford cleaner technologies and
                                                                                   have more to lose from pollution. If Algeria implemented tougher
6.1. Conclusion                                                                    environmental rules, energy and transportation costs would likely rise,
                                                                                   potentially spurring inflation and declining purchasing power while
    A paucity of scholarship exists examining the asymmetrical rela­               causing job losses in key sectors. To curb emissions while supporting
tionship between patents on green technologies and ecological footprint            economic growth, Algeria should pursue balanced environmental pol­
in Algeria. The current study aims to address this gap in the literature by        icies alongside focused support for green innovation. Furthermore, the
investigating how green technologies influence ecological degradation              adoption of supported green technologies can drive sustainable growth,
in Algeria from Q1/1990 to Q4/2022, controlling for energy consump­                create employment opportunities, and contribute to the realization of
tion and economic growth. A novel nonlinear autoregressive distributed             Sustainable Development Goal 8.
lag (NARDL) and bootstrap causality methodologies were employed in                     Secondly, acknowledging Algeria’s historically low and stable elec­
this research. The main benefit of using the NARDL approach is that it             tricity pricing from fossil fuel sources (Bélaïd and Youssef, 2017), it is
can capture the nonlinear and asymmetric effects of the variables, which           recommended to implement carbon pricing policies like cap-and-trade
may not be detected by linear approaches. This is especially important             systems and carbon taxes. These measures can incentivize the shift
when unexpected events can cause instability in the relationships among            away from fossil fuels and encourage the widespread adoption of green
the variables. Moreover, the study examines the robustness of the                  technologies. The generated revenue from such policies can then be
baseline results through several sensitivity analyses. Specifically, alter­        directed towards funding social programs and renewable energy
native estimation methods (FMOLS, DOLS, and CCR) are employed, the                 projects.
dependent variable is substituted, and all control variables are dropped.              Thirdly, Algeria has set ambitious targets for affordable clean energy
The NARDL bound test verifies the presence of long-run equilibrium                 as part of Sustainable Development Goal 7 (SDG 7). The country aims to
relationships between green technologies, economic growth, energy                  derive 27 percent of its electricity generation from renewable sources by
consumption, and ecological footprint in Algeria.                                  2030 and increase its renewable generation capacity to 37 percent by
    The empirical findings of the long-run estimator show that positive            the same year (Haddoum et al., 2018; Haddad et al., 2021). Algeria
and negative shocks in green technologies contribute to the mitigation of          boasts abundant solar potential, with over 3000 h of sunlight annually,
ecological degradation in the long run by lowering ecological footprints,          and is also developing wind, geothermal, and biomass energy sources.
supporting the efficacy of Algeria’s green strategy and environmental              To promote renewable energy development, Algeria has implemented
patenting in spurring industrial transformation. Conversely, only posi­            policies and programs such as feed-in tariffs, tax incentives, and
tive shocks in economic growth were found to negatively impact                     public-private partnerships. However, Algeria faces challenges in
ecological sustainability. A negative shock in economic growth does not            achieving its renewable energy goals, including inadequate grid infra­
significantly affect ecological sustainability. This implies that economic         structure, high investment costs, and low public awareness (UN, 2020).
growth is a crucial driver of ecological footprint, worsening ecological           In terms of climate action under Sustainable Development Goal 13 (SDG
conditions with increasing GDP in Algeria. Additionally, both positive             13), Algeria is one of the most vulnerable countries to climate change in
and negative shocks to energy consumption positively affect Algeria’s              the region (Schilling et al., 2020). The nation faces risks such as
ecological degradation, with positive shocks having a more substantial             desertification, water scarcity, and extreme weather events. Algeria has
effect on ecological footprint than negative shocks. Furthermore, the              submitted its Nationally Determined Contribution (NDC) under the Paris
results of the symmetric and asymmetric causality assessments show                 Agreement, pledging to reduce greenhouse gas emissions by 7 percent
that green technologies, GDP, and energy consumption cause ecological              by 2030 compared to a business-as-usual scenario, or by 22 percent with
footprint levels in Algeria. The baseline findings hold up well against a          international support (Bergougui, 2024). Additionally, Algeria has
set of sensitivity tests using alternative estimators and specifications.          developed a National Climate Plan outlining its adaptation and mitiga­
The results of this study are partially consistent with the empirical              tion strategies in sectors such as energy, agriculture, water, and health.
research perspective, suggesting that the examined variables may                   The country has also participated in regional and international initia­
respond differently to positive and negative disturbances. Overlooking             tives on climate change, including the African Renewable Energy

                                                                              13
B. Bergougui and M.I. Aldawsari                                                                                   Journal of Environmental Management 355 (2024) 120426


Initiative, the Mediterranean Solar Plan, and the Green Climate Fund.             Declaration of competing interest
Despite these efforts, Algeria faces challenges in implementing its
climate action plan, including limited financial and technical resources,             The authors declare that they have no known competing financial
weak institutional capacity, and low public participation (UN, 2020).             interests or personal relationships that could have appeared to influence
    Lastly, the findings show that economic growth has negative impacts           the work reported in this paper.
on ecological sustainability in Algeria. This underscores the necessity of
a balanced strategy centered on regulating growth in an ecologically              Data availability
responsible manner. In particular, supplementing aims for GDP in­
creases with sustainability goals could enable concurrent economic and                Data will be made available on request.
ecological improvements. Aligning environmental priorities may
empower Algerian officials to use positive GDP shocks to considerably             Acknowledgments
advance sustainability. Overall, an integrated approach to coupling
economic progress with ecological protection is imperative.                          The authors extend their appreciation to the Deputyship for Research
                                                                                  & Innovation, “Ministry of Education” in Saudi Arabia for funding this
                                                                                  research work.
6.3. Study limitation and proposal for future study
                                                                                  References
   This study offers important findings on how green technology pat­
ents can help Algeria lower its ecological footprint, but it also has some        Acemoglu, D., Aghion, P., Bursztyn, L., Hemous, D., 2012. The environment and directed
limitations that warrant further investigation. The following research                 technical change. Am. Econ. Rev. 102, 131–166. https://doi.org/10.1257/
                                                                                       aer.102.1.131.
directions could address these gaps:
                                                                                  Adebayo, T.S., Rjoub, H., 2022. A new perspective into the impact of renewable and
                                                                                       nonrenewable energy consumption on environmental degradation in Argentina: a
 • Beyond Patents: This study examined only one dimension of green                     time–frequency analysis. Environ. Sci. Pollut. Res. 29, 16028–16044. https://doi.
                                                                                       org/10.1007/s11356-021-16897-6.
   patents. Other factors such as research expenditure, scientific output,
                                                                                  Adedoyin, F.F., Bekun, F.V., Hossain, M.E., et al., 2023. Glasgow climate change
   and innovation indicators could provide a more comprehensive                        conference (COP26) and its implications in sub-Sahara Africa economies. Renew.
   picture.                                                                            Energy 206, 214–222. https://doi.org/10.1016/j.renene.2023.02.054.
 • Spatial Spillovers: This study analyzed only Algeria’s factors, but            Ahmad, M., Jiang, P., Majeed, A., et al., 2020a. The dynamic impact of natural resources,
                                                                                       technological innovations and economic growth on ecological footprint: an
   green technology and emissions can have cross-border effects                        advanced panel data estimation. Resour Policy 69, 101817. https://doi.org/
   through trade and investment. Special mapping techniques could                      10.1016/j.resourpol.2020.101817.
   reveal how Algeria’s decisions influence the environment in Africa.            Ahmad, M., Khattak, S.I., Khan, A., Rahman, Z.U., 2020b. Innovation, foreign direct
                                                                                       investment (FDI), and the energy–pollution–growth nexus in OECD region: a
 • Green technology Obstacles: Exploring the practical difficulties of                 simultaneous equation modeling approach. Environ. Ecol. Stat. 27, 203–232.
   implementing green technology projects is essential. Understanding                  https://doi.org/10.1007/s10651-020-00442-8.
   why some countries succeed in harnessing green innovation while                Ahmed, Z., Cary, M., Shahbaz, M., Vo, X.V., 2021. Asymmetric nexus between economic
                                                                                       policy uncertainty, renewable energy technology budgets, and environmental
   others face challenges could uncover the barriers to its widespread                 sustainability: evidence from the United States. J. Clean. Prod. 313, 127723 https://
   adoption. This information could inform policies and support                        doi.org/10.1016/j.jclepro.2021.127723.
   mechanisms to speed up the global green transition.                            Amri, F., 2017. Carbon dioxide emissions, output, and energy consumption categories in
                                                                                       Algeria. Environ. Sci. Pollut. Res. 24, 14567–14578. https://doi.org/10.1007/
 • Corporate Carbon Footprints: The fight against climate change re­
                                                                                       s11356-017-8984-7.
   quires attention beyond national boundaries. Investigating green               Anuardo, R.G., Espuny, M., Costa, A.C.F., Oliveira, O.J., 2022. Toward a cleaner and
   innovation and carbon emissions at the corporate level, potentially                 more sustainable world: a framework to develop and improve waste management
                                                                                       through organizations, governments and academia. Heliyon 8, e09225. https://doi.
   contrasting developing and developed economies, could offer valu­
                                                                                       org/10.1016/j.heliyon.2022.e09225.
   able insights into how businesses around the world contribute to or            Awodumi, O.B., Adewuyi, A.O., 2020. The role of non-renewable energy consumption in
   mitigate the environmental crisis.                                                  economic growth and carbon emission: evidence from oil producing economies in
 • Compare and contrast: Developing countries encounter unique                         Africa. Energy Strateg Rev 27, 100434. https://doi.org/10.1016/j.esr.2019.100434.
                                                                                  Aydin, M., Degirmenci, T., 2023. The impact of clean energy consumption, green
   challenges in adopting green technologies. Comparing their inno­                    innovation, and technological diffusion on environmental sustainability: new
   vation patterns with those of more established economies could be                   evidence from load capacity curve hypothesis for 10 European Union countries.
   enlightening.                                                                       Sustain Dev n/a. https://doi.org/10.1002/sd.2794.
                                                                                  Aydin, M., Sogut, Y., Erdem, A., 2024. The role of environmental technologies,
                                                                                       institutional quality, and globalization on environmental sustainability in European
   These research avenues could help overcome these limitations and                    Union countries: new evidence from advanced panel data estimations. Environ. Sci.
enhance the understanding of the complex interplay between green                       Pollut. Res. https://doi.org/10.1007/s11356-024-31860-x.
                                                                                  Banerjee, A., Dolado, J., Mestre, R., 1998. Error-correction mechanism tests for
technology and environmental outcomes. This expanded knowledge will                    cointegration in a single-equation framework. J Time Ser Anal 19, 267–283. https://
be instrumental in devising more effective strategies for a sustainable                doi.org/10.1111/1467-9892.00091.
future, for Algeria and the global community.                                     Baz, K., Xu, D., Ali, H., et al., 2020. Asymmetric impact of energy consumption and
                                                                                       economic growth on ecological footprint: using asymmetric and nonlinear approach.
                                                                                       Sci. Total Environ. 718, 137364 https://doi.org/10.1016/j.scitotenv.2020.137364.
Funding                                                                           Behera, P., Haldar, A., Sethi, N., 2023. Achieving carbon neutrality target in the
                                                                                       emerging economies: role of renewable energy and green technology. Gondwana
                                                                                       Res. 121, 16–32. https://doi.org/10.1016/j.gr.2023.03.028.
   The authors extend their appreciation to the Deputyship for Research           Bélaïd, F., Youssef, M., 2017. Environmental degradation, renewable and non-renewable
& Innovation, “Ministry of Education” in Saudi Arabia for funding this                 electricity consumption, and economic growth: assessing the evidence from Algeria.
research work                                                                          Energy Pol. 102, 277–287. https://doi.org/10.1016/j.enpol.2016.12.012.
                                                                                  Bergougui, B., 2024. Moving toward environmental mitigation in Algeria: asymmetric
                                                                                       impact of fossil fuel energy, renewable energy and technological innovation on CO2
CRediT authorship contribution statement                                               emissions. Energy Strateg Rev 51, 101281. https://doi.org/10.1016/j.
                                                                                       esr.2023.101281.
                                                                                  Bergougui, B., Murshed, S.M., 2023. Aggregate and disaggregate impact of natural
    Brahim Bergougui: Writing – review & editing, Writing – original                   resources on sustainable development: new evidence from the latest institutional
draft, Visualization, Validation, Supervision, Software, Methodology,                  data. Environ Sustain Indic 20, 100302. https://doi.org/10.1016/j.
Investigation, Formal analysis, Data curation, Conceptualization.                      indic.2023.100302.
                                                                                  Boudalia, S., Okoth, S.A., Zebsa, R., 2022. The exploration and exploitation of shale gas
Mohammed Ibrahim Aldawsari: Writing – review & editing, Writing –                      in Algeria: surveying key developments in the context of climate uncertainty. Extr.
original draft, Conceptualization.                                                     Ind. Soc. 11, 101115 https://doi.org/10.1016/j.exis.2022.101115.


                                                                             14
B. Bergougui and M.I. Aldawsari                                                                                                    Journal of Environmental Management 355 (2024) 120426

Boukhelkhal, A, 2022. Impact of economic growth, natural resources and trade on                   Haddoum, S., Bennour, H., Ahmed Zaïd, T., 2018. Algerian energy policy: perspectives,
    ecological footprint: do education and longevity promote sustainable development                   barriers, and missed opportunities. Glob Challenges 2. https://doi.org/10.1002/
    in Algeria? Int. J. Sustain. Dev. World Ecol. 29, 875–887. https://doi.org/10.1080/                gch2.201700134.
    13504509.2022.2112784.                                                                        Hammar, H., Löfgren, Å., 2010. Explaining adoption of end of pipe solutions and clean
Bouraiou, A., Necaibia, A., Boutasseta, N., et al., 2020. Status of renewable energy                   technologies—determinants of firms’ investments for reducing emissions to air in
    potential and utilization in Algeria. J. Clean. Prod. 246, 119011 https://doi.org/                 four sectors in Sweden. Energy Pol. 38, 3644–3651. https://doi.org/10.1016/j.
    10.1016/j.jclepro.2019.119011.                                                                     enpol.2010.02.041.
Bouznit, M., Pablo-Romero, M. del P., 2016. CO2 emission and economic growth in                   Hassan, A.S., Mhlanga, D., 2023. The asymmetric effect of oil price on ecological
    Algeria. Energy Pol. 96, 93–104. https://doi.org/10.1016/j.enpol.2016.05.036.                      footprint: evidence from oil-producing African countries. Sustain Energy Res 10, 16.
Bozatli, O., Akca, H., 2023. The effects of environmental taxes, renewable energy                      https://doi.org/10.1186/s40807-023-00087-8.
    consumption and environmental technology on the ecological footprint: evidence                Hatemi, A., 2012. Asymmetric causality tests with an application. Empir. Econ. 43,
    from advanced panel data analysis. J Environ Manage 345, 118857. https://doi.org/                  447–456.
    10.1016/j.jenvman.2023.118857.                                                                Hatemi, A., 2020. Hidden panel cointegration. J. King Saud Univ. Sci. 32, 507–510.
Broock, WA, Scheinkman, JA, Dechert, WD, LeBaron, B, 1996. A test for independence                     https://doi.org/10.1016/j.jksus.2018.07.011.
    based on the correlation dimension. Econ. Rev. 15, 197–235. https://doi.org/10.108            Hina, M., Chauhan, C., Kaur, P., et al., 2022. Drivers and barriers of circular economy
    0/07474939608800353.                                                                               business models: where we are now, and where we are heading. J. Clean. Prod. 333,
Cantera, S., Tamarit, D., Strong, P.J., et al., 2022. Prospective CO2 and CO bioconversion             130049 https://doi.org/10.1016/j.jclepro.2021.130049.
    into ectoines using novel microbial platforms. Rev Environ Sci Bio/Technology 21,             Hoxha, B., Kuriqi, A., Filkoski, R.V., 2023. Influence of seasonal air density fluctuations
    571–581. https://doi.org/10.1007/s11157-022-09627-y.                                               on wind speed distribution in complex terrains in the context of energy yield.
Chaouachi, M., Balsalobre-Lorente, D., 2022. Environmental strategies for achieving a                  Energy, Ecol Environ. https://doi.org/10.1007/s40974-023-00301-9.
    new foreign direct investment golden decade in Algeria. Environ. Sci. Pollut. Res. 29,        Ibrahim, M., Vo, X.V., 2021. Exploring the relationships among innovation, financial
    37660–37675. https://doi.org/10.1007/s11356-021-18149-z.                                           sector development and environmental pollution in selected industrialized countries.
Chekouri, S.M., Chibi, A., Benbouziane, M., 2023. The impact of natural resource                       J Environ Manage 284, 112057. https://doi.org/10.1016/j.jenvman.2021.112057.
    abundance on ecological footprint: evidence from Algeria. Environ. Sci. Pollut. Res.          Islam, M.M., Shahbaz, M., Sultana, T., et al., 2023. Changes in environmental
    30, 69289–69306. https://doi.org/10.1007/s11356-023-26720-z.                                       degradation parameters in Bangladesh: the role of net savings, natural resource
Chekouri, S.M., Chibi, A., Benbouziane, M., 2020. Examining the driving factors of CO2                 depletion, technological innovation, and democracy. J Environ Manage 343,
    emissions using the STIRPAT model: the case of Algeria. Int. J. Sustain. Energy 39,                118190. https://doi.org/10.1016/j.jenvman.2023.118190.
    927–940. https://doi.org/10.1080/14786451.2020.1770758.                                       Javed, A., Fuinhas, J.A., Rapposelli, A., 2023a. Asymmetric nexus between green
Chekouri, S.M., Chibi, A., Benbouziane, M., 2021. Economic growth, carbon dioxide                      technology innovations, economic policy uncertainty, and environmental
    emissions and energy consumption in Algeria: a wavelet coherence approach. World                   sustainability: evidence from Italy. Energies 16. https://doi.org/10.3390/
    J Sci Technol Sustain Dev 18, 172–189. https://doi.org/10.1108/WJSTSD-12-2020-                     en16083557.
    0097.                                                                                         Javed, A., Rapposelli, A., Khan, F., Javed, A., 2023b. The impact of green technology
Cheng, C., Ren, X., Dong, K., et al., 2021. How does technological innovation mitigate                 innovation, environmental taxes, and renewable energy consumption on ecological
    CO2 emissions in OECD countries? Heterogeneous analysis using panel quantile                       footprint in Italy: fresh evidence from novel dynamic ARDL simulations. Technol.
    regression. J Environ Manage 280, 111818. https://doi.org/10.1016/j.                               Forecast. Soc. Change 191, 122534. https://doi.org/10.1016/j.
    jenvman.2020.111818.                                                                               techfore.2023.122534.
Chishti, M.Z., Sinha, A., 2022. Do the shocks in technological and financial innovation           Jiakui, C., Abbas, J., Najam, H., et al., 2023. Green technological innovation, green
    influence the environmental quality? Evidence from BRICS economies. Technol. Soc.                  finance, and financial development and their role in green total factor productivity:
    68, 101828 https://doi.org/10.1016/j.techsoc.2021.101828.                                          empirical insights from China. J. Clean. Prod. 382, 135131 https://doi.org/10.1016/
Chu, L.K., 2022. The impact of informal economy on technological innovation–ecological                 j.jclepro.2022.135131.
    footprint nexus in OECD countries: new evidence from panel quantile regression.               Jordaan, S.M., Romo-Rabago, E., McLeary, R., et al., 2017. The role of energy technology
    J Environ Stud Sci 12, 515–533. https://doi.org/10.1007/s13412-022-00756-y.                        innovation in reducing greenhouse gas emissions: a case study of Canada. Renew.
Chunling, L., Memon, J.A., Thanh, T Le, et al., 2021. The impact of public-private                     Sustain. Energy Rev. 78, 1397–1409. https://doi.org/10.1016/j.rser.2017.05.162.
    partnership investment in energy and technological innovation on ecological                   Kartal, M.T., Depren, S.K., Kirikkaleli, D., et al., 2022. Asymmetric and long-run impact
    footprint: the case of Pakistan. Sustainability 13, 10085. https://doi.org/10.3390/                of political stability on consumption-based carbon dioxide emissions in Finland:
    su131810085.                                                                                       evidence from nonlinear and Fourier-based approaches. J Environ Manage 321,
Danish, Baloch, MA, Mahmood, N, Zhang, JW, 2019. Effect of natural resources,                          116043. https://doi.org/10.1016/j.jenvman.2022.116043.
    renewable energy and economic development on CO2 emissions in BRICS countries.                Kartal, M.T., Pata, U.K., Kılıç Depren, S., Depren, Ö., 2023. Effects of possible changes in
    Sci. Total Environ. 678, 632–638. https://doi.org/10.1016/j.scitotenv.2019.05.028.                 natural gas, nuclear, and coal energy consumption on CO2 emissions: evidence from
Destek, M.A., Manga, M., 2021. Technological innovation, financialization, and                         France under Russia’s gas supply cuts by dynamic ARDL simulations approach. Appl.
    ecological footprint: evidence from BEM economies. Environ. Sci. Pollut. Res. 28,                  Energy 339, 120983. https://doi.org/10.1016/j.apenergy.2023.120983.
    21991–22001. https://doi.org/10.1007/s11356-020-11845-2.                                      Kazemzadeh, E., Lotfalipour, M.R., Shirazi, M., Sargolzaie, A., 2023. Heterogeneous
EIA, 2023. U.S. Energy Information Administration Publication 2023.                                    effects of energy consumption structure on ecological footprint. Environ. Sci. Pollut.
Elbadri, M., Bsikre, S., Alamari, O., Balcilar, M., 2023. Nexus between renewable energy               Res. 30, 55884–55904. https://doi.org/10.1007/s11356-023-26118-x.
    consumption, economic growth, and CO 2 emissions in Algeria: new evidence from                Khan, I, Hou, F, Le, HP, 2021. The impact of natural resources, energy consumption, and
    the Fourier-Bootstrap ARDL approach. Nat. Resour. Forum 47, 393–412. https://doi.                  population growth on environmental quality: Fresh evidence from the United States
    org/10.1111/1477-8947.12292.                                                                       of America. Sci. Total Environ. 754, 142222. https://doi.org/10.1016/j.scitotenv.20
Epule, T.E., Chehbouni, A., Dhiba, D., et al., 2021. African climate change policy                     20.142222.
    performance index. Environ Sustain Indic 12, 100163. https://doi.org/10.1016/j.               Kihombo, S., Ahmed, Z., Chen, S., et al., 2021. Linking financial development, economic
    indic.2021.100163.                                                                                 growth, and ecological footprint: what is the role of technological innovation? Env
Furuoka, F., 2017. Renewable electricity consumption and economic development: new                     Sci Pollut Res. https://doi.org/10.1007/s11356-021-14993-1.
    findings from the Baltic countries. Renew. Sustain. Energy Rev. 71, 450–463.                  Kirikkaleli, D., Abbasi, K.R., Oyebanji, M.O., 2023a. The asymmetric and long-run effect
    https://doi.org/10.1016/j.rser.2016.12.074.                                                        of environmental innovation and CO2 intensity of GDP on consumption-based CO2
Granger, C.W.J., Yoon, G., 2002. Hidden Cointegration. SSRN Electron J. https://doi.                   emissions in Denmark. Environ. Sci. Pollut. Res. 30, 50110–50124. https://doi.org/
    org/10.2139/ssrn.313831.                                                                           10.1007/s11356-023-25811-1.
Grossman, G.M., Krueger, A.B., 1991. Environmental Impacts of a North American Free               Kirikkaleli, D., Sofuoğlu, E., Ojekemi, O., 2023b. Does patents on environmental
    Trade Agreement. National Bureau of Economic Research, Cambridge, MA.                              technologies matter for the ecological footprint in the USA? Evidence from the novel
Guliyev, H., 2024. Determinants of ecological footprint in European countries: fresh                   Fourier ARDL approach. Geosci. Front. 14, 101564 https://doi.org/10.1016/j.
    insight from Bayesian model averaging for panel data analysis. Sci. Total Environ.                 gsf.2023.101564.
    912, 169455 https://doi.org/10.1016/j.scitotenv.2023.169455.                                  Lacheheb, M., Rahim, A.S.A., Sirag, A., 2015. Economic growth and carbon dioxide
Gupta, S, Jha, B, Singh, RK, 2022. Decision making framework for foreign direct                        emissions: investigating the environmental kuznets curve hypothesis in Algeria. Int J
    investment: Analytic hierarchy process and weighted aggregated sum product                         Energy Econ Policy 5, 1125–1132.
    assessment integrated approach. J. Publ. Aff. 22. https://doi.org/10.1002/pa.2771.            León, L.R., Bergquist, K., Wunsch-Vincent, S., et al., 2017. Measuring innovation in
Gyamfi, B.A., Agozie, D.Q., Musah, M., et al., 2023. The synergistic roles of green                    energy technologies: green patents as captured by WIPO’s IPC green inventory.
    openness and economic complexity in environmental sustainability of Europe’s                       WIPO. 44.
    largest economy: implications for technology-intensive and environmentally friendly           Magazzino, C, Mele, M, Drago, C, et al., 2023. The trilemma among CO2 emissions,
    products. Environ. Impact Assess. Rev. 102, 107220 https://doi.org/10.1016/j.                      energy use, and economic growth in Russia. Sci. Rep. 13, 10225. https://doi.
    eiar.2023.107220.                                                                                  org/10.1038/s41598-023-37251-5.
Habiba, U., Xinbang, C., Ali, S., 2023. Investigating the impact of financial development         Matsumoto, S., Onuma, H., 2020. Measuring household ability to adopt new technology:
    on carbon emissions: does the use of renewable energy and green technology really                  the case of light-emitting diodes (LEDs). J. Clean. Prod. 277, 123323 https://doi.
    contribute to achieving low-carbon economies? Gondwana Res. 121, 472–485.                          org/10.1016/j.jclepro.2020.123323.
    https://doi.org/10.1016/j.gr.2023.05.013.                                                     Mighri, Z., AlSaggaf, M.I., 2023. Asymmetric impacts of renewable energy consumption
Haddad, B., Díaz-Cuevas, P., Ferreira, P., et al., 2021. Mapping concentrated solar power              and economic complexity on economic growth in Saudi Arabia: evidence from the
    site suitability in Algeria. Renew. Energy 168, 838–853. https://doi.org/10.1016/j.                NARDL model. Environ. Sci. Pollut. Res. 30, 7446–7473. https://doi.org/10.1007/
    renene.2020.12.081.                                                                                s11356-022-22718-1.




                                                                                             15
B. Bergougui and M.I. Aldawsari                                                                                                     Journal of Environmental Management 355 (2024) 120426

Nyiwul, L., 2021. Innovation and adaptation to climate change: evidence from the water             Sharif, A., Baris-Tuzemen, O., Uzuner, G., et al., 2020. Revisiting the role of renewable
    sector in Africa. J. Clean. Prod. 298, 126859 https://doi.org/10.1016/j.                            and non-renewable energy consumption on Turkey’s ecological footprint: evidence
    jclepro.2021.126859.                                                                                from Quantile ARDL approach. Sustain. Cities Soc. 57, 102138 https://doi.org/
Nyiwul, L., 2017. Economic performance, environmental concerns, and renewable                           10.1016/j.scs.2020.102138.
    energy consumption: drivers of renewable energy development in Sub-Sahara Africa.              Sharif, A., Raza, S.A., Ozturk, I., Afshan, S., 2019. The dynamic relationship of renewable
    Clean Technol. Environ. Policy 19, 437–450. https://doi.org/10.1007/s10098-016-                     and nonrenewable energy consumption with carbon emission: a global study with
    1229-5.                                                                                             the application of heterogeneous panel estimations. Renew. Energy 133. https://doi.
Pengue, W.A., Verdolini, E., Burch, S., et al., 2023. Innovation, technology development                org/10.1016/j.renene.2018.10.052.
    and transfer. In: Climate Change 2022 - Mitigation of Climate Change. Cambridge                Shehzad, K., Zeraibi, A., Zaman, U., 2022. Testing the N-shaped environmental Kuznets
    University Press, pp. 1641–1726.                                                                    Curve in Algeria: an imperious role of natural resources and economic globalization.
Pesaran, M.H., Shin, Y., Smith, R.J., 2001. Bounds testing approaches to the analysis of                Resour Policy 77, 102700. https://doi.org/10.1016/j.resourpol.2022.102700.
    level relationships. J. Appl. Econom. 16, 289–326. https://doi.org/10.1002/jae.616.            Shin, Y., Yu, B., Greenwood-Nimmo, M., 2014. In: Sickles, R.C., Horrace, W.C. (Eds.),
Rafique, M.Z., Nadeem, A.M., Xia, W., et al., 2022. Does economic complexity matter for                 Modelling Asymmetric Cointegration and Dynamic Multipliers in a Nonlinear ARDL
    environmental sustainability? Using ecological footprint as an indicator. Environ.                  Framework BT - Festschrift in Honor of Peter Schmidt: Econometric Methods and
    Dev. Sustain. 24, 4623–4640. https://doi.org/10.1007/s10668-021-01625-4.                            Applications. Springer New York, New York, NY, pp. 281–314.
Rahmane, A, Benelbar, M, Traich, M, 2021. The Nexus between sustainable energy and                 Shu, D.Y., Deutz, S., Winter, B.A., et al., 2023. The role of carbon capture and storage to
    ecological footprint: evidence from Algeria. Sustain. Sci. Pract. Pol. 17, 323–333.                 achieve net-zero energy systems: trade-offs between economics and the
    https://doi.org/10.1080/15487733.2021.1946298.                                                      environment. Renew. Sustain. Energy Rev. 178, 113246 https://doi.org/10.1016/j.
Ramos, H.M., Sintong, J.E., Kuriqi, A., 2024. Optimal integration of hybrid pumped                      rser.2023.113246.
    storage hydropower toward energy transition. Renew. Energy 221, 119732. https://               Sun, Y., Razzaq, A., Sun, H., Irfan, M., 2022. The asymmetric influence of renewable
    doi.org/10.1016/j.renene.2023.119732.                                                               energy and green innovation on carbon neutrality in China: analysis from non-linear
Razzaq, A., Sharif, A., Afshan, S., Li, C.J., 2023. Do climate technologies and recycling               ARDL model. Renew. Energy 193, 334–343. https://doi.org/10.1016/j.
    asymmetrically mitigate consumption-based carbon emissions in the United States?                    renene.2022.04.159.
    New insights from Quantile ARDL. Technol. Forecast. Soc. Change 186, 122138.                   Sun, Z., Sun, X., Wang, W., Wang, W., 2023. Source reduction strategy or end-of-pipe
    https://doi.org/10.1016/j.techfore.2022.122138.                                                     solution? The impact of green merger and acquisition on environmental investment
Razzaq, A., Sharif, A., Ahmad, P., Jermsittiparsert, K., 2021a. Asymmetric role of tourism              strategy of Chinese heavily polluting enterprises. J. Clean. Prod. 413, 137530
    development and technology innovation on carbon dioxide emission reduction in the                   https://doi.org/10.1016/j.jclepro.2023.137530.
    Chinese economy: fresh insights from QARDL approach. Sustain. Dev. 29, 176–193.                Tang, C.F., Tan, B.W., 2015. The impact of energy consumption, income and foreign
    https://doi.org/10.1002/sd.2139.                                                                    direct investment on carbon dioxide emissions in Vietnam. Energy 79, 447–454.
Razzaq, A., Wang, Y., Chupradit, S., et al., 2021b. Asymmetric inter-linkages between                   https://doi.org/10.1016/j.energy.2014.11.033.
    green technology innovation and consumption-based carbon emissions in BRICS                    Ullah, S., Ozturk, I., Majeed, M.T., Ahmad, W., 2021. Do technological innovations have
    countries using quantile-on-quantile framework. Technol. Soc. 66, 101656 https://                   symmetric or asymmetric effects on environmental quality? Evidence from Pakistan.
    doi.org/10.1016/j.techsoc.2021.101656.                                                              J. Clean. Prod. 316, 128239 https://doi.org/10.1016/j.jclepro.2021.128239.
Rout, S.K., Gupta, M., Sahoo, M., 2022. The role of technological innovation and                   UN, 2020. United Nations 2020 Algeria Annual Report. United Nations.
    diffusion, energy consumption and financial development in affecting ecological                Wackernagel, M., Rees, W., 1998. Our Ecological Footprint: Reducing Human Impact on
    footprint in BRICS: an empirical analysis. Environ. Sci. Pollut. Res. 29,                           the Earth. New society publishers.
    25318–25335. https://doi.org/10.1007/s11356-021-17734-6.                                       Wang, F., Harindintwali, J.D., Yuan, Z., et al., 2021. Technologies and perspectives for
Sahoo, M., Sethi, N., 2022. The dynamic impact of urbanization, structural                              achieving carbon neutrality. Innovation 2, 100180. https://doi.org/10.1016/j.
    transformation, and technological innovation on ecological footprint and PM2.5:                     xinn.2021.100180.
    evidence from newly industrialized countries. Environ. Dev. Sustain. 24, 4244–4277.            Wang, J., Usman, M., Saqib, N., et al., 2023a. Asymmetric environmental performance
    https://doi.org/10.1007/s10668-021-01614-7.                                                         under economic complexity, globalization and energy consumption: evidence from
Saqib, N., Dincă, G., 2023. Exploring the asymmetric impact of economic complexity,                    the World’s largest economically complex economy. Energy 279, 128050. https://
    FDI, and green technology on carbon emissions: policy stringency for clean-energy                   doi.org/10.1016/j.energy.2023.128050.
    investing countries. Geosci. Front., 101671 https://doi.org/10.1016/j.                         Wang, Q., Zhang, F., Li, R., Li, L., 2022. The impact of renewable energy on decoupling
    gsf.2023.101671.                                                                                    economic growth from ecological footprint – an empirical analysis of 166 countries.
Saqib, N., Ozturk, I., Usman, M., 2023. Investigating the implications of technological                 J. Clean. Prod. 354, 131706 https://doi.org/10.1016/j.jclepro.2022.131706.
    innovations, financial inclusion, and renewable energy in diminishing ecological               Wang, R., Usman, M., Radulescu, M., et al., 2023b. Achieving ecological sustainability
    footprints levels in emerging economies. Geosci. Front. 14, 101667 https://doi.org/                 through technological innovations, financial development, foreign direct
    10.1016/j.gsf.2023.101667.                                                                          investment, and energy consumption in developing European countries. Gondwana
Saqib, N., Usman, M., Ozturk, I., Sharif, A., 2024. Harnessing the synergistic impacts of               Res. 119, 138–152. https://doi.org/10.1016/j.gr.2023.02.023.
    environmental innovations, financial development, green growth, and ecological                 Wang, Z., Zhu, Y., 2020. Do energy technology innovations contribute to CO2 emissions
    footprint through the lens of SDGs policies for countries exhibiting high ecological                abatement? A spatial perspective. Sci. Total Environ. 726, 138574 https://doi.org/
    footprints. Energy Pol. 184, 113863 https://doi.org/10.1016/j.enpol.2023.113863.                    10.1016/j.scitotenv.2020.138574.
Schilling, J., Hertig, E., Tramblay, Y., Scheffran, J., 2020. Climate change vulnerability,        WDI (2023) World development indicators 2023. https://databank.worldbank.org.
    water resources and social implications in North Africa. Reg Environ Chang 20, 15.             Wei, Y., De La Vega Navarro, A., Garg, A., et al., 2022. Climate Change 2022: Mitigation
    https://doi.org/10.1007/s10113-020-01597-7.                                                         of Climate Change - Energy Systems.
Shabir, M., Pazienza, P., De Lucia, C., 2023. Energy innovation and ecological footprint:          Wilberforce, T., Olabi, A.G., Sayed, E.T., et al., 2021. Progress in carbon capture
    evidence from OECD countries during 1990–2018. Technol. Forecast. Soc. Change                       technologies. Sci. Total Environ. 761, 143203 https://doi.org/10.1016/j.
    196, 122836. https://doi.org/10.1016/j.techfore.2023.122836.                                        scitotenv.2020.143203.
Shahbaz, M., Raghutla, C., Song, M., et al., 2020. Public-private partnerships investment          Xia, A., Liu, Q., 2024. Modelling the asymmetric impact of fintech, natural resources, and
    in energy as new determinant of CO2 emissions: the role of technological                            environmental regulations on ecological footprint in G7 countries. Resour Policy 89,
    innovations in China. Energy Econ. 86, 104664 https://doi.org/10.1016/j.                            104552. https://doi.org/10.1016/j.resourpol.2023.104552.
    eneco.2020.104664.                                                                             Xie, X., Hoang, T.T., Zhu, Q., 2022. Green process innovation and financial performance:
Shahbaz, M., Shafiullah, M., Papavassiliou, V.G., Hammoudeh, S., 2017. The CO 2                         the role of green social capital and customers’ tacit green needs. J Innov Knowl 7,
    –growth nexus revisited: a nonparametric analysis for the G7 economies over nearly                  100165. https://doi.org/10.1016/j.jik.2022.100165.
    two centuries. Energy Econ. 65, 183–193. https://doi.org/10.1016/j.                            Xu, B., Lin, B., 2018. Investigating the role of high-tech industry in reducing China’s CO2
    eneco.2017.05.007.                                                                                  emissions: a regional perspective. J. Clean. Prod. 177, 169–177. https://doi.org/
Shahzad, U., Fareed, Z., Shahzad, F., Shahzad, K., 2021. Investigating the nexus between                10.1016/j.jclepro.2017.12.174.
    economic complexity, energy consumption and ecological footprint for the United                Yu, H., Xu, J., Hu, H., et al., 2023. How does green technology innovation influence
    States: new insights from quantile methods. J. Clean. Prod. 279, 123806 https://doi.                industrial structure? Evidence of heterogeneous environmental regulation effects.
    org/10.1016/j.jclepro.2020.123806.                                                                  Environ. Dev. Sustain. https://doi.org/10.1007/s10668-023-03369-9.
Shan, S., Genç, S.Y., Kamran, H.W., Dinca, G., 2021. Role of green technology innovation           Zafar, MW, Zaidi, SAH, Khan, NR, et al., 2019. The impact of natural resources, human
    and renewable energy in carbon neutrality: a sustainable investigation from Turkey.                 capital, and foreign direct investment on the ecological footprint: The case of the
    J Environ Manage 294, 113004. https://doi.org/10.1016/j.jenvman.2021.113004.                        United States. Resour. Pol. 63, 101428. https://doi.org/10.1016/j.resourpol.20
                                                                                                        19.101428.




                                                                                              16
