# Progress log

## Step 2: paper extraction (2026-09-28)

25 summaries written (summaries/P01.md to P25.md), all 14 sections present in each.
P01, P03, P06, P07, P15 to P18, P20, P22 to P25 were extracted from the PDFs; the rest from the Markdown conversions.

### NOT REPORTED items

201 items across the 25 summaries, grouped by paper. "(none used)" marks items the summary gives as not part of the design.

### P01

- Variables: moderators or mediators (none used; "none specified").
- Main results: point coefficients for the main MQQKRLS estimates; results shown only as heatmaps with significance asterisks (Figs. 5-7).
- Main results: threshold values; threshold behavior described only in words, no value estimated.
- Heterogeneity: asymmetry in positive versus negative changes (partial sums); the paper's "asymmetry" means differences across quantiles and countries.

### P02

- Data: the word "annual" for the panel frequency (annual is implied by year fixed effects and 580 obs. = 29 x 20).
- Variables: source of the R&D expenditure data (Table 4 col. 5).
- Variables: source of the non-AI patent counts for the placebo test (Table 5 col. 4).
- Variables: data source of labor structure (LS).
- Variables: source of the distance data for the instrument.
- Methods: panel unit root, cross-sectional dependence, Hausman, Granger or other causality tests, System GMM diagnostics (AR, Hansen/Sargan), marginal effects or turning points for the interaction models ("not used or not reported").
- Main results: short-run coefficients (only FMOLS long run shown).
- Main results: threshold values of LS or INST at which the AI effect changes sign.
- Heterogeneity: asymmetry or quantile methods (none used).
- Causality: Granger or other causality tests (none used).
- Causality: statistic of the under-identification test, which the text says confirms identification.
- Extraction notes: System GMM AR(1)/AR(2) and Hansen/Sargan diagnostics.
- Extraction notes: how the US observation is handled in the IV (the US is in the sample and in the instrument).

### P03

- Variables: source of CO2_PC.
- Variables: source of PEI (primary energy intensity).
- Variables: source of labor composition (LC).
- Variables: sources of Ln(CO2/GDP), Ln(Total CO2), Ln(EF), Ln(GHG) (Table 3).
- Variables: source of the R&D data for R&D-weighted AIP (Table 3 col. 7).
- Variables: source of non-AI patents (Table 4 col. 6).
- Variables: source of the distance data for IV1.
- Methods: unit root, cross-sectional dependence, slope homogeneity and cointegration tests.
- Heterogeneity: quantile methods (none used).
- Robustness: exact placebo mean or share significant in the 500-simulation temporal placebo.

### P04

- Data: number of observations per country.
- Variables: moderators or mediators (none used as estimated variables); energy consumption, income and FDI are called "moderating variables" (p. 8) but no moderation estimates are given; four mechanisms are described but not tested.
- Variables: lag length of the lagged AI instrument.
- Main results: control variable estimates (GDP, FDI, EC).
- Heterogeneity: formal threshold estimates; stage boundaries given only as quantile ranges.
- Robustness: instrument strength or validity statistics for IVMQR.
- Causality: causality test, such as Granger causality in quantiles (none used).
- Extraction notes: transformation or scaling of Table 2 values (AI means 0.646 to 1.058 although measured as "Count"; EQ means 0.011 to 0.156).

### P05

- Data: number of observations.
- Variables: mediators (none used; no mediation analysis).
- Heterogeneity: asymmetry (positive/negative shocks).
- Heterogeneity: threshold values (for example a turning point of PRO).
- Causality: causality test (none used); authors recommend quasi-experimental designs for future work.

### P06

- Data: list of the 50 countries.
- Data: frequency not stated explicitly (N = 1250 in Tables 2, 4, 6).
- Data: panel balance.
- Variables: definition and source of the alternative dependent variable LCF (Table 3 col. 5).
- Variables: exact construction and data source of INDSU/INDUS.
- Variables: source of the distance-to-Japan data.
- Variables: source of trade intensity (trade-to-GDP).
- Variables: source of GVC participation.
- Variables: classification criteria and sources for income level, digital infrastructure and population groups (Table 9).
- Variables: sources of all controls (Table 1).
- Methods: instrument used in IV-GMM.
- Methods: first-stage and instrument validity tests for IV-GMM.
- Methods: unit root, cointegration and cross-sectional dependence tests.
- Heterogeneity: full membership of the "near Japan" group (only South Korea, Taiwan, Singapore named).
- Heterogeneity: asymmetry and quantile methods (none used).
- Robustness: instrument for IV-GMM (INRO 0.038***, N 1200).
- Causality: instrument, first-stage, overidentification or weak-instrument statistics, although the authors claim a causal interpretation.

### P07

- Data: list of the 13 MENA countries (examples named: Algeria, Saudi Arabia, Yemen, Egypt, Tunisia, Türkiye, UAE).
- Variables: moderators or mediators (none used).
- Methods: number of GMM instruments.
- Methods: AR(1) test.
- Methods: one-step or two-step GMM, and use of the Windmeijer correction.
- Methods: unit root, cointegration or cross-sectional dependence tests.
- Heterogeneity: asymmetry analysis.
- Heterogeneity: quantile analysis.
- Heterogeneity: threshold analysis.
- Heterogeneity: country-level or subgroup heterogeneity.
- Robustness: robustness checks (none used); the outline says Section 5 does robustness, but Section 5 is "Discussion" with no robustness estimates; only Hansen J and AR(2) diagnostics.
- Causality: causality tests (none used); endogeneity handled through system GMM.

### P08

- Variables: moderators or mediators.
- Methods: NARDL lag selection criterion, software, and dynamic multipliers.
- Main results: short-run NARDL coefficients (only the short-run asymmetry Wald test is shown).
- Robustness: break dummies in the NARDL model (the LS test finds break dates).
- Causality: reverse direction (CO2 to regressors).

### P09

- Variables: moderators or mediators (none used).
- Methods: NARDL lag lengths and lag selection criterion (HJC is in the acronym list, but its use is not described).
- Methods: number of bootstrap replications in the causality test.
- Heterogeneity: variable-specific and short-run asymmetry tests (only the long-run Wald test, 53.46***, is shown).
- Heterogeneity: dynamic multipliers.
- Heterogeneity: quantile or subsample heterogeneity (none used; not part of the design).
- Robustness: standard errors for Table 9.
- Causality: reverse direction (EF to regressors).

### P10

- Data: number of observations.
- Variables: source for total CO2 (alternative dependent variable).
- Variables: exact patent classification for GT.
- Variables: moderators or mediators (none used).
- Main results: EKC turning point.
- Main results: short-run coefficients (no short-run or error correction table).
- Heterogeneity: quantile or threshold results (none used).
- Heterogeneity: subsample or regime heterogeneity.

### P11

- Data: method used to convert annual data to quarterly.
- Data: number of observations (not in Table 1 or Table 5).
- Variables: source of the alternative dependent variable (log of ecological footprint).
- Variables: source of the material footprint data used for MRE.
- Variables: patent office or counting basis for ENT.
- Variables: definitions and sources of EPU and PS beyond the table note.
- Variables: moderators or mediators (none used).
- Main results: short-run NARDL coefficients and error correction term.
- Heterogeneity: per-variable Wald tests (only one joint Wald statistic).
- Heterogeneity: quantile or threshold results (none used).
- Heterogeneity: subgroup or regional heterogeneity (none used; single country).
- Robustness: CUSUM and CUSUMSQ stability tests, although the text calls the model "well-specified and stable".

### P12

- Data: method used to convert annual series to quarterly.
- Variables: source of the alternative dependent variable EF per capita (Table 9 col. 5), not given separately.
- Main results: short-run coefficients.
- Heterogeneity: whole section (none used); symmetric single-country Fourier ARDL, no asymmetric, quantile or threshold estimates; the only conditional effect is the GT*FD interaction.
- Causality: reverse direction tests (EF to X).

### P13

- Data: method used to obtain quarterly data from annual sources.
- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: lag selection criterion, software, short-run coefficients, and CUSUM or CUSUMSQ stability tests.
- Robustness: alternative estimators (for example quantile ARDL, threshold models), alternative EF measures, or subsample checks.
- Causality: reverse direction (EF to rents).

### P14

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: software.
- Heterogeneity: formal asymmetry test (Wald test of equal positive and negative effects).
- Heterogeneity: country-level heterogeneity estimates (only descriptive country examples in Section 6).

### P15

- Citation: issue number.
- Data: method used to convert annual source data to monthly.
- Methods: MQQR bandwidth value.
- Methods: lag length of the lagged AI instrument in IVQR.
- Main results: control variable coefficients (GDP, POP, FDI, EC).
- Main results: long-run versus short-run split (not applicable).

### P16

- Data: number of observations.
- Variables: sources of the tariff and Economic Freedom instrument data.
- Main results: threshold values of income inequality in levels (given only as quantile positions).
- Main results: coefficients of the controls (INST, GDP, EC, POP).
- Causality: numerical test statistics and p-values (shown only in Fig. 7 against a 5 % critical value line).
- Extraction notes: whether MQQR/WQR use levels or first differences (QADF shows stationarity only after first differencing).

### P17

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Variables: controls (none used; the model has only IQ and income).
- Methods: unit root, cointegration and nonlinearity (e.g. BDS) tests.
- Heterogeneity: numerical threshold values (turning points given only as quantile positions).
- Robustness: alternative IQ or CE-I measures, subsamples, or alternative bandwidths.
- Causality: Japan results not described in the text (only in Table 3).

### P18

- Citation: volume, issue and page numbers (online-first PDF).
- Data: list of the 41 countries.
- Data: split between developed and developing countries.
- Data: the word "annual" (implied by the year range).
- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: software (Figs. 1 and 2 look Stata-style, but no software is named).
- Main results: short-run versus long-run split (only the single lag-1 PVAR equation is reported).
- Heterogeneity: developed versus developing subsample results (sample pooled despite the title).
- Heterogeneity: asymmetry (none used; listed as future research).
- Heterogeneity: quantile results.
- Heterogeneity: numerical impulse response values in the text (only plotted).
- Robustness: a separate heterogeneous causality test (for example Dumitrescu-Hurlin) in the body.
- Robustness: alternative estimators, alternative CEI or ENT measures, or subsample re-estimation.

### P19

- Variables: moderators or mediators (none used; no interaction or mediation terms in either model).
- Heterogeneity: subgroup or regional heterogeneity (income groups, regions).
- Robustness: robustness checks (none used); no alternative estimator, index, subsample or sensitivity analysis.
- Causality: causality test (none used); Section 3.2 claims "bidirectional causal links" between ETI and REI, resting only on the two MM-QR models.

### P20

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Heterogeneity: formal Wald test of asymmetry.
- Heterogeneity: subsample heterogeneity (regional, city size, resource type).
- Robustness: robustness checks (none used); the Dumitrescu-Hurlin test is a final phase, not a robustness check.
- Limitations: no explicit limitations section; only future directions are stated.
- Extraction notes: number of observations, software, bootstrap or standard error method, and chosen DH lag length.

### P21

- Data: full-sample N (subsample regressions in Table 9 report N = 1224 per column).
- Variables: units of GDP, TNRR, TO, RE, INDS, POP, GP, HC.
- Causality: Granger or other formal causality test (none used).
- Limitations: no limitations section and no future research agenda.
- Extraction notes: transformation used for IQ (Eq. 3 uses ln IQ, but IQ has negative values, min -0.466).

### P22

- Data: the word "annual" (implied by 560 obs. = 20 x 28).
- Variables: moderators or mediators (none used; no interaction or mediation terms).
- Heterogeneity: asymmetric (positive versus negative shock) decomposition and country-group split (none used; quantile heterogeneity is the core design).
- Robustness: control variable coefficients in the robustness models (only "Controls Yes").
- Causality: RDD (storage) causality (not in Table 8).

### P23

- Data: number of observations per country.
- Data: whether any frequency conversion or interpolation was applied.
- Data: descriptive statistics for GDP and EC.
- Variables: exact WDI indicator codes and units for GDP and EC.
- Methods: m-QQR bandwidth h value.
- Robustness: first-stage strength or instrument validity tests for IVMQR.
- Causality: Granger or other causality test (none used); the IVMQR check is presented as strengthening "the causal interpretation".

### P24

- Variables: source databases for the ENV sub-indicators (only "multiple integrated databases").
- Variables: exact formula and source of the mediator IST.
- Variables: definitions, units and data sources of the controls.
- Variables: definitions and cut-offs for the income, digital and population splits.
- Variables: distance cut-off and group membership for the proximity-to-Japan split (only examples named).
- Methods: pre-estimation tests (unit root, cross-sectional dependence, cointegration, Hausman).
- Heterogeneity: coefficients, standard errors and N for the income, digital and population subsamples (only one number printed: Low-Population -3.163).
- Heterogeneity: quantile results (none used).
- Robustness: diagnostic tests (Hansen/Sargan, underidentification, cross-sectional dependence).
- Causality: formal causality test (none used); the author says the IV-GMM pattern supports a "causal interpretation".

### P25

- Data: method used to convert annual data to quarterly.
- Data: software.
- Variables: moderators or mediators (none used).
- Variables: measurement unit and source of EC (absent from Table 1).
- Variables: measurement and source of the robustness-only variables POP and URB.
- Methods: number of Fourier frequencies selected.
- Methods: selected lag orders.
- Methods: formal Wald test of long-run or short-run symmetry.
- Main results: short-run asymmetric coefficients, although the conclusion refers to "asymmetric short-term dynamics".
- Heterogeneity: quantile or subsample heterogeneity (none used; single-country, mean-based model).
- Heterogeneity: threshold results.
- Causality: causality test (none used).
