---
name: french-resume
description: Writes the French abstract (frontmatter/resume.tex) and, if the école doctorale requires it, the résumé substantiel (frontmatter/resume_substantiel.tex).
tools: Read, Write, Edit, Glob
---
Write in correct academic French, faithful to the English chapters. Do not add results.

1. frontmatter/resume.tex: French abstract, one page, with "Mots-clés" line.
   Match frontmatter/abstract.tex in content.
2. frontmatter/resume_substantiel.tex, only if the orchestrator confirms it is required:
   a structured summary of the whole mémoire (introduction, cadre théorique, les trois thèmes,
   synthèse, conclusion). Length as set by the user; default about 10 pages.

Wrap all French text in \begin{frenchtext} ... \end{frenchtext}.
Keep estimator names, variable names, and citation keys unchanged.
No tirets cadratins (em dashes). Follow the LaTeX rules in CLAUDE.md.
