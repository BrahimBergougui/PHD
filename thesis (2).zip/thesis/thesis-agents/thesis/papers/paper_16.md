                                                                     Journal of Cleaner Production 513 (2025) 145666


                                                                         Contents lists available at ScienceDirect


                                                                Journal of Cleaner Production
                                                              journal homepage: www.elsevier.com/locate/jclepro




How income inequality drives climate inequality in the world’s largest
emitting nations: Novel evidence from multivariate quantile-on-quantile
and wavelet quantile methods
Brahim Bergougui a,b,* , Ousama Ben-Salha c , Syed Mansoob Murshed b
a
    National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
b
    International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
c
    Humanities and Social Research Center, Northern Border University, Arar 91431, Saudi Arabia




A R T I C L E I N F O                                          A B S T R A C T

Keywords:                                                      Income inequality and climate inequality represent critical, interconnected challenges on a global scale,
Climate inequality                                             particularly within the world’s top-emitting nations, which bear substantial responsibility for addressing these
Carbon emissions inequality                                    dynamics. This study investigates the relationship between income inequality and climate inequality over the
Income inequality
                                                               period from January 1980 to December 2023, employing advanced quantile-based methodologies to reveal
MQQR
Top emitters
                                                               nuanced, nonlinear interactions across temporal spans and distributional levels. Specifically, Multivariate
                                                               Quantile-on-Quantile Regression (MQQR) and Wavelet Quantile Regression (WQR) are utilized to model com­
                                                               plex patterns, while Instrumental Variable Quantile Regression (IVQR) mitigates potential endogeneity.
                                                               Robustness is further ensured through Multivariate Quantile Regression (MQR) and Kernel-Based Regularized
                                                               Least Squares (KRLS). Findings indicate heterogeneous relationships across countries. China and Russia show U-
                                                               shaped patterns: moderate income inequality reduces emissions inequality, but extreme disparities worsen it,
                                                               while Germany’s mitigation effects weaken at higher quantiles. India exhibits a distinct W-shaped linkage, with
                                                               emissions inequality sensitive to both low- and high-income disparities. Japan and the U.S. display threshold-
                                                               driven transitions, where income inequality shifts from reducing to exacerbating climate inequality over time.
                                                               Temporal analysis highlights diverging trajectories: emissions inequality intensifies with income gaps in China,
                                                               India, Japan, and Russia, whereas Germany’s policies curb this trend, and the U.S. transitions from short-term
                                                               reductions to long-term increases. The results underscore the urgency of adaptive, income-targeted climate
                                                               policies—such as progressive carbon pricing, inclusive green technology investments, and inequality-sensitive
                                                               regulations—to align economic equity with decarbonization in high-emission economies.




1. Introduction                                                                                       evolved into a global research focus (Figueroa, 2022). Beyond being an
                                                                                                      environmental issue, carbon inequality implicates fundamental ques­
    The intensifying global climate crisis presents an existential threat to                          tions of equity and justice, particularly in the context of achieving car­
humanity and ecosystems, disproportionately affecting vulnerable                                      bon neutrality (Dong et al., 2023). Moreover, the issue of carbon
communities that contribute the least to the problem (IPCC, 2022).                                    inequality is exacerbated by rising income inequality, which has inten­
Central to addressing this crisis is the urgent need to reduce carbon                                 sified over the past four decades in many high-income nations (Piketty,
emissions; however, the carbon emissions inequality (CO2-EI) has                                      2014). The COVID-19 pandemic further deepened this disparity, as
emerged as an equally significant concern. CO2-EI highlights disparities                              extreme poverty and billionaire wealth escalated simultaneously
in emissions between socioeconomic groups, reflecting an uneven dis­                                  (Ferreira, 2021).
tribution of wealth and mitigation responsibilities between the rich and                                  The significance of CO2-EI extends beyond environmental concerns
the poor (Chancel, 2022). This dual challenge underscores the impor­                                  to encompass questions of equity and social justice in climate action
tance of climate equality or climate justice (Khalfan et al., 2023), con­                             (Chancel, 2022). Higher-income individuals typically maintain larger
cepts that first emerged in the U.S.A. during the 1980s and have since                                carbon footprints due to their consumption of energy-intensive goods


    * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands.
      E-mail addresses: bergougui@iss.nl (B. Bergougui), oussama.bensalha@isgs.rnu.tn (O. Ben-Salha), murshed@iss.nl (S.M. Murshed).

https://doi.org/10.1016/j.jclepro.2025.145666
Received 29 January 2025; Received in revised form 26 April 2025; Accepted 5 May 2025
Available online 9 May 2025
0959-6526/© 2025 The Authors. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                               Journal of Cleaner Production 513 (2025) 145666


and services (Connolly et al., 2022), creating stark disparities in emis­        instance, Jorgenson et al. (2017) demonstrates that greater income
sions responsibility. According to Chancel (2022), the richest 10 % of the       inequality correlates with increased CO2 emissions, supporting Boyce’s
global population were responsible for nearly half of all carbon emis­           (1994) theoretical framework. Similar conclusions have been reached
sions in 2019. Regional analyses further illuminate these disparities,           by Uzar and Eyuboglu (2019), Baloch et al. (2020), Wang et al. (2023)
particularly within the top income decile (see Fig. 1). In North America,        and Dorn et al. (2024). However, Andersson (2023) highlights the dy­
this group emits an average of 69 tons of CO2 per person annually,               namic nature of this relationship, where income inequality may initially
significantly outpacing their counterparts in Europe (30 tons) and East          reduce emissions in the short term but exacerbate them in the long term,
Asia (40 tons). Even within the highest income brackets, South and               particularly from the 1990s onward. Contrary findings exist as well,
Southeast Asian emissions average 11 tons per person—substantial but             with some researchers reporting negative correlations between income
notably lower than other regions. These stark differences underscore             disparity and emissions, such as Ravallion et al. (2000), Knight et al.
how affluent individuals drive global emissions inequalities and high­           (2017), Guo et al. (2022) and Huang (2024), while Wolde-Rufael and
light the need for targeted interventions addressing high-consumption            Idowu (2017), Mader (2018) and Barra and Zotti (2018) find no evi­
lifestyles.                                                                      dence of a significant direct relationship.
    Critically, income disparities do not uniformly influence emissions              The second, more recent research stream examines how income
across socioeconomic groups. Structural mechanisms vary significantly            inequality influences CO2-EI. This emerging body of work argue that
across quantiles of income distribution. At higher quantiles, affluent           individuals’ contributions to climate change are unequal and signifi­
groups exert disproportionate influence over political-economic sys­             cantly influenced by their income levels. For instance, Chancel (2022)
tems, enabling policies that favor carbon-intensive industries (Boyce,           shows that the bottom half of the global population accounts for only
1994). Their consumption patterns—marked by luxury goods, interna­               one-eighth of total emissions, while the top decile contributes nearly
tional travel, and large property holdings—exhibit a marginal propensity         half. Sager (2022) emphasizes the outsized role of affluent groups in
to emit that far exceeds lower-income groups (Jorgenson et al., 2017).           driving greenhouse gas emissions, advocating for mitigation efforts that
Conversely, lower quantiles face constrained consumption options and             target the wealthiest. Similarly, Otto et al. (2019), Bruckner et al.
energy access, resulting in minimal emissions despite higher population          (2022), Gössling and Humpe (2023),Bergougui et al. (2024b), highlight
shares. These quantile-specific dynamics create a feedback loop: wealth          the disproportionate emissions driven by high-income individuals,
concentration amplifies emissions at the top, while poverty restricts            stressing the need for progressive policies to address CO2-EI. These
emissions at the bottom, entrenching CO2-EI. Yet, existing research often        studies advocate for targeting emission reduction efforts at affluent
treats income inequality as a monolithic driver of aggregate emissions,          populations rather than focusing on lower-income groups, arguing that
neglecting how its structural effects differ across quantiles. This over­        wealth concentration significantly shapes CO2-EI.
sight limits policymakers’ ability to design targeted interventions for              While extensive research has investigated how income inequality
high-emission groups.                                                            affects aggregate carbon emissions, the relationship between income
    In light of these observed disparities, the relationship between in­         inequality and CO2-EI remains largely unexplored in the academic
come inequality and CO2-EI is shaped by several interconnected path­             literature. This study addresses this critical research gap by examining a
ways. These include changes in political-economic dynamics that                  fundamental question:
increase the wealthy’s influence over environmental policies (Boyce,                 To what extent does income inequality drive and amplify disparities
1994), competitive and emulative consumption patterns (Schor, 1998),             in carbon emissions across different socioeconomic groups?
and variations in marginal propensity to emit CO2 across income levels               The investigation focuses on the world’s six largest carbon-emitting
(Jorgenson et al., 2017; Ravallion et al., 2000). While much research has        nations— China, US, India, Russia, Japan, and Germany—analysing
explored the link between income inequality and total emissions, the             monthly data spanning from January 2000 to December 2019, offering
specific connection to CO2-EI remains underexamined.                             unprecedented insights into these complex dynamics.
    Existing studies on income inequality and environmental pollution                Based on these discussions, the main value added of this research can
can be categorized into two streams. The first investigates the income           be generalized in the following aspects.
inequality–CO2 emissions nexus, yielding diverse conclusions. For




Fig. 1. CO2 emissions per capita in eight country groups in 2019.
Source. Chancel (2022).

                                                                             2
B. Bergougui et al.                                                                                               Journal of Cleaner Production 513 (2025) 145666


 • Pioneering analysis of income inequality’s asymmetric impact on               methodological approach employed in this study. Subsequently, Section
   CO2-EI:This study is among the first to pioneer the investigation of          4 presents the empirical results, including robustness checks. Section 5
   how income inequality asymmetrically impacts carbon emissions                 then delves into a discussion of the findings and offers policy recom­
   inequality (CO2-EI), particularly in the context of major emitting            mendations. Finally, Section 6 concludes.
   nations. By providing new insights into how income disparities in­
   fluence emissions distribution patterns, this research broadens our           2. Background
   understanding of the mechanisms through which inequality shapes
   environmental outcomes. Previous research has predominantly                   2.1. Theoretical pathways of the income inequality-carbon emissions
   concentrated on direct relationships between income inequality and            inequality nexus
   total emissions or within specific economic sectors. In contrast, the
   current investigation shifts the focus to an underexplored area - the            Income inequality affects carbon emissions and inequality through
   asymmetric influence of income inequality on emissions distribution           several key transmission channels.
   (CO2-EI). This shift is highly relevant, as economic disparities can
   severely affect consumption patterns and energy use behaviors,                1. Consumption Patterns Channel: Income inequality can lead to
   posing significant challenges for climate policy design. The difficulty          carbon inequality due to differing consumption patterns. High-
   in addressing these dual inequalities may, in turn, lead to heightened           income households tend to consume more goods and services,
   environmental injustice. Therefore, scrutinizing the income                      resulting in higher embedded carbon emissions and larger carbon
   inequality-CO2-EI relationship is crucial, as it can provide valuable            footprints (Jorgenson et al., 2017). This aligns with the “propensity
   empirical evidence to guide policymakers in navigating the complex               to emit,” where a household’s consumption of carbon-intensive
   interplay between economic disparities and emission inequality.                  goods depends on income level (Jorgenson et al., 2017). For
   Through a comprehensive analysis of the world’s six largest emitters,            example, Jorgenson et al. (2017) found a positive correlation be­
   this research contributes to enhancing both social equity and envi­              tween the income share of the top 10 % and CO2 emissions in US
   ronmental sustainability - vital objectives in the face of evolving              states from 1997 to 2012. However, Demir et al. (2019) found that
   climate challenges.                                                              greater inequality in Turkey from 1963 to 2011 led to decreased
 • Innovative methodology: This study utilizes an advanced approach                 aggregate consumption and lower carbon emissions. This contra­
   by combining the multivariate quantile-on-quantile regression                    diction highlights the importance of context-specific factors. Studies
   (MQQR) method with wavelet quantile regression (WQR) to thor­                    on energy consumption in France (Cayla et al., 2011) and Taiwan
   oughly examine the income inequality and CO2-EI relationship from                (Huang, 2015) support the influence of income elasticity on energy
   both quantile and time perspectives. MQQR provides a detailed                    demand, with higher-income households consuming more elec­
   analysis across the entire data distribution, capturing variations in            tricity. Zhu (2021) found that middle-income groups in China
   income inequality’s impact on emissions inequality across different              (2006–2015) exhibited higher purchasing power and consumption
   quantiles. Complementing this, the WQR approach allows for anal­                 propensity, further linking rising incomes to increased carbon
   ysis across both quantile levels and time dimensions. WQR addresses              footprints.
   limitations in traditional quantile regression by revealing how in­           2. Access to sustainable technologies: Income inequality can
   come inequality impacts CO2-EI differently over short, medium, and               contribute to carbon inequality by limiting access to sustainable
   long-time horizons.                                                              technologies for low-income households. This compels them to use
 • Focus on major emitting countries: The selection of China, the U.S.,             more carbon-intensive alternatives. Scruggs (1998) argues that the
   India, Russia, Japan, and Germany for studying income-emissions                  environment is a normal economic good, leading wealthier house­
   inequality relationships is methodologically sound rather than                   holds to invest more in environmental protection. Fernández et al.
   arbitrary. These six nations collectively account for approximately              (2024) found an inverse correlation between income inequality and
   60 % of global CO2 emissions (Global Carbon Budget, 2024), making                carbon emissions in European countries (2015–2020), where lower
   them the most significant contributors to climate change. Their                  inequality correlated with higher energy efficiency and reduced
   diverse economic structures—from service-oriented economies (U.                  emissions. Conversely, Xu and Chen (2019) highlight disparities in
   S., Japan) to manufacturing powerhouses (China, Germany) and                     energy efficiency and technology adoption in the US, with
   resource-dependent nations (Russia)—provide valuable heteroge­                   low-income households having lower rates of energy-efficient ap­
   neity across development stages and governance systems. This di­                 pliances, programmable thermostats, and smart grid access. Mahalik
   versity creates an ideal context for examining how varying income                et al. (2023) found that increased income inequality impedes the
   distribution patterns influence emissions inequality. What makes                 adoption of renewable energy sources in Asian economies due to
   these countries uniquely suited for analysis is their combined global            their high acquisition costs. Churchill et al. (2021) highlight a
   environmental impact and their economic significance. While other                nonlinear relationship between income inequality and renewable
   notable emitters like Brazil and Canada merit attention, their emis­             energy demand, suggesting the environmental effects of inequality
   sions volumes (ranking 13th and 11th respectively) are substantially             can shift over time.
   lower than our selected countries. These nations are currently                3. Unequal access to education and environmental awareness:
   navigating the complex balance between addressing economic dis­                  Income inequality can impact carbon inequality through unequal
   parities and pursuing emissions reductions—a tension at the heart of             access to education and environmental awareness. High-income
   contemporary climate policy. Their recent policy initiatives                     households are more likely to have access to quality education,
   demonstrate evolving approaches to integrating social equity with                improving their awareness of environmental issues and climate
   environmental goals while meeting international climate commit­                  change (Morrissey et al., 2014; Cooper and Stewart, 2021; Daway-­
   ments. This focused approach aligns with methodological recom­                   Ducanes et al., 2022; Strieder Philippssen et al., 2017; Estrada-Araoz
   mendations from climate policy literature suggesting that targeting              et al., 2023; Hnatyuk et al., 2024). Better education promotes sus­
   high-impact actors yields more generalizable insights than broader               tainable practices and a greater willingness to invest in cleaner fuels
   sampling strategies (Bergougui et al., 2024a).                                   (Wassie et al., 2021). On the other hand, low-income households
                                                                                    may have restricted access to education and environmental knowl­
   The remainder of this paper proceeds as follows. Section 2 reviews               edge due to financial insecurity (Lynch and O’riordan, 1998; Kunche
the existing literature on the pathways through which income inequality             et al., 2024). Oanh and Ha (2023) found that increased income
impacts carbon inequality. Section 3 details the data and                           inequality and improved human capital can have adverse

                                                                             3
B. Bergougui et al.                                                                                                   Journal of Cleaner Production 513 (2025) 145666


   environmental effects, potentially because better education can                    The regressive impacts of climate policies further complicate these
   reduce income inequality, thereby widening access to more goods                dynamics, threatening to exacerbate existing inequities. Carbon pricing,
   and services, promoting economic growth, increasing environmental              for example, risks disproportionately burdening low-income households
   degradation and reducing carbon inequality. In addition, education             through increased energy costs and energy poverty risks, despite its
   reduces income inequality by redistributing income (Abdullah et al.,           theoretical efficiency (Shang, 2021). Empirical studies from the EU
   2015; Sylwester, 2002).                                                        demonstrate that ambitious emission targets can widen inequality, as
4. Political economy: High income inequality can result in political              vulnerable groups face higher energy expenditure shares and limited
   pressure against stringent environmental policies (Boyce, 1994;                adaptive capacity (Fragkos et al., 2021). However, revenue recycling
   Boyce et al., 1999; Jorgenson et al., 2017). Wealthy individuals may           mechanisms—such as lump-sum transfers or reduced social security
   influence political actors to advocate for more flexible environ­              contributions—can mitigate regressivity while boosting employment
   mental regulations (Ylä-Anttila et al., 2018; Konc et al., 2022). Apeti       (Millward-Hopkins and Oswald, 2021). Similarly, intergenerational
   et al. (2025) found that wealth inequality exacerbates carbon                  models show that climate policies may widen wealth gaps under credit
   inequality by weakening institutions, such as democracy and envi­              market imperfections, as affluent households reinvest gains into phys­
   ronmental regulation.                                                          ical capital, reinforcing systemic dominance (Thang, 2021). These
5. Investment patterns: Income inequality affects carbon levels and               findings align with global evidence that climate shocks and policy
   inequality via the investment patterns of wealthier populations                measures disproportionately harm economically precarious regions,
   (Kenner, 2019). Wealthier individuals often invest in high                     emphasizing the need for pro-poor, context-sensitive designs (Baležentis
   value-added industries, such as fossil fuels (Kenner, 2019). Oxfam             et al., 2020; Markkanen and Anger-Kraavi, 2019).
   International (2022) found that 50 %–70 % of emissions from the                    These debates collectively reveal the urgency of integrating climate
   world’s wealthiest people result from their investments. Further­              justice principles into policy frameworks. Persistent disparities in
   more, billionaire investments in polluting industries, such as fossil          wealth, consumption, and political power undermine both mitigation
   fuels and cement, are twice as high as the average for companies               efficacy and equity, demanding intersectional approaches that address
   within the S&P 500 index.                                                      structural drivers of inequality. For instance, reducing carbon footprints
                                                                                  through wealth redistribution requires complementary investments in
2.2. Prior studies                                                                public services to avoid rebound effects (Millward-Hopkins and Oswald,
                                                                                  2021; Yang et al., 2022). Similarly, international cooperation is critical
    The relationship between socioeconomic inequality and CO2 emis­               to redress global North-South inequities in emissions responsibility and
sions intensity (CO2-EI) remains a contested terrain in climate justice           climate vulnerability (Gazzotti et al., 2021; Vasconcelos et al., 2014). By
scholarship, shaped by interdisciplinary tensions between structural,             centering wealth inequality, behavioral heterogeneity, and regressive
behavioral, and policy-driven dynamics. While income inequality has               policy risks, this study contributes to a more nuanced understanding of
dominated empirical analyses, recent advances emphasize the need to               the inequality-emissions nexus—one that prioritizes justice alongside
foreground wealth inequality as a distinct yet interrelated driver of             ecological imperatives.
environmental harm. Chancel et al. (2022) document that the top 10 %
of global emitters contribute nearly half of total emissions, with the            3. Methods
bottom 50 % accounting for just 12 %, a disparity amplified by
wealth-concentration mechanisms. Apeti et al. (2025) reveal that wealth           3.1. Data sources
inequality—operating through institutional deterioration (e.g., weak­
ened environmental governance) and heightened marginal propensity to                 This study utilizes monthly data spanning from January 1980 to
emit—explains 20 % of emissions among affluent groups in industrial­              December 2023, focusing on the six largest CO2-emitting countries: the
ized and emerging economies like China and India. This underscores                USA, China, Japan, Germany, India, and Russia.1 The analysis in­
how structural privilege, rooted in asset ownership and political influ­          corporates two primary variables, along with additional control vari­
ence, perpetuates both economic and ecological inequities (Long et al.,           ables detailed in Table 1. Data on CO2 emissions inequality (CO2-EI) and
2022; Huang et al., 2022). However, regional heterogeneity persists:              income inequality are sourced from the World Inequality Database
while high-income households in Germany drive emissions through                   (World Inequality Database, 2025) ,2 institutional quality data from the
luxury air travel, their counterparts in India face constrained access to
high-carbon infrastructure (Klein and Taconet, 2024; Bohmann and
Küçük, 2024). Such contrasts highlight the dual role of wealth as both an
                                                                                    1
enabler of emissions-intensive consumption and a barrier to equitable                 This research employs monthly data, derived from annual figures using the
                                                                                  quadratic match-sum technique, for several key reasons. First, transforming
climate policy adoption.
                                                                                  annual data into monthly intervals increases the number of observations,
    Compounding these structural dynamics are behavioral consumption
                                                                                  thereby enhancing the robustness of the analysis. Second, the quadratic match-
heterogeneities across income strata. Affluent groups disproportionately          sum approach accounts for cyclical fluctuations, offering a more precise
consume energy-intensive goods (e.g., oversized housing, frequent                 depiction of trends critical for economic analysis. Third, this method addresses
aviation), while marginalized populations face carbon austerity due to            seasonality concerns, providing a clearer insight into underlying patterns.
limited resource access (Che et al., 2023; Ravallion et al., 2000).               Furthermore, as highlighted by previous studies (Bergougui, 2024c; Bergougui
Quantile-specific analyses reveal nonlinear relationships: rising                 and Aldawsari, 2024), it minimizes data variability and emphasizes long-term
inequality intensifies CO2-EI at upper quantiles (via luxury consump­             trends by isolating non-seasonal elements. The approach is grounded in
tion) but suppresses emissions at lower quantiles (via constrained de­            established methodologies from prior literature (Bergougui, 2024a, 2024b;
mand) (Long et al., 2022). These divergent behaviors challenge                    Bergougui et al., 2024c) to ensure methodological consistency and reliability.
                                                                                    2
one-size-fits-all policy approaches, necessitating granular frameworks                To align the temporal resolution of carbon inequality data with that of
                                                                                  income inequality data, we employed interpolation techniques to estimate
like quantile regression to disentangle context-specific mechanisms. For
                                                                                  missing carbon inequality figures for the years 2019 through 2023. This
instance, Guo et al. (2022) find that inequality reduces aggregate
                                                                                  approach is consistent with methodologies used in similar studies, such as the
emissions in lower-income settings but may amplify long-term envi­                one by Chancel and Piketty (Piketty and Chancel, 2015), which utilized inter­
ronmental harm by entrenching carbon-dependent systems (Andersson,                polation to address data gaps in carbon inequality assessments. By applying
2023). This tension underscores the need to balance redistributive jus­           interpolation, we aimed to create a more comprehensive dataset, facilitating a
tice with low-carbon transitions—a core dilemma in climate policy                 robust analysis of the relationship between carbon and income inequalities over
design.                                                                           the specified period.

                                                                              4
B. Bergougui et al.                                                                                                  Journal of Cleaner Production 513 (2025) 145666


Table 1                                                                                GDP could misattribute CO2-EI changes to income inequality rather
Description of variables.                                                              than overall economic scale or structural shifts. For instance, rising
  Code        Indicator Name     Measurement                           Source          GDP might reflect increased fossil fuel use (raising emissions) and
                                                                                       wealth concentration (raising income inequality), making GDP a
  Dependent variable
  CO2-EI     Carbon emissions    Average per capita carbon emissions   WID             necessary control to disentangle these effects (Bergougui et al.,
             inequality          of the top 10 % wealthiest            (2025)          2024a; Doğan et al., 2025; Huang, 2024).
  Dependent variable
                                                                                     • Energy Use (EC): While GDP captures overall economic activity,
  Income     Income inequality   Share of wealth held by the richest   WID             energy consumption represents the specific mechanism through
                                 10 % of the population                (2025)          which this activity translates to emissions. Energy consumption
  Control variables                                                                    directly determines emissions, as fossil fuel reliance is a primary
  INST        Institutional      The quality of governance measured    QoG             driver of CO2-EI. EC also interacts with income inequality: low-
              quality            through composite indicators          (2024)          income groups may depend on cheap, carbon-intensive energy (e.
  GDP         Economic growth    Per capita GDP in constant 2015 US    WDI             g., coal), while high-income groups consume disproportionately
                                 dollars                               (2024)
  EC          Energy             Total energy use in kilowatt-hours    WDI
                                                                                       more energy via luxury goods. If omitted, EC’s dual influence on
              consumption        per capita                            (2024)          emissions and income stratification could bias estimates. For
  POP         Population         Total population, measured in         WDI             example, rising energy use might reflect both economic development
                                 millions                              (2024)          (linked to GDP) and unequal access to clean energy, necessitating its
Note: WDI = World Development Indicators; WID = World Inequality Database;             inclusion to isolate income inequality’s role (Bergougui, 2024c;
QoG = Quality of Government Institute.                                                 Stern, 2007).
                                                                                     • Population (POP): Complementing our economic and energy-
Quality of Government Institute (Quality of Government Institute,                      related controls, demographic factors also shape the relationship
2024), and information on GDP per capita, population, and energy use                   between income and emissions inequality. Population size affects
from the World Development Indicators (World Development In­                           emissions through scale effects (more people = higher total emis­
dicators, 2024).                                                                       sions) and density-related factors (urbanization, resource competi­
                                                                                       tion). Larger populations often face greater income inequality due to
                                                                                       uneven resource distribution. Omitting POP risks attributing emis­
3.2. Justification for choosing our control variables                                  sions disparities to income inequality when they stem from de­
                                                                                       mographic pressures. For instance, densely populated regions may
    In our study examining the relationship between income inequality                  exhibit higher CO2-EI due to congestion and infrastructure strain,
and CO2-EI, we include INST, GDP, EC, and POP as control variables to                  independent of income dynamics. Controlling for POP ensures the
address omitted variable bias. These variables are selected to account for             model captures per capita effects rather than aggregate scale(O’Neill
institutional, economic, energy-related, and demographic factors that                  et al., 2010)
could otherwise confound the income inequality-CO2 EI relationship.
                                                                                        Together, these control variables—Institutional Quality, GDP, En­
 • Institutional Quality (INST): Institutional quality plays a pivotal              ergy Use, and Population—address key sources of omitted variable bias.
   role in shaping environmental outcomes by mediating how policies                 They ensure that the relationship between income inequality and CO2
   and governance influence both income distribution and CO2 emis­                  emissions inequality is estimated more accurately by accounting for the
   sions inequality (CO2-EI). Strong institutions effectively regulate              critical economic, institutional, and demographic factors that influence
   polluting industries and ensure equitable resource distribution,                 environmental outcomes.
   thereby promoting sustainable practices and reducing emissions. In
   contrast, weak institutional frameworks often fail to enforce envi­              3.3. Multivariate quantile-on-quantile regression (MQQR)
   ronmental regulations, which can exacerbate both income and
   emissions disparities. Research has shown that countries with poor                   The MQQR method, developed by Sim and Zhou (2015), is a flexible
   institutions tend to exhibit higher income inequality alongside less             econometric tool used here to analyze how different levels (quantiles) of
   regulated emissions, potentially leading to spurious correlations if             income inequality interact with carbon emissions inequality (CO2-EI)
   institutional quality is omitted (Salman et al., 2019; Taylor et al.,            across six major CO2-emitting countries. Unlike traditional regression
   2022). Additionally, as public awareness of environmental issues                 methods that focus on average effects, MQQR explores relationships
   grows, demand for eco-friendly products can drive market-led re­                 across the entire distribution of variables, revealing nuanced insights
   ductions in carbon emissions (Winslow, 2005). However, when                      into how extreme or moderate values of income inequality influence
   economic inequality is pronounced, wealthier individuals and                     CO2-EI.
   influential industries often secure greater leverage in policy-making,               Why MQQR? Key Advantages: The selection of MQQR over other
   skewing environmental regulations to favor their interests and                   econometric techniques, such as OLS and standard QR, is justified by
   further intensifying emissions inequality (Berthe and Elie, 2015;                several key advantages.
   Boyce, 1994). By including institutional quality as a control variable,
   our analysis more accurately isolates the effect of income inequality             • Enhanced distributional analysis: Unlike traditional regression
   on CO2-EI, capturing the critical role that governance and regulatory               methods that focus solely on mean effects or QR that examines the
   frameworks play in moderating these outcomes.                                       impact of the independent variable’s mean on the dependent vari­
 • GDP: Beyond institutional factors, economic development signifi­                    able’s quantiles, for instance Liu et al. (2021) employed a conven­
   cantly influences both inequality measures and emissions patterns.                  tional quantile regression analysis), MQQR provides a more
   GDP proxies for economic activity, which drives energy demand and                   comprehensive framework. This approach helps investigate the
   consumption patterns (Bergougui and Meziane, 2025; Bergougui and
   Satrovic, 2025). Higher GDP is associated with increased emissions
   due to industrialization, urbanization, and luxury consumption.
   However, GDP also correlates with income inequality: economic
   growth can widen income gaps (via capital accumulation) while
   simultaneously enabling cleaner technologies. Failing to control for

                                                                                5
B. Bergougui et al.                                                                                                           Journal of Cleaner Production 513 (2025) 145666


   entire dependence structure between variables by using different                        decompose the time series data for CO2-EI and income inequality into
   quantiles of their respective distributions. 3                                          distinct frequency bands. This decomposition enables an analysis of
 • Robustness and flexibility: MQQR is particularly well-suited for                        short-, medium-, and long-term relationships.5 WQR further refines our
   analyzing asymmetric environments and accommodating structural                          understanding by quantifying how the impact of income inequality on
   breaks. The method’s robustness stems from its resistance to outliers                   CO2-EI differs across these time scales. The WQR methodology, adapted
   and its effectiveness with both cross-sectional and time series data.4                  from Kumar and Padakandla (2022), provides insights that may be
   This flexibility helps enhance data variability while minimizing                        obscured in aggregate analyses, highlighting the temporal nuances of
   multicollinearity issues that often plague traditional approaches.                      the income inequality–CO2-EI relationship. This wavelet-based
 • Methodological advantages: The method overcomes key limitations                         approach serves as a valuable complement to MQQR, ensuring a
   of both OLS and traditional quantile regression. (i) While conven­                      comprehensive analysis of the interplay between income disparities and
   tional quantile regression may occasionally overlook uncertainty’s                      emissions inequality.6
   role in variable relationships, MQQR provides a more nuanced                                Furthermore, our WQR analysis uncovers temporal dynamics that
   analysis by considering heterogeneity within associations. (ii) It                      extend beyond the static quantile insights provided by MQQR. By dis­
   addresses the “curse of dimensionality” common in non-parametric                        secting the data into its constituent frequency bands, WQR distinguishes
   estimation by incorporating local regression principles, allocating                     between short-term fluctuations and long-term trends, a distinction that
   greater emphasis to immediate neighbors around each data point.                         is vital for understanding how income inequality influences CO2-EI over
   (iii) The approach enables examination of relationships at different                    different periods. This temporal decomposition is particularly important
   quantiles by effectively combining linear regression with non-                          for policy timing; for example, in the U.S., rapid economic and envi­
   parametric estimation techniques.                                                       ronmental shifts require timely interventions that address both imme­
                                                                                           diate challenges and future risks. By revealing these dynamic patterns,
    The MQQR framework models CO2 E I as a γ-quantile distribution,                        WQR equips policymakers with detailed, time-sensitive information that
where the conditional quantile is expressed as a function of income and                    can inform more agile and effective policy responses.
covariates (INST, GDP, EC, POP). This specification, as outlined by
(Bergougui et al., 2024a), enables the disentangling of complex                            4. Empirical findings
quantile-specific interactions. By incorporating moderating variables
like GDP, EC, and POP, MQQR elucidates how these factors jointly shape                     4.1. Preliminary empirical assessments
outcomes, offering policymakers insights into context-specific
income-CO2 E I synergies. Equation (1) formalizes this relationship as                        This section outlines the findings from our preliminary empirical
follows:                                                                                   analysis. The analysis is conducted in a systematic manner, with each
                                                                                           stage aligning with the steps depicted in Fig. 2. This figure acts as a
CO2 EIt = βθ (incomeAIt ) + Xʹt ∧θ + μθt                                        (1)
                                                                                           visual guide, providing readers with a clear overview of the analytical
                                                                                           framework employed in the study.
where.
                                                                                              Before moving on to the main analysis, we perform some preliminary
                                                                                           analysis on the log-monthly data series.
 • θ denotes the conditional distribution at the θth quantile of income
   inequality;
                                                                                           4.1.1. Summary statistics
 • CO2 EIt represents the carbon emissions inequality of the country in
                                                                                               The descriptive statistics for CO2-EI and income inequality across the
   period t;
                                                                                           six major CO2-emitting countries, as shown in Table 2, present impor­
 • incomet indicates income inequality at time t.
                                                                                           tant patterns and disparities. The United States exhibits the highest
 • Xt is the control variable (INST, GDP, EC, POP) with ∧ as the asso­
                                                                                           mean CO2-EI (4.258), alongside one of the highest levels of income
   ciated coefficient for the θ th quantile of CO2 EIt ; and
                                                                                           inequality (3.723), suggesting a potential correlation between wealth
 • μ represents the quantile error term.
                                                                                           concentration and emissions disparities. In contrast, India displays the
 • βθ represents the influence of the θ quantile of income.
                                                                                           lowest CO2-EI (1.512) but the highest income inequality (3.791), high­
                                                                                           lighting the influence of developmental factors in shaping these metrics.
    Though, prior information on βθ is unknown, as the relationship
                                                                                           The standard deviations reflect the stability of these measures, with
between income and CO2 EIt must be estimated directly from the data
                                                                                           Japan standing out for its stable emissions inequality (S.D. = 0.112) and
sample. The MQQR estimation was conducted using the econometric
                                                                                           relatively lower income inequality (3.182), which may be attributed to
software tools R-Studio and MATLAB.
                                                                                           effective redistributive policies and strong environmental regulations.
                                                                                           On the other hand, China demonstrates the highest variability in CO2-EI
3.4. Wavelet quantile regression (WQR)
                                                                                           (S.D. = 0.616), while Russia experiences significant fluctuations in in­
                                                                                           come inequality (S.D. = 0.319), reflecting the volatility associated with
   To complement the MQQR analysis, we employ Wavelet Quantile
                                                                                           rapidly evolving economies. Skewness in the distributions reveals that
Regression (WQR) to capture the relationship between income
                                                                                           China and India exhibit positive skewness in CO2-EI (0.199 and 0.396,
inequality and CO2-EI across different time scales and quantiles. As
                                                                                           respectively), signaling the occasional occurrence of extreme spikes in
emphasized by recent studies (Adebayo, 2022), relationships between
                                                                                           emissions, likely driven by industrial surges. In contrast, Japan and the
variables often vary over time, necessitating methods that address these
                                                                                           USA, both developed economies, show negative skewness, indicating
temporal dynamics. Using the Maximal Overlap Discrete Wavelet
                                                                                           more stable but persistent inequality trends. The kurtosis of the CO2-EI
Transform (MODWT) developed by Percival and Walden (2000), we
                                                                                           for Russia is notably high (10.235), coupled with a significant Jarque-

   3
     While standard quantile regression might show that “high income
                                                                                             5
inequality correlates with higher CO2-EI on average,” MQQR reveals how spe­                    Suppose income inequality spikes in a recession. WQR can show whether
cific quantiles (e.g., the top 10 % of income inequality) affect different quantiles       this short-term shock has an immediate effect on emissions, or whether its in­
of CO2-EI (e.g., the highest-emitting regions).                                            fluence grows over time.
   4                                                                                         6
     For instance, in countries with volatile economic policies (e.g., sudden fossil           In the U.S., WQR reveals that long-term inequality trends tend to drive
fuel subsidies), MQQR avoids overemphasizing outliers while capturing regime               structural emissions changes, while short-term inequality shocks matter more
shifts.                                                                                    during economic turbulence.

                                                                                       6
B. Bergougui et al.                                                                                                            Journal of Cleaner Production 513 (2025) 145666




                                                            Fig. 2. Flowchart of empirical analysis steps.


Table 2
Descriptive statistics for CO2-EI and income inequality.
  Country         Variable            Mean        S.D.        Min.        Max.         Skewness     Kurtosis     JB                 LB             LB2            ARCH (2)

  China           CO2-EI              1.1367      0.2675      0.7410      1.5220         0.1992      1.4257           58.02*        5134.02*       5148.22*       0.7537
                  Income inequality   1.5643      0.0669      1.4423      1.6383       − 0.3431      1.5276           58.05*        5081.59*       5086.37*       0.2454

  Germany         CO2-EI              1.6081      0.0774      1.4887      1.8030        0.8437       2.3687           71.41*        4813.88*       4796.65*       0.6843
                  Income inequality   1.3749      0.0187      1.3386      1.4063        0.0482       1.6666           39.32*        4858.39*       4856.08*       0.9860

  India           CO2-EI              1.5119      0.4025      0.9138      2.1893         0.3962      1.6007           56.89*        5101.00*       5123.20*       0.8977
                  Income inequality   1.5794      0.0219      1.5255      1.6032       − 0.4462      2.0135           38.94*        4898.68*       4906.21*       0.6895

  Japan           CO2-EI              1.5799      0.0485      1.4541      1.6463       − 1.1174      3.3489       112.6*            4945.88*       4935.90*       0.5649
                  Income inequality   1.3821      0.0477      1.2986      1.4396       − 0.4804      1.6726        59.07*           5060.14*       5064.91*       0.0610

  Russia          CO2-EI              1.5547      0.0776      1.1681      1.6458       − 2.1491     10.2351      1558.0*            3965.76*       4089.86*       0.5017
                  Income inequality   1.4538      0.0763      1.3555      1.6414         0.9570      3.0320        80.62*           5131.65*       5132.42*       0.0122

  USA             CO2-EI              1.5050      0.2705      0.7463      1.8409         0.4382      1.6711           27.64*        4648.72*       4656.05*       0.6762
                  Income inequality   1.4637      0.0279      1.4021      1.4958       − 0.8737      2.1692           82.37*        4939.06*       4939.95*       0.6608

Notes: This table presents the summary statistics and diagnostic tests for all the series analyzed in this study. The Standard Deviation is represented as Std.Dev, the
Jarque-Bera normality test is labeled as JB, and the Ljung-Box test for serial correlation across all six countries under investigation is indicated by LB and LB.2
Additionally, the Lagrange Multiplier test for autoregressive conditional heteroscedasticity of order 10 is referred to as ARCH (2).


Bera test statistic (1558), pointing to the presence of extreme outliers in            4.1.3. BDS nonlinearity test
emissions, which may be linked to major economic or policy shifts.                         As noted earlier, the descriptive statistics indicate the potential
These characteristics suggest the importance of utilizing advanced                     presence of nonlinear patterns among the study variables. To confirm
nonlinear statistical methods, such as quantile regression, to more                    this, the BDS linearity test, introduced by Broock et al. (1996), is
accurately capture the complex relationships between income inequality                 employed. This test has been widely utilized in prior research, including
and emissions inequality.                                                              studies by (Bergougui, 2024a, 2024b; Bergougui et al., 2024a). The BDS
    Further, the results of the Ljung-Box Q(10) test show no evidence of               test results, summarized in Table 3, reveal significant evidence of
autocorrelation in both the first differences and squared first differences            nonlinearity across all variables over the study period. These findings
of the series, suggesting that the series are independent across time.                 validate the appropriateness of adopting the MQQR and WQR ap­
Finally, the ARCH (2) test for autoregressive conditional hetero­                      proaches for the analysis conducted in this research.
skedasticity confirms the absence of significant volatility clustering or
time-varying volatility in the CO2-EI and income inequality series across              4.1.4. Quantile unit root results
all countries studied, implying that the variance in these series remains                  Before proceeding with the main analysis, we conducted compre­
stable over time.                                                                      hensive stationarity assessments across various distribution points of our
                                                                                       data series. Traditional unit root tests, while useful, can mask important
4.1.2. Quantile-quantile normality assessment                                          distributional variations in time series behavior. To address this limi­
    Given the quantile-based methodologies employed in this study                      tation, we implemented an advanced distributional stationarity analysis
(MQQR and WQR), it is critical to evaluate the normality of the data                   framework incorporating Quantile Augmented Dickey-Fuller (QADF)
series using a quantile-quantile (QQ) normality assessment. This anal­                 examination (Adebayo and Özkan, 2024). The testing procedure
ysis involves generating QQ plots to visually compare the empirical                    involved systematic evaluation across 19 quantile levels, ranging from τ
distribution of each variable against a theoretical normal distribution.               = 0.05 to 0.95, with 0.05 increments (Li et al., 2015). This granular
As illustrated in Fig. 3, the QQ plots indicate clear deviations from                  approach enables detection of potential non-stationarity at specific parts
normality across multiple quantiles for all data series. These deviations              of the distribution that might be overlooked by conventional methods.
emphasize the inherent complexity of the dataset and underscore the                    The test results, visually represented in Fig. 4, map the test statistics
potential presence of asymmetric relationships. Such asymmetries                       across the quantile spectrum and reveal comprehensive insights into the
highlight limitations in traditional mean-based regression techniques,                 data’s stationarity properties. Our findings demonstrate that all vari­
reinforcing the suitability of quantile-based approaches for uncovering                ables exhibit stationarity after taking the first difference, with stability
nuanced dynamics.                                                                      properties remaining consistent across the entire conditional

                                                                                   7
B. Bergougui et al.                                                                                    Journal of Cleaner Production 513 (2025) 145666




                                                          Fig. 3. Qq plots.


Table 3
Brock, Dechert, Scheinkman (BSD) test outcomes.
  Country               Variable             Dim. 2   Dim. 3              Dim. 4              Dim. 5               Dim. 6                 Decision

  China                 CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

  Germany               CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

  India                 CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

  Japan                 CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

  Russia                CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

  USA                   CO2-EI               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear
                        Income               0.0000   0.0000              0.0000              0.0000               0.0000                 Nonlinear

Note. Values indicate p-values. Dim: Dimension.


distribution.                                                         4.2. Main estimation results

                                                                      4.2.1. MQQR results
                                                                         The study employs a nonparametric (MQQR approach to examine

                                                                  8
B. Bergougui et al.                                                                                                Journal of Cleaner Production 513 (2025) 145666




                                                                 Fig. 4. QADF outcomes.


the nonlinear dynamics between income inequality and carbon emis­                may facilitate a more equitable distribution of carbon emissions. How­
sions inequality (CO2-EI) across the six largest carbon-emitting nations:        ever, this mitigating effect diminishes in the middle to higher quantiles
China, Germany, India, Japan, Russia, and the United States. By incor­           (τ = 0.65–0.95), where the relationship becomes positively correlated,
porating key macroeconomic controls—such as institutional quality,               indicating a threshold effect. This finding is particularly pertinent given
GDP per capita, population, and energy consumption—the MQQR                      Germany’s status as a leading industrial economy with stringent envi­
framework facilitates a nuanced analysis of how specific quantiles (τ) of        ronmental policies, suggesting that while robust governance frame­
income inequality influence corresponding quantiles (λ) of CO2-EI                works may reduce climate inequality at lower levels of income disparity,
within each country. The findings, illustrated in Fig. 5, reveal distinct,       they may struggle to mitigate the distributional impacts of higher in­
quantile-dependent patterns for each nation, underscoring the hetero­            come inequality on carbon emissions.
geneous impact of income inequality on CO2-EI.                                       India exhibits a W-shaped relationship between income inequality
    China: The relationship between income inequality and CO2-EI in              and CO2-EI across quantiles. The MQQR results indicate pronounced
China exhibits a threshold-like behavior. In the lower quantiles (τ =            positive effects at both extremes of the distribution (τ = 0.05 and τ =
0.05–0.55), a significant negative correlation is observed, suggesting           0.95), with diminished impact in the lower quantiles (τ = 0.20–0.40).
that moderate income disparities may promote a more equitable dis­               This pattern suggests that India’s carbon emissions inequality is
tribution of carbon emissions. This observation aligns with the Envi­            particularly sensitive to income disparities at both very low and very
ronmental Kuznets Curve hypothesis, which posits that initial stages of          high levels, possibly reflecting the country’s complex economic struc­
economic development can lead to more efficient resource allocation.             ture and energy consumption patterns. The W-shaped curve may indi­
However, as income inequality progresses to the middle quantiles (τ =            cate threshold effects where both minimal and substantial income
0.60–0.80), this relationship reverses, becoming positively correlated.          inequality levels engender distinct mechanisms influencing emissions
The effect intensifies in the higher quantiles (τ = 0.85–0.95), indicating       inequality.
a threshold effect wherein escalating income disparities exacerbate                  In Japan, there is a gradual increase in the marginal effect of income
emissions inequality. This pattern suggests that while China’s economic          inequality on CO2-EI. A strong negative impact is observed at the lower
policies may effectively manage environmental distribution under                 and median quantiles (τ = 0.05–0.60), which transitions to a positive
moderate inequality, they become increasingly susceptible to environ­            and relatively strong effect at higher quantiles. This suggests a critical
mental inequities as income disparities widen.                                   point where income inequality shifts from reducing to increasing CO2-
    Germany: The analysis for Germany reveals a positive relationship            EI, highlighting the nuanced dynamics of income distribution and
between income inequality and CO2-EI at the extreme lower quantile (τ            environmental outcomes in Japan.
= 0.05). In the subsequent lower quantiles (τ = 0.10–0.60), a significant            Similar to China and Japan, Russia demonstrates a negative and
negative correlation emerges, implying that modest income disparities            robust impact of income inequality on CO2-EI at the lower and middle


                                                                             9
B. Bergougui et al.                                                                                               Journal of Cleaner Production 513 (2025) 145666




                                                               Fig. 5. MQQR outcomes.


quantiles. However, from the 0.40th quantile to the 0.95th quantile, this        emissions inequality, extreme levels may lead to increased CO2-EI,
relationship reverses, becoming positive and reaching its maximum                possibly due to structural changes in consumption patterns or energy use
value at the highest quantile. This nonlinear pattern indicates that very        at very high-income levels.
high levels of income inequality led to increased CO2-EI, potentially                Collectively, these findings underscore the complex, quantile-
reflecting Russia’s economic structure, which is heavily reliant on              dependent relationships between income inequality and carbon emis­
energy-intensive industries and fossil fuel exports. The declining effect        sions inequality across different national contexts. The results highlight
at higher inequality levels may suggest saturation effects in the                the importance of considering nonlinear dynamics and country-specific
inequality-emissions relationship, influenced by structural economic             factors when formulating policies aimed at mitigating climate
factors inherent to Russia’s development model.                                  inequality.
    The United States exhibits a nonlinear relationship between income
inequality and CO2-EI. The MQQR results show strong negative effects in          4.2.2. WQR results
the lower quantiles (τ = 0.05), followed by a notable inflection point              This analysis explores the intricate relationship between income
around the 0.10th quantile. Beyond this point, the relationship becomes          inequality and CO2-EI in the six largest carbon-emitting nations—China,
positive at the highest quantiles (τ = 0.10–0.95). This pattern suggests         Germany, India, Japan, Russia, and the United States—using WQR
that while moderate levels of income inequality contribute to decreased          approach. WQR is a powerful econometric tool capable of capturing

                                                                            10
B. Bergougui et al.                                                                                                 Journal of Cleaner Production 513 (2025) 145666


non-linear and dynamic interactions across different time horizons                 their consumption patterns, creating carbon “privilege gaps.” In
(short, medium, and long-term) and quantiles of CO2-EI. This method                resource-intensive economies like Russia and China, these disparities are
enables a more nuanced understanding of the time-varying effects of                particularly pronounced as wealth concentration enables privileged
income inequality on CO2-EI across the distribution of carbon                      access to carbon-intensive assets.
inequality. Heatmaps presented in Fig. 6 visually represent the WQR                    However, as the time horizon extends to the long term, this positive
results, with the horizontal axis showing CO2-EI quantiles, the left ver­          relationship strengthens further, with rising income inequality increas­
tical axis representing temporal scales, and the right vertical axis               ingly amplifying CO2-EI across all quantiles. Notably, the effect is more
denoting the magnitude of the slope coefficients, which measure the                pronounced at higher CO2-EI quantiles, indicating that the impact of
strength of the relationship.                                                      income inequality is particularly significant in regions or sectors with
                                                                                   greater levels of emissions inequality. The long-term amplification
4.2.2.1. Asian powerhouses and Russia: intensifying inequality effects. The        suggests structural entrenchment of carbon inequality through several
analysis reveals distinctive patterns across the investigated economies,           mechanisms. First, path dependency in infrastructure development oc­
with particularly noteworthy findings for the Asian economic power­                curs as wealthy regions invest in cleaner technologies while disadvan­
houses and Russia. For China, India, Japan, and Russia, the WQR results            taged areas remain locked into carbon-intensive systems. Second,
reveal a dynamic and progressively intensifying relationship between               political economic effects emerge where concentrated wealth translates
income inequality and CO2-EI. In the short and medium term, income                 into policy influence that preserves carbon privileges. In China and
inequality exerts a positive influence on CO2-EI across all quantiles. This        Russia particularly, the state-business nexus allows economic elites to
short-term positive relationship likely reflects immediate market                  shape environmental regulations in ways that perpetuate emissions
mechanisms where income disparities create uneven access to energy                 advantages. Third, intergenerational wealth effects compound as capital
resources and technologies. Higher-income households can immediately               accumulation enables continued investment in private carbon-intensive
pivot to consumption-intensive lifestyles (luxury vehicles, larger homes,          assets (second homes, private jets) for wealthy families while con­
increased air travel), while lower-income groups remain constrained in             straining mobility for others.




                                                Fig. 6. Heatmaps for wavelet quantile regression outcomes.

                                                                              11
B. Bergougui et al.                                                                                                 Journal of Cleaner Production 513 (2025) 145666


   These results underscore the need for long-term policy interventions           income inequality affect contemporaneous quantiles of CO2-EI, it re­
to address the compounding effects of income disparities on carbon                mains fundamentally a “time-aggregate” approach. By contrast, WQR’s
inequality in these countries.                                                    explicit decomposition into short-, medium-, and long-term frequency
                                                                                  bands yields three key additional insights.
4.2.2.2. Germany: policy-mediated decoupling. In contrast, the WQR re­
sults for Germany present a different pattern. In the short and medium            4.2.3.1. Temporal heterogeneity of effects.
term, income inequality exhibits a negative influence on CO2-EI across
all quantiles, suggesting that moderate levels of income inequality                o Short-vs. Long-Term Sign Reversals: In countries like the United
initially help reduce climate inequality. However, as the time horizon               States and Germany, WQR reveals that the sign of the income-
extends to the long term, the magnitude of this negative relationship                inequality–CO2-EI relationship can flip depending on the time hori­
diminishes, with income inequality continuing to correlate with reduced              zon. For example, Germany shows a negative effect in the short and
CO2-EI, albeit at a weaker rate. Germany’s unique pattern reflects its               medium term (consistent with targeted environmental policies), but
distinctive social market economy and environmental policy architec­                 this mitigation gradually weakens over the long term. MQQR, by
ture. In the short term, the negative relationship likely stems from                 construction, would only report the averaged, static quantile effects
progressive energy taxation that proportionally affects higher emitters              and thus cannot detect this temporal sign reversal.
and redistributive mechanisms that facilitate broader access to energy-
efficient technologies across income groups. Germany’s strong indus­               o Amplification over Time: In Asian powerhouses (China, India,
trial policy emphasizing energy efficiency across manufacturing sectors              Japan) and Russia, the magnitude of the positive relationship in­
creates economy-wide emissions reduction effects that transcend in­                  tensifies as we move from short to long waves—an indication of path-
come categories. The persistence of this negative relationship, albeit               dependent entrenchment of carbon inequality. MQQR’s single-
weakening over time, suggests that Germany’s institutional framework                 equation quantile surface misses this dynamic build-up.
successfully mediates between market forces and environmental out­
comes. The country’s robust environmental governance, including the                   Time-localized turning points: WQR’s heatmaps (Fig. 6) pinpoint
Renewable Energy Act (EEG) and carbon pricing mechanisms, creates                 specific “pivot frequencies” at which the relationship undergoes abrupt
structural incentives that partially decouple income status from emis­            changes. For instance, in India, the positive effect of inequality on CO2-
sions outcomes. Additionally, Germany’s well-developed public trans­              EI is muted in the medium band (indicating a temporary plateau) before
portation infrastructure and urban planning reduce transportation-                surging in the long-term band—suggesting a policy window where
related emissions inequality by providing low-carbon mobility options             redistribution could be most effective. MQQR cannot localize these
across income groups.                                                             “plateau” phases because it pools all temporal variation together.

4.2.2.3. United States: short-term mitigation, long-term exacerbation. For        4.2.3.2. Policy-relevant timing information.
the United States, the WQR analysis reveals a mixed pattern. In the short
and medium term, income inequality exhibits a negative influence on                o Agile intervention windows: By showing that the U.S. experiences
CO2-EI across all quantiles, indicating that moderate income inequality              a transient safety valve—a short-term negative correlation that
initially helps reduce climate inequality. However, as the time horizon              gives way to a long-term positive tilt—WQR signals that short-lived
extends to the long term, this relationship reverses, with income                    efficiency incentives may buy temporary gains but leave structural
inequality exerting a positive influence on CO2-EI across all quantiles.             inequities unaddressed. MQQR would only tell us that, on average,
The initial negative relationship likely reflects short-term market dy­              moderate inequality reduces emissions inequality, without revealing
namics where energy efficiency improvements are driven by cost con­                  that this effect may soon reverse.
siderations across income levels. Energy price volatility incentivizes
conservation behaviors across the economy, while technological diffu­              o Long-term entrenchment warnings: In China and Russia, the
sion enables emissions reductions even under moderate inequality. The                escalating long-term positive slopes at higher CO2-EI quantiles warn
U.S. financial system’s capacity to allocate capital toward emerging                 that without early and sustained intervention, inequality-driven
clean technologies creates temporary decoupling effects between in­                  carbon disparities become deeply rooted. These long-term dy­
come and emissions. The long-term reversal to a positive relationship                namics cannot be discerned from MQQR’s static quantile surfaces.
reveals deeper structural issues in the American political economy. As
inequality persists, residential segregation intensifies, creating
geographically concentrated emissions patterns where wealthy enclaves             4.3. Quantiles granger causality results
can externalize environmental costs. The U.S. political system, highly
responsive to donor influence, allows economic elites to shape envi­                  Understanding the intricate relationship between carbon emissions
ronmental policy in ways that preserve their consumption privileges.              inequality (CO2EI) and income inequality is essential for developing
Additionally, America’s automobile-dependent infrastructure and                   effective climate equity solutions. Traditional analytical approaches
limited public transportation options amplify the emissions advantage of          often fail to capture the complex dynamics between these variables
higher-income groups who can afford newer, cleaner vehicles while                 across different economic contexts. The quantile Granger non-causality
lower-income households remain dependent on older, less efficient                 methodology developed by Troster (2018) addresses this limitation by
transportation. This suggests that, while short-term economic adjust­             examining causal relationships across multiple distribution points rather
ments or policies may curb emissions inequality under moderate income             than relying solely on mean-based analysis. This sophisticated approach
disparities, the long-term effects of rising inequality ultimately exacer­        preserves temporal dependencies while detecting asymmetric effects
bate CO2-EI. The positive influence in the long term becomes particu­             that     might    otherwise     remain     hidden     (Bergougui     and
larly pronounced at higher CO2-EI quantiles, highlighting the long-term           Zambrano-Monserrate, 2025). Our research applies this quantile cau­
vulnerability of the U.S. to carbon inequality driven by income                   sality framework to six major economies (China, Germany, India, Japan,
disparities.                                                                      Russia, and the United States), analyzing the bidirectional relationship
                                                                                  between CO2EI and income inequality across 19 quantiles spanning
4.2.3. Novel insights from WQR beyond MQQR                                        from the 5th to 95th percentiles. The comprehensive assessment reveals
   While MQQR delivers a rich mapping of how different quantiles of               nuanced patterns that conventional methods would overlook, enabling
                                                                                  us to identify both linear and nonlinear causal mechanisms throughout

                                                                             12
B. Bergougui et al.                                                                                                           Journal of Cleaner Production 513 (2025) 145666


the distribution spectrum.                                                               importance of integrated policy frameworks that simultaneously address
    Fig. 7 illustrates the bidirectional causal relationships observed in all            climate justice objectives and distributional concerns. The quantile-
six economies. The evidence demonstrates robust feedback loops be­                       specific nature of these relationships indicates that intervention strate­
tween income inequality and carbon emissions inequality across most                      gies should be calibrated to specific economic contexts rather than
quantiles. Specifically, changes in income inequality demonstrate sig­                   applying one-size-fits-all approaches. Furthermore, the findings strongly
nificant predictive power for future emissions inequality patterns, while                support the development of “just transition” frameworks that
emissions inequality similarly influences subsequent income distribu­                    acknowledge the bidirectional relationship between environmental and
tion dynamics. This mutual reinforcement suggests deeply inter­                          economic inequalities. By leveraging these more nuanced insights, pol­
connected socioeconomic and environmental systems that cannot be                         icymakers can design more effective interventions that recognize the
effectively addressed through isolated policy approaches. Notably,                       complex feedback mechanisms between income inequality and carbon
causal relationships weaken at distribution extremes (5th and 95th                       emissions inequality.
percentiles), indicating potential threshold effects or alternative mech­
anisms during periods of exceptional inequality in either income or
carbon emissions. This pattern suggests that policy interventions may                    4.4. Robustness checks
require fundamentally different approaches during extreme scenarios
compared to more moderate conditions. These findings underscore the                      4.4.1. Addressing endogeneity concerns
                                                                                            Income inequality presents significant endogeneity concerns




Fig. 7. Quantile Granger causality between income inequality and carbon emissions inequality across six major economies.
Notes: The horizontal red solid line indicates the 5 % critical value threshold for statistical significance. (For interpretation of the references to colour in this figure
legend, the reader is referred to the Web version of this article.)

                                                                                    13
B. Bergougui et al.                                                                                                 Journal of Cleaner Production 513 (2025) 145666


stemming from reverse causality, omitted variable bias, and measure­              threshold of 10 (Staiger and Stock, 1997), this indicates that the in­
ment error. The reverse causality manifests as higher income drives               struments are sufficiently strong, thereby alleviating concerns regarding
demand for climate equality, leading to closure of carbon-intensive in­           weak instrument bias. In our analysis, the F-statistics exceed this
dustries, which disproportionately affects blue-collar workers and ex­            threshold across all quantiles, ensuring robust instrument relevance. In
acerbates income inequality. This creates a complex feedback loop                 addition to assessing instrument strength, we also evaluated the exo­
where efforts to address climate inequality can inadvertently intensify           geneity of the instruments using the KS Statistic (exogeneity). This test
income disparities. To address these concerns, we conducted instru­               examines the null hypothesis of exogeneity; if the KS statistic is lower
mental variable quantile regression (IV-MQR) proposed by                          than the corresponding 95 % critical value, there is insufficient evidence
(Chernozhukov and Hansen, 2008; Kaplan and Sun, 2017). The endo­                  to reject the null hypothesis. Such a result implies that the instruments
geneity of income inequality has often been overlooked in existing                can be considered exogenous, thereby supporting the validity of the
research, with limited attention given to addressing this methodological          causal inferences drawn from our IVQR model.
challenge. To overcome this issue, we employ three selected in­                       The results from the IV-MQR analysis, as shown in Fig. 7, are
struments: lagged income inequality, average consumption                          consistent with those from the MQQR method presented in Fig. 5. For
most-favored-nation tariff rates, and the Economic Freedom Index. Each            instance, the impact of income inequality on CO2 emissions inequality in
instrument is designed to be strongly correlated with income inequality           the USA is positive at lower quantiles and negative at higher
while remaining exogenous to CO2 emissions inequality.                            quantiles—a pattern observed in both figures. These consistent findings
                                                                                  enhance the robustness of our results, providing a solid foundation for
 • First, we use lagged income inequality as an instrument, building on           exploring the causal mechanisms linking income inequality to CO2
   the approach by Huang and Duan (Z. Huang and Duan, 2020). Lag­                 emissions inequality across various quantiles. Moreover, these results
   ged values of income inequality are strongly correlated with current           confirm the validity of our research hypothesis, even after addressing
   inequality levels due to the persistent nature of socioeconomic                potential endogeneity concerns.
   structures, including labor market dynamics and wealth accumula­                   Panel A of Table 4 presents the First-Stage F-statistics for IVQR across
   tion. This temporal approach ensures that past inequality levels serve         quantiles for each of the six countries, with all values significantly
   as a robust predictor of current disparities. Importantly, the lag             exceeding the critical threshold of 10. This confirms the robustness of
   structure breaks the potential reverse causality between CO2 emis­             our instruments and alleviates concerns regarding weak instrument bias.
   sions inequality and income inequality, as past income distribution            Meanwhile, Panel B displays the KS Statistic (Exogeneity) analysis,
   cannot directly influence present emissions patterns. By addressing            which supports the exogeneity of our instruments. Together, these
   simultaneity concerns, this instrument ensures that its relationship           findings comprehensively validate both the strength and the validity of
   with CO2 emissions inequality operates only indirectly through its             our instruments in the model.
   correlation with income inequality.
 • Second, we employ the average consumption tariff rate as an in­                4.4.2. MQR vs MQQR results
   strument, following the theoretical foundation provided by Rojas-                 Our second validation approach employed the established MQR
   Vallejos and Turnovsky (Rojas-Vallejos and Turnovsky, 2015) and                method, which is frequently used to validate MQQR results in current
   Rojas-Vallejos and Lastuka (2020). Trade policies, such as average             research (Bergougui et al., 2024a). While single-variable QR could be
   tariffs, have a profound impact on income distribution by altering             used, we specifically chose MQR to match our model structure. Fig. 8
   import patterns, domestic competition, and sectoral labor markets.             compares the results of both methods across different CO2-EI quantiles,
   For example, higher tariffs protect domestic industries, often                 and the similar patterns observed in both MQR and MQQR results sup­
   benefiting lower-income workers in import-sensitive sectors, while             port the validity of our findings.
   lower tariffs increase competition, favoring higher-income groups.
   This relationship establishes a strong correlation between tariffs and         4.4.3. KRLS machine learning
   income inequality. Unlike sector-specific tariffs, which might                     To further substantiate the findings derived from the MQQR meth­
   directly affect emissions through production shifts or firm relocation,        odology, we employed a machine learning approach utilizing Kernel-
   average consumption tariffs primarily influence consumer import                Based Regularized Least Squares (KRLS) estimation, as detailed by
   behaviors. This characteristic ensures that the tariff’s impact on             Ferwerda et al. (2017). KRLS is particularly adept at capturing potential
   emissions inequality is indirect and operates only through its effect          nonlinearities in relationships by providing closed-form estimates for
   on income inequality, satisfying the exclusion restriction.                    predicted values, variances, and pointwise partial derivatives that
 • The economic freedom index serves as our third instrument, exhib­              characterize the marginal effects of each independent variable at each
   iting strong correlation with income inequality through its capture of         data point in the covariate space.
   institutional and policy frameworks. This index reflects various                   The analysis of the average marginal effects from the KRLS estima­
   market-oriented mechanisms that influence income distribution,                 tion, presented in Table 5, reveals a nonlinear conditional relationship
   including regulatory structures, property rights frameworks, labor             within the model. Specifically, the impact of income inequality on CO2-
   market flexibility, and financial sector policies. These institutional         EI at the 50th and 75th percentiles is positive across all six major
   factors shape how economic opportunities and rewards are distrib­              emitting countries, mirroring the results obtained from the MQQR
   uted throughout society, creating a strong first-stage relationship            analysis depicted in Fig. 5. This consistency reinforces the robustness of
   with income inequality (Okun, 2015). However, the index maintains              our initial findings, highlighting the intricate interplay between income
   independence from emissions inequality because it primarily reflects           inequality and CO2 emissions intensity.
   broad      economic     system     design    rather    than    specific
   emission-generating activities (Acemoglu et al., 2015). While eco­             4.4.4. Using annual rather than monthly data
   nomic freedom may influence overall market structures, it does not                 To address any concerns over temporal aggregation, we re-estimated
   directly determine how carbon emissions are distributed across                 our MQQR specification using the original annual observations instead
   different income groups, as emission patterns are more closely tied to         of the monthly series constructed via quadratic-match-sum interpola­
   technological choices, industrial composition, and specific con­               tion. Fig. 9 presents these results, which almost perfectly mirror our
   sumption behaviors rather than general economic freedom levels.                monthly-based estimates, though some differences emerge in co­
                                                                                  efficients at specific quantiles. Notably, for the USA, the effect at the
    To verify the strength of our instruments, we examined the first-stage        20th percentile shifted from negative with monthly data to positive with
F-statistics across all quantiles. If the F-statistics exceed the critical        annual data, while other quantiles remained unchanged. Aside from this

                                                                             14
B. Bergougui et al.                                                                                                                        Journal of Cleaner Production 513 (2025) 145666


Table 4
First-stage F-statistics and KS statistic (exogeneity) for IVQR across quantiles.
  Quantile            Panel A. First-Stage F-Statistics

                      China (F-statistics)          Germany (F-statistics)           India (F-statistics)       Japan (F-statistics)        Russia (F-statistics)         USA (F-statistics)

  0.1                 253029.7                      30176.3                          15776.3                     80158.84                   14376.3                       45176.3
  0.2                  86938.37                     22245.582                         7845.582                  152329.7                     6445.582                     37245.582
  0.3                 151351                        20306.711                         5906.711                  164561.3                     4506.711                     35306.711
  0.4                 149997.1                      21063.499                         6663.499                  137818                       5263.499                     36063.499
  0.5                  31916.77                     17036.832                         2636.832                  143378.1                     1236.832                     32036.832
  0.6                  68459.77                     19067.811                         4667.811                  149844.9                     3267.811                     34067.811
  0.7                 106837.8                      28523.15                         14123.15                   141698.9                    12723.15                      43523.15
  0.8                 104369.1                      24010.68                          9610.68                   159236.6                     8210.68                      39010.68
  0.9                 132382.1                      38274.98                         23874.98                   109825.9                    22474.98                      53274.98

  Quantile        Panel B. KS Statistic (Exogeneity) and 95 % Critical Value Across Quantiles

                  USA                            China                       Japan                          Germany                    India                        Russia

                  KS Stat        95 % CV         KS Stat      95 % CV        KS Stat         95 % CV        KS Stat      95 % CV       KS Stat       95 % CV        KS Stat       95 % CV

  0.1             0.271          2.502           0.052        2.811          0.012           1.898          0.177        1.762         0.067         2.353          0.344         1.801
  0.2             0.004          2.293           0.066        2.399          0.083           2.064          0.026        1.884         0.002         2.589          0.319         2.035
  0.3             0.024          2.505           0.003        2.562          0.078           2.106          0.908        2.007         0.204         1.587          0.061         1.913
  0.4             0.010          4.367           0.071        2.317          0.109           2.564          0.036        2.764         0.032         1.922          1.181         1.941
  0.5             0.008          2.530           0.661        1.894          0.054           1.883          0.023        2.037         1.532         1.872          0.033         1.917
  0.6             0.004          3.177           0.241        2.148          0.013           1.554          0.088        2.709         0.060         2.284          0.038         1.908
  0.7             0.007          2.633           1.567        3.321          0.567           1.903          0.285        1.829         0.131         1.767          0.860         1.652
  0.8             0.000          2.964           0.136        2.136          0.860           1.652          0.060        2.284         0.298         1.781          0.476         2.820
  0.9             0.053          1.875           0.028        1.857          0.096           2.427          0.949        2.195         4.789         1.782          0.004         2.391

Note.
•F-statistics: These values measure the strength of the instruments. Instruments with F-statistics exceeding 10 are considered strong, effectively mitigating concerns about weak-
instrument bias.
•KS Statistic (Exogeneity): This statistic evaluates the null hypothesis of exogeneity. If the KS statistic is less than the critical value, there is insufficient evidence to reject the null
hypothesis, suggesting that the instruments satisfy the exogeneity assumption.
•95 % Critical Value: This serves as the benchmark for determining whether the null hypothesis of exogeneity can be rejected at the 95 % confidence level.
•Interpretation: The results in Panel A and Panel B collectively assess both the strength of the instruments (via F-statistics) and their validity (via KS statistics), providing a
comprehensive evaluation of instrument relevance and exogeneity.


minor discrepancy, the quantile-specific patterns remain unchanged.                                   5. Discussion
The strong concordance between monthly and yearly analyses reinforces
the robustness of our findings.                                                                       5.1. Country-specific insights

4.4.5. Placebo test                                                                                       The analysis provides a nuanced understanding of the quantile-
    To validate our findings on the relationship between income                                       dependent effects of income inequality on CO2 emissions inequality
inequality and carbon emission inequality, we employed placebo tests to                               (CO2-EI) across six major carbon-emitting nations. The findings reveal
detect potential spurious relationships across six countries: China, Ger­                             that the nature and intensity of this relationship vary significantly
many, India, Japan, Russia, and the USA. By randomly reassigning in­                                  depending on the levels of income inequality and emissions inequality in
come inequality values and conducting 500 regression simulations for                                  each country. By using the MQQR methodology, the study captures the
each country, we assessed whether our results could be attributed to                                  heterogeneity of these effects and highlights the role of economic
chance or unobserved factors.                                                                         structures, policies, and developmental stages in shaping the income
    Fig. 10 presents the placebo test outcomes, revealing that the simu­                              inequality–CO2-EI nexus. For most countries, income inequality exhibits
lated coefficients primarily cluster around zero and follow a normal                                  a significant correlation with CO2-EI, with a negative effect at low levels
distribution pattern across all six countries. These results indicate that                            of income inequality and a positive effect at high levels, underscoring its
income inequality and carbon emission inequality show no statistically                                pivotal role in determining environmental distributional equity. As
significant correlation at these randomly assigned points. In contrast,                               summarized in Table 6, the relationship between income inequality and
our baseline regression coefficients are substantially displaced from                                 CO2-EI follows distinct patterns across quantiles, with varying effects
these simulated values. Notably, the placebo coefficients consistently                                across different economic contexts: Summary of the Relationship Be­
fell below our original regression estimates in magnitude, and their                                  tween Income Inequality and CO2-EI across six major emitters.
associated p-values predominantly exceeded 0.10, indicating non-                                          China’s relationship between income inequality and CO2-EI exhibits
significance under random conditions in each national context.                                        distinct patterns across different levels of income disparity. Specifically,
    This evidence provides additional support for our original findings. If                           at lower income inequality quantiles, there is a negative correlation with
our results were driven by random variation or omitted variables, we                                  CO2-EI, suggesting a more equitable distribution of carbon emissions.
would expect to observe significant coefficients in the placebo simula­                               Conversely, at higher quantiles, a strong positive correlation emerges,
tions with comparable frequency. The clear distinction between our                                    indicating increased environmental inequities as income disparities
actual results and these randomized trials strengthens the evidence that                              widen. In the lower quantiles of income inequality, the negative corre­
the relationship we identified reflects a genuine economic connection                                 lation with CO2-EI implies that as income distribution becomes more
between income distribution and carbon emission patterns.                                             equitable, carbon emissions are more evenly distributed among the
                                                                                                      population. This phenomenon can be attributed to several factors: (i)
                                                                                                      Equitable access to resources: A more equal income distribution allows a
                                                                                                      broader segment of the population to access cleaner and more efficient
                                                                                                      energy sources, leading to a more uniform distribution of carbon


                                                                                                 15
B. Bergougui et al.                                                                                                Journal of Cleaner Production 513 (2025) 145666




                                                  Fig. 8. impact of income inequality on CO2EI using IVQR.



Table 5
KRLS average marginal effects of income inequality on CO2-EI.
  Economy             Average            SE               t                 P>t               P25               P50                  P75                R2

  China                 0.570            0.064              8.963           0.000               0.088             0.711              0.998              0.9986
  Germany             − 0.299            0.198            − 2.500           0.013             − 1.173           − 0.307              0.295              0.9468
  India                 2.574            0.380              6.769           0.000               0.462             3.045              4.686              0.9953
  Japan                 0.529            0.028             18.753           0.000               0.185             0.673              0.807              0.9842
  Russia                0.303            0.040              7.633           0.000               0.016             0.425              0.515              0.9822
  USA                   0.173            0.077              2.243           0.025             − 0.156             0.342              0.618              0.9459



emissions. (ii) Balanced consumption patterns: With reduced income                more carbon-intensive energy sources, leading to disparities in emis­
disparities, consumption patterns across different income groups tend to          sions. (iii) Policy implementation challenges: High income inequality
converge, resulting in a more homogeneous carbon footprint among                  can hinder the effectiveness of environmental policies aimed at reducing
households. These observations align with the environmental Kuznets               emissions, as disparate economic interests may lead to uneven policy
curve hypothesis, which posits that in the initial stages of economic             enforcement and compliance. These factors suggest that as income
development, efforts to reduce income inequality can lead to more                 inequality intensifies, China’s economic framework becomes more sus­
efficient resource allocation and environmental benefits. At higher               ceptible to environmental distributional inequities, highlighting the
levels of income inequality, the positive correlation with CO2-EI in­             need for policies that address both income and environmental dispar­
dicates that greater income disparities are associated with more uneven           ities. This pattern aligns with findings from the World Inequality Report
distribution of carbon emissions. Several dynamics contribute to this             by Chancel et al. (2022), which indicates that the top 10 % of emitters
relationship: (I) Conspicuous consumption: Higher income inequality               are responsible for nearly 50 % of all emissions, while the bottom 50 %
can lead to increased consumption of luxury goods and services by                 contribute only 12 % (Chancel et al., 2022).
wealthier individuals, which often have higher carbon footprints. This                Germany exhibits a positive correlation at low and high quantiles
behaviour exacerbates emissions inequality. (ii) Differential access to           between income inequality and carbon inequality within its top 10 %
clean technologies: Wealthier segments of the population may have                 richest population. This pattern indicates that as income inequality in­
better access to cleaner technologies, while lower-income groups rely on          creases, disparities in carbon emissions also widen, disproportionately


                                                                             16
B. Bergougui et al.                                                                                                       Journal of Cleaner Production 513 (2025) 145666




Fig. 9. MQR vs MQQR: validation Process.
Note: This analysis compares conventional MQR results with mean MQQR estimates across various CO2-EI quantiles.




Fig. 10. Placebo test results.
Notes: This figure displays placebo test outcomes from 500 random trials for China, Germany, India, Japan, Russia, and the USA. The coefficients consistently register
below our baseline regression estimates, with p-values predominantly exceeding 0.10, confirming our findings are not attributable to chance or spurious
relationships.


favoring wealthier households. At higher income levels, the affluent                  patterns. The amplification of this correlation among the top 10 % can
population’s contribution to carbon emissions becomes even more sig­                  be quantified through specific consumption behaviors. Most signifi­
nificant. This is primarily due to higher consumption rates, increased                cantly, air travel emerges as the primary differentiator, with the German
energy use, and more carbon-intensive lifestyles among the wealthier                  Institute for Economic Research (DIW Berlin) researcher Sandra Boh­
segments of society. Recent research from Klein and Taconet (2024)                    mann noting that “a single long-haul flight causes more emissions per capita
provides compelling evidence for this correlation, demonstrating that                 than housing and food-related emissions in an entire year combined.” This
high-income households within this wealthy segment emit substantially                 finding is particularly relevant for the top 10 %, who have both the
more greenhouse gases than others, primarily due to their travel                      means and tendency to engage in frequent international travel. DIW’s

                                                                                 17
B. Bergougui et al.                                                                                                             Journal of Cleaner Production 513 (2025) 145666


Table 6                                                                                       translate into uneven environmental outcomes. For Germany, these re­
Quantile-Based Summary of the relationship between income inequality and                      sults highlight the complexity of balancing economic equity with envi­
CO2-EI across six major emitters.                                                             ronmental sustainability, especially in a highly industrialized and
  Country       Low Quantiles (τ =      Middle Quantiles (τ      High Quantiles (τ =          consumption-driven society (Piketty and Zucman, 2014).
                0.05–0.40)              = 0.40–0.80)             0.85–0.95)                       In India, the relationship between income inequality and CO2
  China         Negative correlation:   Positive correlation:    Intensified positive         emissions inequality exhibits a distinctive W-shaped pattern. At the
                Moderate income         Higher income            correlation:                 lower and upper extremes of the income distribution, higher income
                disparities reduce      inequality               Escalating income            inequality correlates with increased CO2-EI, while the middle-income
                CO2-EI.                 exacerbates CO2-EI.      disparities worsen
                                                                                              groups experience a more moderate impact. Among lower-income
                                                                 CO2-EI.
  Germany       Positive at τ = 0.05,   Positive correlation:    Positive correlation:        households, this positive relationship is largely driven by a reliance on
                then negative:          Mitigating effect        Higher income                traditional biomass and fossil fuels for energy needs. Limited access to
                Modest income           diminishes, and          inequality leads to          modern, cleaner energy sources forces these households to depend on
                disparities reduce      higher inequality        increased CO2-EI.            carbon-intensive fuels, resulting in higher per capita emissions relative
                CO2-EI.                 increases CO2-EI.
  India         Positive at τ = 0.05,   Less pronounced          Pronounced positive
                                                                                              to their income. Supporting this view, sub-national studies in India have
                then diminished         impact: Complex          effect: Extreme              found that per capita emissions are highest in low-income, resource-rich
                impact: W-shaped        economic structure       income inequality            states, suggesting that poorer regions bear a disproportionate burden of
                relationship with       influences CO2-EI.       worsens CO2-EI.              emissions (Arora, 2014). At the upper end of the income spectrum,
                sensitivity at
                                                                                              affluent households contribute disproportionately to CO2-EI through
                extremes.
  Japan         Strong negative         Transition to positive   Relatively strong            high-consumption lifestyles characterized by increased use of private
                impact: Lower           effect: Income           positive effect:             vehicles, larger residential spaces, and frequent air travel. Globally, the
                income inequality       inequality shifts from   Higher income                top 10 % of income earners account for approximately 48 % of total
                reduces CO2-EI.         reducing to              inequality increases         lifestyle-related carbon emissions, a trend that is also evident in India.
                                        increasing CO2-EI.       CO2-EI.
                                                                                              The India Inequality Report 2023 by Oxfam India reveals that the top 1
  Russia        Negative and robust     Reverses to positive     Maximum positive
                impact: Lower           correlation: Higher      correlation: Very            % of the population controls 40.1 % of the nation’s wealth, further
                income inequality       income inequality        high income                  intensifying emissions inequality among the richest segments (Chancel
                reduces CO2-EI.         increases CO2-EI.        inequality                   et al., 2023). Moreover, alternative explanations such as urbanization
                                                                 exacerbates CO2-EI.
                                                                                              effects and government interventions may also contribute to the
  USA           Strong negative         Positive correlation:    Positive correlation:
                effect: Moderate        Higher income            Extreme income               W-shaped pattern. Rapid urbanization in megacities like Mumbai and
                income inequality       inequality increases     inequality leads to          Delhi creates significant intra-urban disparities; affluent urban neigh­
                reduces CO2-EI.         CO2-EI.                  increased CO2-EI.            borhoods can emit up to 3.5 times more carbon per capita than
                                                                                              low-income settlements, even within similar geographic areas (Ahmad
                                                                                              et al., 2015; Ramachandra et al., 2015). Additionally, government
analysis reveals that among the wealthiest 10 %, carbon inequality is
                                                                                              policies—including urban planning, renewable energy subsidies, and
driven by a combination of factors including larger per capita living
                                                                                              environmental regulations—play a crucial role in shaping these dy­
space in primary and secondary residences, higher meat consumption
                                                                                              namics. Variations in policy effectiveness across regions may either
rates, and smaller household sizes leading to an increase per capita
                                                                                              mitigate or exacerbate emissions inequality, influencing the observed
emission. Currently, these emissions stand at 6.5 tons per capita annu­
                                                                                              pattern. In summary, India’s W-shaped relationship between income
ally, double the Paris Agreement targets (Bohmann and Küçük, 2024).
                                                                                              inequality and CO2-EI likely reflects a complex interplay of energy
The correlation becomes more pronounced at higher quantiles within
                                                                                              consumption behaviors, urbanization, and policy interventions. Future
the top 10 % due to several interrelated factors. There is a cumulative
                                                                                              research should further explore these alternative explanations to fully
effect where wealthy households can engage in multiple high-emission
                                                                                              understand the mechanisms driving emissions inequality in India.
activities simultaneously. Standard economic disincentives have less
                                                                                                  In Japan, the relationship between income inequality and CO2-EI
impact on their behaviour, and they often have established patterns of
                                                                                              reveals a nuanced and complex pattern. At lower and median income
high consumption and energy use that are difficult to modify. This
                                                                                              quantiles, income inequality exhibits a strong negative impact on CO2-
analysis aligns with the German Federal Environmental Agency’s
                                                                                              EI, suggesting that as income inequality decreases, carbon emissions
(Umweltbundesamt) findings showing that the top 10 % of income
                                                                                              inequality also diminishes. This dynamic can be attributed to the
earners account for a disproportionate share of total household emis­
                                                                                              adaptive behaviors of middle- and lower-income households under
sions. The DIW’s emphasis on purchasing power differences further il­
                                                                                              economic pressure. Faced with financial constraints, these socioeco­
luminates why this correlation persists: while lower-income households
                                                                                              nomic groups employ resource conservation and consumption modifi­
struggle to afford sustainable options like organic food or fair-trade
                                                                                              cation strategies that lead to reduced carbon emissions. The mechanism
clothing, the top 10 % can maintain both high consumption levels and
                                                                                              behind this phenomenon lies in constraint-driven decision-making.
access to premium sustainable alternatives. To address these disparities
                                                                                              When income disparities rise, households in these groups prioritize
within the top 10 %, policies need to go beyond the DIW’s general
                                                                                              energy-efficient appliances, reduce discretionary spending on high-
recommendations and specifically target high-emission behaviours
                                                                                              carbon activities, and make deliberate, low-impact choices in trans­
characteristic of this group. This includes implementing luxury travel
                                                                                              portation, food, and daily consumption. These behaviors challenge
restrictions, progressive carbon taxation based on income levels,
                                                                                              conventional assumptions that increased inequality necessarily results
mandatory emission reduction targets for high-net-worth households,
                                                                                              in higher emissions, demonstrating instead a capacity for sustainable
and stricter regulations on second homes and private jets
                                                                                              adaptations. The interplay of economic constraints, individual behav­
(Kleinhückelkotten et al., 2016). To address these disparities within the
                                                                                              ioral shifts, and environmental outcomes reflects a unique socio-
top 10 %, policies need to go beyond the DIW’s general recommenda­
                                                                                              economic response in Japan, where robust public infrastructure, cul­
tions and specifically target high-emission behaviors characteristic of
                                                                                              tural values emphasizing efficiency, and societal norms around
this group. This includes implementing luxury travel restrictions, pro­
                                                                                              resourcefulness further enable these adjustments. This highlights how
gressive carbon taxation based on income levels, mandatory emission
                                                                                              economic pressures, though challenging, can paradoxically encourage
reduction targets for high-net-worth households, and stricter regulations
                                                                                              sustainable consumption patterns and contribute to broader environ­
on second homes and private jets (Kleinhückelkotten et al., 2016). This
                                                                                              mental sustainability goals. However, this trend reverses at higher in­
dynamic reflects global studies indicating that income disparities often
                                                                                              come quantiles, where increasing income inequality correlates with a

                                                                                         18
B. Bergougui et al.                                                                                                  Journal of Cleaner Production 513 (2025) 145666


significant rise in CO2-EI. Studies reveal that income disparities at these        a negative effect at lower income levels to a positive one at higher levels.
levels have a profound impact on household carbon footprints (HCF).                This shift, far from being unexplained, reflects distinct economic be­
High-income households tend to have significantly larger carbon foot­              haviors and structural dynamics across the income distribution, which
prints due to their higher consumption levels and energy use. For                  we elucidate here and substantiate with external economic indicators.
instance, wealthier households often live in larger residences, own more           At lower income quantiles, rising income inequality is associated with a
electrical appliances, and have higher rates of automobile ownership, all          reduction in CO2-EI. This negative relationship stems from the con­
of which contribute to elevated CO2 emissions (Long et al., 2022).                 strained consumption patterns of low-income households, whose limited
Additionally, the widening of income inequality exacerbates the HCF                purchasing power restricts access to carbon-intensive goods and services
gap between socio-economic groups, indicating that disparities in                  such as vehicles, heating, or appliances. Evidence from Starr et al.
emissions grow more pronounced as inequality rises (Huang et al.,                  (2023) supports this: in 2019, the bottom 50 % of U.S. households by
2022). These findings underscore the critical need to integrate income             income contributed a disproportionately small share of emissions, while
distribution considerations into carbon mitigation policies. By address­           the top 10 % accounted for 40 % of the national total. As income
ing income inequality, policymakers can simultaneously work toward                 inequality widens in this segment, the emissions gap narrows because
reducing overall CO2 emissions and promoting environmental equity in               low earners remain anchored to minimal carbon footprints, while higher
Japan. This approach emphasizes the interconnectedness of economic                 earners diverge upward. In contrast, at higher income quantiles, the
structures, individual behaviors, and environmental outcomes,                      relationship reverses, with increasing income inequality amplifying
providing valuable insights for achieving sustainability in an increas­            CO2-EI. This positive shift arises from the disproportionate environ­
ingly unequal world.                                                               mental impact of affluent households, whose wealth enables extrava­
    The relationship between income inequality and CO2 emissions                   gant consumption—private jets, multiple residences, and luxury
inequality in Russia is complex and exhibits a notable nonlinear reversal          goods—that escalates emissions nonlinearly. Song et al. (2022) affirm
across income quantiles that reflects the nation’s unique domestic en­             this disparity, noting that the carbon footprints of the top 1 % vastly
ergy policies and socio-economic dynamics. At lower- and middle-                   outstrip those of even upper-middle-income groups. To validate this
income quantiles, greater income disparities are associated with                   trend externally, we point to the income-based emissions Gini coeffi­
reduced CO2-EI. This negative relationship can be largely attributed to            cient, which climbed from 0.51 in 1990 to 0.57 (producer-based) and
the limited consumption capacity of lower-income groups, who, due to               0.58 (supplier-based) by 2019 (Starr et al., 2023). This rise parallels the
constrained resources, have restricted access to energy-intensive goods            U.S. income Gini coefficient’s increase from 0.428 to 0.486 over the
and services. Furthermore, many middle-income households in Russia                 same period (U.S. Census Bureau, 2022), reflecting a tandem growth in
benefit from state-subsidized energy, which standardizes consumption               economic and emissions inequality, particularly among high earners.
patterns and further minimizes emissions differences within these                  The drivers of this shift are rooted in both theory and observable trends.
groups. However, the situation reverses at higher income quantiles,                The power-weighted social choice theory (Boyce, 1994) suggests that
where the relationship turns positive. Here, increased income inequality           wealthier individuals wield greater influence over environmental pol­
correlates with higher CO2-EI as affluent households engage in luxury              icies and resource allocation, perpetuating high-emission outcomes.
consumption behaviors—such as frequent air travel, large residential               Similarly, the Veblen effect (Veblen, 1899; Grunewald et al., 2017) links
spaces, and ownership of high-emission vehicles—that contribute                    income inequality to status-driven overconsumption and extended work
disproportionately to overall carbon emissions. This pattern is intensi­           hours among the affluent, further boosting energy use. These mecha­
fied by Russia’s heavy reliance on fossil fuels and resource extraction            nisms align with global patterns: Che et al. (2023) analyzed 65 countries
industries, where domestic energy policies, including generous energy              from 1990 to 2019 and found income inequality consistently increases
subsidies and limited incentives for renewable energy adoption,                    emissions, with the effect magnified in developed nations like the U.S.,
encourage a fossil fuel-driven economy. As a result, wealthy individuals           where consumption disparities are stark. U.S.-specific economic in­
are better positioned to take advantage of these policies, further                 dicators reinforce this narrative—per capita GDP grew from $23,889 in
amplifying emissions disparities. Moreover, domestic energy policies in            1990 to $65,605 in 2019 (World Bank, 2024), yet real wages for the
Russia, characterized by subsidized energy prices and a lack of aggres­            bottom 20 % stagnated (EPI, 2022), concentrating wealth and emissions
sive renewable energy initiatives, contribute to a structural imbalance            among the top tiers. This quantile-specific dynamic carries significant
that reinforces high emissions among the wealthy. Urban-rural dispar­              policy implications. The negative relationship at lower quantiles sug­
ities further complicate this relationship, as urban populations—where             gests that broad emissions reduction strategies may disproportionately
policy implementation and market dynamics differ from rural area­                  burden the poor unless paired with income support, while the positive
s—often exhibit higher levels of carbon-intensive consumption.                     link at higher quantiles underscores the need for targeted measur­
Addressing these challenges requires a multifaceted approach: imple­               es—such as carbon taxes scaled to income or luxury consumption—to
menting progressive taxation on luxury goods and carbon-intensive                  curb the outsized impact of the wealthy (Huang, 2024). Far from lacking
activities, reforming energy subsidies to promote cleaner technologies,            explanation or validation, our findings are contextualized by theoretical
and enhancing investments in renewable energy and green infrastruc­                frameworks and corroborated by external metrics like emissions and
ture. Such measures could help decouple income inequality from CO2-EI              income Gini coefficients, GDP trends, and wage data. These insights
by reducing the disproportionate impact of high-income consumption                 highlight the interplay of economic and environmental inequality, of­
while encouraging broader access to sustainable energy alternatives. In            fering a foundation for nuanced, equitable climate policies in the U.S.
summary, the nonlinear reversal observed in Russia’s model un­
derscores the critical role that domestic energy policies play in shaping          5.2. Comparative analysis across countries
emissions patterns. By contextualizing these dynamics within the
framework of Russia’s subsidized, fossil fuel-dependent energy system,                 A comparative review of the results across the six nations reveals
our analysis highlights the need for tailored policy interventions that            both commonalities and notable differences. In China, Russia, and the
address both economic and environmental disparities. Future research               United States, threshold effects are observed: income inequality initially
comparing Russia’s experience with that of other major emitters, like              appears to have a negative association with CO2-EI at lower quanti­
China and the United States, could further illuminate best practices for           les—suggesting that moderate disparities can lead to a more even dis­
integrating equity into climate strategies, ultimately fostering a more            tribution of emissions—but shifts to a strongly positive association as
sustainable future.                                                                inequality intensifies. These patterns indicate that, in these countries,
    The United States model reveals a nuanced, quantile-dependent                  once a critical income threshold is exceeded, the benefits of more
relationship between income inequality and CO2-EI, transitioning from              equitable energy consumption are outweighed by the disproportionate

                                                                              19
B. Bergougui et al.                                                                                                    Journal of Cleaner Production 513 (2025) 145666


environmental impacts of extreme wealth.                                            consumption habits of wealthier groups at higher quantiles. This im­
    Conversely, India and Germany exhibit distinct dynamics. India’s                plies that promoting sustainable behaviors across all income levels could
relationship with CO2-EI is characterized by a “W-shaped” pattern,                  enhance environmental equity. Together, these mechanisms reveal a
where the impact is pronounced at both the lowest and highest quantiles             complex, quantile-dependent relationship between income inequality
but less so in the middle. This suggests that both the poorest and the              and CO2-EI, emphasizing the need for tailored policies that address ac­
richest segments contribute disproportionately to emissions inequality,             cess to resources, consumption habits, governance quality, economic
potentially due to different mechanisms such as reliance on traditional             structures, and behavioral shifts to achieve both economic fairness and
fuels versus luxury consumption patterns. In Germany, governance                    environmental sustainability.
factors play a critical role, as indicated by the unique pattern where the
relationship between income inequality and CO2-EI shifts with changes               5.4. Synthesis with existing literature
in institutional performance and policy effectiveness. This governance
influence modulates the typical threshold effects seen elsewhere, high­                 The findings of this study align with and expand upon existing
lighting the importance of robust regulatory frameworks in mitigating               research exploring the relationship between income inequality and
environmental disparities.                                                          emissions inequality, drawing on several key studies to provide a
                                                                                    comprehensive comparison.
5.3. Underlying mechanisms driving emissions inequality                                 The World Inequality Report by Chancel et al. (2022) reveals that the
                                                                                    top 10 % of global emitters are responsible for nearly 50 % of total
    The relationship between income inequality and CO2 emissions                    emissions, while the bottom 50 % contribute just 12 %. This global
inequality (CO2-EI) varies across different quantiles and countries due to          disparity supports our observation of a positive correlation between
a combination of interconnected mechanisms that shape how economic                  income inequality and CO2 emissions inequality (CO2-EI) at high
disparities translate into environmental outcomes. These mechanisms                 quantiles across all six countries analyzed—China, the USA, Japan,
include access to clean energy and technologies, consumption patterns,              Russia, Germany, and India. In these nations, greater income inequality
policy and governance, economic structure, and behavioral adaptations,              amplifies CO2-EI, driven by the disproportionate emissions of wealthier
each playing a distinct yet overlapping role in driving these dynamics. At          individuals. For example, countries like China and the USA exemplify
lower levels of income inequality, more equitable income distribution               this trend, particularly at higher quantiles, where the emissions of the
often enables broader access to cleaner energy sources, such as elec­               affluent significantly outpace those of lower-income groups, mirroring
tricity instead of biomass, leading to a more uniform distribution of               the global pattern highlighted in the report. Research on household
emissions and reducing CO2-EI. For instance, in China, when income                  carbon footprints by Long et al. (2022) and Huang et al. (2022) further
inequality is low, equitable access to resources helps minimize emissions           corroborates our findings. These studies demonstrate that wealthier
disparities, whereas at higher levels of inequality, the poor lack access to        households have significantly larger carbon footprints due to higher
clean technologies while the rich adopt them, widening CO2-EI. This                 levels of consumption and energy use. This is consistent with the pat­
suggests that policies improving access to sustainable energy can                   terns we observed in Japan and Russia, where high quantiles exhibit
significantly reduce emissions inequality, particularly in societies with           increased CO2-EI linked to affluent lifestyles. In the USA, our analysis
less pronounced economic divides. Consumption patterns also play a                  reveals a notable shift: at lower quantiles, the relationship between in­
critical role, especially as income inequality increases. Higher inequality         come inequality and CO2-EI is negative, but it becomes positive at higher
often leads to conspicuous consumption by wealthier groups—think                    quantiles. This transition underscores the critical role of the household
luxury goods, larger homes, and frequent air travel—which dispropor­                carbon footprint (HCF) gap in driving emissions inequality, as wealthier
tionately boosts CO2-EI. In Germany, for example, the top 10 % drive                households’ consumption habits disproportionately elevate emissions.
emissions inequality at higher quantiles through air travel, while in the           Additionally, studies by Klein and Taconet (2024) and DIW Berlin
USA, the lavish lifestyles of high-income households amplify these dis­             (Bohmann and Küçük, 2024) emphasize the influence of high-income
parities. This highlights the need for targeted interventions aimed at              households’ travel patterns, particularly air travel, on emissions dis­
curbing the carbon-intensive behaviors of the affluent to address emis­             parities. Their research indicates that in Germany, the top 10 % of
sions inequality effectively. The influence of policy and governance                emitters produce double the per-capita emissions allowed under the
cannot be overstated. Strong environmental policies and effective                   Paris Agreement targets, largely due to frequent air travel. This aligns
governance can temper the impact of income inequality on CO2-EI by                  with our observation of a positive correlation between income
enforcing equitable regulations and incentivizing sustainable practices,            inequality and CO2-EI at high quantiles in Germany, where air travel
while weak governance tends to exacerbate disparities. Germany’s                    emerges as a key differentiator. In contrast, this pattern is less pro­
robust regulatory framework mitigates some of these effects, whereas in             nounced in contexts like India’s lower quantiles, where travel intensi­
Russia, lax environmental regulations allow high-income groups to in­               ty—and thus emissions from travel—remains relatively low,
crease CO2-EI unchecked at higher quantiles. This underscores the                   highlighting how regional differences in lifestyle and infrastructure
importance of strong governance in aligning economic equity with                    shape emissions inequality. Finally, research by Che et al. (2023) on
environmental sustainability. The economic structure of a country                   income inequality and emissions in developed countries finds that in­
further shapes these dynamics, as the sectors driving growth determine              come inequality has a positive impact on emissions, with a stronger
how income inequality affects CO2-EI. When economic growth benefits                 effect in nations like the USA. Our study’s findings for the USA at high
lower-income groups, emissions inequality may decrease, but when it                 quantiles corroborate this, showing that greater income inequality am­
favors the wealthy, disparities grow. In Japan, adaptive behaviors by               plifies CO2-EI as the wealthy contribute disproportionately to emissions.
middle- and lower-income groups reduce CO2-EI at lower quantiles,                   However, we also observed a negative relationship at lower quantiles in
while in India, the poor’s reliance on traditional fuels and the rich’s             the USA, suggesting a unique threshold effect where income inequality
luxury consumption create a complex W-shaped pattern. This suggests                 may suppress emissions inequality among lower-income groups. This
that diversifying economies into less carbon-intensive sectors could help           nuance, less evident in broader studies like Che et al.’s, underscores the
balance these effects. Finally, behavioral adaptations driven by eco­               importance of quantile-specific analysis in understanding the complex
nomic pressures can lead to more sustainable practices among lower-                 dynamics of the income inequality–CO2-EI nexus.
and middle-income groups, such as improved energy efficiency or
reduced consumption, which can lower CO2-EI when inequality is
moderate. In Japan, for instance, constraint-driven sustainability at
lower quantiles reduces emissions inequality, in contrast to the high-

                                                                               20
B. Bergougui et al.                                                                                                  Journal of Cleaner Production 513 (2025) 145666


6. Conclusion, policy caveats, limitations and future research                      redirected toward renewable energy projects and equitable climate
                                                                                    programs that support low- and middle-income groups. Additionally,
6.1. Conclusion                                                                     public investments in green energy access and supply, combined with
                                                                                    incentives for green housing construction and energy-efficient technol­
     A growing body of research has explored the relationship between               ogies, should ensure that all societal segments—particularly low-income
income inequality and climate change, yet relatively little has focused             households—benefit from the energy transition. These measures
on the interplay between income inequality and climate inequality, as               collectively highlight the need for inclusive, equitable, and context-
measured by CO2 emissions inequality. Most studies on the latter either             specific climate policies to tackle both economic and environmental
rely on descriptive statistics or methodologies that emphasize mean ef­             disparities while advancing a sustainable future.
fects, leaving substantial gaps in understanding the nuanced dynamics.
This study addresses this gap by investigating the critical relationship            6.2. Policy Caveats
between income inequality and climate inequality from
1980M1–2023M12 in the six largest emitter nations. Specifically, it                    The relationship between income inequality and CO2 emissions
examines how income inequality asymmetrically influences carbon                     inequality varies significantly across nations, reflecting their unique
inequality in these economies. This research distinguishes itself through           regulatory environments, economic structures, and socio-economic
its innovative application of quantile-based methodologies, which offer             contexts. Based on individual findings, the following country-specific
detailed insights across different temporal periods and distribution                policy recommendations are proposed.
quantiles—an underutilized approach in this area of study. Advanced
statistical frameworks such as the multivariate quantile-on-quantile                 • In China, policy must blend equity with sustainability to address its
regression (MQQR) and wavelet quantile regression (WQR) were                           rapidly developing yet regionally diverse framework. Recognizing
employed to capture nonlinearities in the dataset, while instrumental                  decentralized enforcement across urban and rural areas, China
variable quantile regression (IVQR) was applied to address potential                   should expand rural renewable energy infrastructure—such as sub­
endogeneity. Complementary robustness checks using multivariate                        sidized solar microgrids and wind farms—to preserve the equitable
quantile regression (MQR) and kernel-based regularized least squares                   emissions distribution observed at lower quantiles. Additionally,
(KRLS) further enhance the credibility of the findings.                                introducing progressive carbon taxation on luxury goods like private
     The analysis reveals a complex, nonlinear relationship between in­                jets and oversized residences can help curb the emissions driven by
come inequality and CO2 emissions inequality across countries, char­                   affluent urban elites. Rather than adopting a one-size-fits-all mea­
acterized by thresholds and varying patterns. In China and Russia,                     sure, China should centralize environmental governance and inte­
negative correlations at lower quantiles shift to positive correlations at             grate equity metrics into its carbon neutrality roadmap through
higher quantiles, indicating that while moderate income disparities may                measures like mandatory emissions audits for state-owned enter­
initially promote equitable emissions distribution, extreme inequality                 prises and pilot programs linking income support to green technol­
worsens emissions inequity. Germany exhibits a similar trend, where the                ogy adoption.
mitigating effects of income equality weaken at higher quantiles. India              • In Germany, a mature regulatory environment and strong institu­
displays a unique W-shaped relationship, highlighting sensitivity to both              tional frameworks allow for targeted measures to address the pro­
extreme low and high levels of income disparities. Japan shows a                       nounced emissions inequality among the top 10 % of earners. By
gradual transition from negative to positive effects, underscoring a                   leveraging robust administrative capacity, Germany can introduce
critical inflection point where the impact of income inequality on                     income-scaled aviation taxes that increase with flight frequency and
emissions shifts. The United States demonstrates a strong nonlinear                    class, discouraging excessive luxury travel. A property surcharge on
pattern, with negative effects at lower quantiles reversing to positive                secondary homes—calculated by energy consumption and square
effects at higher levels, signaling that extreme income inequality can                 footage—would further incentivize efficiency and generate funds for
aggravate emissions inequity. These findings align with previous                       retrofitting low-income housing. At a European level, harmonizing
descriptive analyses (Chancel, 2022; Chancel et al., 2022, 2023). Tem­                 emissions caps for high-net-worth households, including carbon
poral and quantile-specific dynamics, as captured through WQR, further                 budgets for private jet ownership, can align national efforts with
illuminate the heterogeneity in these relationships. In China, India,                  broader climate goals while ensuring that revenue supports public
Japan, and Russia, income inequality consistently drives higher CO2                    transit and renewable energy access for vulnerable populations.
emissions inequality over time, with its effects intensifying at higher              • For India, characterized by significant urban–rural disparities and
emissions levels. Conversely, Germany demonstrates a persistently                      rapid urbanization, policies must address both energy poverty and
negative relationship, suggesting that its policies effectively mitigate the           the emissions stemming from luxury consumption. India should
impact of income inequality on emissions inequity, even in the long                    pursue decentralized renewable energy solutions like village-level
term. The United States, however, experiences a dynamic reversal,                      solar microgrids paired with microloans to reduce reliance on
where short-term reductions in emissions inequality due to moderate                    biomass in rural areas. In urban centers such as Delhi and Bangalore,
inequality eventually give way to long-term increases, highlighting the                implementing emissions zoning with stricter carbon caps on affluent
difficulty of maintaining effective interventions.                                     districts can directly target high-end consumption. A calibrated na­
     Building on these findings, it is evident that policy interventions               tional luxury goods tax on items like SUVs, air conditioners, and
must address the interconnected challenges of income inequality and                    international travel would help finance clean energy transitions,
climate inequality. To ensure equitable contributions to climate action                while tiered electricity pricing protects low-income households.
across all income groups, policymakers should implement a compre­                      Integrating these initiatives into the National Clean Air Program and
hensive strategy. Wealth or corporate taxes with pollution top-ups can                 Smart Cities Mission ensures that policies resonate with India’s socio-
generate funds for green investments and accelerate the transition away                economic realities.
from fossil fuels, while bans on new fossil fuel investments and stricter            • In Japan, where cultural norms of efficiency and resourcefulness
divestment measures must be prioritized to promote decarbonization.                    play a crucial role, expanding tax credits for retrofitting older homes
Regulations on emissions-intensive consumption, such as taxes or pen­                  and adopting electric vehicles can reward sustainable practices
alties on the purchase of SUVs and air travel, should target high-income               among middle- and low-income households. For high-income
groups, complemented by innovative tools like carbon cards to track and                groups, implementing a progressive carbon tax on luxury
cap personal carbon footprints. Fossil fuel subsidies, which dispropor­                assets—such as second homes and high-emission vehicles—can
tionately benefit wealthier populations, must be phased out and                        directly address excessive emissions. Revitalizing initiatives like the

                                                                               21
B. Bergougui et al.                                                                                                   Journal of Cleaner Production 513 (2025) 145666


   Cool Biz campaign with year-round energy-saving incentives (e.g.,                   elsewhere. Behavioral incentives are broadly applicable but require
   subsidies for heat pumps) leverages Japan’s cultural strengths, while               cultural tailoring.
   corporate governance reforms, such as mandating emissions-linked                  • Barriers: Potential obstacles include elite resistance (e.g., fossil fuel
   executive bonuses, encourage firms to align with national climate                   lobbies), economic constraints (e.g., prioritizing poverty alleviation
   goals without imposing a uniform tax burden.                                        over environmental policies), infrastructure gaps (e.g., lack of
 • Russia’s policy approach must contend with a regulatory environ­                    renewable energy infrastructure), cultural resistance (e.g., consum­
   ment still heavily influenced by fossil fuel subsidies and centralized              erism), and weak governance structures.
   energy markets. To dismantle support for elite emissions, Russia                  • Trade-offs: Policymakers must balance economic growth with eq­
   should gradually redirect subsidies from oil and gas to rural solar and             uity, manage short-term costs against long-term gains, navigate in­
   wind projects, thereby democratizing energy access. Instead of                      dividual freedoms versus collective goals, address urban-rural
   relying solely on market-based mechanisms, regulating luxury                        disparities, and consider global competitiveness when designing and
   imports—such as high-emission vehicles and private jets—through                     implementing these policies.
   bans or strict limits is critical. Establishing urban–rural equity funds,
   financed by progressive carbon taxes on luxury real estate, offers a                To overcome barriers, policymakers should adopt incremental
   pathway to finance green infrastructure in underserved regions.                  approaches—piloting luxury taxes in regions like California or part­
   Complementary measures, such as strengthening the legal standing                 nering with firms like Siemens for renewable projects. International
   of environmental NGOs and enhancing transparency through public                  funding, via the Green Climate Fund, can alleviate fiscal pressures in
   emissions disclosures, are essential for a gradual transition toward             developing nations. Public-private partnerships and culturally resonant
   decarbonization.                                                                 campaigns, emphasizing communal benefits in Japan and individual
 • In the United States, the policy framework must navigate both                    savings in the USA, enhance engagement. Compensatory mechanisms,
   market-driven emissions and entrenched political influences.                     such as grants for transitioning industries, ensure stakeholder buy-in
   Aggressive carbon pricing should be paired with robust equity safe­              while mitigating displacement risks.
   guards to address the dichotomy between low-income households
   and high-emission elites. A federal carbon dividend program that                 6.3. Limitations of the study and opportunities for future research
   redistributes a significant portion of carbon tax revenue to low-
   income households can offset rising energy costs, while legislating                  This study offers valuable insights into the relationship between in­
   annual carbon budgets for high earners—enforced through registries               come inequality and CO2 emissions inequality, yet it is subject to several
   of luxury assets—would specifically cap discretionary emissions.                 limitations that merit careful scrutiny and present opportunities for
   Rather than replicating measures from other countries, the U.S.                  further exploration.
   should embed environmental justice mandates into existing legisla­
   tion (such as the Inflation Reduction Act) by prioritizing renewable              • One primary constraint is its predominant reliance on aggregate
   projects in marginalized communities. Additionally, culturally                      country-level data, which, while useful for cross-national compari­
   attuned strategies—like promoting electric vehicles as status sym­                  sons, risks glossing over significant intra-national disparities. For
   bols and reforming campaign finance laws to limit fossil fuel lob­                  example, within nations like China or the USA, pronounced regional
   bying—are necessary to address elite influence on climate policy.                   differences—such as urban-rural divides or state-specific policy
                                                                                       variations—could substantially shape emissions patterns in ways this
    These country-specific strategies are underpinned by a broader set of              analysis does not fully address. Urban centers might exhibit higher
approaches essential for reducing CO2 emissions inequality. Addressing                 per capita emissions due to concentrated wealth and industrial ac­
the mechanisms driving emissions disparities requires a combination of                 tivity, whereas rural areas may rely on less efficient energy sources,
progressive taxation, targeted clean energy subsidies, regulation of                   amplifying CO2-EI disparities. To overcome this, future research
luxury consumption, and strengthened governance. Reducing income                       could harness subnational datasets, such as provincial income sta­
inequality is a foundational step, especially at higher income quantiles               tistics in China or municipal emissions records in the USA, to illu­
where extreme disparities facilitate lavish, high-emission lifestyles.                 minate these localized dynamics and provide a more detailed picture
Enhancing clean energy access is crucial to preserve the benefits seen at              of how inequality influences emissions within countries.
lower quantiles, ensuring disadvantaged groups have affordable alter­                • Another limitation arises from the study’s focus on income inequality
natives to high-emission sources.                                                      as a key driver of CO2-EI, which, while significant, does not
    However, carbon pricing and redistribution policies could have                     encompass the full range of factors that may contribute to emissions
regressive effects on lower-income groups, yet this is ignored. While                  inequality. Cultural norms, such as consumer preferences for high-
carbon pricing aims to reduce emissions, it often disproportionately                   emission lifestyles (e.g., car ownership or meat-heavy diets), tech­
burdens those who spend a larger share of their income on energy-                      nological adoption rates (e.g., the penetration of renewable energy
related expenses. Without adequate compensation mechanisms, such                       or electric vehicles), and political institutions (e.g., the strength of
as direct rebates or investments in affordable clean energy alternatives,              regulatory enforcement) could also play pivotal roles. For instance,
these policies risk exacerbating existing inequalities rather than allevi­             in car-dependent societies like the USA, cultural resistance to sus­
ating them. Future research and policy design must consider these                      tainable alternatives might exacerbate emissions inequality, while in
regressive impacts to ensure that efforts to combat climate change do not              Germany, robust technological advancements might mitigate it.
come at the expense of economic justice for vulnerable populations.                    Incorporating these variables into future analyses could yield a
    Implementing these strategies requires careful consideration of                    richer, more nuanced understanding of the interplay between so­
feasibility, potential barriers, and associated trade-offs.                            cioeconomic disparities and environmental outcomes, revealing
                                                                                       additional pathways through which CO2-EI manifests and evolves.
 • Feasibility: Progressive taxation may align with institutional frame­             • The study’s exclusion of smaller emitter countries—such as Scandi­
   works in countries like Germany but face resistance in others. Clean                navian nations with high renewable energy use or small-island
   energy subsidies are viable in nations with strong renewable sectors,               developing states facing unique climate vulnerabilities—further re­
   while luxury taxes may be more challenging to implement in                          stricts the generalizability of its findings. These countries often
   developing countries. Governance reforms are feasible in nations                    feature distinct economic structures (e.g., service-based economies),
   with stable institutions but may require significant overhauls                      policy frameworks (e.g., aggressive decarbonization targets), and
                                                                                       emission profiles (e.g., reliance on hydropower or susceptibility to

                                                                               22
B. Bergougui et al.                                                                                                     Journal of Cleaner Production 513 (2025) 145666


   sea-level rise) that could either reinforce or challenge the patterns        Investigation, Formal analysis, Conceptualization. Ousama Ben-Salha:
   observed among major emitters. Including such cases in future                Writing – review & editing, Writing – original draft, Validation, Inves­
   research would not only test the robustness of the identified re­            tigation. Syed Mansoob Murshed: Writing – original draft, Methodol­
   lationships across diverse contexts but also enhance the study’s             ogy, Conceptualization.
   relevance for global climate policy. For example, examining whether
   income inequality drives CO2-EI similarly in a renewable-heavy               Declaration of competing interest
   economy like Norway could broaden the applicability of the
   conclusions.                                                                     The authors declare that they have no known competing financial
 • Additionally, the study’s use of yearly data, converted into monthly         interests or personal relationships that could have appeared to influence
   intervals, may oversimplify the temporal dynamics that influence             the work reported in this paper.
   emissions inequality. This approach could obscure short-term fluc­
   tuations or lagged effects that are critical to understanding CO2-EI.        Acknowledgement
   For instance, seasonal spikes in energy demand (e.g., winter heating
   in Russia) or abrupt income shocks (e.g., unemployment surges                   The authors extend their appreciation to Northern Border University,
   during economic downturns) might disproportionately impact                   Saudi Arabia, for supporting this work through project number (NBU-
   lower-income quantiles, altering their emissions contributions in            CRP-2025-2922).
   ways annual aggregates fail to capture. Transitioning to actual
   monthly or daily datasets—such as real-time energy consumption               Data availability
   metrics from smart grids, daily income fluctuation records, or
   satellite-based emissions tracking—would offer greater precision.                Data will be made available on request.
   This shift could reveal how temporal factors, like monthly weather
   patterns or economic cycles, interact with income inequality to shape
                                                                                References
   emissions, enabling more timely and targeted policy interventions.
 • Finally, by concentrating on six major emitters—Germany, India,              Abdullah, A., Doucouliagos, H., Manning, E., 2015. Does education reduce income
   China, the USA, Russia, and Japan—the study adopts a pragmatic yet               inequality? A meta-regression analysis. J. Econ. Surv. 29 (2), 301–316. https://doi.
                                                                                    org/10.1111/joes.12056.
   limited scope that overlooks transnational interactions, such as car­
                                                                                Acemoglu, D., Naidu, S., Restrepo, P., Robinson, J.A., 2015. Democracy, redistribution,
   bon leakage or emissions embedded in global supply chains.                       and inequality. In: Atkinson, A.B., Bourguignon, F. (Eds.), Handbook of Income
   Wealthier nations might outsource carbon-intensive production to                 Distribution, vol. 2. Elsevier, pp. 1885–1966. https://doi.org/10.1016/B978-0-444-
   poorer ones, skewing domestic CO2-EI figures while shifting envi­                59429-7.00022-4.
                                                                                Adebayo, T.S., 2022. Environmental consequences of fossil fuel in Spain amidst
   ronmental burdens internationally. Future research could adopt a                 renewable energy consumption: a new insights from the wavelet-based granger
   multi-scalar approach, integrating national data with international              causality approach. Int. J. Sustain. Dev. World Ecol. 29 (7), 579–592. https://doi.
   trade and investment flows, to account for these complexities. For               org/10.1080/13504509.2022.2054877.
                                                                                Adebayo, T.S., Özkan, O., 2024. Evaluating the role of financial globalization and oil
   instance, analyzing how China’s exports or the USA’s imports in­                 consumption on ecological quality: a new perspective from quantile-on-quantile
   fluence global emissions inequality could provide a more compre­                 granger causality. Heliyon 10 (2), e24636. https://doi.org/10.1016/j.heliyon.2024.
   hensive view of the income-CO2-EI nexus.                                         e24636.
                                                                                Ahmad, S., Baiocchi, G., Creutzig, F., 2015. CO2 emissions from direct energy use of
                                                                                    urban households in India. Environ. Sci. Technol. 49 (19), 11312–11320.
   To mitigate these limitations and enhance the study’s framework,             Andersson, F.N.G., 2023. Income inequality and carbon emissions in the United States
researchers could pursue several strategies.                                        1929–2019. Ecol. Econ. 204, 107633. https://doi.org/10.1016/j.
                                                                                    ecolecon.2022.107633.
                                                                                Wealth inequality and carbon inequality. In: Apeti, A.E., Bambe, B.W.W., Edoh, E.D.,
 • First, leveraging subnational data—such as Germany’s state-level                 Ly, A. (Eds.), Ecol. Econ. 227, 108406. https://doi.org/10.1016/j.
   emissions registries or India’s district-wise income surveys—would               ecolecon.2024.108406.
                                                                                Arora, R.U., 2014. Inequality in carbon emissions at sub-national level in India.
   unpack regional disparities and offer a finer resolution of CO2-EI
                                                                                    J. Develop. Area. 48 (2), 383–397. https://doi.org/10.1353/jda.2014.0038.
   patterns.                                                                    Baležentis, T., Liobikienė, G., Štreimikienė, D., Sun, K., 2020. The impact of income
 • Second, adopting mixed methods approaches, which combine                         inequality on consumption-based greenhouse gas emissions at the global level: a
   quantitative data with qualitative insights into cultural norms and              partially linear approach. J. Environ. Manag. 267, 110635. https://doi.org/
                                                                                    10.1016/j.jenvman.2020.110635.
   institutional factors, could deepen the analysis; for example, in­           Baloch, M.A., Danish, Khan, S.U.-D., Ulucak, Z.Ş., Ahmad, A., 2020. Analyzing the
   terviews or surveys could elucidate how consumer attitudes or                    relationship between poverty, income inequality, and CO2 emission in Sub-Saharan
   governance quality mediate emissions outcomes.                                   African countries. Sci. Total Environ. 740, 139867. https://doi.org/10.1016/j.
                                                                                    scitotenv.2020.139867.
 • Third, collaborating with international databases, such as the World         Barra, C., Zotti, R., 2018. Investigating the non-linearity between national income and
   Bank’s subnational climate portals, would enable the inclusion of                environmental pollution: international evidence of Kuznets curve. Environ. Econ.
   smaller emitter countries, improving representativeness and testing              Pol. Stud. 20 (1), 179–210. https://doi.org/10.1007/s10018-017-0189-2.
                                                                                Bergougui, B., 2024a. Algeria’s pathway to COP28 and SDGs: asymmetric impact of
   the findings across varied economic and environmental contexts.                  environmental technology, energy productivity, and material resource efficiency on
 • Fourth, shifting to real-time data streams—like satellite-based                  environmental sustainability. Energy Strategy Rev. 55, 101541. https://doi.org/
   emissions monitoring or daily energy usage reports—would cap­                    10.1016/j.esr.2024.101541.
                                                                                Bergougui, B., 2024b. Moving toward environmental mitigation in Algeria: asymmetric
   ture temporal granularity, revealing short-term drivers and
                                                                                    impact of fossil fuel energy, renewable energy and technological innovation on CO2
   enhancing the precision of policy recommendations.                               emissions. Energy Strategy Rev. 51, 101281. https://doi.org/10.1016/j.
                                                                                    esr.2023.101281.
                                                                                Bergougui, B., 2024c. Investigating the relationships among green technologies, financial
   By addressing these gaps, subsequent research could deliver a more
                                                                                    development and ecological footprint levels in Algeria: evidence from a novel fourier
holistic, actionable, and globally relevant framework for tackling in­              ARDL approach. Sustain. Cities Soc. 112, 105621. https://doi.org/10.1016/j.
come and emissions inequality, building on the foundation established               scs.2024.105621.
here.                                                                           Bergougui, B., Aldawsari, M.I., 2024. Asymmetric impact of patents on green
                                                                                    technologies on Algeria’s ecological future. J. Environ. Manag. 355, 120426.
                                                                                    https://doi.org/10.1016/j.jenvman.2024.120426.
CRediT authorship contribution statement                                        Bergougui, B., Meziane, S., 2025. Assessing the impact of green energy transition,
                                                                                    technological innovation, and natural resources on load capacity factor in Algeria:
                                                                                    evidence from dynamic autoregressive distributed lag simulations and machine
   Brahim Bergougui: Writing – review & editing, Writing – original                 learning validation. Sustainability 17 (5), 1815. https://doi.org/10.3390/
draft, Visualization, Validation, Supervision, Software, Methodology,               su17051815.


                                                                           23
B. Bergougui et al.                                                                                                                            Journal of Cleaner Production 513 (2025) 145666

Bergougui, B., Satrovic, E., 2025. Towards eco-efficiency of OECD countries: how does                Ferwerda, J., Hainmueller, J., Hazlett, C.J., 2017. Kernel-based regularized least squares
    environmental governance restrain the destructive ecological effect of the excess use                 in R (KRLS) and Stata (krls). J. Stat. Software 79 (3 SE-Articles), 1–26. https://doi.
    of natural resources? Ecol. Inform. 87, 103093. https://doi.org/10.1016/j.                            org/10.18637/jss.v079.i03.
    ecoinf.2025.103093.                                                                              Figueroa, R.M., 2022. Environmental justice. In: The Routledge Companion to
Bergougui, B., Zambrano-Monserrate, M.A., 2025. Assessing the relevance of the granger                    Environmental Ethics. Routledge, pp. 767–782.
    non-causality test for energy policymaking: theoretical and empirical insights.                  Fragkos, P., Fragkiadakis, K., Sovacool, B., Paroussos, L., Vrontisi, Z., Charalampidis, I.,
    Energy Strategy Rev. 59, 101743. https://doi.org/10.1016/j.esr.2025.101743.                           2021. Equity implications of climate policy: assessing the social and distributional
Bergougui, B., Boudjana, R.H., Mehibel, S., Zambrano-Monserrate, M.A., 2024a. How do                      impacts of emission reduction targets in the European Union. Energy 237, 121591.
    institutional quality and income asymmetrically affect carbon emissions inequality?                   https://doi.org/10.1016/J.ENERGY.2021.121591.
    A quantile-on-quantile assessment for six major global emitters. J. Clean. Prod.,                Gazzotti, P., Emmerling, J., Marangoni, G., Castelletti, A., van der Wijst, K.-I., Hof, A.,
    144215 https://doi.org/10.1016/j.jclepro.2024.144215.                                                 Tavoni, M., 2021. Persistent inequality in economically optimal climate policies.
Bergougui, B., Doğan, B., Ghosh, S., Ayad, H., 2024b. Impact of environmental                            Nat. Commun. 12 (1), 3421. https://doi.org/10.1038/s41467-021-23613-y.
    technology, economic complexity, and geopolitical risk on carbon emission                        Global Carbon Budget, 2024. – with major processing by Our World in Data. Annual CO₂
    inequality in developed and developing countries: evidence from a PVAR-GMM                            emissions. Global Carbon Project.
    approach. Environ. Dev. Sustain. https://doi.org/10.1007/s10668-024-05715-x.                     Gössling, S., Humpe, A., 2023. Millionaire spending incompatible with 1.5 ◦ C ambitions.
Bergougui, B., Mehibel, S., Boudjana, R.H., 2024c. Asymmetric nexus between green                         Clean. Prod. Lett 4, 100027. https://doi.org/10.1016/j.clpl.2022.100027.
    technologies, economic policy uncertainty, and environmental sustainability:                     Guo, Y., You, W., Lee, C.-C., 2022. CO2 emissions, income inequality, and country risk:
    evidence from Algeria. J. Environ. Manag. 360, 121172. https://doi.org/10.1016/j.                     some international evidence. Environ. Sci. Pollut. Control Ser. 29 (9), 12756–12776.
    jenvman.2024.121172.                                                                                  https://doi.org/10.1007/s11356-020-09501-w.
Berthe, A., Elie, L., 2015. Mechanisms explaining the impact of economic inequality on               Grunewald, N., Klasen, S., Martínez-Zarzoso, I., Muris, C., 2017. The trade-off between
    environmental deterioration. Ecological Economics 116, 191–200.                                       income inequality and carbon dioxide emissions. Ecological Economics 142,
Bohmann, S., Küçük, M., 2024. High-income households emit more greenhouse gases,                          249–256.
    primarily due to transport behavior. DIW Weekly Report 14 (27), 179–186.                         Hnatyuk, V., Pshenychna, N., Kara, S., Kolodii, V., Yaroshchuk, L., 2024. Education’s role
Boyce, J.K., 1994. Inequality as a cause of environmental degradation. Ecol. Econ. 11 (3),                in fostering environmental awareness and advancing sustainable development
    169–178. https://doi.org/10.1016/0921-8009(94)90198-8.                                                within a holistic framework. Mult Rev. 7. https://doi.org/10.31893/
Boyce, J.K., Klemer, A.R., Templet, P.H., Willis, C.E., 1999. Power distribution, the                     multirev.2024spe012.
    environment, and public health: A state-level analysis. Ecological Economics 29 (1),             Huang, W.H., 2015. The determinants of household electricity consumption in Taiwan:
    127–140.                                                                                              evidence from quantile regression. Energy 87, 120–133. https://doi.org/10.1016/j.
Broock, W.A., Scheinkman, J.A., Dechert, W.D., LeBaron, B., 1996. A test for                              energy.2015.04.101.
    independence based on the correlation dimension. Econom. Rev. 15 (3), 197–235.                   Huang, X., 2024. Harness the Co-Benefit and avoid the trade-off: the complex
    https://doi.org/10.1080/07474939608800353.                                                            relationship between income inequality and carbon dioxide emissions. Soc. Forces
Bruckner, B., Hubacek, K., Shan, Y., Zhong, H., Feng, K., 2022. Impacts of poverty                        103 (2), 403–428. https://doi.org/10.1093/sf/soae074.
    alleviation on national and global carbon emissions. Nat. Sustain. 5 (4), 311–320.               Huang, Y.Y., Shen, L., Zhang, C., 2022. Home-country government support, the belt and
    https://doi.org/10.1038/s41893-021-00842-z.                                                           road initiative, and the foreign performance of Chinese state-owned subsidiaries.
Cayla, J.M., Maizi, N., Marchand, C., 2011. The role of income in energy consumption                      Asia Pac. J. Manag. 39 (3), 1023–1049. https://doi.org/10.1007/s10490-020-
    behaviour: evidence from French households data. Energy Policy 39 (12),                               09743-9.
    7874–7883. https://doi.org/10.1016/j.enpol.2011.09.036.                                          Huang, Z., Duan, H., 2020. Estimating the threshold interactions between income
Chancel, L., 2022. Global carbon inequality over 1990–2019. Nat. Sustain. 5 (11),                         inequality and carbon emissions. J. Environ. Manag. 263, 110393. https://doi.org/
    931–938. https://doi.org/10.1038/s41893-022-00955-z.                                                  10.1016/j.jenvman.2020.110393.
Chancel, L., Piketty, T., Saez, E., Zucman, G., Duflo, E., Banerjee, A., 2022. Global                IPCC, 2022. IPCC Sixth Assessment Report - Synthesis Report, vol. 2023.
    Inequality Report 2022. World Inequality Lab, pp. 1–236 wir2022.wid.world.                            Intergovernmental Panel on Climate Change.
Chancel, L., Bothe, P., Voituriez, T., 2023. Climate inequality report 2023, fair taxes for a        Jorgenson, A., Schor, J., Huang, X., 2017. Income inequality and carbon emissions in the
    sustainable future in the global South. World Inequality Lab (WIL).                                   United States: a state-level analysis, 1997–2012. Ecol. Econ. 134, 40–48. https://doi.
Chancel, L., Piketty, T., Saez, E., Zucman, G., Duflo, E., Banerjee, A., 2022. Global                     org/10.1016/j.ecolecon.2016.12.016.
    Inequality Report 2022, wir2022.wid. World Inequality Labworld, pp. 1–236.                       Kaplan, D.M., Sun, Y., 2017. Smoothed estimating equations for instrumental variables
Che, C., Li, S., Yin, Q., Li, Q., Geng, X., Zheng, H., 2023. Does income inequality have a                quantile regression. Econom. Theory 33 (1), 105–157. https://doi.org/10.1017/
    heterogeneous effect on carbon emissions between developed and developing                             S0266466615000407.
    countries? Evidence from simultaneous quantile regression. Front. Environ. Sci. 11.              Kenner, D., 2019. Carbon Inequality: the Role of the Richest in Climate Change.
    https://www.frontiersin.org/journals/environmental-science/articles/10.3389/fe                        Routledge.
    nvs.2023.1271457.                                                                                Khalfan, A., Nilsson Lewis, A., Aguilar, C., Persson, J., Lawson, M., Dabi, N., Jayoussi, S.,
Chernozhukov, V., Hansen, C., 2008. Instrumental variable quantile regression: a robust                   Acharya, S., 2023. Climate equality: a planet for the 99. https://doi.org/10.21201/
    inference approach. J. Econom. 142 (1), 379–398. https://doi.org/10.1016/j.                           2023.000001.
    jeconom.2007.06.005.                                                                             Klein, F., Taconet, N., 2024. Unequal ‘drivers’: on the inequality of mobility emissions in
Churchill, S.A., Ivanovski, K., Munyanyi, M.E., 2021. Income inequality and renewable                     Germany. Energy Econ. 136, 107630. https://doi.org/10.1016/j.
    energy consumption: time-varying non-parametric evidence. J. Clean. Prod. 296,                        eneco.2024.107630.
    126306. https://doi.org/10.1016/j.jclepro.2021.126306.                                           Kleinhückelkotten, S., Neitzke, H., Moser, S., 2016. Repräsentative Erhebung Von Pro-
Connolly, M., Shan, Y., Bruckner, B., Li, R., Hubacek, K., 2022. Urban and rural carbon                   Kopf-Verbräuchen Natürlicher Ressourcen in Deutschland (Nach
    footprints in developing countries. Environ. Res. Lett. 17 (8), 084005. https://doi.                  Bevölkerungsgruppen).
    org/10.1088/1748-9326/ac7c2a.                                                                    Knight, K.W., Schor, J.B., Jorgenson, A.K., 2017. Wealth inequality and carbon emissions
Cooper, K., Stewart, K., 2021. Does household income affect children’s outcomes? A                        in high-income countries. Soc. Curr. 4 (5), 403–412. https://doi.org/10.1177/
    systematic review of the evidence. Child Indic. Res. 14 (3), 981–1005. https://doi.                   2329496517704872.
    org/10.1007/s12187-020-09782-0.                                                                  Konc, T., Drews, S., Savin, I., Van Den Bergh, J.C., 2022. Co-dynamics of climate policy
Daway-Ducanes, S.L.S., Pernia, E.E., Ramos, V.J.R., 2022. On the “income advantage” in                    stringency and public support. Glob. Environ. Change 74, 102528. https://doi.org/
    course choices and admissions: evidence from the University of the Philippines. Int.                  10.1016/j.gloenvcha.2022.102528.
    J. Educ. Dev. 91, 102578. https://doi.org/10.1016/j.ijedudev.2022.102578.                        Kumar, A.S., Padakandla, S.R., 2022. Testing the safe-haven properties of gold and
Demir, C., Cergibozan, R., Gök, A., 2019. Income inequality and CO2 emissions:                           bitcoin in the backdrop of COVID-19: a wavelet quantile correlation approach.
    empirical evidence from Turkey. Energy Environ. 30 (3), 444–461. https://doi.org/                     Finance Res. Lett. 47, 102707. https://doi.org/10.1016/j.frl.2022.102707.
    10.1177/0958305X18793109.                                                                        Kunche, S., Prabha, D., Yadav, S., Ahire, P.P., Ramdas, S., Khan, M.S.A., 2024.
Doğan, B., Tiwari, S., Bergougui, B., Ghosh, S., Balsalobre-Lorente, D., 2025. Green                     Understanding the barriers to environmental education in developing countries. Int.
    innovation and fiscal spending: decoding the path to sustainable development.                         Electron. J. Environ. Educ. 14 (1), 44–52. https://doi.org/10.52783/iejee.v14.102.
    Sustain. Dev. https://doi.org/10.1002/sd.3464 n/a(n/a).                                          Li, G., Li, Y., Tsai, C.-L., 2015. Quantile correlations and quantile autoregressive
Dong, K., Ni, G., Taghizadeh-Hesary, F., Zhao, C., 2023. Does smart transportation                        modeling. J. Am. Stat. Assoc. 110 (509), 246–261. https://doi.org/10.1080/
    matter in inhibiting carbon inequality? Energy Economics 126, 106952. https://doi.                    01621459.2014.892007.
    org/10.1016/j.eneco.2023.106952.                                                                 Liu, Y., Lin, B., Xu, B., 2021. Modeling the impact of energy abundance on economic
Dorn, F., Maxand, S., Kneib, T., 2024. The nonlinear dependence of income inequality                      growth and CO2 emissions by quantile regression: Evidence from China. Energy 227,
    and carbon emissions: potentials for a sustainable future. Ecol. Econ. 216, 108016.                   120416. https://doi.org/10.1016/j.energy.2021.120416.
    https://doi.org/10.1016/j.ecolecon.2023.108016.                                                  Long, Y., Yoshida, Y., Huang, L., Gasparatos, A., 2022. Carbon footprint differentiation in
Estrada-Araoz, E.G., Gallegos Ramos, N.A., Paredes Valverde, Y., Quispe Herrera, R.,                      the Japanese residential sector due To income-driven divergences in consumption
    Mori Bazán, J., 2023. Examining the relationship between environmental education                     and time allocation. Earths Future 10 (10), e2022EF002954. https://doi.org/
    and pro-environmental behavior in regular basic education students: a cross-                          10.1029/2022EF002954.
    sectional study. Soc. Sci. 12 (5), 307. https://doi.org/10.3390/socsci12050307.                  Lynch, K., O’riordan, C., 1998. Inequality in higher education: a study of class barriers.
Fernández, J.A.F., Cano, M.Á.C., Gómez, S.Q., 2024. The interplay between carbon                       Br. J. Sociol. Educ. 19 (4), 445–478. https://doi.org/10.1080/0142569980190401.
    emissions and inequality: a complex networks approach. Environ. Sustain. Indic.,                 Mader, S., 2018. The nexus between social inequality and CO2 emissions revisited:
    100520 https://doi.org/10.1016/j.indic.2024.100520.                                                   challenging its empirical validity. Environ. Sci. Pol. 89, 322–329. https://doi.org/
Ferreira, F.H.G., 2021. Inequality in the time of COVID-19. Finance Dev. 58 (2), 20–23.                   10.1016/j.envsci.2018.08.009.




                                                                                                24
B. Bergougui et al.                                                                                                                        Journal of Cleaner Production 513 (2025) 145666

Mahalik, M.K., Patel, G., Sahoo, B.K., Rahman, M.M., 2023. Impact of income inequality            Song, K., Baiocchi, G., Feng, K., Hubacek, K., Sun, L., 2022. Unequal household carbon
    on renewable energy demand in south Asian economies. Energy Policy 180, 113628.                    footprints in the peak-and-decline pattern of U.S. greenhouse gas emissions. J. Clean.
    https://doi.org/10.1016/j.enpol.2023.113628.                                                       Prod. 368, 132650. https://doi.org/10.1016/j.jclepro.2022.132650.
Markkanen, S., Anger-Kraavi, A., 2019. Social impacts of climate change mitigation                Staiger, D.O., Stock, J.H., 1997. Instrumental variables regression with weak
    policies and their implications for inequality. Clim. Policy 19, 827–844. https://doi.             instruments. Econometrica 65 (3), 557–586.
    org/10.1080/14693062.2019.1596873.                                                            Starr, J., Nicolson, C., Ash, M., Markowitz, E.M., Moran, D., 2023. Income-based U.S.
Millward-Hopkins, J., Oswald, Y., 2021. ‘Fair’ inequality, consumption and climate                     household carbon footprints (1990–2019) offer new insights on emissions inequality
    mitigation. Environ. Res. Lett. 16 (3), 034007. https://doi.org/10.1088/1748-9326/                 and climate finance. PLOS Climate 2 (8), e0000190. https://doi.org/10.1371/
    abe14f.                                                                                            journal.pclm.0000190.
Morrissey, T.W., Hutchison, L., Winsler, A., 2014. Family income, school attendance, and          Stern, N., 2007. The Economics of Climate Change: The Stern Review. Popul Dev Rev,
    academic achievement in elementary school. Dev. Psychol. 50 (3), 741–753.                          p. 32.
Oanh, T.T.K., Ha, N.T.H., 2023. Impact of income inequality on climate change in Asia:            Strieder Philippssen, J., Soares Angeoletto, F.H., Santana, R.G., 2017. Education level
    the role of human capital. Humanit. Soc. Sci. Commun. 10 (1), 1–11. https://doi.                   and income are important for good environmental awareness: a case study from
    org/10.1057/s41599-023-01963-w.                                                                    south Brazil. Ecol. Austral 27 (1), 39–44.
Okun, A.M., 2015. Equality and Efficiency: the Big Tradeoff. Brookings Institution Press.         Sylwester, K., 2002. Can education expenditures reduce income inequality? Econ. Educ.
    http://www.jstor.org/stable/10.7864/j.ctt13wztjk.                                                  Rev. 21 (1), 43–52. https://doi.org/10.1016/S0272-7757(00)00038-8.
O’Neill, B.C., Dalton, M., Fuchs, R., Jiang, L., Pachauri, S., Zigova, K., 2010. Global           Taylor, I.W., Ullah, M.A., Koul, S., Ulloa, M.S., 2022. Evaluating the impact of
    demographic trends and future carbon emissions. Proceed. Nat. Acad. Sci. 107 (41),                 institutional improvement on control of corruption—a system dynamics approach.
    17521–17526. https://doi.org/10.1073/pnas.1004581107.                                              Systems 10 (3), 64.
Otto, I.M., Kim, K.M., Dubrovsky, N., Lucht, W., 2019. Shift the focus from the super-            Thang, D.N., 2021. Climate policy and wealth distribution. https://doi.org/10.2120
    poor to the super-rich. Nat. Clim. Change 9 (2), 82–84. https://doi.org/10.1038/                   3/rs.3.rs-203455/v1.
    s41558-019-0402-3.                                                                            Troster, V., 2018. Testing for Granger-causality in quantiles. Econome. Rev. 37 (8),
Oxfam International, 2022. Carbon billionaires: the investment emissions of the world’s                850–866.
    richest people. Available at: https://policy-practice.oxfam.org/resources/carbon-             Uzar, U., Eyuboglu, K., 2019. The nexus between income inequality and CO2 emissions
    billionaires-the-investment-emissions-of-the-worlds-richest-people-621446/.                        in Turkey. J. Clean. Prod. 227, 149–157. https://doi.org/10.1016/j.
Percival, D.B., Walden, A.T., 2000. Wavelet Methods for Time Series Analysis, vol. 4.                  jclepro.2019.04.169.
    Cambridge university press.                                                                   Vasconcelos, V.V., Santos, F.C., Pacheco, J.M., Levin, S.A., 2014. Climate policies under
Piketty, T., 2014. Capital in the Twenty-First Century. Harvard University Press. https://             wealth inequality. Proc. Natl. Acad. Sci. 111 (6), 2212–2216. https://doi.org/
    doi.org/10.4159/9780674369542.                                                                     10.1073/pnas.1323479111.
Piketty, T., Chancel, L., 2015. Carbon and Inequality : from Kyoto to Paris. Paris School         U.S. Census Bureau, 2022. Income in the United States: 2021. U.S. Government
    of Economics, November, p. 48.                                                                     Publishing Office, Washington, DC.
Piketty, T., Zucman, G., 2014. Capital is back: Wealth-income ratios in rich countries            Wang, Q., Li, L., Li, R., 2023. Uncovering the impact of income inequality and population
    1700–2010. The Quarterly Journal of Economics 129 (3), 1255–1310.                                  aging on carbon emission efficiency: an empirical analysis of 139 countries. Sci.
Quality of Government Institute, 2024. QoG Data. University of Gothenburg.                             Total Environ. 857, 159508. https://doi.org/10.1016/j.scitotenv.2022.159508.
    Gothenburg.                                                                                   Veblen, T., 1899. The Theory of Leisure Class: An Economic Study of Institutions. The
Ramachandra, T.V., Aithal, B.H., Sreejith, K., 2015. GHG footprint of major cities in                  Macmillan Company, New York.
    India. Renew. Sustain. Energy Rev. 44, 473–495.                                               Wassie, Y.T., Rannestad, M.M., Adaramola, M.S., 2021. Determinants of household
Ravallion, M., Heil, M., Jalan, J., 2000. Carbon emissions and income inequality. Oxf.                 energy choices in rural Sub-Saharan Africa: an example from southern Ethiopia.
    Econ. Pap. 52 (4), 651–669.                                                                        Energy 221, 119785. https://doi.org/10.1016/j.energy.2021.119785.
Rojas-Vallejos, J., Lastuka, A., 2020. The income inequality and carbon emissions trade-          Winslow, M., 2005. Is democracy good for the environment? J. Environ. Plann. Manage.
    off revisited. Energy Policy 139, 111302. https://doi.org/10.1016/j.                               48 (5), 771–783.
    enpol.2020.111302.                                                                            Wolde-Rufael, Y., Idowu, S., 2017. Income distribution and CO2 emission: a comparative
Rojas-Vallejos, J., Turnovsky, S.J., 2015. The consequences of tariff reduction for                    analysis for China and India. Renew. Sustain. Energy Rev. 74, 1336–1345. https://
    economic activity and inequality. Open Econ. Rev. 26 (4). https://doi.org/10.1007/                 doi.org/10.1016/j.rser.2016.11.149.
    s11079-015-9341-4, 599–599.                                                                   World Bank, 2024. GDP per capita (current US$). World Bank Group, Washington D.C.
Sager, L., 2022. Highly unequal carbon footprints. Nat. Sustain. 5 (11), 912–913. https://        World Development Indicators, 2024. DataBank, World Development Indicators. World
    doi.org/10.1038/s41893-022-00939-z.                                                                Bank Group. Washington D.C.
Salman, M., Long, X., Dauda, L., Mensah, C.N., 2019. The impact of institutional quality          World Inequality Database, 2025. Top 10% national income share. World Inequality Lab,
    on economic growth and carbon emissions: Evidence from Indonesia, South Korea                      Paris.
    and Thailand. Journal of Cleaner Production 241, 118331.                                      Xu, X., Chen, C.F., 2019. Energy efficiency and energy justice for US low-income
Schor, J.B., 1998. The Overspent American: Upscaling, Downshifting and the New                         households: An analysis of multifaceted challenges and potential. Energy Poli. 128,
    Consumer.                                                                                          763–774.
Scruggs, L.A., 1998. Political and economic inequality and the environment. Ecol. Econ.           Yang, B., Ali, M., Hashmi, S.H., Jahanger, A., 2022. Do income inequality and
    26 (3), 259–275. https://doi.org/10.1016/S0921-8009(97)00118-3.                                    institutional quality affect CO2 emissions in developing economies? Environ. Sci.
Shang, B., 2021. The poverty and distributional impacts of carbon pricing: channels and                Pollu. Res. 29 (28), 42720–42741.
    policy implications. Rev. Environ. Econ. Pol. 17, 64–85. https://doi.org/10.1086/             Ylä-Anttila, T., Gronow, A., Stoddart, M.C., Broadbent, J., Schneider, V., Tindall, D.B.,
    723899.                                                                                            2018. Climate change policy networks: why and how to compare them across
Sim, N., Zhou, H., 2015. Oil prices, US stock return, and the dependence between their                 countries. Energy Res. Social Sci. 45, 258–265. https://doi.org/10.1016/j.
    quantiles. J. Bank. Fina. 55, 1–8. https://doi.org/10.1016/j.jbankfin.2015.01.013.                 erss.2018.06.020.
                                                                                                  Zhu, D., 2021. Consumption trends of the middle-income group (2006–2015). In: China’s
                                                                                                       Middle Class. Routledge, pp. 149–160.




                                                                                             25
