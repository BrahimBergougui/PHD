                                                             Journal of Environmental Management 395 (2025) 127823


                                                                       Contents lists available at ScienceDirect


                                                   Journal of Environmental Management
                                                           journal homepage: www.elsevier.com/locate/jenvman


Research article

Assessing the asymmetric effects of clean and dirty energy budgets on load
capacity factor: Evidence from top investing countries
Brahim Bergougui a,b,c,* , Reda Hamza Boudjana d , Samer Mehibel d , Ousama Ben-Salha e,** ,
Manuel A. Zambrano-Monserrate f
a
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
b
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
c
  College of Business & Economics, Qatar University, Doha, Qatar
d
  Centre de Recherche en Economie Appliquée pour le Développement (CREAD), Alger, Algeria
e
  Humanities and Social Research Center, Northern Border University, Arar, Saudi Arabia
f
  Universidad Espíritu Santo, Samborondón, Ecuador




A R T I C L E I N F O                                        A B S T R A C T

Keywords:                                                    This study examines the relationship between national research, development, and demonstration (RD&D)
Load capacity factor                                         budgets — both in total and split into clean and fossil categories — and environmental quality, as measured by
Clean energy                                                 the Load Capacity Factor (LCF). The analysis covers eight advanced economies from January 1990 to December
Dirty energy
                                                             2023 and applies a kernel-based quantile method designed to capture non-linear and heterogeneous effects. The
Environmental sustainability
                                                             results indicate that the link between energy budgets and environmental outcomes is not uniform across
Quantile-on-Quantile
Top investing countries                                      countries or quantiles. Moreover, aggregate and clean energy budgets show consistent positive impacts in
                                                             Germany, the United States, and Sweden, particularly at higher levels of technological maturity and environ­
                                                             mental performance, which supports the presence of threshold effects. On the other hand, France and Norway
                                                             exhibit weak or negative associations, which are likely explained by energy system saturation or misaligned
                                                             RD&D strategies. Meanwhile, dirty energy budgets produce limited benefits, with some short-term improvements
                                                             at low environmental performance levels in Canada and Australia. Therefore, clean energy budgets are more
                                                             likely to generate reliable gains, especially in countries with strong innovation capacity and supporting infra­
                                                             structure. However, mixed results are found in Japan, France, and Sweden. Based on these findings, RD&D
                                                             policies should be context-specific and aligned with the maturity of energy systems, the level of innovation, and
                                                             prevailing environmental conditions. Instead of uniformly increasing RD&D budgets, policymakers in leading
                                                             investor countries should focus on targeted allocations to clean energy, supported by enabling infrastructure and
                                                             appropriate regulatory frameworks, in order to maximize environmental gains.



List of Acronyms                                                                                     (continued )
                                                                                                      Abbreviation   Full Form
    Abbreviation    Full Form
                                                                                                      GDPC           GDP per capita
    LCF             Load Capacity Factor                                                              CO2            Carbon Dioxide
    RD&D            Research, Development, and Demonstration                                          Nat Res Rent   Natural Resource Rents
    TRD&D           Total energy technology RD&D budgets                                              QQGC           Quantile on Quantile Granger Causality
    CRD&D           Clean energy technology RD&D budgets                                              MQQKRLS        Multivariate Quantile on Quantile Kernel-Based Regularized Least
    DRD&D           Dirty (fossil) energy technology RD&D budgets                                                    Squares
    HC              Human Capital Index                                                               MQQR           Multivariate Quantile on Quantile Regression
    EPS             Environmental Policy Stringency                                                   KRLS           Kernel Regularized Least Squares
                                                               (continued on next column)                                                                      (continued on next page)



  * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands.
  ** Corresponding author.
    E-mail addresses: brahimbergougui@gmail.com, bergougui@iss.nl (B. Bergougui), boudjana_reda@hotmail.fr (R.H. Boudjana), samer.mehibel@gmail.com
(S. Mehibel), ousama.bensalha@nbu.edu.sa (O. Ben-Salha), manuelzambranom@uees.edu.ec (M.A. Zambrano-Monserrate).

https://doi.org/10.1016/j.jenvman.2025.127823
Received 30 August 2025; Received in revised form 17 October 2025; Accepted 26 October 2025
Available online 30 October 2025
0301-4797/© 2025 The Authors. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                           Journal of Environmental Management 395 (2025) 127823

(continued )                                                                       systems.
  Abbreviation        Full Form                                                        Traditional indicators such as CO2 emissions and the ecological
  EKC                 Environmental Kuznets Curve
                                                                                   footprint capture important dimensions of environmental pressure but
  LCC                 Load Capacity Curve                                          remain partial. CO2 reflects energy consumption patterns, while the
  ICT                 Information and Communication Technologies                   Ecological Footprint measures resource use and waste generation. In
  EF                  Ecological Footprint                                         contrast, the LCF integrates ecological supply and demand in a single
  SDG                 Sustainable Development Goal
                                                                                   metric, offering a broader measure of environmental quality (Pata and
  OECD                Organization for Economic Co-operation and Development
  IEA                 International Energy Agency                                  Kartal, 2023). Adopting the LCF enables this study to move beyond
  WDI                 World Development Indicators                                 conventional approaches and provides a stronger basis for policy rec­
                                                                                   ommendations (Ullah et al., 2024).
                                                                                       Recent evidence highlights the heterogeneous effects of energy in­
                                                                                   vestments on LCF across countries. Comparative analyses document
1. Introduction                                                                    country-specific responses and distributional patterns (Pata et al.,
                                                                                   2024). Clean technologies such as hydropower and nuclear power have
    The 1970s marked a turning point in global environmental history,              sustained strong LCF trajectories in Canada and France, while Ger­
as carbon dioxide (CO2) emissions nearly doubled within a single                   many’s positive outcomes are mainly tied to hydropower and other re­
decade, primarily driven by industrialization and expanding energy use             newables (Ülger et al., 2024). Japan, by contrast, has experienced mixed
(IEA, 2018). At the center of this surge was the energy sector, which              results since the Fukushima disaster disrupted its nuclear program.
accounted for about three-quarters of total emissions. At the same time,           Similar patterns appear in industrializing economies, where expansion
unsustainable production and consumption patterns pushed many na­                  of fossil capacity is linked to deteriorating LCF (Durmus et al., 2025). As
tions into ecological deficit (Global Footprint Network, 2025). These              shown in Fig. 1, the distribution of investment across hydropower, nu­
developments placed the energy transition at the core of international             clear, other renewables, and fossil fuels is reflected in LCF outcomes,
sustainability agendas. Sustainable Development Goal 7 (SDG 7), for                highlighting both the diversity of strategies among advanced economies
instance, highlights the expansion of affordable and accessible green              and the environmental implications of their budget choices.
energy and makes clear that progress requires profound structural                      Additional empirical support comes from Pata et al. (2024), who, in a
changes in how energy is produced and consumed (UN, 2021). Eco­                    panel analysis of OECD member states, finds that increases in renewable
nomic development strategies have historically prioritized growth over             energy investments, particularly when substituting fossil-based sources,
environmental safeguards, leading to heavy reliance on fossil fuels such           are strongly associated with improvements in LCF. As shown in Fig. 2,
as oil, gas, and coal, with severe implications for climate stability              countries such as Sweden, Norway, France, and Australia exhibit up­
(Shahbaz et al., 2017). Addressing this imbalance requires targeted in­            ward LCF trajectories that closely align with rising shares of renewables
vestments in innovation, particularly through research, development,               in their investment portfolios. In contrast, countries experiencing
and demonstration (RD&D) budgets focused on energy efficiency and                  delayed transitions away from fossil fuels, such as Germany (following
clean technologies. Energy efficiency RD&D is essential because a                  its nuclear withdrawal) and Japan, exhibit flatter or negative LCF trends
complete transition to renewables is still technologically and economi­            during the same period, underscoring the challenges of integrating
cally distant; improving current systems remains a necessary interme­              intermittent renewables without sufficient baseload support or grid
diate step. This type of investment supports the development of                    flexibility. Comparable patterns are also observable in non-OECD and
technologies that lower energy waste and reduce greenhouse gas emis­               industrializing economies. As highlighted by Durmus et al. (2025) and
sions. Nevertheless, efficiency budgets have often been underestimated             other recent studies, fossil fuel expansion in these contexts tends to
in the literature, despite their potential to deliver immediate environ­           correlate with deteriorating LCF metrics and increased ecological stress.
mental benefits.                                                                   In contrast, renewable energy deployment, especially in higher-income
    In parallel, renewable energy RD&D plays a critical role in acceler­           or rapidly industrializing countries, has shown the most pronounced
ating the deployment of clean technologies. Prior studies show that such           positive effect on LCF outcomes, particularly where regulatory frame­
investments not only advance environmental objectives but also                     works and infrastructure capacity support integration.
generate new economic opportunities (Ardito et al., 2019). Moreover,                   Collectively, the data presented in Figs. 1 and 2 illustrate a consistent
green energy budgets can reduce energy insecurity, create fiscal reve­             pattern: nations that allocate a larger share of their energy investments
nues, and support ecological sustainability (Koçak and Ulucak, 2019).              to high-capacity, stable, clean technologies—chiefly hydropower and
As renewable RD&D expands, clean technologies become more afford­                  nuclear—tend to sustain more robust and reliable LCF trajectories over
able and effective alternatives to fossil fuels (Ahmed et al., 2021).              time. Conversely, systems with persistent dependence on fossil energy or
Empirical evidence suggests that even modest increases in renewable                limited capacity to integrate renewables effectively are prone to LCF
budgets improve LCF, an indicator that measures the balance between                stagnation or volatility. These findings underscore that long-term gains
ecological supply and human demand (Bergougui and Meziane, 2025).                  in LCF, which are crucial for enhancing energy system resilience and
Institutional and regulatory frameworks are equally decisive. When                 environmental sustainability, are contingent not merely on the share of
environmental standards are stringent and technological progress sup­              clean energy in total investments but also on the operational reliability,
ports clean alternatives, renewables are integrated more effectively into          scalability, and systemic integration of those energy sources.
energy systems, amplifying their impact on the LCF. Nuclear power,                     Taken together, the growing body of international evidence makes
though socially contentious, remains an important low-carbon option,               clear that investments targeting high-efficiency clean technologies
offering a large-scale, stable supply. Research in nuclear RD&D can                deliver superior outcomes in terms of load capacity utilization. This
enhance its safety, efficiency, and scalability, making it a complemen­            result has direct implications for policy design to meet energy security
tary component of the clean energy mix (Ahmed et al., 2022). By                    and climate objectives; nations must adopt strategic investment ap­
contrast, evidence also shows that fossil-based RD&D undermines                    proaches that emphasize technologically mature, high-capacity clean
environmental quality. Studies of investment patterns in both emerging             energy, complemented by flexible grid infrastructure and strong regu­
and advanced economies confirm that reliance on fossil fuels erodes the            latory support. As illustrated in the comparative performances mapped
LCF and heightens ecological stress (Bergougui and Meziane, 2025).                 in Figs. 1 and 2, energy transitions grounded in such principles are not
Institutional assessments echo these concerns: the IEA (2025) and                  only more effective at reducing ecological pressure but also more likely
Greenpeace International (2011) report that fossil fuels still command             to ensure long-term system stability and policy credibility. Although
huge investment volumes, which slows the shift toward sustainable                  empirical research increasingly recognizes the influence of clean and

                                                                               2
B. Bergougui et al.                                                                                          Journal of Environmental Management 395 (2025) 127823




Fig. 1. Share of energy investments vs LCF in 2024.
Source: Bloomberg NEF (2024); IEA (2024).


fossil-based energy investments on the evolution of the LCF, significant          or have not systematically contrasted clean and dirty energy in­
voids persist in the scholarly discourse. Firstly, the majority of existing       vestments within a comparative, cross-national framework (Eberhart
analyses remain confined to single-country settings or narrow regional            et al., 2025). By focusing on the world’s top investing nations, our study
scopes, thereby constraining the extrapolation of insights to heteroge­           not only elucidates the differentiated impacts arising from varying
neous structural and institutional environments (Bergougui et al.,                country-specific investment profiles and institutional capacities but also
2024a,b; Ragosa and Warren, 2019; Wen et al., 2022). Secondly, a                  facilitates robust cross-sectional generalizability. Through this compar­
substantial methodological limitation arises from the prevailing reliance         ative lens, we can expose the contingent nature of energy investment
on linear specifications and average-effect estimations, which tend to            effects, showing that the marginal influence of clean or dirty budgets on
overlook asymmetries and nonlinear dynamics that may characterize                 LCF fluctuates markedly across distinct quantiles of national budget
the interplay between energy investment typologies and LCF (Ulucak                allocation and systemic performance. Notably, the analytical architec­
et al., 2020; van Eyden et al., 2019). Thirdly, cross-national comparative        ture of this investigation enables the identification of previously
studies that simultaneously disentangle the differential effects of clean         obscured asymmetries. The quantile-on-quantile framework reveals, for
versus dirty energy budget allocations on operational efficiency metrics,         instance, that the beneficial effects of augmenting clean energy budgets
such as LCF, remain sparse, particularly those that utilize sophisticated         are not uniform but are instead accentuated at specific segments of the
techniques capable of modeling complex interdependencies within the               LCF distribution. In contrast, the detrimental effects of fossil fuel in­
joint distribution of variables.                                                  vestments intensify at the upper extremes of their own allocation
                                                                                  spectra. This multidimensional mapping provides an empirical founda­
1.1. Study contribution                                                           tion for targeted, context-sensitive policy recommendations, a signifi­
                                                                                  cant departure from the generalized prescriptions prevalent in earlier
    In response to the above-mentioned lacunae, the current paper offers          research. Furthermore, by incorporating regularization and
a systematic, cross-country empirical assessment by making several                kernel-based nonlinear estimation within the quantile-on-quantile
pivotal advances over the extant literature through unveiling the                 design, our study delivers enhanced predictive robustness and greater
nuanced, heterogeneous, and nonlinear effects of energy research and              fidelity in modelling real-world complexities. This technical advance­
development budgets on load capacity factor (LCF), particularly within            ment addresses potential issues of multicollinearity and overfitting that
the context of major investing economies. Foremost, the application of            have frequently impaired prior empirical studies, particularly in settings
the MQQKRLS approach represents a substantial methodological inno­                marked by high-dimensional or overlapping national data.
vation. Traditional literature in energy economics has predominantly                  The structure of this paper is as follows: Section 2 presents a critical
relied on linear models or simple quantile regressions (Bergougui et al.,         synthesis of recent scholarly literature; Section 3 outlines the method­
2024a), thereby restricting analytical focus to average or symmetric              ological framework and data sources employed; Section 4 presents the
effects (van Eyden et al., 2019). In contrast, our use of the MQQKRLS             empirical results and an in-depth discussion; and Section 5 concludes
estimator allows for a simultaneous exploration of the distributional             with key findings and policy-relevant implications.
intricacies across both predictor (clean and dirty energy budgets) and
response variables, capturing nonlinear and multidimensionally asym­
metric interactions. Empirically, this work distinguishes itself from
prevailing studies, which have either focused on isolated national con­
texts (Bergougui, 2025a,c; Ragosa and Warren, 2019; Wen et al., 2022)

                                                                              3
B. Bergougui et al.                                                                                          Journal of Environmental Management 395 (2025) 127823




                                           Fig. 2. Load Capacity Factor and renewable-to-fossil investment ratio.


2. Literature review                                                             the ratio of biocapacity to ecological footprint. Values above one signal
                                                                                 ecological balance, while those below one indicate overshoot. As a
2.1. Theoretical foundations                                                     diagnostic tool, the LCF links ecological demand and supply, offering a
                                                                                 more integrated measure of environmental quality. The relationship
    In recent decades, development agendas have been shaped by the               between growth and environmental outcomes has also been reex­
assumption that economic expansion directly improves social welfare.             amined. Alvarado et al. (2021) emphasize that GDP remains a strong
While this assumption holds in some respects, it has also generated              predictor of ecological stress. Building on this, Dogan and Pata (2022)
unintended environmental consequences, most notably sustained                    introduced the LCC, which posits a U-shaped association between in­
ecological degradation (Pata et al., 2023a,b). Rising carbon dioxide             come growth and environmental quality. At early stages of develop­
(CO2) emissions and other atmospheric pollutants have contributed to             ment, rising GDP reduces the LCF, reflecting heavier ecological strain.
deteriorating air quality, ecological disruption, and climate instability        Beyond a certain threshold, however, further growth improves envi­
(Shao et al., 2021). These pressures are especially evident in rapidly           ronmental performance, as wealthier societies allocate resources to
industrializing economies, where energy demand is high and balancing             regulation, innovation, and ecological protection.
growth with sustainability is acute. This context has prompted renewed               This relationship is illustrated in Fig. 3, which contrasts the LCC with
scrutiny of how environmental quality is measured. Historically, CO2             the conventional EKC.1 While the EKC assumes an inverted-U pattern,
emissions were used as a principal indicator, but as Purcel (2020) notes,        the LCC shows a U-shaped trajectory in which economic growth first
this measure is limited in scope and fails to capture the full range of          undermines but later strengthens ecological capacity once structural and
ecological stress. The ecological footprint (EF) was introduced to               institutional conditions allow. The LCC thus reframes the
broaden this perspective by integrating six dimensions of environmental
demand and thereby providing a more complete assessment of anthro­
pogenic pressure.
                                                                                   1
    Both CO2 and EF, however, are demand-side measures. They capture                 In the empirical analysis that follows, the LCC will serve as a theoretical
environmental use but do not reflect the regenerative capacity of eco­           benchmark rather than a testable model. The forthcoming sections will explore
systems. To address this, Siche et al. (2010) proposed the LCF, defined as       whether the distributional effects of RD&D on ecological capacity are consistent
                                                                                 with the LCC narrative, without estimating income–LCF curves directly.

                                                                             4
B. Bergougui et al.                                                                                         Journal of Environmental Management 395 (2025) 127823




Fig. 3. LCC and EKC hypothesis.
Source: (Pata et al. (2023a,b).


growth–environment nexus by showing that development may initially                Finally, operational perspectives from power systems engineering
degrade but subsequently improve sustainability, provided policies                demonstrate that technological composition affects reliability and load
support the transition (Pata et al., 2023a,b). As such, the LCF emerges           outcomes. Fossil and nuclear power provide stable capacity, while re­
not only as a monitoring indicator for ecological balance but also as a           newables introduce variability, which complicates grid management
strategic benchmark for long-term planning. Given the close connection            (Bolson et al., 2022). Consequently, the system-level LCF depends not
between environmental resource management and the Sustainable                     only on the scale of investment but also on its technological mix and
Development Goals (notably Goals 7, 8, 13, and 16), the LCC and LCF               integration readiness. This reinforces the need for econometric models
frameworks provide robust lenses for evaluating national progress. In             that capture non-linear, distribution-sensitive dynamics.
this sense, the structural transformation of energy portfolios from fossil
inputs toward renewables becomes a central policy priority. Because
energy use underpins production systems, the integration of renewables            2.2. Clean energy budgets and LCF
is decisive in shaping ecological quality as measured by LCF (Guloglu
et al., 2023; Yavuz et al., 2024). While the benefits of renewable energy             Evidence indicates that clean energy budgets improve LCF under the
deployment are widely recognized, the role of renewable energy                    right conditions. Dogan and Pata (2022) show that in G7 countries,
research and development (RR&D) remains less explored. Much of the                economic growth coupled with strong RD&D, information and
existing literature emphasizes infrastructure investment, while RR&D              communication technologies (ICT), and renewable infrastructure raises
has received limited attention. Some recent contributions highlight its           LCF, although early growth phases reduce it. This is consistent with the
importance, but analyses remain concentrated in advanced economies                LCC hypothesis, which describes a U-shaped path where LCF first de­
such as the G7, Japan, the United States, and Germany (Ahmed et al.,              clines and later recovers as incomes rise. Pata and Kartal (2023) validate
2022; Jin et al., 2024), which suggests the need for broader                      this mechanism in South Korea by including sustainable energy in their
cross-national studies. A more complete theoretical framework requires            models. While further validations are limited, the LCC offers a promising
treating energy investments—both clean and fossil—as dynamically                  framework for interpreting energy–environment dynamics.
substitutable rather than isolated inputs. The elasticity of substitution             Several studies confirm that energy R&D mitigates emissions. Jin
perspective clarifies that renewable–fossil substitution is neither uni­          et al. (2017) show that energy R&D lowers CO2 emissions in China.
form nor linear but contingent on innovation diffusion, grid adapt­               Shahbaz et al. (2018) find that while foreign direct investment raises
ability, and the baseline energy mix (Jo, 2025; Stöckl and Zerrahn,              emissions, energy R&D offsets part of this increase. Baloch et al. (2021)
2022). This implies that marginal shifts in clean or fossil allocations can       confirm the EKC for OECD countries, while highlighting the role of en­
have asymmetrical effects on LCF. Related research emphasizes                     ergy R&D in reducing emissions. Altıntaş and Kassouri (2020) reach
non-linearities and thresholds in these effects: early renewable in­              similar conclusions for Europe, and Balsalobre et al. (2015) affirm the
vestments improve efficiency, but large-scale deployment can create               same across OECD states. Ahmed et al. (2022) observe differences be­
integration challenges, while fossil expansion consistently depresses             tween renewable and nuclear energy R&D: nuclear often achieves
environmental performance, though by varying magnitudes depending                 deeper reductions, particularly in advanced economies, while renew­
on context (Alola et al., 2022; Bergougui et al., 2024a,b). Within this           ables have weaker but still positive impacts. For Germany and the G7,
framework, the concept of directed technical change is also relevant.             however, renewable budgets deliver consistent gains (Ahmed et al.,
The orientation of RD&D—toward clean or fossil tech­                              2022; Pata et al., 2023a,b). However, not all evidence is supportive.
nologies—determines the trajectory of energy systems. Clean-oriented              Jordaan et al. (2017) report that fossil R&D in Canada constrained
budgets can catalyze cost reductions, efficiency improvements, and                environmental commitments. Mourshed and Quddus (2009) found
technological maturity, whereas fossil-oriented budgets reinforce                 limited benefits from energy R&D in parts of Europe. Koçak and Ulucak
high-emission lock-in (Jo, 2025). At the same time, environmental load            (2019) conclude that renewable R&D had no significant impact on
theory positions LCF as a composite metric that integrates ecological             emissions, whereas fossil R&D increased them. In the United States,
capacity and human demand, thereby extending beyond narrow                        Ahmed et al. (2021) find that renewable R&D is ineffective at reducing
emission-based indicators (Inuwa et al., 2025; Pata & Balcilar, 2024).            emissions, and Pata et al. (2023a,b) note that integrating clean tech­
                                                                                  nologies did not improve LCF.

                                                                              5
B. Bergougui et al.                                                                                          Journal of Environmental Management 395 (2025) 127823


     Dynamic, complex interplays among economic, technological, and                structured sample of eight countries. The selection follows a two-by-two
policy factors strongly support the enhancement of LCF through clean               design based on industrialization level and LCF status: (1) high-
energy budgets. Research demonstrates that economic growth, when                   industrialized with LCF surplus (Canada and Norway), (2) high-
synergized with robust RD&D investments, ICT, and renewable infra­                 industrialized with LCF deficit (Germany and Japan), (3) low-
structure, fosters improvements in LCF despite early-stage declines,               industrialized with LCF surplus (Sweden and Australia), and (4) low-
reflecting the LCC hypothesis, which describes a nonlinear, U-shaped               industrialized with LCF deficit (France and the USA). This classifica­
pathway in energy sustainability (Avci and Caglar, 2025). Empirical                tion systematically captures both industrialization intensity and LCF
validations in diverse contexts reinforce those investments in energy              status, without drawing direct contrasts between industrialized and non-
R&D, particularly in advanced economies, significantly mitigate emis­              industrialized nations or between surplus and deficit groups. Following
sions and elevate environmental quality, with nuclear energy R&D                   established methodologies ((Bergougui et al., 2024a,b), the annual data
exhibiting deeper reductions and renewable energy R&D contributing                 were converted into quarterly and subsequently monthly frequencies
steadily (Ulug et al., 2025). Conversely, the adverse environmental                using the Sparse Time Dimension method (Mosley et al., 2022).
impact of fossil fuel R&D and mixed results regarding the effectiveness
of clean energy R&D in certain regions highlight the heterogeneous                 3.1.2. Dependent variable
nature of energy transition outcomes. Additionally, the influence of                  Load Capacity Factor (LCF): Introduced by Siche et al. (2010), the
financial globalization and foreign direct investments adds a layer of             LCF measures a country’s capacity to sustain its population under cur­
complexity, modulating the net effects of energy budgets on LCF                    rent consumption patterns. It is calculated as the ratio of per capita
through varying regional economic and institutional factors. These                 biocapacity to per capita ecological footprint (Bergougui, 2025b,
empirical insights underscore the need for sophisticated nonlinear                 2025c). An LCF value below 1 indicates ecological footprint overshoot,
analytical frameworks to accurately capture the asymmetric and                     while a value above 1 indicates sustainability.
context-dependent effects of clean and dirty energy budgets on load
capacity factors in the broader transition toward sustainable energy               3.1.3. Key independent variables
systems.                                                                              Energy Technology R&D Expenditures: The study examines
     Other factors interact with energy budgets. The Environmental                 research and development (R&D) expenditures directed toward energy
Kuznets Curve, for instance, has mixed effects. Xu et al. (2022) show that         technologies, analyzed both in aggregate and across major sub­
in Brazil, FIG improves LCF, though both fossil and green energy reduce            categories: clean energy, energy storage, energy efficiency, and fossil-
it. In West Asia and the Middle East, Kihombo et al. (2022) find that FIG          based (dirty) technologies.
lowers EF and supports environmental outcomes. Akadiri et al. (2022)
report that FIG enhances LCF in India, while Ulucak et al. (2020)                  3.1.4. Control variables
conclude that FIG increases EF in emerging economies, weakening EKC                   Following the empirical literature, several control variables are
validation. Shahzad et al. (2022) show that FIG raises EF in China,                incorporated to account for factors influencing the LCF:
though under certain conditions it may support ecological quality.
                                                                                    • Political Pressure: Proxied by the Environmental Policy Stringency
2.3. Dirty energy budgets and LCF                                                     Index. Political pressure, reflected through the stringency of envi­
                                                                                      ronmental policies, promotes cleaner technologies and sustainable
    The relationship between fossil-based energy investment and LCF is                practices, thereby enhancing ecological capacity (Bergougui and
consistently negative. Coal, oil, and gas remain central to energy supply,            Satrovic, 2025).
but their long-term environmental costs are well documented. LCF, as                • Renewable Energy Consumption: Renewable energy use mitigates
the ratio of biocapacity to ecological footprint, provides a comprehen­               environmental degradation by reducing reliance on fossil fuels,
sive metric that captures these impacts. Cross-national studies confirm               contributing positively to sustainability (Sohag et al., 2024).
that higher fossil budgets reduce LCF, as these technologies are less               • Human Capital: Human capital may exert a dual effect: higher ed­
efficient and more polluting (Emre Caglar et al., 2024; Liu et al., 2024).            ucation and skill levels facilitate technological innovation and
Beyond direct emissions, fossil energy undermines ecological balance by               environmental awareness that improve resource efficiency; however,
exhausting resources, expanding ecological footprints, and locking sys­               they may also intensify economic activity and energy consumption,
tems into carbon-intensive infrastructures (Ullah and Lin, 2025).                     potentially leading to ecological stress (Ahakwa et al., 2023).
    Empirical research shows that fossil R&D rarely offsets these costs.            • Carbon Dioxide (CO2) Emissions: Higher CO2 emissions impose
Instead, it often deepens them by enabling more efficient extraction and              ecological stress and lower the LCF by expanding the ecological
combustion, thereby raising throughput and accelerating biocapacity                   footprint (Musah et al., 2024).
loss (Emre Caglar et al., 2024). Country studies illustrate feedback loops          • Institutional Quality: Institutional quality fosters environmental
in which fossil-fuel industrialization reduces LCF, erodes ecological ca­             governance and efficient resource management, supporting long-
pacity, and worsens sustainability outcomes. Econometric evidence,                    term ecological balance (Ben Ali et al., 2025b; Bergougui, 2025d;
including ARDL and quantile models, further demonstrates that fossil                  Bergougui et al., 2025).
use has lagged but persistent adverse effects on LCF across both                    • Natural Resource Rents: The effect of natural resource rents de­
advanced and developing economies (Ullah and Lin, 2025).                              pends on governance efficiency; poor rent management exacerbates
    The policy implication is clear. Nations prioritizing fossil energy risk          ecological degradation, whereas effective use can support sustain­
long-term LCF decline and ecological vulnerability. Redirecting budgets               ability (Yıldırım et al., 2025).
toward renewables and nuclear, supported by strong institutions and                 • Income: Income captures the role of economic development, which
adaptive innovation systems, emerges as a necessary condition for                     may initially strain the environment but ultimately enhances sus­
reversing these trends and sustaining environmental capacity.                         tainability through technological advancement and cleaner produc­
                                                                                      tion (Chovancová et al., 2024; Zambrano-Monserrate et al., 2024).
3. Data and methodology                                                               Table 1 summarizes the variables studied and their data sources.

3.1. Data sources and country selection                                            3.2. Quantile-on-quantile granger causality method

3.1.1. Sample and data                                                                The Granger causality test, initially developed by Granger (1969),
   This study employs annual data spanning 1990 to 2023 for a                      assesses whether past values of one variable can predict future values of

                                                                               6
B. Bergougui et al.                                                                                                   Journal of Environmental Management 395 (2025) 127823


Table 1                                                                                 Hazlett (2014). KRLS is a flexible nonparametric regression method that
Details of the variables.                                                               avoids restrictive functional-form assumptions. It employs Gaussian
  Variable            Code           Measurement                 Source                 kernels to approximate the data structure, reducing model mis­
                                                                                        specification bias, and estimates marginal effects point by point, aver­
  Load Capacity       LCF            An LCF less than 1          Global Footprint
    Factor                           indicates that the          Network (2025)         aging them to obtain global measures (Bergougui, 2025a, 2025b;
                                     current environmental                              Bergougui et al., 2025; Ferwerda et al., 2017; Özkan et al., 2025). A
                                     condition is                                       limitation of standard KRLS is that it focuses on conditional means and
                                     unsustainable, and a                               does not account for heterogeneity across the quantiles of the dependent
                                     value greater than 1
                                     indicates that the
                                                                                        variable. To overcome this, the QQKRLS combines the flexibility of KRLS
                                     system is sustainable                              with the quantile-on-quantile approach developed by Sim and Zhou
  Total energy        TRD&D          Millions of USD (2022                              (2015). This hybrid method estimates the effect of the θ-th quantile of a
                                                                 IEA (2025)
    technology                       prices and PPP)                                    predictor on the τ-th quantile of the outcome, providing richer insights
    RD&D budgets
                                                                                        into asymmetric and nonlinear relationships.
  Dirty energy        DRD&D          This variable is
    technology                       represented by the                                     The MQQKRLS model further incorporates multiple control vari­
    RD&D budgets                     fossil fuel technology                             ables, thereby improving the precision of estimates and isolating the
                                     RD&D budgets,                                      specific effect of RD&D on environmental outcomes. In this setting, the
                                     expressed in millions of                           estimation of marginal effects is expressed as:
                                     USD at 2022 prices and
                                     adjusted for purchasing
                                                                                           [       ]                  ( ⃦           ⃦ )
                                                                                              ̂
                                                                                             δQτ
                                                                                                       − 2 ∑N ∑N           ⃦Xθ − Xθ ⃦2 (            )
                                                                                                                             i    k
                                     power parity (PPP).                                EN     LCF
                                                                                                     = 2          exp −                 * Xiθ − Xkθ           (1)
  Clean energy        CRD&D          This variable is defined                                δQθXK    σ N k=1 i=1              σ2
    technology                       as the combined total
    RD&D budgets                     of renewable energy                                Where:
                                     technology RD&D
                                     budgets and nuclear                                      [       ]
                                     energy RD&D budgets,                                     ̂ τ
                                                                                         • EN δQLCF       denotes the average pointwise marginal effect of the θ-th
                                                                                              δQ
                                     measured in millions of                                     θ
                                                                                                 XK
                                     USD at 2022 prices and
                                     adjusted for purchasing                               conditional quantile of the predictor variables Xk on the τ-th condi­
                                     power parity (PPP).                                   tional quantile of the outcome variable LCF,
  Human capital       HC             Years of schooling and      Penn World              • QτLCF and QθX represent the τ-th and θ-th conditional quantile series of
   index                             returns to education        Table, version
                                                                 10.01
                                                                                           LCF and covariates, respectively,
  Environmental       EPS            The Environmental           OECD                    • σ 2 is the bandwidth parameter of the Gaussian kernel,
    Policy                           Policy Stringency Index     Environmental           • N is the number of observations,
    Stringency                       serves as a measure of      Statistics              • In this multivariate setting, X ∈ RN*P contains multiple covariates,
                                     the rigor of                Database
                                                                                           and the kernel is computed over the joint quantile space.
                                     environmental
                                     regulations. The index
                                     ranges from 0 (minimal                                 This approach captures nonlinear and heterogeneous effects of
                                     policy stringency) to 6                            RD&D budgets on the LCF while controlling for relevant economic and
                                     (highly stringent
                                                                                        institutional factors. The methodology’s structure is summarized in
                                     environmental
                                     requirements).
                                                                                        Fig. 4, which presents a flowchart of the analytical steps.
  GDP per capita      GDPC           Per capita constant         WDI
                                     2010 US$                                           4. Results
  Renewable           Renewable      The share of renewable      WDI
    energy            energy cons    energy in total final
                                                                                        4.1. Preliminary analysis
    consumption                      energy consumption.
  carbon dioxide      Co2pc          CO2 emissions per           Global Carbon
    (CO2) emissions                  capita in metric tons.      Budget                     Determining whether the MQQKRLS is a suitable methodology for
  Institutional       inst           Rule of law                 WDI                    this investigation is the main goal of this section. This is accomplished by
    quality
                                                                                        first evaluating the data’s descriptive statistics, followed by its (non)
  Natural resource    Nat_res_rent   Total natural resources     WDI
    rents                            rents are the sum of oil
                                                                                        linearity properties and (in)stability features.
                                     rents, natural gas rents,
                                     coal rents (hard and                               4.1.1. Descriptive statistics
                                     soft), mineral rents,                                  The descriptive statistics provide an overview of the distribution of
                                     and forest rents.
                                                                                        the study variables. The mean and median indicate the data’s central
                                                                                        tendency, while the standard deviations indicate moderate volatility for
another. Its main limitation is the assumption of linearity, which re­                  most variables. The main exception is renewable energy consumption,
stricts its ability to capture complex interactions. To address this, Ade­              which shows higher dispersion across countries. This variability likely
bayo et al. (2024a)(2024) introduced the QQGC method. Unlike the                        reflects differences in renewable energy adoption rates, policy frame­
standard test, QQGC examines how different quantiles of one variable                    works, and infrastructure development. Skewness and kurtosis values
affect those of another, thereby capturing causal dynamics across the full              suggest significant departures from normality, with most variables
distribution rather than focusing on the mean.                                          negatively skewed and platykurtic. The Jarque–Bera (JB) test further
                                                                                        confirms non-normality at the 1 % level for most series, with only a few
                                                                                        exceptions, such as clean energy RD&D in Norway.
3.3. Multivariate quantile-on-quantile kernel-based regularized least
square method
                                                                                        4.1.2. The (non)linearity properties
                                                                                           To examine the dynamic features of the data, the
   This study applies the MQQKRLS framework to assess the effects of
                                                                                        Broock–Dechert–Scheinkman (BDS) nonlinearity test was applied to the
aggregate and disaggregated energy RD&D expenditures on the LCF.
                                                                                        quarterly log-transformed series (Broock et al., 1996). As shown in
The method extends KRLS, initially proposed by Hainmueller and

                                                                                    7
B. Bergougui et al.                                                                                          Journal of Environmental Management 395 (2025) 127823




                                                              Fig. 4. Flowchart of the analyses.


Table A.2, the dependent variable, the core RD&D variables, and the                weak, whereas Germany and France display mid-range or fragmented
control variables display strong nonlinear dynamics across all countries.          significance, reflecting transitional and state-sensitive dynamics. In
The BDS statistics for embedding dimensions M2 through M6 are                      contrast, Japan and Sweden exhibit limited or selective predictability,
consistently high and significant at the 1 % level, leading to rejection of        with Japan showing notable effects when modest RD&D coincides with
the null hypothesis of i.i.d residuals. These results confirm the presence         high LCF and Sweden displaying highly localized responses, consistent
of nonlinear structures, which justifies the use of nonlinear econometric          with mature systems experiencing diminishing predictive returns.
approaches.                                                                        Overall, the heterogeneity across countries underscores that the pre­
                                                                                   dictive role of RD&D is contingent upon national innovation structures
4.1.3. The (in)stability characteristics                                           and the prevailing level of ecological capacity.
    Structural stability was evaluated using the Max-F, Exp-F and Ave-F
tests developed by Andrews (1993) and Andrews and Ploberger (1994).                4.2.2. QQGC from dirty energy RD&D to LCF
The results, summarized in Table A.3, uniformly reject the null hy­                    Figure B.2summarizes the quantile-on-quantile Granger causality
pothesis of parameter stability across all variables and countries. This           from fossil energy RD&D to the LCF, revealing pronounced cross-
finding indicates pervasive structural breaks throughout the sample.               country heterogeneity in the predictive influence of fossil-related in­
When combined with the evidence of non-normality and nonlinear dy­                 vestments. Broad and robust causality is evident for Norway and the
namics, the tests confirm that the dataset is characterized by instability         United States, where fossil RD&D predicts LCF across wide quantile
and complexity.                                                                    ranges—though with differing emphases. In Norway, effects span nearly
    These outcomes indicate that the assumptions of linear models are              all combinations of RD&D and LCF, while in the United States, pre­
not satisfied. The presence of volatility, asymmetric distributions,               dictability peaks when high LCF coincides with low fossil RD&D, sug­
nonlinear dynamics, and repeated structural breaks across countries                gesting that even marginal investment shifts influence ecological
provides strong justification for adopting the MQQKRLS methodology.                capacity in high-performing systems. Moderate or localized effects
This approach can handle heterogeneous effects and nonlinear patterns,             characterize Canada, Australia, and Germany: Canada’s causal link
making it well-suited for examining the relationship between RD&D                  concentrates where LCF is low and fossil RD&D is high, Germany’s
expenditures and environmental performance.                                        significance appears primarily at high LCF levels, and Australia’s pre­
                                                                                   dictive strength clusters around mid-range RD&D quantiles, indicating
                                                                                   conditional sensitivity to investment scale. Limited and context-specific
4.2. QQGC results                                                                  predictability is observed for Sweden, Japan, and France, with Japan
                                                                                   exhibiting stronger effects at upper RD&D quantiles—signifying that
    Figures B.1–B.3 (Appendix B) illustrate the quantile-on-quantile               high investment intensity bears greater predictive weight—while Swe­
Granger causality relationships from aggregate, fossil, and clean                  den and France display scattered significance, reflecting context-
RD&D to LCF. The horizontal and vertical axes correspond to the con­               dependent and non-systematic patterns. Overall, these findings indi­
ditional quantiles of LCF and RD&D, respectively. The color intensity              cate that the predictive role of fossil RD&D in shaping ecological ca­
indicates the strength of causality (darker shades signify stronger effects,       pacity is highly uneven—pervasive and robust in innovation-intensive
lighter shades weaker ones), while white cells represent statistically             systems such as Norway and the United States, yet weaker or fragmented
insignificant regions and asterisks mark significant causal relationships.         elsewhere—highlighting the importance of national energy structures
                                                                                   and policy frameworks in determining RD&D effectiveness.
4.2.1. QQGC from aggregate RD&D to LCF
   Figure B.1 presents the marginal predictive effects of aggregate                4.2.3. QQGC from clean energy RD&D to LCF
RD&D on the LCF across countries, revealing three distinct response                    Figure B.3summarizes the quantile-on-quantile Granger causality
patterns. Broad and consistently positive predictive relationships are             from clean energy RD&D to the LCF, revealing distinct national patterns
observed for Norway, Australia, and the United States, where RD&D                  in both predictive strength and distributional scope. Broad and robust
expenditures remain informative across wide ecological conditions—­                causality emerges for Japan, Germany, and the United States. In Japan,
most strongly when LCF is low in Australia and high in the United States           significance spans nearly the entire grid, indicating a pervasive and
and Norway—suggesting that investment effectively signals ecological               systemic link between clean RD&D and ecological capacity. Germany’s
capacity changes within dynamic innovation environments. Moderate                  strongest effects cluster at low quantiles of both variables, suggesting
and context-dependent effects characterize Canada, Germany, and                    that clean energy investment is most informative during early stages of
France: Canada’s predictive strength is concentrated at low LCF levels,            ecological development. At the same time, the United States displays
implying that RD&D is most influential when ecological capacity is

                                                                               8
B. Bergougui et al.                                                                                        Journal of Environmental Management 395 (2025) 127823


pronounced upper-tail effects, with moderate to high RD&D aligning              4.3. MQQKRLS results
with advanced LCF states, reflecting the efficient translation of inno­
vation into environmental outcomes. Moderate or quantile-specific ef­               Given the asymmetric causal patterns, a distribution-sensitive esti­
fects characterize Canada, France, and Australia: Canada’s predictability       mator is required. The MQQKRLS framework captures effects across the
concentrates under low LCF and mid-to-high RD&D, France’s influence             joint quantiles of LCF and RD&D. Figs. 5–7 display heatmaps of marginal
strengthens at high LCF quantiles—signaling greater feedback in mature          effects from total, fossil, and clean RD&D to LCF. The horizontal and
systems—and Australia’s effects center below the median LCF, indi­              vertical axes represent conditional quantiles of LCF and RD&D
cating predictive relevance under weaker ecological conditions. Limited         (0.05–0.95), respectively. Color shading indicates effect sign and
or asymmetric relationships are found for Norway and Sweden. Norway             magnitude (dark blue = strong positive; deep red = strong negative),
shows sparse significance, suggesting selective, context-dependent as­          and asterisks mark statistical significance.
sociations. In contrast, Sweden exhibits a dual-peak structure linking
high RD&D to effects at both low and high LCF levels, consistent with           4.3.1. Aggregated RD&D impact on LCF
flexible investment returns across ecological states. Overall, clean en­            Fig. 5 presents the marginal effects of total RD&D on the LCF across
ergy RD&D displays heterogeneous and quantile-dependent predictive              the eight countries, revealing heterogeneous and asymmetric relation­
patterns—strong and pervasive in innovation-intensive economies, yet            ships consistent with the preliminary diagnostics. Overall, positive ef­
more constrained and context-bound where clean technology invest­               fects tend to occur when RD&D intensity is high and LCF values fall
ment and policy coordination are less developed.                                within the low-to-middle quantile range, suggesting that innovation
    Across countries, the patterns are heterogeneous and quantile-              investment is most effective during the development of ecological ca­
dependent. Some economies display broad, persistent effects, while              pacity. In contrast, negative or insignificant effects are more prevalent at
others concentrate predictive power in specific regions—often at lower          higher LCF levels or under low RD&D intensity, indicating diminishing
or middle LCF levels. These differences reflect each country’s stage in         returns in mature environmental systems and limits to absorptive ca­
the energy transition and the composition of its clean-energy portfolio         pacity. Country-specific variations reflect distinct innovation contexts:
and are mediated by institutional capacity. Stronger and more consistent        Germany exhibits broadly positive outcomes consistent with an efficient
effects in Germany, the United States, and Sweden align with robust             RD&D–environmental linkage; Sweden and the United States experience
innovation systems, diversified energy portfolios, and long-standing            substantial improvements when LCF is low and RD&D is high; France
policy frameworks that integrate. At the same time, the industrial and          and Norway show predominantly negative effects at higher LCF quan­
environmental goals. In contrast, the more limited or context-specific          tiles, suggesting inefficiencies or diffusion barriers; Canada and
responses in France and Norway are consistent with nuclear- and                 Australia display mixed patterns driven by contextual factors; and Japan
hydropower-dominated systems, where technological trajectories are              records fewer but largely positive responses at high RD&D and mid-level
mature and the marginal ecological gains from additional RD&D are               LCF, reflecting incremental yet constrained progress. Collectively, these
comparatively smaller. This evidence indicates that the influence of            results imply that higher RD&D spending does not inherently guarantee
clean RD&D on ecological capacity depends not only on the scale of              ecological gains; its effectiveness depends on the interaction between
investment but also on how effectively countries convert research inputs        environmental capacity, innovation maturity, and each country’s ability
into technological diffusion and policy outcomes within their institu­          to absorb and transform technological advances into sustainable
tional–policy environment.                                                      outcomes.




                                                  Fig. 5. Marginal effect of Aggregated RD&D on LCF.



                                                                            9
B. Bergougui et al.                                                                                      Journal of Environmental Management 395 (2025) 127823




                                                 Fig. 6. Marginal effect of dirty energy RD&D on LCF.




                                                Fig. 7. Marginal effect of clean energy RD&D on LCF.


4.3.2. Dirty energy RD&D impact on LCF                                         illustrate these asymmetries: Canada, Sweden, and Australia exhibit
    Fig. 6 depicts the marginal effects of dirty energy RD&D expendi­          predominantly positive effects at low or moderate LCF, while Norway
tures on the LCF, revealing pronounced cross-country heterogeneity in          and Japan record negative impacts under weak ecological conditions,
both the magnitude and direction of impacts. Positive effects generally        with modest improvements only at higher LCF levels. France shows
emerge at low-to-middle LCF quantiles, suggesting that dirty energy-           consistently adverse effects across the distribution, likely due to struc­
related RD&D can temporarily enhance environmental capacity                    tural misalignment between dirty energy RD&D focus and sustainability
through efficiency gains or transitional technological improvements            objectives. Germany’s results are mixed, characterized by insignificant
when ecological systems are still developing. In contrast, negative ef­        or localized negative zones indicative of its transition from fossil to
fects tend to appear at higher LCF levels or under excessive RD&D in­          renewable energy. The United States displays a distinctly asymmetric
tensity, reflecting diminishing returns, technological lock-in, or             pattern, in which modest dirty energy RD&D enhances ecological per­
misaligned innovation priorities. Country-level patterns further               formance at lower LCF levels but becomes less effective as LCF increases.

                                                                          10
B. Bergougui et al.                                                                                           Journal of Environmental Management 395 (2025) 127823


Collectively, these findings indicate that dirty energy RD&D exerts state-         visible in extreme states of ecological performance.
dependent ecological effects, with outcomes determined by baseline
environmental capacity, innovation alignment, and the extent to which              5. Discussion of the findings
countries can redirect fossil-related research toward cleaner techno­
logical pathways.                                                                      The MQQKRLS estimates indicate a non-monotonic relationship be­
                                                                                   tween aggregate RD&D expenditures and the LCF, underscoring how
4.3.3. Clean energy RD&D impact on LCF                                             innovation interacts with environmental conditions and varies by
    Fig. 7 illustrates the MQQKRLS heatmaps of the marginal effects of             country and position in the distribution. Across the eight economies,
clean energy RD&D on the LCF, revealing substantial cross-country                  marginal effects change in sign and significance. Germany, the United
heterogeneity in both the sign and magnitude of effects. Overall, posi­            States, and Sweden exhibit predominantly positive impacts, especially at
tive impacts prevail at low-to-middle LCF quantiles and under high                 higher quantiles of both variables, consistent with threshold behavior.
RD&D intensity, suggesting that clean energy research is most effective            Once technological maturity and environmental performance reach
in strengthening ecological capacity during early and intermediate                 certain levels, additional RD&D translates more readily into capacity
development stages. Conversely, negative or insignificant effects are              gains. Countries with stronger RD&D ecosystems and sturdier environ­
more common in mature ecological states, reflecting diminishing                    mental baselines appear better able to convert budgets into measurable
returns where environmental quality and innovation saturation already              improvements. By contrast, France and Norway show weak or negative
prevail. Country-specific patterns further nuance these findings: Canada,          associations, suggesting diminishing marginal returns or a misalignment
Sweden, and the United States show broadly positive effects under                  between RD&D allocation and operational constraints. Norway’s limited
strong RD&D, indicating that clean innovation supports both recovery               or adverse effects, despite its very high share of low-carbon supply,
and consolidation phases; Germany records robust gains at high RD&D                suggest saturation of the energy system, where new spending adds little
and LCF levels, underscoring an efficient translation of clean-technology          unless it targets specific bottlenecks. Canada, Australia, and Japan
investment into ecological improvement; France and Australia display               exhibit mixed patterns, with both positive and negative effects that
mixed or asymmetric outcomes, with benefits concentrated at early                  occur only in specific quantile regions. In these cases, signals are
stages but diminishing as systems mature, pointing to coordination gaps;           consistent with systems in transition, where budget effectiveness de­
Norway exhibits predominantly weak or negative effects, consistent                 pends on technological maturity, institutional readiness, and the current
with limited potential for incremental gains given its high environ­               LCF state. Negative effects at lower LCF quantiles in Canada and
mental baseline; and Japan demonstrates positive outcomes concen­                  Australia point to early-stage inefficiencies, whereas positive effects at
trated in advanced ecological states, reflecting its focus on efficiency-          higher quantiles indicate improving returns as systems mature.
oriented innovation. Collectively, these results highlight that clean en­          Conceptually, these results challenge linear models of innovation
ergy RD&D generates state-dependent ecological benefits, with the                  adoption and motivate quantile-based approaches that allow for distri­
strongest payoffs arising when investment intensity aligns with the                butional heterogeneity. They also reinforce the role of path dependence:
system’s absorptive capacity and stage of ecological development.                  the productivity of RD&D depends on absorptive capacity, comple­
    Two mechanisms help explain weak or negative clean RD&D effects                mentary investments in grid and storage, and the ability of institutions
in specific cases. In Norway, a high environmental baseline and mature             to integrate new technologies into operations. In the context of the
clean infrastructure reduce marginal gains from additional spending. In            LCF—which embeds both ecological supply and demand—higher ca­
France, negative regions in the mid-to-upper LCF are consistent with               pacity levels typically reflect joint progress on demand-side efficiency
diffusion gaps and fragmented implementation, which limit the con­                 and supply-side clean deployment. The quantile patterns indicate that
version of budgets into capacity gains. In Japan, benefits materialize             clean RD&D has broader payoffs where diffusion and system integration
mainly in advanced phases, with few significant cells at low LCF and               are advanced, underscoring complementarity rather than a trade-off
isolated negatives—evidence of adjustment lags and integration con­                between efficiency and clean technologies.
straints. These mechanisms are consistent with a path-dependence                       The marginal effects of fossil (dirty) energy RD&D on LCF are highly
channel, where RD&D productivity hinges on absorptive capacity and                 context dependent. Patterns differ across countries and within the LCF
complementary investments.                                                         distribution, confirming that these budgets do not have uniform envi­
                                                                                   ronmental consequences. Canada, Australia, Sweden, and the United
4.4. Robustness analysis                                                           States show positive effects at low LCF quantiles, indicating that in
                                                                                   weaker ecological states, targeted spending on performance improve­
    To verify the consistency of the main results, this section applies the        ments for legacy assets can, in the short run, raise system capacity and
MQQR as a complementary check to the MQQKRLS estimations. While                    mitigate pressure. Even in these cases, reversals appear at higher LCF
MQQKRLS combines kernel-based regularization with quantile struc­                  quantiles in Australia and Sweden, with marginal effects turning nega­
tures, MQQR offers a more conventional econometric approach that                   tive once environmental capacity is already strong. France, Norway, and
focuses on how quantiles of the explanatory variables influence different          Germany offer a different picture. France displays broadly adverse ef­
quantiles of the dependent variable. Originally introduced by Sim and              fects across much of the distribution, consistent with the limited value of
Zhou (2015), the method has been used in recent applications to eval­              further fossil-oriented innovation in a system already anchored by
uate nonlinear and asymmetric relationships in environmental and en­               cleaner base-load. Norway shows negative effects at low LCF states and
ergy research (Adebayo et al., 2024; Adebayo et al., 2024; Ben Ali et al.,         only limited positives at higher quantiles. At the same time, Germany
2025a). The comparative exercise between MQQKRLS and MQQR,                         records mostly insignificant or adverse regions, including a clear nega­
presented in Appendix C, confirms a high degree of alignment between               tive cluster in the mid-to high-LCF range. Japan’s map shows a balance
the two approaches. In particular, the results indicate that the direction         of red and blue areas, with more pronounced negative effects when LCF
and significance of marginal effects remain stable across methodologies.           is low and fossil RD&D is high, a sign that misaligned spending can
For countries such as Canada, France, the United States, and Norway,               compound pressure when systems are already strained. The United
both estimators consistently point to strong positive effects of clean             States, in turn, records beneficial signals at lower RD&D intensities and
RD&D on the upper quantiles of LCF, as well as negative effects of fossil          low-to-moderate LCF, yet localized negative patches emerge at higher
RD&D, especially at the tails of the distribution. These findings reinforce        LCF, which indicates that conventional or unbalanced allocations can
the robustness of the main conclusions: clean energy investment                    erode gains once capacity is strong. These patterns suggest that fossil
strengthens ecological capacity. At the same time, fossil-related RD&D             RD&D may have a narrow role as transitional, efficiency-oriented
generally intensifies environmental stress, with the adverse effects most          spending, while broad increases risk locking in carbon-intensive

                                                                              11
B. Bergougui et al.                                                                                         Journal of Environmental Management 395 (2025) 127823


pathways or crowding out cleaner options.                                        national RD&D budgets—both in aggregate and split into clean and
    Clean energy RD&D shows a different profile. Canada, the United              fossil components—and environmental quality measured by the LCF,
States, and Germany report consistent, widespread positive effects,              using monthly data from January 1990 to December 2023 across eight
especially in the mid-to-upper quantiles, suggesting that where inno­            strategically selected advanced economies. The sample follows a struc­
vation ecosystems and deployment infrastructure are well developed,              tured two-by-two design, encompassing high-industrialized countries
budgets translate into operational improvements. Canada’s corridor of            with LCF surpluses (Canada and Norway) and deficits (Germany and
strong effects between mid LCF and high clean RD&D suggests absorp­              Japan), alongside low-industrialized countries with LCF surpluses
tion into the grid rather than mere pipeline accumulation. The United            (Sweden and Australia) and deficits (France and the USA). This sys­
States shows gains at both low and high LCF states, indicating effec­            tematic approach ensures comprehensive coverage of both industriali­
tiveness in early corrective phases and in advanced conditions with              zation levels and load capacity positions. Employing the MQQKRLS
substantial investment. Norway, by comparison, records limited bene­             framework, the results indicate a non-monotonic, heterogeneous asso­
fits, consistent with innovation saturation in a system already domi­            ciation in which the sign and strength of the marginal effects vary across
nated by low-emission supply. Australia’s results reveal thresholds:             countries and along the joint distribution of RD&D and LCF.
negative impacts at low LCF and positive impacts at high clean RD&D,                 The analysis reveals that Germany, the United States, and Sweden
indicating that budgets must be paired with enabling conditions such as          exhibit predominantly positive effects of aggregate and clean RD&D,
grid modernization and institutional support. Sweden, Japan, and                 especially at higher quantiles of both variables, consistent with
France present more complex mixes of weak positives and localized                threshold behavior in which benefits emerge once technological matu­
negatives. In Japan, stronger effects concentrate in the upper halves of         rity and environmental performance reach sufficient levels. By contrast,
both distributions, whereas in France, negative regions appear in the            France and Norway show weak or negative links, a pattern aligned with
mid-to-upper LCF, despite modest positives at low LCF. These configu­            system saturation, misaligned budget allocation, or diminishing mar­
rations point to implementation frictions and the need for complemen­            ginal returns in already advanced energy systems. Fossil-oriented RD&D
tary reforms. The presence of insignificant regions at lower LCF levels          exhibits country-specific and quantile-dependent effects, with Canada,
across several countries further indicates that simply raising clean             Australia, and the United States registering improvements mainly at
RD&D is unlikely to deliver broad improvements without addressing                lower LCF quantiles. At the same time, gains fade or reverse as LCF rises.
infrastructure constraints, resource capacity, and regulatory procedures.        This suggests a limited transitional role focused on efficiency upgrades
    Policy implications follow from these distributional results and the         rather than long-run environmental progress. In systems already
MQQR robustness checks in Appendix B. First, aggregate increases in              anchored by cleaner supply—such as France, Germany, New York, and
RD&D are not a sufficient condition for environmental gains. Budgets             Norway—continued fossil RD&D tends to be counterproductive. Clean
should be targeted to clean technologies and matched with grid and               RD&D demonstrates more consistent positive outcomes, particularly in
storage investments, streamlined permitting, and market designs that             Canada, the United States, and Germany, where innovation capacity and
reward flexibility and integration. Within the clean portfolio, renew­           deployment infrastructure facilitate effective absorption. Mixed results
ables- and efficiency-oriented RD&D should be prioritized to deliver             in Japan, France, and Sweden highlight conditional effectiveness shaped
broad-based gains in the LCF. Nuclear RD&D plays a complementary                 by institutional frameworks, policy design, and integration constraints.
role where firm low-carbon supply is required and existing fleets are in
place; in such mature systems, however, the marginal contribution to             6.2. Policy implications
the LCF tends to be smaller. Second, fossil RD&D should be tightly
scoped to transitional efficiency upgrades and managed to avoid lock-in,             Based on the empirical findings, this research provides recommen­
especially in higher-LCF states where returns are weak or negative.              dations to accelerate the transition toward net-zero economies in top
Third, countries operating near the top of the LCF distribution should           RD&D-investing countries. The findings suggest that the effects of RD&D
prioritize bottleneck removal and system integration rather than volume          on environmental quality are heterogeneous, depending on countries,
expansion, since saturation effects can mute the impact of additional            RD&D intensity, and environmental performance. These findings do not
spending. Finally, programs should be sequenced according to each                align with the common consensus that greater RD&D budgets lead to
country’s position in the LCF distribution: early-stage systems benefit          better environmental indicators. Consequently, policymakers should
from efficiency and foundational clean deployment, while mature sys­             avoid designing or implementing uniform policies and instead adopt
tems require targeted innovation in hard-to-abate sectors and comple­            specific RD&D strategi that takeng into account national conditions,
mentary infrastructure to sustain further gains. A brief policy note is          such as existing energy-related technologies and the absorptive capacity
provided here; expanded implications are developed in Section 6.2.               of innovation systems. Additionally, before implementing RD&D stra­
                                                                                 tegies, it is important to conduct a thorough assessment to identify the
6. Conclusion                                                                    most urgent environmental challenges, comprehend existing techno­
                                                                                 logical deficiencies, and evaluate the absorptive capacity of the national
6.1. Summary of the findings                                                     ecosystem.
                                                                                     Countries with strong innovation ecosystems and high environ­
   The relationship between research, development, and demonstration             mental performance, including the United States, Germany, and Swe­
(RD&D) investments and environmental outcomes is a critical area of              den, should be selective regarding RD&D investments. The ongoing
inquiry for sustainable development policy. While conventional wisdom            investments in fossil-focused RD&D in these countries seem ineffective
suggests that increased RD&D spending should translate into improved             for environmental protection. Indeed, energy systems in these countries
environmental performance, the empirical evidence reveals a more                 may experience declining returns because of technological saturation.
complex picture characterized by significant heterogeneity across                Due to strong innovation ecosystems, they are close to reaching critical
countries and technological domains. The challenge lies in under­                thresholds of technological maturity, at which clean innovations can
standing not only whether RD&D investments matter for environmental              provide significant environmental benefits. Therefore, they should
quality, but also under what conditions, at what scales, and through             optimize RD&D investments by prioritizing advanced environmental
which pathways these investments generate meaningful environmental               technologies. Another important policy direction for countries with
benefits. This complexity is particularly pronounced when examining              robust innovation ecosystems is to position themselves as global hubs for
the differential impacts of clean versus fossil-oriented RD&D spending           the transfer of clean technologies by fostering joint ventur­
across countries with varying levels of industrialization and environ­           esstrengthening innovation system capacityms, and creating RD&D
mental performance. This research examined the relationship between              platforms within less developed economies. For emerging countries,

                                                                            12
B. Bergougui et al.                                                                                         Journal of Environmental Management 395 (2025) 127823


actively participating in these global hubs may improve their ability to          countries with different innovation systems and environmental condi­
innovate and speed up their shift towards cleaner energy sources. By              tions. Contingent on data availability, future studies could expand the
engaging in international collaborations and utilizing shared RD&D                sample to include additional countries to examine whether the observed
knowledge, emerging economies can overcome challenges related to                  heterogeneity in the impact of RD&D on environmental quality across
limited financial resources and a lack of technical expertise. Building           top RD&D-investing nations persists. Second, relying solely on the load
these connections is vital for emerging countries, among others, to               capacity factor as a measure of environmental quality, although
achieve SDG7 and foster energy transition. In countries such as France            comprehensive, may not allow for accounting for other dimensions of
and Norway, the weak/negative impacts of RD&D on environmental                    environmental performance. Employing alternative environmental in­
performance suggest that increased RD&D investments are no longer                 dicators could confirm the robustness of the findings and the design of
effective. These findings suggest potential system saturation and                 specific policy implications. For example, using the different compo­
diminishing marginal returns, in which additional RD&D funding yields             nents of the ecological footprint—such as built-up land, carbon foot­
weak environmental benefits. In these nations, policymakers should                print, and fishing grounds, among others-could yield more detailed
reevaluate the allocation of RD&D funds, placing more emphasis on                 outcomes. Finally, while the MMQKRLS allows capturing complex
energy systems, including grid flexibility and storage.                           distributional dynamics, it does not identify the causal mechanisms
    In Canada and Australia, fossil RD&D shows some benefits at lower             through which RD&D spending may influence environmental outcomes.
levels of environmental performance, suggesting positive short-term               To examine how RD&D affects environmental quality, a causal media­
environmental benefits resulting from fossil-oriented innovation,                 tion analysis can be conducted to identify indirect pathways through
particularly through enhanced energy efficiency. However, the positive            which RD&D may affect environmental outcomes.
environmental impact of fossil RD&D declines as environmental per­
formance improves, suggesting that such efforts should be phased out              CRediT authorship contribution statement
strategically to shift toward clean alternatives. These findings emphasize
that fossil RD&D is a limited solution for environmental protection and              Brahim Bergougui: Writing – review & editing, Writing – original
may not constitute a long-term environmental strategy. To avoid pro­              draft, Validation, Supervision, Conceptualization. Reda Hamza Boud­
longed reliance on fossil-fuel-polluting systems, policymakers should set         jana: Writing – original draft, Visualization, Software, Methodology.
phase-out schedules for fossil RD&D programs, gradually reducing them             Samer Mehibel: Writing – original draft, Conceptualization. Ousama
as clean technologies become more viable and adopted. During the                  Ben-Salha: Writing – original draft, Investigation, Formal analysis.
transition towards cleaner energy systems, fossil RD&D initiatives                Manuel A. Zambrano-Monserrate: Writing – review & editing,
should undergo comprehensive impact assessments to avoid resource                 Validation.
misallocation and conflicts with long-term climate goals. Finally, fossil
RD&D initiatives should be strictly conditioned on providing tangible             Declaration of competing interest
short-term environmental gains and demonstrating alignment with
long-term national climate objectives.                                                The authors declare that they have no known competing financial
                                                                                  interests or personal relationships that could have appeared to influence
6.3. Limitations and avenues for future research                                  the work reported in this paper.

    Despite providing insights into the effects of RD&D investments on            Acknowledgement
environmental quality, this study has some limitations that may be
addressed in future research. First, the empirical investigation is con­             The authors extend their appreciation to Northern Border University,
strained to the eight top RD&D-investing nations, which may limit the             Saudi Arabia, for supporting this work through project number (NBU-
generalizability of the findings to emerging and other developed                  CRP-2025-2922).



Appendix

Appendix A



Table A.1
Descriptive Statistics

  Countries              Variable                  Mean          SD               Min             Max             Skewness            Kurtosis            JB

  ​                      LCF                        0.659        0.151            − 0.490          0.989          − 1.721               9.848             0.000
  Canada                 Fossil_energy              2.716        0.659              0.952          4.338            0.446             − 0.405             0.000
                         Clean_energy               3.152        0.448              2.021          4.108          − 0.240             − 0.476             0.022
                         Total_budget               4.087        0.477              2.950          5.036            0.082             − 1.296             0.000
                         renewable_energy_cons     21.994        2.596              6.568         31.442          − 0.595               5.544             0.000
                         EPS                        2.024        1.128              0.376          4.175          − 0.011             − 1.511             0.000
                         Co2_per capita             0.306        0.145            − 0.774          0.710          − 2.167              10.456             0.000
  ​                      LGDPC                      8.081        0.177              6.955          8.530          − 1.029               4.170             0.000

  Germany                LCF                       − 1.178       0.150            − 2.272         − 0.796         − 1.320               8.636             0.000
                         Fossil_energy               1.079       1.068            − 8.056           2.902         − 2.678              14.576             0.000
                         Clean_energy                3.946       0.341              2.549           4.616         − 0.435             − 0.417             0.000
                         Total_budget                4.402       0.513              2.023           5.331         − 0.277             − 0.205             0.053
                         renewable_energy_cons       9.085       5.955              0.707          21.049           0.185             − 1.493             0.000
                         EPS                         2.567       0.808              1.064           4.364         − 0.097             − 1.338             0.000
                         Co2_per capita            − 0.163       0.191            − 1.250           0.283         − 1.642               4.476             0.000
                                                                                                                                        (continued on next page)



                                                                             13
B. Bergougui et al.                                                                                 Journal of Environmental Management 395 (2025) 127823

Table A.1 (continued )
  Countries           Variable                   Mean             SD            Min       Max             Skewness               Kurtosis            JB

                      LGDPC                       8.034           0.178          6.793     8.464          − 1.202                 6.591              0.000

  Japan               LCF                        − 2.011          0.142         − 3.113   − 1.629         − 1.306                 10.745             0.000
                      Fossil_energy                3.301          0.500           1.532     4.169         − 1.269                  1.001             0.000
                      Clean_energy                 5.506          0.281           4.612     5.995         − 1.059                  0.115             0.000
                      Total_budget                 5.845          0.182           4.929     6.291         − 0.919                  1.683             0.000
                      renewable_energy_cons        5.124          1.807           0.547    10.218           0.946                − 0.025             0.000
                      EPS                          2.938          0.900           0.785     4.634         − 0.212                − 1.110             0.000
                      Co2_per capita             − 0.241          0.146         − 1.457     0.141         − 2.945                 16.603             0.000
                      LGDPC                        7.903          0.147           6.658     8.309         − 2.347                 16.765             0.000

  Norway              LCF                          0.258          0.156         − 1.048    0.579          − 2.525                 15.270             0.000
                      Fossil_energy                1.792          0.723           0.628    3.321            0.351                − 1.046             0.000
                      Clean_energy                 1.348          0.883         − 2.151    3.444            0.115                − 0.104             0.593
                      Total_budget                 2.682          0.809           1.404    4.133            0.191                − 1.649             0.000
                      renewable_energy_cons       58.744          6.556          17.649   84.730          − 1.082                  7.564             0.000
                      EPS                          2.717          1.084           1.012    4.770            0.066                − 1.565             0.000
                      Co2_per capita             − 0.322          0.149         − 1.344    0.099          − 1.831                  7.538             0.000
                      LGDPC                        8.647          0.177           7.604    9.107          − 1.077                  3.364             0.000

  Sweden              LCF                          0.506          0.146         − 0.393     0.871         − 0.995                  4.281             0.000
                      Fossil_energy              − 2.792          1.584         − 7.064   − 0.004           0.021                − 0.725             0.013
                      Clean_energy                 1.402          0.658         − 4.515     2.377         − 3.894                 26.502             0.000
                      Total_budget                 2.621          0.437           1.092     3.473         − 0.102                − 0.752             0.007
                      renewable_energy_cons       42.785          9.919          12.195    69.789           0.402                − 0.595             0.000
                      EPS                          2.786          1.052           1.002     4.817         − 0.334                − 1.325             0.000
                      Co2_per capita             − 0.819          0.261         − 1.880   − 0.437         − 1.061                  0.684             0.000
                      LGDPC                        8.209          0.205           7.052     8.672         − 0.745                  1.950             0.000

  France              LCF                        − 0.694          0.147         − 2.035   − 0.349         − 2.787                 21.654             0.000
                      Fossil_energy                2.358          0.735           0.523     3.674           0.165                − 1.165             0.000
                      Clean_energy                 4.682          0.326           3.683     5.640           0.253                − 0.054             0.110
                      Total_budget                 4.975          0.442           4.164     5.971         − 0.153                − 1.132             0.000
                      renewable_energy_cons       11.703          2.843           2.249    19.438           0.405                − 0.209             0.003
                      EPS                          2.982          1.370           0.926     5.814           0.117                − 1.466             0.000
                      Co2_per capita             − 0.712          0.213         − 1.713   − 0.319         − 1.302                  1.869             0.000
                      LGDPC                        7.942          0.160           6.819     8.380         − 1.273                  6.873             0.000

  USA                 LCF                         1.117           0.184           0.443    1.809            0.348                  0.863             0.000
                      Fossil_energy               0.053           0.018           0.012    0.123            0.921                  1.410             0.000
                      Clean_energy                5.007           0.534           4.009    6.131          − 0.125                − 1.173             0.000
                      Total_budget                6.212           0.388           5.598    7.201            0.355                − 1.057             0.000
                      renewable_energy_cons       7.009           2.502           1.484   12.949            0.388                − 1.162             0.000
                      EPS                         1.880           0.794           0.578    3.586            0.424                − 1.374             0.000
                      Co2_per capita              0.421           0.183         − 0.629    0.823          − 1.551                  3.815             0.000
                      LGDPC                       8.347           0.196           7.127    8.784          − 0.907                  3.706             0.000




Table A.2
BDS test

  Country                Variables                    Dimension

                                                      m=2                 m=3             m=4                       m=5                      m=6

  Australia              LCF                           84.95***            125.12***       199.68***                 344.33***                  635.48***
                         TRD&D                         62.05***             95.63***       159.61***                 287.74***                  551.16***
                         FRD&D                         96.92***            168.28***       319.21***                 659.87***                 1462.14***
                         CRD&D                        215.61***            374.97***       711.12***                1468.52***                 3223.22***
                         renewable_energy_cons         50.24***             73.04***       114.85***                 194.64***                  358.74***
                         EPS                          243.17***            415.02***       770.08***                1550.31***                 3330.21***
                         HC                            21.39***             29.01***        39.95***                  58.51***                   89.66***
                         Co2_per capita                41.90***             57.52***        83.44***                 131.15***                  220.22***
                         GDPC                         175.84***            280.87***       496.51***                 957.55***                 1984.99***
                         nat_res_rent                  72.17***            106.06***       165.81***                 276.23***                  485.58***
                         inst                         138.07***            221.57***       406.63***                 826.83***                 1831.60***

  Canada                 LCF                           88.45***            129.67***       204.41***                 350.62***                 657.83***
                         TRD&D                        619.53***           1103.48***      2157.31***                4579.01***               10373.72***
                         FRD&D                        185.62***            325.97***       638.13***                1356.11***                3062.53***
                         CRD&D                        102.87***            176.49***       331.62***                 681.76***                1499.43***
                         renewable_energy_cons         34.48***             47.44***        68.62***                 110.62***                 192.82***
                         EPS                          343.54***            579.32***      1062.63***                2120.14***                4526.23***
                         HC                            32.93***             44.80***        66.06***                 104.08***                 172.77***
                         Co2_per capita                43.69***             59.18***        83.26***                 126.73***                 207.30***
                         GDPC                         130.36***            198.72***       334.46***                 611.33***                1219.67***
                         nat_res_rent                  89.30***            150.39***       274.34***                 539.89***                1122.85***
                                                                                                                                   (continued on next page)




                                                                           14
B. Bergougui et al.                                                               Journal of Environmental Management 395 (2025) 127823

Table A.2 (continued )
  Country                Variables               Dimension

                                                 m=2         m=3         m=4                    m=5                     m=6

                         inst                     36.28***    50.81***     78.46***              130.79***                 232.13***

  France                 LCF                      38.81***    51.49***     73.30***              110.67***                176.55***
                         TRD&D                   157.11***   252.01***    435.68***              811.48***               1599.41***
                         FRD&D                   119.17***   195.88***    349.97***              678.26***               1401.06***
                         CRD&D                   152.00***   252.19***    457.86***              905.52***               1909.33***
                         renewable_energy_cons    90.54***   143.26***    249.71***              476.57***                974.88***
                         EPS                     271.61***   452.58***    823.37***             1634.28***               3493.93***
                         HC                       35.88***    49.13***     72.91***              117.75***                200.83***
                         Co2_per capita           52.68***    77.97***    124.14***              212.61***                385.46***
                         GDPC                    104.93***   156.75***    257.09***              457.66***                879.86***
                         nat_res_rent            124.77***   206.87***    370.75***              717.73***               1485.89***
                         inst                     76.46***   116.89***    198.35***              373.56***                758.30***

  Germany                LCF                      50.97***    69.53***    103.23***              165.60***                283.77***
                         TRD&D                   370.36***   666.18***   1313.24***             2821.03***               6478.75***
                         FRD&D                    62.63***    91.22***    139.97***              228.04***                390.52***
                         CRD&D                   174.36***   287.10***    512.14***              985.95***               2013.87***
                         renewable_energy_cons   222.80***   374.51***    683.86***             1357.41***               2888.84***
                         EPS                     248.59***   391.65***    672.45***             1250.69***               2489.31***
                         HC                       24.72***    33.88***     48.43***               72.77***                115.00***
                         Co2_per capita           41.94***    57.74***     83.42***              129.35***                213.97***
                         GDPC                    137.07***   208.02***    348.61***              633.82***               1236.87***
                         nat_res_rent             64.70***    97.40***    155.75***              265.17***                474.98***
                         inst                     41.67***    60.65***     96.76***              166.85***                308.61***

  Japan                  LCF                      45.91***    62.25***     90.72***              141.37***                232.20***
                         TRD&D                    61.25***    94.43***    155.78***              282.59***                561.43***
                         FRD&D                    40.82***    55.45***     79.08***              119.41***                188.41***
                         CRD&D                    39.80***    54.51***     77.76***              116.73***                183.51***
                         renewable_energy_cons    45.92***    64.80***     97.03***              155.97***                263.87***
                         EPS                     427.70***   743.21***   1449.01***             3095.50***               7099.72***
                         HC                       33.25***    45.23***     66.61***              105.13***                174.89***
                         Co2_per capita           27.29***    34.55***     45.14***               62.11***                 90.36***
                         GDPC                     55.72***    74.94***    108.42***              167.95***                276.41***
                         nat_res_rent             43.90***    55.61***     73.18***              100.65***                144.02***
                         inst                    261.02***   449.07***    856.39***             1797.18***               4085.18***

  Norway                 LCF                      41.45***    56.95***     82.06***              125.67***                205.53***
                         Total_budget            223.81***   332.55***    524.51***              881.77***               1560.53***
                         Fossil_energy           221.41***   392.66***    764.52***             1630.61***               3716.45***
                         Clean_energy            122.16***   199.72***    351.47***              668.23***               1346.82***
                         renewable_energy_cons    26.14***    35.66***     48.66***               70.49***                107.71***
                         EPS                     289.34***   487.39***    897.70***             1798.63***               3864.78***
                         Humain_capital           35.23***    48.14***     71.53***              115.31***                196.73***
                         Co2_per capita           43.43***    58.38***     83.03***              127.94***                211.13***
                         LGDPC                    66.71***    96.74***    152.86***              260.67***                476.54***
                         nat_res_rent            152.57***   255.31***    461.42***              904.28***               1881.00***
                         regulatory               79.64***   122.23***    210.25***              396.61***                825.22***

  Sweden                 LCF                      44.29***    62.80***     93.85***              157.19***                281.88***
                         Total_budget            327.59***   606.03***   1237.41***             2775.84***               6685.13***
                         Fossil_energy           287.55***   520.46***   1036.64***             2257.50***               5290.64***
                         Clean_energy             61.46***    82.70***    116.20***              172.24***                267.27***
                         renewable_energy_cons   114.80***   184.47***    328.04***              636.47***               1317.67***
                         EPS                     146.72***   226.89***    378.93***              684.14***               1314.58***
                         Humain_capital           29.83***    41.00***     60.30***               94.30***                155.33***
                         Co2_per capita           63.18***    96.46***    158.33***              280.06***                525.91***
                         LGDPC                   196.72***   315.62***    557.72***             1076.58***               2236.59***
                         nat_res_rent             46.35***    65.25***     96.63***              151.56***                250.24***
                         regulatory              202.81***   333.00***    622.12***             1274.94***               2842.90***

  USA                    LCF                      81.32***   115.56***    177.12***              293.73***                527.79***
                         Total_budget            161.08***   258.62***    450.20***              852.20***               1716.74***
                         Fossil_energy            40.99***    55.77***     79.59***              119.42***                187.83***
                         Clean_energy            305.56***   541.93***   1051.58***             2225.13***               5017.00***
                         renewable_energy_cons   117.79***   189.55***    332.56***              632.66***               1282.76***
                         EPS                      97.64***   152.90***    262.59***              485.42***                953.25***
                         Humain_capital           27.07***    37.01***     53.84***               82.28***                132.09***
                         Co2_per capita           45.47***    65.31***    100.49***              166.29***                291.63***
                         LGDPC                   159.67***   249.74***    427.87***              805.94***               1640.00***
                         nat_res_rent            104.25***   174.46***    316.10***              616.97***               1276.69***
                         regulatory               38.68***    55.07***     84.57***              140.57***                248.01***




                                                             15
                                                                                                                                                                                                          B. Bergougui et al.
     Table A.3
     Parameter Stability Tests Estimates
      Country        Stat        LCF              TRD&D             DRD&D            CRD&D             renewable         EPS            HC          Co2          GDPC         nat_res_rent   inst

      Australia      Max-F       243.643***        171.276***        286.646***      1065.794***        363.828***       2122.704***     4.08        77.049***   404.878***   331.866***     334.798***
                     Exp-F       118.174***         81.106***        138.167***       527.408***        177.35***        2122.704***     0.639       34.016***   197.767***   161.638***     162.637***
                     Ave-F       110.032***         69.16***          58.93***        405.677***        141.234***        782.094***     1.03        27.343***   270.431***   188.489***     205.415***
      Canada         Max-F       150.351***        978.764***        298.545***       364.9***           30.601***       1824.474***    49.17***    115.9***     292.371***    67.584***     122.224***
                     Exp-F        70.763***        483.738***        144.742***       177.574***         12.074***       1824.474***    20.058***    52.675***   141.959***    29.335***      56.155***
                     Ave-F        61.101***        368.924***        112.004***        88.298***         12.685***        602.566***    29.037***    45.809***   173.535***    16.617***      58.783***
      France         Max-F        94.297***       1482.17***         261.578***       565.35***         662.625***       1412.694***    88.03***    515.08***    194.378***   531.121***     191.32***
                     Exp-F        42.994***       1482.17***         126.09***        277.606***        325.902***        701.294***    39.146***   251.91***     93.203***   261.474***      91.118***
                     Ave-F        42.566***        488.813***         63.818***       291.861***        286.419***        683.156***    48.064***   255.17***    123.855***   284.098***      61.247***
      Germany        Max-F       107.044***        955.186***         81.341***       398.629***       1688.66***        1461.911***    19.907***   253.9***     288.979***    74.405***      90.236***
                     Exp-F        48.614***        472.133***         37.197***       194.264***       1688.66***        1461.911***     6.248***   121.51***    139.197***    34.01***       40.227***
                     Ave-F        77.244***        371.276***         39.602***       128.331***        782.785***        508.834***     9.43***    166.42***    171.316***    26.893***      48.686***
      Japan          Max-F       126.657***        258.97***         114.463***      1133.734***       1293.95***         722.395***    55.349***    78.895***    96.23***    724.708***     866.088***
16




                     Exp-F        58.319***        124.998***         53.19***        561.299***        641.317***        356.649***    22.997***    35.146***    43.237***   357.138***     427.438***
                     Ave-F        60.064***         99.416***         30.028***       318.763***        458.871***        466.874***    31.28***     23.622***    61.441***   184.034***     324.803***
      Norway         Max-F       106.885***       4230.67***        1186.912***      1314.767***          8.193*         1633.202***    74.391***    96.903***   299.513***   135.786***     176.875***
                     Exp-F        49.006***       4230.67***         588.063***       651.884***          2.532**        1633.202***    32.444***    43.773***   145.557***    63.605***      83.288***
                     Ave-F        40.779***        678.711***        409.579***       379.688***          3.795**         648.432***    41.434***    33.817***   157.736***    28.397***      66.443***
      Sweden         Max-F        52.926***        953.733***        180.911***        34.503***        720.996***       1741.503***    48.46***    583.333***   389.748***   491.603***     354.567***
                     Exp-F        22.881***        471.278***         85.229***        14.494***        355.099***       1741.503***    19.574***   286.057***   190.5***     240.82***      172.721***
                     Ave-F        20.159***        379.226***         76.248***        16.136***        363.784***        587.33***     23.66***    310.996***   253.013***   167.524***     199.549***
      USA            Max-F       122.058***       1278.584***         62.753***      1006.043***       1368.816***       1556.666***    31.241***   401.834***   273.33***     69.46***      158.895***
                     Exp-F        56.106***        633.7***           26.608***       497.794***        678.839***       1556.666***    11.217***   195.311***   132.693***    30.663***      74.144***
                     Ave-F        47.497***        431.024***          7.671***       324.981***        576.32***         645.968***    15.318***   177.298***   210.652***    17.47***       59.252***

     Note: The table presents the stability status of the data series. PV: Probability Value. *** PV < 1 %, ** PV < 5 %, * PV < 10 %.




                                                                                                                                                                                                          Journal of Environmental Management 395 (2025) 127823
B. Bergougui et al.                                                   Journal of Environmental Management 395 (2025) 127823




Appendix B




                      Fig. B.1. QQGC from total budget RD&D on LCF.




                      Fig. B.2. QQGC from dirty energy RD&D on LCF.




                                           17
B. Bergougui et al.                                                                                                              Journal of Environmental Management 395 (2025) 127823




                                                               Fig. B.3. QQGC from clean energy RD&D on LCF.



Appendix C




Data availability                                                                                Adebayo, T.S., Özkan, O., Eweade, B.S., 2024b. Do energy efficiency R&D investments
                                                                                                    and information and communication technologies promote environmental
                                                                                                    sustainability in Sweden? A quantile-on-quantile KRLS investigation. J. Clean. Prod.
    Data will be made available on request.                                                         440, 140832.
                                                                                                 Ahmed, Z., Cary, M., Shahbaz, M., Vo, X.V., 2021. Asymmetric nexus between economic
                                                                                                    policy uncertainty, renewable energy technology budgets, and environmental
References
                                                                                                    sustainability: evidence from the United States. J. Clean. Prod. 313, 127723. https://
                                                                                                    doi.org/10.1016/J.JCLEPRO.2021.127723.
Adebayo, T.S., Meo, M.S., Eweade, B.S., Özkan, O., 2024a. Examining the effects of solar        Ahakwa, I., Xu, Y., Tackie, E.A., 2023. Greening human capital towards environmental
   energy innovations, information and communication technology, and financial                      quality in Ghana: Insight from the novel dynamic ARDL simulation approach. Energy
   globalization on environmental quality in the United States via quantile-on-quantile             Policy 176, 113514. https://doi.org/10.1016/j.enpol.2023.113514.
   KRLS analysis. Sol. Energy 272, 112450.


                                                                                            18
B. Bergougui et al.                                                                                                                   Journal of Environmental Management 395 (2025) 127823

Ahmed, Z., Ahmad, M., Murshed, M., Ibrahim Shah, M., Mahmood, H., Abbas, S., 2022.                   Chovancová, J., Zambrano-Monserrate, M.A., Bergougui, B., Ahakwa, I., Dam, M.M.,
    How do green energy technology investments, technological innovation, and trade                       2024. Global determinants of methane emissions in OECD countries: a dynamic
    globalization enhance green energy supply and stimulate environmental                                 panel approach. Research in Globalization 9, 100232. https://doi.org/10.1016/j.
    sustainability in the G7 countries? Gondwana Res. 112, 105–115. https://doi.org/                      resglo.2024.100232.
    10.1016/J.GR.2022.09.014.                                                                        Dogan, A., Pata, U.K., 2022. The role of ICT, R&D spending and renewable energy
Akadiri, S. Saint, Adebayo, T.S., Riti, J.S., Awosusi, A.A., Inusa, E.M., 2022. The effect of             consumption on environmental quality: testing the LCC hypothesis for G7 countries.
    financial globalization and natural resource rent on load capacity factor in India: an                J. Clean. Prod. 380, 135038. https://doi.org/10.1016/J.JCLEPRO.2022.135038.
    analysis using the dual adjustment approach. Environ. Sci. Pollut. Control Ser. 29               Durmus, S., Batu Ağirkaya, M., Akyol, H., 2025. Drivers of the load capacity factor in
    (59), 89045–89062. https://doi.org/10.1007/s11356-022-22012-0.                                        new i˙ndustrialized countries: economic growth, financial development and
Alola, A.A., Alola, U.V., Akdag, S., Yildirim, H., 2022. The role of economic freedom and                 urbanization on load capacity factor. Int. J. Econ. Financ. Issues 15, 184–195.
    clean energy in environmental sustainability: implication for the G-20 economies.                     https://doi.org/10.32479/ijefi.18988.
    Environ. Sci. Pollut. Control Ser. 29 (24), 36608–36615. https://doi.org/10.1007/                Eberhart, S., Schmidt, T.S., Steffen, B., Egli, F., 2025. The internationalization of
    s11356-022-18666-5.                                                                                   renewable energy finance. iScience 28 (5), 112367. https://doi.org/10.1016/J.
Altıntaş, H., Kassouri, Y., 2020. The impact of energy technology innovations on cleaner                 ISCI.2025.112367.
    energy supply and carbon footprints in Europe: a linear versus nonlinear approach.               Emre Caglar, A., Gökçe, N., Balsalobre-Lorente, D., 2024. Towards the vision of going
    J. Clean. Prod. 276, 124140. https://doi.org/10.1016/J.JCLEPRO.2020.124140.                           green: the role of different energy research and development investments,
Alvarado, R., Tillaguango, B., Dagar, V., Ahmad, M., Işık, C., Méndez, P., Toledo, E.,                  urbanization and income in load capacity factor. Sustain. Energy Technol.
    2021. Ecological footprint, economic complexity and natural resources rents in Latin                  Assessments 68, 103888. https://doi.org/10.1016/J.SETA.2024.103888.
    America: empirical evidence using quantile regressions. J. Clean. Prod. 318, 128585.             Ferwerda, J., Hainmueller, J., Hazlett, C.J., 2017. Kernel-based regularized least squares
    https://doi.org/10.1016/J.JCLEPRO.2021.128585.                                                        in R (KRLS) and Stata (krls). J. Stat. Software 79, 1–26.
Andrews, D.W.K., 1993. Tests for parameter instability and structural change with                    GFN, 2025. Global Footprint Network.
    unknown change point. Econometrica: J. Econom. Soc. 821–856.                                     Granger, C.W.J., 1969. Investigating causal relations by econometric models and cross-
Andrews, D.W.K., Ploberger, W., 1994. Optimal tests when a nuisance parameter is                          spectral methods. Econometrica: J. Econom. Soc. 424–438.
    present only under the alternative. Econometrica: J. Econom. Soc. 1383–1414.                     Greenpeace International, 2011. Annual Report 2011.
Ardito, L., Petruzzelli, A.M., Ghisetti, C., 2019. The impact of public research on the              Guloglu, B., Emre Caglar, A., Korkut Pata, U., 2023. Analyzing the determinants of the
    technological development of industry in the green energy field. Technol. Forecast.                   load capacity factor in OECD countries: evidence from advanced quantile panel data
    Soc. Change 144, 25–35. https://doi.org/10.1016/J.TECHFORE.2019.04.007.                               methods. Gondwana Res. 118, 92–104. https://doi.org/10.1016/J.GR.2023.02.013.
Avci, S.B., Caglar, A.E., 2025. Exploring the United States’ 2050 net zero-emission paths            Hainmueller, J., Hazlett, C., 2014. Kernel regularized least squares: reducing
    via nonlinear Fourier procedures: the role of low-carbon energy technology, income                    misspecification bias with a flexible and interpretable machine learning approach.
    and foreign direct investments. Nucl. Eng. Technol. 57 (5), 103380. https://doi.org/                  Polit. Anal. 22 (2), 143–168.
    10.1016/J.NET.2024.103380.                                                                       IEA, 2018. CO2 Emissions from Fuel Combustion: Overview. International Energy
Baloch, M.A., Ozturk, I., Bekun, F.V., Khan, D., 2021. Modeling the dynamic linkage                       Agency.
    between financial development, energy innovation, and environmental quality: does                IEA, 2024. World Energy Investment 2024 :Overview and Key Findings.
    globalization matter? Bus. Strat. Environ. 30 (1), 176–184. https://doi.org/10.1002/             IEA, 2025. World Energy Investment 2025.
    bse.2615.                                                                                        Inuwa, N., Rej, S., Onwe, J.C., Hossain, Md E., 2025. Do clean energy and dependence on
Balsalobre, D., Álvarez, A., Cantos, J.M., 2015. Public budgets for energy RD&D and the                  natural resources stimulate environmental sustainability? A new approach with load
    effects on energy intensity and pollution levels. Environ. Sci. Pollut. Control Ser. 22               capacity factor and temperature. Nat. Resour. Forum 49 (1), 800–823. https://doi.
    (7), 4881–4892. https://doi.org/10.1007/s11356-014-3121-3.                                            org/10.1111/1477-8947.12414.
Ben Ali, M.S., Al-Maadid, A., Bergougui, B., 2025a. How does climate change                          Jin, L., Duan, K., Shi, C., Ju, X., 2017. The impact of technological progress in the energy
    asymmetrically affect economic policy uncertainty in the GCC countries: a                             sector on carbon emissions: an empirical analysis from China. Int. J. Environ. Res.
    multivariate quantile-on-quantile analysis. Sustainable Futures 10, 101063. https://                  Publ. Health 14 (12). https://doi.org/10.3390/ijerph14121505.
    doi.org/10.1016/j.sftr.2025.101063.                                                              Jin, X., Ahmed, Z., Pata, U.K., Kartal, M.T., Erdogan, S., 2024. Do investments in green
Ben Ali, M.S., Al-Maadid, A., Bergougui, B., 2025b. Climate change and energy security                    energy, energy efficiency, and nuclear energy R&D improve the load capacity factor?
    risk: do green patents, institutional quality, and human capital make a difference?                   An augmented ARDL approach. Geosci. Front. 15 (4), 101646. https://doi.org/
    Sustain. Dev. https://doi.org/10.1002/sd.70244. n/a(n/a).                                             10.1016/J.GSF.2023.101646.
Bergougui, B., 2025a. Can artificial intelligence mitigate environmental inequality?                 Jo, A., 2025. Substitution between clean and dirty energy with biased technical change.
    Evidence from leading robotic-driven economies using quantile-based methods.                          International Economic Review 66 (2), 883–902. https://doi.org/10.1111/
    Borsa Istanbul Review. https://doi.org/10.1016/j.bir.2025.07.012.                                     iere.12743.
Bergougui, B., 2025b. Circular pathways to sustainability: asymmetric impacts of the                 Jordaan, S.M., Romo-Rabago, E., McLeary, R., Reidy, L., Nazari, J., Herremans, I.M.,
    circular economy on the EU’s capacity load factor. Land 14 (6), 1216. https://doi.                    2017. The role of energy technology innovation in reducing greenhouse gas
    org/10.3390/land14061216.                                                                             emissions: a case study of Canada. Renew. Sustain. Energy Rev. 78, 1397–1409.
Bergougui, B., 2025c. Industrial robots for a sustainable future: uncovering the                          https://doi.org/10.1016/J.RSER.2017.05.162.
    asymmetric effects of AI on ecological quality in G7 economies. Technol. Soc. 83,                Kihombo, S., Vaseer, A.I., Ahmed, Z., Chen, S., Kirikkaleli, D., Adebayo, T.S., 2022. Is
    103021. https://doi.org/10.1016/j.techsoc.2025.103021.                                                there a tradeoff between financial globalization, economic growth, and
Bergougui, B., 2025d. Institutional adaptability, skill-bias technological shifts, and                    environmental sustainability? An advanced panel analysis. Environ. Sci. Pollut.
    energy efficiency in global decarbonization pathways: exploring the role of artificial                Control Ser. 29 (3), 3983–3993. https://doi.org/10.1007/s11356-021-15878-z.
    intelligence patents. Technol. Soc. 83, 103029. https://doi.org/10.1016/j.                       Koçak, E., Ulucak, Z.Ş., 2019. The effect of energy R&D expenditures on CO2 emission
    techsoc.2025.103029.                                                                                  reduction: estimation of the STIRPAT model for OECD countries. Environ. Sci. Pollut.
Bergougui, B., Meziane, S., 2025. Assessing the impact of green energy transition,                        Control Ser. 26 (14), 14328–14338. https://doi.org/10.1007/s11356-019-04712-2.
    technological innovation, and natural resources on load capacity factor in Algeria:              Liu, Z., Mehmood, U., Nassani, A.A., 2024. How do energy efficiency, technology,
    evidence from dynamic autoregressive distributed lag simulations and machine                          natural resources and globalization impact environmental sustainability? Fresh
    learning validation. Sustainability 17 (5). https://doi.org/10.3390/su17051815.                       evidence from load capacity curve theory. Front. Environ. Sci. 12. https://doi.org/
Bergougui, B., Satrovic, E., 2025. Towards eco-efficiency of OECD countries: how does                     10.3389/fenvs.2024.1447808.
    environmental governance restrain the destructive ecological effect of the excess use            Mosley, L., Eckley, I.A., Gibberd, A., 2022. Sparse temporal disaggregation. J. Roy. Stat.
    of natural resources? Ecol. Inform. 87, 103093. https://doi.org/10.1016/j.                            Soc. Stat. Soc. 185 (4), 2203–2233. https://doi.org/10.1111/rssa.12952.
    ecoinf.2025.103093.                                                                              Mourshed, M., Quddus, M., 2009. Renewable Energy RD&D Expenditure and CO2
Bergougui, B., Boudjana, R.H., Mehibel, S., Zambrano-Monserrate, M.A., 2024a. How do                      Emissions in 15 European Countries, vol. 3. International Journal of Energy Sector
    institutional quality and income asymmetrically affect carbon emissions inequality?                   Management. https://doi.org/10.1108/17506220910970588.
    A quantile-on-quantile assessment for six major global emitters. J. Clean. Prod. 483,            Musah, M., Ahakwa, I., Asongu, S.A., Owusu-Akomeah, M., Ampong, G.O.A., 2024.
    144215. https://doi.org/10.1016/j.jclepro.2024.144215.                                                Unlocking the COP28 climate agenda in G10 economies: do environmental taxes and
Bergougui, B., Mehibel, S., Boudjana, R.H., 2024b. Asymmetric nexus between green                         environmentally-related technologies matter in the natural resource-load capacity
    technologies, economic policy uncertainty, and environmental sustainability:                          factor connection? Sustainable Futures 8 (September). https://doi.org/10.1016/j.
    evidence from Algeria. J. Environ. Manag. 360, 121172. https://doi.org/10.1016/J.                     sftr.2024.100341.
    JENVMAN.2024.121172.                                                                             Özkan, O., Obekpa, H.O., Alola, A.A., 2025. Examining the nexus of energy intensity,
Bergougui, B., Ben-Salha, O., Murshed, S.M., 2025. How income inequality drives                           renewables, natural resources, and carbon intensity in India. Energy Environ. 36 (1),
    climate inequality in the world’s largest emitting nations: novel evidence from                       168–186.
    multivariate quantile-on-quantile and wavelet quantile methods. J. Clean. Prod. 513,             Pata, U.K., Kartal, M.T., 2023. Impact of nuclear and renewable energy sources on
    145666. https://doi.org/10.1016/j.jclepro.2025.145666.                                                environment quality: testing the EKC and LCC hypotheses for South Korea. Nucl.
Bloomberg NEF, 2024. Energy Transition Investment Trends 2024.                                            Eng. Technol. 55 (2), 587–594. https://doi.org/10.1016/J.NET.2022.10.027.
Bolson, N., Prieto, P., Patzek, T., 2022. Capacity factors for electrical power generation           Pata, U.K., Caglar, A.E., Kartal, M.T., Kılıç Depren, S., 2023a. Evaluation of the role of
    from renewable and nonrenewable sources. Proceedings of the National Academy of                       clean energy technologies, human capital, urbanization, and income on the
    Sciences of the United States of America 119, e2205429119. https://doi.org/                           environmental quality in the United States. J. Clean. Prod. 402, 136802. https://doi.
    10.1073/pnas.2205429119.                                                                              org/10.1016/J.JCLEPRO.2023.136802.
Broock, W.A., Scheinkman, J.A., Dechert, W.D., LeBaron, B., 1996. A test for                         Pata, U.K., Kartal, M.T., Erdogan, S., Sarkodie, S.A., 2023b. The role of renewable and
    independence based on the correlation dimension. Econom. Rev. 15 (3), 197–235.                        nuclear energy R&D expenditures and income on environmental quality in Germany:




                                                                                                19
B. Bergougui et al.                                                                                                                  Journal of Environmental Management 395 (2025) 127823

     scrutinizing the EKC and LCC hypotheses with smooth structural changes. Appl.                      Pakistan. Frontiers in Sustainable Energy Policy 3. https://doi.org/10.3389/
     Energy 342, 121138. https://doi.org/10.1016/J.APENERGY.2023.121138.                                fsuep.2024.1438573.
Pata, U.K., Wang, Q., Kartal, M.T., Sharif, A., 2024. The role of disaggregated renewable           Ullah, S., Luo, R., Adebayo, T.S., Kartal, M.T., 2024. Paving the ways toward sustainable
     energy consumption on income and load capacity factor: a novel inclusive                           development: the asymmetric effect of economic complexity, renewable electricity,
     sustainable growth approach. Geosci. Front. 15 (1), 101693. https://doi.org/                       and foreign direct investment on the environmental sustainability in BRICS-T.
     10.1016/J.GSF.2023.101693.                                                                         Environ. Dev. Sustain. 26 (4), 9115–9139. https://doi.org/10.1007/s10668-023-
Purcel, A.-A., 2020. New insights into the environmental Kuznets curve hypothesis in                    03085-4.
     developing and transition economies: a literature survey. Environ. Econ. Pol. Stud.            Ulucak, R., Danish, Khan, S., 2020. Does information and communication technology
     22 (4), 585–631. https://doi.org/10.1007/s10018-020-00272-9.                                       affect CO2 mitigation under the pathway of sustainable development during the
Ragosa, G., Warren, P., 2019. Unpacking the determinants of cross-border private                        mode of globalization? Sustain. Dev. 28, 857–867. https://doi.org/10.1002/
     investment in renewable energy in developing countries. J. Clean. Prod. 235,                       sd.2041.
     854–865. https://doi.org/10.1016/J.JCLEPRO.2019.06.166.                                        Ulucak, R., Danish, Ozcan, B., 2020. Relationship between energy consumption and
Shahbaz, M., Solarin, S.A., Hammoudeh, S., Shahzad, S.J.H., 2017. Bounds testing                        environmental sustainability in OECD countries: the role of natural resources rents.
     approach to analyzing the environment Kuznets curve hypothesis with structural                     Resour. Policy 69, 101803. https://doi.org/10.1016/J.RESOURPOL.2020.101803.
     beaks: the role of biomass energy consumption in the United States. Energy Econ. 68,           Ulucak, Z.Ş., İlkay, S.Ç., Özcan, B., Gedikli, A., 2020. Financial globalization and
     548–565. https://doi.org/10.1016/J.ENECO.2017.10.004.                                              environmental degradation nexus: evidence from emerging economies. Resour.
Shahbaz, M., Nasir, M.A., Roubaud, D., 2018. Environmental degradation in France: the                   Policy 67, 101698. https://doi.org/10.1016/J.RESOURPOL.2020.101698.
     effects of FDI, financial development, and energy innovations. Energy Econ. 74,                Ulug, M., Caglar, A.E., Avci, M.A., Avci, S.B., 2025. Germany’s sustainable future: how
     843–857. https://doi.org/10.1016/J.ENECO.2018.07.020.                                              artificial intelligence and energy innovation shape the carbon neutrality roadmap?
Shahzad, U., Ferraz, D., Nguyen, H.H., Cui, L., 2022. Investigating the spill overs and                 Energy 335, 137949. https://doi.org/10.1016/J.ENERGY.2025.137949.
     connectedness between financial globalization, high-tech industries and                        UN, 2021. THE 17 GOALS.
     environmental footprints: fresh evidence in context of China. Technol. Forecast. Soc.          van Eyden, R., Difeto, M., Gupta, R., Wohar, M.E., 2019. Oil price volatility and
     Change 174, 121205. https://doi.org/10.1016/J.TECHFORE.2021.121205.                                economic growth: evidence from advanced economies using more than a century’s
Shao, X., Zhong, Y., Li, Y., Altuntaş, M., 2021. Does environmental and renewable energy               data. Appl. Energy 233–234, 612–621. https://doi.org/10.1016/J.
     R&D help to achieve carbon neutrality target? A case of the US economy. J. Environ.                APENERGY.2018.10.049.
     Manag. 296, 113229. https://doi.org/10.1016/J.JENVMAN.2021.113229.                             Wen, J., Okolo, C.V., Ugwuoke, I.C., Kolani, K., 2022. Research on influencing factors of
Siche, R., Pereira, L., Agostinho, F., Ortega, E., 2010. Convergence of ecological footprint            renewable energy, energy efficiency, on technological innovation. Does trade,
     and emergy analysis as a sustainability indicator of countries: peru as case study.                investment and human capital development matter? Energy Policy 160, 112718.
     Communications in Nonlinear Science and Numerical Simulation 15 (10),                              https://doi.org/10.1016/J.ENPOL.2021.112718.
     3182–3192. https://doi.org/10.1016/J.CNSNS.2009.10.027.                                        Xu, D., Salem, S., Awosusi, A.A., Abdurakhmanova, G., Altuntaş, M., Oluwajana, D.,
Sim, N., Zhou, H., 2015. Oil prices, US stock return, and the dependence between their                  Kirikkaleli, D., Ojekemi, O., 2022. Load capacity factor and financial globalization in
     quantiles. J. Bank. Finance 55, 1–8. https://doi.org/10.1016/j.                                    Brazil: the role of renewable energy and urbanization. Front. Environ. Sci. 9–2021.
     jbankfin.2015.01.013.                                                                              https://doi.org/10.3389/fenvs.2021.823185.
Sohag, K., Husain, S., Soytas, U., 2024. Environmental policy stringency and ecological             Yavuz, E., Kilic, E., Caglar, A.E., 2024. A new hypothesis for the unemployment-
     footprint linkage: mitigation measures of renewable energy and innovation. Energy                  environment dilemma: is the environmental Phillips curve valid in the framework of
     Econ. 136 (November 2023), 107721. https://doi.org/10.1016/j.                                      load capacity factor in Turkiye? Environ. Dev. Sustain. 26 (11), 29475–29492.
     eneco.2024.107721.                                                                                 https://doi.org/10.1007/s10668-023-04258-x.
Stöckl, F., Zerrahn, A., 2022. Substituting clean for dirty energy: a Bottom-Up analysis.          Yıldırım, D.Ç., Esen, Ö., Urgan, N.N., Çınar, U., Magazzino, C., 2025. Pathways to
     Journal of the Association of Environmental and Resource Economists 10 (3),                        environmental welfare: linking energy transitions, globalisation, natural resource
     819–863. https://doi.org/10.1086/722612.                                                           rents, and load capacity factor in the advanced emerging countries. Environ. Dev.
Ülger, M., Atamer, M., Uçar, M., 2024. Examining the effects of energy consumption on                   Sustain. https://doi.org/10.1007/s10668-025-06719-x.
     the load capacity factor: evidence from the G7 Group of countries. https://doi.org/1           Zambrano-Monserrate, M.A., Subramaniam, Y., Adnan, N., Bergougui, B., Adebayo, T.S.,
     0.2139/ssrn.4978878.                                                                               2024. Dynamic factors driving PM2.5 concentrations: fresh evidence at the global
Ullah, S., Lin, B., 2025. An environmental assessment through load capacity factor: the                 level. Environmental Pollution 362, 124940. https://doi.org/10.1016/j.
     dynamic effects of technological cooperation grants and energy depletion in                        envpol.2024.124940.




                                                                                               20
