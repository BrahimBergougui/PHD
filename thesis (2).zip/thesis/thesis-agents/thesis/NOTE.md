# NOTE.md: project notes and open items

Kept by the orchestrator. Paths are relative to thesis-agents/thesis/ unless stated.

## Status (2026-09-28)

- Step 1 done: data/main_messages.md approved by the candidate.
- Step 2 done: summaries/P01.md to P25.md and P01.bib to P25.bib, all 14 sections present in each.
- Step 3: reference-manager build mode, see "References that need checking" below.

## Inputs

- papers/: holds paper1.md to paper13.md and paper_14.md to paper_25.md (Markdown conversions).
  Paper N is PN, following the candidate's Part Two list. The published PDFs are no longer in papers/.
  ACTION: Part Two (scripts/make_part2.py) needs papers/P01.pdf to P25.pdf. Supply them before the build.
- Summaries P01, P03, P06, P07, P15 to P18, P20, P22 to P25 were extracted from the PDFs;
  the others from the Markdown files.
- The former file "paper 26.pdf" was Bergougui (2027), "Does geopolitical risk shape green hydrogen
  innovation?", Energy Policy 220, 115599. It is not one of the 25 works and is excluded.
- source/: created. Holds the Note de Synthèse (final version, pdf and docx), the seven chapter files
  copied from "thesis/all chapters/", and their plain text in source/txt/.
  Other chapter versions exist in "Frence PHD/Chapters/final/" and "Frence PHD/Chapters/final2026/".
  CONFIRM that "all chapters/" is the current set for Mode B.
- data/outline.md: does not exist. The chapter list in CLAUDE.md is used as the outline.
  "NOTE DE SYNTHÈSE/plan.docx" and "plan2026.docx" may hold an outline; not read.

## Conflicts to resolve

- P24 title. The candidate's Part Two list and CLAUDE.md say "When Does Automation Secure Energy?".
  The manuscript file is titled "Mitigating Energy Vulnerability with Industrial Robotics: When Institutions
  Matter, How Green Innovation Mediates, and Where Spillovers Concentrate", submitted to Energy Sources,
  Part B (Submission ID 269271714). The Note de Synthèse lists it with the Journal of Innovation & Knowledge.
- Theme titles. The Part Two list names Theme 1 "Technological Innovation, Environmental Quality, and
  Sustainability" and Theme 2 "Environmental Inequality and the Distribution of Environmental Burdens".
  CLAUDE.md and the chapter files use "Technological Innovation and Environmental Quality" and
  "Environmental Inequality and Technological Justice". CONFIRM which titles to use, and where.
- Theme 3 numbering in the Note de Synthèse (P21 automation, P22 robots, P23 Ben Ali, P24 high-tech R&D)
  differs from CLAUDE.md and the Part Two list, which are followed. The Note de Synthèse mapping table needs updating.
- Portfolio count: Note de Synthèse says 23 published plus 2 with the editor; CLAUDE.md says 24 plus 1.
- The Note de Synthèse (section 2.2) claims institutional adaptability as a "key theoretical contribution".
  CLAUDE.md forbids this claim. P13 also calls something a "theoretical cornerstone".
- The Note de Synthèse does not state the research questions or hypotheses H1 to H3.

## Note de Synthèse statements that disagree with itself or with the papers (for the fact-checker)

- P01: described as clean-budget increases versus dirty-budget decreases; the paper estimates
  quantile-on-quantile effects (MQQKRLS), not increases versus decreases, and does not use NARDL.
- P05: section 3.3.1 says governance declines hurt more than improvements help; sections 3.4 and 6.1 say the reverse.
  The P05 abstract gives 0.65-0.95 %, Table 7 gives 0.067-0.145.
- P08 and P10: section 3.3.2 says fossil cuts act fast and renewables slowly; section 6.2.2 says the reverse.
  P10 appears under two headings ("Papers 8, 10" and "Papers 9, 10").
- Section 6.1 speaks of "institutional capacity thresholds" for robotics; the papers report robot-density thresholds.

Per-paper internal inconsistencies are listed in the "Extraction notes for the fact-checker" section of each summary.

## NOT REPORTED items (from step 2)

201 items, from the summaries. "(none used)" = not part of the design.

### P01

- Variables: moderators or mediators (none used; "none specified").
- Main results: point coefficients for the main MQQKRLS estimates; results shown only as heatmaps with significance asterisks (Figs. 5-7).
- Main results: threshold values; threshold behavior described only in words, no value estimated.
- Heterogeneity: asymmetry in positive versus negative changes (partial sums); the paper's "asymmetry" means differences across quantiles and countries.

### P02

- Data: the word "annual" for the panel frequency (annual is implied by year fixed effects and 580 obs. = 29 x 20).
- Variables: source of the R&D expenditure data (Table 4 col. 5).
- Variables: source of the non-AI patent counts for the placebo test (Table 5 col. 4).
- Variables: data source of labor structure (LS).
- Variables: source of the distance data for the instrument.
- Methods: panel unit root, cross-sectional dependence, Hausman, Granger or other causality tests, System GMM diagnostics (AR, Hansen/Sargan), marginal effects or turning points for the interaction models ("not used or not reported").
- Main results: short-run coefficients (only FMOLS long run shown).
- Main results: threshold values of LS or INST at which the AI effect changes sign.
- Heterogeneity: asymmetry or quantile methods (none used).
- Causality: Granger or other causality tests (none used).
- Causality: statistic of the under-identification test, which the text says confirms identification.
- Extraction notes: System GMM AR(1)/AR(2) and Hansen/Sargan diagnostics.
- Extraction notes: how the US observation is handled in the IV (the US is in the sample and in the instrument).

### P03

- Variables: source of CO2_PC.
- Variables: source of PEI (primary energy intensity).
- Variables: source of labor composition (LC).
- Variables: sources of Ln(CO2/GDP), Ln(Total CO2), Ln(EF), Ln(GHG) (Table 3).
- Variables: source of the R&D data for R&D-weighted AIP (Table 3 col. 7).
- Variables: source of non-AI patents (Table 4 col. 6).
- Variables: source of the distance data for IV1.
- Methods: unit root, cross-sectional dependence, slope homogeneity and cointegration tests.
- Heterogeneity: quantile methods (none used).
- Robustness: exact placebo mean or share significant in the 500-simulation temporal placebo.

### P04

- Data: number of observations per country.
- Variables: moderators or mediators (none used as estimated variables); energy consumption, income and FDI are called "moderating variables" (p. 8) but no moderation estimates are given; four mechanisms are described but not tested.
- Variables: lag length of the lagged AI instrument.
- Main results: control variable estimates (GDP, FDI, EC).
- Heterogeneity: formal threshold estimates; stage boundaries given only as quantile ranges.
- Robustness: instrument strength or validity statistics for IVMQR.
- Causality: causality test, such as Granger causality in quantiles (none used).
- Extraction notes: transformation or scaling of Table 2 values (AI means 0.646 to 1.058 although measured as "Count"; EQ means 0.011 to 0.156).

### P05

- Data: number of observations.
- Variables: mediators (none used; no mediation analysis).
- Heterogeneity: asymmetry (positive/negative shocks).
- Heterogeneity: threshold values (for example a turning point of PRO).
- Causality: causality test (none used); authors recommend quasi-experimental designs for future work.

### P06

- Data: list of the 50 countries.
- Data: frequency not stated explicitly (N = 1250 in Tables 2, 4, 6).
- Data: panel balance.
- Variables: definition and source of the alternative dependent variable LCF (Table 3 col. 5).
- Variables: exact construction and data source of INDSU/INDUS.
- Variables: source of the distance-to-Japan data.
- Variables: source of trade intensity (trade-to-GDP).
- Variables: source of GVC participation.
- Variables: classification criteria and sources for income level, digital infrastructure and population groups (Table 9).
- Variables: sources of all controls (Table 1).
- Methods: instrument used in IV-GMM.
- Methods: first-stage and instrument validity tests for IV-GMM.
- Methods: unit root, cointegration and cross-sectional dependence tests.
- Heterogeneity: full membership of the "near Japan" group (only South Korea, Taiwan, Singapore named).
- Heterogeneity: asymmetry and quantile methods (none used).
- Robustness: instrument for IV-GMM (INRO 0.038***, N 1200).
- Causality: instrument, first-stage, overidentification or weak-instrument statistics, although the authors claim a causal interpretation.

### P07

- Data: list of the 13 MENA countries (examples named: Algeria, Saudi Arabia, Yemen, Egypt, Tunisia, Türkiye, UAE).
- Variables: moderators or mediators (none used).
- Methods: number of GMM instruments.
- Methods: AR(1) test.
- Methods: one-step or two-step GMM, and use of the Windmeijer correction.
- Methods: unit root, cointegration or cross-sectional dependence tests.
- Heterogeneity: asymmetry analysis.
- Heterogeneity: quantile analysis.
- Heterogeneity: threshold analysis.
- Heterogeneity: country-level or subgroup heterogeneity.
- Robustness: robustness checks (none used); the outline says Section 5 does robustness, but Section 5 is "Discussion" with no robustness estimates; only Hansen J and AR(2) diagnostics.
- Causality: causality tests (none used); endogeneity handled through system GMM.

### P08

- Variables: moderators or mediators.
- Methods: NARDL lag selection criterion, software, and dynamic multipliers.
- Main results: short-run NARDL coefficients (only the short-run asymmetry Wald test is shown).
- Robustness: break dummies in the NARDL model (the LS test finds break dates).
- Causality: reverse direction (CO2 to regressors).

### P09

- Variables: moderators or mediators (none used).
- Methods: NARDL lag lengths and lag selection criterion (HJC is in the acronym list, but its use is not described).
- Methods: number of bootstrap replications in the causality test.
- Heterogeneity: variable-specific and short-run asymmetry tests (only the long-run Wald test, 53.46***, is shown).
- Heterogeneity: dynamic multipliers.
- Heterogeneity: quantile or subsample heterogeneity (none used; not part of the design).
- Robustness: standard errors for Table 9.
- Causality: reverse direction (EF to regressors).

### P10

- Data: number of observations.
- Variables: source for total CO2 (alternative dependent variable).
- Variables: exact patent classification for GT.
- Variables: moderators or mediators (none used).
- Main results: EKC turning point.
- Main results: short-run coefficients (no short-run or error correction table).
- Heterogeneity: quantile or threshold results (none used).
- Heterogeneity: subsample or regime heterogeneity.

### P11

- Data: method used to convert annual data to quarterly.
- Data: number of observations (not in Table 1 or Table 5).
- Variables: source of the alternative dependent variable (log of ecological footprint).
- Variables: source of the material footprint data used for MRE.
- Variables: patent office or counting basis for ENT.
- Variables: definitions and sources of EPU and PS beyond the table note.
- Variables: moderators or mediators (none used).
- Main results: short-run NARDL coefficients and error correction term.
- Heterogeneity: per-variable Wald tests (only one joint Wald statistic).
- Heterogeneity: quantile or threshold results (none used).
- Heterogeneity: subgroup or regional heterogeneity (none used; single country).
- Robustness: CUSUM and CUSUMSQ stability tests, although the text calls the model "well-specified and stable".

### P12

- Data: method used to convert annual series to quarterly.
- Variables: source of the alternative dependent variable EF per capita (Table 9 col. 5), not given separately.
- Main results: short-run coefficients.
- Heterogeneity: whole section (none used); symmetric single-country Fourier ARDL, no asymmetric, quantile or threshold estimates; the only conditional effect is the GT*FD interaction.
- Causality: reverse direction tests (EF to X).

### P13

- Data: method used to obtain quarterly data from annual sources.
- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: lag selection criterion, software, short-run coefficients, and CUSUM or CUSUMSQ stability tests.
- Robustness: alternative estimators (for example quantile ARDL, threshold models), alternative EF measures, or subsample checks.
- Causality: reverse direction (EF to rents).

### P14

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: software.
- Heterogeneity: formal asymmetry test (Wald test of equal positive and negative effects).
- Heterogeneity: country-level heterogeneity estimates (only descriptive country examples in Section 6).

### P15

- Citation: issue number.
- Data: method used to convert annual source data to monthly.
- Methods: MQQR bandwidth value.
- Methods: lag length of the lagged AI instrument in IVQR.
- Main results: control variable coefficients (GDP, POP, FDI, EC).
- Main results: long-run versus short-run split (not applicable).

### P16

- Data: number of observations.
- Variables: sources of the tariff and Economic Freedom instrument data.
- Main results: threshold values of income inequality in levels (given only as quantile positions).
- Main results: coefficients of the controls (INST, GDP, EC, POP).
- Causality: numerical test statistics and p-values (shown only in Fig. 7 against a 5 % critical value line).
- Extraction notes: whether MQQR/WQR use levels or first differences (QADF shows stationarity only after first differencing).

### P17

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Variables: controls (none used; the model has only IQ and income).
- Methods: unit root, cointegration and nonlinearity (e.g. BDS) tests.
- Heterogeneity: numerical threshold values (turning points given only as quantile positions).
- Robustness: alternative IQ or CE-I measures, subsamples, or alternative bandwidths.
- Causality: Japan results not described in the text (only in Table 3).

### P18

- Citation: volume, issue and page numbers (online-first PDF).
- Data: list of the 41 countries.
- Data: split between developed and developing countries.
- Data: the word "annual" (implied by the year range).
- Data: number of observations.
- Variables: moderators or mediators (none used).
- Methods: software (Figs. 1 and 2 look Stata-style, but no software is named).
- Main results: short-run versus long-run split (only the single lag-1 PVAR equation is reported).
- Heterogeneity: developed versus developing subsample results (sample pooled despite the title).
- Heterogeneity: asymmetry (none used; listed as future research).
- Heterogeneity: quantile results.
- Heterogeneity: numerical impulse response values in the text (only plotted).
- Robustness: a separate heterogeneous causality test (for example Dumitrescu-Hurlin) in the body.
- Robustness: alternative estimators, alternative CEI or ENT measures, or subsample re-estimation.

### P19

- Variables: moderators or mediators (none used; no interaction or mediation terms in either model).
- Heterogeneity: subgroup or regional heterogeneity (income groups, regions).
- Robustness: robustness checks (none used); no alternative estimator, index, subsample or sensitivity analysis.
- Causality: causality test (none used); Section 3.2 claims "bidirectional causal links" between ETI and REI, resting only on the two MM-QR models.

### P20

- Data: number of observations.
- Variables: moderators or mediators (none used).
- Heterogeneity: formal Wald test of asymmetry.
- Heterogeneity: subsample heterogeneity (regional, city size, resource type).
- Robustness: robustness checks (none used); the Dumitrescu-Hurlin test is a final phase, not a robustness check.
- Limitations: no explicit limitations section; only future directions are stated.
- Extraction notes: number of observations, software, bootstrap or standard error method, and chosen DH lag length.

### P21

- Data: full-sample N (subsample regressions in Table 9 report N = 1224 per column).
- Variables: units of GDP, TNRR, TO, RE, INDS, POP, GP, HC.
- Causality: Granger or other formal causality test (none used).
- Limitations: no limitations section and no future research agenda.
- Extraction notes: transformation used for IQ (Eq. 3 uses ln IQ, but IQ has negative values, min -0.466).

### P22

- Data: the word "annual" (implied by 560 obs. = 20 x 28).
- Variables: moderators or mediators (none used; no interaction or mediation terms).
- Heterogeneity: asymmetric (positive versus negative shock) decomposition and country-group split (none used; quantile heterogeneity is the core design).
- Robustness: control variable coefficients in the robustness models (only "Controls Yes").
- Causality: RDD (storage) causality (not in Table 8).

### P23

- Data: number of observations per country.
- Data: whether any frequency conversion or interpolation was applied.
- Data: descriptive statistics for GDP and EC.
- Variables: exact WDI indicator codes and units for GDP and EC.
- Methods: m-QQR bandwidth h value.
- Robustness: first-stage strength or instrument validity tests for IVMQR.
- Causality: Granger or other causality test (none used); the IVMQR check is presented as strengthening "the causal interpretation".

### P24

- Variables: source databases for the ENV sub-indicators (only "multiple integrated databases").
- Variables: exact formula and source of the mediator IST.
- Variables: definitions, units and data sources of the controls.
- Variables: definitions and cut-offs for the income, digital and population splits.
- Variables: distance cut-off and group membership for the proximity-to-Japan split (only examples named).
- Methods: pre-estimation tests (unit root, cross-sectional dependence, cointegration, Hausman).
- Heterogeneity: coefficients, standard errors and N for the income, digital and population subsamples (only one number printed: Low-Population -3.163).
- Heterogeneity: quantile results (none used).
- Robustness: diagnostic tests (Hansen/Sargan, underidentification, cross-sectional dependence).
- Causality: formal causality test (none used); the author says the IV-GMM pattern supports a "causal interpretation".

### P25

- Data: method used to convert annual data to quarterly.
- Data: software.
- Variables: moderators or mediators (none used).
- Variables: measurement unit and source of EC (absent from Table 1).
- Variables: measurement and source of the robustness-only variables POP and URB.
- Methods: number of Fourier frequencies selected.
- Methods: selected lag orders.
- Methods: formal Wald test of long-run or short-run symmetry.
- Main results: short-run asymmetric coefficients, although the conclusion refers to "asymmetric short-term dynamics".
- Heterogeneity: quantile or subsample heterogeneity (none used; single-country, mean-based model).
- Heterogeneity: threshold results.
- Causality: causality test (none used).

## References that need checking (from step 3)

bib/references.bib: 84 entries (25 portfolio, 59 external). Details in reports/references_todo.md.
Key changes from the rule "surname + year + first significant word", to avoid collisions:
P02 bergougui2025artificialadvance, P15 bergougui2025artificialmitigate, P09 bergougui2024asymmetricimpact,
P10 bergougui2024asymmetricnexus, P20 bergougui2025secure, P24 bergougui2026automation.
P13 author corrected to "Bergougui, Brahim" (printed reversed in the paper).

Entries marked NEEDS VERIFICATION (11):
- P02: the paper prints 2025, pp. 1-23 (early view); the Note de Synthèse gives 34(S2), 222-244; Chapters 2 and 5 give 2026.
- P21: early view in the file; CLAUDE.md says Sustainable Development 34(1). Final volume and pages to confirm.
- P24: title "When Does Automation Secure Energy?" differs from the manuscript file title; no year printed, so the
  citation renders with an empty year. Venue: Note de Synthèse says Journal of Innovation & Knowledge, the manuscript
  says Energy Sources, Part B.
- P06, P14, P18, P25: early-view or online-first versions, no final volume or pages. Update when issued.
- ipcc2023climate: dated 2023 but the title reads "Climate Change 2021 - The Physical Science Basis".
- ipcc2023synthesis: in no source reference list; only cited in the placeholder text of ch00.
- chancel2015carbon: report number or URL missing.
- mcwilliams2022preparing: "Bruegel Blog, 28." is unclear.

Other disagreements between sources:
- P07: the Note de Synthèse says 2025; the paper prints 2026, Natural Resources Forum 50, 1299-1319.
- P23: the Note de Synthèse lists it "With Editor" at Energy & Environment; it is published in Energy Nexus 23 (2026) 100760.
