                                                                          Resources Policy 113 (2026) 105830


                                                                      Contents lists available at ScienceDirect


                                                                             Resources Policy
                                                          journal homepage: www.elsevier.com/locate/resourpol




Aggregate and disaggregate natural resources impacts on environmental
sustainability: An Asymmetric NARDL analysis
Said Meziane a, Bergougui Brahim b,c,d,*
a
  Mohamed Cherif Messaadia University - Souk Ahras, Algeria
b
  College of Business & Economics, Qatar University, Doha, Qatar
c
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
d
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria




A R T I C L E I N F O                                        A B S T R A C T

Keywords:                                                    While many studies have explored the relationship between aggregate natural resource rents and environmental
Ecological footprint                                         sustainability, understanding the broader impact of TNRR on the ecological footprint remains critical. However,
Environmental sustainability                                 focusing solely on the aggregate measure may obscure the distinct effects of different types of natural resources
Natural resources rents
                                                             on environmental outcomes. This study bridges that gap by analyzing not only the aggregate effect of TNRR on
NARDL
Algeria
                                                             EF but also the disaggregated impacts of different types of natural resource rents —oil, gas, minerals, coal, and
                                                             forests—on EF in Algeria between 1970/Q1 and 2022/Q4, Applying nonlinear autoregressive distributed lag
                                                             (NARDL) models. Our results reveal a non-symmetric impact of aggregate TNRR in Algeria's ecological footprint,
                                                             with positive shocks significantly increasing EF and negative shocks decreasing it. The disaggregated analysis
                                                             uncovers nuanced sector-specific dynamics: oil rents mirror the asymmetric pattern of aggregate TNRR, while gas
                                                             and mineral rents increase EF regardless of shock direction. Coal rents show no significant impact, and forest
                                                             rents demonstrate a sharp increase in EF with positive shocks and a reduction with negative shocks. These results
                                                             underscore the need for a differentiated approach to resource management in Algeria, emphasizing economic
                                                             diversification, promotion of cleaner energy alternatives, and sustainable forest management practices.




1. Introduction                                                                                    the "paradox of plenty" (Van Der Ploeg, 2011; Li et al., 2025). Alongside
                                                                                                   the economic implications of natural resource, global economic prog­
    Natural resources are materials that occur naturally in the environ­                           ress, particularly in the industrial sector, has placed significant pressure
ment through natural processes, holding significant value for human                                on the environment due to the high demand for natural resources. This
use. Although The abundance of natural resources is widely recognized                              pressure has resulted in resource depletion and ecosystem degradation
as more than merely a primary driver of economic growth; it plays a                                (Cai et al., 2023). In response to the escalating climate change crisis,
critical role in shaping a range of socio-economic indicators (Badeeb                              academic research has increasingly focused on environmental sustain­
et al., 2020; Bergougui and Murshed, 2021, 2023). It has been observed                             ability, with particular emphasis on the rising levels of greenhouse gases
that countries blessed with natural resource wealth often face worse                               such as CO2 emissions, which pose a threat to future growth and global
economic performance than countries without such resources (Ding and                               environmental health (Ahmed et al., 2020b; Bergougui and Murshed,
Field, 2005; Bergougui and Murshed, 2020; Bergougui and Satrovic,                                  2025).
2025). However, there are exceptions to this trend, such as Indonesia,                                 The ecological footprint (EF) serves as a crucial metric for assessing
which is dependent on oil, and Botswana, which is rich in diamonds                                 the sustainability of human activities and the impact of economic
which have performed relatively better than others (Harvey, 2015;                                  growth on the environment. The EF quantifies the total area of ecosys­
Rahman et al., 2023). In many cases, however, the abundance of re­                                 tems required to support the production of goods and services consumed
sources can be a factor in economic failure, with many oil-exporting                               by a society, while also absorbing the waste generated by that society
countries and other resource-rich countries failing to achieve develop­                            (Ragmoun, 2023; Bergougui, 2025a). Expressed in global hectares per
ment this phenomenon is commonly known as the "resource curse" or                                  capita (GHG), the EF provides a standardized method for comparing the


    * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands.
      E-mail addresses: said.meziane@univ-soukahras.dz (S. Meziane), brahim.bergougui@qu.edu.qa, bergougui@iss.nl (B. Brahim).

https://doi.org/10.1016/j.resourpol.2026.105830
Received 23 January 2025; Received in revised form 27 September 2025; Accepted 3 January 2026
Available online 5 January 2026
0301-4207/© 2026 The Authors. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
S. Meziane and B. Brahim                                                                                                       Resources Policy 113 (2026) 105830


environmental impacts of different nations or communities (Global                    revealing sector-specific impacts on EF that aggregate-level studies
Footprint Network, 2024). A rising EF is typically associated with rapid             have overlooked. For instance, hydrocarbons and minerals emerge as
urbanization and industrial growth, both of which increase the demand                primary drivers of ecological degradation due to extraction-intensive
for resources and lead to environmental degradation (Usman et al.,                   processes, while forest rents exhibit a dual nature: exacerbating EF
2023). The increasing demand for resources, including agriculture,                   through deforestation but potentially alleviating it via conservation
livestock, fisheries, forests, and infrastructure, to meet national needs            efforts. Including coal rents, though marginal in scale, highlights
contributes to a larger ecological footprint and accelerates environ­                transitional energy dynamics, such as shifts toward cleaner alterna­
mental damage (Danish and Wang, 2019b). A significant body of                        tives. This approach fills a gap in Algerian scholarship, where pre­
research has focused on the key drivers of the ecological footprint,                 vious research, like Chekouri et al. (2023), focused on aggregated
prompting studies on specific economies or groups of countries. For                  NRR without disaggregation, thus masking these nuanced
instance, studies by (Ahmed et al., 2020a; Xu et al., 2022a; Gu et al.,              contributions.
2024; Khan et al., 2024) have explored the ecological footprint in China,          • Secondly, by employing NARDL, the study departs from linear
while other studies have focused on countries such as Malaysia (Ahmed                models to explore asymmetric responses to positive and negative
et al., 2020a), Thailand (Shu et al., 2023), and Pakistan (Hassan et al.,            shocks in each rent type. This uncovers a "resource asymmetry trap"
2019). These studies provide important insights into how different fac­              mechanism—where positive shocks (e.g., rent increases from forest
tors, including natural resource extraction and industrial activities, in­           exploitation) intensify short-run EF degradation via unsustainable
fluence national environmental outcomes. Furthermore, as part of                     practices like logging, whereas negative shocks facilitate ecological
addressing the complex relationships between natural resource rents                  recovery by easing biodiversity pressures. Such patterns, absent in
and environmental sustainability, forest rents are now recognized as                 symmetric analyses like Chekouri et al. (2023), yield targeted policy
potential contributors to environmental sustainability, provided they                implications for Algeria, including phased rent reductions to avert
are managed through sustainable practices such as reforestation, affor­              environmental lock-ins.
estation, and eco-tourism. These practices ensure that forest rents are            • Thirdly, the research bridges asymmetric econometrics with insti­
seen as indicators of environmental stewardship and resource manage­                 tutional economics, proposing an "institutional rent asymmetry"
ment, promoting ecological balance when exploited within the limits of               framework. This theorizes how colonial legacies—such as France's
the environment's carrying capacity (Cai et al., 2023; Ragmoun, 2023).               historical emphasis on diversified rents (minerals and forests)—
In contrast, coal rents are consistently identified as environmental                 moderate NRR–EF relationships in Algeria, differing markedly from
stressors, primarily due to the significant carbon emissions and air                 rentier states like Saudi Arabia. In contrast to Ben-Salha and Zmami
pollution associated with coal extraction and consumption, particularly              (2023), who applied disaggregation in Saudi Arabia's oil-dominant,
within Algeria's energy mix. As such, coal rents are viewed as a source of           monarchical context, our inclusion of forest and coal rents materi­
environmental degradation, underscoring the urgent need for tran­                    ally alters insights: forests amplify EF through colonial-era land
sitioning towards cleaner energy alternatives (Ahmed et al., 2020b).                 policies linked to deforestation, while coal exhibits long-run miti­
    Algeria's institutional and regulatory frameworks are pivotal in                 gating effects amid energy transitions. This challenges the univer­
shaping the dynamics between total natural resource rents (TNRR) and                 sality of Gulf-centric models and extends the resource curse
the ecological footprint (EF). Historically, the country has relied heavily          hypothesis to encompass ecological asymmetries, emphasizing gov­
on hydrocarbons, with oil and gas constituting approximately 95 % of its             ernance's role in shaping outcomes.
exports and over 50 % of tax revenues as of 2024. To address the                   • Fourthly, the study targets Algeria during its ongoing policy meta­
environmental repercussions of this dependence, Algeria introduced its               morphosis, positioning it as a vital case in the developing world. As
National Climate Plan (NCP) in 2020, aiming for 27 % of electricity from             Africa's third-largest polluter and a hyper-resource-dependent
renewable sources by 2030, with a complementary target of installing                 economy (with hydrocarbons dominating exports), Algeria offers
15 GW of renewable capacity, predominantly solar PV. This policy pivot               an underexplored "natural laboratory" for asymmetric resource­
emphasizes diversification toward solar and wind energy, marking a                   –environment interactions, especially amid NCP implementation.
critical step in curbing emissions and fostering sustainable development.            Unlike well-studied cases like China or Turkey, Algeria's blend of
Sonatrach, the state-owned hydrocarbon giant and Africa's largest oil                extreme dependence, resource diversity, and reform initiatives pro­
producer, occupies a central dual role in this transition: fueling eco­              vides transferable lessons for African and Middle Eastern peers
nomic growth while advancing environmental stewardship. Under                        grappling with extraction-sustainability tensions.
mounting global pressure, Sonatrach is modernizing operations through
enhanced energy efficiency, adoption of carbon capture and storage                    Overall, this work transcends conventional aggregate treatments of
(CCS) technologies, and exploration of green hydrogen initiatives.                TNRR as a monolithic EF driver, as critiqued in Ben-Salha and Zmami
Nevertheless, Algeria's entrenched fossil fuel reliance poses formidable          (2023) and Chekouri et al. (2023), which often sidelined
obstacles to achieving these climate objectives. Robust institutional re­         non-hydrocarbon rents and asymmetries. By disaggregating and
forms are imperative to harmonize economic imperatives with ecolog­               revealing context-specific vulnerabilities—like "hidden rent vulnerabil­
ical safeguards, particularly given the nation's vulnerability to resource        ities" in forests and coal—the study advocates for differentiated gover­
volatility. Sonatrach's evolving mandate is crucial, as it must align with        nance: prioritizing high-impact sectors while leveraging diffuse
renewable targets while integrating innovative technologies. These re­            resources for sustainability (e.g., afforestation or eco-tourism). This
forms demand fortified governance, substantial green investments, and             conceptual innovation elevates the research from empirical extension to
a steadfast dedication to decarbonization for enduring sustainability.            a theoretical cornerstone, fostering cross-country comparisons and
    This study advances the EF–NRR literature through several concep­             policy refinement in resource-rich nations.
tual and methodological innovations, particularly in the Algerian                     The empirical results reveal that positive shocks in TNRR signifi­
context, by uncovering novel mechanisms, patterns, and theoretical                cantly increase the EF, while negative TNRR shocks reduce it. A similar
insights that extend beyond prior empirical works:                                pattern is observed with oil rents, where positive shocks lead to a rise in
                                                                                  EF, and negative shocks result in a significant decrease. In contrast, both
 • Firstly, it introduces a disaggregated analysis of five TNRR compo­            positive and negative shocks in gas and mineral resources consistently
   nents—oil, gas, mineral, coal, and forest rents—within a Nonlinear             lead to higher EF. Interestingly, coal rents, regardless of the direction of
   Autoregressive Distributed Lag (NARDL) framework, a first for                  the shock, show no significant impact on EF. However, forest resource
   Algeria. This granular decomposition distinguishes between point               shocks display strong asymmetry—positive shocks substantially in­
   resources (oil, gas, minerals, coal) and diffuse resources (forests),          crease EF, while negative shocks reduce it. Granger causality analysis

                                                                              2
S. Meziane and B. Brahim                                                                                                       Resources Policy 113 (2026) 105830


further confirms that TNRR, oil rents, and mineral rents drive long-term          one-way causal relationship between TNRR and EF. In the case of
changes in EF in Algeria. While these findings align with parts of existing       Algeria, Shehzad et al. (2022) investigated the effects of TNRR on EF.
literature, particularly in relation to negative shocks, they underscore          Their empirical analysis indicated a significant causal relationship be­
the asymmetric effects of shocks on EF. This insight can aid Algeria in           tween TNRR and short-term environmental degradation. However, they
crafting more effective environmental policies that reflect these nuanced         also found that revenues derived from natural resources can enhance
dynamics.                                                                         environmental quality over the long term. Similarly for Algeria Chekouri
                                                                                  et al. (2023), investigated the influences of TNRR on the EF from 1970 to
2. Literature review                                                              2018. Their empirical research found that the impact of TNRR on the EF
                                                                                  is positive and significant at the central and higher quantiles but di­
    A growing body of literature has explored the environmental effects           minishes at the inferior quantile.
of TNRR, using diverse methodological and econometric approaches.                     Recent scholarly advancements have substantially deepened our
This body of research can be broadly classified within two primary                understanding of the intricate relationship between TNRR and envi­
strands. The first strand involves aggregated analyses that examine the           ronmental sustainability. As the body of literature continues to evolve,
net effect of natural resources treated as a composite variable on sus­           several significant contributions have enriched our comprehension of
tainability outcomes. In contrast, the second strand concentrates on              how various economic, environmental, and policy factors interact to
detailed disaggregated analyses, investigating the distinct impacts of            shape ecological outcomes, especially in resource-dependent economies.
various natural resources categories on the ecosystem sustainability,             A key contribution to this discourse is the exploration of the Pollution
nexus. By categorizing the literature into these two groups—aggregated            Haven Hypothesis (PHH), which suggests that countries with weaker
versus disaggregated analytical approaches—we gain a systematic un­               environmental regulations may attract polluting industries, thereby
derstanding of how modeling choices affect the measured relationship              transforming these regions into "havens" for pollution. This hypothesis
between TNRR and EF. The aggregated approach treats natural capital               has been widely tested in developing nations, such as Turkey, which is
as a homogeneous factor, while the disaggregated approach allows for              characterized by substantial industrial activity and natural resource
heterogeneity across different resource types, such as oil and minerals,          extraction (Terzi and Pata, 2020). Empirical studies examining the PHH
in their individual influence on Environmental sustainability.                    have demonstrated that lax environmental regulations in certain coun­
    The relevant literature exhibits ambiguity and can be broadly                 tries may lead to the relocation of polluting industries to these regions,
divided into two primary categories regarding the indicators of envi­             exacerbating environmental degradation (Javorcik and Wei, 2005). The
ronmental quality. The first group considers CO2 emissions as a proxy             relevance of PHH to developing economies, particularly Algeria, un­
for environmental quality, as highlighted in the works of Cai et al.              derscores the crucial need for strong environmental governance and
(2023). The second category employs different metrics, notably the                policy alignment to mitigate the detrimental effects of resource extrac­
ecological footprint, to analyze the interplay between the use of natural         tion. Another notable contribution to the literature is the integrated
resources and the overall quality of the environment. This literature             analysis of energy security risks and green innovation (Pata and Karlilar,
review will primarily focus on the latter one. Within the context of the          2024). investigate the interrelationship between energy secur­
ecological footprint, two contrasting perspectives regarding the impact           ity—defined as the reliable and affordable availability of energy sour­
of TNRR have emerged. The first perspective suggests an inversed link             ces—and green innovation, analyzing how these factors collectively
between TNRR and the EF, indicating that the effective use of natural             influence the environmental outcomes of resource-extracting nations.
resources can contribute to improved environmental sustainability. For            This relationship is particularly significant for countries such as Algeria,
instance, Zafar et al. (2019) investigated the United States from 1970 to         which are heavily dependent on fossil fuel exports. Understanding how
2015 and found a significant negative associations between TNRR and               energy security and green innovation intersect is pivotal for fostering
the long-term EF. These findings suggest that an abundance of TNRR can            sustainable development in these economies. Incorporating green
help achieve a balance in ecosystems. Similarly Kongbuamai et al.                 innovation into energy policies offers a promising strategy for reducing
(2020), examined the association between TNRR and EF across several               material footprints and addressing the environmental challenges asso­
Southeast Asian nations during the period from 1995 to 2016. The                  ciated with fossil fuel dependency (Pata and Karlilar, 2024). Addition­
research revealed a long-term inverse relationship, implying that an              ally (Pata et al., 2023), build upon this integrated framework by
increased utilization of natural resources is associated with improved            evaluating the role of renewable energy in promoting sustainable
environmental quality.                                                            development, emphasizing the importance of renewable energy adop­
    Conversely, other studies have found a positive association among             tion to mitigate the environmental impacts of fossil fuel reliance.
TNRR and ecological footprint, indicating environmental deterioration.            Collectively, these studies underscore the need to diversify energy
Such as Emir and Karlilar (2023), assessed the effects of TNRR avail­             sources and integrate green innovation into energy strategies to promote
ability on EF in Turkey from 1970 to 2017. Their research discovered a            long-term sustainability.
positive and substantial impact of TNRR on long-term EF, Additionally,                The role of renewable energy in advancing sustainable development
their causal analysis verified that there is a short-term causal relation­        has emerged as a central focus in recent studies. Research by Danish and
ship among environmental deterioration and TNRR (Ben-Salha and                    Khan (2025) and Shu et al. (2023) highlights the importance of
Zmami, 2023) sought to confirm that the exploitation of natural re­               increasing the share of renewable energy sources—such as solar, wind,
sources in Saudi Arabia between 1981 and 2018 had both symmetric                  and hydropower—in driving sustainable development. These studies
and asymmetric influences on EF. Through the application of the dy­               suggest that countries diversifying their energy mix to include a higher
namic ARDL model, the research investigated both the short-term and               proportion of renewables can significantly reduce their ecological
long-term environmental consequences resulting from shocks to natural             footprint and enhance energy independence. These findings are espe­
resources. Their findings indicated a positive symmetrical relationship           cially relevant for resource-dependent nations like Algeria, where in­
among TNRR and long-term ecological footprints, while the asymmetric              vestments in renewable energy can reduce reliance on fossil fuels and,
analysis indicated that increases in TNRR tend to worsen the ecological           consequently, lower the national ecological footprint (Danish et al.,
footprint. Finally Gu et al. (2024), explored the effects of innovation,          2019; Shu et al., 2023). Further comparative research, such as that by Xu
economic growth, human capital, and natural resources on ecological               et al. (2022b), assesses the impact of various renewable energy sour­
footprints in the BRICS countries from 1992 to 2020. By employing a               ces—solar, wind, biofuels, and hydropower—on sustainable develop­
serval of econometric techniques, such as quantile regression with the            ment. Their findings emphasize the critical importance of a diversified
method of moments, least squares, dynamic ordinary least squares, and             energy portfolio, which not only improves environmental performance
fixed effects ordinary least squares, the empirical analysis established a        but also ensures the long-term sustainability of energy systems (Xu et al.,

                                                                              3
S. Meziane and B. Brahim                                                                                                       Resources Policy 113 (2026) 105830


2022b). For countries like Algeria, adopting a diversified energy port­         reduce environmental impacts while promoting economic growth.
folio could provide solutions to both energy security and environmental         These studies offer valuable frameworks for policymakers to shape the
sustainability challenges. In addition Karlilar Pata and Pata (2025),           future of resource economies by integrating sustainability goals with
conduct a comparative analysis of the impacts of solar, wind, biofuels,         technological and human capital development.
and hydropower on the load capacity factor and sustainable develop­
ment index, further reinforcing the need for integrating diverse renew­         3. Method and data
able energy sources to achieve sustainability objectives.
    Building on this technological dimension, a growing body of research        3.1. Data
highlights the transformative role of artificial intelligence (AI) in
advancing sustainability and environmental protection. Empirical evi­               This study investigates the influence of TNRR and their five com­
dence demonstrates that AI stimulates green innovation through direct,          ponents—on Algeria's EF over the period Q1 1970–Q4 2022, with EC
indirect, and spillover effects while exhibiting heterogeneous impacts          and GDP included as control variables. The EF, serving as a compre­
across economic contexts (Wang et al., 2023). In the context of urban­          hensive indicator of ecological degradation (Bergougui and Meziane,
ization, AI has been shown to enhance sustainable development by                2025; Bergougui, 2025b), is obtained from Lo et al. (2025). The dataset
reinforcing R&D innovation, strengthening infrastructure, and sup­              for TNRR, disaggregated resource rents (Doğan et al., 2025), gross do­
porting market expansion (Wang et al., 2025c). At the economic level,           mestic product, and energy consumption are obtained from World Bank
AI also contributes to improving green economy efficiency, particularly         (WDI, 2025). The details of the variables and their respective data
when combined with complementary factors such as green finance,                 sources are provided in Table 1.
trade openness, and investment in research and development (Wang
et al., 2025b) Within the energy sector, AI applications—including de­          3.2. Methodology
mand forecasting, smart grid optimization, and demand-side manage­
ment—are increasingly recognized as essential tools for accelerating                The methodological framework of this study (see Fig. 1) is structured
renewable energy integration and ensuring system stability (Wang et al.,        to capture both the asymmetric and long-run effects of TNRR and their
2025a). Cross-country evidence further suggests that higher levels of AI        components on EF in Algeria.
adoption significantly lower ecological footprints and carbon emissions
while simultaneously reinforcing energy transition pathways, especially         3.3. Model specification and NARDL farmwork
in more trade-open and industrialized economies (Wang et al., 2024).
    The relationship between foreign direct investment (FDI), fossil fuel           In this section, we employed an NARDL model developed by (Shin
consumption, and globalization represents another critical area of in­          et al., 2014) to evaluate the nonlinear and asymmetric relationship
quiry. Research, including a case study from Mexico, indicates that             among the key variables under examination. This flexible modeling
economic growth, fossil fuel consumption, and urbanization have                 approach is well-suited for contexts involving unanticipated or unob­
negative implications for environmental quality, while renewable en­            served perturbation events, such as abrupt political shifts, financial
ergy adoption and financial globalization produce positive effects              crises, pandemic disease outbreaks, and other major societal disrup­
(Eweade et al., 2024). This dual challenge is particularly pertinent for        tions. Linear modeling strategies can prove insufficient in such situa­
countries like Algeria, where managing foreign investments alongside            tions due to inability to adequately account for periods of instability or
balancing environmental concerns is crucial. Understanding the con­             volatility. The asymmetric modeling techniques used here allow for
nections between FDI and ecological impacts can help inform policies            assessment of both immediate and gradual cointegrating associations
that attract sustainable investments while minimizing the environ­              among predictor and outcome variables. Additionally, these models al­
mental costs associated with globalization. Finally, the Environmental          lows the variables both I(0), I(1), rather than imposing assumptions of
Kuznets Curve (EKC) hypothesis, which posits that economic growth               equivalent integration across all-time series under analysis. The current
initially leads to environmental degradation but ultimately results in          analysis specifically investigates the long-run asymmetric impact of
environmental improvements as economies mature, has been explored               aggregate and disaggregate TNRR on EF while adjusting for GDP and EC
in several recent studies. These studies suggest that the relationship          in Algeria. To enhance model parsimony, the analytic framework fo­
between economic growth and environmental quality is dynamic and                cuses solely on interrelations among these core variables of interest
evolves with structural changes and policy interventions (Pata and
Yurtkuran, 2022). This insight holds particular relevance for both highly       EFt = α0 + α1 (TNRR)t + α2 (GDP)t + α3 (EC)t + μt                             (1)
industrialized and emerging economies, such as Algeria, where the EKC
hypothesis may offer valuable perspectives on the relationship between          EFt = α0 + α1 (OIL)t + α2 (GDP)t + α3 (EC)t + μt                              (2)
economic growth and environmental outcomes. Furthermore (Pata,
2025), investigates the influence of renewable energy, human capital,
and information and communication technologies (ICT) on the                     Table 1
achievement of the Sustainable Development Goals (SDGs) in the BRICS            Variable Details and data sources.
countries over the period from 2000 to 2023. The findings indicate that
                                                                                 Symbols    Variable                  Units               Source
human capital development, hydropower, and ICT make significant
contributions to the progress of the SDGs, whereas solar and wind en­            EF         Ecological footprint      Global hectare      Lo et al. (2025)
                                                                                 TNRR       Total Natural resources   % of GDP            WDI (2025)
ergy exhibit no substantial effect. The study suggests enhancing in­
                                                                                            rents
vestments in human capital, ICT, and the efficiency of solar and wind            OR         Oil rents                 % of GDP            WDI (2025)
technologies to improve SDG outcomes.                                            GR         Natural gas rents         % of GDP            WDI (2025)
    The importance of leveraging renewable energy, technological in­             CR         Coal rents                % of GDP            WDI (2025)
novations, and human capital for sustainable development is also                 MR         Mineral rents             % of GDP            WDI (2025)
                                                                                 FR         Forest rents              % of GDP            WDI (2025)
emphasized in recent literature. Research advocates for green techno­            GDP        real per capita GDP       Constant 2015       WDI (2025)
logical innovations, coupled with investments in human capital, such as                                               US$
education and training for a green workforce, to foster transitions to­          EC         Primary energy            Per person          Our World in Data
ward greener economies. This is particularly significant for emerging                       consumption                                   (2025)
markets like Algeria, where there is substantial potential to harness           Note: US$ represents United States Dollar, WDI signifies the World Development
renewable energy sources and adopt technological innovations that               Indicators.

                                                                            4
S. Meziane and B. Brahim                                                                                                      Resources Policy 113 (2026) 105830




                                                               Fig. 1. Analysis flowcharts.


EFt = α0 + α1 (GAS)t + α2 (GDP)t + α3 (EC)t + μt                      (3)        EFt = f(FOREST+ , FOREST − , GDP, EC)                                    (12)

EFt = α0 + α1 (MINERAL)t + α2 (GDP)t + α3 (EC)t + μt                  (4)           Based on Bergougui (2024), we use the following empirical model to
                                                                                 account for the asymmetrical relationship between the chosen variables:
EFt = α0 + α1 (COAL)t + α2 (GDP)t + α3 (EC)t + μt                     (5)
                                                                                 EFt = β0 + β1 TNRR+
                                                                                                   t + β2 TNRRt + β3 GDPt + β4 ECt + μt + εt
                                                                                                              −
                                                                                                                                                          (13)
EFt = α0 + α1 (FOREST)t + α2 GDP + α3 (EC)t + μt                      (6)
                                                                                 EFt = β0 + β1 OIL+
                                                                                                  t + β2 OILt + β3 GDPt + β4 ECt + μt + εt
                                                                                                            −
                                                                                                                                                          (14)
where EFt, TNRRt, OILt, GASt, MINERALt, COALt, FORESTt represent
the Ecological footprint, natural resources rents, oil rents, natural gas        EFt = β0 + β1 GAS+
                                                                                                  t + β2 GASt + β3 GDPt + β4 ECt + μt + εt
                                                                                                            −
                                                                                                                                                          (15)
rents, mineral rents, coal rents and forest rents respectively in Algeria.
We employ the NARDL approach, Shin et al., (2014) to estimate an                 EFt = β0 + β1 MINERAL+
                                                                                                      t + β2 MINERAL + β3 GDPt + β4 ECt + μt + εt

asymmetry relationship in the dynamic modification of variables. This is                                                                                  (16)
achieved with taking into account a variation between explanatory and
illustrative variables. The reasoning behind utilizing the nonlinear ARDL        EFt = β0 + β1 COAL+
                                                                                                   t + β2 COALt + β3 GDPt + β4 ECt + μt + εt
                                                                                                              −
                                                                                                                                                          (17)
model is stranded to understand that variables need not exhibit hidden
cointegration, and the effects of explanatory variables varies depending         EFt = β0 + β1 FOREST+
                                                                                                     t + β2 FOREST t + β3 GDPt + β4 ECt + μt + εt
                                                                                                                   −
                                                                                                                                                          (18)
on positive and negative changes in both the long run and short run. The
                                                                                 Where the parameter βi represents the long-run coefficient and asym­
NARDL methodology provides a flexible and straightforward approach
                                                                                 metric influence of the TNRR, OIL, GAS, MINERAL, COAL, and FOREST.
to accommodate these considerations, and it can be used regardless of
                                                                                 Positive variations in these variables are represented as (TNRR+ , OIL+ ;
the order of integration of the time series data. (Hatemi-J 2020) put the
                                                                                 GAS+ , MINERAL+ , COAL+ , FOREST+ ), while negative changes are rep­
notion of hidden cointegration, that discovers a possible unobserved
                                                                                 resented as (TNRR− , OIL− ; GAS− , MINERAL− , COAL− , FOREST − ).
cointegrating interactions between the integrated elements of data set,
illustrated by the following regression:
                                                                                 4. Empirical results
EFt = f(TNRR+ , TNRR− , GDP, EC)                                      (7)
                                                                                 4.1. Preliminary test
EFt = f(OIL+ , OIL− , GDP, EC)                                        (8)
                                                                                 4.1.1. Statistics descriptive
EFt = f(GAS+ , GAS− , GDP, EC)                                        (9)           Table 2 presents descriptive statistics for the dataset. The means of
                                                                                 EF, TNRR, OR, GR, MR, CR, FR, Gross Domestic Product (GDP), and
EFt = f(MINERAL+ , MINERAL− , GDP, EC)                               (10)        Ecological consumption (EC) are higher than their respective standard
                                                                                 deviations, suggesting that these variables are not evenly distributed in
EFt = f(COAL+ , COAL− , GDP, EC)                                     (11)

                                                                             5
S. Meziane and B. Brahim                                                                                                       Resources Policy 113 (2026) 105830


Table 2
Summary statistics.
                      EF            TNRR           Oil             Gas             Mineral         Coal              Forest         GDP              EC

  Mean                  4.3947       5.1704         4.3510         0.7631             0.0212           0.0002         0.0350          2.0292            2.3012
  Median                4.3895       5.0467         4.0477         0.7777             0.0130           0.0000         0.0333          2.0250            2.3405
  Maximum               4.6345      10.1288         9.5781         2.4347             0.0871           0.0055         0.0700          2.0887            2.4264
  Minimum               3.9790       1.7607         1.2846         0.0676           − 0.0002         − 0.0004         0.0100          1.9146            1.9689
  Std. Dev.             0.1576       1.8339         1.7758         0.4619             0.0211           0.0008         0.0107          0.0382            0.1152
  Skewness            − 0.4473       0.2265         0.5247         0.4106             1.5848           5.0581         0.6871        − 0.3548          − 1.5855
  Kurtosis              2.5319       2.6377         2.7466         2.9992             4.8581          30.5118         3.5375          2.9214            4.5194
  Jarque-Bera           8.8360       2.9155        10.1016         5.8456          116.9940        7446.7280         18.8717          4.4178         107.1496
  Probability           0.0121       0.2328         0.0064         0.0538             0.0000           0.0000         0.0000          0.1000            0.0000



Algeria. The skewness results suggest that TNRR, OR, GR, MR, CR, and               biased and inconsistent parameter estimates.
FR have right-skewed distributions, whereas EF, GDP, and EC show left-                 Beyond the empirical testing results, theoretical considerations
skewed distributions The Jarque-Bera (JB) normality test results indi­             strongly support the expectation of non-linear dynamics in Algeria's
cate that all variables except TNRR do not follow a normal distribution,           ecological footprint–natural resource rent (EF–NRR) relationship. The
implying non-normality of the sample data. Quantile-quantile (Q-Q)                 country's resource–environment interactions are characterized by com­
plots is designed for the visualization of distribution of data. As shown in       plex structural and institutional features that generate inherently non-
Fig. 2, the points deviate substantially from the diagonal line, corrobo­          linear responses, including implementation delays in environmental
rating the non-normal distributions. For EF specifically, both the JB test         policies, transitional challenges in energy sector transformation, and
and Q-Q plot indicate non-normality. Consequently, the conventional                amplified sensitivity to external economic shocks. Algeria's pronounced
ARDL framework would be unsuitable given its inability to account for              dependence on hydrocarbon revenues creates structural rigidities and
non-normality during estimation, potentially biasing results. In contrast,         market distortions that produce asymmetric ecological responses to
the NARDL approach is more capable of addressing possible nonlinearity             positive versus negative economic shocks. Furthermore, policy initia­
in data (Cheng et al., 2021; Sun et al., 2022).                                    tives such as the National Climate Plan (2020) introduce adjustment
                                                                                   costs and implementation frictions that generate non-linear environ­
4.1.2. Non-linearity test                                                          mental outcomes. Institutional constraints, including bureaucratic de­
    To assess the linear specification of the analytical framework,                lays in policy execution and cyclical patterns in investment deployment,
comprehensive linearity diagnostics were conducted on the variables                further reinforce these non-linear dynamics. The convergence of
related to Algeria's ecological footprint, specifically TNRR, COAL,                empirical diagnostic evidence and theoretical reasoning provides
MINERAL, OIL, GAS, FOREST, GDP and EC. The linearity evaluation                    compelling justification for rejecting linear modeling specifications in
employed three complementary testing approaches:                                   favor of the NARDL framework, which explicitly accommodates the
                                                                                   identified non-linear relationships and asymmetric adjustment
 • Statistical normality assessment: The Jarque-Bera test was imple­               mechanisms.
   mented to examine distributional properties as a prerequisite for
   linear modeling assumptions. The results presented in Table 2                   4.1.3. Unit root test results
   demonstrate rejection of the null hypothesis across all examined                    Prior to estimating the non-linear ARDL model, it is essential to
   variables, indicating significant departures from normal distribu­              confirm that none of the variables are integrated of order two (I(2)),
   tions. These deviations from normality suggest potential limitations            which is assessed through unit root tests. To this end, this study performs
   of linear specification approaches that rely on normality                       ADF tests, both with and without considering structural breaks, as pre­
   assumptions.                                                                    sented in Table 4. The results of these unit root tests indicate that all
 • Non-linear dependence testing: The Brock–Dechert–Scheinkman                     variables are non-stationary and possess a unit root. However, by
   (BDS) test was applied to directly examine the presence of non-linear           applying first differences to the variables EF, TNRR, OR, GR, MR, CR,
   dependencies within the data series. Table 3 reports the corre­                 FR, GDP, and EC, stationarity is achieved for all of them. This implies
   sponding findings, which consistently reject the null hypothesis of             that the variables are not I(2), allowing the exploration of the asym­
   linear dependence across all variables. This systematic rejection               metric effects of these variables on EF in Algeria using the NARDL
   provides direct evidence of significant non-linear structures                   methodology, while accounting for GDP and EC as control variables.
   embedded within the series, thereby invalidating assumptions of                 Consequently, the study incorporates ADF tests, both including and
   purely linear relationships.                                                    excluding structural breaks, with the findings reported in Table 4, which
                                                                                   facilitate an investigation into the asymmetric impacts on ecological
    The combined evidence from distributional analysis, statistical                footprint in Algeria through the NARDL framework while controlling for
testing, and non-linearity diagnostics conclusively demonstrates that the          GDP and EC.
data series exhibit significant departures from linear specifications and
contain substantial non-linear dependencies. These findings indicate
                                                                                   4.2. Asymmetric NARDL bounds test of cointegration
that conventional linear regression approaches, which assume normally
distributed residuals and linear relationships, would likely produce
                                                                                       In this stage to investigate long-run relation between the variables,
                                                                                   the NARDL bounds testing approach proposed by Pesaran (Pesaran
                                                                                   et al., 2001) was applied. Table 5 indicates the bounds test output for
                                                                                   cointegration. The F-statistics for all six models exceed the 99 % upper
                                                                                   bound critical value, providing evidence to reject the null hypothesis of
                                                                                   no long-run relationship at the 1 % significance level. Therefore, the
                                                                                   bound test results confirm the existence of cointegrating relationships
                                                                                   between EF, TNRR, OR, GR, MR, CR, FR, GDP, and EC in the long -team.
                                                                                       The findings demonstrate that ecological pressures are structurally
 Fig. 2. Outcomes of long-run asymmetric effects of aggregate TNRR on EF.          embedded within the dynamics of resource exploitation and economic

                                                                               6
S. Meziane and B. Brahim                                                                                                                 Resources Policy 113 (2026) 105830


Table 3
Non-linearity BDS test results.
  Variable                        Dimensions                                                                                                                   decisions

                                  m=2                           m=4                            m=5                           m=6

  EF                              0.201389***                   0.437132***                    0.503911***                   0.550656***                       Nonlinear
  TNRR                            0.16961***                    0.351866***                    0.393324***                   0.41388***                        Nonlinear
  OIL                             0.174095***                   0.357664***                    0.397652***                   0.418184***                       Nonlinear
  GAS                             0.182047***                   0.381709***                    0.436334***                   0.475845***                       Nonlinear
  MINERAL                         0.179202***                   0.381872***                    0.434378***                   0.468013***                       Nonlinear
  COAL                            0.192378***                   0.425752***                    0.488875***                   0.530019***                       Nonlinear
  Forest                          0.154001***                   0.306349***                    0.336759***                   0.350674***                       Nonlinear
  LGDPP                           0.193986***                   0.421996***                    0.487538***                   0.53263***                        Nonlinear
  LEC                             0.207425***                   0.455899***                    0.527271***                   0.576725***                       Nonlinear

Note: The significance level represents ***, **, and * for 1 %, 5 %, and 10 %, respectively.



Table 4
Unit root test results.
  Variables                ADF test                                           ADF test with break point

                           At Level             At First Difference           At Level                    Break point          At First Difference            Break point

  EF                         1.777314           − 2.27446**                     − 3.91055                 1973:Q1                − 9.0054***                  1974:Q1
  TNRR                     − 0.05753            − 4.01875***                    − 3.59505                 1979:Q1                − 8.8549***                  1974:Q1
  OIL                      − 0.27748            − 4.805***                      − 3.86389                 1979:Q1                − 9.2506***                  1974:Q1
  GAS                        0.863101           − 2.507**                       − 1.58296                 2020:Q2                − 5.9167***                  1974:Q1
  MINERAL                  − 1.93744*           − 3.42933***                    − 4.72660**               1977:Q1                − 9.4532***                  1974:Q1
  COAL                     − 2.6464***          − 4.73847***                  − 11.6794***                1975:Q1              − 11.7196***                   1975:Q1
  Forest                   − 2.9815**           − 4.5620***                     − 3.57443                 1985:Q1                − 8.8030***                  1974:Q1
  GDP                      − 2.58055*           − 2.87667***                    − 4.58322**               1971:Q3              − 12.6645***                   1972:Q1
  EC                       − 3.1251**           − 2.69067***                    − 8.1969***               1972:Q2                − 5.6012***                  1973:Q1



growth, rather than arising as external or transitory phenomena. In                      dependence has led to intensified resource extraction, resulting in
particular, changes in the scale and composition of natural resource                     increased carbon emissions and environmental degradation. However,
rents, when combined with shifts in economic activity, produce                           it's important to note that this reliance has also provided Algeria with
enduring ecological impacts that extend beyond short-term fluctuations                   significant economic benefits, funding crucial infrastructure projects
and instead shape Algeria's long-run environmental trajectory. This                      and social programs that have improved the quality of life for many
persistence indicates that environmental degradation is not an inci­                     Algerians. The negative shock on natural resources, leading to a
dental outcome of development but a structural feature of the country's                  reduction in EF, can be explained by decreased extraction and use of
dependence on natural resources and its broader macroeconomic                            these resources. This reduction in resource availability slows down
framework. Consequently, addressing these challenges requires sus­                       economic activities, leading to a decline in energy consumption, in­
tainability strategies that are grounded in systemic, long-term reforms.                 dustrial production, and emissions. While this may seem positive from
                                                                                         an environmental perspective, it's crucial to consider the potential
                                                                                         socio-economic impacts of such reductions on Algeria's development
4.3. Asymmetric NARDL empirical analysis                                                 trajectory. The estimations of the long-run asymmetric effects of
                                                                                         aggregate TNRR on EF are further depicted in Fig. 2.
    Disaggregated TNRR on Algeria's EF. This sophisticated approach
allows for a nuanced analysis of the examining the distinct impacts of                   4.3.2. Disaggregate long-run asymmetries
positive and negative shocks in TNRR and its components: OR, GR, MR,                        To provide a more granular perspective, the study examines the in­
CR, and FR on EF. By utilizing this method, we can capture the complex                   dividual effects of five key TNRR: oil rents, gas rents, minerals rents, coal
dynamics between resource exploitation and ecological impact in the                      rents, and forest rents (see Fig. 3).
context of Algeria's unique economic and ecological landscape.
                                                                                          • Oil Rents: According to Table 7, A 1 % positive shock in OR in­
4.3.1. Aggregate long-run asymmetries                                                       creases EF by 0.001 %, while a negative shock decreases EF by
    The EF in Algeria. Positive shocks in TNRR lead to a 0.001 % increase                   0.0009 %. This positive relationship reflects Algeria's strategic po­
in EF, while negative shocks result in a 0.0007 % decrease. This asym­                      sition in the global oil market. The country's oil sector has been a
metry indicates that positive changes in TNRR have a more substantial                       cornerstone of economic growth, providing substantial revenues for
impact on EF than negative changes, highlighting the complex interplay                      national development. While the environmental impact is evident,
between resource utilization and environmental outcomes in Algeria's                        it's important to recognize that oil revenues have enabled Algeria to
resource-dependent economy. These findings align with previous                              invest in education, healthcare, and infrastructure, significantly
studies by Hassan et al., (2019) Ahmad et al. which demonstrate a                           improving living standards for its citizens (Chekouri et al., 2023).
positive correlation between natural resource extraction and environ­                       Moreover, Algeria has been making strides in modernizing its oil
mental degradation. However, they contradict Ahmad et al. (2021) who                        industry. The national oil company, Sonatrach, has been imple­
found that TNRR improve quality of the environment in the United                            menting advanced technologies to decrease the environmental effect
States. This discrepancy underscores the uniqueness of Algeria's situa­                     of oil extraction and production. These efforts include improved ef­
tion and the need for context-specific environmental policies. The pos­                     ficiency in operations, reduced gas flaring, and investments in car­
itive relationship between EF and TNRR in Algeria can be attributed to                      bon capture and storage technologies. Such initiatives demonstrate
the country's historical reliance on fossil fuels, particularly oil, which
account for over 90 % of total exports and primary revenue sources. This

                                                                                    7
S. Meziane and B. Brahim                                                                                                                    Resources Policy 113 (2026) 105830


Table 5                                                                                            diversification efforts, potentially reducing reliance on more
Bounds test results in the nonlinear cointegration.                                                carbon-intensive energy sources in other regions.
  F-Bounds Test                    Null Hypothesis: No levels of relationship                    • Mineral Rents: A 1 % positive shock in MR increases EF by 0.067 %.
                                                                                                   While this indicates a significant environmental impact, it's impor­
  Test              Value          Significance          Lower bound I      Upper Bound I
  Statistic                                              (0)                (1)                    tant to consider the broader context of Algeria's mineral sector. The
                                                                                                   country's rich mineral resources, including iron ore, phosphates,
  Model 1
                                                                                                   uranium, and rare earth elements, present substantial opportunities
  F-statistic       5.534***       Critical values 10    2.2                3.09                   for economic diversification and industrial development. Algeria has
                                   %
                                                                                                   been actively working to modernize its mining sector, focusing on
  K                 4              Critical values 5     2.56               3.49
                                   %                                                               sustainable practices and value-added production. For instance, the
  ​                 ​              Critical values 1     3.29               4.37                   government has introduced new mining laws aimed at attracting
                                   %                                                               foreign investment while ensuring environmental protection
  Model 2                                                                                          (Ben-Salha and Zmami, 2023). The development of the mining sector
                                                                                                   could lead to job creation, technology transfer, and economic growth
  F-statistic       6.8543 a       Critical values 10    2.2                3.09
                                   %                                                               in regions outside the traditional hydrocarbon-producing areas,
      K                 4          Critical values 5     2.56               3.49                   contributing to more balanced regional development.
                                   %                                                               •Forest Rents: The conditional nature of forest rents' impact on
                                   Critical values 1     3.29               4.37
      ​                 ​
                                                                                                   ecological sustainability is evident in Table A.1 (column 1). The
                                   %
                                                                                                   empirical estimates show asymmetric effects: a 1 % positive shock to
      Model 3                                                                                      forest rents increases the ecological footprint (EF) by about 0.010 %,
      F-statistic       5.5141 a   Critical values 10    2.2                3.09                   while a corresponding negative shock lowers it by approximately
                                   %                                                               0.020 %. This asymmetry implies that forest rent increases driven by
      K                 4          Critical values 5     2.56               3.49
                                                                                                   unsustainable exploitation amplify environmental degradation,
                                   %
      ​                 ​          Critical values 1     3.29               4.37                   whereas increases tied to sustainable forest management can
                                   %                                                               improve ecological outcomes. Algeria illustrates this duality: con­
      Model 4
                                                                                                   ventional forest extraction adds to ecological stress, yet large-scale
                                                                                                   reforestation efforts such as the Green Dam project help mitigate
      F-statistic       3.7936 a   Critical values 10    2.2                3.09
                                                                                                   desertification and sequester carbon, and ecotourism based on forest
                                   %
      K                 4          Critical values 5     2.56               3.49                   ecosystems provides income that supports conservation. Overall,
                                   %                                                               these dynamics echo the literature suggesting that renewable
      ​                 ​          Critical values 1     3.29               4.37                   resource rents can act either as environmental stressors or as sus­
                                   %                                                               tainability enhancers, depending heavily on governance quality
      Model 5                                                                                      (Usman et al., 2023).
      F-statistic       5.6977 a   Critical values 10    2.2                3.09                   •Coal Rents: As shown in Table A.1 (column 2), coal rents have no
                                   %                                                               statistically significant effect on the ecological footprint. This
      K                 4          Critical values 5     2.56               3.49                   absence of significance aligns with Algeria's negligible reliance on
                                   %
                                                                                                   coal in its energy mix, setting it apart from coal-intensive economies.
      ​                 ​          Critical values 1     2.54               3.86
                                   %
                                                                                                   As a result, Algeria is spared much of the ecological burden and so­
                                                                                                   cial adjustment costs commonly associated with coal dependency,
      Model 6
                                                                                                   and its primary environmental challenges lie with oil, gas, mineral,
      F-statistic       4.7717 a   Critical values 10    2.2                3.09                   and forest resource rents rather than coal.
                                   %
      K                 4          Critical values 5     2.56               3.49
                                   %                                                                In conclusion, the asymmetric analysis confirms that different types
      ​                 ​          Critical values 1     3.29               4.37                of natural resource rents exert heterogeneous effects on Algeria's
                                   %                                                            ecological footprint. Although environmental challenges remain sub­
Notes.                                                                                          stantial, Algeria has demonstrated notable progress in addressing them
 a
   Indicates statistically significant at the 1 % significance level.                           through economic diversification, modernization of extraction prac­
                                                                                                tices, and environmental protection initiatives. Its commitment to the
   Algeria's commitment to balancing economic needs with environ­                               Paris Agreement and the National Climate Plan underscores the recog­
   mental responsibilities.                                                                     nition of sustainability as a national priority, with ambitious renewable
 • Natural Gas Rents: Following the results shown in Table 6, a posi­                           energy targets set to reach 27 % of electricity generation by 2030. The
   tive and negative variations in GR have a negative impact on EF. This                        country's vast desert regions further enhance this potential by offering
   can be attributed to Algeria's dependence on natural gas for elec­                           significant opportunities for large-scale solar energy projects, which
   tricity and energy production, as well as the environmental impact of                        could satisfy domestic demand and strengthen Algeria's role as a future
   gas extraction and flaring. However, it's crucial to highlight that                          exporter of clean energy to Europe. While the transition entails struc­
   Algeria has been actively working to reduce gas flaring. The country                         tural challenges, Algeria's strategic efforts to balance resource exploi­
   has joined the World Bank's "Zero Routine Flaring by 2030″ initiative,                       tation with environmental protection and its investments in clean
   demonstrating its commitment to reducing the environmental                                   technologies place it on a promising trajectory. Overall, Algeria's expe­
   impact of its gas industry (Usman et al., 2023). Furthermore, Alge­                          rience provides valuable insights for other resource-rich economies
   ria's natural gas sector shows a crucial role in regional energy secu­                       seeking to reconcile economic growth with environmental
   rity, especially for Europe. The country has been investing in                               sustainability.
   expanding its liquefied natural gas (LNG) capabilities, positioning
   itself as a reliable energy partner. This strategic role not only benefits                   4.4. Robustness check
   Algeria economically but also contributes to global energy
                                                                                                    As a robustness check, this study supplements the NARDL estima­
                                                                                                tions with quantile regression, which enables the assessment of how

                                                                                            8
S. Meziane and B. Brahim                                                                                                           Resources Policy 113 (2026) 105830




                                               Fig. 3. Outcomes of long-run asymmetric effects of Aggregate TNRR on EF.


natural resource rents influence the ecological footprint across its con­              framework.
ditional distribution. The results presented in Table 8 reveal marked
distributional heterogeneity. Specifically, TNRR exhibit a negative and                4.5. Spectral Granger causality
statistically significant impact on EF from the 10th to the 75th quantiles,
with coefficients ranging from − 0.05116 at the 10th quantile to                           Given uncertainties surrounding causal relationships between the
− 0.02301 at the 75th quantile, though the magnitude of this effect de­                variables, this research utilizes Breitung and Candelon's (2006) spectral
clines at higher quantiles. By contrast, oil, gas, mineral, coal, and forest           Granger causality approach to examine causal linkages among EF and
rents consistently show positive and significant coefficients at the lower             TNRR, OR, GR, MR, CR, and FR. A key advantage of spectral analysis is
and median quantiles—for instance, oil rents range between 0.05116 at                  assessing causality across different time horizons (long-run,
the 10th quantile and 0.02301 at the 75th quantile—while their effects                 medium-run, short-run). Table 8 reports empirical results at frequencies
taper off toward the upper tail of the distribution. This pattern indicates            from 0.01 to 2.50. Panel A indicates TNRR Granger causes EF, but only
that ecological pressures are most acute in the lower-to-middle range of               in the long-run. Thus, TNRR significantly predicts EF in Algeria over
EF. The control variables also behave asymmetrically: GDP shifts from a                long horizons. Panel B reveals oil rents Granger cause EF across all ho­
negative coefficient (− 0.16 at the 10th quantile) to a positive one                   rizons, underscoring the ecological damages from oil production.
(0.109 at the 90th quantile), whereas energy consumption remains                       Phasing out oil dependence through renewable energy investments and
statistically insignificant across quantiles. To address these issues and              efficiency policies can curb emissions. GR cause EF only in the short-run,
ensure more reliable and robust inference, this study adopts the NARDL                 while mineral rents demonstrate causality at all frequencies. However,
                                                                                       no causal links exist between EF and CR or FR. In summary, spectral
                                                                                       analysis provides nuanced insights into causal relationships over
Table 6                                                                                different timescales. The findings highlight the particular significance of
Estimations of long-run asymmetric of the effect of aggregate and disaggregated        oil and MR in driving Algeria's ecological footprint across horizons.
TNRR on EF.
                         TNRR           Oil            Gas           Mineral           4.6. Model stability outcomes
                         (1)            (2)            (3)           (4)

  EFt-1                  − 0.11012***   − 0.1341       − 0.0437      − 0.0253              Verifying the reliability of estimated models is crucial for successful
                         (0.02182)      (0.0233)       (0.0186)      (0.0119)          econometric analysis. We have conducted post-diagnostic examinations
  TNRR positive          0.00114***     ​              ​             ​
                                                                                       to confirm the robustness of the non-linear ARDL estimations. Table 9
                         (0.00032)                                                     displays the tests performed to evaluate heteroscedasticity, serial cor­
  TNRR negative          − 0.00072**    ​              ​             ​                 relation, and the Wald test across all six models. The Wald test indicates
                         (0.00032)                                                     long-term asymmetry in the models significant at the 1 % level. The LM
  Oil positive           ​              0.0015***      ​             ​                 test found no serial association among parameters. The Breusch/Pagan
                                        (0.0004)                                       test showed no heteroscedasticity between variables. In short, Table 9
        negative
  Oil                    ​              − 0.0009***    ​             ​                 demonstrates the stability of the models.
                                        (0.0003)
  Gas positive           ​              ​              0.0060***     ​
      t-1
                                                       (0.0017)                        5. Conclusion and policy recommendations
  Gastnegative           ​              ​              0.0049*       ​
      -1
                                                       (0.0025)                        5.1. Conclusion
  Mineral positive       ​              ​              ​             0.0673**
          t-1
                                                                     (0.0288)
  Mineralt-1
              negative   ​              ​              ​             0.0191**              The EF is a vital metric for evaluating the environmental conse­
                                                                     (0.0320)          quences of human activities, offering insights into the extent of resource
  GDP                    0.05505**      0.0499**       0.1075**      0.0059**          consumption and the capacity of ecosystems to absorb the resulting
                         (0.02439)      (0.0248)       (0.0333)      (0.0232)          waste and carbon emissions. The role of TNRR as significant contribu­
  EC                     0.00441        0.0081*        − 0.0058**    0.0025*           tors to the EF has been well established in the existing literature.
                         (0.00801)      (0.0079)       (0.0111)      (0.0097)          However, much of the prior research has aggregated TNRR into a single
Notes: *, **, and *** denote statistically significant at the 10 %, 5 %, and 1 %       variable, which has led to inconsistent and often inconclusive findings.
levels, respectively.                                                                  This study seeks to bridge this gap by investigating the nuanced

                                                                                   9
S. Meziane and B. Brahim                                                                                                                         Resources Policy 113 (2026) 105830


Table 7
Quantile estimation analysis.
                                  Quantile

  Variable                        10th                            25th                                 50th                          75th                             90th

  TNRR                            − 0.05116**                     − 0.03504***                         − 0.03334***                  − 0.02301***                     − 0.013075
  OIL                             0.05116**                       0.03504***                           0.03334***                    0.02301***                       0.013073
  GAS                             0.05116**                       0.03504***                           0.03334***                    0.02301***                       0.013074
  COAL                            0.05284**                       0.03572***                           0.03517***                    0.02334***                       0.012662
  MINERAL                         0.05123**                       0.03511***                           0.03338***                    0.02310***                       0.013167
  FOREST                          0.05096**                       0.03498***                           0.03331***                    0.02301***                       0.013112

  GDP                             − 0.16*                         − 0.064**                            − 0.019                       0.05*                            0.109
  EC                              2.67E-06                        3.09E-07                             − 1.2E-06                     − 2.4E-06                        − 4.7E-06

Note: Values in parentheses indicate p values, and significance level at 1 % is presented by ***.


Table 8
Spectral Granger causality test (Frequency domain causality test).
  Direction of causality           Breitung-Candelon ()              Long term                                Medium term                           Short term

                                                                     ωi = 0.01            ωi = 0.05           ωi = 1.00         ωi = 1.50           ωi = 2.00          ωi = 2.50
  Panel A. Causality at aggregate level

  TNRR→ EF                         Wald statistics                   4.7525**             4.6405**            3.1643            5.409               5.2747             3.000
                                   p-value                           0.092                0.098               0.2055            0.066               0.0715             0.2221
                                   Result                            Yes                  Yes                 No                Yes                 Yes                No

  Panel B. Causality at disaggregate level

  Oil → EF                         Wald statistics                   5.0132**             4.894**             3.247             5.3018**            5.221**            2.699
                                   p-value                           0.081                0.086               0.197             0.070               0.073              0.268
                                   Result                            Yes                  Yes                 No                Yes                 Yes                No

  Gas → EF                         Wald statistics                   1.154                1.160               2.409             0.253               0.928              4.921**
                                   p-value                           0.564                0.559               0.299             0.881               0.628              0.085
                                   Result                            No                   No                  No                No                  No                 Yes

  Mineral → EF                     Wald statistics                   8.122**              8.087**             5.554**           5.810**             5.1351**           4.3179
                                   p-value                           0.0172               0.0175              0.062             0.0547              0.076              0.115
                                   Result                            Yes                  Yes                 Yes               Yes                 Yes                No

  Coal→ EF                         Wald statistics                   1.529                1.553               3.708             3.021               2.969              4.041
                                   p-value                           0.465                0.459               0.0.156           0.22                0.226              0.132
                                   Result                            Yes                  Yes                 Yes               No                  No                 No

  Forest → EF                      Wald statistics                   1.255                1.29                3.877             0.957               1.614              4.053
                                   p-value                           0.533                0.530               0.143             0.619               0.446              0.131
                                   Result                            No                   No                  No                No                  No                 No

Note: → represents causality. 10 %, %5 and 1 % levels of significance are depicted by *, **, and ***, respectively.


                                                                                                  increases in TNRR, particularly from oil, gas, minerals, and forests, are
Table 9
                                                                                                  significantly correlated with a rise in the EF over the long term. This
Model diagnostic test.
                                                                                                  suggests that while natural resource rents can foster short-term eco­
                Correlation LM    Heteroskedasticity      Ramsey          Wald test               nomic growth, they may do so at the expense of long-term environ­
                Test              test                    RESET test
                                                                                                  mental sustainability. Conversely, decreases in TNRR rents have
  Model 1       3.01954           0.336798                0.030253        6.26283***              relatively less pronounced effects on the EF, reinforcing the asymmetric
  Model 2       2.692848          0.260151                0.072105        8.17275***
                                                                                                  nature of the relationship between resource rents and ecological out­
  Model 3       13.30137          0.001215                0.718483        4.22762***
  Model 4       0.059213          0.566899                0.559306        2.21466***
                                                                                                  comes. Notably, the impact of coal rents was found to be insignificant
  Model 5       3.480027          0.256060                0.441797        2.00927***              compared to other resources, indicating that the environmental conse­
  Model 6       3.205291          0.15249                 0.221485        4.60149***              quences of coal extraction in Algeria may not be as severe as those linked
  Decision      No                No                      Models are      The existence           to oil or gas. This underscores the complexity of the interactions be­
                autocorrelation   heteroscedasticity      correctly       of Long-term            tween different types of natural resources and their varying impacts on
                                                          specified       asymmetry               environmental sustainability.
Note: Values in parentheses indicate p values, and significance level at 1 % is
presented by ***.                                                                                 5.2. Policy recommendations

relationship between TNRR and EF within the context of Algeria, a                                    Drawing on the empirical analysis of the interactions between
leading oil-producing and exporting country, over the period from Q1                              Algeria's natural resources and environmental dynamics, this section
1970 to Q4 2022. By disaggregating TNRR into distinct categories—oil,                             presents evidence-based policy recommendations aimed at advancing
natural gas, minerals, and forests—the study examines the asymmetric                              sustainable development, fostering economic diversification, and pro­
impacts of these resource rents on Algeria's environmental                                        moting inclusive socio-economic growth. Within this context, four key
sustainability.                                                                                   policy dimensions are identified as fundamental pillars for guiding
    The findings from this research provide several key insights. First,                          Algeria along a sustainable development trajectory.



                                                                                            10
S. Meziane and B. Brahim                                                                                                                 Resources Policy 113 (2026) 105830


 • Promoting renewable energy adoption: The promotion of                                     opportunities for future research. First, the analysis focuses exclusively
   renewable energy constitutes a critical strategy for Algeria's transi­                    on Algeria, limiting the generalizability of findings to other resource-
   tion toward a sustainable and resilient energy system. Policy initia­                     dependent economies with different institutional and economic struc­
   tives should be explicitly aligned with the 2030 National Climate                         tures. Second, while the study employs advanced econometric tech­
   Plan, ensuring that regulatory frameworks, investment incentives,                         niques, it relies primarily on time-series data without incorporating
   and development programs are coherent and mutually reinforcing.                           spatial or cross-sectional dimensions that might capture regional vari­
   Encouraging both public and private sector participation in renew­                        ations within Algeria. Third, the methodological approach, while uti­
   able energy projects—including solar, wind, and biomass—can                               lizing NARDL for asymmetric analysis, does not compare alternative
   substantially reduce the country's reliance on hydrocarbons, mitigate                     modeling frameworks such as quantile ARDL or threshold regression
   environmental degradation, and stimulate technological innovation                         models that might better capture distributional heterogeneity and
   within the energy sector. A systematic and strategically coordinated                      structural breaks in the resource-environment relationship. Fourth, the
   approach to renewable energy deployment is essential not only for                         analysis does not explicitly account for technological spillovers or
   enhancing energy security but also for advancing Algeria's long-term                      innovation effects that might moderate the resource-environment
   climate objectives.                                                                       relationship.
 • Economic diversification: Economic diversification remains a                                  Future research should address these limitations through several
   strategic imperative, given Algeria's pronounced fiscal dependence                        avenues. First, comparative studies across multiple resource-dependent
   on oil and gas revenues. Policymakers should prioritize the devel­                        economies would enhance the external validity of findings and identify
   opment of alternative economic sectors, including manufacturing,                          context-specific factors that influence resource-environment relation­
   renewable energy technologies, and service industries, thereby                            ships. Second, incorporating spatial econometric techniques could pro­
   strengthening economic resilience and reducing susceptibility to                          vide insights into regional variations in environmental impacts within
   fluctuations in global energy markets. Such diversification strategies                    resource-rich countries. Third, future studies should explore alterna­
   should be integrated within broader national development plans to                         tive econometric approaches, particularly quantile ARDL to examine
   ensure sustainable growth, fiscal stability, and the generation of new                    distributional effects across different quantiles of the ecological foot­
   employment opportunities, ultimately contributing to socio-                               print distribution, and threshold regression models to identify structural
   economic stability and long-term development.                                             breaks and regime changes in the resource-environment nexus. Fourth,
 • Governance improvements in the energy sector: Enhancing                                   future research should examine the role of technological innovation,
   governance within Algeria's energy sector is necessary to address                         human capital, and institutional quality as mediating factors in the
   structural inefficiencies inherent in a predominantly state-controlled                    resource-environment relationship. Additionally, research should
   system. Key measures include strengthening institutional capacity,                        explore the effectiveness of specific policy interventions through quasi-
   improving transparency, and reinforcing regulatory frameworks to                          experimental approaches or natural experiments. Finally, investigating
   facilitate private sector engagement and foster competition. By                           the dynamic interactions between renewable energy adoption, eco­
   establishing a predictable and investment-friendly environment,                           nomic diversification, and environmental outcomes would provide
   effective governance reforms can optimize resource allocation,                            valuable insights for policy design in resource-dependent economies
   stimulate innovation, and support sustainable energy development                          transitioning toward sustainability.
   in alignment with national policy priorities.
 • Socio-economic measures: Socio-economic interventions should                              CRediT authorship contribution statement
   complement structural and sectoral reforms to promote inclusive and
   equitable development. Comprehensive subsidy reforms are needed                               Said Meziane: Methodology, Investigation, Data curation, Concep­
   to enhance fiscal sustainability while safeguarding access to essential                   tualization. Bergougui Brahim: Writing – review & editing, Writing –
   goods and services. Addressing youth unemployment through the                             original draft, Visualization, Validation, Supervision.
   creation of green jobs and targeted vocational training programs can
   enhance social stability and strengthen human capital. Moreover,                          Declaration of competing interest
   these socio-economic policies should be designed in accordance with
   Algeria's commitments under the Paris Agreement, ensuring that                                The authors declare that they have no known competing financial
   development strategies are environmentally responsible and                                interests or personal relationships that could have appeared to influence
   contribute effectively to climate change mitigation objectives.                           the work reported in this paper.

5.3. Study limitations and future research directions

    This    study    acknowledges   several          limitations   that       present



Appendix A



                                    Table A.1
                                    Estimations of long-run asymmetric of the effect of coal and forest on EF.

                                                                          Coal                                   Forest

                                                                          (1)                                    (2)

                                     EFt-1                                − 0.0109 (0.0054)                      − 0.0931 (0.0213)
                                     Coal positive                        1.2313 (0.9148)                        ​
                                          t -1
                                     Coalt-1
                                             negative                     0.9156 (0.6605)                        ​
                                     Forest positive                      ​                                      0.1006** (0.0455)
                                            t-1

                                                                                                              (continued on next page)


                                                                                        11
S. Meziane and B. Brahim                                                                                                                                     Resources Policy 113 (2026) 105830

                                           Table A.1 (continued )
                                                                                Coal                                         Forest

                                                                                (1)                                          (2)
                                                    negative
                                             Forestt-1                          ​                                            − 0.0223** (0.0478)

                                             GDP                                0.0390** (0.0191)                            0.0746** (0.0252)
                                             EC                                 − 0.0088** (0.0105)                          0.0242* (0.0095)
                                           Notes: *, **, and *** denote statistically significant at the 10 %, 5 %, and 1 % levels,
                                           respectively.



Data availability                                                                                  Danish, Baloch MA., Mahmood, N., Zhang, J.W., 2019. Effect of natural resources,
                                                                                                        renewable energy and economic development on CO2 emissions in BRICS countries.
                                                                                                        Sci. Total Environ. 678, 632–638. https://doi.org/10.1016/j.scitotenv.2019.05.028.
    Data will be made available on request.                                                        Danish, Baloch MA., Wang, B., 2019. Analyzing the role of governance in CO2 emissions
                                                                                                        mitigation: the BRICS experience. Struct. Change Econ. Dynam. 51, 119–125.
                                                                                                        https://doi.org/10.1016/j.strueco.2019.08.007.
References
                                                                                                   Danish, Hassan ST., Khan, I., 2025. Achieving net-zero carbon emission targets in OECD
                                                                                                        countries: the role of the energy transition, institutional quality, and green
Ahmad, M., Jiang, P., Murshed, M., et al., 2021. Modelling the dynamic linkages between                 technological innovation. Gondwana Res. 144, 20–32. https://doi.org/10.1016/j.
     eco-innovation, urbanization, economic growth and ecological footprints for G7                     gr.2025.03.012.
     countries: does financial globalization matter? Sustain. Cities Soc. 70, 102881.              Ding, N., Field, B.C., 2005. Natural resource abundance and economic growth. Land
     https://doi.org/10.1016/j.scs.2021.102881.                                                         Econ. 81, 496–502. https://doi.org/10.3368/le.81.4.496.
Ahmed, Z., Asghar, M.M., Malik, M.N., Nawaz, K., 2020a. Moving towards a sustainable               Doğan, B., Tiwari, S., Bergougui, B., et al., 2025. Green innovation and fiscal spending:
     environment: the dynamic linkage between natural resources, human capital,                         decoding the path to sustainable development. Sustain. Dev. 33, 6307–6327.
     urbanization, economic growth, and ecological footprint in China. Resour. Policy 67,               https://doi.org/10.1002/sd.3464.
     101677. https://doi.org/10.1016/j.resourpol.2020.101677.                                      Emir, F., Karlilar, S., 2023. Application of RALS cointegration test assessing the role of
Ahmed, Z., Zafar, M.W., Ali, S., Danish, 2020b. Linking urbanization, human capital, and                natural resources and hydropower energy on ecological footprint in emerging
     the ecological footprint in G7 countries: an empirical analysis. Sustain. Cities Soc.              economy. Energy Environ. 34, 764–779. https://doi.org/10.1177/
     55, 102064. https://doi.org/10.1016/j.scs.2020.102064.                                             0958305X211073807.
Badeeb, R.A., Lean, H.H., Shahbaz, M., 2020. Are too many natural resources to blame               Eweade, B.S., Karlilar, S., Pata, U.K., et al., 2024. Examining the asymmetric effects of
     for the shape of the Environmental Kuznets Curve in resource-based economies?                      fossil fuel consumption, foreign direct investment, and globalization on ecological
     Resour. Policy 68, 101694. https://doi.org/10.1016/j.resourpol.2020.101694.                        footprint in Mexico. Sustain. Dev. 32, 2899–2909. https://doi.org/10.1002/sd.2825.
Ben-Salha, O., Zmami, M., 2023. Analyzing the symmetric and asymmetric effects of                  Gu, X., Baig, I.A., Shoaib, M., Zhang, S., 2024. Examining the natural resources-
     disaggregate natural resources on the ecological footprint in Saudi Arabia: insights               ecological degradation nexus: the role of energy innovation and human capital in
     from the dynamic ARDL approach. Environ. Sci. Pollut. Res. 30, 59424–59442.                        BRICST nations. Resour. Policy 90, 104782. https://doi.org/10.1016/j.
     https://doi.org/10.1007/s11356-023-26683-1.                                                        resourpol.2024.104782.
Bergougui, B., 2025a. Industrial robots for a sustainable future: uncovering the                   Harvey, R.G., 2015. From diamonds to coal? Critical reflections on Botswana's economic
     asymmetric effects of AI on ecological quality in G7 economies. Technol. Soc. 83,                  future. Extr. Ind. Soc. 2, 827–839. https://doi.org/10.1016/j.exis.2015.06.009.
     103021. https://doi.org/10.1016/j.techsoc.2025.103021.                                        Hassan, S.T., Xia, E., Khan, N.H., Shah, S.M.A., 2019. Economic growth, natural
Bergougui, B., 2025b. Circular pathways to sustainability: asymmetric impacts of the                    resources, and ecological footprints: evidence from Pakistan. Environ. Sci. Pollut.
     circular economy on the EU's capacity load factor. Land 14, 1216. https://doi.org/                 Res. 26, 2929–2938. https://doi.org/10.1007/s11356-018-3803-3.
     10.3390/land14061216.                                                                         Hatemi, J.A., 2020. Hidden panel cointegration. J. King Saud Univ. Sci. 32, 507–510.
Bergougui, B., 2024. Moving toward environmental mitigation in Algeria: asymmetric                      https://doi.org/10.1016/j.jksus.2018.07.011.
     impact of fossil fuel energy, renewable energy and technological innovation on CO2            Javorcik, B., Wei, S.-J., 2005. Pollution havens and foreign direct investment: dirty secret
     emissions. Energy Strategy Rev. 51, 101281. https://doi.org/10.1016/j.                             or popular myth? Contrib. Econ. Anal. Pol. 3, 1244.
     esr.2023.101281.                                                                              Karlilar Pata, S., Pata, U.K., 2025. Comparative analysis of the impacts of solar, wind,
Bergougui, B., Meziane, S., 2025. Assessing the impact of green energy transition,                      biofuels and hydropower on load capacity factor and sustainable development index.
     technological innovation, and natural resources on load capacity factor in Algeria:                Energy 319, 134991. https://doi.org/10.1016/j.energy.2025.134991.
     evidence from dynamic autoregressive distributed lag simulations and machine                  Khan, N.U., Udemba, E.N., Emir, F., Hussain, S., 2024. A look into sustainable
     learning validation. Sustain. Times 17, 1815. https://doi.org/10.3390/su17051815.                  development goal amidst technological innovation, financial development and
Bergougui, B., Murshed, S.M., 2023. Aggregate and disaggregate impact of natural                        natural resources: a symmetry and asymmetry analyses. Environ. Dev. Sustain. 26,
     resources on sustainable development: new evidence from the latest institutional                   11929–11956. https://doi.org/10.1007/s10668-023-03576-4.
     data. Environ. Sustain. Indic. 20, 100302. https://doi.org/10.1016/j.                         Kongbuamai, N., Bui, Q., Yousaf, H.M.A.U., Liu, Y., 2020. The impact of tourism and
     indic.2023.100302.                                                                                 natural resources on the ecological footprint: a case study of ASEAN countries.
Bergougui, B., Murshed, S.M., 2021. Revisiting the oil wealth-growth nexus: the role of                 Environ. Sci. Pollut. Res. 27.
     economic norms in avoiding the oil curse. Extr. Ind. Soc. 8, 100929. https://doi.org/         Li, Y., Bergougui, B., Murshed, S.M., 2025. China trade shock: is there a reversal of Dutch
     10.1016/j.exis.2021.100929.                                                                        disease for exporters of primary commodities? J. Int. Trade Econ. Dev. 1–28. https://
Bergougui, B., Murshed, S.M., 2020. New evidence on the oil-democracy nexus utilising                   doi.org/10.1080/09638199.2025.2553905.
     the varieties of democracy data. Resour. Policy 69, 101905. https://doi.org/                  Lo, K., Miller, E., Dworatzek, P., Basnet, N., Silva, J., Van Berkum, J.L., Halldórsdóttir, R.
     10.1016/j.resourpol.2020.101905.                                                                   B., Dyck, M.D.R., 2025. National ecological footprint and biocapacity accounts.
Bergougui, B., Murshed, S.M., 2025. Heterogeneous spillover effects: how FDI in                    Our World in Data, 2025. https://ourworldindata.org/.
     resources extraction, manufacturing, and services affect sectoral carbon emissions in         Pata, U.K., 2025. How to progress towards sustainable development by leveraging
     the MENA region. Nat Resour Forum n/a. https://doi.org/10.1111/1477-                               renewable energy sources, technological advances, and human capital. Renew.
     8947.70028.                                                                                        Energy 241, 122367. https://doi.org/10.1016/j.renene.2025.122367.
Bergougui, B., Satrovic, E., 2025. Towards eco-efficiency of OECD countries: how does              Pata, U.K., Erdogan, S., Ozcan, B., 2023. Evaluating the role of the share and intensity of
     environmental governance restrain the destructive ecological effect of the excess use              renewable energy for sustainable development in Germany. J. Clean. Prod. 421,
     of natural resources? Ecol. Inform. 87, 103093. https://doi.org/10.1016/j.                         138482. https://doi.org/10.1016/j.jclepro.2023.138482.
     ecoinf.2025.103093.                                                                           Pata, U.K., Karlilar, S., 2024. The integrated influence of energy security risk and green
Breitung, J., Candelon, B., 2006. Testing for short- and long-run causality: a frequency-               innovation on the material footprint: an EKC analysis based on fossil material flows.
     domain approach. J. Econom. 132, 363–378. https://doi.org/10.1016/j.                               J. Clean. Prod. 435, 140469. https://doi.org/10.1016/j.jclepro.2023.140469.
     jeconom.2005.02.004.                                                                          Pata, U.K., Yurtkuran, S., 2022. Is the EKC hypothesis valid in the five highly globalized
Cai, X., Li, K., Wang, W., et al., 2023. The role of resource rent in shaping CO2 emissions             countries of the European union? An empirical investigation with smooth structural
     in BRICS countries: a panel data approach. Resour. Policy 85, 103857. https://doi.                 shifts. Environ. Monit. Assess. 195, 17. https://doi.org/10.1007/s10661-022-10660-
     org/10.1016/j.resourpol.2023.103857.                                                               1.
Chekouri, S.M., Chibi, A., Benbouziane, M., 2023. The impact of natural resource                   Pesaran, M.H., Shin, Y., Smith, R.J., 2001. Bounds testing approaches to the analysis of
     abundance on ecological footprint: evidence from Algeria. Environ. Sci. Pollut. Res.               level relationships. J. Appl. Econom. 16, 289–326. https://doi.org/10.1002/jae.616.
     30, 69289–69306. https://doi.org/10.1007/s11356-023-26720-z.                                  Ragmoun, W., 2023. Ecological footprint, natural resource rent, and industrial
Cheng, C., Ren, X., Dong, K., et al., 2021. How does technological innovation mitigate                  production in MENA region: empirical evidence using the SDM model. Heliyon 9,
     CO2 emissions in OECD countries? Heterogeneous analysis using panel quantile                       e20060. https://doi.org/10.1016/j.heliyon.2023.e20060.
     regression. J. Environ. Manag. 280, 111818. https://doi.org/10.1016/j.
     jenvman.2020.111818.



                                                                                              12
S. Meziane and B. Brahim                                                                                                                                  Resources Policy 113 (2026) 105830

Rahman, A., Richards, R., Dargusch, P., Wadley, D., 2023. Pathways to reduce                       Wang, Qiang, Sun, Tingting, Rongrong, Li, 2023. Does artificial intelligence promote
    Indonesia's dependence on oil and achieve longer-term decarbonization. Renew.                      green innovation? An assessment based on direct, indirect, spillover, and
    Energy 202, 1305–1323. https://doi.org/10.1016/j.renene.2022.11.051.                               heterogeneity effects. Energy Environ. 36, 1005–1037. https://doi.org/10.1177/
Shehzad, K., Zeraibi, A., Zaman, U., 2022. Testing the N-shaped environmental Kuznets                  0958305X231220520.
    Curve in Algeria: An imperious role of natural resources and economic globalization.           Wang, Q., Li, Y., Li, R., 2025a. Integrating artificial intelligence in energy transition: a
    Resour. Policy 77 (January), 102700. https://doi.org/10.1016/j.                                    comprehensive review. Energy Strategy Rev. 57, 101600. https://doi.org/10.1016/j.
    resourpol.2022.102700.                                                                             esr.2024.101600.
Shin, Y., Yu, B., Greenwood-Nimmo, M., 2014. In: Sickles, R.C., Horrace, W.C. (Eds.),              Wang, Q., Li, Y., Li, R., 2024. Ecological footprints, carbon emissions, and energy
    Modelling Asymmetric Cointegration and Dynamic Multipliers in a Nonlinear ARDL                     transitions: the impact of artificial intelligence (AI). Humanit. Soc. Sci. Commun. 11,
    Framework BT - Festschrift in Honor of Peter Schmidt: Econometric Methods and                      1–18. https://doi.org/10.1057/S41599-024-03520-5.
    Applications. Springer, New York, New York, NY, pp. 281–314.                                   Wang, Q., Sun, T., Li, R., 2025b. Does artificial intelligence (AI) enhance green economy
Shu, D.Y., Deutz, S., Winter, B.A., et al., 2023. The role of carbon capture and storage to            efficiency? The role of green finance, trade openness, and R& D investment.
    achieve net-zero energy systems: Trade-Offs between economics and the                              Humanit. Soc. Sci. Commun. 12, 12. https://doi.org/10.1057/s41599-024-04319-0.
    environment. Renew. Sustain. Energy Rev. 178, 113246. https://doi.org/10.1016/j.               Wang, Q., Zhang, F., Li, R., 2025c. Artificial intelligence and sustainable development
    rser.2023.113246.                                                                                  during urbanization: perspectives on AI R&D innovation, AI infrastructure, and AI
Sun, Y., Razzaq, A., Sun, H., Irfan, M., 2022. The asymmetric influence of renewable                   market advantage. Sustain. Dev. 33, 1136–1156. https://doi.org/10.1002/sd.3150.
    energy and green innovation on carbon neutrality in China: analysis from non-linear            WDI, 2025. World Development Indicators. https://databank.worldbank.org/reports.as
    ARDL model. Renew. Energy 193, 334–343. https://doi.org/10.1016/j.                                 px?source=World-Development-Indicators.
    renene.2022.04.159.                                                                            Xu, P., Hussain, M., Ye, C., et al., 2022a. Natural resources, economic policies, energy
Terzi, H., Pata, U., 2020. Is the pollution haven hypothesis (PHH) valid for Turkey?                   structure, and ecological footprints' nexus in emerging seven countries. Resour.
    Panoeconomicus 67, 93–109. https://doi.org/10.2298/PAN161229016T.                                  Policy 77, 102747. https://doi.org/10.1016/j.resourpol.2022.102747.
Usman, O., Alola, A.A., Usman, M., Uzuner, G., 2023. Asymmetric effect of                          Xu, Y., Umar, M., Kirikkaleli, D., et al., 2022b. Carbon neutrality target in Turkey:
    environmental cost of forest rents in the Guinean forest-savanna mosaic: the                       measuring the impact of technological innovation and structural change. Gondwana
    Nigerian experience. Environ. Sci. Pollut. Res. 30, 50549–50566. https://doi.org/                  Res. 109, 429–441. https://doi.org/10.1016/j.gr.2022.04.015.
    10.1007/s11356-023-25653-x.                                                                    Zafar, M.W., Zaidi, S.A.H., Khan, N.R., et al., 2019. The impact of natural resources,
Van Der Ploeg, F., 2011. Natural resources: Curse or blessing? J. Econ. Lit. 49, 366–420.              human capital, and foreign direct investment on the ecological footprint: the case of
    https://doi.org/10.1257/jel.49.2.366.                                                              the United States. Resour. Policy 63.




                                                                                              13
