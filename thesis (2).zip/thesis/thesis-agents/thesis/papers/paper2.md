Sustainable Development




   RESEARCH ARTICLE                     OPEN ACCESS




Can Artificial Intelligence Technologies Advance
Environmental Sustainability? The Role of Institutional
Adaptability and Skill-­Biased Technological Transformation
Brahim Bergougui1,2,3

1National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria | 2 International Institute of Social Studies (ISS), Erasmus

University Rotterdam, Hague, the Netherlands | 3College of Business & Economics, Qatar University, Doha, Qatar

Correspondence: Brahim Bergougui (bergougui@iss.nl; brahimbergougui@gmail.com)

Received: 14 July 2025 | Revised: 18 September 2025 | Accepted: 26 September 2025

Keywords: AI | environmental sustainability | institutional framework | load capacity factor | technological transformation


  ABSTRACT
  The ubiquitous proliferation of artificial intelligence (AI) technologies across contemporary global economic systems necessi-
  tates a comprehensive empirical examination of their environmental ramifications, particularly with respect to environmental
  sustainability paradigms. This study leverages a longitudinal panel of 29 advanced and developing economies over the period
  2005–2024, employing AI patent filing frequencies as a quantitative proxy for national AI capability. Our econometric analy-
  sis reveals a statistically robust and economically meaningful relationship: higher AI activity is consistently associated with
  increases in the load capacity factor (LCF), a composite indicator of environmental sustainability. This association endures
  across multiple model specifications, remains significant under instrumental-­variable estimation to address endogeneity, and
  passes a battery of robustness and sensitivity checks. Mechanism analysis uncovers two principal transmission channels. First,
  AI drives technological transformation in labor markets—favoring non-­routine and high-­skilled occupations—which in turn
  enhances resource efficiency and elevates LCF. Second, institutional flexibility—proxied by regulatory quality and innovation-­
  friendly governance—magnifies AI's positive environmental effects by lowering transaction costs and facilitating diffusion.
  Heterogeneity tests further demonstrate that countries geographically proximate to global AI leaders experience stronger LCF
  gains, underscoring the importance of knowledge spillovers. Moreover, lower-­income and fossil-­f uel–dependent economies ex-
  hibit more pronounced benefits, indicating AI's potential as a transitional “leapfrog” technology. Among AI subfields, patents
  in energy-­management applications deliver the largest LCF improvements. Overall, our evidence underscores the pivotal role of
  AI-­driven patented technologies in strengthening environmental sustainability. Policies that incentivize AI innovation, support
  institutional adaptability, and foster international technology transfer are therefore essential to accelerate global progress toward
  sustainable development targets.


1   |   Introduction                                                                planet's renewable resources well before the year's end—
                                                                                    within the first 8 months consistently occurred in August
The escalating ecological strain on our planet has become a                         from 2021 to 2024, indicating that humanity exhausted the
central concern for policymakers and researchers alike. Based                       Earth's annual resource budget in less than 8 months each
on data from the global footprint network (see Figure 1), be-                       year. 2 This persistent overshoot reflects a fundamental mis-
tween 2021 and 2024, Earth Overshoot Day fell in August                             match between human consumption and the biosphere's
each year,1 showing that global consumption surpassed the                           regenerative capacity (Wang et al. 2024; Wiedmann and


This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium,
provided the original work is properly cited.
© 2025 The Author(s). Sustainable Development published by ERP Environment and John Wiley & Sons Ltd.


Sustainable Development, 2025; 0:1–23                                                                                                                         1
https://doi.org/10.1002/sd.70296
                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 1    |    Earth overshoot day from 1971 to 2024.


Barrett 2010). Climate-­ d riven catastrophes—ranging from            achieving comprehensive sustainability goals across both ad-
heatwaves, droughts, and floods to hurricanes—have inten-             vanced and developing countries (Bergougui 2025a; Vinuesa
sified, while global environmental degradation continues to           et al. 2020; Zhao and Gómez Fariñas 2023). At this critical
accelerate, with the IEA reporting that global energy-­related        juncture, AI's potential to reshape environmental outcomes is
CO2 emissions reached 37.8 Gt in 2024, marking a record high          immense, demonstrating synergistic effects across multiple do-
following a 0.8% increase during the year (Wälde 2010). These         mains (Wang et al. 2024): (i) Intelligent manufacturing: AI-­driven
trends underscore that achieving ecological sustainability has        production lines can analyze real-­time data at every stage—de-
emerged as a defining challenge of our era (Bergougui and             sign, assembly, logistics—minimizing waste, energy use, and
Aldawsari 2024; Petrosillo et al. 2024).                              pollutant output. Machine learning algorithms optimize process
                                                                      parameters so that factories consume fewer resources per unit
Traditional metrics—such as tracking CO2 emissions                    of output, directly reducing ecological footprints and enhancing
alone—capture only a fraction of this ecological imbalance            resource utilization efficiency across manufacturing processes
(Bergougui 2024; Bergougui and Meziane 2025; Karlilar Pata            (Zhou et al. 2024). (ii) Smart energy systems: By leveraging AI
and Korkut Pata 2025). In contrast, the load capacity factor          for real-­time monitoring and adaptive control, power grids can
(LCF), defined as biocapacity per capita divided by ecological        balance supply and demand more efficiently. Predictive mod-
footprint per capita, provides a more complete picture: an LCF        els forecast renewable generation from solar and wind, while
above one indicates that a nation's natural capital exceeds its       AI-­enabled balancing algorithms dispatch storage or flexible
demand, while an LCF below one signals ecological deficit. By         loads to smooth fluctuations. The result is higher utilization of
encompassing land, water, carbon, and resource usage in a sin-        clean energy, less reliance on fossil reserves, and a smaller gap
gle ratio, LCF more faithfully represents whether a country is        between ecological demand and Earth's regenerative capacity
moving toward or away from ecological environment quality             (Rajagopalan et al. 2024). (iii) Smart cities and green lifestyles:
(Shah et al. 2025; Sun et al. 2024). The ecological footprint (EF),   Urban platforms that integrate AI analytics can encourage low-­
which measures ecological pressure exerted by human activi-           carbon choices. City-­level applications track individual emis-
ties, has garnered widespread attention in sustainability discus-     sions—transport, electricity, waste—and convert them into
sions, with empirical work consistently showing that economic         “carbon credits” or gamified green incentives. By turning in-
growth and rising consumption expand per capita footprints,           tangible eco-­friendly behavior into measurable economic value,
outpacing improvements in production efficiency (Çakmak and           AI-­enabled systems can nudge residents toward sustainable life-
Acar 2022; Omar and Hasanujzaman 2025).                               styles, reducing per-­capita ecological footprints and improving
                                                                      LCF (Leal Filho et al. 2024).
To address this challenge, nations and international bodies are
advancing collaborative policies and frameworks. The 2015             However, the rapid development and application of AI also
Paris Agreement, for instance, unites nearly 200 countries in a       bring ethical, social, and environmental challenges (Leal
pledge to cap global temperature rise below 2°C, with aspirations     Filho et al. 2024; Qian et al. 2024). Training and running
to limit it to 1.5°C above pre-­industrial benchmarks (Bergougui      large-­scale AI models can be highly energy-­intensive3 (Karen
and Meziane 2025; Doğan et al. 2025). While reinforcing global        Hao 2019). In a January 2024 report, the International Energy
cooperation remains critical, artificial intelligence (AI) tech-      Agency (IEA) projected that electricity usage by data centers,
nology is triggering a new wave of technological revolution and       artificial intelligence systems, and cryptocurrency operations
industrial transformation, offering transformative potential for      may increase twofold by 2026—significantly exceeding the

2                                                                                                             Sustainable Development, 2025
                                                                                                                                               10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
average annual global growth rate of 3.4%. Combined, their                 single-­d imensional metrics (e.g., CO2 emissions) by cap-
energy demand could exceed 1000 terawatt-­hours (IEA 2024).                turing the balance between resource supply (biocapac-
In several parts of the world, data centers have already become            ity) and demand (footprint, including land, water, food,
key contributors to rising electricity consumption (IEA 2020).             carbon, and material flows). An LCF above one signals
Moreover, AI's “black-­box” nature can obscure environmen-                 an ecological surplus, where a country lives within its
tal trade-­offs; opaque decision-­making may overlook or un-               natural means; an LCF below one indicates an ecological
derestimate ecological risks (Miller 2019). Accordingly, it is             deficit. By linking AI to LCF, we offer a more nuanced
crucial to clarify how AI technology affects broad ecological              assessment of whether AI innovation helps countries
metrics—balancing its resource demands against its sustain-                transition to sustainable modes of production and
ability dividends.                                                         consumption.
                                                                        3. Mechanistic insights: Beyond establishing an empirical
Despite mounting evidence of AI's role in enhancing ecological
                                                                           link between AI and LCF, we uncover three primary chan-
sustainability—such as studies showing how AI-­based applica-
                                                                           nels through which AI drives ecological transition:
tions optimize production and consumption to raise resource-­              ○
                                                                              Energy efficiency gains: AI optimizes grid operations,
use efficiency and accelerate renewable energy adoption (Liu
                                                                              storage, and renewable integration, reducing per-­capita
et al. 2024)—existing research remains narrowly focused on a
                                                                              energy use and lowering ecological footprints.
handful of advanced economies or specific regions. As a result,            ○
                                                                              Skill-­and task-­biased technological shifts: AI's auto-
little is known about AI's ecological impact when resource endow-
                                                                              mation of routine tasks and augmentation of skilled
ments and development levels vary. In particular, there is a need
                                                                              labor alter production structures. Countries with higher
for a comprehensive, cross-­country analysis that includes both
                                                                              shares of nonroutine and high-­skill occupations realize
high-­ income and lower-­  income nations to determine whether
                                                                              larger LCF improvements due to AI's complementarity
AI-­driven innovations consistently improve ecological outcomes
                                                                              with skilled work.
beyond carbon reduction. Scholars have also explored contextual            ○
                                                                              Regulatory and institutional flexibility: AI's sustain-
factors shaping AI's sustainability outcomes across different de-
                                                                              ability potential is magnified in nations with adaptive
velopmental stages. Wang et al. (2023) identify varying relation-
                                                                              governance frameworks, streamlined environmental
ships between automation and ecological pressure, mediated by
                                                                              regulations, and supportive innovation ecosystems. We
resource dependency levels that differ between advanced and
                                                                              document that institutional quality positively moderates
developing countries. Global analyses emphasize AI's conditional
                                                                              the AI–LCF relationship.
efficacy: trade openness and institutional quality can amplify
AI's ecological benefits, particularly in advanced and developing       4. Contextual heterogeneity: We also explore heterogeneity
economies, while adaptive governance frameworks enhance AI's               by income level (high-­income vs. lower-­income), energy
positive impacts on ecological balance across different industrial         mix (fossil-­f uel-­reliant vs. renewable-­rich), and geographic
contexts.                                                                  proximity to AI innovation hubs (e.g., distance to the US).
                                                                           Our results show that AI's ecological benefits are strongest
This paper seeks to fill that gap by examining how AI-­driven              in advanced, renewable-­oriented, and US-­proximate econ-
technologies contribute to ecological sustainability—measured              omies, although developing countries and fossil-­         reliant
through the load capacity factor—across a panel of 29 advanced             nations also gain significantly—often because they have
and developing countries over the period 2005–2024. Our con-               more room for efficiency improvements
tributions are threefold:
                                                                        5. Strategic Policy Framework: These findings highlight that
                                                                           strategic AI technology deployment, tailored to different
  1. Comprehensive AI technology measurement: We con-
                                                                           developmental contexts and supported by adaptive gov-
     struct a novel index of national AI technology by count-
                                                                           ernance frameworks, can accelerate the global transition
     ing AI-­related patent applications filed under the Patent
                                                                           to comprehensive ecological sustainability. The analysis
     Cooperation Treaty (PCT), as cataloged by the WIPO
                                                                           demonstrates how progressive AI policy and targeted ap-
     Artificial Intelligence Index. Unlike proxies that rely solely
                                                                           plications across manufacturing, energy, and urban sys-
     on robotics or AI investment, our approach captures the
                                                                           tems can enhance the balance between ecological demand
     full spectrum of AI advancements—ranging from core
                                                                           and supply, ultimately improving Load Capacity Factors
     machine-­  learning algorithms to domain-­   specific appli-
                                                                           across diverse economic contexts.
     cations in energy management, agriculture, and envi-
     ronmental monitoring. By normalizing patent counts by
                                                                      The subsequent sections examine how AI technology can be
     population, we generate a robust measure of AI technology
                                                                      harnessed for ecological sustainability across diverse economic
     intensity that reflects how actively countries are develop-
                                                                      contexts. Section 2 outlines the theoretical foundations for using
     ing AI technologies. We find that higher AI patent inten-
                                                                      LCF as an ecological transition metric and formulates hypothe-
     sity correlates with significantly higher LCF, even after
                                                                      ses on AI's role. Section 3 details data sources, variable construc-
     controlling for endogeneity and conducting extensive ro-
                                                                      tion, and econometric methodology. Section 4 presents baseline
     bustness checks.
                                                                      panel regression results, including fixed-­effects estimates, en-
  2. Holistic sustainability metric: We foreground Load               dogeneity tests, and graphical analyses. Section 5 delves into
     Capacity Factor—the ratio of biocapacity per person              heterogeneity analyses across income, energy, and proximity
     to ecological footprint per person—as our principal              dimensions. Section 6 unpacks the mechanisms by which AI
     indicator of ecological sustainability. LCF surpasses            fosters ecological sustainability, drawing on case studies and


Sustainable Development, 2025                                                                                                             3
                                                                                                                                             10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
secondary data. Finally, Section 7 synthesizes policy implica-       combining IoT devices and AI-­powered platforms to establish
tions, acknowledges research limitations, and suggests direc-        affordable and scalable air quality monitoring systems across
tions for future research.                                           African cities, offering timely environmental insights that aid
                                                                     urban sustainability strategies.

2   |   Literature Review and Theoretical                            AI also contributes significantly to sustainable resource and en-
Mechanisms                                                           ergy management by optimizing usage patterns and improving
                                                                     energy efficiency. With smart algorithms and predictive analyt-
2.1   |   Literature Review                                          ics, AI can streamline how resources are distributed and energy
                                                                     is consumed (Ahmad et al. 2022). Smart grid systems are a no-
AI is at the forefront of current technological and industrial       table application in this area, as they incorporate sensors, mi-
advancements, representing a rapidly evolving domain fo-             croprocessors, and digital communication technologies to create
cused on replicating, enhancing, and extending human cog-            adaptive, automated electricity networks. These grids enhance
nitive capabilities. This field encompasses a diverse range          reliability and operational performance while reducing energy
of tools and techniques, including machine learning, deep            losses and supporting transitions to low-­carbon energy models
learning models, computer vision, speech recognition, natu-          (Dileep 2020). By enabling dynamic balancing of supply and de-
ral language processing, expert systems, reinforcement learn-        mand, smart grids contribute to minimizing waste and improv-
ing, recommendation mechanisms, and autonomous robotics.             ing overall sustainability. Furthermore, the combination of AI
According to Vinuesa et al. (2020), a system qualifies as AI if it   with renewable energy technologies paves the way for innova-
performs tasks such as sensory perception (e.g., audio, visual,      tions in clean power infrastructure, including hybrid wind-­solar
textual, or tactile inputs), decision-­making (like clinical diag-   systems, optimized energy storage, and intelligent grid integra-
nostics), predictive modeling (such as weather forecasting),         tion (Liu et al. 2022). Such advances help lower reliance on fossil
automatic data evaluation and pattern identification, interac-       fuels, cut emissions, and support long-­term ecological goals.
tive communication (via chatbots or social robots), and logical
reasoning.                                                           The industrial competitiveness aspect of AI implementation
                                                                     also deserves attention. Rasheed et al. (2024) demonstrated
With AI technologies advancing rapidly, their integration into       that competitive industrial performance, when enhanced by
both industrial operations and daily life is expanding, making       AI technologies, has asymmetric effects on environmental
their influence on environmental sustainability a growing sub-       outcomes. Their findings show that both positive and nega-
ject of academic inquiry (Francisco 2023). Recent empirical ev-      tive changes in competitive industrial performance mitigate
idence from developing economies provides valuable insights          carbon footprint, with the negative shock demonstrating
into this relationship. Rasheed et al. (2024) examined seven         significantly substantial value compared to positive shocks.
Asian developing countries from 1990 to 2020 and found that          This suggests that AI-­d riven industrial competitiveness can
artificial intelligence significantly reduces carbon footprints,     contribute to environmental improvements even during eco-
demonstrating its potential for environmental benefits in emerg-     nomic downturns or industrial adjustments. The role of AI in
ing economies. Their panel NARDL analysis revealed that AI,          supporting broader technological ecosystems is equally im-
along with natural resource rents, effectively decreases carbon      portant. Nazir et al. (2025) highlighted how the integration
emissions while information and communication technology             of computer technology, semiconductors, and artificial intel-
intensifies environmental concerns. The study emphasizes the         ligence creates synergistic effects that promote sustainable
critical importance of integrating artificial intelligence, robot-   development. However, their study also revealed that geopo-
ics, and technological industrial competitiveness to adequately      litical risks can decrease the progression of sustainable devel-
address carbon footprint challenges in Asian developing coun-        opment indices, suggesting that the environmental benefits
tries. Similarly, Nazir et al. (2025) explored the relationship      of AI may be influenced by broader political and economic
between technological innovation and environmental quality           stability factors.
among the top 12 semiconductor-­producing countries from 2000
to 2020. Using advanced panel ARDL techniques, they found            Nonetheless, despite these benefits, the rapid growth of AI raises
that computer technology, artificial intelligence, and semicon-      sustainability concerns. Ethical and societal implications are
ductor technology usage positively correlate with sustainable        gaining attention, as Cowls et al. (Cowls et al. 2021) argue that
development. Their findings reinforce the notion that AI and         even well-­intentioned AI applications may hinder sustainable
related technologies can serve as catalysts for environmental        development if they undermine personal freedoms or societal
improvements when properly integrated into sustainable devel-        norms. Moreover, the environmental costs of AI itself—espe-
opment frameworks.                                                   cially the energy and computational resources required—must
                                                                     be factored into sustainability evaluations. Since the emergence
AI offers promising opportunities to support ecological goals        of deep learning around 2012, the energy consumption associ-
through enhanced real-­time observation, data-­driven insights,      ated with training AI models has soared. For instance, Taddeo
and advanced decision-­ making tools (Himeur et al. 2022).           et al. (Taddeo et al. 2021) estimated that a single training run of
For example, in environmental surveillance, AI can gather            GPT-­3 generates roughly 223,920 kg of CO2 emissions, equiva-
and process data in real time, helping to anticipate ecological      lent to what 49 average American cars emit annually. This ex-
shifts that could impact sustainability. The AirQo initiative,       ample highlights the inherent tension between advancing AI
led by Bainomugisha et al. (2024), showcases this capability by      capabilities and preserving environmental integrity.



4                                                                                                            Sustainable Development, 2025
                                                                                                                                             10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
2.2   |   Theoretical Mechanisms                                      The resource reallocation mechanism operates through what
                                                                      Acemoglu and Restrepo (2018) describe as the “productivity effect”
The relationship between AI patents and ecological sustainabil-       of automation. As AI technologies handle routine tasks more ef-
ity can be theoretically grounded in several well-­established eco-   ficiently, human resources are freed to focus on complex, creative
nomic frameworks. This section integrates endogenous growth           activities—including environmental stewardship and sustainable
theory, institutional economics, and technological change the-        innovation. Firms in economies with larger shares of skilled labor
ories to provide a comprehensive understanding of the mecha-          and nonroutine occupations realize greater productivity gains
nisms through which AI innovations influence environmental            from AI, generating surplus resources that can be invested in en-
outcomes.                                                             vironmental R&D and cleaner production technologies (Al-­Jafari
                                                                      and Altaee 2023; Godil et al. 2021; Zhang et al. 2017).

2.2.1   |   Endogenous Growth Theory
and Innovation-­Driven Environmental Progress                         2.2.3   |   Role of Flexible Institutional Frameworks

Drawing from Romer's (1990) endogenous growth theory, tech-           The New Institutional Economics framework, particularly
nological innovations—captured through patent filings—serve           North's (1990) theory of institutions, provides crucial insights
as key drivers of sustained economic progress and structural          into how formal and informal rules shape technology adop-
transformation. The theory posits that knowledge spillovers           tion patterns. The flexibility and effectiveness of institutional
from research and development activities generate positive ex-        frameworks critically determine how firms exploit AI patents
ternalities that extend beyond immediate commercial applica-          for ecological sustainability improvements. Strong, adaptable
tions. In the context of AI patents, this framework suggests that     governance systems reduce transaction costs associated with
innovations in artificial intelligence create knowledge spillovers    environmental compliance and technology adoption, following
that can be redirected toward environmental applications, lead-       Williamson's (2000) transaction cost economics principles.
ing to what Aghion and Howitt (1990) term “creative destruc-
tion” in traditional, pollution-­intensive production processes.      Acemoglu and Robinson's (2013) theory of inclusive versus ex-
The Porter Hypothesis (Porter and Van Der Linde 2017) further         tractive institutions offers additional theoretical grounding.
supports this mechanism by arguing that properly designed en-         Inclusive institutions—characterized by secure property rights,
vironmental standards trigger innovation that often fully offsets     rule of law, and regulatory flexibility—create incentives for
compliance costs (Bergougui and Murshed 2025). AI patent              firms to invest in long-­term environmental improvements en-
accumulation represents a stock of technological capabilities         abled by AI technologies. These frameworks lower compliance
that firms can leverage to meet increasingly stringent environ-       burdens and legal uncertainties, encouraging businesses to
mental regulations while maintaining competitiveness. This            adopt patented AI innovations for environmental applications
innovation-­offset effect is particularly pronounced in AI appli-     (Carrillo 2020; Smuha 2021).
cations where pattern recognition, optimization algorithms, and
predictive analytics can simultaneously enhance productivity          Conversely, extractive institutions or overly rigid regulatory re-
and reduce environmental impact.                                      gimes can create what Olson (1993) termed “institutional scle-
                                                                      rosis,” where established interests resist technological change.
                                                                      Such environments may deter firms from integrating AI into
2.2.2   |   Skill-­Biased and Routine-­Biased Technological
                                                                      operations, limiting potential gains in ecological sustainability
Change Theory
                                                                      (Traverso et al. 2023). The institutional quality thus acts as a
                                                                      moderating variable that amplifies or diminishes the positive
Patent filings in AI reflect growing technological sophistication
                                                                      externalities of AI patents on environmental outcomes.
that extends beyond automation of manual routines toward sub-
stitution of cognitive, high-­skill tasks (Acemoglu et al. 2022).
                                                                      The theoretical synthesis generates the following testable
The skill-­biased technological change theory (Acemoglu 2002;
                                                                      hypotheses:
Machin 2008) provides a foundational framework for under-
standing how AI innovations reshape labor markets and, con-             • H1. Drawing from endogenous growth theory and the Porter
sequently, environmental outcomes. This theory suggests that              Hypothesis, a greater volume of AI patent filings is associated
technological progress increases the relative demand for skilled          with improvements in ecological sustainability through inno-
workers who are better positioned to utilize complex technolo-            vation spillovers and environmental technology development.
gies effectively.
                                                                        • H2. Based on skill-­biased and routine-­biased technolog-
                                                                          ical change theories, the labor market transformations in-
In the environmental context, skilled workers are more likely to
                                                                          duced by AI patent accumulation contribute to enhanced
identify and implement eco-­efficient practices, operate sophisti-
                                                                          ecological sustainability performance through improved re-
cated environmental monitoring systems, and engage in green
                                                                          source allocation and environmental expertise deployment.
innovation processes. The routine-­biased technological change
framework (Acemoglu and Autor 2011; Autor et al. 2003) com-             • H3. Grounded in institutional economics, the positive im-
plements this by explaining how AI displaces codifiable, rule-­           pact of AI patents on ecological sustainability is moderated
based tasks while complementing nonroutine problem-­solving               by institutional quality, being stronger in economies with
roles that often involve environmental optimization and sus-              flexible, inclusive institutional frameworks that facilitate en-
tainability planning (Bergougui 2025d).                                   vironmental technology adoption.

Sustainable Development, 2025                                                                                                           5
                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Integrating these mechanistic analyses, Figure 2 schematically        hectares (gha). This ratio analysis offers a holistic evaluation
delineates a holistic theoretical framework.                          of environmental pressure (EF) and the Earth's ability to with-
                                                                      stand it (BC).

                                                                        • LCF > 1: This indicates a sustainable ecological situation.
3   |   Empirical Methodology
                                                                          The BC exceeds the EF, meaning that the Earth's regenera-
                                                                          tive capacity can handle human demands.
3.1   |   Data Sources and Construction
                                                                        • LCF < 1: This signifies an unsustainable situation. EF sur-
3.1.1   |   Dependent Variable                                            passes BC, highlighting environmental stress and exceed-
                                                                          ing the Earth's ability to replenish resources.
Within the context of this research, LCF serves as the investi-
                                                                        • LCF = 1 signifies a critical threshold at which the system is
gated dependent variable. Owing to its comprehensive nature,
                                                                          balanced on the edge of ecological sustainability.
LCF is employed as a proxy for ecological sustainability. This
metric mitigates the shortcomings inherent in employing CO2
                                                                      By combining supply (BC) and demand (EF) into a single, di-
emissions, EF, and the environmental performance index as
                                                                      mensionless metric, LCF directly reflects the ecological carry-
indicators of ecological sustainability (Bergougui 2025b; Sun
                                                                      ing capacity across various environmental domains (air, water,
et al. 2024). The utility of CO2 as a proxy for ecological quality
                                                                      and soil). Its wide recognition and ability to provide insights
has been subject to critique because of its exclusive focus on
                                                                      into the long-­term sustainability of human–environment in-
energy-­related emissions, neglecting a comprehensive spectrum
                                                                      teractions (Bergougui 2024; Yurtkuran and Pata 2024) make
of environmental attributes. Conversely, while ecological foot-
                                                                      LCF an ideal proxy for ecological sustainability in this study,
prints offer a broader perspective on environmental pressures,
                                                                      offering a nuanced understanding of the balance between
they consider only consumption patterns, disregarding the criti-
                                                                      human consumption and ecosystem resilience. Furthermore,
cal supply side, specifically the Earth's biocapacity. Biocapacity,
                                                                      its applicability in evaluating the effectiveness of AI initiatives
which represents the planet's ability to regenerate resources and
                                                                      in mitigating ecological pressures strengthens the justifica-
assimilate waste, is indispensable for a complete assessment of
                                                                      tion for its deployment in this context.
environmental quality. To holistically evaluate environmental
services, Siche et al. (2010) introduced the LCF, which synthe-
                                                                      Figure 3 delineates the LCFs of the 29 countries between 2005
sizes human demands on environmental resources with the
                                                                      and 2023. Most of the 29 countries studied exhibited LCF val-
Earth's regenerative capacity, providing a more comprehensive
                                                                      ues below 1, indicating that their ecological footprints consis-
measure of ecological sustainability (Bergougui et al. 2024; Uche
                                                                      tently exceeded domestic biocapacity. Countries such as Austria,
et al. 2024).
                                                                      Belgium, Czechia, France, Germany, Greece, India, Italy, Japan,
                                                                      Korea, Malaysia, Mexico, the Netherlands, Poland, Portugal,
LCF is calculated as the ratio of biocapacity
                                           ) to the ecological
         (
                      Biocapacity (BC)                                Spain, Switzerland, Türkiye, the United Kingdom, and the
footprint LCF = Ecological Footprint (EF) .                           United States never reached ecological balance during this pe-
                                                                      riod. In contrast, Brazil and Canada maintained LCF values
where BC represents the Earth's ability to regenerate resources       well above 1, signaling sustained ecological surpluses: Brazil's
and absorb waste, and EF quantifies human demand for en-              LCF decreased modestly from around 3.0 to 2.5, while Canada's
vironmental resources, both of which are measured in global           remained near 1.3–1.4. Several European nations—Denmark,




FIGURE 2    |    Analytical framework.


6                                                                                                             Sustainable Development, 2025
                                                                                                                                                       10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 3    |    Trend of load capacity factor across 29 countries (2005–2024).


Italy, Portugal, Spain, Sweden, and the United Kingdom—                      worldwide AI innovation analysis. While larger economies dom-
showed gradual upward trends in LCF, reflecting improvements                 inate our dataset, smaller nations' minimal carbon footprints
that brought them closer to (or, in Denmark's case, just above)              maintain sample validity for examining AI technology's envi-
the sustainability threshold. Conversely, India and Türkiye ex-              ronmental implications. Throughout the studied period, global
perienced notable declines, with India's LCF falling from about              PCT AI patent submissions expanded 2.4-­fold, demonstrating
0.6 to 0.45 and Türkiye's dropping from 0.75 to 0.60, highlight-             accelerated innovation momentum. Regarding the geographic
ing growing resource pressures. High-­income countries such                  distribution of PCT AI patents from 2005 to 2024, America com-
as Australia, Finland, Norway, and Switzerland displayed rel-                mands the dominant position with 51% of worldwide filings.
atively stable but below-­  threshold LCFs, while Russia's sur-              Germany and Britain follow as secondary contributors at 6%
plus weakened slightly. Singapore remained at the lowest end,                each, while remaining nations individually represent under 5%
around 0.05–0.10, due to limited biocapacity and high per-­capita            of total submissions. Consequently, America maintains substan-
consumption. Overall, only Brazil and Canada consistently                    tial supremacy in global AI technological development.
achieved ecological surpluses. Others have either remained in
deficit or are only beginning to approach balance. These findings            Table 1 lists each variable alongside its definition and data
underscore the urgent need for policies that expand biocapacity              source. To address any gaps in the data, missing values were
(e.g., reforestation, habitat restoration), enhance resource effi-           estimated using linear interpolation. This method projects the
ciency (especially in energy and land use), and curb consump-                trend between neighboring observations, thereby minimizing
tion to help nations move toward sustainable ecological footing.             interpolation error and preserving data continuity (Honaker and
                                                                             King 2010).

3.1.2   |   Independent Variable
                                                                             3.2   |   Model Specification
The evaluation of artificial intelligence advancement across na-
tions utilizes patent filing data extracted from WIPO's AI classi-           Our baseline specification employs a two-­
                                                                                                                      way fixed-­
                                                                                                                                effects
fication system, encompassing PCT applications submitted by 30               panel regression:
selected economies during the 2005–2020 timeframe in 29 coun-
tries (see Table A1). WIPO's AI patent taxonomy encompasses                                   LCFit = 𝛼 + 𝛽 1 AIit + Xit + 𝜇 i + 𝜏 t + 𝜀it       (1)
three primary domains: technical methodologies, functional
implementations, and sectoral applications, with each domain                 where:
containing multiple specialized subdivisions. Our analysis in-
corporates comprehensive patent counts across all AI categories                   • LCFit indicates country i's ecological sustainability in year t,
submitted via PCT channels from the designated countries. The
                                                                                  • AIit counts of AI-­related patent submissions,
chosen sample represents more than 95% of annual global PCT-­
filed AI technologies, establishing strong representativeness for                 • Xit comprises control variables,


Sustainable Development, 2025                                                                                                                     7
                                                                                                                                                                10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
    • 𝜇i and 𝜏 t are country and year fixed effects, respectively,              for our primary hypothesis H1, which proposes that arti-
                                                                                ficial intelligence enhances environmental sustainability
    • 𝜀it is a heteroskedasticity-­robust error term.
                                                                                (Bergougui 2025c). The findings demonstrate that nations
                                                                                with superior AI capabilities exhibit markedly improved eco-
A statistically significant positive estimate of 𝛽 1 indicates that
                                                                                logical performance metrics, even after accounting for various
higher AI is associated with higher levels of ecological sustain-
                                                                                confounding variables.
ability. Summary statistics are provided in Table A2.


4   |   Results and Discussion                                                  4.2   |   Testing for Endogeneity

4.1   |   Primary Empirical Findings                                            A critical methodological concern in our model specification in-
                                                                                volves the potential for bidirectional causality between environ-
The empirical findings displayed in Table 2 explore the association             mental sustainability and artificial intelligence development.
between artificial intelligence advancement and environmental                   Specifically, countries demonstrating superior environmental
performance indicators through LCF. Our two-­way fixed-­effects                 performance may possess greater resources and motivation
panel estimation reveals significant evidence supporting AI's                   for technological advancement, potentially accelerating AI in-
beneficial environmental contributions. The foundational model                  novation. To address this reverse causality issue, we employ
(Column 1), which examines AI's direct influence without ad-                    an instrumental variables framework utilizing two-­stage least
ditional variables, shows a positive and highly significant coef-               squares estimation. Our instrumental variable approach con-
ficient at the 1% threshold. Upon incorporating comprehensive                   structs the instrument IVit for AIit as follows:
nation-­level control variables (Column 2), the AI parameter re-
tains its positive magnitude and statistical significance at the 1%
                                                                                                           IVit = 𝜑i AIU .S. t−1                          (2)
level, confirming the stability of this empirical relationship.
                                                                                  • 𝝋i represents the standardized inverse geographic distance
The persistent positive correlation between AI sophistica-                          between country i's capital and Washington D.C., normal-
tion and LCF values offers substantial empirical validation                         ized within the 0–1 range with the US domestic distance


TABLE 1    |    Variable definitions, sources, and construction.

    Variable name                   Code                        Description        Unit of measurement               Data source and web link
    Load capacity                    LCF                    Ratio of total              Ratio (unitless)                    Footprint network
    factor                                                 biocapacity per
                                                                                                                        https://​w ww.​footp​rintn​
                                                         capita to ecological
                                                                                                                         etwork.​org/​our-­​work/​
                                                         footprint per capita
                                                                                                                          ecolo​gical​-­​footp​rint/​
    Artificial                 AI Technology            AI patenting activity        Patents (thousands)               AI Index, WIPO Database
    intelligence                                         submitted under
                                                                                                                         https://​w ww.​w ipo.​int/​
    technology                                            the PCT system
                                                                                                                          tech_​trends/​en/​artif​
                                                                                                                           icial_​intel​ligen​ce/​
    Economic growth                  GDP              Natural log of per capita        Log of constant              World Development Indicators
                                                      Gross Domestic Product             2021 PPP $
    Industrial                    Industry                  Share of total              Percentage (%)                   https://​datab​ank.​world​
    employment                                           employment in the                                               bank.​org/​source/​world​
                                                          industrial sector                                             -­​devel​opmen​t-­​indic​ators​
    Internet                       Internet             Share of individuals            Percentage (%)
    penetration                                          using the Internet
    Foreign direct                   FDI                Net FDI inflows as a        Percentage of GDP (%)
    investment                                           proportion of GDP
    Urbanization                    Urban                Share of population            Percentage (%)
                                                        living in urban areas
    Trade openness                  Trade                  Merchandize              Percentage of GDP (%)
                                                          trade value as a
                                                         proportion of GDP
    Population density           Population              Population density          Hundreds of persons
                                                                                         per sq. km
Abbreviation: WIPO, World intellectual property organization.


8                                                                                                                             Sustainable Development, 2025
                                                                                                                                                           10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 2    |    Primary regression outcomes.                                       variable methodology. The first stage (Column 1) demonstrates
                                                                                   that our chosen instrument—combining geographic proxim-
                                           Dependent variable:
                                                                                   ity to the US with lagged American AI development—exhibits
                                           Load capacity factor
                                                                                   strong positive correlation with AI. This significant association
  Explained variable                       (1)                      (2)            validates instrument relevance, meeting the primary require-
                                                                                   ment for valid instrumentation.
  AI technology                      0.030 (3.56)             0.035 (4.46)
  Economic growth                                           −0.100 (−2.91)         Additionally, instrument strength receives confirmation through
                                                                                   both Cragg-­Donald Wald F-­statistics (1212.19) and Kleibergen-­
  Industry                                                  −0.880 (−3.92)
                                                                                   Paap Wald F-­statistics (130.68), substantially exceeding conven-
  Urban                                                     −0.510 (−3.51)         tional threshold values, eliminating weak instrument concerns.
                                                                                   Under-­identification tests further confirm instrument validity,
  FDI                                                       −0.005 (−0.24)
                                                                                   demonstrating adequate model identification. The second stage
  Internet                                                  −0.257 (−4.56)         (Column 2) reveals that AI development's environmental impact
  Trade                                                       0.099 (4.35)         remains positive and statistically significant, consistent with base-
                                                                                   line fixed-­effects findings. This result reinforces evidence that AI
  Population                                                  0.005 (2.14)         adoption enhances environmental sustainability. Coefficient sta-
  Constant                          0.633 (219.23)            2.405 (7.11)         bility across various specifications indicates robust relationships
                                                                                   unaffected by omitted variables or reverse causality. Overall,
  Country FE                                ✓                       ✓              2SLS estimates confirm AI's positive ecological contribution.
  Country YE                                ✓                       ✓
  Obs.                                     551                     551             4.3   |   Robustness Checks
  R2                                     0.986                    0.989
                                                                                   To evaluate the consistency and dependability of our primary
Note: Robust standard errors in parentheses. Statistical significance is denoted
by **p < 0.05, and ***p < 0.01.                                                    estimation results, we subject the fundamental model from
                                                                                   Equation (1) to comprehensive sensitivity testing through var-
                                                                                   ied specifications, variable modifications, and sample parti-
       calibrated at 1 km. Higher values indicate closer geographic
                                                                                   tioning. These validation exercises seek to establish whether
       proximity to the United States.
                                                                                   the documented association between artificial intelligence
  • AI U .S. t−1 denotes the preceding year's AI development level                 development and load capacity factor maintains consistency
    within the United States.                                                      across different analytical frameworks and environmental
                                                                                   conditions.
This instrumental variable construction fulfills both rele-
vance and exclusion criteria essential for valid IV implemen-
tation. Through weighting lagged US AI advancement with                            4.3.1   |   Modified Variable Specifications
𝝋i—the standardized proximity metric to the US capital—
our instrument leverages established patterns of geographic                        Initial robustness verification involves altering the operation-
knowledge diffusion, where technological benefits decrease                         alization of core variables (Table 4). Column (2) substitutes the
with increasing physical distance (Kwon et al. 2022). Given                        dependent variable with the natural logarithm of LCF to address
America's dominance in AI patent applications, neighbor-                           potential non-­ linear relationships. Extreme value treatment
ing countries benefit from enhanced access to advanced AI                          through winsorization procedures was applied to data under-
methodologies through partnerships, technology transfer, and                       lying Columns (3) and (4), whereby the top and bottom 1% of
informal knowledge exchange, establishing robust statistical                       observations were adjusted for both the outcome variable (LCF)
correlation between IV and domestic AI (Ganguli et al. 2020;                       and the predictor variable (AI).
Zheng and Slaper 2016). The one-­year lag in US AI measure-
ments establishes temporal precedence, preventing direct                           To incorporate innovation quality considerations, Column (5)
simultaneous impacts of American AI progress on foreign                            reconceptualized AI development as the interaction between
emission levels, thus satisfying exclusion requirements. Since                     a nation's AI patent portfolio and R&D expenditure as a per-
geographic distance remains constant over time and lagged                          centage of GDP, reflecting the premise that enhanced R&D
US AI measures are predetermined relative to current envi-                         investment corresponds with superior patent quality. Across
ronmental outcomes, the instrument maintains exogeneity,                           all examined specifications, the AI coefficient maintained its
addressing omitted variable concerns and reverse causality is-                     positive direction, providing robust evidence that AI advance-
sues (Abbasiharofteh et al. 2024; Hu et al. 2025). Therefore, IV                   ment enhances environmental sustainability regardless of
delivers reliable exogenous variation in AI, facilitating consis-                  measurement approach.
tent estimation of AI's environmental impact while preserving
fundamental IV assumptions (Ganguli et al. 2020).
                                                                                   4.3.2   |   Temporal Subsample Verification
Table 3 presents two-­ stage least squares estimation results
designed to control for potential endogeneity between AI and                       To eliminate confounding influences from the COVID-­19 pan-
LCF. This approach isolates causal effects through instrumental                    demic, Column (2) of Table 5 omitted data from 2020 forward,

Sustainable Development, 2025                                                                                                                        9
                                                                                                                                                                           10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 3    |    Two-­stage least squares (2SLS) regression results.

                                        Baseline result                  AI technology First Stage                     Load capacity factor Second Stage
  Explained variable                             (1)                                     (2)                                                 (3)
  AI technology                            0.035 (4.46)                                                                               0.0295 (0.0059)
  IV                                                                             0.8357 (0.0731)
  Economic growth                        −0.100 (−2.91)                          0.0152 (0.0401)                                    −0.1060 (0.0337)
  Industry                               −0.880 (−3.92)                         −0.2277 (0.3024)                                    −0.6294 (0.2143)
  Urban                                  −0.510 (−3.51)                         −0.5105 (0.1699)                                    −0.4679 (0.1564)
  FDI                                    −0.005 (−0.24)                          0.0087 (0.0298)                                    −0.0041 (0.0189)
  Internet                               −0.257 (−4.56)                          0.0570 (0.0417)                                    −0.2323 (0.0546)
  Trade                                    0.099 (4.35)                         −0.1331 (0.0378)                                      0.0919 (0.0202)
  Population                               0.005 (2.14)                         −0.0039 (0.0069)                                     0.0062 (0.0028)
  Country FE                                      ✓                                       ✓                                                   ✓
  Year FE                                         ✓                                       ✓                                                   ✓
  Obs.                                           551                                     551                                                 551
  Cragg-­Donald F                                                                     1212.19
  Kleibergen-­Paap F                                                                   130.68
Note: Robust standard errors displayed in parentheses. Statistical significance is denoted by **p < 0.05, and ***p < 0.01. First Stage: Instrumental variable represents
lagged US AI development weighted by geographic proximity.




constraining the analysis to 2005–2019. The AI coefficient                              lagged LCF term in that specification—points to a stronger (and
retained significance, confirming that AI's sustainability-­                            persistent) effect once dynamics and endogeneity are taken into
enhancing effects preceded pandemic-­    induced disruptions.                           account. Overall, these checks confirm that our baseline infer-
Column (3) concentrated on the post-­2012 era, corresponding                            ence is robust to a range of estimation strategies and to concerns
with deep learning advances (e.g., convolutional neural net-                            about heteroskedasticity, serial and cross-­sectional correlation,
works) that broadened AI applications across autonomous sys-                            endogeneity, and long-­run relationships.
tems and natural language processing domains (WIPO 2019).
Findings indicate that AI development's environmental advan-
tages strengthened as the technology evolved, with sustainabil-                         4.3.4   |   Placebo Test
ity improvements persisting despite widespread adoption.
                                                                                        We implement a validation test to distinguish AI development's
                                                                                        specific environmental impact from general technological ad-
4.3.3   |   Alternative Estimation Techniques                                           vancement. This approach redefines AI in Table 5, Column (4)
                                                                                        using non-­A I patent counts filed by each nation. If broad tech-
To address potential econometric issues and test the stability of                       nological progress (rather than AI-­specific innovations) drove
our findings, we re-­estimate the model using four alternative                          ecological improvements, the AI development coefficient in this
panel techniques: feasible GLS (to correct for heteroskedasticity                       validation test would remain positive. Results reveal a statisti-
and serial correlation), Driscoll–Kraay standard errors (to ac-                         cally significant negative coefficient for the redefined variable,
count for cross-­sectional dependence and temporal correlation),                        suggesting that non-­  A I technologies prove either ineffective
System GMM (to address dynamic-­panel bias and potential en-                            or detrimental for environmental enhancement. This contrast
dogeneity), and FMOLS (to capture long-­run/cointegration rela-                         validates that our primary findings stem not from general tech-
tionships). Prior to applying FMOLS, we confirm the presence                            nological advancement but from AI development's distinctive
of cointegration using the Westerlund (2007) panel cointegra-                           contribution to ecological sustainability.
tion test, which rejects the null hypothesis of no cointegration
(Table A3).
                                                                                        5   |   Underlying Channels
Results are presented in Table 5. The AI technology coefficient
remains positive and statistically significant across these alterna-                    5.1   |   Technological Transformation
tive estimators. In particular, feasible GLS produces an estimate
of 0.012, Driscoll–Kraay yields 0.035, FMOLS gives 0.035, and                           Hypothesis H2 proposes that artificial intelligence advance-
System GMM returns a larger estimate of 0.120. The relatively                           ment promotes ecological sustainability through task-­ based
larger System GMM coefficient—together with the inclusion of a                          and competency-­
                                                                                                       oriented technological transformations. The

10                                                                                                                                         Sustainable Development, 2025
    Sustainable Development, 2025
                                    TABLE 4    |    Robustness verification using alternative operationalizations.

                                                                              Baseline results                               Load capacity factor (ln)                                        Load capacity factor                                    Load capacity factor                                 Load capacity factor
                                     Independent variable                                  (1)                                                     (2)                                                          (3)                                                     (4)                                                  (5)
                                     AI technology                               0.035*** (4.46)                                         0.019*** (5.70)                                             0.048*** (4.52)                                         0.030*** (4.96)                                       0.008*** (4.60)
                                     Economic growth                           −0.100*** (−2.91)                                      −0.090*** (−5.58)                                           −0.100*** (−2.92)                                       −0.115*** (−3.92)                                     −0.101*** (−2.94)
                                     Industry                                  −0.880*** (−3.92)                                      −0.540*** (−5.71)                                            −0.878*** (−3.91)                                      −0.735*** (−4.54)                                     −0.869*** (−3.88)
                                     Urban                                     −0.510*** (−3.51)                                      −0.324*** (−3.96)                                           −0.503*** (−3.46)                                       −0.505*** (−3.76)                                     −0.508*** (−3.51)
                                     FDI                                         −0.005 (−0.24)                                          −0.009 (−0.91)                                              −0.005 (−0.25)                                          −0.000 (−0.00)                                       −0.005 (−0.24)
                                     Internet                                 −0.257*** (−4.56)                                       −0.094*** (−4.60)                                           −0.257*** (−4.56)                                       −0.206*** (−4.92)                                     −0.257*** (−4.55)
                                     Trade                                       0.099*** (4.35)                                         0.055*** (5.68)                                              0.101*** (4.38)                                        0.082*** (4.91)                                       0.098*** (4.34)
                                     Population                                   0.005** (2.14)                                          0.002** (2.33)                                              0.005** (2.16)                                           0.004* (1.85)                                        0.005** (2.09)
                                     Constant                                    2.405*** (7.11)                                        1.811*** (11.06)                                             2.398*** (7.07)                                         2.508*** (8.42)                                       2.415*** (7.15)
                                     Country FE                                             ✓                                                       ✓                                                            ✓                                                       ✓                                                    ✓
                                     Year FE                                                ✓                                                       ✓                                                            ✓                                                       ✓                                                    ✓
                                     Obs.                                                  580                                                     580                                                         580                                                     580                                                   580
                                     R2                                                  0.989                                                   0.993                                                        0.989                                                  0.993                                                 0.989
                                    Note: Robust standard errors presented in parentheses, significance levels: *p < 0.1, **p < 0.05, ***p < 0.01. Column (2): Outcome variable represents log transformed LCF. Columns (3–4): Top and bottom 1% winsorization applied to
                                    LCF (Column 3) and AI development (Column 4) for outlier management. Column (5): AI development redefined as the interaction between R&D expenditure and AI patent counts to capture innovation quality.




    11
10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
    12
                                    TABLE 5    |    Outcomes of validation test and temporal subsamples, and alternative estimation techniques.

                                                                                                                                                            Dependent variable: Load capacity factor
                                                                 Baseline
                                                                  results                   Pre-­COVID                        Post-­A I 2011                        Placebo test                         Feasible GLS                        System-­GMM                           Driscoll-­K raay                             FMOLS
                                     Independent
                                     variable                         (1)                            (2)                                (3)                                   (4)                                  (5)                                  (6)                                    (7)                                   (8)
                                     AI technology               −0.100***                0.039*** (2.71)                      0.012** (2.02)                    −0.001** (−2.06)                         0.012** (2.01)                       0.120** (2.02)                       0.035*** (4.66)                      0.035*** (24.37)
                                                                  (−2.91)
                                     Economic                    −0.880***                −0.076* (−1.73)                    −0.072* (−1.75)                    −0.097*** (−2.83)                            −0.210***                           0.163 (1.51)                    −0.100*** (−6.03)                             −0.101***
                                     growth                       (−3.92)                                                                                                                                     (−8.23)                                                                                                          (−29.27)
                                     Industry                    −0.510***                     −1.401***                      0.945*** (2.88)                   −0.893*** (−3.97)                            −0.461***                         3.624** (2.43)                     −0.880** (−2.52)                            −0.872***
                                                                  (−3.51)                       (−4.96)                                                                                                       (−3.06)                                                                                                          (−41.12)
                                     Urban                    −0.005 (−0.24)                  −0.833***                       −0.430 (−1.62)                    −0.520*** (−3.62)                            −0.591***                          1.902* (1.79)                     −0.510*** (−3.63)                           −0.520***
                                                                                               (−4.78)                                                                                                        (−4.61)                                                                                                          (−28.46)
                                     FDI                         −0.257***                −0.020 (−0.89)                      −0.030 (−1.46)                          0.000 (0.00)                       −0.010 (−1.13)                         0.375* (1.88)                       −0.005 (−0.34)                        −0.003 (−0.91)
                                                                  (−4.56)
                                     Internet                 0.099*** (4.35)                 −0.263***                           −0.215***                     −0.262*** (−4.61)                            −0.076***                        −0.861 (−1.45)                      −0.257*** (−7.98)                           −0.257***
                                                                                               (−3.85)                             (−4.53)                                                                    (−3.40)                                                                                                          (−85.23)
                                     Trade                     0.005** (2.14)             0.089*** (3.40)                       0.002 (0.10)                       0.089*** (4.02)                        0.029** (2.25)                     −0.409* (−1.85)                         0.099*** (6.10)                     0.098*** (39.02)
                                     Population               2.405*** (7.11)                0.002 (0.97)                       0.006 (0.86)                        0.005** (2.22)                       −0.000 (−0.10)                      −0.004 (−0.98)                          0.005** (2.66)                      0.005*** (16.30)
                                     Constant                 2.405*** (7.11)             2.525*** (5.87)                     1.688*** (3.45)                       2.414*** (7.21)                     3.967*** (14.38)                    −2.502** (−2.00)                        2.901*** (10.63)                     2.915*** (78.40)
                                     Country FE                       ✓                               ✓                                  ✓                                     ✓                                    ✓                                    ✓                                      ✓                                     ✓
                                     Year FE                          ✓                               ✓                                  ✓                                     ✓                                    ✓                                    ✓                                      ✓                                     ✓
                                     Obs.                            580                            435                                 377                                  580                                   580                                  551                                   580                                   579
                                     R2                             0.989                          0.991                              0.997                                 0.988                                                                                                            0.989                                 0.970
                                    Note: Robust standard errors in parentheses.
                                    ***p < 0.01.
                                    **p < 0.05.
                                    *p < 0.1.




    Sustainable Development, 2025
10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
                                                                                                                                                          10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
empirical examination of this proposition utilizes the following             in non-­repetitive, cognitive, and service-­oriented tasks. These
econometric specification:                                                   tasks are more likely to be complemented by AI rather than
                                                                             substituted by it, allowing for efficiency gains without increas-
       LCFit = 𝛼 + 𝛽 1 AIit + 𝛽 2 AIit ∗ LSi + Xit + 𝜇 i + 𝜏 t + 𝜀it         ing environmental degradation. This finding supports the task-­
                                                                       (3)   based technological transformation framework, in which the
                                                                             structure of occupational tasks—not just formal skill levels—
where LSi represents the labor structure of nation i throughout              determines how AI interacts with labor to influence environ-
the analysis period. For competency-­    oriented technological              mental outcomes.
transformation assessment, LSi is operationalized by calcu-
lating the average proportion of workers distributed across el-              Taken together, these findings demonstrate that AI's contribu-
ementary, intermediate, and advanced competency categories                   tion to environmental sustainability depends heavily on labor
within each country. Conversely, for task-­based technological               structure. The results provide strong empirical support for
transformation evaluation, it derives from the mean proportion               Hypothesis 2, which posits that the environmental benefits of AI
of employees in non-­repetitive occupational roles. Following                are conditional on the nature of the workforce—both in terms of
Acemoglu and Autor (Acemoglu and Autor 2011), non-­repetitive                skill levels and task complexity. High-­skill, non-­routine labor en-
positions primarily encompass executive, technical, profes-                  vironments are better positioned to integrate AI in ways that im-
sional, and service functions, while repetitive roles incorporate            prove environmental performance, while economies dominated
administrative, clerical, sales, and manufacturing positions.                by routine or low-­skilled labor may experience limited or even ad-
                                                                             verse effects. These insights underscore the need for policies that
To assess the conditional role of labor structure in moderating the          invest in education, skill development, and occupational upgrad-
environmental effects of AI, we examine the interaction between              ing to fully realize the sustainability potential of AI technologies.
AI technology and the composition of labor across skill levels
and task types. Table 6 presents the results, with the dependent
variable being the load capacity factor. The analysis distinguishes          5.2   |   Institutional Frameworks
between two theoretical mechanisms: competency-­oriented and
task-­based technological transformation.                                    Hypothesis H3 proposes that stronger, more adaptable institu-
                                                                             tional frameworks enhance the ability of AI innovations to im-
The first three columns of Table 6 focus on the competency-­                 prove environmental sustainability through better load capacity
oriented dimension by classifying labor into high-­, medium-­,               factor performance. To evaluate this relationship, we estimate
and low-­skilled categories. In Column (1), the interaction term             the following specification:
between AI and the proportion of high-­skilled workers (AI × LS)
is positive and statistically significant, suggesting that AI adop-                LCFit = 𝛼 + 𝛽 1 AIit + 𝛽 2 AIit ∗ INSTi + Xit + 𝜇i + 𝜏 t + 𝜀it
tion leads to improved environmental outcomes in countries                                                                                          (4)
with a higher share of advanced-­competency workers. This
finding indicates that high-­skilled labor complements AI, en-               where LCF represents the Load Capacity Factor—a compre-
abling more efficient and environmentally sustainable use of                 hensive environmental sustainability measure that captures the
technology. The implication is that highly skilled workers are               balance between biocapacity and ecological footprint. Unlike
more capable of adapting to and utilizing AI tools in ways that              traditional CO2 emissions measures, LCF provides a holistic
enhance productivity and reduce ecological pressures.                        view of environmental performance by considering resource
                                                                             consumption relative to regenerative capacity. The institutional
In contrast, Column (2) shows that the interaction between AI                adaptability measure (INSTi) is operationalized along three crit-
and medium-­skilled labor has a negative and significant effect.             ical dimensions:
This suggests that in countries where medium-­skilled workers
dominate, AI may not produce the same environmental improve-                   ○
                                                                                   Legal adaptability (INST1): Drawn from the IMF's AI
ments. This could reflect mismatches between the capabilities of                   Preparedness Index, measuring regulatory agility in evolv-
the workforce and the demands of AI-­based technologies, possibly                  ing alongside AI advances.
leading to displacement effects or inefficient adoption. Similarly,            ○
                                                                                   Labor market efficiency (INST2): Sourced from World
in Column (3), the interaction between AI and low-­skilled labor is
                                                                                   Development Indicators, gauging regulatory capacity to fa-
also negative and statistically significant, with a notably large co-
                                                                                   cilitate efficient workforce transitions during technological
efficient. This indicates that AI may actually worsen environmen-
                                                                                   change.
tal outcomes in economies where low-­skilled labor predominates.
The results collectively confirm that the benefits of AI for environ-          ○
                                                                                   Regulatory quality (INST3): Also, from WDI, indicating
mental sustainability are more likely to be realized in economies                  overall governmental effectiveness in supporting innova-
characterized by a highly skilled workforce, consistent with the                   tion ecosystems.
competency-­oriented technological transformation hypothesis.
                                                                             Table 7 provides compelling evidence that institutional adapt-
Column (4) shifts the focus to the task-­based perspective by ex-            ability is a critical moderator in the relationship between AI and
amining the interaction between AI and the share of workers                  ecological sustainability. The results show that in countries with
in non-­routine occupations. Here, the AI × LS interaction term              more adaptable legal frameworks, the ecological benefits of AI
is positive and significant, indicating that AI has stronger envi-           are significantly amplified. This is demonstrated by the posi-
ronmental benefits in countries where the workforce is engaged               tive and highly statistically significant interaction coefficient

Sustainable Development, 2025                                                                                                                       13
                                                                                                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 6    |    The conditioning effects of task-­based and competency-­oriented technological transformation.

                                                                          Dependent variable: Load capacity factor
                                            High-­skill                     Medium-­skill                            Low-­skill       Non-­routine tasks
  Explained variable                              (1)                               (2)                                  (3)                    (4)
  AI technology                         −7.877*** (−7.66)                    5.881*** (3.72)                    5.260*** (8.66)        −8.824*** (−6.10)
  LS                                      −0.125 (−0.45)                     −0.373 (−1.30)                     2.952*** (3.52)          −0.201 (−0.71)
  AI technology × LS                     16.642*** (7.52)                 −13.510*** (−3.83)                 −61.515*** (−8.84)          13.523*** (6.00)
  Economic growth                       −0.319*** (−4.36)                  −0.284*** (−3.78)                  −0.267*** (−3.41)         −0.260*** (−3.71)
  Industry                                  0.245 (0.79)                    −0.081 (−0.26)                           0.182 (0.53)        −0.252 (−0.75)
  Urban                                   1.919*** (6.30)                    1.779*** (5.56)                    2.080*** (7.18)          1.644*** (4.99)
  FDI                                       0.132 (0.77)                       0.073 (0.40)                     0.421** (2.26)             0.171 (0.89)
  Internet                                  0.017 (0.07)                    −0.014 (−0.06)                      −0.095 (−0.42)           −0.056 (−0.25)
  Trade                                 −0.547*** (−9.89)                 −0.460*** (−8.36)                  −0.583*** (−11.64)         −0.497*** (−9.76)
  Population                              2.995*** (5.18)                   2.900*** (4.88)                     2.062*** (2.85)          2.791*** (4.87)
  Constant                                        ✓                                  ✓                                    ✓                      ✓
  Country YE                                      ✓                                  ✓                                    ✓                      ✓
  Obs.                                           580                                580                                  580                    580
  R2                                            0.385                              0.336                                0.444                  0.353
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as **p < 0.05, ***p < 0.01.




for legal adaptability (AI × INST1), which suggests that flexible                         6   |   Further Analysis
regulatory environments allow AI technologies to be deployed
more effectively for ecological optimization, thereby improv-                             6.1   |   Spatial Spillover Effects
ing the load capacity factor. The strongest moderating effect is
observed in the context of labor market efficiency. The interac-                          The environmental consequences of AI demonstrate significant
tion term (AI × INST 2) yields a substantial positive coefficient of                      geographic heterogeneity across different regions worldwide. To
10.315 with high statistical significance, indicating that efficient                      investigate potential spatial knowledge transfer effects emanat-
labor markets dramatically enhance AI's capacity to improve                               ing from the global leader in AI innovation, a comprehensive
ecological performance. This powerful synergy likely arises                               spatial analysis was conducted examining proximity relation-
from smoother workforce transitions into green technology sec-                            ships to the United States, which serves as the world's dominant
tors and reduced societal resistance to AI-­enabled environmen-                           hub for artificial intelligence patent production. The analytical
tal innovations. While the interaction with general regulatory                            framework divided countries into two distinct geographical
quality (AI × INST3) is also positive and significant at 0.734, its                       classifications: nations positioned relatively close to the USA
smaller magnitude suggests its moderating effect is more mod-                             (characterized by distances falling below the sample mean) and
est compared to the other two dimensions.                                                 those located at greater distances (with distances surpassing the
                                                                                          sample average). The comparative analysis in Table 8 reveals
The consistently positive and significant interaction terms                               striking disparities in environmental impacts between these
across all three models offer strong empirical support for                                two geographic clusters. Countries situated in closer proximity
Hypothesis H3, revealing a clear hierarchy of influence. Labor                            to the United States demonstrate statistically significant im-
market efficiency emerges as the most critical institutional                              provement associated with artificial intelligence activities. This
amplifier, followed by legal adaptability and then overall reg-                           finding suggests the presence of robust geographic knowledge
ulatory quality. This underscores a crucial complementarity:                              transfer mechanisms, whereby environmental benefits from AI
AI technologies and strong institutions are not substitutes but                           diffuse more effectively across shorter geographic distances. The
partners in achieving environmental goals. Countries cannot                               positive coefficient indicates that increased AI activity in these
rely on technology alone without corresponding institutional                              proximate nations corresponds to measurable improvements in
development. Therefore, the findings carry significant policy                             environmental performance, potentially through enhanced ac-
implications, suggesting that nations seeking to leverage AI                              cess to clean technology innovations, improved knowledge shar-
for ecological sustainability should prioritize institutional re-                         ing networks, and more efficient technology transfer processes.
forms—particularly those promoting labor market flexibility
and regulatory adaptability—as a core component of their                                  In stark contrast, nations positioned at greater distances from
strategy.                                                                                 the United States exhibit no statistically significant relationship


14                                                                                                                                  Sustainable Development, 2025
                                                                                                                                                                10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 7    |    The moderating role of institutional frameworks.

                                                                              Dependent variable: Load capacity factor
                                                          AI ∗ INST1                                      AI ∗ INST2                    AI ∗ INST3

  Explained variable                                            (1)                                            (2)                          (3)
  AI technology                                       −9.316*** (−5.56)                                15.430*** (9.19)             −1.197*** (−3.37)
  AI × INSTi                                            5.458*** (5.46)                                10.315*** (9.29)               0.734*** (3.04)
  Economic growth                                     −0.216*** (−2.76)                               −0.195** (−2.50)               −0.173** (−2.25)
  Industry                                              −0.383 (−0.96)                                 −0.577 (−1.50)                −0.821* (−1.94)
  Urban                                                 1.803*** (5.56)                                1.678*** (5.28)                1.733*** (5.34)
  FDI                                                     0.208 (1.03)                                    0.167 (0.81)                  0.134 (0.71)
  Internet                                              −0.205 (−0.92)                                 −0.306 (−1.31)                 −0.078 (−0.34)
  Trade                                               −0.438*** (−7.35)                              −0.422*** (−7.61)              −0.365*** (−6.64)
  Population                                            −0.002 (−1.01)                                 −0.003* (−1.75)              −0.006*** (−3.40)
  Constant                                              2.268*** (3.02)                                2.287*** (4.38)                1.846*** (3.17)
  Country FE                                                    ✓                                               ✓                            ✓
  Country YE                                                    ✓                                               ✓                            ✓
  Obs.                                                         580                                             580                          580
  R2                                                          0.320                                          0.346                         0.316
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as *p < 0.1, **p < 0.05, ***p < 0.01.




between artificial intelligence patenting and environmental                               mean) and low-­income groups (below sample mean) to investi-
outcomes. This absence of correlation suggests that geographic                            gate these differences.
distance may serve as a fundamental barrier to the effective dis-
semination of AI-­driven environmental solutions. The lack of                             The analysis presented in Table 9 demonstrates AI's statistically
environmental benefits in distant countries could reflect several                         significant effect in enhancing the Load Capacity Factor across
constraining factors, including limited access to cutting-­edge                           countries in both income categories. Notably, AI shows positive
technological knowledge, weaker institutional connections with                            coefficients in both high-­and low-­income groups, confirming
leading AI research centers, reduced participation in interna-                            AI's beneficial contribution to environmental sustainability re-
tional technology transfer networks, and potential delays in                              gardless of economic development level. However, the absolute
the adoption and implementation of environmentally beneficial                             magnitude of the estimated AI effect is considerably more sub-
AI innovations. These findings illuminate the spatially uneven                            stantial in low-­income economies, indicating a more pronounced
distribution of environmental benefits derived from artificial                            environmental improvement effect in these regions. This finding
intelligence innovations, highlighting the critical importance of                         suggests that AI offers particularly valuable and adaptable tech-
geographic proximity in determining access to clean technology                            nological support for environmental sustainability initiatives in
solutions. The results suggest that distance-­based disparities in                        low-­income countries, which typically have fewer alternative
environmental outcomes may exacerbate existing inequalities                               technological resources at their disposal. Consequently, AI im-
in global climate mitigation efforts, potentially concentrating                           plementation yields more pronounced environmental sustain-
environmental improvements in regions already advantaged by                               ability benefits in these economies, potentially helping to bridge
proximity to major innovation centers while leaving more dis-                             the technological gap in LCF enhancement capabilities. The
tant nations without access to these beneficial technologies.                             results indicate that artificial intelligence policies may serve as
                                                                                          an especially effective tool for improving environmental perfor-
                                                                                          mance in developing nations, where the marginal impact of such
6.2   |   Heterogeneity of Different Income Levels                                        technological interventions tends to be greater due to lower base-
                                                                                          line technological adoption and infrastructure development.
Environmental sustainability approaches to enhancing the LCF
vary considerably across different income levels. While high-­
income countries typically possess greater technological re-                              6.3   |   Heterogeneity of Energy Utilization Pattern
sources for improving environmental performance, our analysis
reveals interesting patterns in how AI contributes to environ-                            Dependence on fossil fuels typically drives excessive ecological
mental sustainability across economic divides. We categorized                             degradation compared to reliance on renewables, as reflected
countries into high-­income (per capita income above sample                               in lower load capacity factor values. We therefore investigate

Sustainable Development, 2025                                                                                                                             15
                                                                                                                                                                        10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 8    |    Spatial spillover effect.

                                                                                Dependent variable: Load capacity factor
                                                               Countries closer to the US                                      Countries far from the US
  Explained variable                                                            (1)                                                       (2)
  AI technology                                                         0.045*** (4.07)                                              −0.045 (−1.60)
  Economic growth                                                       −0.093* (−1.69)                                            −0.268*** (−5.95)
  Industry                                                              −0.547 (−1.38)                                               −0.077 (−0.27)
  Urban                                                               −1.663*** (−6.29)                                              0.718*** (3.00)
  FDI                                                                   0.072*** (2.71)                                              0.256** (2.32)
  Internet                                                            −0.381*** (−3.87)                                            −0.136*** (−3.54)
  Trade                                                                  0.087** (2.43)                                               0.021 (0.70)
  Population                                                            0.361*** (4.31)                                              0.005** (2.04)
  Constant                                                              2.879*** (4.41)                                              2.783*** (6.07)
  Country FE                                                                     ✓                                                         ✓
  Year FE                                                                        ✓                                                         ✓
  Obs.                                                                         400                                                        180
  R2                                                                          0.988                                                      0.996
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as *p < 0.1, **p < 0.05, ***p < 0.01.




whether countries with greater traditional-­energy dependence                             proportions of total AI activity during our sample period. Energy
experience stronger LCF improvements from AI. Based on World                              management AI constitutes approximately 1.24% of total AI, while
Development Indicators data detailing countries' renewable en-                            industry and manufacturing applications represent 14.30%, and
ergy share of total final consumption, the dataset was separated                          planning and scheduling functions account for 10.09%.
with the average renewable energy share serving as the division
threshold. The high fossil-­fuel reliant economies group comprises                        Table 11 depicts our regression analysis inspecting the environ-
countries where the renewable energy ratio falls below the aver-                          mental impact of different types of AI applications through their
age, pointing to higher dependence on traditional energy sources.                         effect on LCF. All three AI categories demonstrate statistically
The low fossil-­fuel reliant economies are defined by all obser-                          significant associations with improved LCF values, suggesting
vations where the renewable energy ratio is over the average.                             their role in enhancing environmental sustainability. However,
Table 10 presents the estimated effect of AI activity on LCF for                          the magnitude of the impact varies markedly across categories. AI
each group. In the high-­dependence cluster (Column 1), AI ac-                            specifically focused on energy management (Column 3) exhibits
tivity increases LCF significantly, indicating improved ecological                        the strongest environmental benefit with a coefficient magnitude
sustainability. However, for the low-­dependence group (Column                            substantially larger than those for industry and manufacturing
2), the coefficient on AI is negative but statistically insignificant.                    applications (Column 2) or planning and scheduling functions
These results suggest that AI-­driven technological advances yield                        (Column 1). These findings highlight that while all examined
greater environmental sustainability gains in countries heavily                           categories of AI contribute to LCF improvements, AI directly ap-
reliant on traditional energy infrastructure. By enhancing the                            plied to energy management demonstrates the most pronounced
intelligence of existing fossil-­fuel systems—such as through AI-­                        environmental sustainability benefits. This suggests that targeted
enabled smart grids that can cut power costs by 10%–20%—AI                                development of AI solutions specifically optimized for energy sys-
tools unlock environmental improvement potential where it is                              tems could offer particularly promising pathways for addressing
most needed, as evidenced by higher LCF values in these econo-                            climate challenges, despite currently representing the smallest
mies (Ahmad et al. 2021; Chen et al. 2023).                                               proportion of AI activity among the three categories examined.


6.4   |   Heterogeneity in Different Types of AI                                          7   |   Conclusions, Policy Implications, Limitations,
                                                                                          and Future Research Directions
To explore how different categories of AI impact ecological sus-
tainability through LCF, we used WIPO classification standards                            7.1   |   Conclusions
by collecting data on AI applications across three key subcatego-
ries: AI applied to planning and scheduling functions (AI1), in-                          The ubiquitous proliferation of artificial intelligence technolo-
dustry and manufacturing (AI2), and energy management (AI3).                              gies across contemporary global economic systems necessitates
As illustrated in Figure 4, these specialized AI represent varying                        a comprehensive empirical examination of their environmental

16                                                                                                                                      Sustainable Development, 2025
                                                                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 9    |    Heterogeneous effects of AI on LCF by different income levels.

                                                                                   Dependent variable: Load capacity factor
                                                                         High-­income group                                       Low-­income group
  Explained variable                                                                 (1)                                                     (2)
  AI                                                                          0.024*** (3.39)                                          0.815 (1.26)
  Economic growth                                                          −0.258*** (−3.53)                                         0.400*** (2.62)
  Industry                                                                   −0.373* (−1.79)                                        −3.548*** (−3.59)
  Urban                                                                     −0.518** (−2.37)                                          1.189* (1.95)
  FDI                                                                        −0.000 (−0.02)                                          −0.294 (−0.72)
  Internet                                                                 −0.165*** (−4.01)                                        −0.642*** (−3.61)
  Trade                                                                          0.061* (1.91)                                       0.271*** (3.32)
  Population                                                                     0.016 (1.47)                                         0.019** (2.47)
  Constant                                                                     3.976*** (4.83)                                      −3.273** (−1.99)
  Country FE                                                                          ✓                                                       ✓
  Year FE                                                                             ✓                                                       ✓
  Obs.                                                                               367                                                     197
  R2                                                                                0.991                                                   0.990
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as **p < 0.05, ***p < 0.01.




TABLE 10    |    Heterogeneous effects of AI on LCF by pattern of energy utilization.

                                                                             Dependent variable: Load capacity factor
                                                   High fossil-­f uel reliant economies                                Low fossil-­f uel reliant economies
  Explained variable                                                       (1)                                                         (2)
  AI technology                                                    0.034*** (6.67)                                               −0.043 (−0.32)
  Economic growth                                                −0.246*** (−9.80)                                                0.270** (2.59)
  Industry                                                       −0.836*** (−5.37)                                              −3.407*** (−4.04)
  Urban                                                            −0.075 (−0.47)                                               −5.256*** (−6.23)
  FDI                                                                0.021 (0.82)                                                −0.010 (−0.24)
  Internet                                                       −0.094*** (−3.60)                                              −0.893*** (−6.27)
  Trade                                                            0.059*** (3.80)                                                 0.008 (0.10)
  Population                                                       0.004*** (2.82)                                               0.574*** (4.73)
  Constant                                                        3.381*** (11.90)                                               2.460** (2.44)
  Country FE                                                               ✓                                                            ✓
  Year FE                                                                  ✓                                                            ✓
  Obs.                                                                    360                                                          197
  R2                                                                     0.993                                                        0.993
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as *p < 0.1, **p < 0.05, ***p < 0.01.



ramifications, particularly with respect to ecological sustain-                            in artificial intelligence capabilities. Our econometric analy-
ability paradigms. This investigation employed a longitudinal                              sis demonstrates a statistically robust and consistent empiri-
panel dataset encompassing 29 countries over the temporal                                  cal relationship wherein elevated levels of AI are significantly
span of 2005–2024, utilizing AI patent filing frequencies as a                             correlated with enhanced environmental sustainability. The
quantitative proxy for national technological advancement                                  documented association exhibits remarkable resilience across

Sustainable Development, 2025                                                                                                                                17
                                                                                                                                                                10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 4    |    Percentages of AI patents by application type.


TABLE 11    |    Effect of three AI categories on LCF.

                                                                           Dependent variable: Load capacity factor
                                                           AI1                                              AI2                           AI3
                                                           (1)                                              (2)                           (3)
  AI1                                               0.090*** (5.72)
  AI2                                                                                                0.074*** (5.58)
  AI3                                                                                                                              0.495*** (5.86)
  Economic growth                                 −0.097*** (−2.79)                                −0.097*** (−2.79)              −0.100*** (−2.88)
  Industry                                       −0.909*** (−4.01)                                −0.908*** (−4.01)               −0.889*** (−3.93)
  Urban                                           −0.519*** (−3.58)                                −0.514*** (−3.55)              −0.520*** (−3.60)
  FDI                                              −0.005 (−0.29)                                   −0.006 (−0.29)                 −0.005 (−0.26)
  Internet                                        −0.255*** (−4.52)                               −0.254*** (−4.52)               −0.255*** (−4.52)
  Trade                                             0.097*** (4.33)                                  0.098*** (4.36)               0.097*** (4.31)
  Population                                        0.005** (2.13)                                   0.005** (2.15)                 0.005** (2.12)
  Constant                                          2.388*** (7.04)                                  2.382*** (7.01)                2.416*** (7.14)
  Country FE                                                ✓                                                ✓                             ✓
  Year FE                                                   ✓                                                ✓                             ✓
  Obs.                                                     580                                              580                           580
  R2                                                      0.989                                            0.989                         0.989
Note: Robust S.E. errors are reported in parentheses, with significance levels denoted as **p < 0.05, ***p < 0.01.


multiple analytical specifications, maintaining statistical sig-                         outcomes. Primarily, AI functions as a driver of technological
nificance when controlling for potential endogeneity concerns                            transformation, specifically inducing routine-­biased and skill-­
through instrumental variable approaches and demonstrating                               biased technological change within labor market structures.
consistency across various robustness checks and sensitivity                             The beneficial environmental externalities of AI are particularly
analyses. The findings suggest that AI technological advance-                            pronounced in economies characterized by concentrated high-­
ment serves as a catalyst for environmental improvement, with                            skilled employment and prevalent non-­routine occupational ac-
effect sizes that are both economically meaningful and statisti-                         tivities, suggesting that these labor market configurations serve
cally significant at conventional confidence levels. Our mech-                           as facilitating mechanisms that amplify the sustainability div-
anistic analysis elucidates several key transmission channels                            idends from AI adoption and deployment. Furthermore, insti-
through which AI contributes to environmental sustainability                             tutional flexibility emerges as a critical moderating factor, with

18                                                                                                                              Sustainable Development, 2025
                                                                                                                                             10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
more adaptable institutional frameworks correlating with stron-       to promote equitable participation in the sustainable economy.
ger positive impacts of AI on environmental outcomes. This            Regulatory frameworks must evolve to balance innovation
finding implies that reduced transaction costs associated with        promotion with environmental protection imperatives. This
AI innovation diffusion and implementation serve to magnify           requires embedding sustainability criteria into AI governance
the technology's sustainability benefits through enhanced alloc-      structures, developing adaptive regulatory approaches that re-
ative efficiency and reduced regulatory friction. Heterogeneity       spond to technological evolution, and establishing outcomes-­
analysis reveals significant variation in AI's environmental im-      based policy frameworks that incentivize environmental
pact across different geographical, economic, and technological       performance while maintaining innovation flexibility.
contexts. Countries positioned in closer geographical proximity
to leading AI innovator nations demonstrate more substantial
improvements in environmental sustainability metrics, likely          7.3   |   Limitations and Future Research Directions
attributable to knowledge spillover effects and technological
diffusion mechanisms. Additionally, the positive environmen-          This investigation is subject to several methodological and con-
tal influence of AI exhibits greater magnitude in lower-­income       ceptual limitations that circumscribe the generalizability and
economies and those characterized by high dependence on               causal interpretation of our findings. The measurement of “AI
conventional fossil fuel energy sources, highlighting AI's po-        capability” presents a fundamental challenge, as reliance on ag-
tential as a transitional instrument toward cleaner economic          gregate patent counts may inadequately capture the multidimen-
structures in specific developmental contexts. Notably, AI ap-        sional nature of innovation quality, overlooking non-­patented
plications specifically engineered for energy management sys-         technological advances, proprietary innovations, and regional
tems demonstrate particularly potent effects on environmental         variations in patenting behavior. This measurement limitation
sustainability enhancement, suggesting that targeted techno-          potentially introduces systematic bias in our estimates and may
logical development in this domain may yield disproportionate         not fully reflect the true distribution of AI technological capabil-
environmental returns. Collectively, these empirical findings         ity across countries. The utilization of macro-­level country data
provide compelling evidence that AI assumes a crucial and ac-         obscures significant heterogeneity at sub-­national, sectoral, and
celerating role in advancing global environmental sustainability      firm levels, preventing detailed analysis of specific AI applica-
objectives, offering valuable insights for strategic policymaking     tions, sectoral transformation patterns, or potential rebound
and stakeholder engagement.                                           effects that may offset environmental gains. This aggregation
                                                                      bias implies that our results indicate correlation rather than es-
                                                                      tablishing definitive causal relationships, limiting the precision
7.2   |   Policy Implications and Recommendations                     of policy prescriptions derived from our findings. Moreover, the
                                                                      treatment of “AI” as a homogeneous technological entity over-
The empirical findings of this study generate several critical        looks the diverse environmental impacts of different AI tech-
policy implications for optimizing AI's contribution to environ-      nologies and applications, which can range from substantial
mental sustainability. Governments should prioritize targeted         efficiency gains to increased energy consumption for compu-
research and development investments in AI applications spe-          tationally intensive machine learning tasks. This technological
cifically designed to ameliorate environmental challenges, en-        heterogeneity represents a significant limitation in understand-
suring strategic alignment between national AI development            ing the nuanced environmental implications of AI deployment
strategies and sustainability objectives while establishing ded-      across different contexts and applications. Acknowledging these
icated funding mechanisms for green AI initiatives and envi-          methodological constraints, future research should pursue sev-
ronmental technology innovation. International cooperation            eral strategic directions to enhance understanding of the AI-­
mechanisms require substantial strengthening to maximize              environment nexus. Micro-­level empirical analyses at the firm,
AI's global environmental benefits. Building upon existing mul-       household, or regional scale are essential to establish more di-
tilateral frameworks, nations should establish comprehensive          rect causal linkages between AI adoption and environmental
knowledge-­  sharing platforms for sustainable AI deployment          outcomes using granular data sources and quasi-­experimental
practices, foster strategic partnerships that facilitate AI bene-     identification strategies. Developing enhanced metrics for AI
fit diffusion to developing economies, and create institutional       innovation that transcend simple patent counts represents a
mechanisms for coordinated policy responses to AI–environ-            critical methodological advancement. This includes creating
ment nexus challenges. Infrastructure development represents          citation-­
                                                                               weighted indices, composite measures incorporating
another critical policy domain, requiring substantial public          multiple innovation indicators, and qualitative assessments of
investment in digital infrastructure specifically tailored for cli-   technological impact that provide more accurate representations
mate and environmental applications. This includes establishing       of technological advancement and diffusion. Sector-­specific and
comprehensive public data repositories, computational resource        region-­specific investigations are essential given the significant
networks, and interoperable platforms that enable AI deploy-          variation in AI's environmental impacts across different con-
ment across multiple environmental sectors and applications.          texts and applications. These studies should employ detailed
Human capital development necessitates comprehensive adap-            sectoral data to identify optimal deployment strategies and tai-
tation of educational and training systems to cultivate expertise     lor policy interventions to specific economic and technological
in both AI technologies and environmental applications. This          contexts. Finally, exploring the dynamic and potentially nonlin-
involves developing interdisciplinary curricula that integrate AI     ear relationship between AI and environmental outcomes over
competencies with environmental science, establishing profes-         extended temporal periods, using advanced econometric mod-
sional development programs for workforce transitions, and en-        eling techniques such as threshold models, regime-­switching
suring inclusive access to green technology skills development        approaches, and machine learning methods, will contribute to a

Sustainable Development, 2025                                                                                                         19
                                                                                                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
more nuanced understanding of AI's long-­term role in achieving                Al-­
                                                                                  Jafari, M. K., and H. H. A. Altaee. 2023. “The Role of Labor
environmental sustainability objectives. This comprehensive re-                Productivity in Reducing Carbon Emission Utilizing the Method
search agenda is necessary to inform evidence-­based strategies                of Moments Quantile Regression: Evidence From Top 40 Emitter
                                                                               Countries.” International Journal of Economics and Finance 15, no. 3: 1.
for leveraging AI technologies in pursuit of global environmen-
                                                                               https://​doi.​org/​10.​5539/​ijef.​v15n3p1.
tal sustainability goals while addressing the methodological and
conceptual challenges inherent in studying this rapidly evolving               Autor, D. H., F. Levy, and R. J. Murnane. 2003. “The Skill Content of
                                                                               Recent Technological Change: An Empirical Exploration.” Quarterly
technological domain.
                                                                               Journal of Economics 118, no. 4: 1279–1333. https://​doi.​org/​10.​1162/​
                                                                               00335​53033​22552801.
                                                                               Bainomugisha, E., P. A. Warigo, F. B. Daka, A. Nshimye, M. Birungi,
Endnotes                                                                       and D. Okure. 2024. “AI-­Driven Environmental Sensor Networks and
1 To determine Earth Overshoot Day, the yearly ecological capacity of          Digital Platforms for Urban Air Pollution Monitoring and Modelling.”
 the planet—representing the amount of natural resources Earth can             Societal Impacts 3: 100044. https://​doi.​org/​10.​1016/j.​socimp.​2 024.​
 renew in 1 year—is divided by the total ecological demand of humanity         100044.
 for that year. The resulting fraction is then multiplied by 365 to identify   Bergougui, B. 2024. “Investigating the Relationships Among Green
 the exact day on the calendar when human use of resources exceeds             Technologies, Financial Development and Ecological Footprint
 what nature can regenerate annually.                                          Levels in Algeria: Evidence From a Novel Fourier ARDL Approach.”
2 See Global Footprint Network, “Earth Overshoot Day”.                         Sustainable Cities and Society 112: 105621. https://​doi.​org/​10.​1016/j.​scs.​
                                                                               2024.​105621.
3 The artificial intelligence industry draws parallels to the petroleum
                                                                               Bergougui, B. 2025a. “Can Artificial Intelligence Mitigate
 sector: similar to oil extraction and refinement, data processing can
                                                                               Environmental Inequality? Evidence From Leading Robotic-­           Driven
 yield substantial economic returns once transformed into valuable
                                                                               Economies Using Quantile-­           Based Methods.” Borsa Istanbul Review.
 insights. However, like fossil fuel operations, the deep-­learning com-
                                                                               https://​doi.​org/​10.​1016/j.​bir.​2 025.​07.​012.
 putational process generates significant environmental consequences.
 A comprehensive life-­cycle assessment conducted by University of             Bergougui, B. 2025b. “Circular Pathways to Sustainability: Asymmetric
 Massachusetts Amherst researchers revealed that training multiple             Impacts of the Circular Economy on the EU'S Capacity Load Factor.”
 standard large-­scale AI models produces over 626,000 pounds of CO2           Land 14, no. 6: 1216. https://​doi.​org/​10.​3390/​land1​4 061216.
 equivalent emissions—approximately five times the total lifetime car-
 bon footprint of a typical American automobile, including manufac-            Bergougui, B. 2025c. “Industrial Robots for a Sustainable Future:
 turing processes.                                                             Uncovering the Asymmetric Effects of AI on Ecological Quality in G7
                                                                               Economies.” Technology in Society 83: 103021. https://​doi.​org/​10.​1016/j.​
                                                                               techs​oc.​2 025.​103021.
References                                                                     Bergougui, B. 2025d. “Institutional Adaptability, Skill-­                   Bias
Abbasiharofteh, M., T. Broekel, and L. Mewes. 2024. “The Role                  Technological Shifts, and Energy Efficiency in Global Decarbonization
of Geographic Distance and Technological Complexity in U.S.                    Pathways: Exploring the Role of Artificial Intelligence Patents.”
Interregional co-­Patenting Over Almost Two Centuries.” Environment            Technology in Society 83: 103029. https://​doi.​org/​10.​1016/j.​techs​oc.​2 025.​
and Planning A 56, no. 7: 2003–2022. https://​doi.​org/​10.​1177/​03085​       103029.
18X24​1255525.                                                                 Bergougui, B., and M. I. Aldawsari. 2024. “Asymmetric Impact of
Acemoglu, D. 2002. “Technical Change, Inequality, and the Labor                Patents on Green Technologies on Algeria's Ecological Future.” Journal
Market.” Journal of Economic Literature 40, no. 1: 7–72. https://​doi.​org/​   of Environmental Management 355: 120426. https://​doi.​org/​10.​1016/j.​
10.​1257/​0 0220​51026976.                                                     jenvm​an.​2 024.​120426.
                                                                               Bergougui, B., S. Mehibel, and R. H. Boudjana. 2024. “Asymmetric
Acemoglu, D., and D. Autor. 2011. “Skills, Tasks and Technologies:
                                                                               Nexus Between Green Technologies, Economic Policy Uncertainty,
Implications for Employment and Earnings.” In Handbook of Labor
                                                                               and Environmental Sustainability: Evidence From Algeria.” Journal
Economics, vol. 4, 1043–1171. Elsevier. https://​doi.​org/​10.​1016/​S 0169​
                                                                               of Environmental Management 360: 121172. https://​doi.​org/​10.​1016/j.​
-­​7218(11)​02410​-­​5.
                                                                               jenvm​an.​2 024.​121172.
Acemoglu, D., D. Autor, J. Hazell, and P. Restrepo. 2022. “Artificial
                                                                               Bergougui, B., and S. Meziane. 2025. “Assessing the Impact of Green
Intelligence and Jobs: Evidence From Online Vacancies.” Journal of
                                                                               Energy Transition, Technological Innovation, and Natural Resources
Labor Economics 40, no. S1: S293–S340. https://​doi.​org/​10.​1086/​718327.
                                                                               on Load Capacity Factor in Algeria: Evidence From Dynamic
Acemoglu, D., and P. Restrepo. 2018. “The Race Between Man and                 Autoregressive Distributed Lag Simulations and Machine Learning
Machine: Implications of Technology for Growth, Factor Shares, and             Validation.” Sustainability 17, no. 5: 1815. https://​doi.​org/​10.​3390/​su170​
Employment.” American Economic Review 108, no. 6: 1488–1542.                   51815​.
https://​doi.​org/​10.​1257/​aer.​2 0160696.
                                                                               Bergougui, B., and S. M. Murshed. 2025. “Heterogeneous Spillover
Acemoglu, D., and J. A. Robinson. 2013. Why Nations Fail: The Origins          Effects: How FDI in Resources Extraction, Manufacturing, and Services
of Power, Prosperity, and Poverty. Crown Currency.                             Affect Sectoral Carbon Emissions in the MENA Region.” In Natural
                                                                               Resources Forum.
Aghion, P., and P. Howitt. 1990. A Model of Growth Through Creative
Destruction. Vol. 60. National Bureau of Economic Research                     Çakmak, E. E., and S. Acar. 2022. “The Nexus Between Economic
Cambridge.                                                                     Growth, Renewable Energy and Ecological Footprint: An Empirical
                                                                               Evidence From Most Oil-­   Producing Countries.” Journal of Cleaner
Ahmad, T., D. Zhang, C. Huang, et al. 2021. “Artificial Intelligence
                                                                               Production 352: 131548. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 022.​131548.
in Sustainable Energy Industry: Status Quo, Challenges and
Opportunities.” Journal of Cleaner Production 289: 125834. https://​doi.​      Carrillo, M. R. 2020. “Artificial Intelligence: From Ethics to Law.”
org/​10.​1016/j.​jclep​ro.​2 021.​125834.                                      Telecommunications Policy 44, no. 6: 101937.
Ahmad, T., H. Zhu, D. Zhang, et al. 2022. “Energetics Systems and              Chen, L., Z. Chen, Y. Zhang, et al. 2023. “Artificial Intelligence-­Based
Artificial Intelligence: Applications of Industry 4.0.” Energy Reports 8:      Solutions for Climate Change: A Review.” Environmental Chemistry
334–361. https://​doi.​org/​10.​1016/j.​egyr.​2 021.​11.​256.                  Letters 21, no. 5: 2525–2557.


20                                                                                                                              Sustainable Development, 2025
                                                                                                                                                                       10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Cowls, J., A. Tsamados, M. Taddeo, and L. Floridi. 2021. “A Definition,             Machin, S. 2008. “An Appraisal of Economic Research on Changes in
Benchmark and Database of AI for Social Good Initiatives.” Nature                   Wage Inequality.” Labour 22, no. SUPPL. 1: 7–26. https://​doi.​org/​10.​
Machine Intelligence 3, no. 2: 111–115. https://​doi.​org/​10.​1038/​s 4225​6 -­​   1111/j.​1467-­​9914.​2 008.​0 0421.​x.
021- ­​0 0296​- ­​0.
                                                                                    Miller, T. 2019. “Explanation in Artificial Intelligence: Insights From
Dileep, G. 2020. “A Survey on Smart Grid Technologies and                           the Social Sciences.” Artificial Intelligence 267: 1–38. https://​doi.​org/​10.​
Applications.” Renewable Energy 146: 2589–2625. https://​doi.​org/​10.​             1016/j.​artint.​2 018.​07.​0 07.
1016/j.​renene.​2 019.​08.​0 92.
                                                                                    Nazir, M., M. Q. Rasheed, X. H. Yu, and Z. Ahmed. 2025. “Can
Doğan, B., S. Tiwari, B. Bergougui, S. Ghosh, and D. Balsalobre-­                   Computer Technology, Semiconductors, and Artificial Intelligence
Lorente. 2025. “Green Innovation and Fiscal Spending: Decoding the                  Shape a Sustainable Future? Evidence From Leading Semiconductor-­
Path to Sustainable Development.” Sustainable Development 33, no. 4:                Producing Countries.” Sustainable Development 33, no. 4: 5214–5233.
6307–6327. https://​doi.​org/​10.​1002/​sd.​3 464.                                  https://​doi.​org/​10.​1002/​sd.​3394.
Francisco, M. 2023. “Artificial Intelligence for Environmental Security:            North, D. C. 1990. Institutions, Institutional Change and Economic
National, International, Human and Ecological Perspectives.” Current                Performance. Cambridge University.
Opinion in Environmental Sustainability 61: 101250. https://​doi.​org/​10.​
1016/j.​cosust.​2 022.​101250.                                                      Olson, M. 1993. “Dictatorship, Democracy, and Development.”
                                                                                    American Political Science Review 87: 567–576.
Ganguli, I., J. Lin, and N. Reynolds. 2020. “The Paper Trail of Knowledge
Spillovers: Evidence From Patent Interferences.” American Economic                  Omar, M. A., and M. Hasanujzaman. 2025. “Do Ethnically Diverse
Journal: Applied Economics 12, no. 2: 278–302. https://​doi.​org/​10.​1257/​        Societies Amplify the Ecological Footprint? Exploring the Mediating
app.​2 0180017.                                                                     Role of Human Development.” Journal of Environmental Management
                                                                                    386: 125802. https://​doi.​org/​10.​1016/j.​jenvm​an.​2 025.​125802.
Godil, D. I., Y. Zhang, A. Sharif, R. Usman, and S. A. R. Khan. 2021.
“Investigate the Role of Technology Innovation and Renewable Energy                 Petrosillo, I., E. M. Lovello, C. Drago, C. Magazzino, and D. Valente.
in Reducing Transport Sector CO2 Emission in China: A Path Toward                   2024. “Global Environmental Sustainability Trends: A Temporal
Sustainable Development.” Sustainable Development 29, no. 4: 694–707.               Comparison Using a New Interval-­        Based Composite Indicator.”
https://​doi.​org/​10.​1002/​sd.​2167.                                              Environmental and Sustainability Indicators 24: 100482. https://​doi.​org/​
                                                                                    10.​1016/j.​indic.​2 024.​100482.
Hao, K. 2019. “Training a Single AI Model Can Emit as Much Carbon as
Five Cars in Their Lifetimes.” MIT Technology Review 75: 103.                       Porter, M. E., and C. Van Der Linde. 2017. “Toward a New Conception
                                                                                    of the Environment-­     Competitiveness Relationship.” Corporate
Himeur, Y., B. Rimal, A. Tiwary, and A. Amira. 2022. “Using Artificial              Environmental Responsibility 9, no. 4: 61–82. https://​doi.​org/​10.​1257/​
Intelligence and Data Fusion for Environmental Monitoring: A Review                 jep.9.​4.​97.
and Future Perspectives.” Information Fusion 86–87: 44–75. https://​doi.​
org/​10.​1016/j.​inffus.​2 022.​06.​0 03.                                           Qian, Y., K. L. Siau, and F. F. Nah. 2024. “Societal Impacts of Artificial
                                                                                    Intelligence: Ethical, Legal, and Governance Issues.” Societal Impacts 3:
Honaker, J., and G. King. 2010. “What to Do About Missing Values                    100040. https://​doi.​org/​10.​1016/j.​socimp.​2 024.​100040.
in Time-­S eries Cross-­S ection Data.” American Journal of Political
Science 54, no. 2: 561–581. https://​doi.​org/​10.​1111/j.​1540-­​5907. ​2 010.​    Rajagopalan, A., D. Swaminathan, M. Bajaj, et al. 2024. “Empowering
00447.​x .                                                                          Power Distribution: Unleashing the Synergy of IoT and Cloud
                                                                                    Computing for Sustainable and Efficient Energy Systems.” Results in
Hu, Z., Z. Cao, A. Du, and Q. Tu. 2025. “Where Does It Matter?                      Engineering 21: 101949. https://​doi.​org/​10.​1016/j.​rineng.​2 024.​101949.
Revisiting the Role of Proximity in Knowledge Spillovers.” American
Journal of Economics and Sociology 84, no. 2: 297–322. https://​doi.​org/​          Rasheed, M. Q., Z. Yuhuan, A. Haseeb, Z. Ahmed, and S. Saud.
10.​1111/​ajes.​12604​.                                                             2024. “Asymmetric Relationship Between Competitive Industrial
                                                                                    Performance, Renewable Energy, Industrialization, and Carbon
IEA. 2020. Energy and AI, 1–12. IEA Publications.                                   Footprint: Does Artificial Intelligence Matter for Environmental
IEA. 2024. Electricity 2024: Analysis and Forecast to 2026, 1–170. IEA              Sustainability?” Applied Energy 367: 123346. https://​doi.​org/​10.​1016/j.​
Publications.                                                                       apene​rgy.​2 024.​123346.

Karlilar Pata, S., and U. Korkut Pata. 2025. “Comparative Analysis of               Romer, P. M. 1990. “Endogenous Technological Change.” Journal of
the Impacts of Solar, Wind, Biofuels and Hydropower on Load Capacity                Political Economy 98, no. 5: S71–S102. https://​doi.​org/​10.​1086/​261725.
Factor and Sustainable Development Index.” Energy 319: 134991.
                                                                                    Shah, M. H., S. T. Hassan, I. Ullah, Y. Wang, and A. A. Shah. 2025.
https://​doi.​org/​10.​1016/j.​energy.​2 025.​134991.
                                                                                    “Sustainable Water Management Practice in South Asian Countries:
Kwon, H.-­S., J. Lee, S. Lee, and R. Oh. 2022. “Knowledge Spillovers                The Importance of Water Resources, Temperature, and Bioenergy on
and Patent Citations: Trends in Geographic Localization, 1976–2015.”                Ecological Footprint.” Gondwana Research 144: 109–122. https://​doi.​
Economics of Innovation and New Technology 31, no. 3: 123–147. https://​            org/​10.​1016/j.​gr.​2 025.​0 4.​0 04.
doi.​org/​10.​1080/​10438​599.​2 020.​1787001.
                                                                                    Siche, R., L. Pereira, F. Agostinho, and E. Ortega. 2010. “Convergence of
Leal Filho, W., M. F. Mbah, M. A. P. Dinis, et al. 2024. “The Role of               Ecological Footprint and Emergy Analysis as a Sustainability Indicator
Artificial Intelligence in the Implementation of the UN Sustainable                 of Countries: Peru as Case Study.” Communications in Nonlinear Science
Development Goal 11: Fostering Sustainable Cities and Communities.”                 and Numerical Simulation 15, no. 10: 3182–3192. https://​doi.​org/​10.​
Cities 150: 105021. https://​doi.​org/​10.​1016/j.​cities.​2 024.​105021.           1016/j.​cnsns.​2 009.​10.​027.
Liu, J., Y. Qian, Y. Yang, and Z. Yang. 2022. “Can Artificial Intelligence          Smuha, N. A. 2021. “From a ‘Race to AI’ to a ‘Race to AI Regulation’:
Improve the Energy Efficiency of Manufacturing Companies? Evidence                  Regulatory Competition for Artificial Intelligence.” Law, Innovation
From China.” International Journal of Environmental Research and                    and Technology 13, no. 1: 57–84. https://​doi.​org/​10.​1080/​17579​961.​2 021.​
Public Health 19, no. 4: 2091.                                                      1898300.
Liu, L., Z. Rasool, S. Ali, C. Wang, and R. Nazar. 2024. “Robots for                Sun, C., A. Khan, and W. Cai. 2024. “The Response of Energy Aid and
Sustainability: Evaluating Ecological Footprints in Leading AI-­Driven              Natural Resources Consumption in Load Capacity Factor of the Asia
Industrial Nations.” Technology in Society 76: 102460. https://​doi.​org/​10.​      Pacific Emerging Countries.” Energy Policy 190: 114150. https://​doi.​org/​
1016/j.​techs​oc.​2 024.​102460.                                                    10.​1016/j.​enpol.​2 024.​114150.



Sustainable Development, 2025                                                                                                                                    21
                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Taddeo, M., A. Tsamados, J. Cowls, and L. Floridi. 2021. “Artificial
Intelligence and the Climate Emergency: Opportunities, Challenges,
and Recommendations.” One Earth 4, no. 6: 776–779. https://​doi.​org/​10.​
1016/j.​oneear.​2 021.​05.​018.
Traverso, S., M. Vatiero, and E. Zaninotto. 2023. “Robots and Labor
Regulation: A Cross-­Country/Cross-­Industry Analysis.” Economics of
Innovation and New Technology 32, no. 7: 977–999. https://​doi.​org/​10.​
1080/​10438​599.​2 022.​2 063122.
Uche, E., N. Ngepah, N. Das, and L. Dey. 2024. “Dynamic Interactions
of Green Innovations, Green Transitions and Ecological Load Capacity
Factor in BRICS.” Renewable Energy 231: 120905. https://​doi.​org/​10.​
1016/j.​renene.​2 024.​120905.
Vinuesa, R., H. Azizpour, I. Leite, et al. 2020. “The Role of Artificial
Intelligence in Achieving the Sustainable Development Goals.” Nature
Communications 11, no. 1: 233. https://​doi.​org/​10.​1038/​s 4146​7-­​019-­​
14108​-­​y.
Wälde, T. W. 2010. “International Energy Agency.” In Handbook of
Transnational Economic Governance Regimes, 923–942. https://​doi.​org/​
10.​1163/​ej.​97890​0 4163​300.​i-­​1081.​810.
Wang, Q., Y. Li, and R. Li. 2023. “Do Industrial Robots Reduce Carbon
Intensity? The Role of Natural Resource Rents and Corruption Control.”
Environmental Science and Pollution Research 30, no. 49: 107549–
107567. https://​doi.​org/​10.​1007/​s1135​6 -­​023-­​29760​-­​7.
Wang, Y., R. Zhang, K. Yao, and X. Ma. 2024. “Does Artificial Intelligence
Affect the Ecological Footprint? –Evidence From 30 Provinces in
China.” Journal of Environmental Management 370: 122458. https://​doi.​
org/​10.​1016/j.​jenvm​an.​2 024.​122458.
Wiedmann, T., and J. Barrett. 2010. “A Review of the Ecological
Footprint Indicator-­Perceptions and Methods.” Sustainability 2, no. 6:
1645–1693. https://​doi.​org/​10.​3390/​su206​1645.
Williamson, O. E. 2000. “The New Institutional Economics: Taking
Stock, Looking Ahead.” Journal of Economic Literature 38, no. 3: 595–
613. https://​doi.​org/​10.​1257/​jel.​38.3.​595.
Yurtkuran, S., and U. K. Pata. 2024. “The Effect of Nuclear and
Fossil Fuel Energy R&D Expenditures on Environmental Qualities in
Canada.” Sustainable Energy Technologies and Assessments 68: 103872.
https://​doi.​org/​10.​1016/j.​seta.​2 024.​103872.
Zhang, Y. J., Y. L. Peng, C. Q. Ma, and B. Shen. 2017. “Can Environmental
Innovation Facilitate Carbon Emissions Reduction? Evidence From
China.” Energy Policy 100: 18–28. https://​doi.​org/​10.​1016/j.​enpol.​2 016.​
10.​0 05.
Zhao, J., and B. Gómez Fariñas. 2023. “Artificial Intelligence and
Sustainable Decisions.” European Business Organization Law Review
24, no. 1: 1–39. https://​doi.​org/​10.​1007/​s 4080​4 -­​022-­​0 0262​-­​2 .
Zheng, P., and T. Slaper. 2016. University Knowledge Spillovers,
Geographic Proximity and Innovation: An Analysis of Patent Filings
Across U.S. Counties.
Zhou, W., Y. Zhang, and X. Li. 2024. “Artificial Intelligence, Green
Technological Progress, Energy Conservation, and Carbon Emission
Reduction in China: An Examination Based on Dynamic Spatial
Durbin Modeling.” Journal of Cleaner Production 446: 141142. https://​
doi.​org/​10.​1016/j.​jclep​ro.​2 024.​141142.




22                                                                                Sustainable Development, 2025
                                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70296 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Appendix A



TABLE A1    |    List of countries.

 No.         Country       No.         Country       No.        Country

 1            Austria       11         Finland        21        Norway

 2           Australia      12           France       22         Poland

 3           Belgium        13           Greece       23        Portugal

 4            Brazil        14             India      24         Russia

 5           Canada         15             Italy      25        Sweden

 6          Switzerland     16           Japan        26        Singapore

 7            Czech         17        Republic of     27         Turkey
             Republic                   Korea

 8           Germany        18          Mexico        28         United
                                                                Kingdom

 9           Denmark        19         Malaysia       29         United
                                                                 States

 10           Spain         20        Netherlands




TABLE A2    |    Descriptive statistics.

 Variable                        Mean               Std. dev.               Min.            Max.                 Obs.            VIF              R2

 LCF                             0.639               0.517                  0.009           3.271                580             1.46           0.3165

 AI technology                   0.176               0.495                  0.002           4.040                580             1.91           0.4765

 Economic growth                 10.682              0.554                  8.264           11.794               580             2.64           0.6209

 Industry                        0.234               0.048                  0.140           0.406                580             1.99           0.4979

 Urban                           0.779               0.128                  0.292           1.000                580             2.14           0.5322

 FDI                             0.037               0.084                  −0.326          0.860                580             1.3            0.2309

 Internet                        0.751               0.208                  0.024           0.998                580             1.98           0.4961

 Trade                           0.718               0.511                  0.172           3.435                580             2.57           0.6102

 Population                      4.086               13.447                 0.026           79.659               580             2.68           0.6273

 AI*INST1                        −2.708              1.690                  −5.911          1.912                580             1.86           0.4633

 AI*INST2                        −2.823              0.754                  −9.603          −2.337               580             3.59           0.7212

 AI*INST3                        −2.880              2.055                  −7.694          1.756                580             2.05           0.5132



TABLE A3    |    Panel cointegration and slope heterogeneity tests.

 Test                                                             Null hypothesis                    Statistic            p             Conclusion

 Westerlund (2007) panel cointegration                            No cointegration                    2.4511            0.0071          Cointegrated

 Pesaran–Yamagata (2008) slope heterogeneity           Slope coefficients are homogeneous            Δ = 1.305          0.192    Homogeneous slopes

                                                                                                adj. Δ = 1.846          0.065




Sustainable Development, 2025                                                                                                                            23
