                                             Research in International Business and Finance 76 (2025) 102837


                                                          Contents lists available at ScienceDirect


                               Research in International Business and Finance
                                                  journal homepage: www.elsevier.com/locate/ribaf




Unveiling the impact of the digital economy on the interplay of
energy transition, environmental transformation, and renewable
energy adoption
Buhari Doğan a,b,c,d, Rabeh Khalfaoui e,*,1, Brahim Bergougui f,g,2, Sudeshna Ghosh h
a
  Department of Economics, Suleyman Demirel University, Isparta, Turkey
b
  INTI International University, Kuala Lumpur, Malaysia
c
  MEU Research Unit, Middle East University, Amman, Jordan
d
  Western Caspian University, Economic Research Center (WCERC), Baku, Azerbaijan
e
  ICN Business School, CEREFIGE, Université de Lorraine, Nancy, France
f
  College of Business & EconomicsQatar University, Doha, Qatar
g
  National Higher School of Statistics and Applied Economics (ENSSEA), Kolea, Algeria
h
  Department of Economics, Scottish Church College, Kolkata, West Bengal, India




A R T I C L E I N F O                                    A B S T R A C T

Keywords:                                                Energy transition (ET) is considered a key strategy to combat climate change and environmental
Energy transition                                        degradation, making it a critical imperative for all countries. A transition to clean energy is
Energy innovation                                        essential for achieving decarbonization goals. Considering the significant role of the digital
Digital economy, Quantile-based analysis
                                                         economy (DE), this study explores the relationship between ET and renewable energy (RE)
Belt and Road Initiative countries
                                                         innovation in Belt and Road Initiative (BRI) countries from 2002 to 2019. The study focuses on
                                                         four categories of International Patent Classification (IPC) related to solar, wind, biomass, and
                                                         geothermal energy technologies. Panel quantile-based analysis is employed to assess the impact of
                                                         ET in the presence of DE on RE innovation. The main findings indicate that (i) innovation in all
                                                         categories of energy technologies studied plays a pivotal role in assessing ET in BRI economies,
                                                         (ii) the DE substantially contributes to enhancing ET, and (iii) BRI countries should prioritize
                                                         increasing innovation in RE, (iv) the study discusses various policy implications tailored for BRI
                                                         countries accordingly.




1. Introduction

   All major nations are committed to net-zero emanations by 2050. The governments of the major countries are taking concerted
steps to reduce reliance on fossil fuels and develop the deployment of RE (Anika et al., 2022). For example, the European Union has
promised to raise the share of renewables to reach a level of 42.5 per cent in 2030. RE unlike fossil fuels is associated with higher costs
and gestation in the return periods (Yi et al., 2024). Such aspects could put challenges to the expansion of RE in propelling sustainable



  * Corresponding author.
    E-mail addresses: doganbuhari@gmail.com (B. Doğan), rabeh.khalfaoui@gmail.com                       (R.   Khalfaoui),   brahim.bergougui@qu.edu.qa
(B. Bergougui), sudeshna.ghosh@scottishchurch.ac.in (S. Ghosh).
  1
    https://orcid.org/0000-0003-1617-0269
  2
    https://orcid.org/0000-0002-2179-8854

https://doi.org/10.1016/j.ribaf.2025.102837
Received 29 May 2024; Received in revised form 17 February 2025; Accepted 20 February 2025
Available online 21 February 2025
0275-5319/© 2025 Elsevier B.V. All rights are reserved, including those for text and data mining, AI training, and similar technologies.
B. Doğan et al.                                                                       Research in International Business and Finance 76 (2025) 102837


development. Unarguably, RE innovation enables lowering of risks in production, lowers costs associated with investment and raises
the market share in the context of RE (Elia et al., 2021). The pathway for RE innovation is urgently required across the major nations.
    All firms in the manufacturing and service sectors must play a key role in addressing climate change. They should adhere to
environmental protection regulations and implement eco-friendly practices to contribute to an increase in biocapacity. However,
nations vary significantly in terms of industrial development, manufacturing techniques, and technological advancement. In this
context, adopting the green growth model can be beneficial. The green growth model enables firms to achieve sustainable development
while balancing economic and social progress (Hossain et al., 2024).
    The DE known for its expansionary characteristic, can lower asymmetry in information, it further reduces costs of production and
facilitates rapid growth of RE across the globe (Yi et al., 2024; Jia et al., 2024). The DE is gradually becoming the engine for economic
growth and is the facilitator of expansion of RE globally (Yi et al., 2024). The DE accounts for about 15 per cent of the global economy
and its estimated value amounts to $32.6 trillion during 2020 (Ren et al., 2022). The DE is a financial system driven by technology. It
enhances liquidity in capital markets by facilitating the exchange of financial resources between sectors. This new form of financial
development has streamlined resource flow, reduced service costs, and helped firms implement pro-environmental projects (Fang
et al., 2023). DE enables firms to achieve financial stability, improves market forecasting, and provides critical information on liquidity
flows. Furthermore, DE eases financial constraints, allowing small and medium-sized firms to invest in green technologies.
    In the recent periods a fistful of studies has examined the nexus between DE and RE development. The DE has revolutionized the RE
production patterns (Luo, 2023). The DE speeds up data transmission system and has optimized energy management systems and smart
grids (Doğan et al., 2020; Rathor and Saxena, 2020; Ahmad and Zhang, 2021). Again, the interaction between DE and the storage of RE
has the scope to revamp electricity distribution framework. It emphasizes the role of the DE in expanding RE output and transition in
energy (Lee et al., 2022; Li et al., 2023). The study by Li et al., (2023) argue that a symphony of digital technologies has yielded a
diverse and uneven effect on RE.
    RE innovation is crucial for sustainability in the supply of energy (Gielen et al., 2019; Doğan et al., 2021). Presently RE sources pose
challenges for example limitedness in commercialization, rising cost of production and instability in power supply, technological
innovations are vital to counter these barriers. Such processes will raise the cost efficiency and transmission capacities (Yi et al., 2024).
The DE has an immense role in dissemination of information and innovations (Teece,2018). The DE has wireless networks and cloud
computation, this facilitates the task of achieving and processing immense amount of information (Sturgeon, 2021). Such processes
expedites the process of optimization of RE innovation. Nonetheless, the recent literature focusses on ICT or internet development for
RE production (Lee et al., 2022). The fundamental role of the DE in gearing RE innovations for ET and zero emission targets remains
chiefly unexplored. This study addresses this research gap.
    RE technological innovation may lead to decline in consumption of energy due to efficiency in energy (Jin et al., 2018; Murad et al.,
2019; Doğan et al., 2022). However some studies observe that technological innovation leads to consumption of RE. There is inno­
vation in solar photovoltaic technology, innovation in grid technologies and energy storage systems (Wang and Wang, 2020; Izam
et al., 2022; Paramati et al., 2022). Development of sustainable energy systems reduces the demand for non-RE (Murshed and Alam,
2021; Adams et al., 2023). Thus it needs to be explored how energy efficient RE technologies favor ET and stimulate adoption of green
energy sources.
    To discuss the problems associated with ET and to enable to accelerate the development process, research have paid due attention
to the factors affecting ET that range from dimensions like the economic growth, urbanization (Lantz et al., 2021; Asghar et al., 2024)
and environmental policy (Ullah et al., 2023). However in the era of digital technologies the consumption pattern of residents have
altered. It is crucial to explore how DE affect the process of ET. The DE is increasingly becoming the major form of economy after
agriculture and industrial economy (Shahbaz et al., 2022). The digital transition and application of information and communication
technology is becoming the major force to change the pathway to ET (Luo et al., 2024).
    Building on the theoretical foundation of the numerous benefits of the DE in promoting green innovation, this study examines the
effect of DE on ET and RE innovation in the context of BRI countries. In doing so, we have controlled for the impact of key factors,
including environmental policy, foreign direct investment, urbanization, and population levels. This study explores how DE impact ET
and RE innovation for the BRI countries for the period 1995–2020. The study also assesses how ET and RE innovation affect each other
in two different model specifications. The BRI countries require significant infrastructure development (An et al., 2023). For this
reason, there is requirement of energy and this may significantly impact the environment. The BRI countries need to put increased
concerns on energy requirements at the backdrop of sustainability goals and climate change (Feng et al., 2019). BRI countries have
added to over 50 per cent of the global carbon footprint and 92 per cent of the increase is during the period 1995–2015 Lu et al.,
(2020). If the BRI countries relied on traditional energy requirements then the total carbon emanations would be around 66 per cent of
total global carbon emanations by 2050.
    Our research is grounded in both theoretical and empirical evidence to formulate our research question and hypotheses. The main
research question is: Does the DE affect ET and RE innovation in the BRI countries? The fundamental motivation for this research is to
investigate the impact of DE on ET and green innovation. We aim to explore how DE has evolved beyond digital currencies to transform
energy transition in these countries. There is limited empirical research on how DE and its expansion influence energy transition
through various environmental channels, and further research is needed for both theoretical and empirical validation. Most previous
studies have focused on firm-level data from China.
    This study contributes to the existing body of literature in multiple ways.

 • First, it constructs ET comprising two sub-indices quantifying transformation of non-RE to RE sources.


                                                                     2
B. Doğan et al.                                                                     Research in International Business and Finance 76 (2025) 102837


 • Second, based on technological classification in the IPC system categorized RE innovation into four technology groups for example
   solar energy, wind energy, biomass energy and geothermal energy.
 • Third, we construct DE index based on four indicators for example individual using internet, mobile cellular subscriptions, fixed
   broadband subscriptions and secure internet servers. To minimize the subjective bias in the weighting system, the entropy method
   as popularized by Tang et al., (2023) is used in this study.
 • Fourth, this study applies the state-of-the-art estimation techniques (Method of Moments Quantile Regression: MM-QR) to assess
   the impact of the independent variables on RE technology and ET. By applying a quantile regression approach, we reveal the
   asymmetric nature of the relationship between the DE, ET, and RE innovation in the context of a panel of observations.
 • Finally, we control for country-specific factors and use quantile regression to examine how DE affects energy transition across
   different quantiles in the designated nations. This research is pioneering in capturing the heterogeneity in data related to DE, thus
   providing unbiased and consistent empirical results. Our study contributes to the literature by addressing how DE impacts energy
   transition across heterogeneous quantiles, an aspect that has been largely neglected in earlier research.

    The study henceforth is designed in the following manner. Section 2 discusses the key discoveries in the literature. Section 3 delves
into the discussion on data sets and methodology. The major results are discussed in Section 4. Finally, Section 5 concludes.

2. Review of literature

   This section reviews the existing literature at the intersection of the DE, renewable energy innovation, and energy transition. The
study highlights key themes, identifies gaps, and discusses recent developments in the literature. Advances in the Internet and digital
technology have significantly impacted the financial sector. DE, as a component of the financial industry, has seen broad application
across various sectors (Xue et al., 2022). The evolution of blockchain technology has brought about substantial changes in finance,
providing safer and more efficient transactions in the digital realm. The impact of DE on energy consumption, climate change, and
green growth has been a focal point in several research studies.
   The focus of all major nations of the world is to ensure rapid spread of RE. RE costs are high during the early phases and the
consumers strong dependence towards fossil fuels make ET difficult. The DE is an intangible asset that can reduce the cost of RE. In fact,
the DE is considered as an important determinant of ET and replacing coal with RE (Wang et al., 2023). Based on the scope of our
current research the discussion in the literature is divided under two major strands:

2.1. Digital economy and renewable energy innovation

    A fistful of studies have measured the association between DE and RE innovation. However the empirical results are sufficiently
evident to establish widespread agreement on the beneficial effects of DE on RE innovation. Yi et al., (2024) using a panel of 65
countries for the period 2002–2019 explored the relationship among DE and RE innovation. The empirical results document that the
DE significantly enhances innovation in RE. It had positive effect on solar, wind and biomass energy. Further countries with higher
incomes and strong policies were shown to exert a meaningful impact. Zheng and Wong (2024) examined the impact of DE on RE
development for China. Using fixed effects model for 31 provinces the study found favorable connection between DE and RE growth.
The DE has stronger positive effect for hydro energy in comparison to wind energy and solar energy. The involvement of the local
governments raises the positive nexus between DE and RE.
    Hwang (2023) investigated the impact of transitioning to RE and the DE on economic growth across 18 Latin American countries.
To achieve this, the multidimensional nature of the RE transition index and DE index is analyzed using the Principal Component factor
method. The empirical outcomes from Fixed Effect Panel Threshold Regression documents that RE transition have significant threshold
effect on economic growth and sustainability of the environment. Moreover, according to the MM-QR, both RE transition and the DE
exhibit favorable impacts on economic growth across all quantile groups. Wang, et al., (2022) explored how DE affects high quality
energy development in the context of Chinese provinces. Using data for the period 2007–2017 the study found heterogeneous effect of
DE on high quality energy development. The empirical results document that the impact of DE is higher in regions with high DE index
and higher high quality energy development index. The DE affects high quality energy development through innovations.
    Some studies have documented that digital finance promotes RE innovation (Cao et al., 2021; Yu et al., 2022; Lin and Zhang, 2024).
Furthermore the studies obtain that in cases where credit and capital markets are immature digital finance has greater impetus. Efforts
from the government also reinforces the role of digital finance in the context of improving the performance of energy upon envi­
ronment. To promote RE innovation and technological progress there is an urgent need to increase the depth of digital finance (Yu
et al., 2022; Lin and Zhang, 2024). Nonetheless the study by Chen (2023) based on Chinese provinces covering the period
2012–2020 find impeding impact of DE development on innovation in RE technology. The study argues that the impeding impact is
owing to a free rider problem. The research further observes that higher level of judicial protection in the case of patents will mitigate
the negative impacts of DE development on innovation in RE technology.

2.2. Transitioning energy in the digital economy

   The studies on the nexus between DE and ET are still in its infancy. The study by Shahbaz et al., (2022) explored the relationship
between DE and RE transition. The study explored how DE impacted ET for 72 countries for the period 2003–2019. The asymmetric
impact reveals that the ramifications of DE are higher at the upper quantiles. Thus, the results indicate that DE favors ET for the

                                                                    3
B. Doğan et al.                                                                       Research in International Business and Finance 76 (2025) 102837


high-income countries. Further there are regional level heterogeneity as far as the role of DE in ET is concerned. The study by Baloch
et al., (2024) in the context of the BRICS nations for the period 2003–2021 confirm the earlier findings by Shahbaz et al., (2022). The
study by Baloch et al., (2024) further observe that economic development is hampering ET in the BRICS nations. The study recom­
mends that governments of the BRICS nations should develop digital infrastructure and encourage the development of innovation
strategies in the energy sector.
    Gao and Jia (2024) explored how digital finance affects the transition to low-carbon energy for China covering the period
2015–2020. The results based on generalized method of moments suggest that digital finance is impacting the performance of RE
industry in China. The study suggests important policy implications for the stakeholders. Such findings align the study by Li, et al.,
(2023) in the context of 283 Chinese cities. The research by Lu et al., (2023) document for Chinese firms covering the period
2011–2015 how digital inclusive finance paves the way for decarbonization process. Digital finance promotes the firms ET particularly
through investments in information and communication technology.
    Ali et al., (2023) for the E7 nations explored how digital financial inclusion affect ET and technological innovation. The results
based on Augmented Mean Group and common Correlated Effect Mean Group document that digital finance inclusion,energy con­
sumption and economic development lead to the deterioration of the environment. The study by Zhang et al., (2023) explored how
financial institutions provide financial support for digital ET for China. To this end data was chosen for the period 2011–2021. The role
of financial institutions account for 29.86 per cent of the total effect in transiting the energy shift. The results conclude that digital ET
can expand economic sustainability.
    Yang et al. (2024) investigated the impact of the DE on green transformation across 30 Chinese provinces. They found that DE
contributes to green industrial transformation, with financial digitization playing a significant role in promoting green innovation.
This effect is observed across countries, with more pronounced impacts in regions with higher levels of green innovation. There is an
urgent need to allocate a larger portion of growth to research and development to further advance green innovation (Hossain et al.,
2024). Additionally, financial inclusion and digital finance are enabling developing countries like Pakistan to achieve environmental
sustainability. The role of renewable energy is crucial in reducing emissions (Ansari et al., 2024). The expansion of the real economy
drives the growth of the digital economy, with self-enhancement mechanisms contributing to this expansion (Wang et al., 2024).

2.3. Gaps in the earlier literature

   We have conducted a thorough and rigorous review of the literature, providing objective assessments of the current research
domains. The existing literature highlights the significant interest in the DE and its implications. Research spanning from 2003 to 2023
underscores the critical role of DE in fostering environmentally-related innovation.
   Summing up, we identify substantial deficiencies in the existing research. First, pertaining to the ET measure studies have
commonly utilized RE generation. Only a limited number of studies have employed a multidimensional index of ET that takes into
account various aspects of energy transformation process. Second countries from the BRI lack research on the effects between RE
innovation and ET and further how DE in the presence of macro variables can impact them. Most previous studies have concentrated on
Asian countries for example China. The Chinese case study has been investigated at the provincial level. Other research has focused on
industrialized countries like the USA or EU member countries. Finally the earlier studies have failed to consider the heterogeneous
behavior and nonlinear nature of RE innovation and its impact on ET. Further the heterogeneous behavior of DE has not been
considered. The inability to capture nonlinearity or heterogeneity may create biased estimates. After pinpointing the deficiencies in the
existing literature we frame three hypotheses to conduct the current study:
H-1. : The integration of RE innovation with the DE could result in a synergistic impact and significantly advance ET in the BRI
countries.
H-2.     : The impact of ET in the presence of DE upon RE innovation for the BRI countries is significant.
H-3. : The impact of RE innovation and DE on ET shows significant heterogeneity across quantile distribution. Further the impact of
ET on RE innovation in the presence of DE shows wide degree of heterogeneity across quantile distribution. Thus, the impact will be
different across BRI countries.

2.4. Theoretical framework

    The DE is influenced by research and development, artificial intelligence, and digital currency. We hypothesize that DE impacts
energy transition and renewable energy innovation, particularly in the presence of environmental regulation, foreign direct invest­
ment, and population factors. To assess sustainability during the transformation process, we will measure the asymmetric effects of DE
across a panel of observations. As a technology-driven financial system, DE ensures liquidity in capital markets and facilitates the
exchange of financial resources between sectors without compromising critical information. This development supports firms in
implementing environmentally friendly projects and enhancing their Corporate Social Responsibility.
    In the context of decarbonization, renewable energy is expected to play a major role, with DE serving as a crucial tool for achieving
a low-carbon economy. DE and renewable energy can help countries avoid environmental catastrophes and pave the way for sus­
tainability. Additionally, DE enhances national competitiveness and productivity, supporting long-term growth. It is expected to
improve the accuracy of renewable energy predictions and ensure efficient energy management through smart technologies that
address emission-intensive sectors.

                                                                     4
B. Doğan et al.                                                                              Research in International Business and Finance 76 (2025) 102837


3. Methodology and data

3.1. Data and variables

3.1.1. Data description
   This study employs a panel dataset encompassing 40 countries participating in the BRI (refer to Table A1 for the complete list). The
data spans a 26-year period, from 1995 to 2020, constrained by data availability. Data were sourced from three primary databases: the
World Development Indicators (WDI, 2023), the OECD Environmental Data and Indicators (OECD, 2023), and the British Petroleum
(BP, 2023). Notably, the energy transition index (ETI) and renewable energy innovation (REI) constitute the dependent variables,
while the primary predictor refers to the DE index. Table 1 delineates the definitions and sources of all variables employed.

3.1.2. Dependent variables

 • Energy transition index (ETI): we constructed the ETI for this analysis draws on the methodology outlined in Hu et al. (2022). The
   ETI comprises two sub-indices quantifying transitions in non-renewable energy (NRET) and renewable energy (RET). The ETI
   captures the shift from non-renewable to RE sources in four steps (Bergougui and Meziane, 2025):
     Step 1: We identify four non-RE sources: coal, crude oil, natural gas, and nuclear. We measure their carbon contents.
     Step 2: We identify five RE sources: biofuels, solar, hydro, geothermal, and wind. We measure their energy efficiencies.
     Step 3: We compute the sub-indices for each energy source based on their carbon contents or energy efficiencies.
     Step 4: To represent the overall shift from non-renewable to RE at the country level, a weighted geometric mean of the NRET and
   RET indices is calculated as per the following:
                  √̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅̅
                    (βNRET i,t + γRETi,t )
         ETIi,t =
                                  β+γ

   Where β and γ represent the respective weights applied to NRET and RET sub-indices. Given the socioeconomic and environmental
   preferences for transitions towards RE sources, the weighting scheme assigns a higher weight to the RET component such that β < γ.
 • Renewable energy innovation (RE): drawing on the technological classifications outlined in the IPC system, RE innovation is
   categorized into four key technology groups: solar energy, wind energy, biomass energy, and geothermal energy. The RE utilized in
   this analysis is constructed as the sum of innovation output, measured in terawatt hours, across these four technology categories.
   Data on the total RE generated (measured in Terawatt hours) is sourced from the British Petroleum Statistical Review of World
   Energy (BP 2023).

3.1.3. Core independent variable
    This study utilizes the digital economy index (DEI) as the primary explanatory variable to investigate its impact on both ETI and
REI. Recognizing the multifaceted nature of the DE, as highlighted by (Bergougui, Ayad, et al., 2024; Lei et al., 2024; Wu et al., 2021),
we acknowledge the limitations of single indicators and support for a composite index approach to capture its comprehensive essence.
Inspired by (Ren et al., 2021; Zheng and Wong, 2024), we construct a DE by incorporating four key indicators: individuals using the
internet, mobile cellular subscriptions, fixed broadband subscriptions, and secure internet servers. To minimize subjective bias in
weighting, we employ the entropy method, as argued by (Tang et al., 2023). Data for the digitalization development indicator is
sourced from the World Bank database.




Table 1
Variable definitions and data sources.
  Variables                   Notations   Measurement Units                                                                                        Sources

  Energy Transition index     ETI         Index constructed based on (Hu et al., 2022)                                                             BP
  Renewable energy            REI (Ln)    The sum of hydro energy, wind energy, geothermal energy and solar energy measured in Terawatt hour       BP
       Innovation                         (TWh) per capita
  Digital Economy Index       DEI (Ln)    Index constructed through developed entropy method                                                       WDI
  Environmental Policy        EP          Environmental taxes % of GDP                                                                             OECD
  Innovation Capacity         IC          Total number of patents per capita                                                                       WDI
  Environmental tech          ET          Number of patents in environment-related technologies                                                    OECD
  World Uncertainty Index     WUI         World Uncertainty Index                                                                                  WUI
  Foreign direct investment   FDI         % of GDP                                                                                                 WDI
  Urbanization                UP (Ln)     % of total population                                                                                    WDI
  GDP per capita              PGDP        In constant 2015 US$                                                                                     WDI
                              (Ln)
  Population                  POP (Ln)    Total                                                                                                    WDI

Source: World Development Indicators (WDI, 2023), Organisation for Economic Co-operation and Development (OECD, 2023), and British Petroleum
(BP, 2023)

                                                                           5
B. Doğan et al.                                                                                      Research in International Business and Finance 76 (2025) 102837


3.1.4. Covariates
    To elucidate the effects of confounding aspects on ETI and REI, a group of regulating factors are included in the econometric model
specification. Environmental policy (EP) is proxied by environmental taxes as a percentage of GDP, obtained from the OECD Statistics
Database. Following (Cheon and Urpelainen, 2012), a country’s innovation capacity (IC) is quantified based on the per capita number
of patents granted. Aligning with related literature, environmental technology (ET) is quantified by the number of total patent ap­
plications in environmentally-related technologies (Aydin et al., 2024; Bergougui and Aldawsari, 2024; Bergougui, 2024b; Bergougui,
2024) . GDP per capita (PGDP) serves as an indicator of market size (Bergougui et al., 2024; Chovancová et al., 2024). Foreign direct
investment (FDI) is measured as the ratio of annual net inflows to GDP (Bergougui, 2024a). Urbanization (UR) is assessed as the
percentage of the population residing in urban areas. Lastly, the population (POP) reflects the total nation-level population. Table 2
presents descriptive statistics summarizing the distributional properties of all variables utilized in the econometric analysis. Exami­
nation of the skewness and kurtosis statistics reveals substantial non-normality across indicators. The high skewness and kurtosis
values provide quantitative evidence that the variables deviate markedly from normal distributions, implying that the ordinary least
squares (OLS) method is not appropriate.

3.2. Model specification

      This study examines the two-way relationship between REI and ETI in BRI economies. Specifically, the models allow investigation
of:

       (i) How REI levels impact shifts in these economies towards RE sources;
      (ii) The reverse effect, with advances in ETI encouraging additional innovation in RE.

   The models also consider the role of the DE and other controlling factors. The multivariate frameworks for assessing the bidi­
rectional causal links between ETI and REI is formally represented as:
   Model 1: Energy Transition Index (ETI):
          ETIi,t = βi + α1 REIi,t + α2 DEIi,t + α3 ETi,t + α4 WUIi,t + α5 PGDPi,t + α6 UPi,t + α7 FDIi,t + α7 POPi,t + α8 EPi,t + μi,t

      Model 2: Renewable Energy Innovation (REI):
          REIi,t = βi + α1 ETIi,t + α2 DEIi,t + α3 ETi,t + α4 WUIi,t + α5 PGDPi,t + α6 UPi,t + α7 FDIi,t + α7 POPi,t + α9 ICi,t + μi,t

Where i and t represent the 40 BRI countries and year, respectively. The explanatory variables include DE index (DEI), environmental
policy (EP), innovation capacity (IC), environmental tech (ET), world uncertainty index (WUI), foreign direct investment (FDI), ur­
banization (UP), GDP per capita (PGDP), and population (POP). α1 − α9 are the estimated parameters.

3.2.1. Estimation procedures
    The estimation procedures in this study involve a series of steps designed to capture the two-way relationship between Renewable
Energy Investment (REI) and Energy Transition Investment (ETI) in the Belt and Road Initiative (BRI) economies. The key steps are as
follows (see Fig. 1):

3.2.1.1. Data collection. The initial step involves the compilation of relevant data from multiple sources. Specifically, data pertaining
to REI, ETI, and control variables were sourced from the World Development Indicators (WDI), Organisation for Economic Co-
operation and Development (OECD), and British Petroleum (BP) Statistical Review of World Energy databases. This comprehensive
dataset forms the foundation for subsequent analyses.

3.2.1.2. Data preprocessing and normality assessment. Prior to conducting empirical analyses, the collected data underwent rigorous

Table 2
Summary statistics.
                   Avg.        Std. Dev.        Min.            Max.           Skw.            Krt.             Shapiro-Wilk test        Proba.       Sample size

  ETI               0.20574      2.41299          0.00120       0.18614          3.64778       29.22986         12.84600                 0.00000      1040
  REI               4.38890      8.80579          0.00000       2.67229        − 0.32238        1.89140          8.82300                 0.00000      1040
  DEI               7.45184      9.24300          0.18005       1.89263        − 1.52236        4.79669         11.98300                 0.00000      1040
  ET               12.67405    100.00000          0.42000       9.04459          4.02704       31.68492         13.02400                 0.00000      1040
  EP                1.81561      9.89000          0.01000       1.17340          0.65233        5.57127          9.21400                 0.00000      1040
  IC                0.45806      5.78585          0.00021       0.97925          2.96894       11.60732         14.34200                 0.00000      1040
  WUI               0.20684      2.81803          0.00000       0.24612          3.82586       26.28330         13.19000                 0.00000      1040
  PGDP              9.08442     11.62998          6.32738       1.03934        − 0.15273        2.81200          4.05600                 0.00002      1040
  UP                4.11154      4.60517          3.07699       0.29427        − 1.01527        4.23149          9.35900                 0.00000      1040
  FDI               1.31297      5.63887        − 4.77386       1.02428        − 0.37744        8.94315          9.98200                 0.00000      1040
  POP              16.56319     21.06763         12.92055       1.62887          0.10294        2.94159          6.48400                 0.00000      1040

Source: Authors’ computations generated through Stata 18.

                                                                                 6
B. Doğan et al.                                                                         Research in International Business and Finance 76 (2025) 102837




                                           Fig. 1. Theoretical Framework of the flow of variables.




                                                    Fig. 2. Design of the analysis process.


preprocessing to ensure data consistency and accuracy. Outliers and missing values were carefully handled through appropriate
statistical techniques. Subsequently, the Jarque-Bera test (1980).was applied to assess the normality of the data distribution. The
results of this test informed our decision to employ either the Mean Regression Method or the Panel Quantile Regression Method for the
subsequent analysis.

3.2.1.3. Stationarity testing. Given the panel nature of the data, it is essential to examine the stationarity properties of the variables. To


                                                                      7
B. Doğan et al.                                                                        Research in International Business and Finance 76 (2025) 102837


this end, second-generation panel unit root tests proposed by Im et al., (2003), Hadri (2000), and Breitung and Das (2005) were
employed. These tests provide robust evidence on whether the variables are integrated of order zero (I(0)) or integrated of order one (I
(1)). The results of these tests inform the subsequent modeling strategy.

3.2.1.4. Model estimation. Given the complex and potentially non-linear relationship between REI and ETI, the Method of Moments of
Quantile Regression (MM-QR) model was employed. This advanced econometric technique allowed for the estimation of quantile-
specific regression coefficients, providing a comprehensive understanding of the heterogeneous effects across different conditional
distributions. The MM-QR model was estimated using the specified data and control variables, capturing the bidirectional relationship
between REI and ETI.

3.2.1.5. Results analysis and interpretation. The final step involved a thorough analysis of the estimated MM-QR model results. The
focus was on interpreting the quantile-specific coefficients to elucidate the heterogeneous impacts of REI on ETI and vice versa. The
findings were contextualized within the broader literature and discussed in relation to theoretical expectations. Policy implications
and recommendations were derived based on the empirical evidence.

3.2.2. The MM-QR
    Empirical studies in energy economics frequently encounter non-normal data distributions with significant skewness or heavy tails.
Conventional panel data models utilizing conditional mean regression are prevalent in this domain. However, such approaches neglect
the potential heterogeneity in how driving factors influence energy resources, potentially leading to biased estimates. To overcome this
limitation, this study employs the MM-QR for model estimation. This robust technique offers a systematic framework to analyze the
impact of driving factors on both ETI and REI in BRI countries across the entire conditional distribution of ETI and REI. Additionally,
compared to conditional mean regression, MM-QR is demonstrated to produce more robust estimation results (Machado and Santos
Silva, 2019). Furthermore, while the traditional panel quantile regression method possesses the advantage due to its lack of sensitivity
to conditionally weak associated variables, it overlooks unobserved cross-sectional heterogeneity, which is effectively addressed by the
MM-QR approach (Machado and Santos Silva, 2019). Unlike the location shifter approach, MM-QR assumes that both scale and
location functions influence the conditional distribution of ETI and REI. In the comparison of non-linear models, MM-QR emerges as
the more suitable choice due to its capability to handle location parameter asymmetries, endogeneity, and heterogeneity (Bergougui
et al., 2025; Waris et al., 2023). These features of MM-QR offer distinct advantages over other panel data estimation techniques.
    Hence, a quantile regression model QU (τ|V) that accounts for the location-scale domain is given by:

       Ui,t = αi + Vʹi,t b + (δi + Hʹi,t ω)∅i,t                                                                                     [1]
                 (           )
    Given that P (δi +Hʹi,t ω > 0) = 1. The parameters (α, b, δ, ω) are computed. The individual fixed effects for each cross-sectional
unit i are denoted by (αi , δi ), i = 1, ……, N.
   The covariate H is a k-dimensional vector of observable components of V, which are derived from Element l as follows:
         Hı = Hı (V), ı = 1, …,   K                                                                                                               [2]
   Vi,t is independently and identically distributed across time t and individuals i. ∅i,t is also i.i.d across time t and individuals i and is
uncorrelated with Vi,t to satisfy the moment restrictions proposed by Machado and Silva (2019).
   The rule that arises from Eq. (1) according to Machado and Silva (2019) is:
            (    )
        QU τ|Vi,t = (αi + (δi q(τ) ) + Vʹi,t b + Hʹi,t ωq(τ)                                                                               [3]

    Let V represents the exogenous variables, including DEI, ET, EP, IC, WUI, PGDP, UP, FDI, and POP, and U denotes the dependent
                                                                                                        (  )
variables, comprising ETI and REI. Given Vi,t , the conditional quantile distribution of U is QU τ|Vi,t . The quantile (τ) fixed effect for
                                                                                                     th
each individual i is the scalar coefficient Vʹi,t − αi (τ) = αi + δi q(τ), where q(τ) refers to the τ quantile sample. This coefficient can be
estimated by solving the following optimization problem:
               ∑∑
        minq =         ρτ (Mi,t − (δi + Hʹi,t ω)q)                                                                                         [4]
                   i   t


         In whichρτ (β) = (τ − 1)βI   {β ≤ 0} + TβI   {β > 0}

4. Results

   In our research, we employed the MM-QR technique to investigate the heterogeneity effect and dependence structure between ET
and RE innovation in the BRI countries. The analysis was conducted using lower, middle, and greater quantiles of the joint distribution.
The following percentiles were used: q= 10, 20, 30 to define lower quantiles; q= 40, 50, 60 to represent middle quantiles; and q= 70,
80, 90 to refer to greater quantiles. This procedure was employed for models 1 and 2.




                                                                      8
B. Doğan et al.                                                                       Research in International Business and Finance 76 (2025) 102837


4.1. Unit root test

   Before conducting MM-QR analysis for both models presented in the study, second-generation unit root tests are employed to assess
the stationary properties of the variables. We have utilized panel unit root tests introduced by Im et al. (2003), Shin and Lee (2003),
Hadri (2006), and Breitung and Das (2005). The tests are conducted in levels and first differences and are depicted in Table 3. The
results demonstrate that all first difference variables are stationary.

4.2. MM-QR analysis for model 1

    The outcomes for Model 1 are depicted in Table 4 and Fig. 3. These findings reveal intriguing insights into the impact of RE
innovation on the ET of BRI countries. It is noteworthy that RE innovation significantly and positively influences ET across all quantiles
throughout the entire period under consideration. Consequently, innovation in solar, wind, biomass, and geothermal energies plays a
pivotal role in assessing the ET in BRI countries. It is evident that the ET in BRI countries correlates with technological advancements in
RE. However, to facilitate a successful ET, BRI economies must prioritize increasing innovation in RE.
    Furthermore, another notable outcome is the significant positive impact of the DE on ET across all quantiles of the joint distri­
bution. This suggests that the DE contributes significantly to enhancing ET within the BRI sample.
    Environmental technology and environmental policy also exhibit a positive and significant impact on ET across all quantiles. An
exception is noted at the highest quantile (90th) for the environmental technology variable. These findings underscore the importance
of environmental technology and policy in advancing the conditional quantiles of ET in BRI economies. The analysis also shows that
PGDP significantly and negatively influences the ET across all quantiles. This suggests that a one-unit increase in economic growth
leads to a 3.92 % decrease at the lowest quantile (10th quantile) and an 8.45 % decrease at the highest quantile (90th quantile) in the
BRI’s ET. Additionally, the negative effect of PGDP increases across quantiles. The impact of global uncertainty is insignificant across
all quantiles of the joint distribution, with a negative impact at higher quantiles and a positive impact at lower and middle quantiles. As
shown in Table 4, FDI has a positive effect on advancing the ET system, but its impact is insignificant across all quantiles. It may be
suggested that FDI serves as a catalyst for environmental refuge in BRI countries.
    The outcomes from MM-QR analysis based on model 1 further suggest that the estimated coefficients are broadly larger at higher
quantiles. This implies that BRI countries with stronger RE innovations, greater DE, higher environmental technologies, and policies
have a greater probability of generating a larger effect on the ET compared to BRI countries with smaller RE innovations, weaker DE,
and weaker environmental technologies, and policies. Fig. 3 illustrates the estimates of MM-QR-Model 1, indicating significant var­
iations in the magnitude of estimates across all quantiles.

4.3. MM-QR analysis for model 2

    The results of MM-QR based on Model 2 are displayed in Table 5 and Fig. 4. It is evident that the coefficients of the ET variable are
positive for all quantiles, with a significant impact on RE innovations from the 50th quantile onwards. However, for quantiles below
40, the influence of ETI is insignificantly positive on REI. The values for MM-QR estimates range from 0.2150 at the lowest quantile to
0.6430 at the highest quantile, suggesting, for example, that a one-unit increase in ETI contributes to a 0.643 increase in REI at the
extreme upper quantile. Regarding the DE variable, all coefficients are positive and significant across all quantiles, ranging from
0.3701 (10th quantile) to 0.4516 (90th quantile), suggesting a high positive influence of the DE on RE innovations in BRI countries.
    All quantiles of the ET variable demonstrate a notable positive influence on RE innovation in BRI countries. Additionally, as we
move towards higher quantiles, the impact of ET gradually diminishes. Conversely, global uncertainty and economic growth under­
score a statistically significant and positive impact on REI across all quantiles. It’s noteworthy that the coefficients of PGDP are initially
high but decrease as we progress towards the upper quantiles of the joint distribution, ranging from 4.3786 (10th quantile) to 3.4312
(90th quantile). This suggests that a 1 % increase in economic growth results in a minimum increase of 3.4312 % in RE innovations.
The influence of PGDP is more pronounced at lower quantiles, implying that nations with lower economic growth per capita exert a
stronger influence on RE innovations compared to those with higher economic growth per capita.
    Furthermore, according to the findings, innovation capacity, urbanization, foreign direct investment, and population exhibit a
negative impact on REI. All coefficients are statistically significant except for those of the urbanization regressor for the 40th quantile
and below. Concerning innovation capacity, the negative effect magnifies as we move towards larger quantiles. For instance, at the
lowest quantile, a 1 % increase in innovation capacity results in a decline of 0.7345 % in REI. Conversely, at the extreme upper
quantile of the joint distribution, it leads to a decrease of 1.1898 %. The negative relationship observed between IC, UP, FDI, and POP
with REI implies that these factors might not be conducive to fostering innovation in RE. Notably, population (POP) demonstrated a
stronger influence on REI compared to IC, UP, and FDI.

5. Discussion

    The empirical findings provide valuable insights. RE innovations have a positive and significant impact on ET across all quantiles
throughout the study period. This indicates that technological advancements in the BRI countries are strongly correlated with progress
in RE. To facilitate a successful energy transition, BRI countries must increase their focus on RE innovation. Additionally, the impact of
the DE on ET has been consistently positive and significant across all quantiles, suggesting that DE plays a crucial role in enhancing ET
in these countries. The evidence also shows that economic growth correlates with a decline in RE innovation across all quantiles. These

                                                                      9
                                                                                                                                                                                  B. Doğan et al.
     Table 3
     Unit root tests.
       Variable                   ETI             REI            DEI          ET           EP           IC           WUI          PGDP       UP           FDI          POP

       Level series
       Im et al. (2003)              0.1107       − 1.0648         2.0947      − 0.7480      0.5045      − 1.0805     − 1.6129    − 1.3837     1.3484      − 1.5018     2.6086
       p-value                       0.5441         0.1435         0.9819        0.2272      0.6930        0.1400       0.0534      0.0832     0.9112        0.0666     0.9955
       Hadri (2000)                  7.4382        41.4694        43.2804       16.5604     34.4371       36.1115       2.9974     47.7147    60.2733        6.6714    59.1620
       p-value                       0.0000         0.0000         0.0000        0.0000      0.0000        0.0000       0.0014      0.0000     0.0000        0.0000     0.0000
       Breitung and Das (2005)     − 0.3209         0.7815         0.8110        0.1178      1.6215      − 0.7482     − 1.4087      7.7088     0.4686        0.6134     1.4097
10




       p-value                       0.3742         0.7828         0.7913        0.5469      0.9475        0.2272       0.0795      1.0000     0.6803        0.7302     0.9207
       First-differenced series
       Im et al. (2003)           − 22.3752       − 9.5299       − 14.5903    − 21.2961    − 12.7332    − 14.2236    − 24.3751    − 6.3382     − 3.7787   − 20.0103    − 5.4477
       p-value                        0.0000        0.0000           0.0000       0.0000       0.0000       0.0000       0.0000     0.0000       0.0001       0.0000     0.0000
       Hadri (2000)                 − 7.0725      − 6.7261         − 5.6190     − 4.9163     − 0.4562     − 6.7049     − 6.0437   − 4.1391     − 5.6446     − 5.5401   − 2.8548
       p-value                        1.0000        1.0000           1.0000       1.0000       0.6759       1.0000       1.0000     1.0000       1.0000       1.0000     1.0000
       Breitung and Das (2005)    − 12.6742       − 7.1752         − 3.7989   − 12.6108      − 7.0981     − 5.4614   − 13.9916    − 6.5140   − 11.1284      − 9.4033   − 1.9016




                                                                                                                                                                                  Research in International Business and Finance 76 (2025) 102837
       p-value                        0.0000        0.0000           0.0001       0.0000       0.0000       0.0000       0.0000     0.0000       0.0000       0.0000     0.0286

     Source: Authors’ computations generated through Stata 18.
                                                                                                                                                                                                     B. Doğan et al.
     Table 4
     Estimates from panel quantile modeling. Model 1 (Energy Transition index).
                     Location       Scale           Quantiles

                                                    q= 10             q= 20            q= 30             q= 40            q= 50          q= 60          q= 70          q= 80          q= 90

          REI          0.0128         0.0019          0.0105            0.0109           0.0112            0.0116           0.0120         0.0124         0.0132         0.0142         0.0163
          ​           (0.0000)***    (0.5190)        (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0010)***    (0.0060)***    (0.0520)*
              DEI      0.0316         0.0188          0.0092            0.0132           0.0162            0.0201           0.0242         0.0286         0.0364         0.0453         0.0666
      ​               (0.0000)***    (0.0100)**      (0.0440)**        (0.0010)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0010)***
      ET               0.0014         0.0008          0.0005            0.0007)          0.0008            0.0009           0.0011         0.0013         0.0016         0.0020         0.0029
      ​               (0.0500)**     (0.2530)        (0.2500)          (0.0870)*        (0.0430)**        (0.0280)**       (0.0310)**     (0.0410)**     (0.0640)*      (0.0910)*      (0.1350)
              EP       0.0231         0.0060          0.0160            0.0173           0.0182            0.0195           0.0208         0.0222         0.0246         0.0275         0.0342
11




      ​               (0.0000)***    (0.2430)        (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0020)***    (0.0180)**
      WUI            − 0.0080       − 0.0248          0.0215            0.0162           0.0123            0.0072           0.0018       − 0.0040       − 0.0143       − 0.0261       − 0.0541
      ​               (0.6520)       (0.1410)        (0.0420)**        (0.0870)*        (0.1950)          (0.4980)         (0.8860)       (0.7960)       (0.5080)       (0.3690)       (0.2540)
              PGDP   − 0.0569       − 0.0149        − 0.0392          − 0.0424         − 0.0447          − 0.0478         − 0.0510       − 0.0545       − 0.0606       − 0.0677       − 0.0845
      ​               (0.0000)***    (0.1030)        (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0010)***
      UP               0.0092       − 0.0085          0.0193            0.0175           0.0162            0.0144           0.0126         0.0106         0.0070         0.0030       − 0.0066
      ​               (0.7250)       (0.7290)        (0.2110)          (0.2060)         (0.2440)          (0.3510)         (0.4970)       (0.6440)       (0.8230)       (0.9440)       (0.9240)




                                                                                                                                                                                                     Research in International Business and Finance 76 (2025) 102837
      FDI              0.0055         0.0051        − 0.0005            0.0005           0.0013            0.0024           0.0035         0.0047         0.0068         0.0092         0.0149
      ​               (0.2910)       (0.3020)        (0.8640)          (0.8440)         (0.6290)          (0.4390)         (0.3460)       (0.3040)       (0.2820)       (0.2770)       (0.2810)
      _cons            0.3277         0.1137          0.1923            0.2164           0.2343            0.2579           0.2825         0.3093         0.3562         0.4104         0.5388
      ​               (0.0000)***    (0.1070)        (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0010)***    (0.0070)***

     Source: Authors’ computations generated through Stata 18. ***, **, and * refer to 1 %, 5 %, and 10 % significance levels.
B. Doğan et al.                                                                          Research in International Business and Finance 76 (2025) 102837




Fig. 3. The dynamics of the MM-QR coefficients at several quantiles based on Model 1. It provides estimates, along with 95 % confidence intervals,
for the influence of various regressors on ETI.


insights are essential for developing policies that support the adoption of environmentally-based technologies in various contexts.
    Given that DE is a key driver of green innovation, the nations in question should prioritize enhancing financial digitalization across
all sectors related to energy resource management. In addition to promoting the use of digital currencies, these countries should ensure
an inclusive financial system that supports RE. It is important for the studied countries to encourage firms to invest in RE to foster green
innovation. Furthermore, market-based research is needed to highlight how digitization contributes to financial resource management
and impacts energy transition.



                                                                       12
                                                                                                                                                                                                     B. Doğan et al.
     Table 5
     Estimates from panel quantile modeling. Model 2 (Renewable Energy Innovation).
                     Location       Scale           Quantiles

                                                    q= 10             q= 20            q= 30             q= 40            q= 50          q= 60          q= 70          q= 80          q= 90

          ETI          0.4353         0.1415          0.2150            0.2750           0.3305            0.3883           0.4466         0.4998         0.5432         0.5915         0.6430
          ​           (0.1040)       (0.3480)        (0.5530)          (0.3950)         (0.2620)          (0.1580)         (0.0960)*      (0.0680)*      (0.0590)*      (0.0560)*      (0.0590)*
          DEI          0.4121         0.0270          0.3701            0.3815           0.3921            0.4031           0.4142         0.4244         0.4326         0.4418         0.4516
      ​               (0.0000)***    (0.2380)        (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***
      ET               0.0207       − 0.0007          0.0217            0.0214           0.0212            0.0209           0.0206         0.0204         0.0202         0.0200         0.0197
      ​               (0.0010)***    (0.8480)        (0.0090)***       (0.0040)***      (0.0020)***       (0.0010)***      (0.0010)***    (0.0010)***    (0.0020)***    (0.0050)***    (0.0110)**
      IC             − 0.9688       − 0.1505        − 0.7345          − 0.7984         − 0.8574          − 0.9188         − 0.9809       − 1.0375       − 1.0836       − 1.1350       − 1.1898
13




      ​               (0.0000)***    (0.0170)**      (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***
      WUI              0.3777       − 0.0320          0.4275            0.4139           0.4014            0.3883           0.3752         0.3632         0.3534         0.3424         0.3308
      ​               (0.0250)**     (0.7370)        (0.0620)*         (0.0420)**       (0.0310)**        (0.0250)**       (0.0260)**     (0.0360)**     (0.0510)*      (0.0800)*      (0.1240)
              PGDP     3.8911       − 0.3131          4.3786            4.2458           4.1229            3.9951           3.8659         3.7482         3.6522         3.5452         3.4312
      ​               (0.0000)***    (0.0310)**      (0.0000)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***
      UP             − 1.1017       − 0.3316        − 0.5855          − 0.7262         − 0.8563          − 0.9916         − 1.1284       − 1.2530       − 1.3547       − 1.4680       − 1.5887
      ​               (0.0990)*      (0.3770)        (0.5170)          (0.3670)         (0.2430)          (0.1470)         (0.0910)*      (0.0670)*      (0.0590)*      (0.0570)*      (0.0610)*




                                                                                                                                                                                                     Research in International Business and Finance 76 (2025) 102837
      FDI            − 0.1267         0.0320        − 0.1765          − 0.1629         − 0.1503          − 0.1373         − 0.1241       − 0.1121       − 0.1022       − 0.0913       − 0.0797
      ​               (0.0040)***    (0.1900)        (0.0030)***       (0.0020)***      (0.0020)***       (0.0020)***      (0.0040)***    (0.0120)**     (0.0280)**     (0.0690)*      (0.1490)
              POP    − 2.6317       − 0.1571        − 2.3871          − 2.4537         − 2.5154          − 2.5795         − 2.6443       − 2.7034       − 2.7515       − 2.8052       − 2.8624
              ​       (0.0000)***    (0.5870)        (0.0010)***       (0.0000)***      (0.0000)***       (0.0000)***      (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***    (0.0000)***

     Source: Authors’ computations generated through Stata 18. ***, **, and * refer to 1 %, 5 %, and 10 % significance levels.
B. Doğan et al.                                                                          Research in International Business and Finance 76 (2025) 102837




Fig. 4. The dynamics of the MM-QR coefficients at several quantiles based on Model 2. It provides estimates, along with 95 % confidence intervals,
for the influence of various regressors on REI.




                                                                       14
B. Doğan et al.                                                                      Research in International Business and Finance 76 (2025) 102837


6. Study conclusions and suggested policies

6.1. Conclusions

    This study has explored how DE affect ET and RE innovation for the BRI countries, covering the period 1995–2020 from the
perspective of a sustainable environment. In this research the MM-QR technique is applied to examine the heterogeneity effect and
dependence structure amid ET and RE innovation in the context of the BRI countries. The empirical outcomes demonstrate interesting
findings as far as the impact of RE innovation on ET is concerned. Throughout the entire period under consideration, RE innovation
impacts ET positively and significantly. Again DE has a significant and positive impact on ET across all quantiles of the joint distri­
bution for the BRI countries. The role of the DE in ET is crucial for the BRI countries. Environmental technology and environmental
policy also document a positive and significant impact on ET across all quantiles. Further the analysis based on model 1 suggests that
the estimated coefficients are larger at the upper quantiles. Such outcomes document intriguing insights. Among the BRI countries, the
countries with stronger RE innovations, greater DE, higher environmental technologies have a larger effect on ET. As far as the
empirical outcomes based on model 2 is concerned, the coefficients of the ET variable are positive for all quantiles, with a significant
impact on RE innovations from the 50th quantile onwards. Nonetheless for quantiles below 40, the influence of ET on RE innovation is
positive but insignificant. Again based on the findings, innovation capacity, urbanization, foreign direct investment, and population
exhibit a negative impact on RE innovation.

6.2. Policy considerations

    The study has important policy repercussions based on the empirical outcomes. The governments play a crucial role in shaping the
RE sector. The policy analysts can influence the market behavior and encourage RE innovation. Policies must be directed towards
influencing RE innovation. Thrust of emphasis must be given towards reducing cost of capital of RE projects. The reduction in the cost
of capital will encourage investments in RE transition. The government of the BRI countries should take active role to affect the pace
and scale of ET. The efficacy of these policies lies in stimulating innovation and expanding RE. Policy instruments should be there to
reduce the use of non-renewables that include carbon taxes and capping and trading of carbon emissions.
    The BRI countries should devise policy support programs that focus on the power generation based on renewables. Policy
frameworks needs to adopt integrated policies across sectors. To take advantage of the synergies in ET there should be increased access
to renewables. Digital technologies play a crucial role in the process of integration of new RE sources. The digital technologies facilitate
the transition to cleaner energy system. The task of the governments of the BRI countries is to adopt a strong legal framework to
incentivize the adoption of digital practices. Harnessing innovations in the context of the DE will enable these nations to tread the
pathway to sustainable environment in the future. Moreover the BRI countries should adopt stringent regulations that would be
conducive for the development of the DE. The governments can simplify the process of e-commerce and stimulate entrepreneurship
and innovations. Likewise the government can provide subsides to encourage the purchase of RE. The governments of the BRI countries
should encourage research and development for innovation in RE and boost the advancement of DE.

6.3. Managerial implications

    The DE can encourage firms to integrate renewable energy sources to enhance energy infrastructure. The managerial implications
of this research are to expand efficiency in energy, management in energy and environmental sustainability. The study has revealed
that digital economy fosters technological innovation that improves energy transition and it assists in the production of new energy.
The firms need to strengthen the environmental rules so that digital means can optimize the structure of energy consumption.
    There is an urgent need for increased investment in research and development to allocate digital resources. DE have the power to
generate interconnected energy system. Energy managers can use the digital tools to improve energy operations. The companies need
to embrace digital technologies to obtain higher operating efficiency, lower costs and improve renewable energy innovation. The
governments should promote measures to ensure that smaller firms benefit from the application of the DE. Firms must take into
consideration the local context and build appropriate infrastructure to foster DE and RE transition.
    The alternative sources of renewable energy and its association with DE needs to be explored. This is particularly important for
infrastructure building and contribution to energy transition. The DE has made significant contributions to energy transition. The role
of factors like foreign direct investment, environmental policies and national income needs to be explored. The findings from the study
underscore the importance of digital economy in integrating digital methods in renewable energy management. With the process of
evolution of digital economies renewable energy companies needs to adapt for sustainable energy transition.

6.4. Study limitations and potential research directions

    Our research does have limitations. A significant constraint is the unavailability of data on some crucial control variables. Addi­
tionally, due to missing data, we were unable to expand the number of countries in our sample. Including more countries would have
provided a deeper understanding of the dynamics between the DE, ET, and RE. Furthermore, some key aspects of DE indices for BRI
nations were not available, such as high-tech manufacturing value addition, internet speed and bandwidth, and network diffusion. The
absence of these factors prevented their inclusion in the DE index, which could have made it more robust.
    Future research could explore the impact of DE on the sub-dimensions of the ET index and how these influence environmental

                                                                    15
B. Doğan et al.                                                                                            Research in International Business and Finance 76 (2025) 102837


sustainability in BRI countries. There is also potential for extending the research to examine the relationships between ET, RE, and DE
in OECD countries, as well as in both developed and developing nations. Additionally, examining the geographical spillover effects of
ET and DE on RE innovations and environmental degradation within BRI territories could provide valuable insights.

CRediT authorship contribution statement

    Ghosh Sudeshna: Writing – review & editing, Writing – original draft, Visualization, Validation, Supervision, Project adminis­
tration, Methodology, Investigation, Formal analysis, Data curation, Conceptualization. Bergougui Brahim: Writing – review &
editing, Writing – original draft, Visualization, Validation, Supervision, Software, Project administration, Methodology, Investigation,
Formal analysis, Data curation, Conceptualization. Khalfaoui Rabeh: Writing – review & editing, Writing – original draft, Visuali­
zation, Validation, Supervision, Methodology, Formal analysis, Conceptualization. Doğan Buhari: Writing – review & editing, Writing
– original draft, Visualization, Validation, Supervision, Project administration, Methodology, Formal analysis, Data curation,
Conceptualization.

Declaration of Competing Interest

    The authors declare that they have no known competing financial interests or personal relationships that could have appeared to
influence the work reported in this paper.

Appendix A




Table A1
Selected Belt and Road Initiative (BRI) countries

  1                   Argentina                11             Egypt                         21             Malaysia                   31              Singapore

       2              Austria                  12             Estonia, Rep. of              22             Morocco                    32              Slovak Rep.
       3              Bangladesh               13             Greece                        23             New Zealand                33              Slovenia
       4              Bulgaria                 14             Hungary                       24             Macedonia                  34              South Africa
       5              Chile                    15             Italy                         25             Pakistan                   35              Thailand
       6              China                    16             Kazakhstan                    26             Peru                       36              Trinidad and Tobago
       7              Croatia                  17             Korea, Rep. of                27             Philippines                37              Türkiye
       8              Cyprus                   18             Latvia                        28             Poland                     38              Ukraine
       9              Czech Rep.               19             Lithuania                     29             Portugal                   39              Venezuela
       10             Ecuador                  20             Luxembourg                    30             Romania                    40              Vietnam




Data availability

      Data will be made available on request.


References

Adams, A., Jumpah, E.T., Dramani, H.S., 2023. Dynamics of Clean and Sustainable Households’ Energy Technologies in Developing Countries: The Case of Improved
     Cookstoves in Ghana. Sustain. Futures 5, 100108. https://doi.org/10.1016/j.sftr.2023.100108.
Ahmad, T., Zhang, D., 2021. Using the internet of things in smart energy systems and networks. Sustain. Cities Soc. 68, 102783. https://doi.org/10.1016/j.
     scs.2021.102783.
Ali, K., Jianguo, D., Kirikkaleli, D., Mentel, G., Altuntaş, M., 2023. Testing the role of digital financial inclusion in energy transition and diversification towards COP26
     targets and sustainable development goals. Gondwana Res. 121, 293–306. https://doi.org/10.1016/j.gr.2023.05.006.
An, Y., Tan, X., Gu, B., Zhu, K., Shi, L., Ding, Z., 2023. An assessment of renewable energy development in Belt and Road Initiative countries: An entropy and TOPSIS
     approach. Energy Rep. 10, 3545–3560. https://doi.org/10.1016/j.egyr.2023.09.085.
Anika, O.C., Nnabuife, S.G., Bello, A., Okoroafor, E.R., Kuang, B., Villa, R., 2022. Prospects of low and zero-carbon renewable fuels in 1.5-degree net zero emission
     actualisation by 2050: A critical review. Carbon Capture Sci. Technol. 5, 100072. https://doi.org/10.1016/j.ccst.2022.100072.
Ansari, M.A.A., Sajid, M., Khan, S.N., Antohi, V.M., Fortea, C., Zlati, M.L., 2024. Unveiling the effect of renewable energy and financial inclusion towards sustainable
     environment: Does interaction of digital finance and institutional quality matter? Sustain. Futures 7, 100196. https://doi.org/10.1016/j.sftr.2024.100196.
Asghar, M., Ali, S., Hanif, M., Ullah, S., 2024. Energy Transition in Newly Industrialized Countries: A Policy Paradigm in the Perspective of Technological Innovation
     and Urbanization. Sustain. Futures, 100163. https://doi.org/10.1016/j.sftr.2024.100163.
Aydin, M., Sogut, Y., Erdem, A., 2024. The role of environmental technologies, institutional quality, and globalization on environmental sustainability in European
     Union countries: new evidence from advanced panel data estimations. Environ. Sci. Pollut. Res. https://doi.org/10.1007/s11356-024-31860-x.
Baloch, M.A., Qiu, Y., Guo, Z., 2024. Empowering sustainability practices through energy transition: The role of digital economy and technological innovation among
     BRICS economies. Aust. Econ. Pap. https://doi.org/10.1111/1467-8454.12330.
Bergougui, B., 2024b. Moving toward environmental mitigation in Algeria: Asymmetric impact of fossil fuel energy, renewable energy and technological innovation
     on CO2 emissions. Energy Strategy Rev. 51, 101281. https://doi.org/10.1016/j.esr.2023.101281.
Bergougui, B., 2024a. Investigating the relationships among green technologies, financial development and ecological footprint levels in Algeria: Evidence from a
     novel Fourier ARDL approach. Sustain. Cities Soc. 112, 105621. https://doi.org/10.1016/j.scs.2024.105621.


                                                                                     16
B. Doğan et al.                                                                                         Research in International Business and Finance 76 (2025) 102837

Bergougui, B., 2024. Algeria’s pathway to COP28 and SDGs: Asymmetric impact of environmental technology, energy productivity, and material resource efficiency
     on environmental sustainability. Energy Strategy Rev. 55, 101541. https://doi.org/10.1016/j.esr.2024.101541.
Bergougui, B., Aldawsari, M.I., 2024. Asymmetric impact of patents on green technologies on Algeria’s Ecological Future. J. Environ. Manag. 355, 120426. https://
     doi.org/10.1016/j.jenvman.2024.120426.
Bergougui, B., Mehibel, S., Boudjana, R.H., 2024. Asymmetric nexus between green technologies, economic policy uncertainty, and environmental sustainability:
     Evidence from Algeria. J. Environ. Manag. 360, 121172. https://doi.org/10.1016/j.jenvman.2024.121172.
Bergougui, B., Meziane, S., 2025. Assessing the Impact of Green Energy Transition, Technological Innovation, and Natural Resources on Load Capacity Factor in
     Algeria: Evidence from Dynamic Autoregressive Distributed Lag Simulations and Machine Learning Validation. Sustainability 17 (5), 1815. https://doi.org/
     10.3390/su17051815.
Bergougui, B., Murshed, S.M., Shahbaz, M., Zambrano-Monserrate, M.A., Samour, A., Aldawsari, M.I., 2025. Towards secure energy systems: Examining asymmetric
     impact of energy transition, environmental technology and digitalization on Chinese city-level energy security. Renew. Energy 238, 121883. https://doi.org/
     10.1016/j.renene.2024.121883.
Breitung, J., Das, S., 2005. Panel unit root tests under cross-sectional dependence. Stat. Neerl 59 (4), 414–433.
Cao, S., Nie, L., Sun, H., Sun, W., Taghizadeh-Hesary, F., 2021. Digital finance, green technological innovation and energy-environmental performance: Evidence from
     China’s regional economies. J. Clean. Prod. 327, 129458. https://doi.org/10.1016/j.jclepro.2021.129458.
Chen, W., 2023. The impact of digital economy development on innovation in renewable energy technologies. Econ. Change Restruct. 56 (6), 4285–4308. https://doi.
     org/10.1007/s10644-023-09553-1.
Cheon, A., Urpelainen, J., 2012. Oil prices and energy technology innovation: An empirical analysis. Glob. Environ. Change 22 (2), 407–417. https://doi.org/
     10.1016/j.gloenvcha.2011.12.001.
Chovancová, J., Zambrano-Monserrate, M.A., Bergougui, B., Ahakwa, I., Dam, M.M., 2024. Global determinants of methane emissions in OECD countries: A dynamic
     panel approach. Res. Glob. 9, 100232. https://doi.org/10.1016/j.resglo.2024.100232.
Doğan, B., Balsalobre-Lorente, D., Nasir, M.A., 2020. European commitment to COP21 and the role of energy consumption, FDI, trade and economic complexity in
     sustaining economic growth. J. Environ. Manag. 273, 111146. https://doi.org/10.1016/j.jenvman.2020.111146.
Doğan, B., Driha, O.M., Balsalobre Lorente, D., Shahzad, U., 2021. The mitigating effects of economic complexity and renewable energy on carbon emissions in
     developed countries. Sustain. Dev. 1–12. https://doi.org/10.1002/sd.2125.
Doğan, B., Ghosh, S., Hoang, D.P., Chu, L.K., 2022. Are economic complexity and eco-innovation mutually exclusive to control energy demand and environmental
     quality in E7 and G7 countries? Technol. Soc. 68. https://doi.org/10.1016/j.techsoc.2022.101867.
Elia, A., Kamidelivand, M., Rogan, F., Gallachóir, B.Ó., 2021. Impacts of innovation on renewable energy technology cost reductions. Renew. Sustain. Energy Rev.
     138, 110488. https://doi.org/10.1016/j.rser.2020.110488.
Feng, T.T., Kang, Q., Pan, B.B., Yang, Y.S., 2019. Synergies of sustainable development goals between China and countries along the Belt and Road initiative. Curr.
     Opin. Environ. Sustain. 39, 167–186. https://doi.org/10.1016/j.cosust.2019.10.008.
Gao, J., Jia, Z., 2024. How does green digital finance drive the low-carbon energy transition in China? Environ. Sci. Pollut. Res. 31 (1), 699–712. https://doi.org/
     10.1007/s11356-023-31127-x.
Gielen, D., Boshell, F., Saygin, D., Bazilian, M.D., Wagner, N., Gorini, R., 2019. The role of renewable energy in the global energy transformation. Energy Strategy Rev.
     24, 38–50. https://doi.org/10.1016/j.esr.2019.01.006.
Hadri, K., 2000. Testing for stationarity in heterogeneous panel data. Econom. J. 3 (2), 148–161.
Hossain, M.R., Rao, A., Sharma, G.D., Dev, D., Kharbanda, A., 2024. Empowering energy transition: Green innovation, digital finance, and the path to sustainable
     prosperity through green finance initiatives. Energy Econ. 136, 107736. https://doi.org/10.1016/j.eneco.2024.107736.
Hu, K., Sinha, A., Tan, Z., Shah, M.I., Abbas, S., 2022. Achieving energy transition in OECD economies: Discovering the moderating roles of environmental
     governance. Renew. Sustain. Energy Rev. 168, 112808. https://doi.org/10.1016/j.rser.2022.112808.
Hwang, Y.K., 2023. The synergy effect through combination of the digital economy and transition to renewable energy on green economic growth: Empirical study of
     18 Latin American and caribbean countries. J. Clean. Prod. 418, 138146. https://doi.org/10.1016/j.jclepro.2023.138146.
Im, K.S., Pesaran, M.H., Shin, Y., 2003. Testing for unit roots in heterogeneous panels. J. Econom 115 (1), 53–74.
Izam, N.S.M.N., Itam, Z., Sing, W.L., Syamsir, A., 2022. Sustainable development perspectives of solar energy technologies with focus on solar Photovoltaic—A
     review. Energies 15 (8), 2790. https://doi.org/10.3390/en15082790.
Jia, S., Chen, X., Jin, J., 2024. Digital disruption and energy efficiency: The impact of regional digitalization on China’s industrial sector. Energy 300, 131542.
Jin, L., Duan, K., Tang, X., 2018. What is the relationship between technological innovation and energy consumption? Empirical analysis based on provincial panel
     data from China. Sustainability 10 (1), 145. https://doi.org/10.3390/su10010145.
Lantz, T.L., Ioppolo, G., Yigitcanlar, T., Arbolino, R., 2021. Understanding the correlation between energy transition and urbanization. Environ. Innov. Soc. Transit.
     40, 73–86. https://doi.org/10.1016/j.eist.2021.06.002.
Lee, C.C., He, Z.W., Xiao, F., 2022. How does information and communication technology affect renewable energy technology innovation? International evidence.
     Renew. Energy 200, 546–557. https://doi.org/10.1016/j.renene.2022.10.015.
Lei, X., Shen, Z.Y., Štreimikienė, D., Baležentis, T., Wang, G., Mu, Y., 2024. Digitalization and sustainable development: Evidence from OECD countries. Appl. Energy
     357, 122480. https://doi.org/10.1016/j.apenergy.2023.122480.
Li, G., Wu, H., Jiang, J., Zong, Q., 2023. Digital finance and the low-carbon energy transition (LCET) from the perspective of capital-biased technical progress. Energy
     Econ. 120, 106623. https://doi.org/10.1016/j.eneco.2023.106623.
Li, W., Cao, N., Xiang, Z., 2023. Drivers of renewable energy transition: The role of ICT, human development, financialization, and R&D investment in China. Renew.
     Energy 206, 441–450. https://doi.org/10.1016/j.renene.2023.02.027.
Lin, B., Zhang, A., 2024. Digital finance, regional innovation environment and renewable energy technology innovation: Threshold effects. Renew. Energy, 120036.
     https://doi.org/10.1016/j.renene.2024.120036.
Lu, L., Liu, P., Yu, J., Shi, X., 2023. Digital inclusive finance and energy transition towards carbon neutrality: evidence from Chinese firms. Energy Econ. 127, 107059.
     https://doi.org/10.1016/j.eneco.2023.107059.
Lu, Q., Fang, K., Heijungs, R., Feng, K., Li, J., Wen, Q., Huang, X., 2020. Imbalance and drivers of carbon emissions embodied in trade along the Belt and Road
     Initiative. Appl. Energy 280, 115934. https://doi.org/10.1016/j.apenergy.2020.115934.
Luo, S., Chishti, M.Z., Beata, S., Xie, P., 2024. Digital sparks for a greener future: Unleashing the potential of information and communication technologies in green
     energy transition. Renew. Energy 221, 119754. https://doi.org/10.1016/j.renene.2023.119754.
Luo, Y., 2023. Does ICT development influence renewable energy investment? Evidence from top-polluted economies. J. Clean. Prod. 428, 139271. https://doi.org/
     10.1016/j.jclepro.2023.139271.
Machado, J.A.F., Santos Silva, J.M.C., 2019. Quantiles via moments. J. Econ. 213 (1), 145–173. https://doi.org/10.1016/j.jeconom.2019.04.009.
Murad, M.W., Alam, M.M., Noman, A.H.M., Ozturk, I., 2019. Dynamics of technological innovation, energy consumption, energy price and economic growth in
     Denmark. Environ. Prog. Sustain. Energy 38 (1), 22–29. https://doi.org/10.1002/ep.12905.
Murshed, M., Alam, M.S., 2021. Estimating the macroeconomic determinants of total, renewable, and non-renewable energy demands in Bangladesh: the role of
     technological innovations. Environ. Sci. Pollut. Res. 28 (23), 30176–30196. https://doi.org/10.1007/s11356-021-12516-6.
OECD, 2023. OECD Economic Outlook, Volume 2023 Issue 1: A long unwinding road. OECD Publishing, Paris. https://doi.org/10.1787/ce188438-en.
Paramati, S.R., Shahzad, U., Doğan, B., 2022. The role of environmental technology for energy demand and energy efficiency: Evidence from OECD countries. Renew.
     Sustain. Energy Rev. 153. https://doi.org/10.1016/j.rser.2021.111735.
Rathor, S.K., Saxena, D., 2020. Energy management system for smart grid: An overview and key issues. Int. J. Energy Res. 44 (6), 4067–4109. https://doi.org/
     10.1002/er.4883.




                                                                                   17
B. Doğan et al.                                                                                       Research in International Business and Finance 76 (2025) 102837

Ren, S., Hao, Y., Xu, L., Wu, H., Ba, N., 2021. Digitalization and energy: How does internet development affect China’s energy consumption? Energy Econ. 98, 105220.
     https://doi.org/10.1016/j.eneco.2021.105220.
Ren, S., Li, L., Han, Y., Hao, Y., Wu, H., 2022. The emerging driving force of inclusive green growth: does digital economy agglomeration work? Bus. Strategy Environ.
     31 (4), 1656–1678. https://doi.org/10.1002/bse.2975.
Shahbaz, M., Wang, J., Dong, K., Zhao, J., 2022. The impact of digital economy on energy transition across the globe: The mediating role of government governance.
     Renew. Sustain. Energy Rev. 166, 112620. https://doi.org/10.1016/j.rser.2022.112620.
Shin, D.W., Lee, O., 2003. An instrumental variable approach for tests of unit roots and seasonal unit roots in asymmetric time series models. J. Econom 115 (1),
     29–52.
Sturgeon, T.J., 2021. Upgrading strategies for the digital economy. GSJ 11 (1), 34–57.
Tang, Y., Wang, B., Pan, N., Li, Z., 2023. The impact of environmental information disclosure on the cost of green bond: Evidence from China. Energy Econ. 126,
     107008. https://doi.org/10.1016/j.eneco.2023.107008.
Teece, D.J., 2018. Profiting from innovation in the digital economy: Enabling technologies, standards, and licensing models in the wireless world. Res. Policy 47 (8),
     1367–1387. https://doi.org/10.1016/j.respol.2017.01.015.
Ullah, S., Luo, R., Nadeem, M., Cifuentes-Faura, J., 2023. Advancing sustainable growth and energy transition in the United States through the lens of green energy
     innovations, natural resources and environmental policy. Resour. Policy 85, 103848. https://doi.org/10.1016/j.resourpol.2023.103848.
Wang, B., Wang, J., Dong, K., Dong, X., 2023. Is the digital economy conducive to the development of renewable energy in Asia? Energy Policy 173, 113381. https://
     doi.org/10.1016/j.enpol.2022.113381.
Wang, H., Wang, M., 2020. Effects of technological innovation on energy efficiency in China: Evidence from dynamic panel of 284 cities. Sci. Total Environ. 709,
     136172. https://doi.org/10.1016/j.scitotenv.2019.136172.
Wang, J., Wang, B., Dong, K., Dong, X., 2022. How does the digital economy improve high-quality energy development? The case of China. Technol. Forecast. Soc.
     Change 184, 121960. https://doi.org/10.1016/j.techfore.2022.121960.
Wang, Z., Lin, S., Chen, Y., Lyulyov, O., Pimonenko, T., 2024. The Digital Economy and Real Economy: The Dynamic Interaction Effect and the Coupling Coordination
     Degree. Sustainability 16 (13), 5769. https://doi.org/10.3390/su16135769.
Waris, U., Mehmood, U., Tariq, S., 2023. Analyzing the impacts of renewable energy, patents, and trade on carbon emissions—evidence from the novel method of
     MMQR. Environ. Sci. Pollut. Res. 30 (58), 122625–122641. https://doi.org/10.1007/s11356-023-30991-x.
Wu, H., Hao, Y., Ren, S., Yang, X., Xie, G., 2021. Does internet development improve green total factor energy efficiency? Evidence from China. Energy Policy 153,
     112247. https://doi.org/10.1016/j.enpol.2021.112247.
Xue, Y., Tang, C., Wu, H., Liu, J., Hao, Y., 2022. The emerging driving force of energy consumption in China: does digital economy development matter? Energy Policy
     165, 112997.
Yang, X., Xu, Y., Razzaq, A., Wu, D., Cao, J., Ran, Q., 2024. Roadmap to achieving sustainable development: does digital economy matter in industrial green
     transformation? Sustain. Dev. 32 (3), 2583–2599. https://doi.org/10.1002/sd.2781.
Yi, J., Dai, S., Li, L., Cheng, J., 2024. How does digital economy development affect renewable energy innovation? Renew. Sustain. Energy Rev. 192, 114221. https://
     doi.org/10.1016/j.rser.2023.114221.
Yu, M., Tsai, F.S., Jin, H., Zhang, H., 2022. Digital finance and renewable energy consumption: evidence from China. Financ. Innov. 8 (1), 58. https://doi.org/
     10.1186/s40854-022-00362-5.
Zheng, M., Wong, C.Y., 2024. The impact of digital economy on renewable energy development in China. Innov. Green. Dev. 3 (1), 100094. https://doi.org/10.1016/
     j.igd.2023.100094.
WDI (2023) World Development Indicators, World Bank. Available online: https://databank.worldbank.org/home.aspx.
BP (2023) Energy Outlook, https://www.bp.com/content/dam/bp/business-sites/en/global/corporate/pdfs/energy-economics/energy-outlook/bp-energy-outlook-
     2023.pdf?stream=business.




                                                                                  18
