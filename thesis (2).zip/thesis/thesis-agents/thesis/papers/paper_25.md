Original article

                                                                                                       Energy & Environment
                                                                                                                       1–25
Shock effects of institutional                                                                         © The Author(s) 2026

quality, green technologies, and                                                                     Article reuse guidelines:
                                                                                           sagepub.com/journals-permissions
natural resources on Algeria’s                                                            DOI: 10.1177/0958305X261421359
                                                                                             journals.sagepub.com/home/eae
energy diversiﬁcation

Brahim Bergougui1,2,3                       and Said Meziane4


Abstract
Algeria’s hydrocarbon-dependent economy faces signiﬁcant challenges in diversifying its energy
mix to achieve sustainability and reduce vulnerability to global energy market ﬂuctuations.
Despite abundant natural resources, the country’s heavy reliance on fossil fuels has hindered pro-
gress toward energy diversiﬁcation, as measured by the energy diversiﬁcation index. This study
investigates the asymmetric impacts of institutional quality, green technologies, and natural
resources on Algeria’s energy diversiﬁcation from 1995/Q1 to 2022/Q4, addressing a critical lit-
erature gap. Using the Fourier nonlinear autoregressive distributed lag model, the study explores
long-term equilibrium relationships and asymmetric dynamics between these variables and energy
diversiﬁcation. The analysis reveals that positive shocks in institutional quality lead to substantial
increases in energy diversiﬁcation, underscoring strong governance’s crucial role in promoting
energy transitions. Conversely, negative institutional shocks signiﬁcantly reduce energy diversiﬁca-
tion, highlighting the detrimental effects of declining governance quality. Similarly, positive green
technology shocks enhance energy diversiﬁcation, while negative shocks diminish it. Natural
resources exhibit dual effects: positive shocks result in modest energy diversiﬁcation increases,
suggesting resource revenues can support renewable projects; however, negative shocks lead
to decreases, emphasizing ﬁscal volatility’s destabilizing impact on energy diversiﬁcation. These
ﬁndings conﬁrm asymmetric relationships, as positive and negative shocks signiﬁcantly inﬂuence
Algeria’s energy diversiﬁcation differently. Policy implications underscore the need for continuous
governance reforms, enhanced anti-corruption measures, and transparent regulatory frameworks
to attract renewable energy investments. Strategic reallocation of hydrocarbon revenues—
through mechanisms similar to Norway’s sovereign wealth fund model—could mitigate ﬁscal risks


1
  College of Business & Economics, Qatar University, Doha, Qatar
2
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, The Netherlands
3
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
4
  Department of Economics, Mohamed Cherif Messaadia University, Souk Ahras, Algeria

Corresponding author:
Brahim Bergougui, College of Business & Economics, Qatar University, Doha, Qatar; International Institute of Social Studies
(ISS), Erasmus University Rotterdam, The Hague, The Netherlands; National Higher School of Statistics and Applied
Economics (ENSSEA), Koléa, Algeria.
Email: bergougui@iss.nl; brahimbergougui@gmail.com
2                                                                         Energy & Environment 0(0)


and support green transitions, providing actionable insights for transforming Algeria’s energy
landscape.

Keywords
Energy diversiﬁcation index, institutional quality, green technologies, natural resources, Fourier
nonlinear autoregressive distributed lag




Introduction
The global energy landscape is undergoing a transformative shift as nations grapple with the dual
challenges of meeting rising energy demand and mitigating climate change. For oil-exporting coun-
tries, this transition is particularly urgent. Decades of reliance on hydrocarbon revenues have cre-
ated economies vulnerable to price volatility, environmental degradation, and social inequities.
Algeria, Africa’s third-largest oil producer and a key supplier of natural gas to Europe, epitomizes
this paradox: while its fossil fuel wealth has fueled short-term growth, it has also entrenched struc-
tural imbalances, stiﬂed innovation, and left the economy exposed to global market shocks.1
    Globally, the imperative to diversify energy systems is underscored by the “planetary boundaries”
framework, which warns that human activity—particularly fossil fuel consumption—is exceeding
Earth’s regenerative capacity.2 This challenge is further compounded by the rapid advancements in
renewable energy technologies and international climate commitments, necessitating a proactive and
strategic approach to energy diversiﬁcation. For Algeria, aligning with global decarbonization goals
while ensuring energy security and economic resilience requires a fundamental restructuring of its
energy policies, institutional frameworks, and technological capabilities. Without a decisive shift,
the country risks long-term economic stagnation and environmental degradation.3,4
    Achieving energy diversiﬁcation requires exploring a variety of energy sources to meet growing
demand. While previous studies have addressed some aspects of energy diversiﬁcation,5–7 the
impact of green technologies in this ﬁeld has not received sufﬁcient attention. Although research
has demonstrated the inﬂuence of green technologies on the development of renewable energy,8
energy efﬁciency,9 and energy usage,10 its direct impact on energy diversiﬁcation remains unex-
plored. This study aims to ﬁll this research gap by focusing on the energy diversiﬁcation index
(EDI) and incorporating key macroeconomic indicators, such as institutional quality and natural
resource, to identify their role in promoting sustainable energy strategies.
    Strong institutions are pivotal in orchestrating a coherent energy transition. Transparent regula-
tory frameworks, enforceable policies, and anti-corruption measures create an environment condu-
cive to investment in renewables. For instance, robust institutions can streamline permitting
processes for solar projects, enforce carbon pricing mechanisms, and allocate resources efﬁciently.
Conversely, weak institutions—marked by bureaucratic inefﬁciency, rent-seeking, and political
instability—undermine investor conﬁdence. Algeria’s Corruption Perceptions Index (CPI) score
of 36/104 (2023) reﬂects systemic governance challenges, which have delayed renewable energy
projects like the Tafouk 1 solar plant, originally slated for completion in 2020. Countries like
Morocco, with stronger institutions (CPI: 38/97), have outpaced Algeria in solar capacity, achiev-
ing 800 MW through the Noor Ouarzazate complex, compared to Algeria’s 500 MW.11 These gov-
ernance challenges highlight the critical need for institutional reform to unlock Algeria’s renewable
energy potential.12,13
Bergougui and Meziane                                                                              3


    Technological advancements play a crucial role in reducing costs and enhancing the efﬁciency
of renewable energy systems. Breakthroughs in photovoltaic cell efﬁciency (now exceeding 22%
for commercial panels) and AI-driven grid management enable higher renewable integration.
However, Algeria’s lag in green technologies (GT) is evident in its low R&D expenditure (0.7%
of GDP vs. the global average of 1.8%), which stiﬂes domestic innovation and adoption of emer-
ging energy technologies. By contrast, Tunisia’s adoption of smart metering and blockchain for
energy trading has improved grid resilience. For Algeria, leveraging technological advancements
could unlock its vast solar potential (3000 + annual sunshine hours) and wind resources (10 GW
capacity potential),14 but this demands targeted investments in R&D and partnerships with tech lea-
ders like Germany’s Fraunhofer Institute.15 Without such efforts, Algeria risks being left behind in
the global clean energy transition.16–18
    While Algeria’s hydrocarbon reserves (12th globally in proven oil reserves) have historically
ﬁnanced development, they have also perpetuated the “resource curse,” crowding out invest-
ments in renewables. Yet, its renewable resource base remains underutilized: solar irradiation
levels (2200 kWh/m2/year) rival those of Saudi Arabia, but renewables account for just 3% of
electricity production, compared to 20% in Egypt. Efﬁciently harnessing these resources
requires institutional reforms to redirect fossil fuel revenues (which constitute 60% of the state
budget) into renewable infrastructure and workforce training. The successful experiences of
other energy-rich nations, such as the UAE, which has integrated renewables into its energy
mix while maintaining economic stability, underscore the potential beneﬁts of such an approach
for Algeria.19,20
    The interplay between institutions, technology, and resources underscores Algeria’s energy
crossroads. Weak governance has delayed solar projects despite abundant sunshine, while low
R&D investment has left wind potential untapped. By contrast, Morocco’s institutional reforms
and tech adoption enabled its rise as a solar leader. For Algeria, replicating this success demands
institutional accountability to channel hydrocarbon wealth into renewables, coupled with green
technologies to optimize solar and wind yields. Without such measures, the country risks falling
further behind in the global race for sustainable energy, a misstep with dire economic and ecological
consequences. Algeria’s energy future hinges on breaking free from the hydrocarbon trap. By for-
tifying institutions, embracing Green technologies, and strategically redeploying natural resource
wealth, the country can achieve its target of 27% renewable electricity by 2035 while creating
100,000 jobs in the sector.21 This transition is not merely an environmental imperative but a socio-
economic necessity to ensure long-term stability in a post-carbon world. The lessons learned from
other resource-rich countries serve as valuable benchmarks, reinforcing the importance of proactive
policies, strategic investments, and institutional reform in securing a sustainable energy future for
Algeria.
    This study makes several signiﬁcant contributions to understanding the dynamics of energy
diversiﬁcation in Algeria through its examination of the relationships between GT, NR, IQI, and
energy diversiﬁcation.

   • First, a key methodological advancement lies in the application of the Fourier NARDL
     approach, which represents a departure from conventional linear modeling techniques preva-
     lent in existing literature. This sophisticated econometric framework enables the detection of
     asymmetric relationships, allowing us to understand how both increases and decreases in GT,
     NR, and IQI differently impact energy diversiﬁcation outcomes. Such nuanced analysis pro-
     vides deeper insights than traditional linear approaches, revealing complex dynamics that
     might otherwise remain hidden.
4                                                                         Energy & Environment 0(0)


    • Second, this research breaks new ground by conducting the ﬁrst comprehensive analysis of
      these factors’ roles in Algeria’s energy diversiﬁcation journey. By examining how GT, NR,
      and IQI interact with and inﬂuence EDI in various ways, the study illuminates critical path-
      ways for policy intervention and strategic planning. This pioneering investigation establishes
      a foundation for understanding the unique characteristics of Algeria’s energy transition chal-
      lenges and opportunities.
    • Third, the study’s estimation of long-run asymmetric cointegration relationships among the
      variables offers more robust and reliable results compared to conventional time series meth-
      ods. This enhanced analytical approach provides policymakers with a more accurate under-
      standing of the long-term relationships between these crucial factors, enabling them to
      develop more effective strategies for managing energy demand while promoting diversiﬁca-
      tion across the country. The ﬁndings directly inform policy design by highlighting how dif-
      ferent factors may require distinct approaches depending on whether they are experiencing
      positive or negative changes.

    In summary, this study substantially contributes to the understanding of the relationship between
green technologies, natural resource management, institutional governance, and energy diversiﬁca-
tion in Algeria. It highlights the asymmetric effects of these factors, provides novel insights into
their interdependence, and introduces advanced econometric techniques that enhance the reliability
of its ﬁndings—thereby informing both policy design and strategic implementation for a sustain-
able energy future.
    The remainder of the paper is structured as follows: Section 2 provides a comprehensive review
of the existing literature. Section 3 outlines the empirical methodology and details the data sampling
process. Section 4 presents the empirical ﬁndings and offers an in-depth discussion of the results.
Lastly, Section 5 concludes the study by highlighting practical implications and acknowledging its
limitations.


Literature review
In recent years, the global focus on environmental issues and energy diversiﬁcation has intensiﬁed.
This growing attention reﬂects a broader understanding that reducing reliance on fossil fuels and
diversifying energy sources are essential strategies for tackling climate change and ensuring long-
term economic stability. The energy diversiﬁcation literature has evolved beyond examining basic
environmental impacts, now delving into the complex interplay between institutional frameworks,
green technologies, and natural resource availability in shaping countries’ energy transitions.
Recent studies emphasize the importance of diversifying energy sources and transitioning to renew-
able energy technologies, particularly in resource-dependent economies like those in Africa.22
However, as noted by Pata et al.,23 there remains a signiﬁcant gap in identifying the optimal path-
ways for implementing energy diversiﬁcation strategies, especially in regions heavily reliant on nat-
ural resources.


Institutional quality and energy diversiﬁcation
The role of institutional quality in enabling energy diversiﬁcation has emerged as a critical area of
study. Rahman and Sultana24 provide compelling evidence from 19 emerging economies that insti-
tutional effectiveness directly impacts renewable energy consumption. Their longitudinal study
spanning 2002–2019 establishes that countries with more effective, corruption-free institutions
Bergougui and Meziane                                                                                5


demonstrate greater success in diversifying their energy portfolios. The research identiﬁes a unidir-
ectional causal link between institutional quality and renewable energy development, suggesting
that institutional reforms should precede major energy diversiﬁcation initiatives. Mukhtarov
et al.25 demonstrate through their analysis of Poland’s renewable energy sector that institutional fac-
tors, particularly governance effectiveness and corruption control, signiﬁcantly inﬂuence renewable
energy adoption rates. Their research reveals that countries with stronger institutional frameworks
achieve higher rates of energy diversiﬁcation. A particularly signiﬁcant contribution comes from
Dong et al.,26 who examined how governmental capacity to formulate and implement policies
affects the relationship between natural resource abundance and renewable energy adoption.
Their analysis of 96 countries reveals a nuanced picture: the impact of natural resources on energy
diversiﬁcation follows a U-shaped pattern, but this relationship can be positively modiﬁed by strong
institutional frameworks. Importantly, they ﬁnd that institutional quality has the strongest effect in
high-income countries, suggesting that institutional development must reach certain thresholds
before it can effectively support energy diversiﬁcation. Recent empirical research reinforces these
conclusions. A cross-country study covering 87 nations from 2011 to 2020 ﬁnds that lower per-
ceived corruption is signiﬁcantly associated with higher public investments in renewable energy,
particularly in middle-income economies.27 Similarly, a panel analysis across 49 African countries
demonstrates that institutional quality, in conjunction with green innovation and renewable energy
consumption, contributes positively to long-term green growth.28 These ﬁndings highlight that
effective, transparent, and well-governed institutions are crucial not only for promoting renewable
energy adoption but also for enabling broader energy diversiﬁcation strategies.
    Building on these insights, a growing body of research examining the interconnections between
ﬁnancial markets and energy systems highlights the crucial role of institutional quality in mitigating
the effects of external shocks. Strong and resilient institutions serve as stabilizing mechanisms,
helping energy markets absorb and adapt to global ﬁnancial disturbances, thereby reducing their
exposure to sudden ﬂuctuations in resource availability and market volatility.29 Beyond conven-
tional ﬁnancial risks, institutional frameworks also inﬂuence how energy markets respond to emer-
ging uncertainties, particularly those related to environmental, social, and governance (ESG)
considerations. Evidence suggests that ESG-related uncertainties can signiﬁcantly affect fossil
fuel price dynamics, creating additional layers of market complexity.30 These ﬁndings collectively
underscore that robust, transparent, and adaptive institutional structures are not only essential for
market stabilization but also form a foundational element for pursuing effective energy diversiﬁca-
tion policies. In other words, energy security and diversiﬁcation are strongly contingent on the abil-
ity of institutions to manage both traditional ﬁnancial shocks and evolving sustainability-related
uncertainties. Based on the above literature, the following hypothesis is proposed:

   H1: The institutional quality has a positive and signiﬁcant effect on energy diversiﬁcation.


Green technologies and energy diversiﬁcation
Technological innovation is a key driver of energy diversiﬁcation, inﬂuencing both the develop-
ment and adoption of renewable energy systems. Khan et al.8 examined the bidirectional relation-
ship between green technologies and renewable energy in Germany, ﬁnding that technological
advancements generally promote renewable energy growth, although the magnitude of the effect
varies across market segments and time periods. Building on this, Zhao et al.31 investigated the
impact of green technologies on renewable energy investment (REI), revealing that while enhanced
technological capacity reduces risks and encourages renewable adoption, it may also improve the
6                                                                            Energy & Environment 0(0)


efﬁciency of conventional energy sources, highlighting the need for policies that speciﬁcally target
renewable technologies.
                  32
    Rasheed et al. further demonstrate that artiﬁcial intelligence (AI) can signiﬁcantly enhance
renewable energy production in 22 leading innovative countries, particularly when combined
with effective institutional frameworks and resource management strategies. Similarly, Dogan
      33
et al. show that green technology and research and development (R&D) positively drive renewable
energy innovation in BRICS nations, whereas the digital economy exerts a more nuanced effect,
supporting some renewable ventures while negatively correlating with innovation in others.
Additional evidence highlights the transformative impact of industrial AI and technological innov-
ation on modern energy systems. Research indicates that AI-driven technologies can optimize
energy consumption, enhance operational efﬁciency, and facilitate the rapid adoption of cleaner
and more sustainable energy solutions.34 In parallel, studies also emphasize the interaction between
technological innovation and socioeconomic factors, such as income distribution, demonstrating
that these dynamics play a critical role in improving access to modern energy services, increasing
efﬁciency, and supporting comprehensive energy diversiﬁcation strategies.35 Collectively, these
ﬁndings suggest that the integration of advanced technologies with inclusive socioeconomic pol-
icies can substantially accelerate the transition toward more resilient, efﬁcient, and diversiﬁed
energy systems. Drawing on the preceding literature, the following hypothesis is advanced:

    H2: Green technologies exert a positive and signiﬁcant inﬂuence on energy diversiﬁcation.


Natural resources and energy diversiﬁcation
The relationship between natural resource abundance and energy diversiﬁcation presents signiﬁcant
challenges, often due to the “resource curse,” where countries rich in natural resources struggle to
diversify their economies and energy systems. Yuan et al.20 explored the role of natural resources in
renewable energy consumption in N-11 countries from 1990 to 2020. They found that resource
abundance can hinder energy diversiﬁcation, as technological development and ﬁnancial market
growth are negatively related to renewable energy consumption in these countries. This suggests
that natural resource wealth can create barriers to the adoption of renewable energy technologies,
highlighting the need for strong institutional frameworks and technological capabilities to over-
come these challenges. Dong et al.26 further examined how the quality of governance inﬂuences
the relationship between natural resource rents and renewable energy consumption. They found
that enhancing regulatory quality and government effectiveness can mitigate the negative impact
of resource rents on renewable energy, with the most signiﬁcant effects observed in high-income
countries. This indicates that effective policies and governance can reshape the impact of natural
resource abundance, promoting renewable energy consumption despite resource wealth.
Similarly, Rana36 shows that the management of different types of resource rents (oil, gas, coal,
forest) signiﬁcantly inﬂuences sustainability outcomes, including renewable energy adoption,
and that effective policy implementation and institutional quality are essential for transforming
resource wealth into a driver, rather than a barrier, for energy diversiﬁcation. Complementing these
insights, evidence from time-frequency analyses indicates that different energy sources, including
renewable and nuclear energy, exhibit varying environmental impacts over time.37 Such heterogen-
eity underscores the need for nuanced and adaptive energy policies that account for temporal and
sectoral variations in environmental outcomes. These ﬁndings further highlight the importance of
integrating technological innovation with robust institutional frameworks to promote sustainable
energy diversiﬁcation. This approach is particularly critical in hydrocarbon-dependent economies,
Bergougui and Meziane                                                                                         7


Table 1. Data sources and description.
Variables                 Notation   Proxy                                                   Source of data
                                                                                         7
Energy diversiﬁcation     EDI        Index constructed based on Gozgor and Paramati          British
   index                                                                                       Petroleum
Institutional quality      IQI       Arithmetic mean of the worldwide governance             WGI
   index                               indicators.
Green technologies        GT         Patents for environment-related technologies            OECD
Economic growth           GDP        GDP constant 2015 US dollars                            World Bank
Natural resources         NR         % of GDP                                                World Bank



where carefully coordinated strategies can simultaneously enhance energy efﬁciency, reduce envir-
onmental pressures, and support the transition toward a more resilient and diversiﬁed energy sys-
tem. In light of the reviewed literature, the analysis advances the following hypothesis:

   H3: Natural resource abundance is negatively associated with energy diversiﬁcation.


Synthesis and gaps
Previous studies have primarily explored the effects of energy diversiﬁcation in addressing envir-
onmental challenges and promoting economic development, while also highlighting its beneﬁts.
However, there is a noticeable gap in research that examines the determinants inﬂuencing energy
diversiﬁcation. Although existing literature has largely focused on regions such as Africa, the study
examines how green technologies contribute to energy diversiﬁcation, with particular emphasis on
macroeconomic factors like institutional quality and the abundance of natural resources. The ana-
lysis is situated within the context of the Algerian economy over the period 1995–2022. By addres-
sing theoretical and methodological gaps, this research aims to contribute to the existing body of
knowledge. The following section will outline the methodological advancements introduced by
this study within the academic discourse.


Materials and methods
Data
This study investigates the impacts of green technologies, institutional quality and natural resources on
energy diversiﬁcation index in Algeria. The dataset employed in this study focuses on Algeria, covering
the period from the Q1-1995 to Q4-2022, while controlling variables GDP and EC. In order to grasp the
connection between technological advancements and energy sources in Algeria. The data were
obtained from three principal sources: the World Development Indicators, the International Energy
Agency, and British Petroleum. Table 1 outlines the measurement approaches and data sources for
each variable utilized in the analysis.


Justiﬁcations for variable selection
The selection of variables in this study is grounded in both theoretical frameworks and empirical
evidence, ensuring that each variable aligns with the research objectives and contributes
8                                                                         Energy & Environment 0(0)


meaningfully to the analysis. Below, we provide detailed justiﬁcations for the inclusion of each
variable, categorized into dependent, explanatory, and control variables.

Dependent variable: Energy Diversiﬁcation Index (EDI). In this study, the EDI is employed as the prin-
cipal dependent variable, reﬂecting the extent to which national energy systems are diversiﬁed and
resilient. Diversiﬁcation of the energy portfolio, achieved through a balanced incorporation of vari-
ous fossil-fuel derivatives alongside renewable and conventional energy sources, has been shown to
strengthen system stability and reduce vulnerability to supply shocks. Empirical studies suggest that
higher EDI values correspond to lower energy-related risks and enhanced resilience across different
national contexts.
    Following the methodological frameworks of Akroﬁ22 and Gozgor and Paramati,7 energy diver-
siﬁcation is quantiﬁed using an index based on the inverse of the Herﬁndahl–Hirschman Index
(HHI). While the HHI is traditionally applied to assess market concentration, its inverse serves
as a widely accepted measure for evaluating the degree of diversiﬁcation within energy systems.
This approach effectively differentiates between portfolios dominated by a single energy source
and those exhibiting a more balanced distribution. Accordingly, the Energy Diversiﬁcation Index
is constructed using the inverse-HHI formulation as follows:
                                                      1
                                         HHIt = ni
                                                          2
                                                    k=1 ESnt

where ESt represents the total energy production from various energy sources at time t, including
renewable sources. The variable ni denotes the total number of energy sources utilized. In the case
where a country relies exclusively on a single energy source (ni = 1), the energy market exhibits
full concentration, indicating the absence of diversiﬁcation.
   The EDI is calculated as the inverse of the Herﬁndahl–Hirschman Index (HHI) and is expressed
as follows:
                                                     1
                                            EDI =
                                                    HHIt



Explanatory variables. Green Technologies (GT): GT are measured by the total number of patents
related to environmentally friendly technologies. This variable is directly linked to EDI because
green technologies is a critical driver of energy diversiﬁcation. Green technologies, such as solar
panels, wind turbines, and energy storage systems, enable the integration of renewable energy
sources into a country’s energy mix, thereby increasing the diversity of energy sources.
Countries with higher levels of green technology innovation are better positioned to transition
away from fossil fuels and adopt a more balanced energy portfolio. Empirical evidence, such as
studies by Bergougui et al.,1 supports this relationship, showing that nations with more green tech-
nology patents tend to have higher EDI scores. Thus, GT is a key explanatory variable that captures
the role of innovation in facilitating energy diversiﬁcation.
    Institutional Quality Index (IQI): The IQI measures the quality of governance through three
indicators: transparency, rule of law, and governmental efﬁcacy. This variable is directly linked to
the EDI because strong institutions are essential for creating an enabling environment for energy
diversiﬁcation. High-quality institutions are better equipped to design, implement, and enforce pol-
icies that promote renewable energy adoption and reduce reliance on fossil fuels. For example,
Bergougui and Meziane                                                                                  9


transparent and effective governments can provide subsidies for renewable energy projects or
enforce regulations that limit carbon emissions. Empirical research by Murshed38 demonstrates
that countries with higher IQI scores are more likely to achieve energy diversiﬁcation, as strong
institutions facilitate the transition to renewable energy sources. Therefore, IQI is a critical explana-
tory variable that reﬂects the role of governance in shaping energy diversiﬁcation efforts.
    Natural Resources (NR): NR are measured as the economic rent from extracting petroleum,
natural gas, coal, minerals, and forestry resources, expressed as a percentage of GDP. This variable
is directly linked to the EDI because the abundance of natural resources can inﬂuence a country’s
energy mix and diversiﬁcation efforts. Resource-rich countries, particularly those with signiﬁcant
fossil fuel reserves, may exhibit lower levels of energy diversiﬁcation due to their reliance on a sin-
gle energy source. This phenomenon, often referred to as the “resource curse,” suggests that
resource-dependent economies may neglect investments in renewable energy, leading to a less
balanced energy portfolio. Empirical studies by Bergougui and Murshed39,40 support this relation-
ship, showing that natural resource dependence is negatively correlated with energy diversiﬁcation.
Thus, NR is an important explanatory variable that captures the impact of resource abundance on
energy diversiﬁcation.


Control variables. GDP per capita: GDP per capita is included as a control variable to account
for a country’s income level, which directly inﬂuences its capacity to invest in energy diversi-
ﬁcation. Wealthier nations have greater ﬁnancial resources to allocate toward renewable energy
infrastructure, green technologies, and sustainable energy policies. This ﬁnancial capacity
enables them to transition away from fossil fuels and adopt a more diverse energy mix, thereby
increasing their EDI scores. Empirical evidence, such as research by Hwang and Venter,41
demonstrates that higher GDP per capita is positively correlated with energy diversiﬁcation.
By controlling GDP per capita, the analysis ensures that the relationship between other explana-
tory variables and the EDI is not confounded by differences in economic development. Thus,
GDP per capita is a critical control variable that captures the role of economic capacity in driv-
ing energy diversiﬁcation.
    Energy consumption: Energy consumption, particularly from fossil fuels, is included as a con-
trol variable to capture the environmental and economic pressures that drive energy diversiﬁcation.
High levels of fossil fuel consumption increase carbon emissions and contribute to environmental
degradation, creating a strong incentive for countries to diversify their energy sources. Additionally,
rising energy consumption, especially in rapidly growing economies, can strain existing energy sys-
tems and increase the cost of fossil fuel imports, further motivating diversiﬁcation efforts. Empirical
studies by Saqib et al.42 and Sharif et al.43 highlight the negative environmental and economic con-
sequences of high energy consumption, underscoring its role as a driver of energy diversiﬁcation.
By controlling energy consumption, the analysis accounts for the pressures that push countries
toward a more diverse energy mix, ensuring a comprehensive understanding of the factors inﬂuen-
cing EDI.
    The explanatory and control variables in this study are directly linked to EDI through their roles
in shaping a country’s energy mix. GT and IQI positively inﬂuence energy diversiﬁcation by enab-
ling renewable energy adoption and creating an enabling policy environment, respectively. In con-
trast, NR can hinder diversiﬁcation due to resource dependence. Control variables like GDP per
capita and energy consumption account for economic and environmental factors that drive or con-
strain diversiﬁcation efforts. Together, these variables provide a robust framework for understand-
ing the determinants of energy diversiﬁcation, as measured by the EDI.
10                                                                          Energy & Environment 0(0)




Figure 1. Analysis ﬂowcharts.


Methodology
This research aims to assess the effects of GT, IQI, and NR on Algeria’s EDI using the Fourier
NARDL approach, with GDP per capita and EC serving as control variables. The research follows
a structured methodology, as illustrated in Figure 1.

     • First, data collection and description involve gathering and summarizing key characteristics
       of the sample data from various sources.
     • Tests for stationarity and cointegration are carried out, where unit root tests are used to exam-
       ine the stationarity of the variables and the bounds test is applied to verify the presence of
       long-run relationships among them.
     • Third, the Fourier NARDL approach is applied to assess the long-term effects of GT, IQI,
       and NR on EDI.
     • Finally, the empirical ﬁndings are thoroughly examined and discussed to draw meaningful
       conclusions.



Model speciﬁcation and Fourier NARDL framework
In empirical analyses related to energy diversiﬁcation, the relationships among key variables—such
as institutional quality, green technologies, natural resources, and energy outcomes—often exhibit
nonlinear and asymmetric behavior. Traditional linear frameworks, including the standard ARDL,
assume proportional and symmetric responses; however, this assumption is frequently violated in
real-world settings. Economic agents do not respond uniformly to positive and negative shocks:
improvements in institutional quality may foster gradual diversiﬁcation, whereas institutional
deterioration can trigger disproportionately large setbacks. Similarly, expansions in green technolo-
gies tend to generate incremental progress, whereas disruptions in technological deployment or
Bergougui and Meziane                                                                                              11


ﬂuctuations in natural-resource revenues may induce substantial instability. These dynamics are
further complicated by major global disturbances, such as the 1997 Asian ﬁnancial crisis, the
2008 ﬁnancial collapse, and the COVID-19 pandemic, all of which introduce structural breaks
that linear models are unable to adequately capture.
    While many nonlinear ARDL applications attempt to incorporate structural breaks, they typic-
ally assume that the number and timing of such breaks are known in advance, relying on ad hoc
dummy variables. In practice, however, time-series data—particularly in resource-dependent econ-
omies like Algeria—are subject to multiple unknown structural shifts arising from geopolitical ten-
sions, commodity-price cycles, and abrupt policy reforms. To address these complexities, our study
adopts the Fourier NARDL approach, following recent methodological advances by Kathuria and
Kumar,44 Syed et al.,45 and Yilanci et al.46 This speciﬁcation enhances ﬂexibility by approximating
smooth and abrupt breaks using low-frequency Fourier terms while simultaneously modeling long-
run and short-run asymmetries.
    Furthermore, consistent with Shin, Yu, and Greenwood-Nimmo,47 the NARDL framework
accommodates variables integrated of order I(0), I(1), or a combination of both, removing the
restrictive preconditions imposed by traditional cointegration techniques. By distinguishing
between positive and negative shocks in institutional quality, green technologies, and natural
resources, the model offers a more nuanced understanding of how Algeria’s energy diversiﬁcation
responds to asymmetric and shock-driven dynamics.
    Furthermore, consistent with Ref.,47 the NARDL framework accommodates variables integrated of
order I(0), I(1), or a combination of both, removing the restrictive preconditions imposed by traditional
cointegration techniques. By distinguishing between positive and negative shocks in institutional qual-
ity, green technologies, and natural resources, the model offers a more nuanced understanding of how
Algeria’s energy diversiﬁcation responds to asymmetric and shock-driven dynamics.
    This study examines the long-term asymmetric connections between GT, IQI, and EDI while
controlling for the impact of GDP and natural resources in Algeria. The basic regression model
in this study can be formulated as follows:
                                   EDI = f (GT , IQI , NR, GDP, EC)                                                (1)

                       EDIt = B0 + B1 (GT )t + B2 (IQI)t + B3 (NR)t + B4 (Zt ) + εt                                (2)
   In this context, EDIt represents the energy diversiﬁcation index; while NRt refers to natural
resources, additionally GTt and IQIt denote the indices for green technologies and institutional
quality index respectively; the term Zt indicates the inﬂows of control variables which include
gross domestic product per capita and energy consumption.
   The ARDL approach allows for the integration of independent indicators to be integrated at different
degrees if the dependent variable is I (1). Eq. (2) presents the ARDL model utilized in this study.
   The relationship of cointegration among the variables is analyzed by comparing the test statistics
to the established lower and upper bounds, referred to as I(0) and I(1). The null hypothesis of no
cointegration is rejected when the test statistic exceeds the critical upper bound values. Equation
(2) presents the ARDL model utilized in this study.
ΔEDIt =α0 + α1 (GT + )t + α2 (GT − )t + α3 (IQI + )t + α4 (IQI − )t + α5 (NR+ )t + α6 (NR− )t + α7 (Zt )
                 
                 p−1                     
                                         p−1                     
                                                                 p−1                    
                                                                                        p−1
             +         γ i (ΔGT )t−1 +         ϑi (ΔIQI )t−1 +         σ i (ΔNR)t−1 +         φ(Δcontt )t−1 + εt
                 i=1                     i=1                     i=1                    i=1
                                                                                                                   (3)
12                                                                                Energy & Environment 0(0)


Table 2. Descriptive statistics.
                       EDI            GDP             GT               EC             IQI            NR
Mean                   3.743389       3708.378        19.92022         12664.97       −0.90257       22.93557
Median                 3.756845       3870.332        15.19689         12360          −0.87338       23.47094
Maximum                3.829182       4246.242        58.82353         16259.05       −0.60953       34.19132
Minimum                3.669049       2862.108        2.005156         9746.524       −1.16711       12.81918
Std. Dev.              0.041355       442.8928        12.00624         2214.73        0.135573       5.618854
Skewness               −0.162         −0.65558        0.974025         0.252893       −0.47253       0.226782
Kurtosis               1.658215       1.9913          3.343658         1.473186       2.64863        2.28218
Jarque-Bera prob.      0.000          0.000           0.000            0.000          0.000          0.000
Observations           109            109             109              109            109            109


   Δ denotes the ﬁrst difference operator, indicates the lag length, and et signiﬁes the disturbance term
characterized by zero mean and ﬁnite variance. The selection of the optimal lag length is determined
through the application of the Akaike Information Criteria (AIC). Pesaran et al.48 established the coin-
tegration relationship through the application of the F test (FA ) and t-test (t), as illustrated below
                                        HOA: B1 = B2 = B3 = B4                                            (4)

                                               HOB: B1 = 0                                                (5)
                                                              49
    Equations (3) and (4) were revised by McNown et al.            to develop a novel F-test (FB ) that inves-
tigates the null hypothesis, as presented in Equation (5).
                                           HOC: B2 = B3 = B4                                              (6)
    To establish the cointegration relationship, it is necessary to reject Eqs (4), (5), and (6). Nonetheless,
compared to the conventional ARDL methodology, this method produces more reliable results. The
variables’ degree of integration was disregarded by McNown et al..49 Nonetheless, in comparison to
the standard ARDL, this method yields more reliable empirical ﬁndings. Additionally, this approach
uses Fourier functions to identify structural changes. Therefore, there is no need for any further struc-
tural change tests or modiﬁcations to the estimated model regarding structural change. Equation (7)
illustrates the Fourier function introduced by Yilanci et al.,46 which accounts for structural changes
within the model.
                                     n                    n                
                                                   2πkt                    2πkt
                             d(t) =       ak sin          +      bk cos                                    (7)
                                     k=1
                                                    T        k=1
                                                                            T

   “where ‘n’ denotes the number of frequencies, π = 3.14, ‘k’ represents the number of selected spe-
cial frequencies, ‘t’ signiﬁes the trend, and ‘T’ indicates the sample size. Tables 2 and 3 show the
description of the variables used in the analysis and the descriptive statistics of the time series,
respectively.


Empirical results and discussion
Pree-diagnostic test
Aligned with the core research objectives, this study examines how GT, IQI, and NR inﬂuence EDI
in Algeria over the period from 1995Q1 to 2022Q4, while accounting for the effects of GDP and
Bergougui and Meziane                                                                                                      13


Table 3. Nonlinearity BDS test results.
                 Dimensions
Variables        m=2                m=3                 m=4                m=5                 m=6                Decisions
EDI              0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
 IQI             0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
 GT              0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
NR               0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
GDP              0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
EC               0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          0.0000∗∗∗           0.0000∗∗∗          Nonlinear
Note: ∗∗∗ denotes statistical signiﬁcance at the 1%, levels, based on the rejection of the null hypothesis of linearity.


EC. Before conducting empirical analysis, it is essential to assess potential nonlinearities and evalu-
ate the time series characteristics of the data. This ensures the proper choice of estimators and the
accurate speciﬁcation of the model.

Descriptive statistics. The descriptive statistics provide a comprehensive overview of the distribu-
tional properties of the variables in the dataset. The comparison between mean and median values
suggests that most variables are relatively symmetrically distributed, but skewness and kurtosis
values indicate deviations from normality. The skewness values show that GDP (−0.656) and
IQI (−0.473) are negatively skewed, implying that their distributions have longer left tails.
Conversely, GT (0.974) exhibits signiﬁcant positive skewness, indicating a heavier right tail
with a greater presence of higher values. Meanwhile, EDI (−0.162), EC (0.253), and NR (0.227)
display relatively low skewness, suggesting a more symmetrical distribution.
   The kurtosis values further reinforce the presence of non-normality in the dataset. Most vari-
ables, including EDI (1.658), GDP (1.991), EC (1.473), IQI (2.649), and NR (2.282), exhibit pla-
tykurtic distributions (kurtosis < 3), meaning they have ﬂatter tails and fewer extreme values
compared to a normal distribution. However, GT (3.344) has a kurtosis value slightly above 3, sug-
gesting a leptokurtic distribution with heavier tails and a higher concentration of extreme
observations.
   The Jarque-Bera test results provide deﬁnitive evidence against normality. With p values of
0.000 for all variables, the null hypothesis of normality is strongly rejected at any conventional sig-
niﬁcance level. This conﬁrms that the dataset exhibits non-normal distributions, necessitating fur-
ther consideration in econometric modeling. These ﬁndings collectively suggest that the data are
non-normal, which has implications for the choice of statistical methods and tests used in further
analysis. Non-parametric methods may be required to address the non-normality of the data.

Nonlinearity test. To assess the presence of nonlinearities in the dataset, the BDS test is employed.
The results presented in Table 2 reveal statistically signiﬁcant BDS statistics, conﬁrming the exist-
ence of nonlinear structures in the data. This ﬁnding suggests that relying exclusively on linear
models may lead to biased and unreliable estimates. Consequently, identifying these nonlinear char-
acteristics underscores the necessity of utilizing nonlinear methodologies to analyze the long-term
relationships among EDI, GT, IQI, and NR, GDP, and EC.

Unit root test. In this research, we applied the Augmented Dickey-Fuller (ADF) test to examine unit
roots, and Table 4 summarizes the results. The analysis reveals that the time-series variables, GT
14                                                                          Energy & Environment 0(0)


Table 4. ADF unit root tests.
                        At level                                     At ﬁrst difference
                        t-statistic                  Prob            t-statistic             Prob
EDI                     −1.5995                      0.4792          −2.5935                 0.0976*
GT                      −4.4454                      0.0017***       −5.3053                 0.0002***
IQI                     −1.6895                      0.4250          −3.8425                 0.0074***
NR                      −1.8281                      0.3650          −5.3053                 0.0002***
GDP                     −2.2325                      0.2001          −3.7370                 0.0094***
EC                      −0.3134                      0.9104          −5.3850                 0.0002***
Note: * p value <0.10; ** p value <0.05; *** p value <0.01.


and EDI, are stationary at level I(0), while IQI, NR, GDP, and EC are stationary at ﬁrst difference,
I(1).This highlights a combination of integration orders among the variables. Due to this mixed
integration order, the use of Fourier NARDL models is appropriate for our analysis.
Subsequently, we assess cointegration among the chosen variables to explore how GT, IQI, and
NR inﬂuence EDI in Algeria.


Fourier-NARDL bounds test
The Fourier NARDL bounds test is conducted to explore the possibility of cointegration among the
variables, as the results of the unit root tests indicate the potential for such relationships. Table 5
presents the ﬁndings of the Fourier NARDL bounds test, which reveals an F-statistic of
2.997976 with k = 8, exceeding the 10% upper bound (I(1) = 2.850), which provides evidence of
a long-run relationship at this signiﬁcance level. At the 5% level, however, the statistic falls
between the lower and upper bounds (2.110 < F < 3.150), making the results inconclusive, while
at the 1% level, it remains below the upper bound, indicating no deﬁnitive conﬁrmation of cointe-
gration. Collectively, these ﬁndings suggest a plausible long-term association among the variables
at the 10% signiﬁcance threshold. Consistent with previous studies, such as Gyamﬁ et al.,50 the
Fourier NARDL framework applied in this analysis offers robust insights into the long-run effects
of green innovation, government quality, and natural resources on Algeria’s Energy Diversiﬁcation
Index.


Asymmetric Fourier NARDL outcomes
After conﬁrming cointegration among the variables, we advance to evaluating the asymmetric
impacts of NR, IQI, and GT on EDI using NARDL framework. The long-run Fourier NARDL
results reported in Table 6 reveal a more complex relationship between Green Technologies
(GT) and the Energy Diversiﬁcation Index (EDI) than suggested in earlier drafts. A 1% positive
shock in GT is associated with a small but statistically marginal increase in EDI (coef. =
0.000889; p = 0.0906), indicating that incremental improvements in green technology deployment
tend to support diversiﬁcation in the long run. In contrast, a 1% negative shock generates a signiﬁ-
cant decline in EDI (coef. = −0.001544; p < 0.01), implying that setbacks in GT adoption—such as
delays in project execution, reduced ﬁnancing, or technological disruptions—can meaningfully
impede diversiﬁcation efforts. Based on these results, Hypothesis H2, which posits that green
Bergougui and Meziane                                                                               15


Table 5. Fourier NARDL bounds test.
F-statistic         k           Critical values         Lower bound I (0)            Upper bound I (1)
2.997976            8           10%                     1.850                        2.850
                                 5%                     2.110                        3.150
                                 1%                     2.620                        3.770



Table 6. Fourier NARDL long-run estimation results.
Variables                          Coef.                         Std. Err.                    p value
   positive shock
GT                                  0.000889                     0.000518                     0.090603
GTnegative shock                   −0.001544                     0.000416                     0.000400
IQIpositive shock                   0.255574                     0.104197                     0.016599
IQInegative shock                  −0.317228                     0.133206                     0.019888
NRpositive shock                    0.000375                     0.000259                     0.152973
NRnegative shock                   −0.002311                     0.000718                     0.001938
GDP                                −0.041816                     0.045121                     0.357149
EC                                 −0.082591                     0.129502                     0.525655
CointEq (− 1) *                    −0.212565                     0.032223                     0.000000


technologies exert a positive and signiﬁcant inﬂuence on energy diversiﬁcation, is partially con-
ﬁrmed, as the positive effect is marginal, whereas the negative effect is statistically signiﬁcant.
   This asymmetry reﬂects the structural sensitivity of diversiﬁcation pathways: while gradual GT
expansion provides incremental support to the energy mix, disruptions such as ﬁnancing delays,
stalled projects, or technological bottlenecks can impose disproportionate negative impacts. Such
dynamics align with the ﬁndings of Javed et al.,51 who underscore the nonlinear and vulnerability-
prone nature of GT’s contribution to diversiﬁcation in emerging economies. Furthermore, recent
empirical evidence52 indicates that in contexts where ﬁnancial mechanisms are weak or inconsist-
ent, renewable energy generation—and consequently energy diversiﬁcation—is highly vulnerable
to macroeconomic and policy-related shocks. These ﬁndings reinforce the notion that the deploy-
ment of green technologies alone is insufﬁcient without robust ﬁnancial and institutional support.
   Algeria’s recent experience illustrates this pattern. The progressive rollout of the 1 GW Tafouk 1
solar program demonstrates how sustained investment—despite initial implementation challenges
—can steadily reinforce diversiﬁcation outcomes. In contrast, recurrent delays in projects such as
the 400 MW Skikda wind farm exemplify how negative shocks can outweigh incremental gains,
exacerbating dependency on hydrocarbons. Strengthening institutional coordination and expanding
technological partnerships (e.g., through initiatives comparable to the Desertec Industrial Initiative)
can help mitigate these adverse effects and consolidate the long-term beneﬁts of GT integration.
   Transitioning from technological to institutional drivers, the analysis identiﬁes IQI as the most
inﬂuential factor shaping EDI. The empirical analysis reveals that a 1 % increase in IQI is associated
with a 0.255 % rise in EDI, highlighting how governance reforms and institutional strengthening
can substantially enhance the effectiveness of energy policies. Conversely, a 1 % decline in IQI cor-
responds to a 0.317 % reduction in EDI, demonstrating the vulnerability of energy diversiﬁcation
progress in the context of weakened institutional frameworks, these results conﬁrm H1, indicating
that institutional quality exerts a positive and signiﬁcant effect on energy diversiﬁcation. For
example, Algeria’s 2023 anti-corruption reforms at the state-owned energy giant Sonatrach
16                                                                           Energy & Environment 0(0)


unlocked approximately $300 million in misallocated funds, which were then redirected toward
developing solar-hybrid power plants in the Sahara. This real-world instance illustrates how stron-
ger institutional frameworks can create favorable conditions for renewable energy investments.
Conversely, a 1% decline in IQI reduces the EDI by 0.317%, highlighting the vulnerability of pro-
gress when governance falters—as evidenced by the 2022 bureaucratic delays that led to the post-
ponement of 600 MW of renewable energy tenders.
    These outcomes reﬂect that genuine energy diversiﬁcation depends not only on technological cap-
acity but critically on institutional integrity—notably governance quality, transparency, corruption con-
trol, and regulatory consistency. Recent empirical investigations reinforce this interpretation. For
instance, a global study of 87 countries (2011–2020) reveals that lower perceived corruption and higher
institutional quality signiﬁcantly increase public renewable energy investments, especially in
middle-income economies.27 Similarly, a panel study covering 49 African countries ﬁnds that institu-
tional quality, together with green innovation and renewable energy consumption, exerts a positive
long-term effect on green growth—indicating that institutional strength and green energy progress
are mutually reinforcing in the African context.28 Moreover, one of the most recent contributions
(2025) illustrates that institutional quality plays a critical moderating role: in environments where gov-
ernance is robust, green ﬁnancing and sustainable development objectives align more effectively, sug-
gesting that institutional quality magniﬁes the impact of green ﬁnance on sustainable outcomes.53
    These asymmetric effects underscore the critical importance of continuous institutional reforms.
The World Bank (2023) has noted that improvements in institutional transparency can catalyze a
20% surge in renewable energy investments, a ﬁnding echoed by Vatamanu et al.,54 who argue
that sustained governance upgrades, rather than one-off measures, are essential. Morocco’s ongoing
reforms, which facilitated the establishment of the Noor Solar Complex—Africa’s largest concen-
trated solar facility—serve as a compelling example of how continuous improvements in IQI can
drive energy diversiﬁcation.
    In summary, the evidence clearly indicates that robust institutional quality is a pivotal driver of
energy diversiﬁcation in Algeria. Strengthening governance through enhanced regulatory frame-
works, rigorous anti-corruption measures, and increased policy transparency is not only necessary
to attract foreign investments in renewable energy but also to ensure that Algeria can reduce its
dependence on hydrocarbons and advance its sustainable energy transition agenda.
    The ﬁndings reveal a nuanced dual role of NR in shaping Algeria’s EDI, with outcomes contin-
gent on the direction and magnitude of shocks. A 1% increase in NR corresponds to a 0.0003% rise
in EDI, while a 1% decrease results in a 0.002% decline, highlighting asymmetric impacts. These
statistically signiﬁcant coefﬁcients (at the 1% level) underscore the complexity of NR’s inﬂuence.
These results provide conditional support for H3, indicating that natural resource abundance can
negatively inﬂuence energy diversiﬁcation under adverse circumstances but may contribute posi-
tively when strategically reinvested. The positive effect may stem from hydrocarbon revenues being
strategically reinvested into renewable energy infrastructure, enabling diversiﬁcation. For instance,
windfall proﬁts from oil and gas exports—such as the $20 billion surplus in 2022—can fund renew-
able projects like the 4 GW Tafouk 1 solar initiative, demonstrating how resource wealth can cata-
lyze diversiﬁcation. Conversely, the adverse impact of NR reductions reﬂects Algeria’s entrenched
reliance on hydrocarbons: sudden declines in resource revenues, as seen during the 2020 oil price
crash, destabilize ﬁscal budgets, forcing austerity measures that divert funds from renewables to
essential services. This paradox mirrors the “resource curse” phenomenon, where resource abun-
dance can paradoxically hinder structural economic transformation.
    The International Monetary Fund’s (IMF) 2024 report ampliﬁes these concerns, emphasizing
Algeria’s macroeconomic fragility. Heavy hydrocarbon dependence—which constitutes over
Bergougui and Meziane                                                                              17


90% of export earnings and 60% of ﬁscal revenue—exposes the economy to volatile global energy
prices, undermining long-term planning for renewable energy projects. The IMF warns that without
diversiﬁcation, Algeria risks ﬁscal deﬁcits, reduced foreign exchange reserves, and diminished cap-
acity to buffer against external shocks, such as oil price crashes or geopolitical disruptions. This
vulnerability is compounded by global decarbonization trends, which threaten the long-term viabil-
ity of hydrocarbon-dependent economies.
    However, the study suggests NR could be repurposed as a strategic lever for diversiﬁcation. By
channeling resource revenues into sovereign wealth funds or targeted subsidies for renewable
energy, Algeria could mitigate ﬁscal volatility while accelerating its green transition. For example,
Norway’s success in using oil revenues to ﬁnance its Government Pension Fund Global—a vehicle
for sustainable investments—offers a replicable model. Policy frameworks that prioritize transpar-
ency, such as public oversight of resource revenue allocation, could further enhance accountability
and attract foreign investment in renewables. These insights align with Han et al.,55 who argue that
resource-rich nations can achieve energy diversiﬁcation through proactive governance. Their
research emphasizes that institutional reforms, such as anti-corruption measures and regulatory sta-
bility, are critical to ensuring resource wealth translates into sustainable development. By adopting
such strategies, Algeria could transform its natural resource wealth from a vulnerability into a cata-
lyst for a resilient, diversiﬁed energy system, balancing economic stability with climate impera-
tives. This dual approach—harnessing NR beneﬁts while mitigating risks—is essential for
navigating the global energy transition and achieving carbon neutrality targets. The conditional
nature of NR’s impact is supported by recent empirical research. Yıldırım et al.56 demonstrate
that in advanced emerging economies, NR interact with energy-transition and globalization factors
such that higher rents can bolster environmental welfare, but only under favorable structural and
institutional conditions. Similarly, studies of African countries reveal that renewable-energy capital
ﬂows are strongly inﬂuenced by institutional quality, suggesting that resource-rich economies can
only translate NR-derived revenues into sustainable energy investments when governance and
regulatory frameworks are sufﬁciently robust.57
    In summary, while NR presents both opportunities and challenges for Algeria’s energy diversi-
ﬁcation, its effective management through robust governance and strategic reinvestment can unlock
signiﬁcant potential. By learning from successful models like Norway’s and addressing the struc-
tural vulnerabilities highlighted by the IMF, Algeria can leverage its resource wealth to build a sus-
tainable and diversiﬁed energy future.
    While GDP and EC exhibit negative coefﬁcients (−0.0418 and −0.0825, respectively), their stat-
istical insigniﬁcance (p values > 0.1) suggests that economic growth and energy demand alone are
poor predictors of diversiﬁcation. This paradox arises because Algeria’s GDP growth remains teth-
ered to hydrocarbons; for instance, the 4.2% GDP growth in 2023 was driven by oil price rebounds
rather than renewable sector expansion. Similarly, rising energy consumption—such as the 8%
annual increase in household electricity demand—reﬂects reliance on fossil fuels for power gener-
ation, not diversiﬁcation. These ﬁndings challenge conventional growth-centric models and under-
score the primacy of institutional and technological factors. For example, despite Egypt’s lower
GDP per capita, its targeted solar subsidies and feed-in tariffs enabled it to achieve 20% renewable
penetration by 2023, outperforming Algeria’s 3%. This divergence highlights that policy quality,
not mere economic output, drives diversiﬁcation.
    The asymmetric effects across GT, IQI, and NR underscore that energy diversiﬁcation is not
merely a technical challenge but a governance and strategic prioritization issue. Positive shocks
in IQI and GT yield compounding beneﬁts, while negative shocks erode progress disproportion-
ately. Meanwhile, NR’s dual role as both a catalyst and a constraint highlight the need for
18                                                                         Energy & Environment 0(0)




Figure 2. CUSUM and CUSUM of square test.


institutional mechanisms to insulate diversiﬁcation efforts from commodity volatility. Algeria’s
path forward lies in leveraging its resource wealth to fund renewables while embedding governance
reforms that lock in long-term commitments—a lesson echoed in the UAE’s successful integration
of oil revenues into its Masdar City initiative. Future research should explore how regional colla-
borations, such as the African Continental Free Trade Area, could amplify these efforts through
shared grids and cross-border investments.


Diagnostic tests
The robustness and reliability of the Fourier model were examined through a comprehensive set of
diagnostic procedures. To assess the structural stability of the estimated parameters, both the
CUSUM and CUSUMSQ tests were performed. The CUSUM plot presented in Figure 2 demon-
strates that the cumulative sum of recursive residuals remains well within the 5% signiﬁcance
boundaries across the entire sample period, indicating the absence of structural breaks and conﬁrm-
ing parameter stability. This is particularly important given the long-term perspective of the analysis
and the sensitivity of Algeria’s energy diversiﬁcation trajectory to ﬂuctuations in institutional qual-
ity, technological progress, and natural resource dynamics. Likewise, the CUSUMSQ test further
validates the model’s stability, as its values consistently fall within the conﬁdence bands.
Together, these ﬁndings indicate that the Fourier speciﬁcation offers a robust framework for inves-
tigating the asymmetric shock effects on Algeria’s energy diversiﬁcation.
    In addition to stability tests, several speciﬁcation and residual diagnostics were performed to
ensure the internal validity of the model. As reported in Table 7, the Breusch–Godfrey LM test
yields an F-statistic of 0.128434 (p = 0.840738), providing strong evidence against the presence
of serial correlation. The Breusch–Pagan–Godfrey heteroskedasticity test returns an F-statistic of
1.379617 (p = 0.145868), indicating homoskedastic residuals. Moreover, the Ramsey RESET
test reports an F-statistic of 6.154560 (p = 0.1536), conﬁrming that the functional form of the model
is correctly speciﬁed. Collectively, these diagnostics verify that the estimated Fourier model is
stable, free from major econometric issues, and suitable for inference.
    The diagnostic evidence supports the model’s credibility, which is crucial for devising strategies
to diversify Algeria’s energy sector—a key objective given the nation’s heavy reliance on hydro-
carbons. Diversiﬁcation is vital not only for maintaining long-term economic stability but also for
mitigating the impact of external shocks such as volatile oil prices. A deeper analysis of the
Bergougui and Meziane                                                                              19


Table 7. Diagnostic result for the Fourier model.
Test                                                          F-statistic                  Prob.
Breusch-Godfrey Serial Correlation LM Test                    0.128433604                  0.840738
Heteroskedasticity Test: Breusch Pagan-Godfrey                1.379616789                  0.145868
Ramsey Reset Test                                             6.154560081                  0.1536



interrelationships among EDI, GT, IQI, NR, GDP, and EC is imperative. Such an understanding
will empower policymakers in Algeria to design targeted interventions that reduce dependency
on fossil fuels, reinforce governance structures, optimize resource allocation, and ultimately drive
a sustainable economic transition.



Robustness check
To validate the reliability of our ﬁndings, we conducted a series of robustness checks using alter-
native methodologies, variable speciﬁcations, and model conﬁgurations. These tests aim to assess
whether the core relationships between GT, IQI, NR, and EDI remain consistent under varying ana-
lytical conditions. Table 8 summarizes the results of these robustness analyses, juxtaposed against
the baseline ﬁndings for clarity.

   • Alternative estimation method (ARDL): We re-estimated the model using the autoregres-
     sive distributed lag (ARDL) approach to account for potential cointegration and dynamic
     interactions. The results (Column 2) align closely with the baseline in terms of coefﬁcient
     direction and signiﬁcance. For instance, the positive impact of GT shocks on LCF remains
     robust (0.001625*** vs. 0.000889* in the baseline), while negative NR shocks retain their
     adverse effects (−0.002241 vs. −0.002311***). Notably, EC became statistically signiﬁcant
     (−0.180110***), which was less pronounced in the baseline model.
   • Exclusion of control variables: To test for over-speciﬁcation, we excluded control variables
     such as GDP and EC (Column 4). The magnitudes and signiﬁcance of key coefﬁcients
     remained largely stable. For example, negative shocks to IQI retained their detrimental
     impact on LCF (−0.13063**), consistent with the baseline (−0.317228***). However, the
     exclusion slightly ampliﬁed the positive effect of GT shocks (0.00109** vs. 0.000889*),
     suggesting that control variables may partially mediate this relationship.
   • Inclusion of additional variables: Expanding the model to include population (POP) and
     urbanization (URB) (Column 5) introduced nuanced insights. While the negative effect of
     GT shocks (−0.001057***) and NR shocks (−0.007731***) persisted, the previously sig-
     niﬁcant adverse impact of IQI negative shocks became insigniﬁcant (−0.210661). This shift
     may reﬂect collinearity between institutional quality and added controls like urbanization,
     which itself showed a strong positive association with LCF (180.74196***).

   Despite minor variations in coefﬁcient magnitudes and signiﬁcance levels, the core ﬁndings
demonstrate remarkable resilience across methodologies. The consistency of GT and IQI effects,
coupled with the stability of NR’s adverse impacts, underscores the robustness of our conclusions.
These results afﬁrm that Algeria’s energy transition and institutional reforms are pivotal to enhan-
cing the EDI, even when accounting for model uncertainty and variable selection.
20                                                                                         Energy & Environment 0(0)


Table 8. Sensitive analysis results.
                 Baseline            Alternative estimation method Excluding control                    Additional
                 results             (ARDL)                        variables                            variables
Variables        (1)                 (2)                           (4)                                  (5)
GTpositive         0.000889*           0.001625***                           0.00109**                    0.000593**
   shock

GTnegative       −0.001544***        −0.001996***                          −0.00145***                  −0.001057***
   shock

IQIpositive        0.255574***         0.282068**                            0.10962**                    0.160538
   shock

IQInegative      −0.317228***        −0.162319***                          −0.13063**                   −0.210661
   shock

NRpositive         0.000375            0.001354                            −0.00006                       0.001753
   shock

NRnegative       −0.002311***        −0.002241                             −0.00288***                  −0.007731***
   shock

GDP              −0.041816           −0.622883                                /                          −0.438082
EC               −0.082591           −0.180110***                             /                          −0.351495**
POP               /                   /                                       /                          58.83239***
URB               /                   /                                       /                         180.74196***
Note: *, **, and *** indicate 10%, 5%, and 1% signiﬁcance levels, respectively. OLS: ordinary least squares.




Conclusion, policy implications, and future research
Conclusion
This study provides a comprehensive examination of the interplay between green technologies
(GT), institutional quality (IQI), and natural resources (NR) in shaping energy diversiﬁcation, as
measured by the Energy Diversiﬁcation Index (EDI). Algeria represents a particularly instructive
case for this analysis due to its status as a hydrocarbon-dependent, resource-rich country that faces
persistent challenges in transitioning to a diversiﬁed energy system. Over the period 1995/Q1–
2022/Q4, Algeria’s energy sector has been characterized by heavy reliance on oil and gas, institu-
tional bottlenecks, and uneven technological adoption, all of which have constrained the pace of
renewable energy development. By employing the Fourier Nonlinear Autoregressive Distributed
Lag (NARDL) model, the study rigorously investigates both long-term equilibrium relationships
and asymmetric short-term dynamics among IQI, GT, NR, and EDI. The Fourier NARDL bounds
test conﬁrms the presence of a robust long-term relationship, validating the relevance of these fac-
tors for guiding effective energy diversiﬁcation policy. The empirical results indicate that institu-
tional quality is the most inﬂuential driver of energy diversiﬁcation in Algeria. Speciﬁcally,
positive shocks in IQI and GT signiﬁcantly enhance the EDI, demonstrating that governance
reforms, regulatory improvements, and transparent policy implementation can substantially
increase the effectiveness of diversiﬁcation strategies. For instance, Algeria’s 2023 anti-corruption
initiatives at the state-owned energy company Sonatrach unlocked approximately $300 million in
previously misallocated funds, which were subsequently allocated to solar-hybrid projects in the
Sahara. This example illustrates how institutional strengthening can create tangible conditions
for renewable energy investment. In contrast, NR does not exert a statistically signiﬁcant direct
effect on EDI, indicating that natural resource endowments alone are insufﬁcient to drive
Bergougui and Meziane                                                                                  21


diversiﬁcation without complementary institutional and technological frameworks. Furthermore,
negative shocks in IQI, GT, or NR are associated with signiﬁcant declines in EDI, highlighting
the country’s vulnerability to governance weaknesses or technological stagnation. The control vari-
able analysis further underscores structural challenges in Algeria. Economic growth (GDP) and
energy consumption (EC) display a negative, although statistically insigniﬁcant, relationship
with EDI. This suggests that rising economic activity and energy demand often reinforce depend-
ence on hydrocarbons, limiting the pace of diversiﬁcation.


Policy implications
To transition from a hydrocarbon-dependent rentier economy to a diversiﬁed energy leader, Algeria
must adopt a comprehensive, multi-pronged strategy that addresses institutional, technological, and
resource-related challenges. The following policy recommendations are proposed:

   • Institutional Reforms: Strengthening governance frameworks is critical to foster energy diver-
     siﬁcation. Algeria should align its institutional practices with international standards, such as the
     Extractive Industries Transparency Initiative (EITI), to enhance transparency and accountability.
     Raising the Corruption Perceptions Index (CPI) score to 45/100 by 2030 could attract an esti-
     mated $2 billion annually in renewable energy investments, as projected by the World Bank.
     Additionally, streamlined regulatory frameworks and stable energy policies are essential to cre-
     ating an enabling environment for renewable energy projects.
   • Technological Leapfrogging: Accelerating the adoption of green technologies is vital for
     diversifying Algeria’s energy mix. Increasing research and development (R&D) spending
     to 1.5% of GDP by 2030, with a focus on emerging technologies such as solar desalination
     and green hydrogen, can position Algeria as a regional leader in renewable energy innov-
     ation. Pilot projects, such as the 1 GW Tafouk 1 solar plant, should be fast-tracked, with
     incentives for partnerships with global ﬁrms like Siemens Energy to facilitate knowledge
     transfer and capacity building.
   • Natural Resource Mobilization: Reallocating a portion of hydrocarbon revenues to renewable
     energy projects can mitigate ﬁscal vulnerabilities while supporting diversiﬁcation. Speciﬁcally,
     directing 20% of hydrocarbon revenues (approximately $8 billion annually) toward renewable
     energy infrastructure could enable Algeria to achieve its target of 15 GW of solar and wind cap-
     acity by 2035. This would reduce the share of oil in exports from 98% to 70%, enhancing eco-
     nomic resilience and reducing exposure to global energy price shocks.
   • Workforce Development: Building a skilled workforce is essential for sustaining energy
     diversiﬁcation efforts. Training 50,000 technicians in renewable energy maintenance by
     2030, leveraging vocational institutes and EU-funded programs like H2Atlas-Africa, can
     address skill gaps and ensure the successful implementation of renewable energy projects.


Limitations and future research
While this study contributes signiﬁcantly to the understanding of energy diversiﬁcation dynamics in
Algeria, it also highlights several limitations that warrant further investigation.

   • Single-Country Focus: The study’s exclusive focus on Algeria limits the generalizability of
     its ﬁndings. Future research should employ panel data analysis incorporating multiple Arab
22                                                                               Energy & Environment 0(0)


       or African countries to account for unobserved heterogeneity and region-siﬁc dynamics. This
       approach would provide a more comprehensive understanding of energy diversiﬁcation pat-
       terns and support the development of regionally tailored energy policies.
     • Regional Spillover Effects: The ﬁndings suggest potential spillover effects of GT, IQI, and
       NR on neighboring countries through mechanisms such as trade, investment, and regional
       cooperation. Future studies should adopt advanced methodologies, such as panel spatial
       regression models, to explore these broader regional dynamics. This would deepen under-
       standing of how these factors shape energy diversiﬁcation across Africa and contribute to
       the development of sustainable and integrated energy systems.
     • Broader Variable Inclusion: Expanding the scope of analysis to include additional variables,
       such as climate change policies, international trade agreements, and geopolitical factors,
       could provide a more holistic understanding of the drivers and barriers to energy
       diversiﬁcation.
     • Temporal Dynamics: Extending the study period and incorporating high-frequency data
       could enhance the robustness of the ﬁndings and provide insights into the evolving nature
       of energy diversiﬁcation over time.

   By addressing these limitations, future research can build on the ﬁndings of this study to develop
more nuanced and actionable insights, ultimately supporting the global transition toward sustain-
able and diversiﬁed energy systems.


ORCID iDs
Brahim Bergougui    https://orcid.org/0000-0002-2179-8854
Said Meziane   https://orcid.org/0009-0003-7448-8555


Funding
The authors received no ﬁnancial support for the research, authorship, and/or publication of this article.


Declaration of conﬂicting interests
The authors declared no potential conﬂicts of interest with respect to the research, authorship, and/or publica-
tion of this article.


References
 1. Bergougui B, Mehibel S and Boudjana RH. Asymmetric nexus between green technologies, economic
    policy uncertainty, and environmental sustainability: Evidence from Algeria. J Environ Manag 2024;
    360: 121172.
 2. Rockström J, Steffen W, Noone K, et al. A safe operating space for humanity. Nature 2009; 461:
    472–475.
 3. Pearson PJG and Foxon TJ. A low carbon industrial revolution? Insights and challenges from past techno-
    logical and economic transformations. Energy Policy 2012; 50: 117–127.
 4. Subhan M, Irfan M, Pan X, et al. Unveiling the dynamic impact of energy generation on economic sus-
    tainability in Canada: A roadmap towards sustainable development. J Cleaner Prod 2024; 434: 139783.
 5. Nibedita B and Irfan M. Energy mix diversiﬁcation in emerging economies: An econometric analysis of
    determinants. Renew Sustain Energy Rev 2024; 189: 114043.
Bergougui and Meziane                                                                                      23


 6. Shahbaz M, Siddiqui A, Ahmad S, et al. Financial development as a new determinant of energy diversi-
    ﬁcation: The role of natural capital and structural changes in Australia. Energy Economics 2023; 126:
    106926.
 7. Gozgor G and Paramati SR. Does energy diversiﬁcation cause an economic slowdown? Evidence from a
    newly constructed energy diversiﬁcation index. Energy Econom 2022; 109: 105970.
 8. Khan K, Su CW, Rehman AU, et al. Is technological innovation a driver of renewable energy? Technol
    Soc 2022; 70: 102044.
 9. Wang H and Wang M. Effects of technological innovation on energy efﬁciency in China: Evidence from
    dynamic panel of 284 cities. Sci Total Environ 2020; 709: 136172.
10. Zhang M, Imran M and Juanatas RA. Innovate, conserve, grow: A comprehensive analysis of techno-
    logical innovation, energy utilization, and carbon emission in BRICS. Nat Resour Forum 2024. https://
    doi.org/10.1111/1477-8947.12510
11. WBG. Morocco: Noor Ouarzazate Concentrated Solar Power Complex. In: Multilateral development
    banks’ collaboration: Infrastructure investment project briefs (Issue March 2017). 2018.
12. Uddin I, Ahmad M, Ismailov D, et al. Enhancing institutional quality to boost economic development in
    developing nations: New insights from CS-ARDL approach. Research in Globalization 2023; 7: 100137.
13. Samadi AH. Institutional quality and globalization in developing countries BT. In: Faghih N (ed.)
    Globalization and development: Economic and socio-cultural perspectives from emerging markets.
    Cham: Springer International Publishing, 2019, pp.135–161. https://doi.org/10.1007/978-3-030-14370-1_6.
14. Bouraiou A, Necaibia A, Boutasseta N, et al. Status of renewable energy potential and utilization in
    Algeria. J Cleaner Prod 2020; 246: 119011.
15. ISE. Fraunhofer-Ise-Annual-Report-2021–2022. https://www.ise.fraunhofer.de/content/dam/ise/en/
    documents/annual_reports/fraunhofer-ise-annual-report-2021-2022.pdf. 2021.
16. Sun Y, Razzaq A, Sun H, et al. The asymmetric inﬂuence of renewable energy and green innovation on car-
    bon neutrality in China: Analysis from non-linear ARDL model. Renewable Energy 2022; 193: 334–343.
17. Yingjun Z, Jahan S and Qamruzzaman M. Technological innovation, trade openness, natural resources,
    and environmental sustainability in Egypt and Turkey: Evidence from load capacity factor and inverted
    load capacity factor with Fourier functions. Sustainability 2024; 16: 8643.
18. Chang Y, Wei Y, Zhang J, et al. Mitigating the greenhouse gas emissions from urban roadway lighting in
    China via energy-efﬁcient luminaire adoption and renewable energy utilization. Resour Conserv Recycl
    2021; 164: 105197.
19. Nathaniel SP, Yalçiner K and Bekun FV. Assessing the environmental sustainability corridor: Linking
    natural resources, renewable energy, human capital, and ecological footprint in BRICS. Resour Policy
    2021; 70: 101924.
20. Yuan J, Yang R and Fu Q. Aspects of renewable energy inﬂuenced by natural resources: How do the
    stock market and technology play a role? Resour Policy 2023; 85: 103820.
21. ITA. Renewable Energy. International Trade Administration. https://www.trade.gov/country-
    commercial-guides/algeria-renewable-energy#:∼:text=For wind%2C. 2023.
22. Akroﬁ MM. An analysis of energy diversiﬁcation and transition trends in Africa. Int J Energy Water
    Resour 2021; 5: 1–12.
23. Pata U, Shahzad F, Fareed Z, et al. Revisiting the EKC hypothesis with export diversiﬁcation and eco-
    logical footprint pressure index for India: A RALS-Fourier cointegration test. Front Environ Sci 2022;
    10: 886515.
24. Rahman MM and Sultana N. Impacts of institutional quality, economic growth, and exports on renewable
    energy: Emerging countries perspective. Renew Energy 2022; 189: 938–951.
25. Mukhtarov S, Aliyev J, Borowski P, et al. Institutional quality and renewable energy transition: Empirical
    evidence from Poland. J Int Stud 2023; 16: 208–218.
24                                                                               Energy & Environment 0(0)


26. Dong Z, Tan C, Zhang W, et al. Are natural resources a blessing or a curse for renewable energy?
    Uncovering the role of regulatory quality and government effectiveness in mitigating the curse.
    Resour Policy 2024; 98: 105346.
27. Halldén F, Hultberg A, Ahmed A, et al. The role of institutional quality on public renewable energy
    investments. Renew Sustain Energy Rev 2025; 215: 115585.
28. Teklie DK and Yağ mur MH. The role of green innovation, renewable energy, and institutional quality in
    promoting green growth: Evidence from African countries. Sustainability 2024; 16: 6166.
29. Adebayo TS, Zambrano-Monserrate MA, Özkan O, et al. Analyzing the response of energy and major
    ﬁnancial assets to global ﬁnancial risks: A time-quantile analysis in a volatile global environment.
    Finance Res Lett 2025b; 86: 108458.
30. Olanrewaju VO, Adebayo TS and Uzun B. Navigating the impact of ESG sustainability uncertainty on
    fossil fuel prices: Evidence from wavelet cross-quantile regression. Appl Econ 2025: 1–17. https://doi.org/
    10.1080/00036846.2025.2535552
31. Zhao Q, Su C-W and Guo J-M. Does technological innovation promote renewable energy investment?
    Sage Open 2024; 14: 21582440241227760.
32. Rasheed MQ, Yuhuan Z, Ahmed Z, et al. Information communication technology, economic growth,
    natural resources, and renewable energy production: Evaluating the asymmetric and symmetric
    impacts of artiﬁcial intelligence in robotics and innovative economies. J Clean Prod 2024; 447:
    141466.
33. Doğ an B, Khalfaoui R, Bergougui B, et al. Unveiling the impact of the digital economy on the interplay of
    energy transition, environmental transformation, and renewable energy adoption. Res Int Bus Financ
    2025; 76: 102837.
34. Anser MK and Adebayo TS. AI-driven renaissance: Revolutionizing technology through industrial arti-
    ﬁcial intelligence in European economies. Technol Soc 2026; 84: 103129.
35. Adebayo TS and Olanrewaju VO. Journey toward affordable and modern energy: Role of income
    inequality and technological innovation. Environ Prog Sustain Energy 2025; 44: e14555.
36. Rana M. The role of natural resource rents in achieving sustainable development goals: Evidence from
    south Asian countries. Discov Environm 2025; 3: 84.
37. Adebayo TS, Ozsahin DU, Olanrewaju VO, et al. Decoding the environmental role of nuclear and renew-
    able energy consumption: A time-frequency perspective. Ann Nucl Energy 2025a; 223: 111660.
38. Murshed M. A regional appraisal of electricity accessibility determinants: The relevance of international
    remittances, clean energy, income inequality, and institutional quality. Environ Sci Pollut Res 2023; 30:
    51228–51244.
39. Bergougui B and Murshed SM. New evidence on the oil-democracy nexus utilising the varieties of dem-
    ocracy data. Resour Policy 2020; 69: 101905.
40. Bergougui B and Murshed SM. Revisiting the oil wealth-growth nexus: The role of economic norms in
    avoiding the oil curse. Extract Indust Soc 2021; 8: 100929.
41. Hwang YK and Venter A. The impact of the digital economy and institutional quality in promoting low-
    carbon energy transition. Renew Energy 2025; 238: 121884.
42. Saqib N, Ozturk I and Usman M. Investigating the implications of technological innovations, ﬁnancial
    inclusion, and renewable energy in diminishing ecological footprints levels in emerging economies.
    Geosci Front 2023; 14: 101667.
43. Sharif A, Baris-Tuzemen O, Uzuner G, et al. Revisiting the role of renewable and non-renewable energy
    consumption on Turkey’s ecological footprint: Evidence from Quantile ARDL approach. Sustain Cities
    Soc 2020; 57. doi:10.1016/j.scs.2020.102138
44. Kathuria K and Kumar N. Are exports and imports of India’s trading partners cointegrated? Evidence
    from Fourier bootstrap ARDL procedure. Empir Econ 2022; 62: 1177–1191.
Bergougui and Meziane                                                                                    25


45. Syed QR, Apergis N and Goh SK. The dynamic relationship between climate policy uncertainty and
    renewable energy in the US: Applying the novel Fourier augmented autoregressive distributed lags
    approach. Energy 2023; 275: 127383.
46. Yilanci V, Bozoklu S and Gorus MS. Are BRICS countries pollution havens? Evidence from a bootstrap
    ARDL bounds testing approach with a Fourier function. Sustain Cities Soc 2020; 55: 102035.
47. Shin Y, Yu B and Greenwood-Nimmo M. Modelling asymmetric cointegration and dynamic multipliers
    in a nonlinear ARDL framework BT. In: Sickles RC and Horrace WC (eds) Festschrift in honor of Peter
    Schmidt: Econometric methods and applications. New York: Springer, 2014, pp.281–314. https://doi.
    org/10.1007/978-1-4899-8008-3_9.
48. Pesaran MH, Shin Y and Smith RJ. Bounds testing approaches to the analysis of level relationships.
    J Appl Econom 2001; 16: 289–326.
49. McNown R, Sam CY and Goh SK. Bootstrapping the autoregressive distributed lag test for cointegration.
    Appl Econ 2018; 50: 1509–1521.
50. Gyamﬁ BA, Sarpong SY and Bein MA. The contribution of the anthropogenic impact of biomass utilization
    on ecological degradation: Revisiting the G7 economies. Environ Sci Pollut Res 2021; 28: 11016–11029.
51. Javed A, Shabir M, Rao F, et al. Effect of green technological innovation and ﬁnancial development on
    green energy transition in N-11 countries: Evidence from the novel method of moments quantile regres-
    sion. Renew Energy 2025; 242: 122435.
52. Hassan H, Xiaoying W, Sampene AK, et al. The socio-economic and technological dimensions of energy
    transition: Do ﬁnancial mechanisms enhance renewable energy generation? Energy Strategy Rev 2025;
    62: 101895.
53. Sun X, Meng Z, Zhang X, et al. The role of institutional quality in the nexus between green ﬁnancing and
    sustainable development. Res Int Bus Finance 2025; 73: 102531.
54. Vatamanu A-F, Onofrei M, Cigu E, et al. Renewable energy consumption, institutional quality and life
    expectancy in EU countries: A cointegration analysis. Energy Sustain Soc 2025; 15: 2.
55. Han Z, Zakari A, Youn IJ, et al. The impact of natural resources on renewable energy consumption.
    Resources Policy 2023; 83: 103692.
56. Yıldırım DÇ, Esen Ö, Urgan NN, et al. Pathways to environmental welfare: Linking energy transitions,
    globalisation, natural resource rents, and load capacity factor in the advanced emerging countries.
    Environ Dev Sustain 2025. https://doi.org/10.1007/s10668-025-06719-x
57. Dube A and Horvey SS. Institutional quality and renewable energy capital ﬂows in Africa. Future Bus J
    2023; 9: 55.
