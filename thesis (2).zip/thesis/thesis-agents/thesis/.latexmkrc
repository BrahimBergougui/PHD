$pdf_mode = 1;
$bibtex_use = 2;
$out_dir = 'build';
$pdflatex = 'pdflatex -interaction=nonstopmode -file-line-error %O %S';
