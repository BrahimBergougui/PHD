                                                                        Technology in Society 83 (2025) 103021


                                                                       Contents lists available at ScienceDirect


                                                                       Technology in Society
                                                            journal homepage: www.elsevier.com/locate/techsoc




Industrial robots for a sustainable future: Uncovering the asymmetric
effects of AI on ecological quality in G7 economies
Brahim Bergougui a,b,c,*
a
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
b
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
c
  College of Business & Economics, Qatar University, Doha, Qatar




A R T I C L E I N F O                                        A B S T R A C T

Keywords:                                                    Artificial intelligence is increasingly recognized for its potential to enhance ecological quality by streamlining
Artificial intelligence                                      production processes, reducing environmental emissions, and improving ecological monitoring systems. How­
Ecological quality                                           ever, the influence of artificial intelligence on ecological quality is neither uniform across different stages of
Industrial robots
                                                             technological adoption nor consistent across national contexts. The central objective of this study is to investigate
Quantile‒On‒Quantile regression
G7
                                                             the asymmetric and stage-specific effects of artificial intelligence adoption on ecological quality within the Group
                                                             of Seven (G7) economies over the period from January 2000 to December 2019. Employing a novel multivariate
                                                             quantile-on-quantile regression framework, this research examines how varying intensities of artificial intelli­
                                                             gence adoption impact different levels of ecological outcomes. The results indicate that artificial intelligence
                                                             exerts a modest positive effect on ecological quality during early stages of adoption, a more substantial effect
                                                             during transitional phases, and a significantly positive influence at advanced stages of integration. To address
                                                             endogeneity concerns—particularly reverse causality and omitted variable bias—this study utilizes an instru­
                                                             mental variable multivariate quantile regression approach, using lagged values of artificial intelligence adoption
                                                             as an instrument. The findings are validated through robustness checks using kernel regularized least squares and
                                                             standard quantile regression techniques. The results also reveal considerable variation across countries, high­
                                                             lighting the necessity for country-specific and stage-aware policy interventions. Accordingly, the study offers
                                                             detailed, actionable recommendations tailored to the adoption stage of each G7 member to maximize the
                                                             ecological benefits of artificial intelligence. This research provides a rigorous, causally grounded analysis of how
                                                             artificial intelligence can be harnessed to advance environmental sustainability in highly industrialized
                                                             economies.




1. Introduction                                                                                     studies suggest that AI’s environmental benefits may intensify as
                                                                                                    adoption matures, necessitating a nuanced analytical approach beyond
    The recent adoption of artificial intelligence (AI) in manufacturing                            traditional methods. This complex relationship demands careful exam­
has transformed global production methods. AI technologies, which                                   ination through sophisticated methodological frameworks that can
include machine learning, robotics, and intelligent automation, have                                capture nonlinear interactions and conditional effects. One promising
demonstrated remarkable capabilities in optimizing operational effi­                                aspect of AI is its potential to enhance EQ through improved efficiency
ciency,    enhancing productivity, and reshaping              traditional                           (Zhao et al., 2024). AI machines are designed for accuracy and consis­
manufacturing paradigms. These technologies not only have the po­                                   tency, which reduces errors and waste during production. Their
tential to alter economic structures but also significantly impact                                  continuous operation can increase output while lowering energy con­
ecological systems (Ding et al., 2024). The relationship between AI                                 sumption compared to human-operated processes. This efficiency could
adoption and ecological quality (EQ) is intricate and asymmetric,                                   lead to reduced energy use and carbon dioxide (CO2) emissions, thereby
varying across levels of adoption and influenced by country-specific                                lessening the environmental impact of manufacturing (Bergougui and
factors like economic structures and technological maturity. Prior                                  Aldawsari, 2024; Bergougui, Mehibel, & Boudjana, 2024; Rasheed et al.,



    * International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands.
      E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com.

https://doi.org/10.1016/j.techsoc.2025.103021
Received 25 February 2025; Received in revised form 5 May 2025; Accepted 18 July 2025
Available online 21 July 2025
0160-791X/© 2025 The Author. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui                                                                                                                Technology in Society 83 (2025) 103021


2024; Doğan et al. 2025a, 2025b). However, the environmental impli­                   uniquely suited to this investigation. Unlike conventional models, it
cations of AI integration must be carefully examined. The                              examines how specific quantiles of AI adoption (e.g., early, transi­
resource-intensive production of AI components can create significant                  tional, mature stages) influence distinct quantiles of EQ (e.g., low,
ecological challenges (Dong et al., 2024). Additionally, the growing                   moderate, high environmental performance). This approach not only
issue of electronic waste from outdated AI systems poses a serious sus­                uncovers hidden nonlinearities but also identifies critical thresholds
tainability concern. A thorough assessment of AI’s impact on EQ re­                    where AI transitions from having marginal to transformative
quires an evaluation of these environmental costs. Balancing                           ecological effects. For instance, it allows policymakers to discern
technological advancement with ecological responsibility is essential for              whether AI’s environmental benefits accelerate disproportionately at
a future where AI can thrive. This involves understanding both the im­                 higher adoption levels or stagnate due to rebound effects. By
mediate efficiency benefits and the broader ecological costs associated                bridging methodological and contextual gaps, this study advances
with the entire life-cycle of AI (Jin & Chen, 2024). Empirical evidence                theoretical and empirical understanding of AI’s role in shaping
suggests that the relationship between AI and EQ is complex, with                      ecological outcomes, providing a foundation for targeted,
varying outcomes observed across different countries and stages of                     stage-specific policies in technologically advanced economies.
technological adoption.                                                              • Second, the study addresses a geographical and contextual gap in
    Elucidating the complex, stage-dependent relationship between AI                   literature. While AI’s environmental impacts are global, most
adoption and ecological quality within the world’s most advanced                       empirical analyses have focused on individual nations or regions
economies is of paramount importance. The G7 nations (Canada, France,                  without considering the unique economic and technological profiles
Germany, Italy, Japan, the United Kingdom, and the United States) are                  of leading AI adopters. This paper narrows its scope to the G7
not only at the vanguard of AI innovation and industrial implementation                economies-Canada, France, Germany, Italy, Japan, the United
but also grapple with significant environmental policy challenges and                  Kingdom, and the United States-which collectively account for over
commitments. Understanding how AI influences their ecological tra­                     60 % of global AI investments and possess outsized influence on
jectories is crucial for developing evidence-based strategies that                     ecological trends. These nations represent ideal case studies due to
leverage technological progress for sustainable development goals. As                  their advanced technological infrastructure, high industrial AI inte­
these nations collectively account for a substantial share of global AI                gration, and divergent policy frameworks. By focusing on this group,
investment and possess significant influence over international envi­                  the study provides insights into how AI–EQ dynamics manifest in
ronmental norms and technological standards, insights derived from                     economies where AI adoption is both widespread and strategically
their experiences hold considerable relevance for global sustainability                prioritized, offering lessons for global sustainability efforts.
efforts. This research is motivated by the urgent need to provide poli­
cymakers and industry stakeholders within these bellwether economies                   The remainder of this study is organized as follows: Section 2 pro­
with nuanced, actionable intelligence to navigate the complexities of AI            vides a comprehensive review of the relevant literature, drawing on
deployment, ensuring that technological advancement aligns with,                    previous empirical studies. Section 3 outlines the theoretical framework,
rather than undermines, ecological integrity and long-term environ­                 details the research data, and describes the selected econometric
mental objectives.                                                                  methodology. Section 4 presents and analyzes the empirical findings.
    The principal objective of this study is to empirically investigate the         Section 5 includes a discussion of the results. Finally, Section 6 offers
asymmetric effects of artificial intelligence on ecological quality within          concluding insights and suggests potential directions for future research
the G7 economies. Specifically, this research seeks to ascertain how the            endeavors.
nature and magnitude of this relationship evolve across different
quantiles of both AI intensity and ecological quality. Utilizing monthly            2. Background literature
data spanning the period from January 2000 to December 2019, the
study employs multivariate quantile-on-quantile regression (MQQR)                       The burgeoning field of AI and its environmental implications have
approach. The central research question guiding this inquiry is: How                garnered significant scholarly attention in recent years. This review
does the impact of varying levels of AI adoption (representing early, transi­       synthesizes key findings from diverse studies exploring how techno­
tional, and mature stages) influence different levels of ecological quality         logical advancements, particularly AI and industrial robots, influence
across the G7 economies? Subsidiary questions involve exploring poten­              various environmental metrics. These studies offer insights into the
tial heterogeneity in this relationship among G7 member states and                  potential benefits and challenges posed by these technologies in
identifying critical thresholds where the ecological impact of AI may               addressing climate change and promoting sustainable development. A
shift significantly.                                                                groundbreaking multi-country analysis by Chen et al. (2022) explored
    This study advances literature on AI and sustainability in twofold              the impact of AI on the EF across 72 countries from 1993 to 2019. Their
ways.                                                                               mediation model revealed that AI reduced EF through mechanisms such
                                                                                    as time savings, green employment, and energy upgrades, although it
 • First, while prior research has explored the environmental implica­              also increased EF by driving industrial activity. Overall, AI’s dominant
   tions of AI, methodological limitations have constrained a nuanced               effect was a reduction in EF, with more pronounced benefits observed in
   understanding of the asymmetric and nonlinear dynamics between                   countries with higher levels of human capital and economic develop­
   these variables. Conventional approaches, such as ordinary least                 ment, particularly within OECD economies and at higher EF levels (Li
   squares (OLS) and standard quantile regression, often fail to capture            et al., 2022). analyzed how AI, as measured by the application of in­
   the heterogeneous effects of AI adoption across different stages of              dustrial robots, affected the environment and economy in 35 countries
   implementation or ecological conditions. To address this gap, this               from 1993 to 2017. They reported that AI reduced carbon intensity by
   paper introduces a methodological innovation by employing the                    increasing productivity, optimizing production structures, and fostering
   multivariate quantile-on-quantile regression (MQQR) approach, in­                innovation, with sectoral and country-specific variations. Significant
   tegrated with nonparametric techniques. This hybrid method,                      reductions were noted in the manufacturing, agriculture, and energy
   inspired by Liu, Rasool, et al. (2024), enables a granular analysis of           sectors, especially in developed nations. The study highlighted a
   how varying intensities of AI adoption (low, medium, high quantiles)             dual-channel mechanism for reducing carbon intensity, involving the
   interact with distinct levels of ecological quality. By examining these          mediation of green total factor productivity and energy intensity, along
   relationships across quantiles, the study reveals whether the AI–EQ              with the moderation of absorptive capacity. With a focus on the United
   interaction is linear, threshold-dependent, or context-specific-a                States, Saqib et al. (2023) explored the interplay between digital
   dimension overlooked in earlier work. The MQQR method is                         financial inclusion, energy consumption patterns, and the EF. Using the

                                                                                2
B. Bergougui                                                                                                                 Technology in Society 83 (2025) 103021


QARDL and ARDL methods, their findings corroborated the EKC hy­                     through improved processes and technologies. For instance, Tu et al.
pothesis, suggesting that economic growth and nonrenewable energy                   (2024) reported that a mere 1 % improvement in industrial intelligence
use contribute to a larger footprint (Lv et al., 2022). examined the                within Chinese cities led to a significant 2.747 % increase in local carbon
impact of intelligent industrial manufacturing on industrial CO2 emis­              emission performance. Their study also identified mechanisms and
sions in China from 2000 to 2017. Their research highlights the effec­              spatial spillover effects associated with this improvement. Similarly,
tiveness of AI in reducing CO2 from primary fossil fuel sources, with a             Zhou et al. (2024) demonstrated that industrial robots significantly
stronger impact observed in high-polluting industries. Striking a balance           reduce pollution emission intensity by improving energy efficiency and
between industrial development and E-Q is a pressing challenge (Song                pollution control technologies, with varying effectiveness across
et al., 2023) addressing this concern through their study of Chinese firms          different regions of China.
from 2000 to 2013. Their findings demonstrate that adopting automa­                     The positive influence of AI extends to corporate sustainability as
tion and intelligent technologies, particularly in response to stricter             well. Chen et al. (2024) reported that AI promotes environmental
environmental regulations, can significantly improve environmental                  governance and social responsibility within companies. Their study also
management. Research suggests that increased robot adoption leads to                identified factors such as internal and external pressures that moderate
pollution reduction through multiple pathways. These include improved               this relationship and explored potential pathways through which AI
production efficiency, process modifications that minimize waste, and               contributes to corporate sustainability. Uriarte-Gallastegi et al. (2024)
the implementation of end-of-pipe pollution control measures. Focusing              conducted a multisector analysis that examined how AI facilitates the
on the regional impact of AI in China, Ding et al. (2023) employed a                transition to a circular economy model, focusing on energy manage­
spatial Durbin model to analyze data from 30 provinces between 2006                 ment. Their findings confirmed that AI positively influences both energy
and 2019. Their research provided strong evidence that AI development               efficiency and emissions reduction, with variations depending on the
effectively reduces CO2 emissions across regions, regardless of spatial             specific application and sector. In addition to these regional applica­
factors. Additionally, the study identified both the technical and struc­           tions, Qing et al. (2024) explored the broader impact of AI (powered
tural aspects of AI as key contributors to this reduction. Interestingly, the       industrial robotics) on CO2 emissions in economies promoting green
positive effect of AI on CO2 reduction was found to be even stronger in             initiatives. Their research using data from 2008 to 2021 revealed that AI
central and western China than in eastern China. Similarly Chen et al.              significantly reduces CO2 emissions within these economies.
(2023), investigated the impact of AI strategies on CO2 emissions in 282                Xie and Wang (2024), Yin and Zeng (2024), and Liu, Yang, & Zhang
Chinese cities between 2008 and 2019. By employing a                                (2024) emphasized the need for further exploration. Xie and Wang
quasi-experimental design and difference-in-differences modeling                    (2024) investigated the nonlinear carbon reduction effect of AI via panel
approach, their research confirmed that AI implementation effectively               data from 30 Chinese provinces between 1997 and 2019. Their results
reduces CO2 emissions and advances progress toward carbon neutrality.               show that AI primarily helps decrease carbon emissions, with regional
Notably, the study emphasizes the crucial role of green technology                  variations in effectiveness. The study also revealed that improving AI
adoption and industrial upgrades in achieving carbon neutrality. Addi­              development levels and other factors can amplify the marginal carbon
tionally, the effectiveness of AI strategies was found to vary depending            reduction effect of AI. Yin and Zeng (2024) examined the relationships
on factors such as time, location, resource availability, and city size.            among industrial intelligence, technological innovation, economic
Shifting focus to city-level analysis Yu et al. (2023), explored how AI             growth, and environmental quality via provincial data from China from
influences CO2 emissions. Their research, which utilized industry data              2006 to 2020. Their findings indicate that industrial intelligence drives
from the IFR between 2010 and 2018, revealed significant CO2 re­                    both economic growth and environmental quality, whereas technolog­
ductions in cities implementing AI technologies. The study attributes               ical innovation primarily promotes economic growth. The study also
these benefits to AI’s ability to improve energy and green technology               revealed significant regional variations in these relationships. Liu, Yang,
efficiency. Interestingly, the positive influence of AI on environmental            and Zhang (2024) explored the nonlinear effect of industrial robot ap­
outcomes was particularly pronounced in large urban centers, advanced               plications (IRAs) on carbon emissions via regional panel data in China
manufacturing hubs, and designated low-carbon zones, suggesting that                from 2006 to 2017. They reported an inverted U-shaped relationship
specific contextual factors can significantly amplify the environmental             between IRAs and carbon emissions, with IRAs accelerating the advance
benefits of AI technologies. By examining the influence of AI across                of the turning point by improving factor allocation efficiency and opti­
broader geographic scales Zhang & Zhu (2023), investigated its impact               mizing industrial structures. The carbon emission reduction effect of
on CO2 emissions in the USA, China, and Japan via IFR data from 2006                IRAs was found to depend on factors such as the scale of the highly
to 2021. Their findings, which are based on OLS regression models,                  skilled labor force, digital endowment, and environmental regulation
confirm the significant positive influence of industrial intelligence on            intensity. Table A.1. provides an overview of existing studies on the
CO2 reduction in these economies. Additionally, the study highlights                interplay between AI and EQ.
that this positive effect intensifies with increasing robot density, sug­
gesting a dose-dependent relationship between AI adoption and envi­                 2.1. Research gap
ronmental improvement. Nuances in the environmental impact of AI
have been explored by Zhong et al. (2024). Applying Q-R and panel                       A critical review of the extant literature reveals a dominant focus on
smooth transition regression methods, their research analyzes AI’s                  gauging the overall influence of AI on ecological quality (EQ), yet sig­
impact on CO2 emissions in 66 countries from 1993 to 2019. Their                    nificant gaps persist in understanding the nuanced dynamics of this
findings reveal mixed effects, with AI exhibiting both positive and                 relationship.
negative influences on CO2 depending on factors such as the national
income level and industrial structure. Notably, the positive effect of AI            • Overreliance on average effects and overlooking quantile-level
on CO2 reduction weakens in countries with larger secondary industries.                analysis: Previous studies have focused primarily on the overall
Interestingly, the study also identified a demographic influence, with                 impact of AI on EQ, assuming a symmetric and linear relationship
AI’s environmental benefits being more pronounced in countries with                    between the two. However, this approach may overlook crucial de­
older populations.                                                                     tails, such as the nonlinear and asymmetric dynamics inherent in
    Recent research has painted a promising picture of the potential of AI             these relationships. The influence of AI on EQ could vary signifi­
as an environmental boon. Studies by (Chen et al., 2024; Tu et al., 2024;              cantly depending on the level of AI adoption or the severity of
Uriarte-Gallastegi et al., 2024; Zhou et al., 2024) have highlighted AI’s              ecological degradation.
capacity to enhance corporate environmental practices, improve energy                • Methodological Limitations: Prior research often favors panel data
efficiency, reduce urban carbon emissions, and bolster pollution control               analysis over time series data. While panel data capture cross-

                                                                                3
B. Bergougui                                                                                                              Technology in Society 83 (2025) 103021


   sectional variation across countries, challenges such as selecting            enhancing productivity and resource efficiency, which may contribute
   appropriate econometric models to account for potential heteroge­             to a reduction in environmental impact (Dosi, 1988).
   neity and unobserved country-specific effects remain. Additionally,               The notion of the rebound effect, which highlights a potential
   panel data analysis can be susceptible to biases from omitted vari­           paradox associated with increased resource efficiency, is essential.
   ables or measurement error, and its findings may not be easily                While advancements such as AI may lead to improvements in resource
   generalizable to individual economies.                                        utilization within specific processes, the consumption and demand of
 • Limited environmental measures: The current body of research on AI            resources might paradoxically increase (Caballero et al., 2024; Sorrell &
   primarily investigates its impact on economic factors such as green           Dimitropoulos, 2008). This phenomenon is crucial for recognizing the
   total factor productivity and labor productivity (Zhao et al., 2022).         unintended environmental consequences of deploying AI in the G7 na­
   While a nascent body of research delves into the connection between           tions. The efficiency gains from AI might be offset by an increase in
   AI and environmental outcomes, such as CO2 emissions (Bergougui,              overall resource consumption, potentially negating the initial environ­
   2024a; Yin & Zeng, 2024; Zhong et al., 2024) and the EF (Chen et al.,         mental benefits (Saunders, 1992). The framework also acknowledges the
   2022 and Liu, Rasool, et al., 2024) significant gap exists regarding          influence of corporate social responsibility on AI adoption and imple­
   the influence of AI on LCF. This lacuna exists at both the national and       mentation. Corporations in nations with advanced AI integration are
   regional levels, with a dearth of investigations into how AI interacts        increasingly aligning their deployment strategies with corporate social
   with LCF development in countries within the G-7 or other economic            responsibility objectives (Carroll & Shabana, 2010). This translates to
   groupings, as well as individual nations.                                     the utilization of AI in ways that promote environmental sustainability
 • Neglected G7 context: Despite the G7’s significant role in global             while simultaneously pursuing economic growth. This alignment be­
   energy consumption, carbon emissions, and AI adoption, there is               tween AI and corporate social responsibility can serve as a powerful
   insufficient research examining the AI-environmental quality rela­            driver for the adoption of more sustainable practices within these in­
   tionship within these influential economies. Understanding these              dustries. Furthermore, by integrating corporate social responsibility
   dynamics is crucial for global sustainable development efforts.               considerations, the framework acknowledges the potential influence of
                                                                                 corporations in shaping both market behaviors and the development of
    This study seeks to advance the existing body of knowledge by                regulatory policies related to AI deployment. By incorporating both
investigating the asymmetric relationship between AI and EQ within the           corporate social responsibility and rebound effect considerations, the
G-7 economies. It employs the Q‒Q methodology, enabling a nuanced                theoretical framework facilitates a comprehensive understanding of the
analysis of the relationship between AI and EQ across the data’s                 multifaceted relationship between AI deployment and EQ in the G7
different quantiles. This approach reveals how AI’s influence on EQ              context. This approach acknowledges the potential for both positive and
varies at different levels of economic advancement and under conditions          negative environmental consequences associated with AI while also
of environmental pressure. Consequently, a more comprehensive un­                recognizing the role of corporations in shaping the trajectory of AI
derstanding of the interplay between these variables is achieved. The G-         development and its ultimate impact on environmental quality. The
7, as prominent global consumers of energy, emitters of carbon, and              regulatory landscape within G7 nations significantly influences both the
foremost in AI adoption, have the capacity to significantly shape global         deployment and the environmental impact of AI. This framework delves
ecological patterns. This makes them compelling case studies, yet they           into the interplay between government policies, including incentives
have received limited scholarly attention in this specific context.              and regulations, and their influence on the adoption of environmentally
Elucidating these linkages can offer valuable insights into the G-7’s            responsible AI practices (Jacobsson & Johnson, 2000).
pursuit of sustainable development goals.
                                                                                 3.1.2. Integration of MQQR approach
3. Methodology                                                                      While this theoretical framework provides a comprehensive foun­
                                                                                 dation for understanding AI’s EQ impact in G7 nations, empirical evi­
3.1. Theoretical framework                                                       dence suggests a more complex dynamic at play. This complexity
                                                                                 manifests in an asymmetric relationship between AI and ecological
    The theoretical framework guiding this study is anchored in the              quality. This asymmetric relationship implies that the interactions be­
interplay between ecological economics, innovation theory, and distri­           tween AI and ecological quality vary across different scenarios, thresh­
butional heterogeneity, explicitly designed to address the non-linear,           olds, and distributional levels, rather than following a uniform or linear
asymmetric relationship between AI adoption and environmental qual­              pattern. The quantile-on-quantile regression approach is particularly
ity (EQ) in G7 nations. By integrating quantile-on-quantile regression           well-suited to examine these complex, non-linear relationships for
(QQR) as both a methodological and conceptual tool, this framework               several key reasons.
interrogates how varying intensities of AI deployment—across different
quantiles of ecological quality—shape environmental outcomes, thereby             • Distributional heterogeneity: Traditional mean-based analyses often
aligning with the study’s core research questions: How does the nature              mask important variations across the distribution of both AI adoption
and strength of the relationship between AI adoption and Environmental              and EQ. The quantile-on-quantile approach allows us to examine
Quality vary across different quantiles of AI adoption in G7 countries.             how different levels of AI adoption (from low to high quantiles)
                                                                                    affect different levels of EQ (from low to high quantiles).
3.1.1. Theoretical foundational theories                                          • Non-Linear dependencies: The theoretical mechanisms suggest that
    The theory of ecological modernization suggests that technological              AI’s impact on EQ is likely non-linear and conditional on the level of
progress and innovations can foster more sustainable practices (Weber &             both AI implementation and existing environmental conditions.
Weber, 2020). For the G7 nations, the implementation of AI signifies a              Quantile regression techniques capture these non-linearities by
major advancement toward more environmentally efficient production                  examining relationships at various points across the joint
methods. The Environmental Kuznets Curve (EKC) theory, which de­                    distribution.
scribes an inverted U‒shaped relationship between economic develop­               • Asymmetric effects: The four identified mechanisms (Time-Saving
ment and environmental degradation (Grossman & Krueger, 1995), can                  Effect, Green Employment Effect, Energy Upgrading Effect, and In­
be applied to G7 nations to assess whether a rise in AI adoption initially          dustrial Driving Effect) suggest asymmetric impacts that conven­
increases the environmental impact before ultimately leading to im­                 tional regression methods would average out, potentially obscuring
provements. Additionally, technological innovation plays a vital role in            important dynamics across the distribution.
the integration of AI, with advancements such as AI potentially

                                                                             4
B. Bergougui                                                                                                                    Technology in Society 83 (2025) 103021


 • Threshold effects: Our theoretical framework posits that AI adoption           3.2. Data
   may exhibit threshold effects on EQ, with benefits potentially
   accelerating after reaching certain levels of implementation matu­             3.2.1. Sample selection and data sources
   rity. Quantile-on-quantile regression can identify these potential                 This study delves into the impact of AI on EQ in G7 countries, which
   thresholds across the distribution.                                            are known for their extensive use of AI in manufacturing. This study
                                                                                  strategically targets the G7 nations—powerhouses of innovation driving
    Having established the non-linear nature of this relationship, it be­         global technological advancements. These countries, including France,
comes crucial to understand the specific mechanisms through which AI              Germany, Italy, Japan, the United Kingdom, and the United States, are
influences ecological quality and drives EQ. Several distinct mechanisms          not only early adopters of AI but also integrate it extensively across
have been identified that help explain these asymmetrical effects.                cutting‒edge industries. This extensive integration makes them ideal
                                                                                  case studies for understanding the potential environmental ramifica­
 • Time-saving effect: AI-driven industrial robots improve efficiency             tions of AI.
   by reducing the need for manual labor, especially in high-labor-                   This study utilizes time-series data spanning from January 2000 to
   intensive roles. This reduction in labor hours indirectly decreases            December 2019 (2000m1-2019m12). The terminal year of 2019 was
   the overall energy consumed in industrial processes, leading to                selected due to the availability constraint of AI data, which extends only
   enhanced ecological quality and accelerated EQ. The time-saving                to 2020. Data for this research were sourced from the International
   effect thus contributes to better environmental conditions, particu­           Federation of Robotics (IFR)1 and the Global Footprint Network (GFN)2
   larly in industries with high automation potential (Acemoglu et al.,           websites. To enhance the robustness of our analysis, annual data were
   2020; Acemoglu & Restrepo, 2020).                                              converted to monthly observations using the quadratic match-sum
 • Green employment effect: By replacing traditional industrial jobs              method. This methodological approach aligns with established prac­
   with roles focused on green technologies, AI fosters employment in             tices in peer-reviewed literature (Bergougui, 2024a, 2024c, 2024b;
   sectors like agriculture and services, which generally support better          Bergougui and Aldawsari, 2024; Bergougui, Mehibel, & Boudjana,
   ecological quality and EQ efforts. Additionally, the shift to green jobs       2024), ensuring analytical reliability and comparability with existing
   encourages innovation in sustainable practices, indirectly improving           research. The complete dataset used in this study is available in the
   environmental conditions and biodiversity (Acemoglu & Restrepo,                supplementary material (see supplementary data)
   2018; Cecere & Mazzanti, 2017).                                                    The variable details are displayed in Table 1.
 • Energy upgrading effect: AI and robotics improve the integration
   and management of renewable energy sources, reducing reliance on               3.2.2. Dependent variable
   fossil fuels. By enhancing energy efficiency and supporting renew­                 Within the context of this research, the EQ serves as the investigated
   able energy uptake, AI plays a role in improving ecological quality            dependent variable. Owing to its comprehensive nature, LCF is
   and advancing EQ. The energy upgrading effect thus represents a                employed as a proxy for EQ. This metric mitigates the shortcomings
   positive environmental impact, especially in countries or industries           inherent in employing CO2 emissions, the ecological footprint (EF), and
   prioritizing clean energy (Boza & Evgeniou, 2021; DeCanio, 2016).              the environmental performance index as indicators of ecological quality
 • Industrial driving effect: While industrial robots enhance produc­             (Sun et al., 2024). The utility of CO2 as a proxy for ecological quality has
   tivity and reduce costs, they also drive increased production and              been subject to critique because of its exclusive focus on energy‒related
   energy consumption. This boost in industrial output can lead to                emissions, neglecting a comprehensive spectrum of environmental at­
   higher pollutant emissions and resource extraction, potentially                tributes. Conversely, while ecological footprints offer a broader
   slowing EQ progress. This industrial driving effect creates asymme­            perspective on environmental pressures, they consider only consump­
   try, as it tends to counteract the positive environmental impacts of           tion patterns, disregarding the critical supply side, specifically the
   the other mechanisms (Furman & Seamans, 2018).                                 Earth’s biocapacity. Biocapacity, which represents the planet’s ability to
                                                                                  regenerate resources and assimilate waste, is indispensable for a com­
    These mechanisms highlight that the impact of AI on EQ is context-            plete assessment of environmental quality. To holistically evaluate
dependent, varying with economic priorities, regulatory environments,             environmental services, Siche et al. (2010) introduced the EQ, which
and the types of employment AI supports. The quantile-on-quantile                 synthesizes human demands on environmental resources with the
regression approach allows us to capture these nuanced relationships              Earth’s regenerative capacity, providing a more comprehensive measure
by examining how the entire conditional distribution of EQ outcomes
responds to changes across the entire distribution of AI implementation.
    Based on the theoretical foundations, identified mechanisms, and the          Table 1
methodological advantages of quantile-on-quantile regression, this                The list of variables.
study develops a more nuanced understanding of the relationship be­                 Variable         Symbols   Explanation        Measurement     Data sources
tween AI and EQ across different adoption stages. This leads to the
                                                                                    Dependent        EQ        Ecological         Ratio           Global Footprint
following two hypotheses.                                                             variable                 quality                            Network
                                                                                    Independent      AI        Artificial         Count           International
 • H1: At early stages of AI adoption (low quantiles), there exists a                 variable                 intelligence                       Federation of
   significant but weak positive relationship between AI and EQ.                                                                                  Robotics
                                                                                    Control          GDP       Gross Domestic     Per capita      World bank
 • H2: At mature stages of AI adoption (high quantiles), there exists a               variables                Product
   significant and strong positive relationship between AI and EQ.                                   FDI       Foreign Direct     % of GDP
                                                                                                               Investment
   These hypotheses reflect the dynamic nature of AI’s environmental                                 EC        Energy             % of GDP
                                                                                                               Consumption
impact, suggesting that while initial EQ benefits may be modest, the
potential for substantial emissions reductions increases significantly as
AI implementation matures. The quantile-on-quantile regression
approach allows us to test these hypotheses by examining the relation­
ship at various points across the joint distribution of AI adoption and EQ,
providing a more comprehensive understanding than traditional                       1
                                                                                        International Federation of Robotics: https://ifr.org/.
methods could offer.                                                                2
                                                                                        Global Footprint Network: https://www.footprintnetwork.org/.

                                                                              5
B. Bergougui                                                                                                                Technology in Society 83 (2025) 103021


of EQ (Uche et al., 2024).                                                         distinct types of information.
    EQ is calculated as the ratio of biocapacity to the ecological footprint
(                                )
             Biocapacity (BC)                                                       • The total stock of operational industrial robots.
  LCF = Ecological Footprint (EF) .                                                 • The number of newly installed robots.
   where BC represents the Earth’s ability to regenerate resources and
absorb waste, and EF quantifies human demand for environmental re­                     For the purposes of this study, the stock of industrial robots is
sources, both of which are measured in global hectares (Gha). This ratio           employed as the proxy variable. This choice is advantageous because it
analysis offers a holistic evaluation of environmental pressure (EF) and           represents a concrete measure, thereby reducing the ambiguity associ­
the Earth’s ability to withstand it (BC).                                          ated with defining AI and making the findings more comprehensible
                                                                                   (Ding et al., 2024). This methodological framework enables exploration
 • LCF > 1: This indicates a sustainable ecological situation. The BC              of the relationship between AI implementation and EQ, thereby deep­
   exceeds the EF, meaning that the Earth’s regenerative capacity can              ening understanding of the ecological impacts associated with techno­
   manage human demands.                                                           logical advancements in industrial automation. Fig. 2 depicts the
 • LCF < 1: This signifies an unsustainable situation. EF surpasses BC,            evolution of AI implementation in the G7 countries from 2000 to 2019.
   highlighting environmental stress and exceeding the Earth’s ability
   to replenish resources.
 • EQ = 1 signifies a critical threshold at which the system is balanced           3.3. Empirical methodology
   on the edge of ecological sustainability.
                                                                                       In examining the relationship between AI and EQ across G7 nations,
    By combining supply (BC) and demand (EF) into a single, dimen­                 this investigation employs a comprehensive methodological framework,
sionless metric, EQ directly reflects the ecological carrying capacity             as illustrated in Fig. 3.
across various environmental domains (air, water, and soil). Its wide
recognition and ability to provide insights into the long‒term sustain­            3.3.1. Brock-Dechert-Scheinkman test
ability of human‒environment interactions (Yurtkuran & Pata, 2024)                     The BDS test serves as a sophisticated nonparametric statistical
make LCF an ideal proxy for EQ in this study, offering a nuanced un­               procedure for detecting nonlinear serial dependencies within time series
derstanding of the balance between human consumption and ecosystem                 data (Broock et al., 1996). This methodological framework is particu­
resilience (Bergougui, 2025b; Bergougui & Meziane, 2025). Further­                 larly pertinent in examining relationships that conventional linear
more, its applicability in evaluating the effectiveness of AI initiatives in       models might overlook. The test’s distinguishing characteristics include
mitigating ecological pressures strengthens the justification for its              its nonparametric nature, which eliminates the need for specific distri­
deployment in this context. Fig. 1 illustrates the EQ of the G7 countries          butional assumptions, and its capacity to examine dependencies across
during the period from 2000 to 2020.                                               multiple temporal dimensions. Unlike traditional linear approaches that
                                                                                   typically focus on first-order lag relationships, the BDS test implements a
3.2.3. Independent variables                                                       comprehensive approach through product moments calculation, which
   In this investigation, AI is designated as the independent variable.            quantifies deviations from independence across multiple lagged terms
The study utilizes the number of industrial robots as a proxy for AI, a            (Escot et al., 2023). This test is particularly crucial in examining the
method that is both widely adopted and recognized within the field                 relationship between AI deployment and EQ, where relationships may
(Bergougui, 2025a; Yang & Liu, 2024). Notably, the IFR publishes data              exhibit nonlinear dependencies across multiple temporal dimensions,
categorized by country and industry, with each sector providing two                thus providing justification for more sophisticated econometric
                                                                                   techniques.




                      Fig. 1. The evolution of EQ trends in G7 economies from 2000 to 2019. Source: Global Footprint Network (2024).

                                                                               6
B. Bergougui                                                                                                              Technology in Society 83 (2025) 103021




                        Fig. 2. The evolution of AI trends through industrial robot applications in G7 economies from 2000 to 2019.




                                                        Fig. 3. Flowchart of the empirical analysis.


3.3.2. Quantile augmented dickey-fuller test                                     3.3.3. Quantile cointegration test
    Given the non-normal distribution exhibited in the dataset, this study           After establishing the stationarity of the data series, a cointegration
implements the quantile augmented dickey-fuller (QADF) test, following           test is essential to identify any long-term relationships between the
Adebayo and Özkan (2024). The QADF test extends traditional unit root           variables. This study utilizes the quantile cointegration (QC) test by Xiao
testing by examining stationarity properties across the entire probability       (2009) to overcome limitations of traditional cointegration tests, which
distribution, rather than relying solely on mean-based inferences. The           assume constant cointegration relationships across the entire distribu­
empirical procedure consists of three key steps.                                 tion. The QC test enables a more flexible analysis by allowing cointe­
                                                                                 gration to vary across different quantiles, capturing any heterogeneity in
 • Construction of quantile sequences spanning from 0.05 to 0.95, with           the long-run relationship that might be missed in conventional ap­
   0.05 incremental steps, following Li et al. (2015).                           proaches. Xiao’s QC method addresses this by examining the dynamic
 • Application of the augmented dickey-fuller testing framework across           associations between quantiles of both independent and dependent
   these specified quantiles                                                     variables, providing insights into how these variables relate across
 • Visual representation and analysis of the resultant test statistics           various distribution levels. This approach helps avoid estimation biases
   across the distributional spectrum                                            that might arise when assuming a uniform long-term relationship across
                                                                                 quantiles, adapting instead to the conditional distribution. If the QC
   This methodology tests the null hypothesis of non-stationarity                test’s estimated value exceeds the critical value at any quantile level, it
against the alternative of stationarity at each quantile, providing a            confirms cointegration between the series. Upon establishing cointe­
more nuanced understanding of the series’ stochastic properties                  gration, the MQQR approach can then be applied to explore these re­
compared to conventional unit root tests.                                        lationships in greater depth.



                                                                             7
B. Bergougui                                                                                                             Technology in Society 83 (2025) 103021


3.3.4. Multivariate quantile-on-quantile regression approach                   4. Results
    This section delineates the methodological framework of the MQQR
approach developed by Sim and Zhou (2015), which is employed to                4.1. Preliminary outcomes
examine the distributional relationship between AI and EQ in G7 na­
tions. The MQQR approach extends traditional quantile regression (QR)          4.1.1. Summary statistics
by integrating non-parametric estimation, enabling researchers to                  To initiate empirical analysis, descriptive statistics for the key vari­
examine how different quantiles of an independent variable impact the          ables are presented in Table 2. This overview offers insights into the
conditional quantiles of the dependent variable.                               characteristics of both AI and EQ. The Jarque‒Bera and ARCH‒LM tests
                                                                               indicate that the model residuals are neither normally distributed nor
3.3.4.1. Rationale for Choosing MQQR. The selection of MQQR over               homoscedastic. Skewness and kurtosis statistics suggest potential
other econometric techniques, such as OLS and standard QR, is justified        asymmetry in the data, whereas Fig. 4’s kernel density plots confirm the
by several key advantages.                                                     leptokurtic nature of the distributions. The nonnormal distributions of
                                                                               both AI and EG, as evidenced by the Jarque–Bera test, underscore the
 • Enhanced distributional analysis: Unlike traditional regression             need for a robust estimation technique. MQQR is particularly suitable
   methods that focus solely on mean effects or QR that examines the           for analyzing data that deviate from normality.
   impact of the independent variable’s mean on the dependent vari­
   able’s quantiles (for instance Liu et al. (2021)) employed a conven­        4.1.2. Outcomes of BDS linearity test
   tional quantile regression analysis), MQQR provides a more                      The study employs the BDS test (Table 3) to examine potential
   comprehensive framework. This approach helps investigate the                nonlinear or asymmetric relationships within the data. Following Baum
   entire dependence structure between variables by using different            et al. (2021), this test determines whether time series data exhibit linear
   quantiles of their respective distributions (Doko Tchatoka et al.,          or nonlinear interdependence. The results indicate nonlinear structures
   2019).                                                                      for all the variables, given the nonnormal distributions and nonlinear
 • Robustness and flexibility: MQQR is particularly well-suited for            nature of AI and EQ, as confirmed by the descriptive statistics and the
   analyzing asymmetric environments and accommodating structural              BDS test. The null hypothesis of linear interdependence is rejected in
   breaks. The method’s robustness stems from its resistance to outliers       favor of nonlinearity. These findings justify the use of nonlinear
   and its effectiveness with both cross-sectional and time series data.       methods, prompting the employment of MQQR to analyze the impact of
   This flexibility helps enhance data variability while minimizing            AI on EQ across different quantiles.
   multicollinearity issues that often plague traditional approaches
   (Sun et al., 2023).                                                         4.1.3. Outcomes of quantile augmented dickey-fuller
 • Methodological advantages: The method overcomes key limitations                 The graphical representations presented in Figs. 5 and 6 provide
   of both OLS and traditional quantile regression. (i) While conven­          empirical support for the stationarity of the first-differenced series of
   tional quantile regression may occasionally overlook uncertainty’s          both AI and EQ across the majority of their distributions. This conclusion
   role in variable relationships, MQQR provides a more nuanced                is substantiated by the observation that the computed t-statistics fall
   analysis by considering heterogeneity within associations. (ii) It          below the critical threshold of − 2.89 (at the 5 % significance level,
   addresses the "curse of dimensionality" common in non-parametric            denoted by the blue horizontal line) for a predominant proportion of
   estimation by incorporating local regression principles (Shahbaz            quantiles τ.
   et al., 2018), allocating greater emphasis to immediate neighbors
   around each data point. (iii) The approach enables examination of           4.1.4. Outcomes of quantile cointegration
   relationships at different quantiles by effectively combining linear            The data utilized in this analysis are time series, indicating that the
   regression with non-parametric estimation techniques.                       variables possess a temporal dimension. Given that the data are non-
                                                                               stationary and exhibit first-order integration, the paper can proceed
    The MQQR framework models EQ as a γ-quantile distribution, where           with cointegration tests to evaluate the long-run relationship between AI
the conditional quantile is expressed as a function of AI and covariates       and EQ. Cointegration analysis is crucial as it helps determine whether a
(GDP, FDI, EC). This specification, as outlined by Bergougui, Boudjana,        stable long-term relationship exists between these variables. If cointe­
et al. (2024), enables the disentangling of complex quantile-specific          gration is confirmed, it implies that the model can be accurately speci­
interactions. By incorporating moderating variables like energy con­           fied and interpreted (Xu & Lin, 2020). The coefficients from the
sumption, income, and FDI, MQQR elucidates how these factors jointly           cointegration models relating EQ and AI are shown in Table 4. Overall,
shape outcomes, offering policymakers insights into context-specific           our findings suggest a long-run interrelationship between EQ and AI.
AI-EQ synergies. Equation (1) formalizes this relationship as follows:         Additionally, the quantile cointegration results presented in Table 4
                                                                               further reinforce the presence of a nonlinear relationship between EQ
EQt = βθ (AIt ) + Xʹt ∧θ + μθt                                      (1)        and AI across each G7 country.

where.
                                                                               4.2. Outcomes of the quantile-on-quantile regression
                                                 th
 • θ denotes the conditional distribution at the θ quantile of AI;
                                                                                   The preliminary data analysis, including descriptive statistics and the
 • EQt represents the ecological quality of the country in period t;
                                                                               BDS test, indicates that the data series exhibits non-normal distribution,
 • AIt indicates the number of industrial robots at time t.
                                                                               heavy tails, and significant nonlinearity. These features indicated that a
 • Xt is the control variable (GDP, FDI, EC) with ∧ as the associated
                                                                               MQQR approach would be the most appropriate, as it can effectively
   coefficient for the θ th quantile of EQ; and
                                                                               capture the asymmetric effects of AI across different quantiles of EQ. The
 • μ represents the quantile error term.
                                                                               empirical findings for G7 countries, as shown in Fig. 7, illustrate the
 • βθ represents the influence of the θ quantile of AI.
                                                                               nuanced relationship between AI and EQ at varying stages of AI adop­
                                                                               tion. Each country shows unique characteristics in how AI adoption
   Though, prior information on βθ is unknown, as the relationship
                                                                               influences environmental outcomes across early, transitional, and
between AI and EQ must be estimated directly from the data sample. The
                                                                               advanced stages of implementation, as evidenced by specific quantile
MQQR estimation was conducted using the econometric software tools
                                                                               measurements.
R-Studio and MATLAB 2024a.
                                                                                   Canada’s relationship between AI adoption and ecological quality

                                                                           8
B. Bergougui                                                                                                                     Technology in Society 83 (2025) 103021


Table 2
Descriptive statistics and distributional properties of AI and EQ.
  Panel A: AI

  Economy                 Descriptive statistics                                        Distributional properties

                          Mean              S.D          Min.            Max.           Skewness             Kurtosis     Jarque‒Bera Stats           ARCH‒LM (1)

  Canada                  0.646             0.123        0.385           0.850          0.106                1.984        10.77***                    238.48***
  France                  0.863             0.014        0.824           0.892          ‒0.891               3.387        33.22***                    238.48***
  Germany                 0.992             0.021        0.948           1.026          ‒0.189               2.182        33.22***                    238.41***
  Italy                   0.914             0.013        0.876           0.938          ‒1.040               3.806        8.13**                      238.67***
  Japan                   1.058             0.006        1.047           1.068          ‒0.394               1.544        49.74***                    238.53***
  United Kingdom          0.804             0.013        0.780           0.833          0.755                2.627        27.40***                    236.20***
  United States           1.004             0.029        0.947           1.052          ‒0.191               2.076        24.20***                    238.32***
  Panel B: EQ
  Economy                 Descriptive statistics                                        Distributional properties
                          Mean              S.D          Min.            Max.           Skewness            Kurtosis      Jarque‒Bera Stats           ARCH‒LM (1)
  Canada                  0.156             0.006        0.144           0.171          0.368               2.535         5.686**                     232.99***
  France                  0.040             0.002        0.037           0.044          0.100               2.273         9.426***                    223.03***
  Germany                 0.026             0.001        0.024           0.030          0.226               2.141         25.010***                   228.60***
  Italy                   0.016             0.001        0.014           0.018          0.100               1.431         14.110***                   233.42***
  Japan                   0.011             0.001        0.010           0.012          0.275               1.948         7.390***                    232.09***
  United Kingdom          0.018             0.002        0.015           0.024          0.229               2.272         26.510***                   233.57***
  United States           0.035             0.003        0.031           0.041          ‒0.039              1.374         5.686**                     232.99***

Note. Significance levels of 1 % and 5 % are denoted by * and **, respectively. The skewness and kurtosis values describe the data distribution, whereas the Jarque‒
Bera test assesses the normality of the model’s parameters. The ARCH‒LM(1) test checks for potential heteroscedasticity in the model.




                                                        Fig. 4. Kernel density distribution plots of AI and EQ.


follows a distinctive U-shaped pattern. The strongest positive ecological              and turn negative in the lower quantiles (0.15–0.20) during the early-
impacts are observed at the extreme quantiles (both lowest and highest),               transitional phase. However, a significant improvement occurs from
while the middle quantiles show weaker effects. This quantile distribu­                lower-middle to upper-middle quantiles (0.25–0.85), showing sustained
tion demonstrates that both early-stage AI implementation (lower                       positive impacts. Beyond the 0.85 quantile, representing the most
quantiles) and advanced adoption (higher quantiles) yield the most                     advanced stage, France experiences diminishing returns, suggesting an
substantial environmental benefits, while the transitional phase shows                 optimal effectiveness during the middle phases of implementation.
relatively reduced effectiveness.                                                          Italy’s AI adoption journey shows a progressive strengthening
    France exhibits a complex adoption trajectory, with strong positive                pattern across the quantile distribution. The early adoption stage
ecological impacts at the very lowest quantiles (0.05–0.10), represent­                (quantiles 0.05–0.15) begins with weak positive ecological impacts,
ing the early stage of AI implementation. The benefits sharply decline                 followed by a decrease around the median quantiles (0.20–0.45) during


                                                                                   9
B. Bergougui                                                                                                                Technology in Society 83 (2025) 103021


Table 3
BDS test outcomes.
  Country                     Variable             Dimension 2             Dimension 3              Dimension 4            Dimension 5                Decision

  Canada                      AI                   64.38*                  68.89*                   74.53*                 82.68*                     Nonlinear
                              EQ                   47.36*                  50.19*                   53.7*                  58.88*                     Nonlinear
  France                      AI                   35.63*                  37.86*                   40.59*                 44.54*                     Nonlinear
                              EQ                   54.26*                  57.23*                   60.95*                 66.46*                     Nonlinear
  Germany                     AI                   63.4*                   67.98*                   73.72*                 82.32*                     Nonlinear
                              EQ                   65.6*                   68.63*                   72.21*                 77.69*                     Nonlinear
  Italy                       AI                   33.59*                  35.74*                   38.4*                  42.21*                     Nonlinear
                              EQ                   70.01*                  75.13*                   81.63*                 90.9*                      Nonlinear
  Japan                       AI                   55.56*                  59.22*                   63.79*                 70.41*                     Nonlinear
                              EQ                   57.84*                  61.14*                   65.26*                 71.31*                     Nonlinear
  United Kingdom              AI                   44.43*                  47.12*                   50.46*                 55.37*                     Nonlinear
                              EQ                   66.2*                   69.6*                    73.71*                 79.89*                     Nonlinear
  United States               AI                   64.77*                  69.44*                   75.31*                 83.75*                     Nonlinear
                              EQ                   72.14*                  77.15*                   83.48*                 92.61*                     Nonlinear

Note. Significance level of 1 % is denoted by *.




                                                      Fig. 5. Outcomes of the QADF unit root test for AI.


the transitional period. The effects strengthen significantly at higher             at the 0.15 quantile. During the intermediate stage, this positive influ­
quantiles (0.50–0.95), indicating that Italy’s ecological benefits from AI          ence gradually weakens, reaching its lowest at the 0.35 quantile. As
technology become more pronounced as the country achieves greater                   Germany progresses to advanced AI adoption, the impact strengthens
technological sophistication.                                                       again, reaching its maximum at the 0.80 quantile, before showing
    Germany exhibits varying AI impacts across different adoption                   diminishing returns in the very advanced stage (0.90–0.95 quantiles),
stages. The country experiences a pronounced positive effect at lower               suggesting optimal effectiveness during both early and advanced
quantiles, peaking at 0.15 quantile during early adoption. The positive             implementation stages, but with diminishing returns at the highest
influence then gradually weakens, reaching its lowest point at the 0.35             levels of adoption.
quantile during the transitional phase. A second surge occurs with the                  Japan shows an N-shaped pattern of AI impacts across adoption
effect strengthening again and peaking at the 0.80 quantile, before                 stages. The early adoption stage (0.05 quantile) shows weak impacts.
declining at the 0.90–0.95 quantiles, suggesting optimal effectiveness              The early-intermediate stage (0.20 quantile) demonstrates significant
during both early and advanced implementation stages, but with                      positive effects, followed by weaker impacts in the middle stage (0.40
diminishing returns at the highest levels of adoption.                              quantile). The advanced adoption stage (0.95 quantile) shows the
    Germany exhibits varying AI impacts across different adoption                   strongest positive impacts on ecological quality, indicating that Japan’s
stages. The early adoption phase shows strong positive effects, peaking             AI-ecological benefits are maximized at the most advanced stage of


                                                                              10
B. Bergougui                                                                                                                     Technology in Society 83 (2025) 103021




Fig. 6. Outcomes of the QADF Unit Root Test for EQ. Note: Three horizontal lines indicate critical values: green (− 2.58) for 10 %, blue (− 2.89) for 5 %, and red
(− 3.49) for 1 % significance levels. Rejection of the null hypothesis occurs at any quantile τ where the t-statistic falls below the blue line (− 2.89, 5 % signifi­
cance level).



Table 4
Outcomes of the QC test (AI and EQ).
  Country                                Coefficients              Supτ |Vn(τ)|                 C1                          C5                         C10

  Canada: AI vs. EQ                      ρ                           59785.82                     58023.613                  33753                      25412.189
                                         γ                          188458.89                    181549                      93404.695                  74510.578
  France: AI vs. EQ                      ρ                           23639.451                    18562.488                   9297.7031                  7602.793
                                         γ                          291549.94                    221602.05                   80392.984                  51214.211
  Germany: AI vs. EQ                     ρ                           45788.82                     41529.43                   25958.732                  19914.531
                                         γ                          904669.44                    815166.88                  445102.19                  325556.81
  Italy: AI vs. EQ                       ρ                           15528.112                    21516.543                  13138.893                  10029.654
                                         γ                          487242.53                    606517.25                  278459.88                  187350.72
  Japan: AI vs. EQ                       ρ                           39889.035                    36899.344                  20479.496                  15565.23
                                         γ                         1876333.4                    1780593                     871767.25                  568694
  United Kingdom: AI vs. EQ              ρ                            5610.6782                    7152.8486                  3849.1387                  3183.9512
                                         γ                          158756.94                    209267.66                   96670.609                  65205.305
  United States: AI vs. EQ               ρ                           14850.313                    13730.592                   9298.0107                  7365.7939
                                         γ                          206451.83                    199692.59                  115639.84                   78877.32

Note: T statistics are calculated across 19 evenly spaced quantiles ranging from 0.05 to 0.95. The table presents estimates of the supremum norm (ρ and γ) alongside
critical values for significance levels of 1 % (C1), 5 % (C5), and 10 % (C10).



implementation.                                                                        (0.15–0.60 quantiles), these effects decrease. The advanced adoption
    The United Kingdom presents a W-shaped pattern across its AI                       phase (0.65–0.80 quantiles) shows rapid improvement, followed by
adoption journey. The early stage (0.05 quantile) shows strong positive                declining effects in the very advanced stage (0.85–0.95 quantiles),
effects, followed by a sharp decrease (0.10–0.15 quantiles). The early-                suggesting optimal ecological benefits occur before reaching the highest
intermediate stage (0.20–0.35 quantiles) shows rapid improvement,                      levels of AI implementation.
followed by another decline in the intermediate stage (0.40–0.70                           Across all G7 countries, the quantile analysis reveals several common
quantiles). The advanced adoption stage shows steady improvement up                    themes in the relationship between AI adoption stages and ecological
to the 0.95 quantile, suggesting that mature AI implementation consis­                 quality. While most countries demonstrate overall positive impacts of AI
tently enhances ecological quality.                                                    on ecological outcomes, the effectiveness varies significantly across
    The United States demonstrates varying impacts across its AI                       different quantiles representing various stages of implementation.
adoption stages. The early adoption phase (0.05–0.10 quantiles) shows
particularly strong positive effects. During the intermediate stage


                                                                                  11
B. Bergougui                                                                                                              Technology in Society 83 (2025) 103021




                                                                Fig. 7. MQQR estimations



 • Advanced stages (higher quantiles) generally yield stronger positive           4.3. Robustness analysis
   impacts, though several countries show evidence of diminishing
   returns at the highest quantiles.                                                  To assess the reliability of MQQR parameter estimates, the study
 • Transitional stages (middle quantiles) often present variable im­              employed three robustness checks designed to evaluate the consistency
   pacts, suggesting adjustment periods as countries integrate and                of the main findings.
   optimize AI technologies.
 • Early adoption stages (lower quantiles) frequently show significant            4.3.1. Addressing endogeneity concerns
   positive impacts, indicating that even initial AI implementation can               The adoption of AI presents significant endogeneity challenges, pri­
   deliver immediate environmental benefits.                                      marily driven by reverse causality, omitted variable bias, and mea­
                                                                                  surement errors. Greater integration of AI not only stimulates innovation
    These patterns, supported by specific quantile measurements,                  in climate technologies and transforms industrial practices—thereby
collectively suggest that while the path to AI maturity varies by country,        influencing ecological quality—but is also influenced by broader global
the technology consistently contributes to improved ecological out­               technological advancements. This bidirectional relationship creates a
comes across different stages of adoption.                                        feedback loop, complicating efforts to establish clear causal links be­
                                                                                  tween AI adoption and ecological outcomes. To address these concerns,
                                                                                  we employ the instrumental variable multivariate quantile regression
                                                                                  (IVMQR) framework developed by Chernozhukov & Hansen (2008) and

                                                                             12
B. Bergougui                                                                                                            Technology in Society 83 (2025) 103021




                                                                 Fig. 7. (continued).


Kaplan & Sun (2017). Prior research has highlighted the importance of           that ecological quality is predominantly influenced by industry-specific
correcting for AI adoption endogeneity to avoid biased estimates of its         technological choices and energy consumption patterns, this instru­
impact on ecological quality (Zhao et al., 2024). Our approach focuses          mental approach provides a rigorous identification strategy. Correcting
on selecting instruments strongly correlated with domestic AI adoption          for endogeneity in this manner yields more reliable estimates of the
while remaining exogenous to ecological quality.                                causal impact of AI adoption on ecological quality.
    In our baseline specification, we use lagged AI adoption as an in­              The empirical results, visualized in Fig. 8, reveal heterogeneous ef­
strument. Historical levels of AI integration capture the persistence of        fects across national contexts. In Canada, we observe a consistently
technological diffusion, making them strong predictors of current               positive relationship between AI adoption and ecological quality across
adoption trends. Crucially, lagged values are exogenous to present-day          all quantiles, aligning with our main findings. Japan exhibits a nuanced
ecological quality distributions, thereby addressing concerns related to        pattern, with positive effects concentrated in low to middle quanti­
simultaneity and reverse causality. Following Cao et al. (2025)and Tao          les—consistent with our MQQR results (Fig. 7)—but transitioning to
et al. (2024), we incorporate lagged AI adoption as an instrumental             negative effects at higher quantiles. Italy demonstrates similar patterns
variable within an IVMQR framework. While AI adoption has the po­               at upper quantiles, while other analyzed countries maintain relatively
tential to contribute to emissions reductions and improve ecological            consistent effects across their distributions. These findings, robust to
quality—a dynamic that may engender a bidirectional causal relation­            endogeneity corrections, provide strong evidence that AI’s impact on
ship with ecological pressures—the use of lagged variables isolates             ecological quality exhibits significant quantile-dependent variation,
variation not confounded by contemporaneous ecological factors. Given           both augmenting and diminishing ecological disparities across different


                                                                           13
B. Bergougui                                                                                                                    Technology in Society 83 (2025) 103021




                                                                   Fig. 8. IVMQR results.


contexts.                                                                             4.3.3. Outcomes of quantile regression
                                                                                          To assess the robustness of the MQQR methodology, the study im­
4.3.2. Outcomes of kernel-based regularized least squares                             plements a comparative analysis with QR. Fig. 9 illustrates the
   To enhance the robustness of the MQQR results, a machine learning                  comparative dynamics between QR coefficients and averaged MQQR
approach using Kernel Regularized Least Squares (KRLS), as proposed                   estimates, specifically examining AI’s influence on ecological quality
by Hainmueller and Hazlett (2014), is employed to account for potential               across the G7 nations. The graphical representation reinforces the val­
nonlinearities in the relationships. Following Alola et al. (2023), the               idity of the MQQR findings, as evidenced by the strong convergence
model is specified as follow:                                                         between mean MQQR slope estimates and QR calculations throughout
                                                                                      the examined economies. This methodological alignment strengthens
EQt = β0 + β1 AIt + ε                                                    (02)
                                                                                      the reliability of both analytical approaches. The comparative analysis
In this context, β0 denotes the intercept, while β1 represents the slope              reveals distinct patterns in the AI-EQ nexus across different economies.
coefficients associated with IA. The term ε represents the error term.                While most G7 nations demonstrate a positive association between AI
    The average marginal effects from the KRLS estimation, presented in               advancement and ecological quality, notable variations emerge in the
Table 5, confirm the model’s statistical significance at the p < 0.01 level.          Japanese and French contexts, where the relationship exhibits mixed
The model demonstrates high predictive accuracy across the G7 coun­                   patterns. These divergent outcomes underscore the heterogeneous na­
tries examined, with R-squared values exceeding 0.7 for each, indicating              ture of AI’s environmental implications across different economic
that AI accounts for over 70 % of the variance in EQ. This outcome                    frameworks. Furthermore, the magnitude analysis indicates that AI’s
underscores the effectiveness of AI as a predictor of EQ outcomes.                    ecological impact manifests more prominently in the Italian and British
Additionally, an analysis of marginal effects at the 25th, 50th, and 75th             economies compared to their Canadian and German counterparts.
quantiles further supports a nonlinear conditional relationship. Specif­
ically, at the 25th quantile, the impact of AI on EQ varies between                   4.3.4. Outcomes of the dependent variable substitution
positive and negative across countries, whereas at the 75th quantile, the                Finally, the study tested the sensitivity of results to alternative
impact is consistently positive across all countries. The pattern of                  measurement of the dependent variable. The load capacity factor was
average marginal effects and those at specified quantiles aligns with the             substituted with ecological footprint per person as an alternative mea­
MQQR findings, reinforcing the robustness of the initial results.                     sure of ecological quality. The ecological footprint metric provides a
                                                                                      complementary perspective by quantifying the biologically productive


Table 5
KRLS average marginal effects of AI on EQ.
  Economy                   Average          SE              t                       P>t            P25              P50                  P75                R2

  Canada                      0.1325         0.0047            28.1520               0.0000           0.0247           0.1104             0.2372             0.8939
  France                      0.1066         0.0256             4.1580               0.0000         − 0.0243           0.0596             0.2105             0.7081
  Germany                     0.1006         0.0122             8.2440               0.0000           0.0620           0.1143             0.1541             0.7941
  Italy                       0.0610         0.0060            10.2050               0.0000         − 0.0091           0.0698             0.1373             0.9691
  Japan                     − 0.1163         0.0090          − 12.8810               0.0000         − 0.2320         − 0.0816             0.0183             0.9411
  United Kingdom              0.0733         0.0096             7.6490               0.0000         − 0.0566           0.0790             0.1614             0.7360
  United States               0.1503         0.0061            24.7990               0.0000           0.0926           0.1777             0.2162             0.9756

Note: SE: Standard error.

                                                                                14
B. Bergougui                                                                                                                   Technology in Society 83 (2025) 103021




                                               Fig. 9. Validating the MQQR Method: MQQR vs. QR Estimates.


area needed to support resource consumption and waste absorption. The                  reduced pesticide use, contributing to better yields with minimal
substitution results, illustrated in Fig. 10, strongly corroborate the main            ecological impact (Cazzaniga et al., 2024). Government policies
findings presented in Fig. 7. Taking the UK as an example case, the                    further support sustainable agricultural practices.
analysis reveals consistent patterns across both measurements. AI’s                  • Through its Society 5.0 program, Japan has led the integration of AI
impact on the ecological footprint is negative across all quantiles, with              into urban development, prioritizing environmental sustainability,
stronger effects at higher AI levels. This negative relationship indicates             efficiency, and resource management. By applying AI to urban
improved ecological quality, as a reduced ecological footprint is envi­                planning and waste management, Japan reduces its carbon footprint
ronmentally beneficial. These findings align with the primary analysis in              and optimizes complex systems, turning environmental challenges
Fig. 7, which also demonstrated AI’s positive impact on ecological                     into technological solutions (Javed et al., 2024).
quality in the UK.                                                                   • The United Kingdom strategically employs AI technologies in the
                                                                                       transport and energy sectors to foster sustainable development and
5. Discussion                                                                          achieve its net-zero emissions target by 2050. Advanced AI appli­
                                                                                       cations aid in renewable energy optimization, traffic flow manage­
    This section delves into empirical evidence, focusing on the influence             ment, and smart energy systems, reducing emissions and enhancing
of AI on EQ in the context of G7 countries. Across most of these econ­                 operational efficiency. The economic potential is significant, with AI
omies, a notable relationship between AI and EQ is evident, with 2 out of              projected to boost GDP by 10 % by 2030 (£232 billion). This growth
7 nations displaying a consistently positive association across all AI                 reflects the alignment between ecological gains and economic
quantiles, underscoring AI’s potential to enhance EQ. These outcomes                   expansion.
align with prior studies (Ding et al., 2023; Liu, Rasool, et al., 2024; Song         • The United States harnesses AI to improve energy efficiency and
et al., 2023), that emphasize the beneficial effects of AI on EQ. An ex­               address climate change across various industries through smart
amination of Germany, Italy, Japan, the UK, and the US reveals an                      grids, predictive maintenance, and industrial optimization. These AI-
asymmetric relationship between AI adoption and EQ, marked by                          driven initiatives facilitate better renewable energy integration,
stronger positive impacts at higher AI quantiles and weaker effects at                 optimized manufacturing, and reduced emissions. AI is expected to
lower levels of adoption. Advanced stages of AI development in these                   contribute $3.5 trillion to the global economy by 2030, largely
countries are associated with substantial ecological improvements.                     driven by sustainability enhancements.

 • Renowned for its strong engineering and manufacturing sectors,                       In the context of France and Canada, the relationship between AI
   Germany has leveraged AI to enhance production efficiency, mini­                 and EQ has a complex structure characterized by both negative and
   mize waste, and improve energy use. Its commitment to sustain­                   positive correlations. The impact of AI on EQ is not consistently nega­
   ability is evident through rigorous regulations and incentives                   tive; rather, it fluctuates on the basis of factors such as timing, duration,
   promoting eco-friendly practices. The government’s support for AI                and geographical context. The temporal dimension plays a crucial role in
   initiatives that align with environmental goals, especially under the            shaping the AI‒EQ relationship. Over time, advancements in industrial
   Industry 4.0 program (OECD, 2024), has bolstered this trend.                     robotics and AI technologies have led to both negative and positive
 • Italy places significant emphasis on using AI to boost EQ, especially            implications for EQ. In the initial stages, AI implementation might have
   in the agricultural sector. The adoption of precision farming tech­              increased EQ due to higher energy consumption and resource demands.
   nologies powered by AI optimizes resource use and reduces chemical               However, as these technologies mature and become more energy effi­
   inputs, which positively impacts sustainability. Additionally, Italy is          cient, AI can contribute to reducing EQ by optimizing production pro­
   integrating AI into green finance to amplify ecological benefits.                cesses and minimizing waste. The duration of AI deployment within
   These innovations have improved resource management and                          specific production systems significantly influences its impact on EQ.


                                                                               15
B. Bergougui                                                                                                                Technology in Society 83 (2025) 103021




                             Fig. 10. MQQR estimates using ecological footprints as an alternative measure of ecological quality



Short‒term adoption might not yield immediate ecological benefits                     An important dimension to this discussion is the significant ecolog­
because of initial investments in infrastructure and workforce retrain­           ical costs associated with AI, which extend beyond operational effi­
ing. However, long‒term integration of AI tends to reveal more                    ciency gains and present particular challenges and responsibilities for
apparent efficiency improvements and waste reduction potential. The               G7 nations as primary developers, manufacturers, and consumers of this
geographical context of AI implementation in France and Canada also               technology (Dauvergne, 2022). AI systems demand resource-intensive
plays a vital role in its effect on EQ. Regional disparities in ecological        production, generating substantial ecological concerns rooted in com­
conditions, energy infrastructure, and regulatory frameworks exist                plex global supply chains often terminating in G7 economies. The
across the country. For example, areas with a greater proportion of               manufacturing of high-performance AI hardware, such as GPUs, servers,
renewable energy sources may experience a lower environmental                     and associated components, requires vast amounts of critical minerals
impact from AI implementation than regions that are more dependent                like rare earths, lithium, and cobalt. Notably, none of the G7 countries
on fossil fuels. The regional ecological strategies further shape the             are currently major miners of these materials, leading to heavy reliance
interplay between AI and EQ. The proximity to natural resources and               on imports. For instance, the EU imports almost all its rare earths,
supply chains in various parts of the France and Canada can also affect           largely from China, although the bloc’s Critical Raw Materials Act aims
the overall EQ. This geographical variability contributes to the complex          for 10 % domestic mining and increased processing/recycling by 2030.
nature of the AI‒EQ relationship across the country. The mixed rela­              Japan similarly diversified away from Chinese dependence after 2010
tionship between AI and EQ in France and Canada context is supported              through recycling, alternative technologies, and overseas investments
by research, such as that conducted by (Zhong et al., 2024), which                (e.g., Australia). The U.S. and Canada are actively bolstering domestic
revealed a mixed association between AI and CO2 emissions. This un­               supply chains; Canada holds significant cobalt reserves and is financing
derscores the multifaceted nature of AI’s environmental impact in the             new projects, while the U.S. funds partnerships for lithium, cobalt, and
France and Canada, highlighting the need for nuanced analysis and                 rare earth security. Italy remains heavily import-dependent with nascent
region‒specific strategies when considering A‒I adoption and its                  efforts in mapping local deposits, while Germany and France also rely on
ecological consequences.                                                          imports, though European firms like Solvay in France are beginning pilot

                                                                             16
B. Bergougui                                                                                                                 Technology in Society 83 (2025) 103021




                                                                    Fig. 10. (continued).


recycling and reprocessing initiatives. Regardless of origin, the G7’s              solvents) and potent fluorinated greenhouse gases, requiring stringent
demand for AI hardware multiplies the water, land, and biodiversity                 waste treatment under national regulations (e.g., strict effluent controls
impacts in global mining regions (Chakraborty, 2024). Furthermore, the              in Germany/UK, US wastewater limits, upcoming EU chemical regula­
fabrication of sophisticated AI processors (semiconductors) entails sig­            tions impacting chipmaking). Another major ecological concern directly
nificant environmental footprints within the production process. Chip               impacting G7 countries is the rapidly growing volume of electronic
fabrication plants, crucial for the AI supply chain serving all G7 nations,         waste (e-waste) generated by the AI sector. High-performance servers
consume enormous water volumes – a modern facility might use around                 and GPUs often have short operational lifetimes of only 2–5 years before
10 million gallons (38 million liters) of ultrapure water daily, potentially        becoming obsolete due to rapid technological advancement. This
straining resources in arid regions like parts of the US (e.g., an Arizona          accelerated replacement cycle could add an estimated 1.2–5 million
fab projected to use nearly 3 % of Phoenix’s water supply).3 This ne­               tonnes of e-waste annually by 2030 globally (Zhuk, 2023), much of it
cessitates significant investment in water recycling, often reaching 99 %           originating from or consumed within G7 nations. In 2022, the U.S.
on-site. These fabs also utilize hazardous chemicals (strong acids,                 generated approximately 7.2 billion kg (~21 kg/capita) and Canada
                                                                                    0.77 billion kg (~21 kg/capita). European G7 members saw Germany
                                                                                    leading (~1.77 billion kg), followed by the UK, France, and Italy, while
  3                                                                                 Japan generated around 2.64 billion kg. Discarded equipment contains
    See   https://www.fdiintelligence.com/content/c31f977a-a8b7-5ffc-9eaa
                                                                                    toxic substances like lead, mercury, and flame retardants. Recycling
-daa48a8d1d41.

                                                                               17
B. Bergougui                                                                                                                 Technology in Society 83 (2025) 103021


effectiveness varies significantly across the G7. The EU mandates high             AI adoption is still nascent, initial implementation may even increase
collection rates, with Germany and France achieving relatively high                energy consumption and emissions before efficiency gains materialize.
formal recycling rates, while Italy lags. The UK collects large volumes            Over time, as AI systems become more widespread and energy-efficient,
but has high per capita generation. North American recycling is less               their positive impact on EQ becomes more evident, especially when
centralized due to the lack of federal US laws, relying on state-level             supported by renewable energy infrastructure and region-specific stra­
programs, resulting in lower formal recycling rates (globally only                 tegies. Geographical and infrastructural differences also contribute to
about 12 % of e-waste is formally recycled) and potential export to                the variability in outcomes. Regional disparities in access to renewable
developing countries (Shreyas Madhav et al., 2022). This means valu­               energy, the proximity of supply chains, and the presence of ecological
able materials are lost, and the mounting disposal challenge threatens to          vulnerabilities can all shape how AI affects environmental quality. For
swamp existing facilities and amplify soil and water contamination                 example, areas with abundant renewable resources may see lower car­
without stronger circular-economy measures and extended producer                   bon footprints from AI operations compared to regions reliant on fossil
responsibility enforcement across the G7 (Chen et al., 2021). In sum, the          fuels. In summary, the cross-country differences in the AI–EQ relation­
ecological costs of AI in G7 nations related to its physical lifecycle are         ship among G7 nations are the result of a multifaceted interplay between
significant, spanning resource extraction impacts, substantial water and           policy frameworks, institutional effectiveness, industrial composition,
chemical use in fabrication, and vast quantities of toxic electronic waste.        economic cycles, technological maturity, and geographical context.
Addressing these challenges requires harmonizing technological ambi­               These factors collectively determine the extent to which AI adoption
tion with transnational sustainability frameworks, circular supply                 translates into tangible ecological benefits, highlighting the need for
chains, and equitable resource governance.                                         tailored, context-sensitive approaches to harness AI’s full potential for
    The observed cross-country differences in the relationship between             environmental sustainability.
artificial intelligence (AI) and environmental quality (EQ) among G7
nations are shaped by a complex interplay of country-specific policies,            6. Conclusion, policy implications, limitations and
industrial structures, and contextual factors that influence both the pace         recommendations for future research
and the direction of AI’s ecological impact. One of the most significant
determinants is the policy environment. Countries with robust envi­                    This final section distills the main insights from the analysis and
ronmental regulations and targeted incentives for green innovation-such            offers policy suggestions grounded in these findings. Additionally, the
as Germany’s Industry 4.0 program or the United Kingdom’s net-zero                 constraints of the methodology and data sources are recognized and
commitments-tend to see stronger positive associations between AI                  discussed.
adoption and improvements in EQ. These policies not only encourage
the integration of AI into sectors like manufacturing, energy, and                 6.1. Conclusion
transport but also ensure that technological advances are aligned with
sustainability goals. Institutional quality further differentiates outcomes            As one of the leading adopters of AI globally, the G7 countries have
across the G7. Effective governance, characterized by strong regulatory            committed to enhancing their EQ through sustainable AI implementa­
frameworks, transparency, and accountability, is closely linked to better          tion by 2040. This commitment demonstrates a clear recognition of the
environmental performance. Nations with high institutional quality are             necessity to transition from traditional industrial processes to more
more successful in enforcing environmental standards and fostering                 environmentally conscious AI solutions that promote ecosystem pres­
innovation that reduces emissions and resource intensity. For instance,            ervation. In light of this, it is essential to understand how AI integration
Germany and Japan, with their tradition of stringent environmental                 contributes to the improvement of ecological systems. This paper adds
oversight and industrial coordination, have leveraged AI to optimize               significant value to the existing literature on AI and EQ through two key
resource use and minimize waste, resulting in more pronounced                      innovations.
ecological benefits. Industrial structure is another pivotal factor shaping
the AI–EQ relationship. Countries with less diversified economies may               • Firstly, it introduces methodological novelty by employing the
rely more heavily on traditional industries that are slower to adopt                  MQQR approach combined with nonparametric techniques over the
advanced technologies. For example, if a country’s economy is primarily               period from January 2000 to December 2019, a combination that has
based on low-tech manufacturing or resource extraction without sig­                   been underexplored in previous research.
nificant investment in AI, the potential for EQ improvement diminishes.             • Secondly, this paper adds value by focusing on the G7 econo­
In contrast, countries with economies dominated by high-tech                          mies—Canada, France, Germany, Italy, Japan, the United Kingdom,
manufacturing, advanced services, or knowledge-intensive industries                   and the United States—which are not only leaders in AI adoption but
are better positioned to capitalize on AI’s efficiency gains and environ­             also play a crucial role in shaping global ecological trends.
mental innovations. Germany’s advanced engineering sector and Ja­
pan’s focus on smart urban systems exemplify how industrial                           Empirical findings from the MQQR analysis indicate that during the
composition can amplify the ecological advantages of AI, while nations             early stages of AI adoption (low quantiles), there is a weak positive effect
like Canada, with a heavier reliance on resource extraction, may face              of AI on ecological quality across most G7 countries. As the transition
greater challenges in realizing immediate EQ improvements from AI.                 phase progresses, this positive effect begins to strengthen and becomes
The relationship between AI and EQ is also influenced by economic                  increasingly beneficial. At the mature stages of AI adoption (high
cycles. During periods of economic growth, increased investment in AI              quantiles), the positive impact becomes pronounced and significant. To
can accelerate ecological gains, as companies seek to increase efficiency          ensure robustness, additional methods, including KRLS, QR, and alter­
and meet rising demand. Conversely, during economic downturns,                     native measures of EQ were employed to validate the MQQR results. The
reduced industrial activity and financial constraints often lead to                empirical findings from these robustness checks corroborate the out­
delayed or scaled-back AI investments, weakening the positive correla­             comes of the MQQR analysis, reinforcing the reliability of the study’s
tion between AI and EQ. This cyclical dynamic means that the benefits of           conclusions.
AI for environmental quality can fluctuate in tandem with broader                     A comparison with existing literature reveals significant discrep­
economic trends. Technological maturity further modulates the AI–EQ                ancies often associated with the econometric methodologies employed.
relationship. Nations at earlier stages of technological development may           For instance, earlier studies by Zhang and Zhu (2023) and Chen et al.
lack the infrastructure or expertise needed to implement advanced AI               (2022) utilized panel fixed effect (PFE) models or techniques such as
systems effectively, resulting in missed opportunities for optimizing              FMOLS and DOLS, which lack the nuanced capabilities of the MQQR
resource use and minimizing environmental impacts. In countries where              method. The QQR’s ability to analyze how different quantiles of an

                                                                              18
B. Bergougui                                                                                                                  Technology in Society 83 (2025) 103021


independent variable affect the conditional quantile of a dependent                 impact across different regions. Strengthening coordination between
variable provides deeper insights, explaining why this study identifies a           national and regional AI initiatives will ensure more uniform
positive impact of AI on EQ, in contrast to previous research. Conven­              implementation.
tional methodologies may have resulted in spurious associations be­                    For Canada, it is essential to develop region-specific strategies for the
tween AI and EQ, whereas the MQQR approach offers a clearer and more                implementation of artificial intelligence (AI) in natural resource man­
accurate understanding of this relationship. The findings are consistent            agement and to create incentives for AI adoption in remote and rural
with certain individual country-level studies, such as those by Liu,                areas. The government should establish frameworks to measure AI’s
Rasool, et al. (2024) and Zhong et al. (2024), which examined the in­               impact on local ecosystems while enhancing coordination between
fluence of AI on EQ but did not explore the asymmetric effects within the           provincial and federal AI initiatives. Supporting the integration of AI in
G7 context. This focus represents a significant contribution of this                renewable energy systems would help address the country’s unique
research.                                                                           geographical challenges.
                                                                                       To further strengthen the policy relevance of our findings, we offer
6.2. Policy recommendations                                                         specific, stage-appropriate recommendations for policymakers to
                                                                                    maximize the ecological benefits of AI adoption across the G7.
    Drawing on empirical findings, this study presents several country-
specific policy recommendations aimed at optimizing AI implementa­                   • Early-stage AI adoption (low quantiles): At the outset of AI inte­
tion to improve ecological quality across G7 nations.                                  gration, policymakers should focus on curbing rebound effects,
    For Germany, policymakers should enhance the Industry 4.0 pro­                     laying robust regulatory foundations, and jump-starting green AI
gram by integrating explicit environmental targets with goals for tech­                infrastructure. Carbon pricing or resource-use taxes can counteract
nological advancement. The government should create incentive                          any uptick in consumption driven by newfound AI efficiencies, while
structures for small and medium-sized enterprises (SMEs) to adopt eco-                 binding sustainability standards—such as limits on semiconductor-
friendly AI solutions while establishing industry-specific benchmarks for              fab water use and conflict-mineral sourcing restrictions—establish
AI-driven environmental improvements. Implementing certification                       clear environmental guardrails. Incentives that subsidize renewable
systems for environmentally beneficial AI technologies and fostering                   energy for nascent AI installations (for example, tax credits for solar-
cross-sector collaboration between AI developers and environmental                     or wind-powered data centers) further ensure that early adopters
experts would capitalize on Germany’s robust engineering and                           take a low-carbon path. In Canada, this means prioritizing AI projects
manufacturing base.                                                                    in hydro-rich provinces like Quebec to sidestep fossil-fuel de­
    Regarding Italy, policymakers should prioritize the expansion of AI                pendency; in Italy, it entails funding pilot precision-farming schemes
integration in agricultural sustainability programs and enhance green                  in drought-prone regions alongside strict water-extraction rules; and
finance initiatives that utilize AI for environmental risk assessment. The             in France, it calls for targeted mandates that steer AI development
government should establish regulatory frameworks specifically for AI-                 toward the nation’s low-carbon nuclear grid by encouraging uptake
enabled precision farming, along with creating incentives for the                      in historically coal-and-gas-dependent areas.
adoption of agricultural technology among small-scale farmers. Addi­                 • Transitional-stage AI adoption (mid-quantiles): As AI moves
tionally, implementing monitoring systems to evaluate AI’s impact on                   beyond proof-of-concept into broader deployment, the emphasis
agricultural sustainability will ensure the effectiveness of these                     should shift toward scaling green employment, modernizing energy
initiatives.                                                                           systems, and reinforcing circular-economy practices. Large-scale
    In Japan’s case, policy priorities should further integrate AI into the            reskilling programs can equip workers displaced by AI with roles
Society 5.0 framework, incorporating specific environmental metrics.                   in renewable-energy maintenance and eco-innovation, while smart-
The government should expand smart city initiatives that utilize AI for                grid mandates—requiring AI-driven demand-response and dynamic
environmental management and develop policies to accelerate the                        pricing algorithms—optimize renewable integration. Extended pro­
adoption of AI in waste management systems. Additionally, creating                     ducer responsibility (EPR) laws combined with grants for AI-enabled
incentives for AI-driven energy efficiency improvements would enhance                  e-waste recyclers will keep hardware materials in use longer. In the
Japan’s existing technological infrastructure for environmental                        UK, such measures could accelerate AI-powered public-trans­
sustainability.                                                                        portation optimizations (e.g., dynamic congestion pricing in London)
    The United Kingdom should align its AI development strategies with                 tied directly to measured emissions cuts. In Japan, urban centers like
its 2050 net-zero emissions target by expanding support for AI appli­                  Tokyo could expand robotic sorting of discarded electronics and
cations in renewable energy optimization. Policymakers ought to                        deploy AI for offshore wind-farm coordination. In the United States,
formulate policies that accelerate AI adoption in public transportation                federal R&D funding under the National AI Initiative should steer
systems and create incentives for AI-driven energy efficiency improve­                 chip designers toward lower-carbon architectures and promote
ments in buildings. Additionally, establishing frameworks for measuring                closed-loop supply chains in technology hubs such as Silicon Valley.
and verifying AI’s contribution to emissions reduction would ensure                  • Mature-stage AI adoption (high quantiles): When AI reaches full
progress toward environmental goals.                                                   industrial maturity, the goal must be to cement ecological dividends,
    For the United States, it is essential to develop federal guidelines for           institutionalize sustainability across sectors, and resolve any
the implementation of artificial intelligence (AI) in environmental                    lingering asymmetries. Policymakers should require industrial sym­
management while simultaneously expanding support for AI research in                   biosis—such as using data-center waste heat for district hea­
renewable energy integration. The government should establish tax in­                  ting—and fund cutting-edge AI applications in carbon-capture
centives for companies that adopt environmentally beneficial AI solu­                  technologies like machine-learning–optimized direct-air-capture.
tions and enhance partnerships between technology firms and                            Internationally harmonized standards for ethical mineral sourcing
environmental agencies. Additionally, creating standards for measuring                 and e-waste management will ensure that extraction and disposal
the environmental impact of AI would ensure consistent progress across                 practices remain responsible. Germany, for instance, can expand its
various industries.                                                                    Industry 4.0 certification to include cradle-to-grave AI lifecycle as­
    France should address regional disparities in AI adoption by imple­                sessments with enforceable penalties for non-compliance; Japan can
menting targeted support programs and developing policies to accel­                    scale Society 5.0 smart-city pilots into zero-waste urban zones using
erate the integration of AI in renewable energy systems. The government                predictive-analytics to minimize landfill; and the United States could
should create incentives for ecological modernization through AI                       institute a federal “AI Sustainability Index” linking corporate ESG
adoption while establishing frameworks to monitor AI’s environmental                   ratings to verified improvements in environmental quality.

                                                                               19
B. Bergougui                                                                                                                                        Technology in Society 83 (2025) 103021


    By aligning these stage-specific policy mixes with the quantile-based                          Future research would benefit from examining this relationship within
insights from our study, G7 governments can transform AI’s uneven                                  other significant economic groups such as the G-20, MENA region, Eu­
environmental impacts into a coordinated, sustainable pro­                                         ropean Union, and BRICS nations. Such expansion would provide
gression—curbing early rebound, mainstreaming mid-stage green                                      valuable insights into regional variations and context-specific dynamics
innovation, and embedding mature-stage ecological stewardship.                                     of the AI-EQ relationship. Methodologically, while the MQQR technique
                                                                                                   offers unique advantages, it has inherent limitations in accommodating
6.3. Limitations and future research                                                               additional variables that might influence the AI-EQ association. Future
                                                                                                   studies could address this constraint by employing more comprehensive
    While this study provides valuable insights into the AI-EQ relation­                           multivariate techniques, such as quantile ARDL modeling, to capture the
ship, several limitations present opportunities for future research                                complex interplay of multiple factors affecting this relationship.
advancement. Primarily, the analysis focuses solely on EQ without
incorporating specific greenhouse gas emissions, such as sulfur dioxide,                           Declaration of competing interest
nitrous oxide, and methane. This limitation indicates a need for future
studies to employ a more comprehensive set of environmental in­                                        The authors declare that they have no known competing financial
dicators, which could potentially reveal varying outcomes across                                   interests or personal relationships that could have appeared to influence
different environmental proxies. The geographical scope of the study,                              the work reported in this paper.
while focused on G7 nations, could be expanded to enhance under­
standing of the AI-EQ relationship across diverse economic contexts.



Appendix A



Table A.1
Summary of existing research on AI environmental effects.

  Author                           Sample                               Period                 Main Findings

  AI impact on Carbon Emissions
  Yu et al. (2022)               Chinese cities                         2010–2018              The adoption of robots led to lower CO2 emissions in urban areas.
  Wang et al. (2023a)            Chinese cities                         2008–2019              Increased robot usage corresponded with reductions in city-level carbon output.
  Jiang et al. (2022)            Chinese industry                       2003–2016              Automation via robots decreased CO2 emissions in manufacturing sectors.
  Song et al. (2023)             41,419 Chinese firms                   2000–2013              Firms deploying robots saw a measurable drop in their carbon emissions.
  Ding et al. (2023)             30 Chinese provinces                   2006–2019              Higher AI penetration was associated with reduced provincial carbon emissions.
  Zhong et al. (2023)            66 countries                           1993–2019              Greater AI deployment globally tended to lower carbon emissions.
  Luan et al. (2022)             74 countries                           1993–2019              In contrast, wider robot adoption was linked to increased air pollution levels.
  Yu et al. (2023)               Chinese cities                         2010–2018              Instrumental analysis confirmed that AI deployment decreases urban carbon emissions.
  AI impact on Carbon Intensity
  Liu et al. (2022)              Chinese industry                       2005–2016              AI integration led to improved carbon efficiency in industrial output.
  Zhang et al. (2022)            Chinese industry                       2008–2019              Enhanced AI use resulted in lower carbon emissions per unit of industrial production.
  Li et al. (2022b)              35 countries                           1993–2017              Robot deployment contributed to reduced carbon intensity across multiple nations.
  Chen et al. (2022a)            Chinese cities                         2011–2017              Urban centers using more robots achieved better carbon intensity metrics.
  AI impact on Ecological Footprint
  Chen et al. (2022)             72 countries                           1993–2019              AI advancements were found to shrink overall ecological footprints.
  Majeed et al. (2025)           Emerging economies                     1990–2019              AI adoption contributed to notable improvements in ecological quality.
  Liu et al. (2024b)             10 advanced economies                  2007–2020              Across different quantiles, increased AI use consistently reduced ecological footprints.
  Wang et al. (2024b)            67 countries                           1993–2019              Robust GMM estimates show that AI lowers ecological footprints globally.
  Wang et al. (2024a)            30 Chinese provinces                   2018–2022              Provincial analysis revealed threshold effects where AI adoption begins to cut footprints.
  Wang et al. (2025)             51 countries                           2010–2019              AI deployment was positively associated with sustainable development indicators.




Data availability                                                                                      nonparametric multivariate QQR approach. Energy Economics, 120, Article 106613.
                                                                                                       https://doi.org/10.1016/j.eneco.2023.106613
                                                                                                   Baum, C. F., Hurn, S., & Lindsay, K. (2021). The BDS test of Independence. STATA
    Data will be made available on request.                                                            Journal, 21, 279–294. https://doi.org/10.1177/1536867X211025796
                                                                                                   Bergougui, B. (2024a). Moving toward environmental mitigation in Algeria: Asymmetric
                                                                                                       impact of fossil fuel energy, renewable energy and technological innovation on CO2
References
                                                                                                       emissions. Energy Strategy Reviews, 51, Article 101281. https://doi.org/10.1016/j.
                                                                                                       esr.2023.101281
Acemoglu, D., Lelarge, C., & Restrepo, P. (2020). Competing with robots: Firm-level                Bergougui, B. (2024b). Investigating the relationships among green technologies,
    evidence from France. AEA Pap Proc, 110, 383–388. https://doi.org/10.1257/                         financial development and ecological footprint levels in Algeria: Evidence from a
    pandp.20201003                                                                                     novel Fourier ARDL approach. Sustainable Cities and Society, 112, Article 105621.
Acemoglu, D., & Restrepo, P. (2018). The race between man and machine: Implications                    https://doi.org/10.1016/j.scs.2024.105621
    of technology for growth, factor shares, and employment. The American Economic                 Bergougui, B. (2024c). Algeria’s pathway to COP28 and SDGs: Asymmetric impact of
    Review, 108, 1488–1542. https://doi.org/10.1257/aer.20160696                                       environmental technology, energy productivity, and material resource efficiency on
Acemoglu, D., & Restrepo, P. (2020). Robots and jobs: Evidence from US labor markets.                  environmental sustainability. Energy Strategy Reviews, 55, Article 101541. https://
    Journal of Political Economy, 128, 2188–2244. https://doi.org/10.1086/705716                       doi.org/10.1016/j.esr.2024.101541
Adebayo, T. S., & Özkan, O. (2024). Evaluating the role of financial globalization and oil        Bergougui, B. (2025a). Can artificial intelligence mitigate environmental inequality?
    consumption on ecological quality: A new perspective from quantile-on-quantile                     Evidence from leading robotic-driven economies using quantile-based methods.
    granger causality. Heliyon, 10, Article e24636. https://doi.org/10.1016/j.                         Borsa Istanbul Review.
    heliyon.2024.e24636                                                                            Bergougui, B. (2025b). Circular pathways to sustainability: asymmetric impacts of the
Alola, A. A., Özkan, O., & Usman, O. (2023). Examining crude oil price outlook amidst                 circular economy on the EU’s capacity load factor. Land, 14. https://doi.org/
    substitute energy price and household energy expenditure in the USA: A novel                       10.3390/land14061216



                                                                                              20
B. Bergougui                                                                                                                                           Technology in Society 83 (2025) 103021

Bergougui, B., & Aldawsari, M. I. (2024). Asymmetric impact of patents on green                    Furman, J., & Seamans, R. (2018). AI and the economy. Innovation Policy and the
    technologies on Algeria’s ecological future. Journal of Environmental Management,                   Economy, 19, 161–191. https://doi.org/10.1086/699936
    355, Article 120426. https://doi.org/10.1016/j.jenvman.2024.120426                             Grossman, G. M., & Krueger, A. B. (1995). Economic growth and the environment.
Bergougui, B., Boudjana, R. H., Mehibel, S., & Zambrano-Monserrate, M. A. (2024). How                   Quarterly Journal of Economics, 110, 353–377. https://doi.org/10.2307/2118443
    do institutional quality and income asymmetrically affect carbon emissions                     Hainmueller, J., & Hazlett, C. (2014). Kernel regularized least squares: Reducing
    inequality? A quantile-on-quantile assessment for six major global emitters. Journal                misspecification bias with a flexible and interpretable machine learning approach.
    of Cleaner Production. , Article 144215. https://doi.org/10.1016/j.                                 Political Analysis, 22, 143–168. https://doi.org/10.1093/pan/mpt019
    jclepro.2024.144215                                                                            Jacobsson, S., & Johnson, A. (2000). The diffusion of renewable energy technology: An
Bergougui, B., Mehibel, S., & Boudjana, R. H. (2024). Asymmetric nexus between green                    analytical framework and key issues for research. Energy Policy, 28, 625–640.
    technologies, economic policy uncertainty, and environmental sustainability:                        https://doi.org/10.1016/S0301-4215(00)00041-0
    Evidence from Algeria. Journal of Environmental Management, 360, Article 121172.               Javed, A. A., Subhani, B. H., Javed, A. A., & Rapposelli, A. (2024). Accessing the efficacy
    https://doi.org/10.1016/j.jenvman.2024.121172                                                       of green growth, energy efficiency, and green innovation for environmental
Bergougui, B., & Meziane, S. (2025). Assessing the impact of green energy transition,                   performance in top manufacturing nations in the framework of sustainable
    technological innovation, and natural resources on load capacity factor in Algeria:                 development. Quality and Quantity. https://doi.org/10.1007/s11135-024-01918-6
    Evidence from dynamic autoregressive distributed lag simulations and machine                   Jin, M., & Chen, Y. (2024). Has green innovation been improved by intelligent
    learning validation. Sustainability (Switzerland), 17(5), 1815. https://doi.org/                    manufacturing?—Evidence from listed Chinese manufacturing enterprises.
    10.3390/su17051815                                                                                  Technological Forecasting and Social Change, 205, Article 123487. https://doi.org/
Boza, P., & Evgeniou, T. (2021). Artificial intelligence to support the integration of                  10.1016/j.techfore.2024.123487
    variable renewable energy sources to the power system. Applied Energy, 290, Article            Kaplan, D. M., & Sun, Y. (2017). Smoothed estimating equations for instrumental
    116754. https://doi.org/10.1016/j.apenergy.2021.116754                                              variables quantile regression. Econometric Theory, 33, 105–157. https://doi.org/
Broock, W. A., Scheinkman, J. A., Dechert, W. D., & LeBaron, B. (1996). A test for                      10.1017/S0266466615000407
    independence based on the correlation dimension. Econometric Reviews, 15,                      Li, G., Li, Y., & Tsai, C.-L. (2015). Quantile correlations and quantile autoregressive
    197–235. https://doi.org/10.1080/07474939608800353                                                  modeling. Journal of the American Statistical Association, 110, 246–261. https://doi.
Caballero, W. N., Lunday, B. J., & Meissner, F. (2024). Regulating the rebound effect in                org/10.1080/01621459.2014.892007
    the traveling purchaser problem. European Journal of Operational Research, 317,                Li, Y., Zhang, Y., Pan, A., et al. (2022). Carbon emission reduction effects of industrial
    660–677. https://doi.org/10.1016/j.ejor.2022.06.045                                                 robot applications: Heterogeneity characteristics and influencing mechanisms.
Cao, Q., Chi, C., & Shan, J. (2025). Can artificial intelligence technology reduce carbon               Technology in Society, 70, Article 102034. https://doi.org/10.1016/j.
    emissions? A global perspective. Energy Economics, 143, Article 108285. https://doi.                techsoc.2022.102034
    org/10.1016/j.eneco.2025.108285                                                                Liu, Y., Lin, B., & Xu, B. (2021). Modeling the impact of energy abundance on economic
Carroll, A. B., & Shabana, K. M. (2010). The business case for corporate social                         growth and CO2 emissions by quantile regression: Evidence from China. Energy, 227,
    responsibility: A review of concepts, research and practice. International Journal of               Article 120416. https://doi.org/10.1016/j.energy.2021.120416
    Management Reviews, 12, 85–105. https://doi.org/10.1111/j.1468-                                Liu, J., Liu, L., Qian, Y., & Song, S. (2022). The effect of artificial intelligence on carbon
    2370.2009.00275.x                                                                                   intensity: Evidence from China’s industrial sector. Socio-Economic Planning Sciences,
Cazzaniga, M., Jaumotte, F., Li, L., et al. (2024). Gen-AI: Artificial intelligence and the             83, 101002. https://doi.org/10.1016/j.seps.2020.101002
    future of work. Staff Discuss Notes, 2024, Article A001. https://doi.org/10.5089/              Liu, L., Rasool, Z., Ali, S., et al. (2024). Robots for sustainability: Evaluating ecological
    9798400262548.006.A001                                                                              footprints in leading AI-driven industrial nations. Technology in Society, 76, Article
Cecere, G., & Mazzanti, M. (2017). Green jobs and eco-innovations in European SMEs.                     102460. https://doi.org/10.1016/j.techsoc.2024.102460
    Resource and Energy Economics, 49, 86–98. https://doi.org/10.1016/j.                           Liu, B., Yang, X., & Zhang, J. (2024). Nonlinear effect of industrial robot applications on
    reseneeco.2017.03.003                                                                               carbon emissions: Evidence from China. Environmental Impact Assessment Review,
Chakraborty, S. (2024). Towards A comprehensive assessment of AI’s environmental                        104, Article 107297. https://doi.org/10.1016/j.eiar.2023.107297
    impact. arXiv Prepr arXiv240514004.                                                            Lv, H., Shi, B., Li, N., & Kang, R. (2022). Intelligent manufacturing and carbon emissions
Chen, Y., Cheng, L., & Lee, C.-C. (2022). How does the use of industrial robots affect the              reduction: Evidence from the use of industrial robots in China. International Journal
    ecological footprint? International evidence. Ecological Economy, 198, Article                      of Environmental Research and Public Health, 19.
    107483. https://doi.org/10.1016/j.ecolecon.2022.107483                                         Majeed, A., Xie, Y., Gao, C., et al. (2025). Examining the role of artificial intelligence,
Chen, P., Chu, Z., & Zhao, M. (2024). The road to corporate sustainability: The                         financial innovation, and green energy transition in enhancing environmental
    importance of artificial intelligence. Technology in Society, 76, Article 102440.                   quality. International Review of Economics & Finance, 100, Article 104092. https://
    https://doi.org/10.1016/j.techsoc.2023.102440                                                       doi.org/10.1016/j.iref.2025.104092
Chen, J., Huang, S., BalaMurugan, S., & Tamizharasi, G. S. (2021). Artificial intelligence         OECD. (2024). OECD artificial intelligence review of Germany. OECD Publ. https://doi.org/
    based e-waste management for environmental planning. Environmental Impact                           10.1787/609808d6-en
    Assessment Review, 87, Article 106498. https://doi.org/10.1016/j.eiar.2020.106498              Qing, L., Shahbaz, M., Meo, M. S., et al. (2024). Harnessing artificial intelligence-driven
Chen, S., Zhang, S., Zeng, Q., et al. (2023). Can artificial intelligence achieve carbon                industrial robotics for sustainability: Insights from leading green economies. Nat
    neutrality? Evidence from a quasi-natural experiment. Front Ecol Evol, 11.                          Resour Forum n/a. https://doi.org/10.1111/1477-8947.12492
Chernozhukov, V., & Hansen, C. (2008). Instrumental variable quantile regression: A                Rasheed, M. Q., Yuhuan, Z., Haseeb, A., et al. (2024). Asymmetric relationship between
    robust inference approach. Journal of Econometrics, 142, 379–398. https://doi.org/                  competitive industrial performance, renewable energy, industrialization, and carbon
    10.1016/j.jeconom.2007.06.005                                                                       footprint: Does artificial intelligence matter for environmental sustainability?
Dauvergne, P. (2022). Is artificial intelligence greening global supply chains? Exposing                Applied Energy, 367, Article 123346. https://doi.org/10.1016/j.
    the political economy of environmental costs. Review of International Political                     apenergy.2024.123346
    Economy, 29, 696–718. https://doi.org/10.1080/09692290.2020.1814381                            Saqib, N., Duran, I. A., & Ozturk, I. (2023). Unraveling the interrelationship of
DeCanio, S. J. (2016). Robots and humans – Complements or substitutes? Journal of                       digitalization, renewable energy, and ecological footprints within the EKC
    Macroeconomics, 49, 280–291. https://doi.org/10.1016/j.jmacro.2016.08.003                           framework: Empirical insights from the United States. Sustainability, 15.
Ding, T., Li, H., Liu, L., & Feng, K. (2024). An inquiry into the nexus between artificial         Saunders, H. D. (1992). The Khazzoom-Brookes postulate and neoclassical growth.
    intelligence and energy poverty in the light of global evidence. Energy Economics,                  Energy Journal, 13, 131–148. https://doi.org/10.5547/ISSN0195-6574-EJ-Vol13-
    136, Article 107748. https://doi.org/10.1016/j.eneco.2024.107748                                    No4-7
Ding, T., Li, J., Shi, X., et al. (2023). Is artificial intelligence associated with carbon        Shahbaz, M., Zakaria, M., Shahzad, S. J. H., & Mahalik, M. K. (2018). The energy
    emissions reduction? Case of China. Resources Policy, 85, Article 103892. https://doi.              consumption and economic growth nexus in top ten energy-consuming countries:
    org/10.1016/j.resourpol.2023.103892                                                                 Fresh evidence from using the quantile-on-quantile approach. Energy Economics, 71,
Doğan, B., Khalfaoui, R., Bergougui, B., & Ghosh, S. (2025). Unveiling the impact of the               282–301. https://doi.org/10.1016/j.eneco.2018.02.023
    digital economy on the interplay of energy transition, environmental transformation,           Shreyas Madhav, A. V., Rajaraman, R., Harini, S., & Kiliroor, C. C. (2022). Application of
    and renewable energy adoption. Research in International Business and Finance. ,                    artificial intelligence to enhance collection of E-waste: A potential solution for
    Article 102837. https://doi.org/10.1016/j.ribaf.2025.102837                                         household WEEE collection and segregation in India. Waste Management & Research,
Doğan, B., Tiwari, S., Bergougui, B., et al. (2025). Green innovation and fiscal spending:             40, 1047–1053.
    Decoding the path to sustainable development. Sustain Dev n/a. https://doi.org/                Siche, R., Pereira, L., Agostinho, F., & Ortega, E. (2010). Convergence of ecological
    10.1002/sd.3464                                                                                     footprint and emergy analysis as a sustainability indicator of countries: Peru as case
Doko Tchatoka, F., Masson, V., & Parry, S. (2019). Linkages between oil price shocks and                study. Communications in Nonlinear Science and Numerical Simulation, 15, 3182–3192.
    stock returns revisited. Energy Economics, 82, 42–61. https://doi.org/10.1016/j.                    https://doi.org/10.1016/j.cnsns.2009.10.027
    eneco.2018.02.016                                                                              Sim, N., & Zhou, H. (2015). Oil prices, US stock return, and the dependence between
Dong, M., Wang, G., & Han, X. (2024). Impacts of artificial intelligence on carbon                      their quantiles. Journal of Banking & Finance, 55, 1–8. https://doi.org/10.1016/j.
    emissions in China, in terms of artificial intelligence type and regional differences.              jbankfin.2015.01.013
    Sustainable Cities and Society. , Article 105682. https://doi.org/10.1016/j.                   Song, J., Chen, Y., & Luan, F. (2023). Air pollution, water pollution, and robots: Is
    scs.2024.105682                                                                                     technology the panacea. Journal of Environmental Management, 330, Article 117170.
Dosi, G. (1988). Sources, procedures, and microeconomic effects of innovation. Journal of               https://doi.org/10.1016/j.jenvman.2022.117170
    Economic Literature, 1120–1171.                                                                Sorrell, S., & Dimitropoulos, J. (2008). The rebound effect: Microeconomic definitions,
Escot, L., Sandubete, J. E., & Pietrych, Ł. (2023). Detecting structural changes in time                limitations and extensions. Ecological Economy, 65, 636–649. https://doi.org/
    series by using the BDS test recursively: An application to COVID-19 effects on                     10.1016/j.ecolecon.2007.08.013
    international stock markets. Mathematics, 11.                                                  Sun, Y., Gao, P., Raza, S. A., et al. (2023). The asymmetric effects of oil price shocks on
                                                                                                        the world food prices: Fresh evidence from quantile-on-quantile regression


                                                                                              21
B. Bergougui                                                                                                                                          Technology in Society 83 (2025) 103021

    approach. Energy, 270, Article 126812. https://doi.org/10.1016/j.                              Xie, T., & Wang, X. (2024). Investigating the nonlinear carbon reduction effect of AI:
    energy.2023.126812                                                                                  Empirical insights from China’s provincial level. Frontiers of Environmental Science,
Sun, C., Khan, A., & Cai, W. (2024). The response of energy aid and natural resources                   12.
    consumption in load capacity factor of the Asia Pacific emerging countries. Energy             Xu, B., & Lin, B. (2020). Investigating drivers of CO2 emission in China’s heavy industry:
    Policy, 190, Article 114150. https://doi.org/10.1016/j.enpol.2024.114150                            A quantile regression analysis. Energy, 206, Article 118159. https://doi.org/
Tao, W., Weng, S., Chen, X., et al. (2024). Artificial intelligence-driven transformations              10.1016/j.energy.2020.118159
    in low-carbon energy structure: Evidence from China. Energy Economics, 136, Article            Yang, S., & Liu, F. (2024). Impact of industrial intelligence on green total factor
    107719. https://doi.org/10.1016/j.eneco.2024.107719                                                 productivity: The indispensability of the environmental system. Ecological Economy,
Tu, C., Zang, C., Wu, A., et al. (2024). Assessing the impact of industrial intelligence on             216, Article 108021. https://doi.org/10.1016/j.ecolecon.2023.108021
    urban carbon emission performance: Evidence from China. Heliyon, 10, Article                   Yin, Z. H., & Zeng, W. P. (2024). Path to sustainable development: Can industrial
    e30144. https://doi.org/10.1016/j.heliyon.2024.e30144                                               intelligence and technological innovation balance economic growth and
Uche, E., Ngepah, N., Das, N., & Dey, L. (2024). Dynamic interactions of green                          environmental quality in China? Sustain Dev n/a. https://doi.org/10.1002/sd.2918
    innovations, green transitions and ecological load capacity factor in BRICS.                   Yu, L., Wang, Y., Wei, X., & Zeng, C. (2023). Towards low-carbon development: The role
    Renewable Energy, 231, Article 120905. https://doi.org/10.1016/j.                                   of industrial robots in decarbonization in Chinese cities. Journal of Environmental
    renene.2024.120905                                                                                  Management, 330, Article 117216. https://doi.org/10.1016/j.jenvman.2023.117216
Uriarte-Gallastegi, N., Arana-Landín, G., Landeta-Manzano, B., & Laskurain-Iturbe, I.              Yurtkuran, S., & Pata, U. K. (2024). The effect of nuclear and fossil fuel energy R& D
    (2024). The role of AI in improving environmental sustainability: A focus on energy                 expenditures on environmental qualities in Canada. Sustainable Energy Technologies
    management. Energies, 17, 649. https://doi.org/10.3390/en17030649                                   and Assessments, 68, Article 103872. https://doi.org/10.1016/j.seta.2024.103872
Wang, Q., Li, Y., & Li, R. (2024a). Ecological footprints, carbon emissions, and energy            Zhang, X., & Zhu, H. (2023). The impact of industrial intelligence on carbon emissions:
    transitions: The impact of artificial intelligence (AI). Humanities and Social Sciences             Evidence from the three largest economies. Sustainability, 15.
    Communications, 11, 1–18.                                                                      Zhao, P., Gao, Y., & Sun, X. (2022). How does artificial intelligence affect green economic
Wang, Q., Zhang, F., & Li, R. (2025). Artificial intelligence and sustainable development               growth?—Evidence from China. The Science of the Total Environment, 834, Article
    during urbanization: Perspectives on AI R&D innovation, AI infrastructure, and AI                   155306. https://doi.org/10.1016/j.scitotenv.2022.155306
    market advantage. Sustainable Development, 33, 1136–1156. https://doi.org/                     Zhao, C., Li, Y., Liu, Z., & Ma, X. (2024). Artificial intelligence and carbon emissions
    10.1002/sd.3150                                                                                     inequality: Evidence from industrial robot application. Journal of Cleaner Production,
Wang, Y., Zhang, R., Yao, K., & Ma, X. (2024b). Does artificial intelligence affect the                 438, Article 140817. https://doi.org/10.1016/j.jclepro.2024.140817
    ecological footprint? –Evidence from 30 provinces in China. Journal of Environmental           Zhong, J., Zhong, Y., Han, M., et al. (2024). The impact of AI on carbon emissions:
    Management, 370, Article 122458. https://doi.org/10.1016/j.jenvman.2024.122458                      Evidence from 66 countries. Applied Economics, 56, 2975–2989. https://doi.org/
Weber, H., & Weber, M. (2020). When means of implementation meet ecological                             10.1080/00036846.2023.2203461
    modernization theory: A critical frame for thinking about the sustainable                      Zhou, W., Zhuang, Y., & Chen, Y. (2024). How does artificial intelligence affect pollutant
    development goals initiative. World Development, 136, Article 105129. https://doi.                  emissions by improving energy efficiency and developing green technology. Energy
    org/10.1016/j.worlddev.2020.105129                                                                  Economics, 131, Article 107355. https://doi.org/10.1016/j.eneco.2024.107355
Xiao, Z. (2009). Quantile cointegrating regression. Journal of Econometrics, 150,                  Zhuk, A. (2023). Artificial intelligence impact on the environment: Hidden ecological
    248–260. https://doi.org/10.1016/j.jeconom.2008.12.005                                              costs and ethical-legal issues. J Digit Technol Law, 1, 932–954. https://doi.org/
                                                                                                        10.21202/jdtl.2023.40




                                                                                              22
