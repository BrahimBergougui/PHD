                                                                  Sustainable Cities and Society 112 (2024) 105621


                                                                      Contents lists available at ScienceDirect


                                                              Sustainable Cities and Society
                                                               journal homepage: www.elsevier.com/locate/scs




Investigating the relationships among green technologies, financial
development and ecological footprint levels in Algeria: Evidence from a
novel Fourier ARDL approach
Brahim Bergougui
International Institute of Social Studies (ISS), Erasmus University Rotterdam, the Hague, the Netherlands
National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria




A R T I C L E I N F O                                        A B S T R A C T

Keywords:                                                    Many recent initiatives have been introduced to enhance ecological sustainability by minimizing countries’
Green technologies                                           ecological footprints (EF). The focus has been on achieving environmental footprint neutrality through the
Financial development                                        application of green technologies (GT) and financial development (FD) in facilitating this transition. To deter­
Ecological footprint
                                                             mine the contribution of these variables to sustainability, this study investigated the effects of GT and FD on EF in
Ecological sustainability
Algeria
                                                             Algeria from Q1/1990 to Q4/2021. Additionally, this research examines the moderating role of GT with FD on
Fourier ARDL                                                 EF. To achieve these objectives, advanced Fourier autoregressive distributed lag techniques and the Fourier
                                                             causality test were employed. The findings reveal that FD increases EF, leading to ecological degradation.
                                                             Conversely, GT reduces EF in the long run, demonstrating its potential to foster ecological sustainability.
                                                             Notably, the study highlights the significant moderating role of GT in the FD-EF relationship. This underscores
                                                             the critical role of environmental technologies in mitigating the adverse effects of FD by facilitating creative
                                                             technologies and lowering EF. Therefore, the study recommends that Algeria integrates GT with FD to achieve
                                                             long-term reduction of environmental harm. In conclusion, Algeria needs to hasten GT in combination with
                                                             stronger FD to mitigate ecological impacts without compromising sustainable economic growth.




1. Introduction                                                                                         In the quest to address pressing environmental challenges and ach­
                                                                                                    ieve ecological sustainability, green technologies (GT) have emerged as
    Nowadays, climate change has become a pressing matter for hu­                                   a pivotal force, making it of paramount importance to organizations and
manity. The emission of greenhouse gases (GHGs) poses considerable                                  societies; Studies in this field have experienced an upward trend, mainly
threats to our survival and advancement, including scarcity of food re­                             in recent years (Adebayo et al. 2023; Bergougui and Aldawsari 2024). As
sources, extreme weather events, and decline of biodiversity. The ma­                               environmental degradation worsens, the importance of low-carbon
jority of studies have indicated that higher carbon dioxide (CO2)                                   development becomes more evident to the public. Hence, a large num­
emissions ominously exacerbate this problem (Habiba et al. 2023; Umar                               ber of organizations and societies have been directed toward GT as a
and Safi 2023; Bergougui and Murshed 2023). Therefore, there is a shift                             strategy to achieve environmental protection and economic growth
towards pointing out the implementation of Sustainable Development                                  (Umar et al. 2020; Abbasi et al. 2022; Bergougui et al. 2024a). GT offers
Goals (SDGs), specifically in reducing GHGs. To effectively combat                                  a promising avenue for reducing reliance on fossil fuels and transition­
climate change and its detrimental impact, international collaboration is                           ing toward sustainable energy sources, aligning with the global shift
essential. In December 2015, representatives from 196 nations convened                              towards eco-friendly growth (Copeland and Taylor 2004; Adebayo
at the conference of the parties in Paris, pledging to take a central role in                       2022). Antweiler et al. (2001) demonstrated that GT enables countries
addressing climate change and curbing GHGs. The main target of this                                 to reduce their carbon emissions while still growing their economies.
agreement is to restrain global temperature increase to below 2◦ C, with                            According to (Fussler and James 1996), sustainability and
efforts directed towards achieving a more ambitious target of 1.5◦ C and                            eco-innovation are linked through the idea that businesses can increase
attaining net-zero emissions by 2050 (UNFCCC 2015; Abbasi et al. 2022;                              profits and promote economic stability by developing innovative tech­
Qin et al. 2023; Amin et al. 2023; Bergougui et al. 2024b ).                                        nologies that support eco-friendly production, processes, and strategies.


    E-mail address: bergougui@iss.nl.

https://doi.org/10.1016/j.scs.2024.105621
Received 12 November 2023; Received in revised form 12 May 2024; Accepted 24 June 2024
Available online 25 June 2024
2210-6707/© 2024 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui                                                                                                         Sustainable Cities and Society 112 (2024) 105621


This approach aims to reduce the ecological impact of business activ­              established numerous research and development centers, providing
ities. Moreover, GT plays a multifaceted role in the pursuit of ecological         financial support to private enterprises focused on developing environ­
sustainability. It addresses growth limitations, enhances strategies for           mentally friendly technologies. Notably, Algeria ranked first in terms of
ecological pollution adaptation and mitigation, and impacts the effi­              patents for environmental technologies among African countries in 2019
ciency of various factors including green energy, service-oriented in­             (OECD, 2023). Moreover, Algeria boasts exceptional potential for har­
dustries, and ecological policies. this is in line with the propositions of        nessing renewable energy sources such as solar, wind, hydro,
neoclassical and new growth theorists, as well as the Malthusian theory            geothermal, and bio-power due to its favorable geographical location.
of population growth (Galor and Weil 2000). This convergence of                    However, it highlights the current limited contribution of low-carbon
technology, environmental conservation, and sustainable growth em­                 energy sources, which accounted for only 0.66 % of the country’s en­
phasizes the interdependence of these crucial elements in today’s world.           ergy mix in 2021 (EIA 2023). Recognizing the urgency of addressing
    Apart from GT, financial development (FD) is essential for economic            carbon emissions, the paper underscores the significance of formulating
growth because a well-functioning financial system can ensure eco­                 a comprehensive low-carbon development strategy. It details Algeria’s
nomic stability (Arestis and Demetriades 1997; Nguyen et al. 2022).                legislative efforts, including the national renewable energy program,
Conversely, it can also lead to increased energy consumption, which can            which aims to achieve 22 GW of renewable energy generation by 2035,
have detrimental environmental consequences that should not be                     representing 27 % of the country’s energy mix (Zahraoui et al. 2021).
overlooked (Khan et al. 2022; Xu et al. 2022). Recent studies on the               Furthermore, the government is actively seeking international collabo­
impact of FD on CO2 emissions have yielded conflicting results, leading            rations with suppliers specializing in engineering services, energy stor­
to inconclusive findings (Hussain et al. 2023; Tao et al. 2023). Two main          age systems, solar-tracking technologies, universal certification
viewpoints exist on the role of FD in ecological quality. On the one hand,         solutions, and solar application kits for agricultural purposes.
an improved financial sector that provides access to capital and facili­               The primary objective of this study is to discover the appropriate
tates investment can inadvertently contribute to an increase in CO2                strategy for addressing ecological concerns in Algeria and achieving its
emissions. This is primarily due to the potential for such a system to             climate footprint mitigation targets. This objective is further delineated
stimulate the growth of carbon-intensive industries and promote the                through the following three key questions.
adoption of energy-intensive technologies (Acheampong et al. 2020;
Anwar et al. 2022). On the other hand, FD has the potential to improve               (1) What is the ecological implication of GT for Algeria?
the quality of the environment by reducing carbon emissions through                  (2) Does FD indeed have a significant impact on the country’s EF?
the provision of funds for technological development and the facilitation            (3) Is there evidence of a mediating effect of a country’s level of GT
of energy-saving production processes (Ahmed et al. 2021). In essence,                   on the FD-EF nexus? Answering these questions will yield
FD enables firms and governments to adopt environmentally efficient                      meaningful contributions to the realm of environmental studies.
technologies that can reduce carbon emissions, thereby improving the                     Specifically, the study’s outcomes will reveal the ecological status
quality of the environment. Moreover, FD can promote good corporate                      of Algeria amid abundant resource revenue. These findings will
governance and create incentives that motivate companies to initiate                     also serve as a blueprint for the formulation of environmental
environmentally sustainable projects, further contributing to the                        policies, with applicability extending to nations sharing charac­
reduction of carbon emissions (Acheampong 2019; Sinha et al. 2021;                       teristics akin to Algeria.
Ahmad et al. 2022). As mentioned earlier, the existing research on the
impact of FD on CO2 emissions has not reached a consensus. This mo­
tivates our study to determine whether FD leads to an improvement or               1.1. Novelty and contribution of the study
degradation of the environment in Algeria.
    This paper proposes Algeria as a compelling case study for investi­               The current study has three key aspects that make it unique and
gating the multifaceted relationship between GT and FD, and their                  contribute to the existing literature on ecological degradation in the
combined impact on ecological degradation. Several factors substantiate            Algerian economy:
this choice. Algeria stands out as a major producer and consumer of
fossil fuels, with its economic structure heavily reliant on these re­               (1) In response to the limitations observed in prior scholarly assess­
sources. Data from the World Development Indicators (WDI 2023) re­                       ments, we employ novel Fourier ARDL approaches presented by
veals that a staggering 99.1 % of Algerian exports in 2023 stemmed from                  (Yilanci et al. 2020). Unlike (Nwani et al. 2021) which employed
fossil fuels, solidifying its position as a key player in the global energy              the ARDL models, the current study employed the Fourier ARDL
market. Furthermore, Algeria ranks as the third-largest consumer of                      which offers several unique advantages. For instance, there is no
energy in Africa, with fossil fuels contributing 99.75 % of the country’s                requirement for regressors’ integration order; they could be sta­
energy consumption in 2021 (BP 2023). This high dependence on fossil                     tionary at the level or the first differences. Additionally, seamless
fuels is attributed primarily to government policies that subsidize energy               detection of multiple structural changes; these tests can identify
prices, keeping them artificially low compared to market value (Elbadri                  numerous subtle structural changes within time-series data,
et al. 2023). Research by (Olivier 2020) identifies Algeria, alongside the               providing a more comprehensive analysis (Ozgur et al. 2022).
United States and the Russian Federation, as a significant contributors to           (2) In Algeria, most scholars have focused solely on using CO2
the global proliferation of fossil fuel hotspots, highlighting the extensive             emissions to gauge environmental degradation. For instance,
environmental consequences associated with such practices.                               recent studies by (Amri 2017; Rahmane et al. 2021; Nwani et al.
    Such extensive energy usage is inevitably linked to ecological                       2021; Touitou and Langarita 2021) have explored the impact of
degradation and an increased ecological footprint. According to the                      various macroeconomic factors on CO2 emissions. In contrast,
global footprint network (GFN, 2023), the ecological footprint                           (Chaouachi and Balsalobre-Lorente 2022) stands out as the only
(measured in millions of global hectares) soared from 9.55 in 1970 to                    study that included the EF as a measure of ecological degrada­
99.85 in 2022. This poses significant challenges for Algeria, particularly               tion. As a result, empirical evidence regarding the determinants
considering its commitment to the Paris Agreement, which mandates a 7                    of the EF in Algeria is still in its early stages of development. This
% reduction in CO2 emissions by 2030.                                                    highlights a notable scarcity of evidence on the factors influ­
    However, the paper moves beyond solely portraying Algeria as a                       encing Algeria’s EF. Numerous empirical studies are expected to
contributor to global environmental challenges. It emphasizes the na­                    shed more light on this subject, and the current study presents a
tion’s commitment to sustainable development and its efforts to drive                    unique research area. By including EF, the study recognizes the
green growth through technological innovation. The government has                        need to broaden our understanding of ecological degradation

                                                                               2
B. Bergougui                                                                                                        Sustainable Cities and Society 112 (2024) 105621


       beyond air pollution alone, as achieving climate objectives re­            2.1. Research on green technologies-ecological footprint nexus
       quires considering factors such as land requirements to sustain a
       viable population. Consequently, the inclusion of EF provides a                The realm of GT solutions across various industries is rapidly
       more complete and accurate depiction of the state of ecological            evolving, and there exist numerous viewpoints regarding GT’s role
       degradation in Algeria.                                                    concerning environmental principles and the benefits it offers in miti­
   (3) This study uniquely investigates the moderating role of green              gating EF (Numan et al. 2023). As stated by (Guo et al. 2020), GT in­
       technologies in shaping ecological footprint trajectories for              volves the creation of products and materials that incorporate one or
       Algeria, addressing a notable gap in existing investigations.              more essential elements of environmentally sustainable solutions. The
       Whereas preceding efforts such as (Khan et al. 2023; Bergougui             rise in the implementation and adoption of processes and products
       2024) only examined the overall number of patents as a proxy for           related to GT has made it more relevant to environmental consider­
       technological innovation. However, this approach may not                   ations, quality of life, and sustainability aspects (Xie et al. 2019). As
       accurately capture the environmental impact, as total patents              mentioned by (Sun et al. 2017), industries that allocate resources to
       include both green and non-green technologies. This novel                  green investments have exhibited enhanced ecological efficiency in
       analysis not only expands our understanding of the intricate               contrast to traditional sectors that do not embrace GT. In today’s chal­
       relationship between green technologies and ecological outcomes            lenging environmental conditions, ecological survival requires innova­
       but also offers valuable insights for policymakers. By elucidating         tion and investment in green technologies. Consequently, the distinct
       the specific contributions of green technologies to EF reduction,          features of contemporary ecological efficiency are progressively
       this study provides crucial information for designing and imple­           encompassing green renovations and green investments (Zhang et al.
       menting effective policies that accelerate clean technology                2022). Investing in GT offers numerous benefits in terms of long-run
       adoption and promote sustainable development in Algeria.                   ecological impacts. According to (Song et al. 2017) GT has a signifi­
   (4) Our study aims to examine the moderating effect of FD on EF                cant impact on the overall environmental cycle. Arguably, the most
       through GT in Algeria, which has not been investigated in the              pivotal benefit of investing in GT lies in its far-reaching environmental
       existing literature. This will provide valuable insights for poli­         impact. In contrast, conventional technologies, particularly those reliant
       cymakers in Algeria to understand the mechanisms through                   on fossil fuels, can inflict considerable harm on the environment,
       which FD influences EF and how GT plays a crucial role in this             underlining the necessity for businesses and all sectors to adopt GT.
       relationship. It will also assist in formulating more effective            These investments enable businesses the means to diminish their carbon
       policies that can mitigate ecological pressures and promote sus­           footprint, energy consumption, and water usage, contributing signifi­
       tainable development.                                                      cantly to the sustainability of their EF. The adoption of GT investments
                                                                                  also equips industries to incorporate technological practices that
    The empirical findings directly addressed the three research ques­            encompass both green engineering and green chemistry, ultimately
tions outlined above:                                                             leaving a distinct imprint on both EF and sustainability, as underscored
                                                                                  by (Ji et al. 2021).
 • Firstly, regarding the impact of GT on EF, the results demonstrate                 Inspired by the substantial role of GT in lessening the EF, several
   that GT exerts a negative and statistically significant effect on EF.          empirical studies investigate the connection between these two ele­
   Specifically, a 1 % increase in GT leads to a 0.0225 % reduction in EF         ments. For instance, (Ahmad et al. 2021) investigated the dynamic
   in the long run. This result suggests that greater investments and             interplay between GT and urbanization on EF of G-7 nations during the
   advancements in environmentally friendly technologies and pro­                 period spanning from 1980 to 2016. The results obtained from panel
   cesses, such as renewable energy sources and green manufacturing,              CS-ARDL analysis underscored the beneficial impact of GT on the
   contribute to lowering ecological degradation and greenhouse gas               environmental footprint. Exploring data from 1998 to 2018, (Jianguo
   emissions.                                                                     et al. 2022) employed the two-step System-GMM methodology to
 • Secondly, concerning the impact of FD on EF, the results reveal that           investigate the relationship between EF and GT in 37 OECD nations. The
   FD has a positive and statistically significant effect on EF. A 1 % rise       findings demonstrated that GT has a mitigating effect on EF in these
   in FD leads to a 0.5161 % increase in EF in the long run. This implies         regions. This finding aligns with (Rout et al. 2022) who explored the
   that greater financial development and easier access to financing              EF-GT relationship within BRICS nations. Their study, encompassing
   may enable economic activities and investments that are environ­               data from 1985 to 2016 and employing the augmented mean group
   mentally harmful, such as the expansion of polluting industries or             (AMG) estimator. The results concurred with previous studies, revealing
   funding of projects lacking ecological sustainability.                         that GT implementation leads to a reduction in EF within this this
 • Thirdly, regarding the moderating role of GT in the relationship               region.
   between FD and EF, the results of the interaction term GT*FD show a                Building on this research, (Ali et al. 2023), employ panel two-stage
   negative and significant coefficient. This indicates that higher levels        sequential techniques and the generalized method of moments to
   of GT mitigate the positive impact of FD on EF. In other words, ad­            analyze data from OECD countries (2003–2019). Their findings concur
   vancements in green technology serve to weaken the adverse effect              with the positive influence of GT on ecological sustainability. Further
   of financial development on ecological quality in Algeria.                     research by (Javed et al. 2023) utilizes a novel dynamic ARDL approach
                                                                                  to assess how GT, environmental taxes, and renewable energy con­
    The paper is organized as: A brief of prior studies is presented in           sumption affect EF in the economy of Italy. Their research highlights the
Section 2; Section 3 describes the data and methodology; Empirical re­            substantial environmental quality improvement brought about by GT,
sults are presented in Section 4; Finally, the conclusion and policy rec­         resulting in a reduction in EF. The moderating role of GT in achieving
ommendations are shown in Section 5.                                              carbon neutrality is explored by (Chen et al. 2023), employing the
                                                                                  STIRPAT framework on data from 17 emerging economies (1995–2019).
2. Literature review                                                              The robust panel analysis with Driscoll-Kraay standard errors un­
                                                                                  derscores that environment-related technologies contribute significantly
    This section carries out a comprehensive assessment of the theoret­           to a noteworthy enhancement in environmental quality. Building upon
ical and empirical literature on the interplay among green technologies           the work of Chen et al. (2023), (Kirikkaleli et al. 2023a) employed a
(GT), financial development (FD), and ecological footprint (EF). To               novel Fourier ARDL approach to examine the relationship between GT
facilitate a structured analysis, we have categorized the literature into         (proxied by patents related to environmental technologies) and EF in the
the following subsections:                                                        USA. Their outcomes revealed that GT indeed contributes to a reduction

                                                                              3
B. Bergougui                                                                                                       Sustainable Cities and Society 112 (2024) 105621


in EF. Additional studies by (Razzaq et al. 2023; Agrawal et al. 2023;           on environmental quality. Their findings suggest that FD helps reduce EF
Bergougui 2024) using diverse methodologies (NARDL, Quantile ARDL)               by facilitating investments in environmentally friendly products and
further solidify the importance of GT in addressing environmental                initiatives. This strengthens the argument that FD can be a viable
challenges.                                                                      strategy for mitigating environmental burdens.
                                                                                     Conversely, the pessimistic view portrays that FD can alleviate
2.2. Research on financial development-ecological footprint nexus                funding limitations and enable the expansion of economic activity and
                                                                                 energy consumption, thereby worsening ecological impact. Specifically,
    Recent scholarly literature has extensively discussed the relationship       a well-developed financial system can spur economic growth and
between FD and environmental quality (Habiba et al. 2023; Saqib et al.           improve the efficiency of resource allocation in an economy. However, it
2023; Ali et al. 2023). The empirical evidence has revealed two primary          may also lead to greater consumption and depletion of natural resources
viewpoints, which arise from differences in methodological approaches,           through increased industrialization and use of traditional energy sour­
timeframes under consideration, selection of countries, metrics used to          ces. In this way, FD could have negative environmental consequences by
measure FD, and the environmental indicators chosen (such as per                 enlarging a country’s ecological footprint (Saqib et al. 2023). For
capita CO2 emissions, ecological footprint, or carbon footprint) (Omoke          instance, (Ahmad et al. 2022) analyze panel data from emerging coun­
et al. 2020).                                                                    tries (1984–2017) using the CS-ARDL technique. Their findings chal­
    The optimistic view portrays that FD can ease the pressure of                lenge the positive association FD and EF. They argue that FD, while
financing in the energy sector, reduce the financing constraint of envi­         stimulating economic growth, might also increase affordability of fossil
ronmental protection investment, promote the development and appli­              fuels, potentially hindering progress towards ecological sustainability.
cation of renewable and other technologies, and act as a constructive            In alignment with this, a study conducted by (Ahmed et al. 2021)
agent for environmental improvement by providing the capital needed              employed an asymmetric ARDL approach to investigate the relationship
to invest in clean energy projects, effectively reducing energy con­             between FD and EF in Japan. Their findings diverge from the dominant
sumption and mitigating EF (Hu et al. 2023; Kartal et al. 2023). Sup­            trend, revealing a positive association. The authors propose that
porting this view, (Tamazian and Bhaskara Rao 2010) conducted a study            elevated levels of FD enhance the manufacturing processes and amplify
on the dynamic relationship between FD and the environment in 24                 energy consumption, ultimately resulting in a rise in the ecological
transition economies from 1993 to 2004. Their findings, derived from             deficit. Employing a different econometric approach, (Kihombo et al.
standard reduced-form modeling and GMM approaches demonstrated                   2021) investigate the FD-EF nexus in West Asia and Middle East
that FD has a positive impact on ecological sustainability. This is              (WAME) countries. The findings of the Continuously Updated Fully
credited to the fact that the financial sector has given funding for pro­        Modified (CUP-FM) method suggest that FD, measured by the IMF’s
jects focused on emission-free technologies, which enhance economic              financial development index, may contribute to ecological degradation.
growth while reducing reliance on traditional energy sources. Likewise,          In a parallel vein, (Afshan and Yaqoob 2022) employed an innovative
(Dogan and Seker 2016) inspected the causal relationship between FD              quantile ARDL approach and ascertained that over the long run, FD
and carbon emissions. Their study focused on leading economies from              diminishes the level of ecological degradation in China across all
1985 to 2011, employing the Fully Modified Ordinary Least Squares                quantiles. They propose that if conservation and management strategies
(FMOLS) and Dynamic Ordinary Least Squares (DOLS) techniques. The                are disregarded, the excessive reliance on FD could undermine the ob­
study found that FD plays a crucial role in lessening carbon emissions by        jectives of sustainable development in China. A recent study by (Balsa­
offering loans and incentives that encourage the adoption of updated             lobre-Lorente et al. 2023) explored the impact of FD on EF in
production technologies, ultimately leading to an improvement in                 Asia-Pacific Economic Cooperation countries from 1994 to 2018. Using
environmental quality. (Shahbaz et al. 2018) adopted a different                 the fully modified ordinary least squares method, they found that a 1 %
approach, employing the bootstrapping ARDL cointegration technique               increase in FD increases the level of EF, indicating that FD contributes to
to assess the long-run equilibrium relationship between carbon emis­             ecological deterioration. (Saqib et al. 2023) examined the relationship
sions and their influencing factors. Furthermore, they utilized boot­            between FD and EF in a panel of 11 emerging countries using the
strapping ARDL-based Granger causality to investigate the causal                 CS-ARDL approach for the period 1990–2019. Their findings indicate a
direction between these variables. Their findings, analyzing data from           positive impact of FD on EF, suggesting that FD in these countries may
France (1955–2016), indicated a negative impact of FD on carbon                  be contributing to environmental degradation. Several studies have
emissions. This suggests that FD may have contributed to improved                investigated the relationship between FD and CO2 emissions, a
environmental quality in France. Similarly, employing a panel threshold          commonly used indicator of environmental degradation.Using various
approach, (Abid et al. 2022) explored the effect of FD on ecological             econometric techniques, including AMG and two-stage sequential
sustainability in ten leading economies from 2000 to 2019 and                    techniques and GMM methods, these studies have consistently found
concluded that FD significantly reduces carbon emissions. Alike, (Chis­          that FD is associated with higher CO2 emissions (Habiba et al. 2023; Ali
hti and Sinha 2022) investigate the effects of shocks in both GT and FD          et al. 2023).
on carbon emissions within BRICS economies. Employing the
Augmented Mean Group (AMG) and Common Correlated Effect Mean
Group (CCEMG) techniques, their research reveals that positive shocks
(i.e., sudden positive changes) in FD contribute to a reduction in carbon
emissions. (Haldar and Sethi 2022) used Driscoll-Kraay estimators to
examine the impact of FD on carbon emissions. They found that FD
lowers carbon emissions and therefore enhances ecological quality in
emerging countries. (Usman et al. 2022) analyze data for eight Arctic
countries from 1990 to 2017. Employing multivariate composition ap­
proaches like MG, AMG, and CCEMG estimation methods, their findings
align with those reported by Haldar and Sethi (2022). Expanding the
methodological toolbox, additional studies have employed diverse
techniques such as threshold cointegration, fractional frequency cau­
sality, Panel ARDL, and method of moment quantile regressions. These
studies, including (Pata and Yilanci 2020; Caglar et al. 2021; Usman
et al. 2021; Xie et al. 2024) all point towards a positive influence of FD

                                                                             4
B. Bergougui                                                                                                                   Sustainable Cities and Society 112 (2024) 105621


2.3. Research on the moderation effect of GT on the FD-EF nexus                        Table 1
                                                                                       Summary of existing studies in the literature.
    Researchers have employed various systematic approaches,                            Panel (A). Recent literature on green technologies-ecological footprint nexus
including mediating effect models1 and moderating effect models (also
                                                                                        Author(s)        Sample                 Period         Methodology         Main
known as interaction)2, to explore the relationships among variables.                                                                                              Findings
For example, in a study that used a global balanced panel dataset
                                                                                        (Saqib et al.    Top-ten countries      1990–2019      CCEMG;              GT ↓ EF
spanning 62 countries from 2003 to 2018, (Zhao et al. 2021) examined                      2024)          with the biggest EF                   AMG
the causal mediation effect of GT on the association between financial                  (Qayyum          Southern Common        1990–2021      CS-ARDL             GT ↓ EF
risk and CO2 emissions. Employing the system-GMM methodology, their                       et al.         Market
findings suggest a dual impact of financial risk on CO2 emissions. Firstly,               2024)          (MERCOSUR)
                                                                                                         economies
a direct negative association exists, indicating that financial risk inde­
                                                                                        (Aytun et al.    Middle-income          1980–2016      CS-ARDL             GT | EF
pendently reduces emissions. Secondly, an indirect effect is observed,                    2024)          countries
whereby financial risk fosters technological innovation, which in turn                  (Ntom            Russia                 2000–2021      MOLS; DOLS;         GT ↓ EF
contributes to mitigating carbon emissions. Regarding the conditional                     Udemba                                               CCR; ARDL
effect model (i.e., which uses the interaction term), (Jianguo et al. 2022)               et al.
                                                                                          2024)
employed the two-step system-GMM methodology to examined how GT                         (Qing et al.     Six South Asian        1990–2020      CCEMG;
and FD interact to impact CO2 emissions indicators in OECD economies.                     2024)          countries                             AMG
They found that the interaction term between GT and FD had a signif­                    (Kirikkaleli     USA                    1970–2018      Fourier ARDL        GT ↓ EF
icant negative impact on CO2 emissions. This suggests that FD plays a                     et al.
                                                                                          2023a)
crucial role in reducing CO2 emissions when technology development
                                                                                        (Tauseef         USA                    1985–2016      DARDL; KRLS         GT ↓ EF
acts as a facilitating factor in this relationship. (Ali et al. 2023) inves­              Hassan
tigated the impacts of GT, FD, and their interaction term on ecological                   et al.
sustainability in OECD countries. The findings of two-stage sequential                    2023)
techniques and GMM methods reveal a negative impact of the interac­                     (Saqib et al.    Emerging               1990–2019      CCEMG; AMG          GT ↓ EF
                                                                                          2023)          economies
tion term between GT and FD on CO2 emissions. This implies that the                     (Yasmeen         Belt & Road region     1992–2017      CS-ARDL;            GT ↓ EF
development of GT in host nations plays a pivotal role in mitigating CO2                  et al.                                               Driscoll &
emissions resulting from FD, where GT has an environmentally friendly                     2022)                                                Kraay
effect on reducing CO2 levels. In a study conducted by (Habiba et al.                   (Hussain and     BRICS                  1992–2016      ARDL; AMG           GT ↓ EF
                                                                                          Dogan
2023), a moderating effect model was employed to investigate the in­
                                                                                          2021)
fluence of GT, FD, and renewable energy on environmental quality,                       (Destek and      BEM (Big               1995–2016      FMOLS               GT ↓ EF
focusing on emerging countries during the period spanning from 1990 to                    Manga          Emerging Markets)
2020. Employing the AMG estimator, their research findings revealed                       2021)
that FD contributes to the enhancement of environmental quality by                      (Chu 2022)       20 OECD countries      1990 to        D-KSE; FGLS;        GT ↓ EF
                                                                                                                                2015           PCSE; CS-
operating through the GT pathway. Table 1 provides an overview of                                                                              ARDL; PMG
existing studies on the interplay between GT, FD, and EF.
                                                                                        Panel (B). Recent literature on financial development-ecological footprint nexus

                                                                                        Author(s)         Sample               Time           Methodology         Main
2.4. Critical evaluation of prior research                                                                                     period                             Findings

                                                                                        (Saqib et al.     Top-ten              1990–2019      CCEMG               FD ↑ EF
   A review of existing literature on the impact of GT and FD on the EF                   2024)           countries with                      AMG
                                                                                                          the biggest EF
reveals shortcomings in methodology, sample selection, variable choice,
                                                                                        (Aytun et al.     Middle-income        1980–2016      CS-ARDL             FD ↓ EF
and consideration of moderation effects.                                                  2024)           countries
                                                                                        (Guliyev          European             1992–2020      Bayesian Model      FD ↑ EF
 • Methodological limitations: The prevalent use of traditional                           2024)           countries                           Averaging
   models like FMOLS, DOLS, CCR, ARDL, and NARDL restricts data                         (Ntom             Russia               2000–2021      MOLS; DOLS;         FD ↓ EF
                                                                                          Udemba                                              CCR; ARDL
   analysis. These methods require specific assumptions about the
                                                                                          et al. 2024)
   integration order of variables, potentially leading to inaccurate re­                (Saqib et al.     Emerging             1990–2019      CCEMG;              FD ↑ EF
   sults if violated. Additionally, they struggle to capture the com­                     2023)           economies                           AMG
   plexities of time series data, particularly when structural breaks                   (Wang et al.      14 emerging          1995–2020      CCEMG;              FD ↑ EF
   (sudden changes in the relationship between variables) or seasonal                     2023)           European                            AMG
                                                                                                          nations
   variations occur.                                                                    (Aslam et al.     43 middle-           1990–2020      Panel Quantile      FD ↓ EF
 • Limited scope of analysis: Prior research often relies on CO2                          2023)           income                              Regression
   emissions or other pollutants as proxies for environmental degra­                                      countries
   dation. While valuable, these indicators may not fully capture the                                     45 high-income
                                                                                                          countries
                                                                                        (Ashraf et al.    124 economies                       System GMM          FD ↑ EF
                                                                                          2022)
 1
    Mediating effect models are statistical analyses that aim to identify and           (Nathaniel        MENA countries       1990–2016      AMG                 FD ↑ EF
explain the mechanism or process that underlies an observed relationship be­              et al. 2020)
tween an independent variable and a dependent variable via the inclusion of a           (Mrabet and       Qatar                1980–2011      ARDL                FD ↑ EF
third hypothetical variable, known as a mediator variable (Jollineau and Bowen            Alsamara
                                                                                          2017)
2023).
  2                                                                                     (Ahmed et al.     Malaysia             1971–2014      ARDL                FD ↓ EF
    A moderating effect model is a statistical model that examines how a third
                                                                                          2019)
variable (the moderator) affects the relationship between two other variables
(the independent and dependent variables). The moderating variable alters the          Notes: EF = ecological footprint, GT = green technologies, FD = financial
strength or direction of the relationship between the independent and depen­           development, ↑= increases, ↓ = decreases, | = no impact.
dent variables, indicating that the relationship is contingent upon the level or
presence of the moderating variable (Jollineau and Bowen 2023).

                                                                                   5
B. Bergougui                                                                                                           Sustainable Cities and Society 112 (2024) 105621


   intricate nature of environmental deterioration. The ecological                Table 2
   footprint provides a more comprehensive measure. Furthermore,                  Data source and description.
   there is a critical gap in research specifically examining the interplay        Data                Code   Unit                              Source of data
   between GT, FD, and EF in Algeria, despite being the third largest
                                                                                   Dependent variables
   emitter in Africa.                                                              Ecological          EF     Total global hectare              Global Footprint
 • Missing the moderation effect: The potential moderating effect of                 footprint                                                  Network (2022)
   GT on the relationship between FD and EF has been largely unex­                 Independent variables
   plored. It is possible that GT strengthens or weakens the impact of FD          Green               GT     Patents related to the            OECD (2023)
                                                                                     technologies             environment as (% total
   on EF.                                                                                                     patents)
 • Addressing the gaps: This study aims to overcome these limitations              Financial           FD     Index (0–100)                     IMF (2023)
   by employing the Fourier ARDL approach. This method offers several                development
   advantages: (i) It does not require pre-determining the integration             Control variables
                                                                                   GDP per capita      GDP    Constant 2015 international $     WDI (2023)
   order of variables, making it suitable for data with mixed integration
                                                                                   Energy              EC     Kg of oil equivalent              EIA (2023)
   properties. (ii) It can seamlessly detect and account for multiple                consumption
   structural changes and seasonal variations within the data, providing
                                                                                  Notes: USD denotes the United States Dollar, WDI symbolizes the World
   a more nuanced picture of the relationships between GT, FD, and EF.
                                                                                  Development Indicators, and EIA represents the U.S. Energy Information
                                                                                  Administration publication. We use the natural logarithm of these variables in
   By using the Fourier ARDL approach, focusing on the EF in Algeria,             our estimation.
and exploring the moderating effect of GT on the FD-EF nexus, this study
seeks to provide a more comprehensive and nuanced understanding of
                                                                                  Table 2 offers comprehensive information regarding the measurement
the complex interplay between these factors.
                                                                                  and sources of all the variables employed.
3. Data and methodology
                                                                                  3.2. Justifications for variable selection
3.1. Data
                                                                                     This research investigates the influence of GT and FD on EF in
    The primary objective of this study is to assess the effect of GT and         Algeria. The selection of variables is guided by the following theoretical
FD, as well as their interaction (GT*FD), on EF in Algeria, while con­            and empirical underpinnings:
trolling for GDP and EC. We sourced our data from various outlets: EF
data is derived from the global footprint network, GT data is collected           3.2.1. Dependent variable
from (OECD, 2023), FD data is obtained from the IMF, and GDP and EC                  Ecological footprint (EF): The ecological footprint serves as a
information are gathered from the U.S. Energy Information Adminis­                comprehensive measure of environmental sustainability, capturing the
tration publication (EIA, 2023) and the World Bank (WDI, 2023),                   demand on biocapacity imposed by human activities (Bergougui and
respectively. To understand the relationship between environmental                Aldawsari 2024), Its inclusion as the dependent variable is motivated by
impact and technological development in Algeria, refer to Fig.1, which            growing concerns over global warming and ecological degradation
showcases the trends in ecological footprint and green technologies. Our          posing significant challenges for communities and nations (Guliyev
model is based on quarterly data spanning from 1990/q1 to 2021/q4. To             2024).
address discrepancies in measurement units and the presence of outliers,
we transformed all variables into logarithmic series before conducting            3.2.2. Independent variables
the empirical analysis. This logarithmic transformation was employed to               Green Technologies (GT): Theoretically, GT can mitigate ecological
standardize measurement units and facilitate the normalization of out­            impact by offering solutions for polluting sectors (Behera et al. 2023).
liers. This methodology, as advocated by Razzaq et al. (2023) helps               Existing research supports this notion, suggesting that GT can enhance
overcome issues related to data distribution and yields elasticity values         environmental quality (Habiba et al. 2023).
as the outcome. The dependent variable in our investigation is EF, and                Financial Development (FD): While no overarching theory directly
                                                                                  links FD and EF, the motivation stems from the EKC hypothesis. The




                                            Fig. 1. Ecological footprint and green technologies trends in Algeria.

                                                                              6
B. Bergougui                                                                                                        Sustainable Cities and Society 112 (2024) 105621


inverted U-shaped EKC relationship posits that lower levels of FD may              • Stationarity and cointegration tests: We conducted unit root tests to
increase EF due to reliance on resource-intensive production methods,                check the stationarity of the variables and then determine if the
whereas higher FD may reduce EF through the adoption of advanced                     variables have a long-term relationship using the bounds test.
eco-friendly technologies (Saqib et al. 2024). However, empirical evi­             • Assessing long-run effects: We employ the Fourier ARDL approach to
dence on the FD-EF link remains mixed (Aytun et al. 2024).                           evaluate how GT, FD, and their interaction influence EF in the long
                                                                                     run.
3.2.3. Control variables                                                           • Examining causal relationships: We applied the single Fourier-
    GDP per Capita: The EKC theory posits that economic growth can                   frequency Toda Yamamoto causality test to assess the causal
influence ecological sustainability. Study by (Javed et al. 2023) high­              relationship.
lights economic growth as a potential driver of ecological degradation.            • Robustness checks: we used alternative estimation methods (FMOLS,
    Energy Consumption: Fossil fuel reliance increases carbon foot­                  DOLS, and CCR) and substituted the dependent variable to confirm
print. Energy policies promoting green growth and sustainable jobs can               the baseline Fourier ARDL results.
reduce environmental deterioration (Saqib et al. 2023). Additionally,              • Results and discussion: Lastly, we analyzed and discussed the
rapid economic growth and energy use pose threats to biodiversity and                empirical results.
ecological sustainability (Sharif et al. 2020).
                                                                                  3.4. Model specification and Fourier ARDL framework
3.3. Methodology
                                                                                     Given that this study aims to explore the effect of GT and FD on EF in
   This study follows a series of steps to examine the long-term effects of
                                                                                  Algeria from 1990/q1 to 2021/q4 by applying the Fourier ARDL
GT and FD, and their interaction (GT*FD) on EF in Algeria. These steps
                                                                                  approach presents the model for the empirical analysis.
are as follows (see Fig. 2):
                                                                                  EFt = α0 + α1 (GT)t + α2 (FD)t + α3 (CON)t + μt                               (1)
 • Data collection and description: We gathered sample data from
   various sources and summarized its key characteristics.                        where EFt is the ecological footprint; GTt and FDt represent green
                                                                                  technologies innovation and financial development respectively; CONt
                                                                                  stands for control variables including gross domestic product per capita




                                                                Fig. 2. Analysis flowcharts.

                                                                              7
B. Bergougui                                                                                                                                                Sustainable Cities and Society 112 (2024) 105621


and energy consumption. Thus, from Eq. (1), GT and FD reduce EF if                                             (7).
their respective coefficients α1 and α2 are negative and significant at
                                                                                                               H0C : β2 = β3 = β4 = 0                                                                            (7)
standard levels.
   Apart from examining the direct effects, we also explore the potential                                          In the context of examining co-integration, it is essential to reject
mediating effect of a country’s level of GT on the relationship between                                        Eqs. (5), (6), and (7). This methodology provides more robust results
FD and EF. To examine this, we introduce an interactive term of GT and                                         compared to the standard ARDL methodology. (McNown et al. 2018) did
FD, resulting in the Eq. (2) as follows:                                                                       not account for the integration levels of the variables. However, when
                                                                                                               compared to the standard ARDL model, this approach yields more robust
EFt = α0 + α1 (GT)t + α2 (FD)t + α3 (GTI ∗ FD)t + α4 (CON)t + μt                                    (2)
                                                                                                               empirical outcomes. Additionally, this method identifies structural
    The coefficient α3 in Eq. (2) represents the multiplicative interactive                                    changes using Fourier functions, eliminating the need for extra struc­
term and provides insight into how GT impacts the FD-EF nexus. Table 2                                         tural change tests or modifications to the estimated model. The Fourier
describes the variables used in the analysis, while Table 3 presents the                                       function introduced by (Yilanci et al. 2020) takes into consideration
descriptive statistics of the time series data.                                                                structural changes within the model, as illustrated in Eq. (8).
    Traditional cointegration tests become problematic when dealing                                                     n         (      ) ∑ n         (      )
                                                                                                                      ∑            2π kt                 2πkt
with variables that exhibit different levels of integration. To address this                                   d(t) =      ak sin         +     bk cos                               (8)
issue, (Pesaran et al. 2001) introduced the autoregressive distributed lag                                             k=1
                                                                                                                                    T       k=1
                                                                                                                                                          T
(ARDL) cointegration test. The ARDL methodology allows for the in­                                                 In Eq. (8), "n" denotes the number of frequencies, π = 3.14, "k" rep­
clusion of independent variables with different levels of integration                                          resents the number of specific frequencies chosen, "t" signifies the trend,
when the dependent variable is integrated at order 1 (I (1)). Eq. (3) and                                      and "T" stands for the sample size. We adhere to the approach proposed
(4) illustrate the ARDL models used in this study.                                                             by (Ludlow and Enders 2000; Becker et al. 2006), which permits the
    To assess the cointegration relationship between the variables, we                                         utilization of a single frequency as follows:
compare the test statistics with the lower and upper bounds specified as I                                                  (      )          (      )
(0) and I (1). The core hypothesis of no cointegration is rejected if the                                                     2πkt              2πkt
                                                                                                               d(t) = γ1 sin         + γ2 cos                                          (9)
test statistic exceeds the critical upper bound values. Eqs. (3) and (4)                                                       T                 T
present the ARDL model used in this study.
                                                                                                                  The Fourier augmented regressive distributed lag (FARDL) model
ΔEFt = α0 + α1 (EF)t− 1 + α2 (GT)t− 1 + α3 (FD)t− 1 + α4 (CON)t− 1                                             used in this study is depicted in Eqs. (10) and (11) as follows:
                                                                                                                                  (      )          (      )
               ρ− 1
               ∑                   ρ− 1
                                   ∑                   ρ− 1
                                                       ∑                                                                           2π kt              2πkt
                                                                                                               ΔEFt = α0 + γ1 sin          + γ2 cos
                     ʹ                   ʹ                   ʹ
         +          γi (ΔEF)t− 1 +      ϑi (ΔGT)t− 1 +      σ i (ΔFD)t− 1                                                                                    + α1 (EF)t− 1 + α2 (GT)t− 1
                                                                                                                                     T                 T
               i=1                     i=1                       i=1
                                                                                                                                                               ρ− 1
                                                                                                                                                               ∑                        ρ− 1
                                                                                                                                                                                        ∑
               ρ− 1
               ∑
         +
                       ʹ
                      φi (ΔCON)t− 1 + εt                                                            (3)                + α3 (FD)t− 1 + α4 (CON)t− 1 +                 γʹi (ΔEF)t− 1 +           ϑʹi (ΔGT)t− 1
                                                                                                                                                                i=1                      i=1
                i=1
                                                                                                                           ρ− 1
                                                                                                                           ∑                        ρ− 1
                                                                                                                                                    ∑
ΔEFt = α0 + α1 (EF)t− 1 + α2 (GT)t− 1 + α3 (FD)t− 1 + α4 (GT ∗ FD)t− 1                                                 +          σʹi (ΔFD)t− 1 +          φʹi (ΔCON)t− 1 + εt
                                                                                                                           i=1                      i=1
                                 ρ− 1                     ρ− 1
                                 ∑                        ∑                                                                                                                                                     (10)
         + α5 (CON)t− 1 +               γʹi (ΔEF)t− 1 +          ϑʹi (ΔGT)t− 1
                                 i=1                      i=1                                                                     (      )          (      )
                                                                                                                                   2π kt              2πkt
               ρ− 1
               ∑                        ρ− 1
                                        ∑                                   ρ− 1
                                                                            ∑                                  ΔEFt = α0 + γ1 sin          + γ2 cos          + α1 (EF)t− 1 + α2 (GT)t− 1
         +            σʹi (ΔFD)t− 1 +          τʹi (ΔGT ∗ FD)t− 1 +                φʹi (ΔCON)t− 1                                   T                  T
                i=1                      i=1                                i=1                                                                                                          ρ− 1
                                                                                                                                                                                         ∑
         + μt                                                                                                          + α3 (FD)t− 1 + α4 (GT ∗ FD)t− 1 + α5 (CON)t− 1 +                        γʹi (ΔEF)t− 1
                                                                                                                                                                                          i=1
                                                                                                    (4)                    ρ− 1                     ρ− 1                      ρ− 1
                                                                                                                           ∑                        ∑                         ∑
   The symbol Δ denotes the first difference operative, "ρ" represents                                                 +          ϑʹi (ΔGT)t− 1 +          σʹi (ΔFD)t− 1 +           τʹi (ΔGT ∗ FD)t− 1
                                                                                                                           i=1                      i=1                       i=1
the lag length, and "εt " represents the disturbance term with a mean of
                                                                                                                           ρ− 1
                                                                                                                           ∑
zero and finite variance. The optimal lag length is selected based on the                                              +          φʹi (ΔCON)t− 1 + μt
Akaike information criteria (AIC). In the study by (Pesaran et al. 2001),                                                  i=1
the cointegration relationship was determined using both the F test (FA)                                                                                                                                        (11)
and the t-test (t), as illustrated below.
                                                                                                                   To the suggestions made by (Yilanci et al. 2020) adopt the frequency
H0A : β1 = β2 = β3 = β4 = 0                                                                         (5)        value that yields the minimum sum of squared errors. They employ
                                                                                                               bootstrap simulations to estimate critical values (CV) for the FA, FB, and
H0B : β1 = 0                                                                                        (6)        t-tests.
   Eqs. (5) and (6) were adapted by (McNown et al. 2018) to introduce a                                            It is well-established that environmental economics time series data,
new F-test (FB) designed to assess the null hypothesis, as presented in Eq.                                    such as GT, FD, GDP, and EF, are vulnerable to structural breaks over


Table 3
Descriptive Statistics.
                                    EF                                 GT                             FD                            GT*FD                             GDP                             EC

  Mean                              0.248160                           0.723236                       1.788367                      1.293678                          2.044255                        0.102505
  Median                            0.243657                           0.722051                       1.788253                      1.293473                          2.060322                        0.077685
  Maximum                           0.367438                           1.057066                       1.817021                      1.871808                          2.088666                        0.233856
  Minimum                           0.152224                           0.136443                       1.758304                      0.240463                          1.984735                        0.015469
  Std. Dev.                         0.064125                           0.206103                       0.015014                      0.369042                          0.035127                        0.077971
  Skewness                          0.048338                           –0.856110                      0.011114                      –0.860334                         –0.345071                       0.437750
  Kurtosis                          1.544414                           3.691139                       2.014033                      3.685507                          1.510328                        1.597158
  Observations                      132                                132                            132                           132                               132                             132


                                                                                                           8
B. Bergougui                                                                                                                               Sustainable Cities and Society 112 (2024) 105621


time (Nawaz et al. 2019). Ignoring these issues can lead to spurious                                 variables to analyze the impact of GT and FD on EF in Algeria.
inferences and inaccurate model estimates. Consequently, addressing                                      Since the results of the unit root tests enable us to explore the pos­
structural breaks is vital when analyzing such data.                                                 sibility of cointegration among the variables, we present the FARDL
    The Fourier ARDL model offers a robust approach to address this                                  cointegration results in Table 5. According to the co-integration results,
challenge. Unlike other advanced econometric techniques, including                                   the t-test statistics for models (1) and (2) exceed the critical values. This
linear and nonlinear augmented ARDL models, and cointegration tech­                                  scrutiny signifies the existence of a long-term relationship between the
niques like FMOLS and DOLS, Fourier ARDL explicitly incorporates                                     variables in models (1) and (2), suggesting the presence of cointegration
structural breaks, into the model framework (Enders & Lee, 2012). This                               using the Fourier approach.
characteristic is particularly advantageous for economic and environ­                                    In the next phase, this study employs the FARDL estimator to assess
mental time series that are inherently prone to such disruptions.                                    the impact of GT and FD on EF in Algeria. To achieve this objective, the
Furthermore, Fourier ARDL possesses the additional benefit of providing                              study includes controls for both GDP and EC. Table 6 shows the FARDL
a more comprehensive analysis of cointegration (Syed et al. 2024). It                                long-run estimates.
goes beyond the simple rejection of the null hypothesis of no cointe­                                    At the outset, the effect of GT on EF, as observed in the model (1) of
gration, characteristic of traditional methods. Fourier ARDL delves                                  Table 6, we find a negative effect of GT on EF where a 1 % increase in GT
deeper to reveal the underlying cointegration relationship, offering                                 dampens EF by 0.0225 % in the long run. Thus, the dampening impact of
valuable insights into the long-run dynamics between the variables                                   GT implies that higher levels of patents on environmental technologies
(Aydin et al. 2024). In essence, Fourier ARDL offers a two-fold advan­                               are linked to an improvement in environmental quality. This result is not
tage (Syed et al. 2023):                                                                             far-fetched. GT in cleaner and ecologically friendly processes can lead to
                                                                                                     the development of new, environmentally friendly energy sources,
  [1]. It effectively addresses the issue of structural breaks, enhancing                            reducing dependence on fossil fuels and thereby decreasing environ­
       the model’s reliability,                                                                      mental degradation. In essence, increased GT, which fosters the dis­
  [2]. It provides a more complete picture of co-integration, leading to                             covery of new environmentally-friendly energy solutions and promotes
       richer interpretations.                                                                       efficient land use and consumption through green manufacturing, con­
                                                                                                     tributes to the reduction of the EF (Xu and Lin 2018; Ibrahim and Vo
    Due to these merits, Fourier ARDL emerges as a superior choice for                               2021). (Ahmad et al. 2020) provide examples of this phenomenon,
the current analysis, investigating the relationship between GT, FD, and                             highlighting how Germany uses flue-gas desulfurization tools and
EF.                                                                                                  France relies on nuclear energy, both of which enhance environmental
                                                                                                     quality by reducing greenhouse gas emissions. Japan, in a similar vein,
4. Empirical results and discussion                                                                  utilizes both nuclear energy and flue-gas desulfurization tools, further
                                                                                                     demonstrating their positive impact on environmental quality through
    In our study, we conduct unit root tests using both the FADF and ADF                             the reduction of greenhouse gases. Furthermore, as noted by (Kirikkaleli
methods, as detailed in Table 4. The outcomes of these unit root tests                               et al. 2023a), the USA plays an active role in advancing its green strat­
reveal that the time-series variables GT and GT*FD exhibit integration at                            egy. This includes extensive efforts to decarbonize transportation, sup­
level I (0), whereas EF, FD, GDP, and EC are integrated at order I(1).                               port the adoption of electric cars, and implement various forms of broad
These results demonstrate a mixed order of integration among the time-                               renewable energy technologies. These initiatives collectively contribute
series variables. Given the mixed order of integration in our time series                            to the country’s commitment to ecological sustainability. The observed
data, it becomes feasible to implement FARDL models in this study. As                                mitigating effect of GT on EF aligns with the findings of several studies
the next step, we investigate the cointegration between the selected                                 conducted by various researchers, including (Habiba et al. 2023;
                                                                                                     Agrawal et al. 2023; Saqib and Dincă 2023; Behera et al. 2023)).
                                                                                                         Regarding FD in the model (1) of Table 6, the empirical results
Table 4                                                                                              suggest the coefficient of FD is positive, implying that an increase in FD
Fourier ADF and ADF unit root tests.
                                                                                                     positively affects EF by 0.516 % in the long run. Therefore, the evidence
               Fourier ADF unit root test (Enders and Lee 2012)                                      suggests that enhanced FD in Algeria is not conducive to supporting
               Fourier      F-stat      Frequency     Fourier ADF-          F-stat   Frequency       environmental quality. In essence, while GT contributes to enhancing
               ADF-stat                               stat                                           environmental quality by reducing EF, greater FD appears to have a
               At Level                               At First Difference                            detrimental impact on environmental quality. Notably, when comparing
  EF           –1.890       3.639       1.000         –5.389***           2.311      1.000           the coefficients of GT and FD, it becomes evident that the adverse effect
  GT           –4.236**     4.642       1.000         –5.799***           1.960      5.000           of FD on environmental quality is more significant than the positive
  FD                        4.782       1.000                             1.395      3.000
               –3.158                                 –4.580***
                                                                                                     effect of GT on environmental quality. There are two plausible expla­
  GT*FD        –4.211**     4.663       1.000         –5.800***           1.946      5.000
  GDP          –1.289       2.241       5.000         –3.959**            2.931      1.000           nations through which, enhanced FD lessens the environmental quality:
  EC           –1.224       7.583       1.000         –5.477***           7.460      1.000           (i) Financial institutions and markets make more financial resources
  Fourier ADF Test Critical Values
                                                                                                     accessible to businesses, making the production of high-energy-
                                                                                                     intensive goods more affordable to various economic agents like vehi­
  Frequency                    1%                     5%                                10 %
                                                                                                     cles and household appliances, which, in turn, contribute to higher
  1                            − 4.42                 − 3.81                            − 3.49
  3                            − 3.77                 − 3.07                            − 2.71
  5                            − 3.58                 − 2.93                            − 2.60       Table 5
  ADF unit root test                                                                                 Fourier ADL cointegration analysis.

                    At Level                                   At First Difference                    Model                                     Test            Frequency     Min AIC
                                                                                                                                                statistics
                    t-Statistic              Prob.             t-Statistic             Prob.
  EF                –0.985945                0.7569            –4.899331***            0.0001         Model       EF=f (GT, FD, GDP, EC)        –5.288104       1             –8.138731
  GT                –3.029535**              0.0349            –5.494135***            0.0000          (1)
  FD                –1.385360                0.5876            –4.319598***            0.0000         Model       EF=f (GT, FD, GT*FD, GDP,     –4.393116       1             –8.052612
  GT*FD             –2.989488**              0.0386            –5.497379***            0.0000          (2)        EC)
  GDP                                        0.6724                                    0.0178
                    –1.201746                                  –3.281266**
                                                                                                     Note: *, **, and *** denote 10 %, 5 %, and 1 % significance levels, respectively.
  EC                0.114503                 0.9657            –4.134370***            0.0012
                                                                                                     The critical values at the 1 %, 5 %, and 10 % levels for the FADL test are 5.147,
Note: *, **, and *** denote 10 %, 5 %, and 1 % significance levels, respectively.                    4.428, and 4.042, respectively.

                                                                                                 9
B. Bergougui                                                                                                              Sustainable Cities and Society 112 (2024) 105621


Table 6
Fourier ARDL long-run estimation results.
  Dependent variable= EF

                              Model (1)                                                                   Model (2)

  Variables                   Coefficient                 Std. Error                 Prob.                Coefficient                 Std. Error                Prob.

  EFt–1                       1.346178***                 0.077528                   0.0000               1.336402***                 0.071702                  0.0000
  GT                          –0.022554***                0.007611                   0.0037               –0.840649***                0.317436                  0.0092
  FD                          0.516102***                 0.167063                   0.0025               0.500549**                  0.246316                  0.0451
  GT*FD                       /                           /                          /                    –0.489055***                0.146161                  0.0011
  GDP                         1.018010*                   0.568231                   0.0766               0.457869*                   0.241899                  0.0613
  EC                          0.521447***                 0.118499                   0.0000               0.416289***                 0.104027                  0.0001
  CointEq (− 1) *             –0.059112***                0.016694                   0.0006               –0.060872***                0.015799                  0.0002

Note: *, **, and *** denote 10 %, 5 %, and 1 % significance levels, respectively.


energy consumption and potential environmental damage (Sadorsky                          carbon-neutral economies. These findings are consistent with the results
2011; Habiba et al. 2023). Furthermore, well-developed financial sys­                    of other studies, such as (Ibrahim and Vo 2021; Jianguo et al. 2022).
tems attract both domestic and foreign investments, which, in turn, have                     To ensure the reliability of the results, this paper employs the
environmental costs due to increased EF. (ii) This finding may also be                   CUSUM and CUSUM of squares methods, along with the Breusch-
associated with financial markets and institutions in Algeria providing                  Godfrey serial correlation LM test and residual diagnostic tests. These
funding for projects that lack ecological sustainability, including the                  approaches are used to assess the stability of the two models and ensure
expansion of oil drilling operations and the construction of large-scale                 that they are free from issues related to heteroskedasticity and serial
oil refineries and polluting industries.                                                 correlation. In the empirical evaluation, it is crucial to examine the
    This study’s results, which indicate that FD harms Algeria’s envi­                   stability of the models and conduct residual diagnostic tests. This is
ronmental sustainability, are inconsistent with those of two earlier                     essential to make informed policy decisions concerning GT, FD, GDP,
studies by Nwani et al. (2021) and Khan et al. (2023). Those studies                     and EC, to reduce environmental impact in Algeria. Figs. 3–6 represent
reported that FD enhances the Algerian environment by reducing                           visual representations of the cumulative stability tests. The CUSUM and
pollution levels (Nwani et al. 2021) and carbon emissions (Khan et al.                   CUSUM of squares results reveal that the statistical values fall within
2023). The different econometric methods used by the studies may ac­                     acceptable limits. Additionally, Table 7 presents the results of LM,
count for these divergent results. Specifically, this current study utilizes             Heteroskedasticity, and Ramsey Reset tests.
the Fourier ARDL approach, while the other studies relied on conven­                         The conclusions drawn from these tests confirm the stability of the
tional ARDL or other techniques like fully modified OLS (FMOLS) and                      model. This signifies that the coefficients in the error-correction model
dynamic OLS (DOLS). The Fourier ARDL allows for detecting smooth                         remain stable and can guide policy decisions aimed at reducing the
breaks and structural changes in the data, which other traditional                       carbon footprint in Algeria. To provide more effective policy recom­
methods fail to model properly. This likely explains why this study                      mendations, it is essential, and indeed sufficient, to analyze the in­
draws an inference of the negative impact of FD on environmental                         terrelationships among EF, GT, FD, GDP, and EC. The Fourier-frequency
sustainability, contradicting previous Algerian studies. The conven­                     Toda-Yamamoto Causality test results presented in Table 8 were
tional ARDL, FMOLS, and DOLS may have led to spurious findings of                        employed to evaluate this interrelationship.
associations between FD and EF in the long run. Thus, the Fourier ARDL                       According to the findings, changes in GT have a causal effect on
approach employed here provides improved modeling and likely a more                      changes in EF in Algeria. This implies that advancements in environ­
accurate picture of the lack of impact of FD on Algeria’s environment.                   mental innovations play a significant role in predicting ecological sus­
Moreover, this discrepancy could also be due to the role of green                        tainability. Furthermore, the study demonstrates that FD, GDP, and EC
financial systems in reducing EF. The financial sector can contribute to a               have a causal impact on EF. The results of the Fourier-frequency Toda-
more environmentally friendly economy by supporting energy innova­                       Yamamoto causality test corroborate the conclusions drawn in previous
tion and other initiatives.                                                              research by (Addai et al. 2023; Kirikkaleli et al. 2023b).
    Given that FD increases EF, we investigate the moderation role of GT                     This study conducts further robustness checks on the baseline results
in FD–EF nexus. In other words, we investigate whether higher GT                         by using data from 1990/q1 to 2021/q4 and performing several sensi­
dampens or magnifies the positive effect of FD on EF as specified in Eq.                 tivity analyses presented in Table 9. Alternative estimation methods
(11). The results are presented in model 2 of Table 6. In the FARDL                      (FMOLS, DOLS, and CCR) are applied, and the dependent variable is
results, the coefficients for GT and FD maintain their negative and                      substituted. For comparison purposes, Table 6 baseline results are
positive signs, respectively, although their magnitudes differ. Notably,                 reproduced in Column 1 of Table 9.
the coefficient for GT increases in absolute terms from 0.0225 to 0.8406,
indicating a more significant improvement in environmental quality.
Conversely, the coefficient for FD decreases from 0.5161 to 0.5005. As a
result, compared to the earlier findings in model (1), our results in model
(2) suggest that the positive impact of GT on environmental quality is
more pronounced than the dampening impact of FD. Shifting the focus
to the mediating role of GT in the relationship between FD and EF, the
study finds a negative and statistically significant coefficient for the
interaction term (GT*EF) in the long run. Considering the positive effect
of FD and the negative coefficient of the interaction term (GT*EF), we
can deduce that as FD improves, it leads to an increase in EF, but higher
levels of GT serve to mitigate the detrimental impact of FD on ecological
sustainability. An analysis by (Tamazian et al. 2009) confirmed that the
use of FD helps traded companies advance their efforts in promoting GT,
aiming to establish more energy-efficient systems and foster
                                                                                                           Fig. 3. Cumulative Sum for model (1).

                                                                                    10
B. Bergougui                                                                                                                       Sustainable Cities and Society 112 (2024) 105621


                                                                                          Table 8
                                                                                          Single Fourier-frequency Toda-Yamamoto Causality Test Result.
                                                                                           Null Hypothesis               Direction           Wald                Bootstrap p-value

                                                                                           GT does not cause EF          GT→EF               33.488***           0.017
                                                                                           FD does not cause EF          FD→EF               31.902***           0.019
                                                                                           GDP does not cause EF         GDP→EF              33.914***           0.013
                                                                                           EC does not cause EF          EC→EF               88.06***            0.000

                                                                                          Note: *, **, and *** display the significance at the 1 %, 5 %, and 10 % signifi­
                                                                                          cance level. → signifies the direction of the causality.



                                                                                          Table 9
                                                                                          Sensitivity analyses.
                                                                                           Variables   Baseline         Alternative estimation methods              EF Per Capita
                Fig. 4. Cumulative Sum of squares for model (1).                                       results (EF is                                               as an
                                                                                                                        FMOLS          DOLS          CCR
                                                                                                       the                                                          alternative
                                                                                                       dependent                                                    dependent
                                                                                                       variable)                                                    variable

                                                                                                       (1)              (2)            (3)           (4)            (5)

                                                                                           Model (1)
                                                                                           GT          –0.0225***       –0.953***      –0.703***     –0.613***      –0.0990***
                                                                                           FD          0.5161***        0.392          0.953**       0.409*         0.1388**
                                                                                           GT*FD       /                /              /             /              /
                                                                                           GDP         1.0180*          0.973***       0.897***      0.920***       1.0461
                                                                                           EC          0.5214***        0.436***       0.505***      0.559***       0.8056***
                                                                                           Model (2)
                                                                                           GT          –0.8406***       –1.389**       –0.883***     –0.495**       –0.0174**
                                                                                           FD          0.5005**         1.62*          1.011*        0.032          0.3849***
                                                                                           GT*FD       –0.4890***       –1.325         –1.97**       –0.486***      –0.1283***
                                                                                           GDP         0.4578*          0.862***       0.406*        0.912***       1.8524**
                                                                                           EC          0.4162***        0.642**        0.591***      0.507***       0.3476***

                                                                                          Note: *, **, and *** indicate 10 %, 5 %, and 1 % significance levels, respectively.
                                                                                          FMOLS: Fully modified ordinary least squares; DOLS: dynamic ordinary least
                                                                                          squares; CCR: canonical cointegrating regression.
                      Fig. 5. Cumulative Sum for model (2).
                                                                                          account for endogeneity and serial correlation. As evidenced by Col­
                                                                                          umns 2–4 of Table 9, these methods produce results that are in line with
                                                                                          the Fourier ARDL long-run estimates in Column 1 in terms of sign and
                                                                                          significance for model (1) and model (2) with minor exceptions. For
                                                                                          instance, FD becomes statistically insignificant under FMOLS. Overall,
                                                                                          the long-run Fourier ARDL estimates with ecological footprint as the
                                                                                          dependent variable are robust.
                                                                                              Regarding the substitution of the dependent variable with the
                                                                                          ecological footprint per person. The results do not significantly change
                                                                                          the main findings either, as shown in Column 5 of Table 9. The co­
                                                                                          efficients remain similar except for one change: the previously signifi­
                                                                                          cant positive effect of GDP on EF becomes insignificant while retaining
                                                                                          its positive sign. This provides further evidence of the robustness of the
                                                                                          core results. In summary, the baseline findings hold up well against a set
                                                                                          of sensitivity tests using alternative estimators and specifications. This
                                                                                          strengthens confidence in the main conclusions.

                                                                                          5. Conclusion and policy implications
                Fig. 6. Cumulative Sum of squares for model (2).
                                                                                          5.1. Conclusion

Table 7                                                                                       In the past, the financial industry overlooked its impact on the
Diagnostic Result for the Fourier Model.                                                  environment, which resulted in a range of environmental issues
  Test                                 Model (1)              Model (2)                   including climate change, pollution, habitat loss, and resource deple­
                                       F-statistic   Prob.    F-statistic   Prob.         tion. To address these pressing concerns, the financial sector has taken
                                                                                          steps to introduce financial products designed to protect the environ­
  Breusch-Godfrey Serial Correlation   0.993637      0.3734   1.463236      0.2358
    LM Test                                                                               ment. Consequently, this study’s primary objective is to investigate how
  Heteroskedasticity Test: Breusch-    0.843714      0.6818   1.520457      0.1275        green technologies, financial development, and their interaction can
    Pagan-Godfrey                                                                         collectively enhance ecological sustainability in Algeria for the period
  Ramsey Reset                         1.728890      0.1912   1.887448      0.1722        1990/q1 to 2021/q4. We employ advanced econometric techniques
                                                                                          such as the Fourier ARDL approach and Fourier Toda-Yamamoto cau­
    The alternative estimation methods of FMOLS, DOLS, and CCR                            sality to analyze the tripartite relationships. The Fourier ARDL approach


                                                                                     11
B. Bergougui                                                                                                          Sustainable Cities and Society 112 (2024) 105621


offers a distinct advantage by identifying structural changes using               between GT, FD, and EF in Algeria compare with existing research. The
Fourier functions, eliminating the need for structural break detection or         observed inconsistencies in the literature, particularly concerning the
model modification in Fourier models.                                             impact of FD on EF, can be attributed to the different econometric
    The empirical findings yielded three key insights:                            methodologies employed. While this study leverages the Fourier ARDL
                                                                                  approach, earlier investigations by Nwani et al. (2021) and Khan et al.
 • First, green technologies significantly reduced ecological footprint in        (2023) relied on conventional ARDL or alternative techniques like
   the long run, with a 1 % increase in green technologies lowering               FMOLS and DOLS. The Fourier ARDL offers a distinct advantage in its
   ecological footprint by 0.0225 %. This suggests investments in                 ability to detect smooth structural breaks and changes in the data, a
   renewable energy and green manufacturing lower ecological degra­               capability lacking in traditional methods. This enhanced modeling ca­
   dation and emissions.                                                          pacity likely explains why our study infers a positive impact of FD on EF,
 • Second, financial development positively and significantly impacted            contradicting previous Algerian research. The conventional ARDL,
   the ecological footprint, with a 1 % rise increasing it by 0.5161 % in         FMOLS, and DOLS techniques may have yielded spurious findings of
   the long run, implying easier access to financing may enable                   long-run associations between FD and EF. Consequently, the Fourier
   ecologically harmful economic activities and investments.                      ARDL approach employed here provides a more accurate picture of the
 • Third, the interaction term (green technologies*financial develop­             nuanced relationship between these variables, suggesting a lack of sig­
   ment) exhibits a negative and significant coefficient, indicating that         nificant impact of FD on Algeria’s environment. Our results align with
   higher levels of green technologies mitigate the positive impact of            individual country-level studies conducted by Nwani et al. (2021), Khan
   financial development on ecological footprint. Specifically, a 1 % rise        et al. (2023), and Bergougui (2024), who all explored the impact of GT
   in financial development leads to a 0.489055 % increase in ecolog­             and FD on environmental sustainability. Notably, these studies represent
   ical footprint in the long run, implying that advancements in green            the only existing research examining the combined effect of GT and FD
   technology serve to weaken the adverse effect of financial develop­            on environmental outcomes. These studies, however, did not delve into
   ment on ecological quality in Algeria.                                         the specific influence of GT on the relationship between FD and EF,
                                                                                  which is a key contribution of our research. Furthermore, a prevalent
   The study further confirms the expected negative impact of economic            limitation within existing research (Nwani et al. 2021; Khan et al. 2023;
growth and energy consumption on ecological sustainability in Algeria.            Bergougui 2024) is the use of total patent counts as a proxy for tech­
Additionally, the Fourier-Toda-Yamamoto causality analysis reveals                nological innovation. This approach fails to capture the true ecological
bidirectional causality between green technologies, financial develop­            impact of GT, as it encompasses patents for technologies that may not be
ment, and the ecological footprint.                                               environmentally friendly. Our study addresses this gap by distinguishing
                                                                                  between "dirty" and "green" technologies, thereby offering a more
5.2. Policy implication                                                           nuanced understanding of how innovation, particularly through the lens
                                                                                  of GT, shapes environmental sustainability.
    The study’s findings offer valuable insights for shaping economic
policies in Algeria. Consequently, the following policy recommenda­               5.4. Study limitation and proposal for future study
tions are put forth:
    Firstly, the study underlines the positive impact of green technolo­              Despite its contributions to existing literature, this study has iden­
gies on ecological sustainability. Therefore, policymakers should                 tified several limitations that could guide future research endeavors.
vigorously support eco-friendly technologies to propel green initiatives.             Firstly, the analysis in this study is limited in its consideration of only
Policymakers must ensure green technology aligns with sustainable                 one aspect of green technologies; future research could incorporate
development goals, addressing economic and ecological challenges. To              additional variables like government R&D expenditures, research pub­
enhance environmental conditions, the establishment of green tech­                lications per 1000 residents, and the global innovation index.
nology guidelines is vital. Innovative technologies, coupled with envi­               Secondly, the study’s reliance on a financial development index,
ronmental benefits, can create a collaborative marketplace among                  with its mixed environmental impacts, could be refined by adopting
competing firms, fostering synergy. Furthermore, the advantages of                green finance that focuses on environmentally positive investments.
green technologies can promote sustainable growth and generate                    Subsequent studies should consider this improved measure for a more
employment opportunities, contributing to the attainment of Sustain­              precise understanding of the relationship between green finance and
able Development Goal 8 (SDG8).                                                   environmental quality.
    Secondly, our findings indicate that financial development has a                  Thirdly, due to data constraints for Algeria, we could not account for
detrimental impact on the environment, highlighting the necessity for             the influence of environmental protection funds and ecological resto­
policymakers to reform financial structures in the country to mitigate            ration projects on the country’s footprint. As better Algerian data be­
environmental degradation. Algeria should take proactive steps to                 comes available, future analyses should examine how investments in
innovate and enhance financial instruments, diverting investment away             conservation and restoration affect ecological degradation.
from polluting industries towards environmentally friendly projects.                  Lastly, as this research was exclusively conducted in Algeria, future
Moreover, continuous adjustments to the regulations, laws, and internal           investigations might expand to encompass the entire African region,
requirements of financial institutions are essential to minimize envi­            providing insights into regional-level environmental degradation within
ronmental issues stemming from economic growth.                                   a single or panel data framework.
    Lastly, another important finding is that energy consumption and
economic growth have detrimental impacts on ecological sustainability.            CRediT authorship contribution statement
Algerian Governments and policymakers must formulate sustainable
and efficient environmental policies and regulations. To reduce                      Brahim Bergougui: Writing – review & editing, Writing – original
ecological footprints without hampering economic growth, the                      draft, Visualization, Validation, Supervision, Software, Resources,
replacement of outdated technologies with state-of-the-art alternatives           Project administration, Methodology, Investigation, Formal analysis,
is imperative.                                                                    Data curation, Conceptualization.

5.3. Comparison with previous findings                                            Declaration of competing interest

    This section examines how our findings regarding the relationship                The authors declare that they have no known competing financial

                                                                             12
B. Bergougui                                                                                                                                 Sustainable Cities and Society 112 (2024) 105621


interests or personal relationships that could have appeared to influence                          Arestis, P., & Demetriades, P. (1997). Financial development and economic growth:
                                                                                                       Assessing the evidence. The Economic Journal, 107, 783–799. https://doi.org/
the work reported in this paper.
                                                                                                       10.1111/j.1468-0297.1997.tb00043.x
                                                                                                   Ashraf, A., Nguyen, C. P., & Doytch, N. (2022). The impact of financial development on
Data availability                                                                                      ecological footprints of nations. Journal of Environmental Management, 322, Article
                                                                                                       116062. https://doi.org/10.1016/j.jenvman.2022.116062
                                                                                                   Aslam, B., Zhang, G., Amjad, M. A., et al. (2023). Does the impact of financial
    Data will be made available on request.                                                            development reinforce sustainability ecological footprint? Fresh evidence from
                                                                                                       middle and high-income economies. Journal of Cleaner Production, 429, Article
                                                                                                       139573. https://doi.org/10.1016/j.jclepro.2023.139573
                                                                                                   Aydin, M., Degirmenci, T., Bozatli, O., & Balsalobre-Lorente, D. (2024). Fresh evidence of
References                                                                                             the impact of economic complexity, health expenditure, natural resources, plastic
                                                                                                       consumption, and renewable energy in air pollution deaths in the USA? An empirical
Abbasi, K. R., Hussain, K., Haddad, A. M., et al. (2022). The role of financial development            approach. The Science of the Total Environment, 921, Article 171127. https://doi.org/
     and technological innovation towards sustainable development in Pakistan: Fresh                   10.1016/j.scitotenv.2024.171127
     insights from consumption and territory-based emissions. Technological Forecasting            Aytun, C., Erdogan, S., Pata, U. K., & Cengiz, O. (2024). Associating environmental
     and Social Change, 176, Article 121444. https://doi.org/10.1016/j.                                quality, human capital, financial development and technological innovation in 19
     techfore.2021.121444                                                                              middle-income countries: A disaggregated ecological footprint approach. Technology
Abid, N., Ceci, F., Ahmad, F., & Aftab, J. (2022). Financial development and green                     in Society, 76, Article 102445. https://doi.org/10.1016/j.techsoc.2023.102445
     innovation, the ultimate solutions to an environmentally sustainable society:                 Balsalobre-Lorente, D., Topaloglu, E. E., Nur, T., & Evcimen, C. (2023). Exploring the
     Evidence from leading economies. Journal of Cleaner Production, 369, Article                      linkage between financial development and ecological footprint in APEC countries:
     133223. https://doi.org/10.1016/j.jclepro.2022.133223                                             A novel view under corruption perception and environmental policy stringency.
Acheampong, A. O. (2019). Modelling for insight: Does financial development improve                    Journal of Cleaner Production, 414, Article 137686. https://doi.org/10.1016/j.
     environmental quality? Energy Economics, 83, 156–179. https://doi.org/10.1016/j.                  jclepro.2023.137686
     eneco.2019.06.025                                                                             Becker, R., Enders, W., & Lee, J. (2006). A stationarity test in the presence of an unknown
Acheampong, A. O., Amponsah, M., & Boateng, E. (2020). Does financial development                      number of smooth breaks. Journal of Time Series Analysis, 27, 381–409. https://doi.
     mitigate carbon emissions? Evidence from heterogeneous financial economies.                       org/10.1111/j.1467-9892.2006.00478.x
     Energy Economics, 88, Article 104768. https://doi.org/10.1016/j.                              Behera, P., Haldar, A., & Sethi, N. (2023). Achieving carbon neutrality target in the
     eneco.2020.104768                                                                                 emerging economies: Role of renewable energy and green technology. Gondwana
Addai, K., Genç, S. Y., Castanho, R. A., et al. (2023). Financial risk and environmental               Research: International Geoscience Journal, 121, 16–32. https://doi.org/10.1016/j.
     sustainability in Poland: Evidence from novel Fourier-based estimators.                           gr.2023.03.028
     Sustainability, 15, 5801. https://doi.org/10.3390/su15075801                                  Bergougui, B. (2024). Moving toward environmental mitigation in Algeria: Asymmetric
Adebayo, T. S. (2022). Environmental consequences of fossil fuel in Spain amidst                       impact of fossil fuel energy, renewable energy and technological innovation on CO2
     renewable energy consumption: A new insights from the wavelet-based Granger                       emissions. Energy Strategy Reviews, 51, Article 101281. https://doi.org/10.1016/j.
     causality approach. International Journal of Sustainable Development & World Ecology,             esr.2023.101281
     29, 579–592. https://doi.org/10.1080/13504509.2022.2054877                                    Bergougui, B., & Aldawsari, M. I. (2024). Asymmetric impact of patents on green
Adebayo, T. S., Ağa, M., & Kartal, M. T. (2023). Analyzing the co-movement between                    technologies on Algeria’s Ecological Future. Journal of Environmental Management,
     CO2 emissions and disaggregated nonrenewable and renewable energy consumption                     355, Article 120426. https://doi.org/10.1016/j.jenvman.2024.120426
     in BRICS: Evidence through the lens of wavelet coherence. Environmental Science and           Bergougui, B., Ayad, H., Ghosh, S., & Doğan, B. (2024a). Do green total factor productivity
     Pollution Research, 30, 38921–38938. https://doi.org/10.1007/s11356-022-24707-                    and digital economy matter for energy transition: Evidence from Chinese cities. https://
     w                                                                                                 doi.org/10.2139/ssrn.4795205
Afshan, S., & Yaqoob, T. (2022). The potency of eco-innovation, natural resource and               Bergougui, B, Mehibel, S, & Boudjana, RH (2024b). Asymmetric nexus between green
     financial development on ecological footprint: A quantile-ARDL-based evidence                     technologies, economic policy uncertainty, and environmental sustainability:
     from China. Environmental Science and Pollution Research, 29, 50675–50685. https://               Evidence from Algeria. J Environ Manage, 360, 121172. https://doi.org/10.1016/j.
     doi.org/10.1007/s11356-022-19471-w                                                                jenvman.2024.121172
Agrawal, R., Agrawal, S., Samadhiya, A., et al. (2023). Adoption of green finance and              Bergougui, B., & Murshed, S. M. (2023). Aggregate and disaggregate impact of natural
     green innovation for achieving circularity: An exploratory review and future                      resources on sustainable development: New evidence from the latest institutional
     directions. Geoscience Frontiers. , Article 101669. https://doi.org/10.1016/j.                    data. Environmental and Sustainability Indicators, 20, Article 100302. https://doi.org/
     gsf.2023.101669                                                                                   10.1016/j.indic.2023.100302
Ahmad, M., Ahmed, Z., Yang, X., et al. (2022). Financial development and environmental             BP (2023) statistical review of world energy.
     degradation: Do human capital and institutional quality make a difference?                    Caglar, A. E., Mert, M., & Boluk, G. (2021). Testing the role of information and
     Gondwana Research: International Geoscience Journal, 105, 299–310. https://doi.org/               communication technologies and renewable energy consumption in ecological
     10.1016/j.gr.2021.09.012                                                                          footprint quality: Evidence from world top 10 pollutant footprint countries. Journal
Ahmad, M., Jiang, P., Murshed, M., et al. (2021). Modelling the dynamic linkages                       of Cleaner Production, 298, Article 126784. https://doi.org/10.1016/j.
     between eco-innovation, urbanization, economic growth and ecological footprints                   jclepro.2021.126784
     for G7 countries: Does financial globalization matter? Sustainable Cities and Society,        Chaouachi, M., & Balsalobre-Lorente, D. (2022). Environmental strategies for achieving a
     70, Article 102881. https://doi.org/10.1016/j.scs.2021.102881                                     new foreign direct investment golden decade in Algeria. Environmental Science and
Ahmad, M., Khattak, S. I., Khan, A., & Rahman, Z. U. (2020). Innovation, foreign direct                Pollution Research, 29, 37660–37675. https://doi.org/10.1007/s11356-021-18149-z
     investment (FDI), and the energy–pollution–growth nexus in OECD region: A                     Chen, F., Ali, S., Ma, J., et al. (2023). Material productivity and environmental
     simultaneous equation modeling approach. Environmental and Ecological Statistics,                 degradation: Moderating role of environment-related technologies in achieving
     27, 203–232. https://doi.org/10.1007/s10651-020-00442-8                                           carbon neutrality. Gondwana Research: International Geoscience Journal, 117,
Ahmed, Z., Wang, Z., Mahmood, F., et al. (2019). Does globalization increase the                       155–168. https://doi.org/10.1016/j.gr.2023.01.010
     ecological footprint? Empirical evidence from Malaysia. Environmental Science and             Chishti, M. Z., & Sinha, A. (2022). Do the shocks in technological and financial
     Pollution Research, 26, 18565–18582. https://doi.org/10.1007/s11356-019-05224-9                   innovation influence the environmental quality? Evidence from BRICS economies.
Ahmed, Z., Zhang, B., & Cary, M. (2021). Linking economic globalization, economic                      Technology in Society, 68, Article 101828. https://doi.org/10.1016/j.
     growth, financial development, and ecological footprint: Evidence from symmetric                  techsoc.2021.101828
     and asymmetric ARDL. Ecological Indicators, 121, Article 107060. https://doi.org/             Chu, L. K. (2022). Determinants of ecological footprint in OCED countries: Do
     10.1016/j.ecolind.2020.107060                                                                     environmental-related technologies reduce environmental degradation?
Ali, K., Jianguo, D., Kirikkaleli, D., et al. (2023). Do green technological innovation,               Environmental Science and Pollution Research, 29, 23779–23793. https://doi.org/
     financial development, economic policy uncertainty, and institutional quality matter              10.1007/s11356-021-17261-4
     for environmental sustainability? All Earth, 35, 82–101. https://doi.org/10.1080/             Copeland, B. R., & Taylor, M. S. (2004). Trade, growth, and the environment. Journal of
     27669645.2023.2200330                                                                             Economic Literature, 42, 7–71. https://doi.org/10.1257/002205104773558047
Amin, N., Shabbir, M. S., Song, H., et al. (2023). A step towards environmental                    Destek, M. A., & Manga, M. (2021). Technological innovation, financialization, and
     mitigation: Do green technological innovation and institutional quality make a                    ecological footprint: Evidence from BEM economies. Environmental Science and
     difference? Technological Forecasting and Social Change, 190, Article 122413. https://            Pollution Research, 28, 21991–22001. https://doi.org/10.1007/s11356-020-11845-2
     doi.org/10.1016/j.techfore.2023.122413                                                        Dogan, E., & Seker, F. (2016). The influence of real output, renewable and non-
Amri, F. (2017). The relationship amongst energy consumption (renewable and non-                       renewable energy, trade and financial development on carbon emissions in the top
     renewable), and GDP in Algeria. Renewable & Sustainable Energy Reviews, 76, 62–71.                renewable energy countries. Renewable & Sustainable Energy Reviews, 60, 1074–1085.
     https://doi.org/10.1016/j.rser.2017.03.029                                                        https://doi.org/10.1016/j.rser.2016.02.006
Antweiler, W., Copeland, B. R., & Taylor, M. S. (2001). Is free trade good for the                 EIA. (2023). U.S. energy information administration publication 2023.
     environment? The American Economic Review, 91, 877–908. https://doi.org/                      Elbadri, M., Bsikre, S., Alamari, O., & Balcilar, M. (2023). Nexus between renewable
     10.1257/aer.91.4.877                                                                              energy consumption, economic growth, and CO2 emissions in Algeria: New evidence
Anwar, A., Sinha, A., Sharif, A., et al. (2022). The nexus between urbanization,                       from the Fourier-Bootstrap ARDL approach. Natural Resources Forum, 47, 393–412.
     renewable energy consumption, financial development, and CO2 emissions:                           https://doi.org/10.1111/1477-8947.12292
     Evidence from selected Asian countries. Environment, Development and Sustainability,
     24, 6556–6576. https://doi.org/10.1007/s10668-021-01716-2


                                                                                              13
B. Bergougui                                                                                                                                 Sustainable Cities and Society 112 (2024) 105621

Enders, W., & Lee, J. (2012). A unit root test using a fourier series to approximate smooth            Sustainable Energy Reviews, 70, 1366–1375. https://doi.org/10.1016/j.
     breaks. Oxford Bulletin of Economics and Statistics, 74, 574–599. https://doi.org/                rser.2016.12.039
     10.1111/j.1468-0084.2011.00662.x                                                              Nathaniel, S., Anyanwu, O., & Shah, M. (2020). Renewable energy, urbanization, and
Fussler C., James P. (1996) Driving eco-innovation: A breakthrough discipline for                      ecological footprint in the Middle East and North Africa region. Environmental
     innovation and sustainability. (No Title).                                                        Science and Pollution Research, 27, 14601–14613. https://doi.org/10.1007/s11356-
Galor, O., & Weil, D. N. (2000). Population, technology, and growth: From Malthusian                   020-08017-7
     stagnation to the demographic transition and beyond. The American Economic                    Nawaz, K., Lahiani, A., & Roubaud, D. (2019). Natural resources as blessings and finance-
     Review, 90, 806–828. https://doi.org/10.1257/aer.90.4.806                                         growth nexus: A bootstrap ARDL approach in an emerging economy. Resources
GFN. Global footprint network. https://data.footprintnetwork.org/#/analyzeTrends?                      Policy, 60, 277–287. https://doi.org/10.1016/j.resourpol.2019.01.007
     type=EFCtot&cn=5001.                                                                          Nguyen, H. M., Thai-Thuong, L.e Q., Ho, C. M., et al. (2022). Does financial development
Guliyev, H. (2024). Determinants of ecological footprint in European countries: Fresh                  matter for economic growth in the emerging markets? Borsa Istanbul Review, 22,
     insight from Bayesian model averaging for panel data analysis. The Science of the                 688–698. https://doi.org/10.1016/j.bir.2021.10.004
     Total Environment, 912, Article 169455. https://doi.org/10.1016/j.                            Ntom Udemba, E., Khan, N.-U., & Raza Shah, S. A. (2024). Demographic change effect on
     scitotenv.2023.169455                                                                             ecological footprint: A tripartite study of urbanization, aging population, and
Guo, R., Lv, S., Liao, T., et al. (2020). Classifying green technologies for sustainable               environmental mitigation technology. Journal of Cleaner Production, 437, Article
     innovation and investment. Resources, Conservation, and Recycling, 153, Article                   140406. https://doi.org/10.1016/j.jclepro.2023.140406
     104580. https://doi.org/10.1016/j.resconrec.2019.104580                                       Numan, U., Ma, B., Sadiq, M., et al. (2023). The role of green finance in mitigating
Habiba, U., Xinbang, C., & Ali, S. (2023). Investigating the impact of financial                       environmental degradation: Empirical evidence and policy implications from
     development on carbon emissions: Does the use of renewable energy and green                       complex economies. Journal of Cleaner Production, 400, Article 136693. https://doi.
     technology really contribute to achieving low-carbon economies? Gondwana                          org/10.1016/j.jclepro.2023.136693
     Research: International Geoscience Journal, 121, 472–485. https://doi.org/10.1016/j.          Nwani, C., Effiong, E. L., Okpoto, S. I., & Okere, I. K. (2021). Breaking the carbon curse:
     gr.2023.05.013                                                                                    The role of financial development in facilitating low-carbon and sustainable
Haldar, A., & Sethi, N. (2022). Environmental effects of information and communication                 development in Algeria. African Development Review, 33, 300–315. https://doi.org/
     technology - Exploring the roles of renewable energy, innovation, trade and financial             10.1111/1467-8268.12576
     development. Renewable & Sustainable Energy Reviews, 153, Article 111754. https://            OECD. (2023). OECD stats. https://stats.oecd.org.
     doi.org/10.1016/j.rser.2021.111754                                                            Olivier, J. G. J., & PJAH. (2020). Trends in global CO2 and total greenhouse gas
Hu, B., Alola, A. A., Tauni, M. Z., et al. (2023). Pathway to cleaner environment: How                 emissions. PBL Netherlands Environmental Assessment Agency, 1–85.
     effective are renewable electricity and financial development approaches? Structural          Omoke, P. C., Nwani, C., Effiong, E. L., et al. (2020). The impact of financial development
     Change and Economic Dynamics. https://doi.org/10.1016/j.strueco.2023.08.003                       on carbon, non-carbon, and total ecological footprint in Nigeria: New evidence from
Hussain, M., & Dogan, E. (2021). The role of institutional quality and environment-                    asymmetric dynamic analysis. Environmental Science and Pollution Research, 27,
     related technologies in environmental degradation for BRICS. Journal of Cleaner                   21628–21646. https://doi.org/10.1007/s11356-020-08382-3
     Production, 304, Article 127059. https://doi.org/10.1016/j.jclepro.2021.127059                Ozgur, O., Yilanci, V., & Kongkuah, M. (2022). Nuclear energy consumption and CO2
Hussain, S., Akbar, M., Gul, R., et al. (2023). Relationship between financial inclusion               emissions in India: Evidence from Fourier ARDL bounds test approach. Nuclear
     and carbon emissions: International evidence. Heliyon, 9, e16472. https://doi.org/                Engineering and Technology, 54, 1657–1663. https://doi.org/10.1016/j.
     10.1016/j.heliyon.2023.e16472                                                                     net.2021.11.001
Ibrahim, M., & Vo, X. V. (2021). Exploring the relationships among innovation, financial           Pata, U. K., & Yilanci, V. (2020). Financial development, globalization and ecological
     sector development and environmental pollution in selected industrialized countries.              footprint in G7: Further evidence from threshold cointegration and fractional
     Journal of Environmental Management, 284, Article 112057. https://doi.org/10.1016/                frequency causality tests. Environmental and Ecological Statistics, 27, 803–825.
     j.jenvman.2021.112057                                                                             https://doi.org/10.1007/s10651-020-00467-z
Javed, A., Rapposelli, A., Khan, F., & Javed, A. (2023). The impact of green technology            Pesaran, M. H., Shin, Y., & Smith, R. J. (2001). Bounds testing approaches to the analysis
     innovation, environmental taxes, and renewable energy consumption on ecological                   of level relationships. Journal of Applied Econometrics, 16, 289–326. https://doi.org/
     footprint in Italy: Fresh evidence from novel dynamic ARDL simulations.                           10.1002/jae.616
     Technological Forecasting and Social Change, 191, Article 122534. https://doi.org/            Qayyum, M., Zhang, Y., Ali, M., & Kirikkaleli, D. (2024). Towards environmental
     10.1016/j.techfore.2023.122534                                                                    sustainability: The role of information and communication technology and
Ji, X., Chen, X., Mirza, N., & Umar, M. (2021). Sustainable energy goals and investment                institutional quality on ecological footprint in MERCOSUR nations. Environmental
     premium: Evidence from renewable and conventional equity mutual funds in the                      Technology & Innovation, 34, Article 103523. https://doi.org/10.1016/j.
     Euro zone. Resources Policy, 74, Article 102387. https://doi.org/10.1016/j.                       eti.2023.103523
     resourpol.2021.102387                                                                         Qin, M., Su, C.-W., Umar, M., et al. (2023). Are climate and geopolitics the challenges to
Jianguo, D., Ali, K., Alnori, F., & Ullah, S. (2022). The nexus of financial development,              sustainable development? Novel evidence from the global supply chain. Economic
     technological innovation, institutional quality, and environmental quality: Evidence              Analysis and Policy, 77, 748–763. https://doi.org/10.1016/j.eap.2023.01.002
     from OECD economies. Environmental Science and Pollution Research, 29,                        Qing, L., Usman, M., Radulescu, M., & Haseeb, M. (2024). Towards the vision of going
     58179–58200. https://doi.org/10.1007/s11356-022-19763-1                                           green in South Asian region: The role of technological innovations, renewable
Jollineau, S. J., & Bowen, R. M. (2023). A practical guide to using path analysis:                     energy and natural resources in ecological footprint during globalization mode.
     Mediation and moderation in accounting research. The Journal of Financial Reporting,              Resources Policy, 88, Article 104506. https://doi.org/10.1016/j.
     8, 11–40. https://doi.org/10.2308/JFR-2021-004                                                    resourpol.2023.104506
Kartal, M. T., Pata, U. K., Destek, M. A., & Caglar, A. E. (2023). Environmental effect of         Rahmane, A., Benelbar, M., & Traich, M. (2021). The Nexus between sustainable energy
     clean energy research and development investments: Evidence from Japan by using                   and ecological footprint: Evidence from Algeria. Sustainability: Science, Practice and
     load capacity factor. Journal of Cleaner Production, 416, Article 137972. https://doi.            Policy, 17, 323–333. https://doi.org/10.1080/15487733.2021.1946298
     org/10.1016/j.jclepro.2023.137972                                                             Razzaq, A., Sharif, A., Afshan, S., & Li, C. J. (2023). Do climate technologies and
Khan, M. A., Khan, M. A., Ahmed, M., & Khan, K. (2022). Environmental consequences of                  recycling asymmetrically mitigate consumption-based carbon emissions in the
     financial development in emerging and growth-leading economies: A                                 United States? New insights from Quantile ARDL. Technological Forecasting and Social
     multidimensional assessment. Borsa Istanbul Review, 22, 668–677. https://doi.org/                 Change, 186, Article 122138. https://doi.org/10.1016/j.techfore.2022.122138
     10.1016/j.bir.2021.10.003                                                                     Rout, S. K., Gupta, M., & Sahoo, M. (2022). The role of technological innovation and
Khan, N.-U., Udemba, E. N., Emir, F., & Hussain, S. (2023). A look into sustainable                    diffusion, energy consumption and financial development in affecting ecological
     development goal amidst technological innovation, financial development and                       footprint in BRICS: An empirical analysis. Environmental Science and Pollution
     natural resources: A symmetry and asymmetry analyses. Environment, Development                    Research, 29, 25318–25335. https://doi.org/10.1007/s11356-021-17734-6
     and Sustainability. https://doi.org/10.1007/s10668-023-03576-4                                Sadorsky, P. (2011). Financial development and energy consumption in Central and
Kihombo, S., Ahmed, Z., Chen, S., et al. (2021). Linking financial development, economic               Eastern European frontier economies. Energy Policy, 39, 999–1006. https://doi.org/
     growth, and ecological footprint: What is the role of technological innovation?                   10.1016/j.enpol.2010.11.034
     Environmental Science and Pollution Research. https://doi.org/10.1007/s11356-021-             Saqib, N., & Dincă, G. (2023). Exploring the asymmetric impact of economic complexity,
     14993-1                                                                                           FDI, and green technology on carbon emissions: Policy stringency for clean-energy
Kirikkaleli, D., Sofuoğlu, E., & Ojekemi, O. (2023a). Does patents on environmental                   investing countries. Geoscience Frontiers. , Article 101671. https://doi.org/10.1016/
     technologies matter for the ecological footprint in the USA? Evidence from the novel              j.gsf.2023.101671
     Fourier ARDL approach. Geoscience Frontiers, 14, Article 101564. https://doi.org/             Saqib, N., Ozturk, I., & Usman, M. (2023). Investigating the implications of technological
     10.1016/j.gsf.2023.101564                                                                         innovations, financial inclusion, and renewable energy in diminishing ecological
Kirikkaleli, D., Sowah, J. K., Addai, K., & Altuntaş, M. (2023b). Energy productivity and             footprints levels in emerging economies. Geoscience Frontiers, 14, Article 101667.
     environmental quality in Sweden: Evidence from Fourier and non-linear based                       https://doi.org/10.1016/j.gsf.2023.101667
     approaches. Geological Journal, 58, 3452–3465. https://doi.org/10.1002/gj.4684                Saqib, N., Usman, M., Ozturk, I., & Sharif, A. (2024). Harnessing the synergistic impacts
Ludlow, J., & Enders, W. (2000). Estimating non-linear ARMA models using Fourier                       of environmental innovations, financial development, green growth, and ecological
     coefficients. International Journal of Forecasting, 16, 333–347. https://doi.org/                 footprint through the lens of SDGs policies for countries exhibiting high ecological
     10.1016/S0169-2070(00)00048-0                                                                     footprints. Energy Policy, 184, Article 113863. https://doi.org/10.1016/j.
McNown, R., Sam, C. Y., & Goh, S. K. (2018). Bootstrapping the autoregressive                          enpol.2023.113863
     distributed lag test for cointegration. Applied Economics, 50, 1509–1521. https://doi.        Shahbaz, M., Nasir, M. A., & Roubaud, D. (2018). Environmental degradation in France:
     org/10.1080/00036846.2017.1366643                                                                 The effects of FDI, financial development, and energy innovations. Energy Economics,
Mrabet, Z., & Alsamara, M. (2017). Testing the Kuznets Curve hypothesis for Qatar: A                   74, 843–857. https://doi.org/10.1016/j.eneco.2018.07.020
     comparison between carbon dioxide and ecological footprint. Renewable &


                                                                                              14
B. Bergougui                                                                                                                               Sustainable Cities and Society 112 (2024) 105621

Sharif, A., Baris-Tuzemen, O., Uzuner, G., et al. (2020). Revisiting the role of renewable        UNFCCC. (2015). Report of the Conference of the Parties on its twenty-first session, held
    and non-renewable energy consumption on Turkey’s ecological footprint: Evidence                    in Paris from 30 November to 13 December 2015. In Addendum. Part Two: Action
    from Quantile ARDL approach. Sustainable Cities and Society, 57, Article 102138.                   taken by the Conference of the Parties at its twenty-first session.
    https://doi.org/10.1016/j.scs.2020.102138                                                     Usman, M., Jahanger, A., Makhdum, M. S. A., et al. (2022). How do financial
Sinha, A., Mishra, S., Sharif, A., & Yarovaya, L. (2021). Does green financing help to                 development, energy consumption, natural resources, and globalization affect Arctic
    improve environmental & social responsibility? Designing SDG framework through                     countries’ economic growth and environmental quality? An advanced panel data
    advanced quantile modelling. Journal of Environmental Management, 292, Article                     simulation. Energy, 241, Article 122515. https://doi.org/10.1016/j.
    112751. https://doi.org/10.1016/j.jenvman.2021.112751                                              energy.2021.122515
Song, M., Zheng, W., & Wang, S. (2017). Measuring green technology progress in large-             Usman, M., Makhdum, M. S. A., & Kousar, R. (2021). Does financial inclusion, renewable
    scale thermoelectric enterprises based on Malmquist–Luenberger life cycle                          and non-renewable energy utilization accelerate ecological footprints and economic
    assessment. Resources, Conservation, and Recycling, 122, 261–269. https://doi.org/                 growth? Fresh evidence from 15 highest emitting countries. Sustainable Cities and
    10.1016/j.resconrec.2017.03.001                                                                    Society, 65, Article 102590. https://doi.org/10.1016/j.scs.2020.102590
Sun, L., Miao, C., & Yang, L. (2017). Ecological-economic efficiency evaluation of green          Wang, R., Usman, M., Radulescu, M., et al. (2023). Achieving ecological sustainability
    technology innovation in strategic emerging industries based on entropy weighted                   through technological innovations, financial development, foreign direct
    TOPSIS method. Ecological Indicators, 73, 554–558. https://doi.org/10.1016/j.                      investment, and energy consumption in developing European countries. Gondwana
    ecolind.2016.10.018                                                                                Research: International Geoscience Journal, 119, 138–152. https://doi.org/10.1016/j.
Syed, Q. R., Apergis, N., & Goh, S. K. (2023). The dynamic relationship between climate                gr.2023.02.023
    policy uncertainty and renewable energy in the US: Applying the novel Fourier                 WDI. (2023). World development indicators 2023.
    augmented autoregressive distributed lags approach. Energy, 275, Article 127383.              Xie, J., Ahmed, Z., Zhang, P., et al. (2024). Financial expansion and CO2 mitigation in
    https://doi.org/10.1016/j.energy.2023.127383                                                       top twenty emitters: Investigating the direct and moderating effects of the digital
Syed, Q. R., Durani, F., Kisswani, K. M., et al. (2024). Testing natural resource curse                economy. Gondwana Research: International Geoscience Journal, 125, 1–14. https://
    hypothesis amidst geopolitical risk: Global evidence using novel Fourier augmented                 doi.org/10.1016/j.gr.2023.07.013
    ARDL approach. Resources Policy, 88, Article 104317. https://doi.org/10.1016/j.               Xie, X., Huo, J., & Zou, H. (2019). Green process innovation, green product innovation,
    resourpol.2023.104317                                                                              and corporate financial performance: A content analysis method. Journal of Business
Tamazian, A., & Bhaskara Rao, B. (2010). Do economic, financial and institutional                      Research, 101, 697–706. https://doi.org/10.1016/j.jbusres.2019.01.010
    developments matter for environmental degradation? Evidence from transitional                 Xu, B., Li, S., Afzal, A., et al. (2022). The impact of financial development on
    economies. Energy Economics, 32, 137–145. https://doi.org/10.1016/j.                               environmental sustainability: A European perspective. Resources Policy, 78, Article
    eneco.2009.04.004                                                                                  102814. https://doi.org/10.1016/j.resourpol.2022.102814
Tamazian, A., Chousa, J. P., & Vadlamannati, K. C. (2009). Does higher economic and               Xu, B., & Lin, B. (2018). Investigating the role of high-tech industry in reducing China’s
    financial development lead to environmental degradation: Evidence from BRIC                        CO2 emissions: A regional perspective. Journal of Cleaner Production, 177, 169–177.
    countries. Energy Policy, 37, 246–253. https://doi.org/10.1016/j.enpol.2008.08.025                 https://doi.org/10.1016/j.jclepro.2017.12.174
Tao, M., Sheng, M. S., & Wen, L. (2023). How does financial development influence                 Yasmeen, R., Zhaohui, C., Hassan Shah, W. U., et al. (2022). Exploring the role of
    carbon emission intensity in the OECD countries: Some insights from the information                biomass energy consumption, ecological footprint through FDI and technological
    and communication technology perspective. Journal of Environmental Management,                     innovation in B&R economies: A simultaneous equation approach. Energy, 244,
    335, Article 117553. https://doi.org/10.1016/j.jenvman.2023.117553                                 Article 122703. https://doi.org/10.1016/j.energy.2021.122703
Tauseef Hassan, S., Wang, P., Khan, I., & Zhu, B. (2023). The impact of economic                  Yilanci, V., Bozoklu, S., & Gorus, M. S. (2020). Are BRICS countries pollution havens?
    complexity, technology advancements, and nuclear energy consumption on the                         Evidence from a bootstrap ARDL bounds testing approach with a Fourier function.
    ecological footprint of the USA: Towards circular economy initiatives. Gondwana                    Sustainable Cities and Society, 55, Article 102035. https://doi.org/10.1016/j.
    Research: International Geoscience Journal, 113, 237–246. https://doi.org/10.1016/j.               scs.2020.102035
    gr.2022.11.001                                                                                Zahraoui, Y., Basir Khan, M. R., Alhamrouni, I., et al. (2021). Current status, scenario,
Touitou, M., & Langarita, R. (2021). Environmental Kuznets curve for carbon dioxide                    and prospective of renewable energy in algeria: A review. Energies, 14. https://doi.
    emissions and economic growth in Algeria. Margin - The Journal of Applied Economic                 org/10.3390/en14092354
    Research, 15, 418–432. https://doi.org/10.1177/09738010211036261                              Zhang, H., Shao, Y., Han, X., & Chang, H.-L. (2022). A road towards ecological
Umar, M., Ji, X., Kirikkaleli, D., & Xu, Q. (2020). COP21 Roadmap: Do innovation,                      development in China: The nexus between green investment, natural resources,
    financial development, and transportation infrastructure matter for environmental                  green technology innovation, and economic growth. Resources Policy, 77, Article
    sustainability in China? Journal of Environmental Management, 271, Article 111026.                 102746. https://doi.org/10.1016/j.resourpol.2022.102746
    https://doi.org/10.1016/j.jenvman.2020.111026                                                 Zhao, J., Shahbaz, M., Dong, X., & Dong, K. (2021). How does financial risk affect global
Umar, M., & Safi, A. (2023). Do green finance and innovation matter for environmental                  CO2 emissions? The role of technological innovation. Technological Forecasting and
    protection? A case of OECD economies. Energy Economics, 119, Article 106560.                       Social Change, 168. https://doi.org/10.1016/j.techfore.2021.120751
    https://doi.org/10.1016/j.eneco.2023.106560




                                                                                             15
