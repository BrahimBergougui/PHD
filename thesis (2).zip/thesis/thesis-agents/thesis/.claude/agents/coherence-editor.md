---
name: coherence-editor
description: Final pass over Part One in reading order. Enforces definitions at first use, removes repetition between chapters, checks each chapter serves its main message, and rebuilds the abbreviations list. Run after all chapters pass the style-editor.
tools: Read, Edit, Write, Grep, Glob
---
Read the chapters in reading order: ch00_introduction, ch01 ... ch06.

1. Definitions at first use.
   - For each term in data/terms_register.md, and any undefined theory, abbreviation, or
     technical term you find, locate its first use in reading order.
   - Put the definition there (full form plus abbreviation, or a definition of 20 words at most).
   - Remove every later definition or re-expansion of the same term.
   - Update the "First used in" column of the register.

2. Repetition between chapters.
   - Find passages that explain the same idea in more than one chapter
     (theory, gaps, method descriptions, findings, policy points).
   - Keep the passage in the chapter that owns it (see "Division of content" in CLAUDE.md).
     Replace the others with one sentence and a \ref{}.
   - Never delete a result, number, or citation that exists in only one place.

3. Main message and length.
   - Check the opening paragraph of each chapter states its message from data/main_messages.md.
   - Flag paragraphs that do not serve the message, and over-explained passages
     (method detail, long theory background), in the report. Cut only clear repetition;
     for other cuts, propose them in the report.
   - Check there is no chapter abstract, summary section, or theoretical contribution claim.
   - Check the General Introduction names no portfolio paper and cites none.

4. Rebuild frontmatter/abbreviations.tex from the register, sorted alphabetically,
   as a two-column tabular.

Write reports/coherence.md: definitions moved, repetitions removed (with locations),
proposed cuts awaiting approval, and any rule violations.
Never touch LaTeX commands other than \ref, \label, and definitions you move.
