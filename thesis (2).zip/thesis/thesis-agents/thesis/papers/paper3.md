                                                                          Technology in Society 83 (2025) 103029


                                                                        Contents lists available at ScienceDirect


                                                                         Technology in Society
                                                              journal homepage: www.elsevier.com/locate/techsoc




Institutional adaptability, skill-bias technological shifts, and energy
efficiency in global decarbonization pathways: Exploring the role of
artificial intelligence patents
Brahim Bergougui a,b,c
a
    National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
b
    International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
c
    College of Business & Economics, Qatar University, Doha, Qatar




A R T I C L E I N F O                                          A B S T R A C T

Keywords:                                                      The catalytic role of artificial intelligence patents (AIP) in accelerating global decarbonization pathways—­
AI patents                                                     through structural reductions in CO2 emissions—remains underexplored. Leveraging a panel of 29 countries
CO2 emissions                                                  (2005–2023), this study explores the effect of AIP on carbon mitigation. We find robust evidence that AIP drives
Decarbonization
                                                               significant emissions reductions, with results persisting across instrumental variable regressions, sensitivity an­
Energy efficiency
Institutional adaptability
                                                               alyses, and alternative model specifications. Mechanism tests reveal three decarbonization channels: AIP drives
Technological shift                                            technological shift by favoring skilled labor and automating carbon-intensive routine tasks; institutional
                                                               adaptability magnifies these decarbonization benefits; and AIP enhances systemic energy efficiency, evidenced
                                                               by substantial reductions in both primary energy intensity and per capita CO2 emissions. Heterogeneity tests
                                                               demonstrate that AIP’s decarbonization impact is most pronounced in economies geographically proximate to
                                                               the USA (the global AI innovation hub), in lower-income nations, and in countries with high fossil fuel de­
                                                               pendency. Within AIP categories, energy-management patents yield the highest decarbonization returns. These
                                                               findings underscore AI patents as critical yet underutilized tools for achieving net-zero transitions, with policy
                                                               implications for targeted intellectual property incentives, global technology transfer, and institutional reforms to
                                                               amplify decarbonization synergies.




1. Introduction                                                                                          While reinforcing global cooperation remains critical, harnessing
                                                                                                     technological innovation—particularly artificial intelligence (AI)—of­
    Climate-driven catastrophes—ranging from heatwaves, droughts,                                    fers transformative potential for achieving sustainability goals. As a
and floods to hurricanes—have intensified in recent years, posing grave                              general-purpose technology with far-reaching adaptive capabilities
risks to communities worldwide. Despite international efforts, the up­                               (Bergougui, 2025a; Gruetzemacher et al., 2021), AI is reshaping in­
ward trajectory of global temperatures persists (Bergougui & Satrovic,                               dustries, economies, and daily life, positioning it as a pivotal tool for
2025). Despite growing awareness, global environmental degradation                                   mitigating ecological impacts. McKinsey indicates that artificial intelli­
continues to accelerate. The IEA reported that global energy-related CO2                             gence could potentially automate more than 29 % of jobs worldwide by
emissions reached 37.8 Gt in 2024, marking a record high following a                                 2030. This projection aligns with observed trends in physical automa­
0.8 % increase during the year (IEA, 2023), reflecting a marginal rise                               tion, such as the 5 percent year-on-year increase in industrial robot in­
from prior levels. These trends highlight that fostering decarbonization                             stallations worldwide reported in 2022 (Müller & Bill, 2023, pp. 1–48).
has emerged as a defining challenge of our era. To address this, nations                             These advancements raise critical questions about how AI can be stra­
and international bodies are advancing collaborative policies and                                    tegically deployed to enhance resource efficiency, reduce waste, and
frameworks. The 2015 Paris Agreement, for instance, unites nearly 200                                support sustainable development (Cao et al., 2025). Recent research
countries in a pledge to cap global temperature rise below 2 ◦ C, with                               underscores AI’s multifaceted contributions to environmentally
aspirations to limit it to 1.5 ◦ C above pre-industrial benchmarks                                   friendly. A study by Ding et al. (2023) provides empirical support,
(Bergougui and Meziane, 2025; Doğan et al., 2025).                                                  showing that AIin Chinese cities correlates with reduced ecological



      E-mail addresses: bergougui@iss.nl, bergouguibrahim@gmail.com.

https://doi.org/10.1016/j.techsoc.2025.103029
Received 9 May 2025; Received in revised form 2 July 2025; Accepted 30 July 2025
Available online 5 August 2025
0160-791X/© 2025 The Author. Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui                                                                                                               Technology in Society 83 (2025) 103029


footprints. Similarly, Zhou, Zhuang, and Chen (2024) find that industrial         • Enhanced Measurement of AIP: We utilize the count of AI-related
robots lower pollution intensity in manufacturing sectors, and Lin and              patent applications—sourced from the WIPO Artificial Intelligence
Xu link robot adoption to decreased energy consumption in firms.                    Index—as a precise indicator of technological advancement. This
Globally, Zhao and Xu (Lin and Xu, 2024) reveal that robotic automation             approach overcomes the limitations of prior research that proxies AI
narrows disparities in global sustainability performance, while Yu et al.           solely with industrial robots. Unlike robots, which execute narrowly
(2023) associate urban AI integration with declines in city-level carbon            defined tasks, AI embodies adaptive learning and reasoning capac­
footprints.                                                                         ities (Goertzel, 2014). By compiling Patent Cooperation Treaty fil­
    Scholars have also explored contextual factors shaping AI’s sustain­            ings across 30 nations, we offer a robust assessment of AI’s influence
ability outcomes. Wang et al. (2023) identify a U-shaped association                on decarbonization. Our results reveal a significant, negative asso­
among automation and emissions intensity, mediated by resource de­                  ciation between AI intensity and environmental impact, enduring
pendency, while Jiao et al. (2024) connect corporate AI investments to              through endogeneity controls and robustness checks. Moreover, the
cut emissions in the U.S. Lee et al. (2022) highlight AI’s role in driving          sustainability benefits are magnified in countries closer—geo­
green innovation, and Qi et al. (2024) document reductions in industrial            graphically and technologically—to AI front-runners, in
pollution following robot adoption in China. Global analyses further                lower-income economies, and in regions heavily reliant on fossil
emphasize AI’s conditional efficacy: Wang, Li, et al. (2024) note that              fuels. Applications of AI in energy management exhibit particularly
trade openness amplifies AI’s environmental benefits, and Wang, Zhang,              strong effects.
et al. (2024) associate AI with declines in ecological footprints. Zhang          • Mechanistic Insights: We identify three pathways through which AI
et al. (2024) stress AI’s capacity to spur sustainable industrial                   promotes sustainability: Improved energy efficiency, evidenced by
transitions.                                                                        reductions in per-capita environmental footprints and primary en­
    However, the environmental implications of AI deployment present                ergy intensity; Skill- and task-biased technological change, as nations
critical negative externalities that could potentially offset the antici­           with higher shares of trained labor and non-routine occupations
pated decarbonization benefits (Leal Filho et al., 2024; Qian et al.,               experience larger environmental improvements; and Regulatory
2024). Most notably, the substantial energy consumption required for                flexibility, whereby adaptive governance frameworks amplify AI’s
training and operating large-scale AI models represents a significant               positive impacts. These findings highlight that progressive AI policy
environmental cost that must be weighed against AI’s sustainability                 and targeted applications can accelerate the global transition to
contributions (Hao, 2019). The International Energy Agency (IEA)                    sustainable development.
projected in January 2024 that electricity usage by data centers, artifi­
cial intelligence systems, and cryptocurrency operations may increase                The subsequent sections are arranged in the following manner.
twofold by 2026—significantly exceeding the average annual global                Section 2 outlines the theoretical framework and presents the hypoth­
growth rate of 3.4 %. Combined, their energy demand could exceed                 esized mechanisms. Section 3 describes the research design and data.
1000 TW-hours (IEA, 2024, pp. 1–170), with data centers already                  Section 4 discusses empirical results, endogeneity test, and robustness
becoming key contributors to rising electricity consumption in several           checks. Section 5 investigates the underling pathways. Section 6 con­
parts of the world (IEA, 2025). These energy-intensive requirements for          ducts supplementary investigations and. Finally, Section 7 summarizes
AI model training and deployment create a paradox where the tech­                the key findings and offers policy recommendation.
nologies designed to enhance environmental efficiency may simulta­
neously increase overall energy consumption and carbon emissions.                2. Background
Furthermore, AI’s “black-box” nature can obscure these environmental
trade-offs; opaque decision-making processes may systematically over­            2.1. Theoretical framework
look or underestimate the ecological risks associated with AI infra­
structure and operations (Miller, 2019). This creates the potential for AI           The contemporary global economy is witnessing an unprecedented
policies to inadvertently prioritize short-term efficiency gains while           surge in artificial intelligence innovation, fundamentally reshaping how
neglecting the long-term environmental costs embedded in AI systems              societies approach environmental challenges. AI innovations cover a
themselves (Bergougui, 2025b). Accordingly, it is crucial to examine             broad array of methodologies—ranging from machine learning and deep
how AI technologies affect broad ecological metrics through a compre­            neural networks to natural language processing, image analysis, expert
hensive lens that explicitly accounts for these negative external­               systems, speech-to-text technologies, reinforcement learning, recom­
ities—carefully balancing AI’s resource demands against its                      mendation algorithms, and autonomous robots. This technological rev­
sustainability dividends to determine the net environmental impact of            olution has prompted major economies to develop comprehensive AI
AI deployment strategies.                                                        agendas to accelerate these breakthroughs. For instance, China’s 2017
    While extensive research has investigated how AI applications in­            ″New Generation AI Development Plan” sets a goal of global AI leader­
fluence environmental outcomes, the causal role of AI patents                    ship by 2030; the U.S. refreshed its National AI R&D Strategic Plan in
itself—particularly as captured through patent activity—remains largely          2023 to protect long-term technological advantage; aligned with its
unexplored in the academic literature. This study addresses this critical        “Society 5.0″ vision, Japan’s 2017 AI strategy incorporates artificial
research gap by examining a fundamental question:                                intelligence into various sectors like manufacturing, health, and agri­
    To what extent does AI innovation drive net carbon-emission re­              culture; and the European Union’s 2018 AI strategy focuses on safe,
ductions and through which specific mechanisms do these environ­                 transparent, and trustworthy AI systems.
mental effects manifest?                                                             However, understanding AI’s environmental impact requires careful
    Leveraging a panel dataset of 29 economies from 2005 to 2023, we             theoretical distinction between technological potential and practical
employ the World Intellectual Property Organization’s Patent Cooper­             implementation. While AI capability—proxied here by patent activi­
ation Treaty records to obtain a precise measure of AI patents, system­          ty—reflects technical potential, deployment (adoption) constitutes its
atically test three pathways, and explore how geographic proximity to            realized impact. This critical distinction is rooted in innovation diffusion
AI front-runners, income levels, and fossil-fuel dependence condition            theory (Rogers, 1964) and the knowledge-based view of the firm (Grant,
the magnitude of AI’s decarbonization impact.                                    1996). Patents signify codified knowledge and inventive capacity but do
    Based on these discussions, this study yields two principal                  not guarantee utilization; they represent a supply-side metric of AI
contributions.                                                                   advancement. Conversely, adoption is a demand-side phenomenon,
                                                                                 contingent on organizational readiness (e.g., absorptive capacity; Cohen
                                                                                 & Levinthal, 1990), complementary investments (e.g., data

                                                                             2
B. Bergougui                                                                                                            Technology in Society 83 (2025) 103029


infrastructure; Brynjolfsson & Hitt, 2000), and institutional legitimacy       2.1.3. Pathway 3: institutional adaptability
(e.g., ethical approvals; Teece, 2018). This capability-deployment di­             The third pathway recognizes that the translation of AI capabilities
chotomy fundamentally shapes our theoretical understanding. The gap            into environmental benefits is fundamentally mediated by institutional
between capability and deployment thus mirrors the “innovation-ap­             contexts. The adaptability and effectiveness of institutions critically
plication chasm” (Acemoglu et al., 2022), where technological feasi­           shape how firms exploit AI patents, creating substantial variation in
bility (patents) diverges from economic and social integration                 outcomes across different economic and regulatory environments. This
(adoption). Ignoring this duality risks conflating invention with inno­        institutional dimension bridges the capability-deployment gap by
vation—the latter requiring market translation (Schumpeter & Opie,             determining the conditions under which technological potential can be
1934), Our analysis explicitly disentangles these layers, acknowledging        realized. Strong, adaptable governance frameworks facilitate this
patents as necessary but insufficient signals of AI’s transformative           translation by lowering compliance burdens and legal uncertainties,
footprint.                                                                     encouraging businesses to adopt patented AI innovations for environ­
    Building upon this theoretical foundation, we identify that the            mental applications (Carrillo, 2020; Smuha, 2021). Such institutions
resulting surge in AI-related patent filings creates multiple pathways         create enabling environments that reduce the risks and costs associated
through which these inventions can shape decarbonization. These                with AI deployment, thereby accelerating the pace at which capabilities
pathways operate through interconnected mechanisms that collectively           are converted into practical solutions.
determine the environmental outcomes of AI innovation.                             We identify three key institutional dimensions that specifically
                                                                               facilitate AI deployment for environmental benefits.
2.1.1. Pathway 1: enhanced energy efficiency
    The first and most direct pathway involves boosting energy effi­            • Legal Adaptability for AI Governance: AI technologies evolve
ciency through sophisticated AI applications. Patented AI method­                 rapidly, creating regulatory gaps that can hinder optimal deploy­
s—such as algorithms for predictive maintenance, smart grid                       ment. Legal systems that can quickly adapt regulations to accom­
management, and building energy optimization—help organizations use               modate AI innovations while maintaining environmental standards
resources more judiciously by transforming traditional reactive ap­               are crucial. This includes flexible frameworks for AI testing,
proaches into proactive, data-driven strategies. These innovations                deployment approval processes, and liability structures that
represent a fundamental shift from static optimization to dynamic, real-          encourage environmental applications of AI without stifling inno­
time resource management that continuously adapts to changing con­                vation. Regulatory flexibility, when well-designed, allows govern­
ditions. Supporting this theoretical proposition, empirical studies               ments to respond to technological advancements while preserving
demonstrate that AI-driven innovations enhance firms’ green R&D                   ecological safeguards (Papagiannidis et al., 2025).
productivity, leading to measurable gains in energy utilization rates           • Labor Market Efficiency in AI Transitions: AI adoption often re­
(Hussain et al., 2024; Song et al., 2024). The benefits extend beyond             quires workforce reallocation and skill transitions. Efficient labor
individual organizations, as urban implementations of AI exhibit posi­            markets that support smooth transitions help minimize resistance to
tive spatial spillovers, raising energy performance across neighboring            AI adoption and ensure that AI technologies are deployed where they
regions through demonstration effects and competitive pressures                   can maximize environmental benefits. This includes retraining pro­
(Wang, Zhao, & Ma, 2024). Furthermore, AI-powered improvements in                 grams, flexible employment regulations, and social safety nets that
industrial structure and cross-border technology transfer facilitate              support workers during AI-driven structural shifts. In contrast, overly
broader systemic changes that reorient energy mixes toward                        rigid labor regimes may protect incumbents at the expense of inno­
lower-impact sources (Feng et al., 2024; Mhlanga, 2023).                          vation, slowing diffusion and dampening environmental gains (Zhou
                                                                                  et al., 2025).
2.1.2. Pathway 2: inducing biased technological shift                           • Regulatory Quality for AI Innovation Ecosystems: Effective
    The second pathway operates through the transformation of labor               regulation must strike a balance between incentivizing innovation
markets and the induced changes in economic structure. Patent filings in          and ensuring environmental integrity. High-quality regulatory
AI reflect growing sophistication that extends beyond automation of               frameworks provide clear, enforceable guidelines for AI develop­
manual routines toward substitution of cognitive, high-skill tasks                ment while maintaining standards for ecological outcomes. This in­
(Acemoglu et al., 2022). This evolution creates complex ripple effects            cludes comprehensive data governance regimes that support
throughout the economy that ultimately influence environmental out­               environmental AI applications, intellectual property protections that
comes through resource reallocation and productivity enhancements.                foster AI innovation diffusion, and regulatory sandboxes that enable
Specifically, this transformation manifests through two complementary             real-world testing of AI solutions in decarbonization contexts (Chan
mechanisms. Consistent with the hypothesis of skill-biased technolog­             et al., 2024).
ical change (Acemoglu, 2002; Machin, 2008), AI patents accelerate
productivity more for highly educated workers than for those perform­              In sharp contrast, institutional environments characterized by rigid
ing low-skill jobs, thereby shifting labor demand toward                       rules, fragmented governance, or limited administrative capacity may
knowledge-intensive activities. Concurrently, routine-biased techno­           hinder the translation of AI potential into actual environmental impact.
logical change (Acemoglu & Autor, 2011; Autor et al., 2003) posits that        These constraints effectively widen the capability-deployment gap,
AI displaces codifiable, rule-based tasks while complementing nonrou­          preventing the realization of environmental benefits even when tech­
tine problem-solving roles, freeing human cognitive resources for more         nological solutions are available (Traverso et al., 2023). High institu­
complex and creative endeavors. The environmental implications of              tional quality thus amplifies the positive externalities of AI patents on
these labor market shifts are profound. Firms in economies with larger         ecological preservation by creating the structural and procedural con­
shares of skilled labor and nonroutine occupations realize bigger pro­         ditions necessary for effective technology diffusion, adoption, and
ductivity boosts from AI, freeing up resources for environmental R&D           scale-up.
and ultimately improving sustainability outcomes (Al-Jafari & Altaee,
2023; Godil et al., 2021; Zhang et al., 2017). This                            2.1.4. Research hypotheses
productivity-sustainability nexus suggests that AI-induced labor trans­            Drawing from these mechanistic analyses and their theoretical in­
formations can create virtuous cycles where economic gains enable              terconnections, we propose the following research hypotheses.
greater environmental investments.
                                                                               H1. A greater volume of AI patents is associated with accelerated
                                                                               decarbonization pathways.


                                                                           3
B. Bergougui                                                                                                                     Technology in Society 83 (2025) 103029


H2. AI patents enhance decarbonization by improving energy                         and Li (2024) identified a negative spatial spillover effect between AI
efficiency.                                                                        and green-tech progress on carbon efficiency across 30 provinces from
                                                                                   2012 to 2021, primarily in the short term. Dong et al. (2023) confirmed
H3. Skill-biased and routine-biased technological changes arising from
                                                                                   that AI can curb CO2 emissions (2006–2019), but emphasized that its
AI patents contribute to deeper emissions reductions.
                                                                                   effectiveness is contingent on each region’s industrial structure. Further
H4. The positive impact of AI patents on decarbonization is strength­              studies by Zhou, Zhuang, and Chen (2024) and Ding et al. (2023)
ened in economies with adaptable institutional frameworks.                         corroborate AI’s substantial, multi-channel impact on emission in­
                                                                                   tensity, highlighting both technical and structural pathways. Beyond
    Integrating these mechanistic analyses and their theoretical un­
                                                                                   manufacturing, Liu et al. (2022) found that increased use of industrial
derpinnings, Fig. 1 presents a comprehensive theoretical framework
                                                                                   robots and AI-related scholarly output between 2005 and 2016 were
illustrating the pathways through which AI-related patents influence
                                                                                   associated with significant declines in China’s industrial carbon
decarbonization. This framework serves as the conceptual foundation
                                                                                   intensity.
for our subsequent empirical analysis, providing both theoretical
                                                                                       While the literature on AI and emissions is robust, it omits a critical
grounding and practical guidance for understanding how AI innovation
                                                                                   demand-side perspective: operational decarbonization in the building
contributes to global environmental goals.
                                                                                   and electric-vehicle (EV) sectors. Buildings alone account for a sub­
                                                                                   stantial share of global CO2 emissions, and electrification—paired with
2.2. Prior studies
                                                                                   renewable energy integration—emerges as a keystone strategy. Ma et al.
                                                                                   (2024) outline a multisectoral decarbonization framework emphasizing
    The relationship between AIP and environmental outcomes has
                                                                                   advanced building technologies, financial mechanisms, and policies to
garnered significant attention due to AI’s transformative potential in
                                                                                   constrain embodied carbon, extend building lifespans, and accelerate
addressing environmental challenges. An increasing body of research
                                                                                   electrification. At a global scale, Wang et al. (2025) trace operational
has investigated AI’s impact on carbon dioxide emissions across coun­
                                                                                   carbon-intensity trends in 16 countries since 2000, revealing an average
tries, industries, and time periods. At the cross-national level, Wang,
                                                                                   annual decrease of 3.8 percent after 2011, yet also noting that early
Zhang, et al. (2024) analyzed data from 69 countries between 1993 and
                                                                                   electrification efforts—especially in space heating—temporarily hin­
2019, finding a strong correlation between AI development and signif­
                                                                                   dered decarbonization. In China, Deng et al. (2025) project a national
icant CO2 reductions. Zhong et al. (2024) reinforced this conclusion with
                                                                                   commercial-building operational carbon peak of 890 ± 50 MtCO2 by
a study of 66 nations, demonstrating that AI delivers the greatest mar­
                                                                                   2028, with stark provincial disparities that call for tailored mitigation
ginal benefits in high-income, high-pollution economies. However, the
                                                                                   strategies. In parallel, the electric-vehicle sector holds immense promise
emission-reduction impact diminishes in countries with a higher share
                                                                                   but faces real-world performance gaps. Deng et al. (2024) provide the
of heavy industry. Interestingly, their study also found stronger benefits
                                                                                   first bottom-up analysis of China’s top-selling plug-in hybrids from 2020
in nations with older populations, suggesting that demographic factors
                                                                                   to 2022, uncovering electricity intensities 30–40 percent above—and
may play a critical role in AI’s environmental effectiveness. At the sec­
                                                                                   gasoline intensities up to six times—official cycle values, as well as
toral level, Shang et al. (2024) used industrial robot installations as a
                                                                                   pronounced regional energy-use differences. Finally, Yan et al. (2025)
proxy for AI deployment across ten polluting sectors from 2000 to 2020.
                                                                                   examine residential cooling in India (2000–2022), identifying distinct
They found that increased robot adoption and energy efficiency im­
                                                                                   state-level decarbonization potentials shaped by income, appliance
provements contribute to carbon neutrality both in the short and long
                                                                                   ownership, and unmet cooling demand.
term. Similarly, Chen and Jin (2023) documented that AI adoption in
China’s manufacturing sector (2012–2021) led to substantial reductions
in CO2 emissions, particularly when firms pursued green innovations                2.3. Research gap
alongside AI integration. Provincial-level analyses in China offer addi­
tional insights into the localized effects of AI on emissions. Zhou, Zhang,              While previous research has explored connections between AI and


                                                        Hypothesis 2: Energy eﬃciency


                                                                         - Individual energy consumption
                                                                         - Energy use in economic production


                                                       Hypothesis 3: Technological SHIFT

                                                                                                 - Skill‐biased
                                                                                                 - Routine‐biased


                                                        Hypothesis 4: Ins�tu�onal adaptability


                                                                                         - Legal adaptability
                                                                                         - Labor market efficiency
                                                                                         - Regulatory quality




                              AI patents                   Hypothesis 1: Direct impact                               Decarbonization


                                                                Fig. 1. Analytical framework.

                                                                               4
B. Bergougui                                                                                                                  Technology in Society 83 (2025) 103029


environmental outcomes, several critical limitations remain that our             country, resulting in a sample that captures over 95 % of global AI patent
study addresses through methodological innovations and theoretical               activity annually. Although most sample members are larger countries,
contributions.                                                                   the relatively small carbon footprints of the remaining countries do not
                                                                                 compromise the analysis of AI’s environmental effects. Between 2005
 • First, much existing research relies on imprecise proxies for AI, such        and 2023, PCT AI patent filings grew by approximately 140 %, reflecting
   as industrial robots or general automation indicators. This represents        rapid technological expansion. Geographically, the USA dominates with
   a fundamental limitation because robots are typically designed for            about 55 % of filings, while Germany and the UK each contribute around
   specific physical tasks, whereas AI encompasses broader learning,             6.5 %, and no other individual country exceeds 5.5 % of the total.
   reasoning, and adaptive capabilities (Goertzel, 2014). This mea­                  Fig. 2 illustrates AI development across 29 economies over four time
   surement imprecision limits our understanding of AI’s true envi­              periods (2005, 2015, 2023, and 2005–2023), showcasing distinct pat­
   ronmental impact and creates ambiguity in policy recommendations.             terns in global AI innovation through patent application data. The
   We employ a more direct and accurate measure through AI patent                United States has maintained clear leadership throughout, with patent
   applications filed via the Patent Cooperation Treaty (PCT) across 29          applications surging 94 % from 1672 in 2005 to 3244 by 2023, reflecting
   countries, compiled from the World Intellectual Property Organiza­            consistent and substantial R&D investment in artificial intelligence
   tion (WIPO) database. This approach provides a clearer, more                  technologies. Within Europe’s innovation landscape, Germany and the
   comprehensive assessment of AI innovation’s impact on CO2 emis­               United Kingdom have established themselves as major AI centers,
   sions. Our patent-based measure captures the breadth of AI techno­            achieving impressive growth rates of 98 % and 110 % respectively,
   logical development while maintaining cross-country comparability             while Switzerland and the Netherlands have emerged as significant mid-
   and temporal consistency.                                                     tier innovators. Most notably, South Korea has undergone a remarkable
 • Second, While the literature debates AI’s net environmental effect, it        evolution in the AI sector, recording an extraordinary 516 % increase
   often lacks systematic empirical testing of the specific mechanisms           from just 51 applications in 2005 to 314 in 2023, demonstrating its
   driving outcomes. This gap prevents the development of targeted               successful strategic pivot toward AI-enhanced manufacturing and ro­
   policies and limits theoretical advancement in understanding how AI           botics technologies. By contrast, smaller economies such as Austria and
   technologies translate into environmental benefits or costs. We fill          Spain exhibited marginal growth during this period, underscoring how
   this void by explicitly testing the three pathways identified in our          AI innovation tends to concentrate in nations with advanced techno­
   theoretical framework: enhanced energy efficiency, biased techno­             logical infrastructure and capabilities.
   logical change, and institutional adaptability. Our mechanism tests               To measure decarbonization (DEC), we draw country–year data on
   provide robust evidence that AI reduces carbon emissions by                   CO2 emissions, measured in kilograms of CO2 per 2017 PPP dollar of
   improving energy efficiency, as evidenced by lower per capita car­            GDP from the World Bank’s World Development Indicators. Our analysis
   bon emissions and reduced primary energy intensity. Furthermore,              also incorporates a set of country-level covariates: the share of the urban
   we demonstrate that AI’s carbon-reducing impact is more pro­                  population, the share of industrial employment, merchandise trade as a
   nounced in countries with higher proportions of skilled labor and             percentage of GDP, population density, income per capita, Internet-user
   nonroutine occupations, supporting hypotheses of both skill-biased            penetration, and net FDI inflows relative to GDP. We construct a panel of
   and routine-biased technological change. Finally, we show that                29 developed and developing economies over the period 2005–2023,
   flexible government regulation strengthens the emissions-reducing             yielding 551 country-year observations.
   effects of AI technology.
 • Last, previous research often treats AI’s environmental impact as
                                                                                 3.2. Model specification
   uniform across different economic, institutional, and developmental
   contexts. This assumption overlooks important heterogeneity in how
                                                                                    Our baseline specification employs a two-way fixed-effects panel
   AI technologies are deployed and their effectiveness in different
                                                                                 regression:
   settings. Our analysis reveals that AI’s environmental impact varies
   significantly across contexts. We find stronger effects in countries          DECit = α + β1 AIPit + Xit + μi + τt + εit                                     (1)
   with greater geographic proximity to leading AI innovators, in lower-
   income nations, and in economies highly dependent on fossil fuels.            where.
   These findings highlight the importance of considering contextual
   factors in both research design and policy development.                          •DECit indicates country i’s decarbonization progress in year t,
                                                                                  • AIPit counts of AI-related patent submissions,
    By addressing these limitations through rigorous methodology and              • Xit comprises control variables,
comprehensive mechanism testing, our study demonstrates how                       • μi and τt are country and year fixed effects, respectively,
advancing AI technology can effectively accelerate global progress to­            • εit is a heteroskedasticity-robust error term.
ward a low-carbon future. Our findings provide both theoretical insights
into the mechanisms through which AI influences environmental out­                   A statistically significant positive estimate of β1 indicates that higher
comes and practical guidance for policymakers seeking to harness AI’s            AIP is associated with higher levels of decarbonization. Variable defi­
potential for decarbonization while mitigating potential negative                nitions and summary statistics are provided in Tables A.2 and A.2.
effects.
                                                                                 4. Results and discussion
3. Empirical methodology
                                                                                 4.1. Primary empirical findings
3.1. Data sources and construction
                                                                                    Table 1 presents the econometric analysis examining the relationship
    We quantify national AI innovation by extracting the amount of AI-           between AIP and decarbonization outcomes as measured by CO2 emis­
related patent applications each of 29 countries (see Table A.1) filed via       sions. The two-way fixed-effects panel regression yields compelling ev­
the PCT (2005–2023), using the WIPO’s AI Index. The AI index classifies          idence of AIT’s positive environmental impact. In the baseline
patents into three broad groups—core AI techniques, functional AI ap­            specification (column 1), which isolates the direct effect of AIT without
plications, and AI submission domains—each further divided into                  additional controls, the coefficient for AIP is negative and statistically
detailed subcategories. Our study aggregates all such PCT filings per            significant at the 1 % level. When the model is extended to incorporate a

                                                                             5
B. Bergougui                                                                                                                     Technology in Society 83 (2025) 103029




                               Fig. 2. AI patent applications in 29 economies: Trends for 2005, 2015, 2023, and 2005–2023 average.


                                                                                        improvements that exceed regulatory burdens. The induced innovation
Table 1
                                                                                        theory (Jaffe et al., 2002) further explains these results by proposing
Primary regression outcomes.
                                                                                        those environmental policies direct technological change toward cleaner
  Independent variable              Dependent Variable: CO2 emissions                   alternatives. The significant relationship between AIP and reduced
                                    (1)                          (2)                    emissions suggests that AI governance frameworks are successfully
  AIP                               − 0.0177***                  − 0.0165***
                                                                                        channeling innovation efforts toward carbon-reducing technologies,
                                    (-5.50)                      (-5.26)                consistent with directed technical change literature where policy in­
  GDP                               ​                            − 0.0906***            terventions create incentives for clean technology development over
                                    ​                            (-5.31)                carbon-intensive alternatives.
  IND                                                            0.3662***
                                                                                            The empirical evidence supports the theoretical prediction that
                                    ​
                                    ​                            (4.04)
  URB                               ​                            0.5857***              innovation-based environmental policies can yield “win-win” outcomes.
                                    ​                            (6.69)                 Specifically, the results demonstrate that countries investing in AI
  FDI                               ​                            − 0.0074               development experience measurable environmental benefits, validating
                                    ​                            (-0.91)                the Porter Hypothesis’s core proposition that environmental improve­
  INT                                                            − 0.0120
                                                                                        ment and innovation can be complementary rather than conflicting
                                    ​
                                    ​                            (-0.82)
  TO                                ​                            − 0.0147               objectives. Furthermore, the robustness of the AIP coefficient across
                                    ​                            (-1.36)                specifications suggests that the induced innovation mechanism is oper­
  POP                               ​                            0.0042***              ating effectively in the AI domain, where environmental challenges are
                                                                 (3.29)
                                    ​
                                                                                        spurring technological solutions that reduce carbon intensity. This
  Constant                          0.2114***                    0.6245***
                                    (244.57)                     (3.81)                 finding has important implications for environmental policy design,
                                                                                        suggesting that innovation incentives and R&D support may be as
  Country FE                        ✓                            ✓
  Year FE                           ✓                            ✓
                                                                                        effective as traditional command-and-control regulations in achieving
  Obs.                              551                          551                    decarbonization objectives.
  R2                                0.976                        0.981

Note: The coefficient estimates are accompanied by robust standard errors.              4.2. Endogeneity analysis
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %
level, and * for the 10 % level.                                                            Our estimation framework faces several potential endogeneity
                                                                                        challenges that could compromise the credibility of our fin­
comprehensive set of country-specific control factors (Column 2), the                   dings—namely, reverse causality, measurement error, and omitted
AIP coefficient maintains its negative direction and high statistical sig­              variable bias (Angrist and Pischke, 2009). While measurement error
nificance at the 1 % level, demonstrating the robustness of this                        poses a potential threat when explanatory variables are inaccurately
relationship.                                                                           recorded, we minimize this risk using high-quality cross-sectional data,
    The consistent negative association between AITlevels and CO2                       robust statistical methodologies, and a focus on relative differences
emissions provides strong empirical support for research Hypothesis H1,                 rather than absolute levels. More critically, reverse causality presents a
which posits that AIPcontributes positively to decarbonization. Specif­                 complex challenge in our analysis. The relationship specified in Equa­
ically, the results indicate that countries with more advanced AIP                      tion (1) may be subject to bidirectional causation, where carbon emis­
implementation experience significantly lower CO2 emissions levels,                     sions could influence AI development patterns. Specifically, countries
after controlling for potential confounding factors.                                    with already low CO2 emission levels might be more inclined to invest in
    These findings are theoretically grounded in several established                    technological innovation, potentially accelerating their AIP. This creates
frameworks from environmental economics. The Porter Hypothesis                          a feedback loop that compounds the analytical complexity. Additionally,
(Porter and van der Linde, 1995) suggests that properly designed envi­                  omitted variable bias represents a concern when important de­
ronmental regulations can trigger innovation that partially or fully off­               terminants of carbon emissions are excluded from our model specifica­
sets compliance costs. Our results support this theory, as the negative                 tion. To comprehensively address these interconnected endogeneity
AIPcoefficient indicates that countries with comprehensive AIpolicy                     concerns, we employ a multi-pronged approach including instrumental
frameworks may be experiencing innovation-driven environmental                          variable (IV) estimation with GMM, the Oster coefficient stability test,
                                                                                        and propensity score matching to control for potential selection bias.

                                                                                    6
B. Bergougui                                                                                                              Technology in Society 83 (2025) 103029


4.2.1. Instrumental variable approach                                            environmental policies or emission levels. The relevance condition is
    Building on this foundation, we implement an instrumental variable           also met, as these milestone years align with noticeable surges in AI
strategy using two-stage least squares (2SLS) estimation with two                patenting activity worldwide. The instrument thus introduces exoge­
distinct instruments to ensure robustness of our identification strategy.        nous variation in AIP that is uncorrelated with unobserved confounders
This dual-instrument approach allows us to test the validity of our              in the emissions equation.
identification assumptions while providing multiple sources of exoge­                Table 2 presents the results from our Two-Stage Least Squares
nous variation.                                                                  regression designed to address potential endogeneity between AIP and
    First instrument (Geographical Proximity): Our first instrument for          CO2 emissions. We employ both instruments separately to demonstrate
AIP is constructed as:                                                           robustness across different identification strategies. In the first stage
                                                                                 (Column 1), our geographical proximity instrument demonstrates a
IV1it = φi AIPU.S. t− 1                                               (2)
                                                                                 strong and statistically significant relationship with AIP (coefficient =
                                                                                 0.8341, p < 0.01), confirming instrument relevance. In the second stage
 • φi represents the geographical closeness of country i to the U.S.             (Column 2), AIP’s impact on CO2 emissions remains negative and highly
   Specifically, it is defined as the standardized inverse geographical          significant (coefficient = − 0.0184, p < 0.01) when using the
   distance, measured in kilometers, separating the capital cities of            geographical proximity instrument. When employing the AI break­
   country i and the USA. This measure is normalized to a range be­              through discovery instrument, we observe similar patterns of strong
   tween 0 and 1, where the domestic distance for the U.S. is set at 1 km.       first-stage relevance and consistent second-stage results, with AIP
   Therefore, larger values of this variable indicate nearer geographical        maintaining its negative and significant effect on CO2 emissions (coef­
   proximity to the USA.                                                         ficient = − 0.0289, p < 0.01). This consistency across different identi­
 • AIPU.S. t− 1 denotes the previous year’s AIP level in the USA.                fication strategies strengthens our confidence in the causal relationship.
                                                                                 The consistency of results across different specifications and instruments
   Second instrument (AI breakthrough discovery): Complementing                  suggests that the observed relationship is robust and not driven by
our geographical instrument, our second instrument captures major                omitted variable bias or reverse causality. The GMM estimation in Model
breakthroughs in AI discovery that created exogenous shocks to global            3 yields an AIPcoefficient of 1.767** (p < 0.05), further supporting the
AI development. IV2 = 1 if year corresponds to major AI breakthrough,            negative association between AIPand carbon emissions (see Table 3).
0 otherwise. Specifically, we set IV2 = 1 for years marking significant AI
breakthroughs.                                                                   4.2.2. Oster coefficient stability test
                                                                                     We apply Oster’s (2019) bias-adjusted treatment test to further
 • 2012: Deep learning breakthrough with Convolutional Neural Net­               assess the risk of omitted variable bias. This approach evaluates coeffi­
   works (CNNs)                                                                  cient stability when transitioning from observed to unobserved pre­
 • 2017: Transformer model breakthrough revolutionizing natural                  dictors, providing a more nuanced assessment of endogeneity concerns.
   language processing                                                           The test examines whether the predictor’s coefficient remains stable
 • 2020: Major reinforcement learning breakthrough and other signif­             across varying subsamples, detecting potential endogeneity by
   icant AI developments                                                         observing how coefficients change as sample characteristics shift.
                                                                                 Oster’s method assumes that observed predictors are representative of
    This instrument exploits the fact that major AI breakthroughs                all relevant variables and provides a range for the treatment effect by
represent exogenous technological shocks that affect global AI patent            analyzing the proportional influence (δ) between observed and unob­
activity but are not directly caused by individual countries’ carbon             served predictors, along with the overall model fit (Rmax). A δ value of 1
emission levels.                                                                 indicates equal weight between observed and unobserved variables,
    Geographical proximity instrument (IV1): This instrument is                  while δ > 1 suggests stronger influence from unobserved factors. Col­
constructed to satisfy both the relevance and exclusion requirements             umn (4) of Table 2 presents the Oster test results. The AIP coefficient
fundamental to valid IV estimation. By weighting the lagged AIP level in         remains − 0.017*** (p < 0.05), indicating a significant negative effect.
the U.S. with φi —the standardized inverse distance from country iii to          The δ statistic of − 0.141 suggests reasonable coefficient stability as
the U.S. capital—our instrument exploits well-documented geographic              covariates are added, indicating low sensitivity to potential omitted
decay in knowledge spillovers, whereby innovation benefits diminish as           variable bias. The β statistic of − 0.0455 (p < 0.01) further confirms
physical separation increases (Kwon et al., 2022). Given the USA’ pre­           coefficient robustness, reinforcing the stability and significance of the
eminence in AI patent filings, proximate nations experience dispropor­           negative AI-emissions relationship.
tionately greater access to cutting-edge AI techniques through
collaborative ventures, licensing, and informal cross-border exchanges,          4.2.3. Propensity score matching
ensuring a strong statistical association between IVit and domestic AIP              Countries’ decisions to invest in AI development may not be random
(Ganguli et al., 2020; Zheng & Slaper, 2016). Moreover, the use of the U.        and could be influenced by unobserved factors that also affect emissions.
S. AIP level lagged by one year introduces temporal precedence, effec­           We employ propensity score matching to address this potential selection
tively precluding any direct contemporaneous effect of American AIP              bias (Caliendo & Kopeinig, 2008). Column (5) of Table 2 presents results
advancements on foreign carbon emissions and thereby satisfying the              using nearest-neighbor matching, where countries with AI levels above
exclusion restriction. Because geographic distance is inherently                 the global sample median constitute the treatment group (indicating
time-invariant and the lagged U.S. AI measure is predetermined with              more comprehensive AI adoption), while those below the median form
respect to current emission outcomes, the instrument also meets the              the control group. The treatment effect, captured by the coefficient on
criterion of exogeneity, mitigating concerns about omitted variable bias         the TREATED variable, measures the impact of more extensive AI
and reverse causality (Abbasiharofteh et al., 2024; Hu et al., 2025).            adoption on emissions. After matching, standardized differences be­
Consequently, IVit provides a robust source of exogenous variation in            tween treated and control groups should ideally fall below 10 %, indi­
AIP, enabling consistent estimation of AIP’s impact on CO2 emissions             cating well-balanced covariates. In Model (5), the TREATED coefficient
while upholding the core assumptions of instrumental variable meth­              is − 0.007** (p < 0.01) with a mean bias of 13 %. Despite slightly
odology (Ganguli et al., 2020).                                                  exceeding the ideal threshold, this represents a substantial improvement
    Turning to the AI Breakthrough discovery instrument (IV2), its               and confirms that AI adoption is associated with decreased carbon
exogeneity stems from the fact that these breakthroughs are determined           emissions, even after controlling for other factors.
by global scientific progress rather than any individual country’s

                                                                             7
B. Bergougui                                                                                                                              Technology in Society 83 (2025) 103029


Table 2
Endogeneity analysis results.
  Independent variable                      IV-2SLS (IV1)                IV-2SLS (IV2)                 2-step GMM                   Oster test                     PMS

                                            (1)                          (2)                           (3)                          (4)                            (5)

  AIP                                       − 0.018***                   − 0.029***                    0.049***                     − 0.017***                     /
                                            (0.005)                      (0.006)                       (0.011)                      (0.004)                        /
  GDP                                       − 0.087***                   − 0.165***                    − 0.116***                   − 0.091**                      − 0.145***
                                            (0.013)                      (0.013)                       (0.040)                      (0.044)                        (0.017)
  IND                                       0.307***                     0.801***                      0.694***                     0.366                          0.743***
                                            (0.078)                      (0.074)                       (0.262)                      (0.216)                        (0.106)
  URB                                       0.528***                     0.246***                      0.087                        0.586**                        − 0.095
                                            (0.068)                      (0.079)                       (0.136)                      (0.228)                        (0.086)
  FDI                                       − 0.009                      0.018*                        0.008                        − 0.007                        − 0.000
                                            (0.009)                      (0.011)                       (0.043)                      (0.015)                        (0.008)
  INT                                       − 0.001                      − 0.082***                    0.169*                       − 0.012                        − 0.098***
                                            (0.011)                      (0.012)                       (0.092)                      (0.034)                        (0.016)
  TO                                        − 0.013                      − 0.015                       − 0.007                      − 0.015                        0.013
                                            (0.009)                      (0.010)                       (0.031)                      (0.029)                        (0.011)
  POP                                       0.005***                     0.007***                      0.000                        0.004                          0.013***
                                            (0.001)                      (0.001)                       (0.001)                      (0.003)                        (0.003)
  TREATED                                   /                            /                             /                            /                              − 0.007**
                                            /                            /                             /                            /                              (0.003)

  Country FE                                ✓                            ✓                             ✓                            ✓                              ✓
  Year FE                                   ✓                            ✓                             ✓                            ✓                              ✓
  Obs.                                      522                          522                           522                          551                            535
  Instrument Relevance                      363.884***                   361.847***                    493.366***                   /                              /
  Instrument Strength                       1077.038***                  546.771***                    8546.233***                  /                              /
  Delta                                     /                            /                             /                            − 4.124                        /
  Beta                                      /                            /                             /                            − 0.0455                       /
  Mean bias                                 /                            /                             /                            /                              13.59 %

Note.
•Statistical significance levels are denoted as ***p < 0.01, **p < 0.05, and * p < 0.10, with robust standard errors reported in parentheses below coefficient estimates.
•Model (1) uses the two-stage least squares (2SLS) estimator with an instrumental variable based on geographic proximity, while Model (2) applies the same 2SLS
approach but instruments using breakthrough discoveries in AI. Model (3) implements the two-step generalized method of moments (GMM) estimator, Model (4)
presents results from the Oster test for coefficient stability assessment, and Model (5) employs propensity score matching estimation.
•The instrument diagnostics confirm the validity of the instrumental variable approach across the relevant models. For instrument relevance, the Anderson canonical
correlation LM test statistics demonstrate that the instruments are relevant across all IV models (columns 1–3), with all tests being significant at least at the 5 % level,
thereby indicating strong statistical relationships between the chosen instruments and the endogenous variables they predict. Regarding instrument strength, the
Cragg-Donald Wald F statistics are significant at the 1 % level for all IV models, confirming that the instruments are strong rather than weak and validating the
instrumental variable approach employed in the analysis.


Table 3
Robustness check outcomes using alternative measurements of CO2 emissions and AI patents.
                     Ln               Ln                    Ln             Ln                CO2                 CO2 (Winsorized)          CO2                     CO2
                     (CO2/GDP)        (Total CO2)           (EF)           (GHG)             (Winsorized)                                  (R&D-Weighted)          (AIP2)

                     (1)              (2)                   (3)            (4)               (5)                 (6)                       (7)                     (8)

  AIP                − 0.024**        − 0.026**             − 0.068***     − 0.084***        − 0.021***          − 0.017***                − 0.004***              − 0.060***
                     (-2.57)          (-2.56)               (-5.83)        (-5.22)           (-4.03)             (-5.53)                   (-4.98)                 (-4.21)
  AIP2               ✓                ✓                     ✓              ✓                 ✓                   ✓                         ✓                       − 0.157***
                     ✓                ✓                     ✓              ✓                 ✓                   ✓                         ✓                       (-9.23)
  GDP                − 0.208***       0.798***              0.407***       0.453***          − 0.090***          − 0.083***                − 0.090***              0.786***
                     (-3.10)          (10.29)               (6.28)         (5.77)            (-5.27)             (-4.90)                   (-5.28)                 (8.10)
  IND                2.226***         3.073***              2.924***       3.989***          0.363***            0.340***                  0.364***                0.329***
                     (5.96)           (7.49)                (8.11)         (9.63)            (4.00)              (3.88)                    (4.02)                  (3.88)
  URB                1.685***         2.251***              0.815**        0.147             0.584***            0.507***                  0.581***                0.018**
                     (5.70)           (6.38)                (2.36)         (0.33)            (6.65)              (5.80)                    (6.62)                  (2.31)
  FDI                − 0.041          − 0.049*              0.155***       0.153***          − 0.008             − 0.013                   − 0.007                 − 0.088***
                     (-1.45)          (-1.73)               (3.41)         (2.76)            (-0.94)             (-1.63)                   (-0.91)                 (-6.79)
  INT                0.341***         0.330***              − 0.110**      − 0.096           − 0.013             0.013                     − 0.012                 − 0.020**
                     (5.90)           (5.31)                (-2.01)        (-1.41)           (-0.85)             (1.04)                    (-0.81)                 (-2.07)
  TO                 − 0.110***       − 0.189***            0.020          − 0.218***        − 0.015             − 0.023**                 − 0.014                 0.005***
                     (-3.19)          (-4.86)               (0.60)         (-4.16)           (-1.37)             (-2.12)                   (-1.34)                 (3.53)
  POP                0.001            0.009**               0.016***       0.010             0.004***            0.003**                   0.004***                0.006**
                     (0.16)           (1.98)                (3.41)         (1.60)            (3.27)              (2.58)                    (3.29)                  (2.17)
  Contant            − 1.487**        − 7.893***            13.198***      13.974***         0.622***            0.605***                  0.623***                1.489***
                     (-2.44)          (-11.15)              (24.99)        (19.30)           (3.79)              (3.75)                    (3.80)                  (10.57)
  Country FE         ✓                ✓                     ✓              ✓                 ✓                   ✓                         ✓                       ✓
  Year FE            ✓                ✓                     ✓              ✓                 ✓                   ✓                         ✓                       ✓
  Obs.               551              551                   551            551               551                 551                       551                     551
  R2                 0.985            0.998                 0.997          0.996             0.981               0.982                     0.981                   0.981

Note. The coefficient estimates are accompanied by robust standard errors. Statistical significance is indicated using *** for the 1 % level, ** for the 5 % level, and * for
the 10 % level.


                                                                                         8
B. Bergougui                                                                                                               Technology in Society 83 (2025) 103029


4.3. Robustness checks                                                            are defined or adjusted.

    To assess the stability and reliability of the baseline regression            4.3.2. Temporal subsample analyses
findings, the model specified in Equation (1) was re-examined through                 To mitigate potential confounding factors arising from the COVID-19
alternative specifications, variable transformations, and subsample an­           pandemic, we conducted temporal subsample analyses employing
alyses. These robustness checks aim to confirm whether the observed               restricted observation periods.
relationship between AIP and CO2 emissions persists across diverse                    Specification (1) excludes observations from 2020 onwards, con­
methodological and contextual scenarios.                                          straining the analytical framework to the period 2005–2019. The AIP
                                                                                  coefficient maintains statistical significance within this restricted tem­
4.3.1. Alternative variable definitions                                           poral domain, substantiating that the emission-reduction effects attrib­
    To assess the robustness of the results, several alternative specifica­       utable to AI technological advancement preceded pandemic-induced
tions were employed, modifying the measurement of key variables to                economic and environmental disruptions.
ensure the findings were not dependent on specific variable definitions               Specification (2) examines the post-2012 epoch, corresponding to
or measurement approaches. The steps taken to validate the robustness             seminal developments in deep learning architectures, particularly con­
are outlined as follows.                                                          volutional neural networks, which catalyzed the proliferation of AIP
                                                                                  applications across diverse domains including autonomous systems and
 • Alternative dependent variable specifications: Column (1)                      natural language processing (WIPO, 2019). The empirical findings
   replaced the dependent variable with the natural logarithm of CO2              indicate that the environmental co-benefits of AIP activity intensified
   emissions (ln_CO2). This transformation allows for the modeling of             concomitantly with technological maturation, with emission reductions
   potential nonlinearities in the relationship between AI patents (AIP)          persisting notwithstanding expanded commercial deployment.
   and CO2 emissions. The coefficient for AIP in this specification was
   − 0.024, which was statistically significant, reinforcing the negative         4.3.3. Lagged effects
   association between AIP and emissions. In Column (2), total CO2                    To further address this temporal concern, we used the lagged effects
   emissions (total_CO2) were used as the outcome variable, yielding a            of the AIP on CO2 emissions by introducing lagged explanatory vari­
   significant negative impact. This finding further supports the                 ables for one, two, and three periods. This approach is crucial for
   robustness of the relationship, as the results remain consistent across        identifying delayed impacts of the AI innovation on CO2 emissions and
   different CO2 measurement approaches.                                          ensuring the robustness of our findings. Specifically, in Columns (3–5) of
 • Environmental impact measures: Beyond our primary focus on                     Table 4, we employed lagged independent variables, using data from the
   CO2 emissions, we extend the analysis to capture broader environ­              previous year for each variable to capture the delayed effects of AI on
   mental sustainability effects through additional ecological in­                emissions. The regression results from this model show that the AIP
   dicators. When examining the total ecological footprint (EF) in                coefficient remains significantly negative, reinforcing the robustness of
   Column (3), AIP demonstrates a coefficient of − 0.068, indicating              our findings. This approach allows us to more accurately assess the
   that artificial intelligence development contributes to reducing               potential lag in the environmental benefits of AIP, ensuring that the
   overall environmental pressures. Similarly, when greenhouse gas                results reflect the real-world delay between patent innovation and
   emissions (GHG) serve as the outcome variable in Column (4), the               commercial deployment. The lagged analysis in Table 4 provides further
   coefficient of − 0.084 reveals that AI’s environmental benefits                evidence of the robustness of our results and highlights the importance
   encompass a broader spectrum of atmospheric pollutants beyond                  of considering both short-term and long-term effects in the evaluation of
   carbon dioxide alone. These complementary findings substantiate                the impact of AI on emissions. These findings confirm that the impact of
   that AI’s contribution to environmental sustainability transcends              the AIPis not immediate and may manifest after a few periods, thus
   specific emission categories, suggesting that technological innova­            supporting the use of lagged models to capture the full scope of its
   tion through artificial intelligence generates comprehensive ecolog­           effects.
   ical improvements that extend across diverse environmental impact
   channels.                                                                      4.3.4. Placebo test
 • Outlier treatment: Columns (5) and (6) addressed the potential                     To ensure that the observed relationship between AI patent activity
   influence of extreme values by implementing winsorization, which               and carbon emissions is not confounded by general technological
   adjusts the highest and lowest one percent of observations for both            progress or driven by random temporal variation, we conduct two
   the dependent (CO2 emissions) and independent (AIP) variables. The             distinct placebo tests to strengthen the causal interpretation of our
   coefficients for AIP remained significantly negative, at − 0.021 and           findings.
   − 0.017 respectively, indicating that the results are not driven by
   outliers or extreme values in the data. This strengthens the argument           • Non-AI patent placebo test: In the first specification, we replace the
   that AIP’s effect on emissions is robust and not unduly influenced by             AIP variable with counts of patents unrelated to AI technologies,
   atypical observations.                                                            capturing broader but non-AI-specific innovation efforts. As shown
 • Innovation quality adjustment: In Column (7), the AIP variable                    in Table 4, Column 6, the estimated coefficient for non-AI patents is
   was redefined to account for the quality of innovation. Here, AIP was             positive and statistically significant, in stark contrast to the consis­
   modified by incorporating R&D spending as a percentage of eco­                    tently negative and significant coefficients for AIP. This suggests that
   nomic output, reflecting the assumption that higher R&D investment                general technological progress—at least as proxied by non-AI patent
   correlates with the generation of higher-quality patents. The                     activity—is either ineffective in reducing emissions or may even be
   adjusted coefficient for AIP was − 0.004, which remained statistically            associated with increases in emissions. This contrast reinforces our
   significant, indicating that the negative relationship between AIP                claim that AI innovations uniquely contribute to emission re­
   and emissions holds even when accounting for innovation quality.                  ductions, rather than the effect being attributable to overall tech­
                                                                                     nological intensity.
    These alternative specifications provide strong evidence that the              • Randomized temporal placebo test: To further test whether our
negative relationship between AIP and CO2 emissions is robust across                 findings could arise from unobserved temporal confounders or
various measurements and treatments of the data. The consistent                      spurious correlation, we implement a randomized intervention
negative coefficients across different specifications affirm that AIP is a           approach (Bergougui et al., 2025). Specifically, we conduct 500
reliable factor in reducing emissions, regardless of how the key variables           simulation trials where the timing of AI patent adoption is randomly

                                                                              9
B. Bergougui                                                                                                                            Technology in Society 83 (2025) 103029


Table 4
Robustness check outcomes using placebo test and two sample periods.
  Independent variable         Dependent variable: CO2 emissions

                               Pre-COVID               Post-AI 2011 breakthroughs         Lagged effect         Lagged effect          Lagged effect          Placebo test
                                                                                          L1.AIP                L2.AIP                 L3.AIP                 Non-AI Patent

                               (1)                     (2)                                (3)                   (4)                    (5)                    (6)

  AIP                          − 0.0153***             − 0.0086***                        − 0.014***            − 0.012***             − 0.010***             0.0011***
                               (0.0046)                (0.0023)                           (-4.96)               (-4.07)                (-2.99)                (0.0003)
  GDP                          − 0.0954***             − 0.1015***                        − 0.086***            − 0.089***             − 0.092***             − 0.0940***
                               (0.0195)                (0.0189)                           (-5.13)               (-5.47)                (-5.61)                (0.0166)
  IND                          0.4082***               − 0.0943                           0.297***              0.253***               0.167*                 0.3665***
                               (0.0947)                (0.1228)                           (3.32)                (2.90)                 (1.87)                 (0.0922)
  URB                          0.6356***               0.4009***                          0.534***              0.453***               0.442***               0.6072***
                               (0.0985)                (0.1121)                           (5.84)                (4.99)                 (4.95)                 (0.0836)
  FDI                          0.0001                  − 0.0051                           − 0.008               − 0.012*               − 0.014*               − 0.0117
                               (0.0083)                (0.0070)                           (-1.10)               (-1.74)                (-1.85)                (0.0084)
  INT                          − 0.0188                − 0.0006                           − 0.001               0.007                  0.009                  − 0.0056
                               (0.0169)                (0.0144)                           (-0.08)               (0.58)                 (0.73)                 (0.0146)
  TO                           − 0.0064                − 0.0049                           − 0.011               − 0.013                − 0.014                − 0.0107
                               (0.0107)                (0.0153)                           (-1.01)               (-1.16)                (-1.21)                (0.0104)
  POP                          0.0045***               0.0068**                           0.005***              0.005***               0.006***               0.0048***
                               (0.0013)                (0.0030)                           (3.24)                (3.01)                 (2.86)                 (0.0013)
  Constant                     0.6311***               0.9472***                          0.620***              0.717***               0.765***               0.6237***
                               (0.1891)                (0.2123)                           (3.81)                (4.36)                 (4.44)                 (0.1622)

  Country FE                   ✓                       ✓                                  ✓                     ✓                      ✓                      ✓
  Year FE                      ✓                       ✓                                  ✓                     ✓                      ✓                      ✓
  Obs.                         435                     348                                522                   493                    464                    551
  R2                           0.9820                  0.9941                             0.983                 0.986                  0.988                  0.9815

Note. The coefficient estimates are accompanied by robust standard errors. Statistical significance is indicated using *** for the 1 % level, ** for the 5 % level, and * for
the 10 % level.


    reassigned across the sample. The resulting distribution of placebo                   5. Underlying channels
    coefficients, illustrated in Fig. 3, is approximately normal and tightly
    clustered around zero. The vast majority of simulated estimates are                   5.1. Energy efficiency as a channel for AI-driven emission reductions
    statistically insignificant (p-values >0.10), indicating no meaningful
    association between randomized AI patent timing and carbon                                Research hypothesis H2 proposes that AI patenting activity promotes
    emissions.                                                                            decarbonization through increased efficiency in energy utilization
                                                                                          throughout economic production and societal energy use. To test this
    Importantly, the baseline regression coefficient lies well outside the                hypothesis empirically, we utilize two key metrics: (1) per capita carbon
central mass of the simulated placebo distribution. This displacement                     dioxide emissions (CO2_PC), which reflects the environmental impact of
suggests that the observed relationship between AIP and emissions is not                  individual energy consumption, and (2) primary energy intensity (PEI),
a statistical artifact of random assignment or time-related bias. Instead,                calculated as primary energy consumed per unit of economic output,
it reflects a distinct and systematic effect of AI innovations on environ­                which captures the efficiency of energy used in the generation of eco­
mental outcomes. Taken together, these two placebo tests—one based                        nomic value.
on alternative technological domains and the other on randomized                              As shown by the regression results in Table 5, Column (1), the co­
temporal variation—provide strong empirical validation for the causal                     efficient for AIP is statistically significant and associated with a reduc­
role of AI in driving decarbonization. They demonstrate that the                          tion in per capita CO2 emissions, this implies that an increase of 1000
emission-reducing impact of AI is not only statistically robust but also                  AIP correlates with a decline of roughly 0.981 metric tons in per capita
technologically specific and temporally grounded.                                         CO2 emissions. This finding highlight AIP’s capability to enhance energy
                                                                                          utilization across various domains. For instance, AIP-powered intelli­
                                                                                          gent traffic management systems can adjust signal timing in real time to
                                                                                          minimize vehicle idling and congestion, lowering fuel use and emis­
                                                                                          sions. Adaptive HVAC systems also utilize AIP to optimize temperature
                                                                                          settings according to occupancy, reducing energy expenditure in
                                                                                          buildings. Additionally, smart grids leverage AIP for efficient prediction
                                                                                          of electricity demand and seamless integration of renewable energy
                                                                                          sources, contributing to overall emission mitigation.
                                                                                              In Table 5, Column (2), the regression results indicate an inverse
                                                                                          relationship between AIP and PEI, with an estimated coefficient of
                                                                                          − 0.188. This suggests each additional 1000 AIP application reduces
                                                                                          primary energy intensity by 0.188 MJ per unit of economic output. This
                                                                                          result emphasizes AI’s role in decoupling economic growth from energy
                                                                                          consumption, a cornerstone of sustainable development (Nahar, 2024).
                                                                                          In manufacturing contexts, the application of AI to predictive mainte­
                                                                                          nance can anticipate machine breakdowns and streamline maintenance
                                                                                          planning, thereby minimizing energy inefficiencies during production
                                                                                          processes (Shadi, Mirshekali, and Shaker, 2025). Moreover,
                           Fig. 3. Placebo test results.                                  AI-enhanced logistics networks streamline transportation routes,

                                                                                     10
B. Bergougui                                                                                                                                Technology in Society 83 (2025) 103029


Table 5                                                                                      portional representation of individuals in low-, medium-, and high-skill
Mechanisms of AIP in enhancing production and reducing energy intensity.                     occupations to define LCi . The estimated effect of the AIP*LC interaction
  Independent variable      Per capita CO2 emissions        Primary energy intensity         in Column (1) is consistent with a decrease, it is positive according to the
                                                                                             results in Column (2), while the coefficient in Column (3) is positive but
                            (1)                             (2)
                                                                                             lacks statistical significance. These findings imply that AI’s capacity to
  AIP                       − 0.981 ***                     − 0.188 ***                      mitigate CO2 emissions is predominantly effective in nations with
                            (0.186)                         (0.030)
  GDP                       4.800 ***                       − 1.280 ***
                                                                                             elevated high-skill labor representation. The empirical evidence sup­
                            (0.585)                         (0.200)                          ports the concept of skill-biased technological shift, arguing that
  IND                       8.675 ***                       1.546                            AIconsiderably enhances the effectiveness of workers in high-skill roles.
                            (2.737)                         (1.136)                          Therefore, countries with a more skilled labor force can more readily
  URB                       12.243 ***                      2.529 **
                                                                                             benefit from the efficiency gains induced by AIP, contributing to
                            (2.272)                         (1.007)
  FDI                       − 0.261                         − 0.004                          diminished emissions.
                            (0.255)                         (0.084)                              Additional findings from Table 6, Column (4) arise from examining a
  INT                       2.910 ***                       0.861 ***                        variable representing the share of the labor force in non-routine roles.
                            (0.453)                         (0.200)                          Here, the interaction term (AIP*LC) displays a significantly negative
  TO                        − 0.563 *                       − 0.124
                            (0.316)                         (0.136)
                                                                                             coefficient, suggesting that AI’s emission-reducing potential is amplified
  POP                       0.024                           0.050 ***                        in countries with greater non-routine occupational prevalence. This
                            (0.031)                         (0.018)                          supports the concept of routine-biased technological shift, suggesting
  Constant                  − 55.805 ***                    14.457 ***                       that AIPprovides the greatest productivity enhancements for non-
                            (5.016)                         (1.960)
                                                                                             routine activities (Hötte et al., 2023). Collectively, the evidence from
  Country FE                ✓                               ✓                                Table 6 substantiates the two-fold mechanisms (routine- and skill-biased
  Year FE                   ✓                               ✓                                technological shift) hypothesized by H3, emphasizing AIP’s role in
  Obs.                      551                             551
  R2                        0.9852                          0.9873
                                                                                             fostering ecological well-being.

Note. The coefficient estimates are accompanied by robust standard errors.
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %            5.3. Institutional frameworks
level, and * for the 10 % level.
                                                                                                Hypothesis H4 proposes that stronger, more adaptable institutional
                                                                                             frameworks enhance the ability of AI innovations to lower CO2 emis­
reducing fuel use and emissions. In energy-intensive industries,
                                                                                             sions, thereby promoting decarbonization. To evaluate this, we estimate
real-time monitoring systems powered by AI detect inefficiencies and
                                                                                             the following specification:
suggest improvements, boosting overall energy productivity (El jaouhari
et al., 2025).                                                                               ESit = α + β1 AIPit + β2 AIPit *INSTi + Xit + μi + τt + εit                      (4)
    The simultaneous reductions in CO2 pre capita and PEI provide
compelling evidence that AIP mitigates CO2 emissions by improving                            Where INSTi captures average institutional quality in the country i. We
energy performance at both micro (individual/household) and macro                            operationalize INSTi along three dimensions:
(economic system) levels. These findings robustly support hypothesis
H2, demonstrating that AI’s environmental benefits are directly tied to                      Table 6
its capacity to improve efficiency across various sectors. For policy­                       The moderating role of routine and skill biases technological shift.
makers, these results emphasize the need to incorporate AI technologies                       Independent         Dependent Variable: CO2 emissions
into national energy transition and decarbonization strategies. Priority                      variable
                                                                                                                  High-Skill      Medium-         Low-Skill    Non-Routine
should be given to sectors with high idle energy waste, such as trans­
                                                                                                                                  Skill                        Tasks
portation and construction, and those with inefficient production
                                                                                                                  (1)             (2)             (3)          (4)
methods, like heavy industry. Governmental support for AIPintegration
across these areas can expedite the shift towards decarbonization,                            AIP                 0.178***        − 0.424***      − 0.052**    0.170***
facilitating the alignment of economic progress with ecological well-                                             (2.99)          (-3.92)         (-1.97)      (2.86)
                                                                                              AIP £ LC            − 0.4241***     0.9035***       0.3997       − 0.2948***
being.
                                                                                                                  (0.1289)        (0.2403)        (0.2953)     (0.0934)
                                                                                              GDP                 − 0.097***      − 0.097***      − 0.093***   − 0.097***
5.2. Technological shift: skill and routine biases                                                                (-5.58)         (-5.58)         (-5.40)      (-5.61)
                                                                                              IND                 0.374***        0.374***        0.369***     0.374***
                                                                                                                  (4.06)          (4.01)          (4.05)       (4.09)
   Hypothesis H3 argues that improvements in AI patents facilitate
                                                                                              URB                 0.597***        0.604***        0.589***     0.603***
positive environmental outcomes mediated by routine- and skill-biased                                             (6.92)          (7.02)          (6.75)       (6.95)
technological shifts. The empirical investigation of this hypothesis em­                      FDI                 − 0.009         − 0.009         − 0.008      − 0.008
ploys an econometric framework, defined as follows:                                                               (-1.11)         (-1.14)         (-1.02)      (-1.02)
                                                                                              INT                 − 0.010         − 0.010         − 0.012      − 0.010
ESit = α + β1 AIPit + β2 AIPit *LCi + Xit + μi + τt + εit                         (3)                             (-0.70)         (-0.69)         (-0.79)      (-0.72)
                                                                                              TO                  − 0.014         − 0.014         − 0.014      − 0.013
Here, LCi captures the labor composition of country i across the observed                                         (-1.26)         (-1.27)         (-1.31)      (-1.22)
                                                                                              POP                 0.005***        0.005***        0.004***     0.005***
timeframe. For the evaluation of skill-biased technological shifts, LCi is
                                                                                                                  (3.48)          (3.55)          (3.34)       (3.47)
determined by computing the mean share of the workforce categorized                           Constant            0.672***        0.672***        0.646***     0.670***
across low, medium, and high skill levels within the country. In contrast,                                        (4.09)          (4.08)          (3.93)       (4.08)
for routine-biased technological shifts, it is derived from the average                       Country FE          ✓               ✓               ✓            ✓
share of employees who participated in non-routine occupations.                               Year FE             ✓               ✓               ✓            ✓
Following Acemoglu and Autor (Acemoglu & Autor, 2011), non-routine                            Obs.                551             551             551          551
roles predominantly comprise managerial, technical, professional, and                         R2                  0.982           0.982           0.982        0.982
service-oriented positions, whereas routine roles include administrative,                    Note. The coefficient estimates are accompanied by robust standard errors.
clerical, sales, and production-related jobs.                                                Statistical significance is indicated using *** for the 1 % level, ** for the 5 %
    The empirical outcomes, detailed in columns (1–3), utilize the pro­                      level, and * for the 10 % level.

                                                                                        11
B. Bergougui                                                                                                                                Technology in Society 83 (2025) 103029


1. Legal adaptability (INST1 ): Drawn from the IMF’s AI Preparedness                     Table 8
   Index, the Regulation and Ethics sub-score reflects how swiftly reg­                  Spatial spillover effect.
   ulations can evolve alongside AI advances.                                              Independent variable      CO2                             CO2
2. Labor market efficiency (INST2 ): Sourced from the WDI, this metric                                               Countries closer to the U.S.    Countries far from the U.S.
   gauge the ability of regulations to facilitate efficient workforce                                                (1)                             (2)
   allocation in response to technological change.
                                                                                           AIT                       − 0.0190***                     0.0056
3. Regulatory quality (INST3 ): Also, from WDI, this score indicates the                                             (0.0029)                        (0.0165)
   overall effectiveness and inclusiveness of governmental regulation in                   GDP                       − 0.1673***                     0.0193
   supporting innovative ecosystems.                                                                                 (0.0240)                        (0.0224)
                                                                                           IND                       0.5009***                       − 0.1253
                                                                                                                     (0.0770)                        (0.1476)
    Table 7 displays the results for each institutional dimension. In all
                                                                                           URB                       0.5740***                       0.4904***
three models, the interaction term (AIP*INST) is negative and statisti­                                              (0.0966)                        (0.1579)
cally significant, demonstrating that AI’s emission-reducing effect is                     FDI                       − 0.0145                        0.0851
amplified when institutions are higher. This pattern confirms that flex­                                             (0.0091)                        (0.0595)
ible legal frameworks, efficient labor markets, and robust regulatory                      INT                       0.0395**                        − 0.0663**
                                                                                                                     (0.0178)                        (0.0281)
environments each strengthen AIP’s capacity to curb CO2 output.                            TO                        − 0.0579***                     0.0591***
Consequently, empirical evidence supports H4: strong institutions act as                                             (0.0151)                        (0.0142)
a crucial moderator in the relationship between AIPadoption and                            POP                       0.0242                          0.0065***
COEemissions mitigation.                                                                                             (0.0218)                        (0.0017)
                                                                                           Constant                  1.3693***                       − 0.3379
                                                                                                                     (0.2981)                        (0.2182)
6. Further analysis
                                                                                           Country FE                ✓                               ✓
                                                                                           Year FE                   ✓                               ✓
6.1. Spatial spillover effects                                                             Obs.                      380                             171
                                                                                           R2                        0.9770                          0.9860
   The environmental impacts of AI patenting (AIP) vary significantly
                                                                                         Note. The coefficient estimates are accompanied by robust standard errors.
across regions, reflecting the complexities of global knowledge diffusion
                                                                                         Statistical significance is indicated using *** for the 1 % level, ** for the 5 %
and technology transfer. To analyze these spatial differences, we                        level, and * for the 10 % level.
examined geographic spillover effects originating from the U.S., the
leading hub for AI innovation. Countries were categorized into two
                                                                                         AIP and carbon emissions. Nations positioned in closer geographic
groups based on their proximity to the U.S.: those closer than the sample
                                                                                         proximity to the United States demonstrate a statistically significant and
average distance and those farther away. This approach highlights how
                                                                                         economically substantial reduction in CO2 emissions associated with
geographic distance influences the dissemination of innovation benefits
                                                                                         artificial intelligence patenting activities, with a coefficient of − 0.019
across borders (Zhao et al., 2025).
                                                                                         (p < 0.01). This finding provides compelling evidence for the existence
   The results presented in Table 8 reveal a striking and economically
                                                                                         of robust geographic knowledge transfer effects that facilitate the
meaningful pattern of spatial heterogeneity in the relationship between
                                                                                         adoption and implementation of AI-driven environmental solutions. The
                                                                                         underlying mechanisms driving this spatial pattern are multifaceted and
Table 7                                                                                  interconnected. Countries closer to the United States benefit from
The moderating role of institutional frameworks.                                         significantly enhanced access to cutting-edge AI technologies through
  Independent variable       Dependent Variable: CO2 emissions
                                                                                         well-established and robust trade relationships that facilitate not only
                                                                                         the exchange of goods and services but also the transfer of technological
                             AIP*INST1            AIP*INST2         AIP*INST3
                                                                                         knowledge and expertise. These nations experience more frequent and
                             (1)                  (2)               (3)                  intensive direct collaborations between their firms and academic in­
  AIP                        0.238***             − 0.592***        0.075**              stitutions and their American counterparts, creating channels for real-
                             (0.087)              (0.170)           (0.038)              time knowledge exchange and joint problem-solving initiatives
  AIP £ INSTi                − 0.153***           − 0.379***        − 0.065*             (AlShebli et al., 2023; Tang et al., 2022). Furthermore, the geographic
                             (0.052)              (0.112)           (0.027)
                                                                                         proximity enables more efficient talent exchange programs, where re­
  GDP                        − 0.095***           − 0.098***        − 0.096***
                             (0.017)              (0.017)           (0.017)              searchers, engineers, and entrepreneurs can more easily move between
  IND                        0.376***             0.377***          0.367***             countries, carrying with them valuable tacit knowledge that is often
                             (0.092)              (0.091)           (0.091)              crucial for successful technology implementation (Kucharska & Scott
  URB                        0.599***             0.591***          0.594***
                                                                                         Erickson, 2023). This close interaction and collaboration foster a
                             (0.088)              (0.086)           (0.087)
  FDI                        − 0.008              − 0.010           − 0.009              significantly faster assimilation and adaptation of AI-driven solutions
                             (0.008)              (0.008)           (0.008)              specifically designed for energy efficiency improvements and decar­
  INT                        − 0.010              − 0.009           − 0.013              bonization efforts. The benefits of proximity become particularly
                             (0.015)              (0.014)           (0.015)              evident in the transfer and implementation of sophisticated AI tech­
  TO                         − 0.014              − 0.014           − 0.014
                                                                                         nologies such as smart grid systems and industrial optimization tech­
                             (0.011)              (0.011)           (0.011)
  POP                        0.004***             0.004***          0.004***             niques that have been developed and refined in the United States.
                             (0.001)              (0.001)           (0.001)              Countries like Canada and Mexico, for instance, can more readily access,
  Constant                   0.650***             0.684***          0.670***             adapt, and implement these advanced AI-powered solutions due to their
                             (0.164)              (0.164)           (0.165)
                                                                                         geographic proximity, established trade relationships, and similar reg­
  Country FE                 ✓                    ✓                 ✓                    ulatory frameworks, ultimately leading to more pronounced and
  Year FE                    ✓                    ✓                 ✓                    measurable emission reductions.
  Obs.                       551                  551               551
                                                                                             In stark contrast, countries situated at greater distances from the
  R2                         0.982                0.982             0.982
                                                                                         United States show no statistically meaningful relationship between AIP
Note. The coefficient estimates are accompanied by robust standard errors.               and emission levels, as evidenced by the insignificant coefficient in
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %
                                                                                         Column 2 of Table 8. This absence of a significant relationship suggests
level, and * for the 10 % level.

                                                                                    12
B. Bergougui                                                                                                                       Technology in Society 83 (2025) 103029


that geographic distance functions as a substantial constraint on the                    emissions across both income categories, confirming that AIP contrib­
efficacy of artificial intelligence solutions designed to address climate                utes positively to decarbonization efforts regardless of a country’s level
challenges. The barriers created by greater geographic separation                        of economic development. However, the magnitude and economic sig­
manifest in multiple dimensions, including reduced opportunities for                     nificance of these effects reveal important differences between the two
technology transfer, limited cross-border collaborations, and more                       groups. Both high-income and low-income countries show negative co­
complex licensing arrangements for AI technologies. Countries farther                    efficients for AIP, with statistical significance at the 1 % level, but the
from the United States often face significant economic and institutional                 absolute size of the estimated AIP effect is substantially more pro­
constraints that fundamentally hinder their capacity to effectively                      nounced in low-income economies, indicating a more dramatic emis­
absorb and implement advanced AI solutions. These constraints may                        sions mitigation impact in these regions.
include inadequate technological infrastructure, insufficient human                          This heightened impact in lower-income nations can be attributed to
capital with the necessary skills to operate and maintain AI systems,                    several interconnected factors that create unique opportunities for AI-
regulatory environments that are not conducive to rapid technology                       driven environmental improvements. Low-income countries typically
adoption, and limited financial resources to invest in the necessary                     operate with less efficient industrial and energy infrastructure systems
complementary assets required for successful AI implementation.                          that have not benefited from decades of technological upgrades and
Consequently, the observable decarbonization impact of global AI                         optimization efforts. This infrastructure deficit, while representing a
innovation becomes substantially diminished in these more distant re­                    developmental challenge, simultaneously creates substantial “low-
gions, highlighting the critical importance of geographic proximity in                   hanging fruit” opportunities for AI systems to generate significant effi­
determining the environmental benefits of technological innovation.                      ciency improvements and emission reductions (IEA, 2025; Pimenow
                                                                                         et al., 2024). The concept of technological leapfrogging plays a crucial
6.2. Heterogeneity of different income levels                                            role in explaining these results. Low-income countries possess the
                                                                                         unique ability to bypass traditional development stages by directly
    The relationship between artificial intelligence patenting and                       adopting modern AI-enabled solutions without being constrained by
decarbonization varies dramatically across different economic devel­                     substantial sunk investments in older, less efficient technologies. Unlike
opment levels, revealing important insights about how technological                      their high-income counterparts, these nations are not locked into
innovation interacts with economic capacity and existing infrastructure.                 existing technological pathways and can more readily embrace trans­
While conventional wisdom might suggest that high-income countries,                      formative AIP that fundamentally restructure their energy and industrial
with their superior technological resources and advanced infrastructure,                 systems. AIP in low-income countries can yield disproportionately large
would derive greater benefits from AI innovations, our empirical anal­                   proportional reductions in emissions precisely because these economies
ysis reveals a more nuanced and counterintuitive pattern that challenges                 operate from a baseline of higher inefficiency and greater optimization
these assumptions. To investigate these differences, we categorized                      potential. When AIP are applied to improve energy efficiency in pro­
countries into high-income and low-income groups based on whether                        duction processes, optimize logistics and supply chain management, or
their per capita income fell above or below the sample mean. This                        enhance the performance of energy distribution systems, the absolute
classification allows us to examine how economic development level                       and relative improvements are substantially larger in contexts where
mediates the relationship between AI innovation and environmental                        initial inefficiencies are more pronounced and alternative advanced
outcomes.                                                                                decarbonization technologies are either scarce or economically prohib­
    The results presented in Table 9 demonstrate that artificial intelli­                itive. Furthermore, low-income countries often demonstrate greater
gence patenting exhibits a statistically significant effect in reducing CO2              adaptability and flexibility in adopting new technologies, as they face
                                                                                         fewer institutional constraints and legacy system dependencies that
Table 9                                                                                  might slow down implementation processes. Their regulatory environ­
Heterogeneous effects of AIP on CO2 emissions by different income levels.                ments may be more accommodating to rapid technological change, and
                                                                                         their industries may be more willing to embrace disruptive innovations
  Independent variable          CO2 emissions                 CO2 emissions
                                                                                         that promise significant efficiency gains.
                                High-income group             Low-income group               In contrast, high-income countries already possess sophisticated
                                (1)                           (2)                        technological infrastructure and well-established environmental pol­
  AIP                           − 0.0215***                   − 0.2751***                icies that have resulted in relatively efficient energy systems through
                                (-6.40)                       (-3.67)                    decades of continuous improvement and optimization. While AIP still
  GDP                           − 0.0327                      − 0.1439***                provide valuable contributions to further refining these already
                                (-1.15)                       (-5.71)                    advanced systems, such as optimizing existing renewable energy grids,
  IND                           0.2241**                      0.5453***
                                (2.35)                        (3.01)
                                                                                         enhancing energy storage capabilities, or improving the efficiency of
  URB                           0.3901***                     0.9188***                  already sophisticated industrial processes, the incremental benefits of AI
                                (3.68)                        (6.36)                     in generating additional emission reductions are naturally more modest
  FDI                           − 0.0111                      0.1708                     compared to the transformative potential that exists in less developed
                                (-1.65)                       (1.34)
                                                                                         and less optimized systems. The institutional and economic context in
  INT                           0.0323                        0.0180
                                (1.49)                        (0.63)                     high-income countries also creates different dynamics for AI adoption.
  TO                            0.0038                        0.0262                     These nations often have more complex regulatory frameworks, estab­
                                (0.30)                        (1.46)                     lished industry practices, and existing technological investments that
  POP                           0.0037***                     0.0873***                  can slow down the implementation of disruptive AI innovations. Addi­
                                (2.95)                        (3.71)
  Constant                      0.1200                        0.7679***
                                                                                         tionally, the marginal cost of achieving further emission reductions is
                                (0.35)                        (2.93)                     typically higher in countries that have already implemented many of the
                                                                                         most cost-effective decarbonization measures.
  Country FE                    ✓                             ✓
  Year FE                       ✓                             ✓
  Obs.                          350                           189                        6.3. Heterogeneity of energy utilization pattern
  R2                            0.985                         0.979

Note. The coefficient estimates are accompanied by robust standard errors.                  The relationship between AI innovation and carbon emission re­
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %        ductions is strongly shaped by a country’s energy infrastructure. Nations
level, and * for the 10 % level.                                                         with higher reliance on fossil fuels tend to produce more CO2 emissions,

                                                                                    13
B. Bergougui                                                                                                                       Technology in Society 83 (2025) 103029


offering greater potential for AI-driven efficiency improvements                         require more complex and capital-intensive technological advance­
compared to countries already using substantial renewable energy. To                     ments. In this context, AI’s value lies less in direct emissions mitigation
explore these differences, we classified countries into two groups—high                  and more in enabling long-term energy system optimization. This het­
and low fossil-fuel reliant—based on their renewable energy share from                   erogeneity underscores the importance of tailoring AI deployment
the World Development Indicators database. Using the sample average                      strategies: the greatest environmental returns are observed in high
as a threshold, we identified high fossil-fuel reliant economies as those                fossil-fuel dependent economies where AI can drive substantial effi­
below the average in renewable energy use, while low fossil-fuel reliant                 ciency gains. For policy makers and innovators, this suggests a targeted
economies exceeded it. This distinction allows for a targeted analysis of                approach—prioritizing AI applications in carbon-intensive contexts—­
how AI innovation differentially impacts emissions depending on a                        while recognizing that in clean-energy systems, AI’s strategic value may
country’s energy profile.                                                                lie in ensuring reliable, scalable, and economically efficient transitions
    The findings in Table 10 highlight significant heterogeneity in the                  to sustainable energy futures.
environmental benefits of AI technologies, aligning with theoretical
expectations. In high fossil-fuel dependent economies, AI patenting ac­                  6.4. Heterogeneity in different types of AIP
tivity significantly reduces CO2 emissions (coefficient = − 0.0135, p <
0.01), demonstrating the potential for AI to drive substantial decar­                        To explore how different categories of AIP impact CO2 emissions, we
bonization gains. This effect stems from AI’s ability to optimize ineffi­                used WIPO classification standards by collecting data on AIP applica­
cient, carbon-intensive energy systems. For instance, AI enhances power                  tions across three key subcategories: AIP applied to planning and
plant efficiency by improving combustion processes, reducing energy                      scheduling functions (AIP_1), industry and manufacturing (AIP_2), and
waste, and optimizing maintenance schedules. Additionally, AI-powered                    energy management (AIP_3). As illustrated in Fig. 4, these specialized
smart grids minimize transmission losses, balance loads, and manage                      AIP patents represent varying proportions of total AIP activity during
demand more effectively, cutting emissions and reducing costs by                         our sample period. Energy management AIP constitute approximately
10–20 %. These advancements are particularly impactful in countries                      4.6 % of total AIP, while industry and manufacturing applications
with outdated infrastructure, where inefficiencies create substantial                    represent 56.1 %, and planning and scheduling functions account for
optimization opportunities. In contrast, low fossil-fuel dependent                       39.3 %.
economies show no measurable reduction in emissions from AI patent­                          Table 11 depicts our regression analysis inspecting the environ­
ing (β = 0.0287, p > 0.10). These nations, with cleaner energy systems,                  mental impact of different types of AIP applications. All three AIP cat­
already operate at lower emissions baselines, limiting the marginal                      egories demonstrate statistically significant associations with reduced
impact of AI on further reductions. While AI remains valuable for opti­                  CO2 emissions, suggesting their role in enhancing decarbonization.
mizing renewable energy systems—such as forecasting solar/wind                           However, the magnitude of the impact varies markedly across cate­
output, managing storage, and stabilizing grids—their inherently effi­                   gories. AIP specifically focused on energy management (Column 3)
cient infrastructure means AI’s role is more focused on fine-tuning than                 exhibit the strongest decarbonization benefit with a coefficient magni­
achieving transformative emission cuts. Thus, AI’s environmental ben­                    tude substantially larger than those for industry and manufacturing
efits are most pronounced in high fossil-fuel reliant economies, were                    applications (Column 2) or planning and scheduling functions (Column
inefficiencies present greater opportunities for impactful interventions.                1). These findings highlight that while all examined categories of AIP
    Given that these nations have typically implemented the most cost-                   contribute to CO2 emission reductions, AIP directly applied to energy
effective decarbonization strategies, further emission reductions                        management demonstrates the most pronounced decarbonization ben­
                                                                                         efits. This suggests that targeted development of AI solutions specifically
Table 10                                                                                 optimized for energy systems could offer particularly promising path­
Heterogeneous effects of AIP on CO2 emissions by pattern of energy utilization.          ways for addressing climate challenges, despite currently representing
  Independent         Dependent Variable: CO2 emissions
  variable
                      High fossil-fuel reliant            Low fossil-fuel reliant
                      economies                           economies

                      (1)                                 (2)

  AIP                 − 0.0135***                         0.0287
                      (-4.63)                             (1.16)
  GDP                 − 0.0735***                         − 0.1399***
                      (-3.96)                             (-4.22)
  IND                 − 0.0090                            1.1206***
                      (-0.11)                             (8.82)
  URB                 0.6503***                           0.4013***
                      (6.20)                              (3.15)
  FDI                 0.0059                              − 0.0206
                      (0.82)                              (-1.53)
  INT                 − 0.0130                            0.0799***
                      (-0.73)                             (3.74)
  TO                  − 0.0147                            0.0858***
                      (-1.42)                             (3.56)
  POP                 0.0031***                           − 0.0231
                      (3.07)                              (-0.93)
  Constant            0.4940**                            1.0092***
                      (2.40)                              (3.29)

  Country FE          ✓                                   ✓
  Year FE             ✓                                   ✓
  Obs.                345                                 188
  R2                  0.985                               0.986

Note. The coefficient estimates are accompanied by robust standard errors.
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %
level, and * for the 10 % level.                                                                    Fig. 4. Percentages of AI patents by application type.

                                                                                    14
B. Bergougui                                                                                                                      Technology in Society 83 (2025) 103029


Table 11                                                                                 demonstrate more significant improvements in decarbonization, likely
Effect of three AIP categories on CO2 emissions.                                         benefiting from knowledge spillovers. Additionally, the positive influ­
  Independent variable     CO2 emissions      CO2 emissions       CO2 emissions          ence of AIP is observed to be more pronounced in economies categorized
                                                                                         as lower-income and those with high reliance on conventional fossil
                           AIP_1              AIP_2               AIP_3
                                                                                         fuels, highlighting its potential as a tool for transitioning towards
                           (1)                (2)                 (3)                    cleaner economies in specific contexts. Notably, AIP applications spe­
  AIP_1                    − 0.050***         ​                   ​                      cifically tailored for energy management appear to have a particularly
                           (-7.29)            ​                   ​                      potent effect on enhancing decarbonization. Collectively, our findings
  AIP_2                                       − 0.040***
                                                                                         provide compelling evidence that AIP plays a crucial and accelerating
                           ​                                      ​
                           ​                  (-7.26)             ​
  AIP_3                    ​                  ​                   − 0.294***             role in advancing global efforts towards decarbonization. This research
                           ​                  ​                   (-6.10)                offers valuable insights for policymakers aiming to strategically apply
  GDP                      − 0.092***         − 0.092***          − 0.092***             the development and deployment of AIP to more effectively advance
                           (-5.44)            (-5.43)             (-5.39)                global environmental goals.
  IND                      0.376***           0.376***            0.373***
                           (4.14)             (4.14)              (4.11)
  URB                      0.590***           0.587***            0.585***               7.2. Suggested policies
                           (6.80)             (6.75)              (6.71)
  FDI                      − 0.007            − 0.007             − 0.006                    Our findings suggest several key policy recommendations aimed at
                           (-0.86)            (-0.85)             (-0.79)
  INT                      − 0.013            − 0.013             − 0.012
                                                                                         effectively leveraging AI patenting to drive decarbonization efforts.
                           (-0.89)            (-0.91)             (-0.80)                Governments must adopt a holistic approach to the AI innovation life­
  TO                       − 0.015            − 0.015             − 0.015                cycle, which includes not only incentivizing AI patents but also
                           (-1.35)            (-1.37)             (-1.37)                addressing critical downstream factors such as deployment, infrastruc­
  POP                      0.004***           0.004***            0.004***
                                                                                         ture readiness, and policy integration. In particular, fostering interna­
                           (3.34)             (3.32)              (3.31)
  Cons                     0.637***           0.640***            0.633***               tional cooperation on AI-for-climate intellectual property (IP) transfer is
                           (3.88)             (3.90)              (3.85)                 essential to mitigate the disparities in AI capabilities across countries
  Country FE               ✓                  ✓                   ✓
                                                                                         and ensure that AI innovations contribute to global sustainability goals.
  Year FE                  ✓                  ✓                   ✓                          One important aspect of policy is promoting research and develop­
  Obs.                     551                551                 551                    ment (R&D) in AI applications that are specifically designed to address
  R2                       0.982              0.982               0.982                  environmental challenges. Governments should prioritize funding for
Note. The coefficient estimates are accompanied by robust standard errors.               AIsystems that optimize energy use, improve resource management, and
Statistical significance is indicated using *** for the 1 % level, ** for the 5 %        reduce emissions across key sectors such as transportation,
level, and * for the 10 % level.                                                         manufacturing, and agriculture. To ensure that AIis used for environ­
                                                                                         mental benefits, national AIstrategies should be aligned with sustain­
the smallest proportion of AIP activity among the three categories                       ability objectives, and green AIinitiatives should be supported by
examined.                                                                                appropriate funding mechanisms. These efforts will help channel the
                                                                                         potential of AI toward reducing carbon footprints and accelerating the
7. Conclusions and policy implications and limitations and                               global transition to a low-carbon economy.
future research                                                                              Given the global nature of AI innovation, it is also crucial to
                                                                                         strengthen international cooperation, allowing countries to share best
7.1. Study conclusions                                                                   practices, technologies, and strategies for the sustainable deployment of
                                                                                         AI. Existing global forums and partnerships should be leveraged to
    The pervasive integration of artificial intelligence patent (AIP) across             facilitate the exchange of knowledge and expertise, ensuring that the
global economies necessitates a thorough understanding of its envi­                      benefits of AIP are accessible worldwide, particularly in developing
ronmental implications, particularly concerning decarbonization. This                    nations. This cooperation will foster equitable access to AI-driven
study investigated the relationship using a panel dataset spanning 29                    decarbonization technologies, helping to address global challenges
countries from 2005 to 2023, employing AIP filing counts as a metric for                 such as climate change in a more inclusive manner.
national AI technological advancement. Our empirical analysis yields a                       In this regard, several practical steps can be taken to facilitate in­
consistent finding: higher levels of AIP are significantly associated with               ternational cooperation on AI-for-climate IP transfer. Developed nations
improved decarbonization metrics. This result remains robust when                        with advanced AI capabilities, such as the United States and European
accounting for potential endogeneity and subjecting the model to                         countries, can establish technology-sharing agreements with developing
various sensitivity checks. Delving into the underlying mechanisms, our                  nations. These agreements should focus on AI-for-climate applications
research identifies key pathways through which AIP contributes to                        and facilitate the transfer of technologies, knowledge, and best prac­
decarbonization. First, AIP appears to foster greater energy efficiency,                 tices, ensuring that developing countries can utilize these innovations to
evidenced by its association with reduced per capita CO2 emission                        advance their own decarbonization efforts. Furthermore, creating flex­
impact and lower energy intensity in primary energy consumption.                         ible and affordable licensing models for AI patents related to climate and
Second, AIP drives technological change, specifically inducing routine-                  sustainability technologies is vital. Such models could include reduced
and skill-biased shifts in labor markets. The beneficial environmental                   licensing fees for developing countries, royalty-sharing arrangements, or
influence of AI is more evident particularly in economies with a larger                  long-term partnerships that allow for the localized adaptation and
concentration of high-skilled employment and widespread non-routine                      scaling of AItechnologies. This would make AI innovations more
activities, suggesting that these labor market structures facilitate the                 accessible to countries with weaker IP enforcement or fewer resources.
sustainability gains from AI adoption. Third, a more flexible intuitions                     International cooperation should also focus on enhancing the local
correlate with a stronger positive impact of AI on environmental out­                    AI research and development capacity in developing countries. This can
comes, implying that reduced transaction costs associated with AI                        be achieved through educational partnerships, technical training, and
innovation and deployment amplify its sustainability benefits. Further                   collaborative research projects focused on AI applications for climate
granular analysis reveals heterogeneous effects across different contexts.               change mitigation. Knowledge exchange programs between researchers
Countries situated geographically closer to leading nations in AIP                       from advanced and developing countries can help address disparities in
                                                                                         AI capabilities and foster a more equitable distribution of technological

                                                                                    15
B. Bergougui                                                                                                                Technology in Society 83 (2025) 103029


advances. Establishing funding mechanisms such as a Climate and AI                 • First, our measure of AI-patenting capability relies on aggregate
IPFund is also essential for supporting the acquisition, adaptation, and             patent counts, which may not fully capture the breadth, quality, or
deployment of AItechnologies in developing countries. This fund could                diversity of AI innovations. In particular, we were unable to disag­
be supported by international financial institutions, philanthropic or­              gregate patents by technology type (e.g., predictive-maintenance
ganizations, and technology companies, ensuring that AIinnovations are               algorithms versus deep-learning models for autonomous systems),
both available and affordable for countries with fewer technological                 so our analysis treats all AI patents as a uniform proxy. Future
resources.                                                                           research should leverage more granular patent classifications—or
    To realize the full decarbonization potential of AIP, significant in­            develop citation-weighted and composite innovation indices—to
vestments are required in digital infrastructure tailored to environ­                distinguish between the distinct environmental impacts of different
mental applications. Governments should prioritize expanding public                  AI applications.
data repositories, enhancing computational resources, and supporting               • Second, the macro-level, country-panel approach obscures subna­
platforms that enable the deployment of AIin climate and sustainability              tional and firm-level heterogeneity, preventing detailed investiga­
projects. Creating environments where AI solutions can be tested,                    tion of specific AIP uses, sectoral shifts, or potential rebound effects.
deployed, and scaled effectively is crucial for ensuring that the infra­             Micro-level studies—using firm, household, or regional data—will
structure is ready to meet the demands of AI-driven environmental                    be crucial to establish clearer causal pathways and to assess how AI
solutions.                                                                           adoption translates into operational emissions reductions in contexts
    Moreover, as AI technologies transform industries, it is essential to            like buildings or electric-vehicle charging networks.
prepare the workforce for the changes brought about by AI and its                  • Third, although our 29-country sample covers leading AI innovators
integration into green technologies. Governments should adapt educa­                 (e.g., the United States, Germany, the UK) and accounts for roughly
tion and training systems to equip individuals with the necessary skills             44 percent of global CO2 emissions, it underrepresents many devel­
to work with both AI technologies and green technologies. This will help             oping economies in Asia, Africa, and Latin America. As AI-patent
facilitate the transition to a low-carbon economy, ensuring that workers             data from the Global South improve, expanding the geographic
are prepared for emerging sectors such as green AI, renewable energy,                scope will be essential to test the generality of our results and to
and sustainable manufacturing. Finally, regulatory frameworks must                   capture innovation dynamics under weaker IP regimes.
evolve to keep pace with AI innovation, ensuring that they balance the             • Finally, our analysis focuses on linear relationships and a limited set
need for technological development with environmental protection.                    of decarbonization metrics. Future work should explore nonlinear
Governments should integrate sustainability criteria into AI governance,             and dynamic effects of AI over time, test alternative functional forms,
promoting adaptive, outcomes-based regulations that incentivize envi­                incorporate additional environmental indicators (e.g., sectoral
ronmentally responsible AI development and deployment. This could                    emissions intensity, electricity-carbon ratios), and conduct targeted
include measures such as carbon footprint reporting for AItechnologies,              sensitivity analyses—such as excluding oil-dependent countries or
sustainable design standards, and policies that support AIapplications               using placebo tests with unrelated patent fields—to further validate
aimed at environmental conservation.                                                 the robustness of the AI–environment link.
    These policy recommendations, which encompass a comprehensive
approach to incentivizing AI innovation, fostering international coop­                This multi-faceted research agenda—combining more precise inno­
eration, enhancing local capacity, and investing in infrastructure and            vation measures, finer spatial and sectoral resolution, broader samples,
workforce development, are essential for ensuring that AI technologies            and advanced empirical techniques—will help clarify AI’s long-term
contribute meaningfully to global decarbonization efforts.                        role in sustainable development.

                                                                                  Declaration of competing interest
7.3. Limitations and future research directions
                                                                                      The authors declare that they have no known competing financial
    This study faces several important limitations that qualify our               interests or personal relationships that could have appeared to influence
findings.                                                                         the work reported in this paper.



Appendix A



                                     Table A.1
                                     List of Countries

                                      Country                      Country                              Country

                                      Austria                      Finland                              Norway
                                      Australia                    France                               Poland
                                      Belgium                      Greece                               Portugal
                                      Brazil                       India                                Russia
                                      Canada                       Italy                                Sweden
                                      Switzerland                  Japan                                Singapore
                                      Czech Republic               Republic of Korea                    Turkey
                                      Germany                      Mexico                               United Kingdom
                                      Denmark                      Malaysia                             United States
                                      Spain                        Netherlands                          ​




                                                                             16
B. Bergougui                                                                                                                                               Technology in Society 83 (2025) 103029

Table A.2
List of Variables, Definitions, Sources, and Units

  Variable     Description                                                                     Source                                         Unit

  DEC          Operationalized using CO2 emissions, defined as the ratio of total CO2          World Bank                                     CO2 emissions per unit of GDP (Metric tons per
               emissions to GDP.                                                                                                              million USD)
  AIP          AI patenting activity submitted under the PCT system (scaled in                 WIPO (World Intellectual Property              Thousands of AI patents
               thousands).                                                                     Organization)
  GDP          The natural log of per capita Gross Domestic Product (constant 2017             World Bank                                     Log of GDP per capita (constant 2017 PPP $)
               PPP $).
  IND          Share of total employment in the industrial sector.                             World Bank                                     Percentage (%)
  INT          Share of individuals using the Internet.                                        World Bank                                     Percentage (%)
  FDI          Net Foreign Direct Investment inflows as a proportion of GDP.                   World Bank                                     Percentage (%) of GDP
  URB          Share of population living in urban areas.                                      World Bank                                     Percentage (%)
  TO           Merchandise trade values as a proportion of GDP.                                World Bank                                     Percentage (%) of GDP
  POP          Population density (hundreds of persons per square kilometer).                  World Bank                                     Persons per square kilometer (x100)




                 Table A.3
                 Descriptive Statistics

                    Variable                      Mean                        Std. dev.                        Min.                           Max.                          Obs.

                    ES                             0.208                       0.096                             0.060                         0.560                        551
                    AIP                            0.174                       0.490                             0.002                         4.040                        551
                    GDP                           10.515                       0.551                             8.079                        11.497                        551
                    IND                            0.236                       0.048                             0.146                         0.405                        551
                    URB                            0.777                       0.129                             0.292                         1.000                        551
                    FDI                            0.036                       0.082                           − 0.361                         0.865                        551
                    INT                            0.732                       0.206                             0.024                         0.981                        551
                    TO                             0.705                       0.514                             0.172                         3.435                        551
                    POP                            4.078                      13.440                             0.026                        79.659                        551




Data availability                                                                                         learning validation. Sustainability, 17(5), 1815. https://doi.org/10.3390/
                                                                                                          su17051815
                                                                                                     Bergougui, B., & Satrovic, E. (2025). Towards eco-efficiency of OECD countries: How
    Data will be made available on request.                                                               does environmental governance restrain the destructive ecological effect of the
                                                                                                          excess use of natural resources? Ecological Informatics, 87, Article 103093. https://
                                                                                                          doi.org/10.1016/j.ecoinf.2025.103093
References
                                                                                                     Brynjolfsson, E., & Hitt, L. M. (2000). Beyond computation: Information technology,
                                                                                                          organizational transformation and business performance. The Journal of Economic
Abbasiharofteh, M., Broekel, T., & Mewes, L. (2024). The role of geographic distance and                  Perspectives, 14(4), 23–48.
    technological complexity in U.S. Interregional Co-patenting over almost two                      Caliendo, M., & Kopeinig, S. (2008). Some practical guidance for the implementation of
    centuries. Environment & Planning A, 56(7), 2003–2022. https://doi.org/10.1177/                       propensity score matching. Journal of Economic Surveys, 22(1), 31–72.
    0308518X241255525                                                                                Cao, Q., Chi, C., & Shan, J. (2025). Can artificial intelligence technology reduce carbon
Acemoglu, D. (2002). Technical change, inequality, and the labor market. Journal of                       emissions? A global perspective. Energy Economics, 143, Article 108285. https://doi.
    Economic Literature, 40(1), 7–72.                                                                     org/10.1016/j.eneco.2025.108285
Acemoglu, D., & Autor, D. (2011). Skills, tasks and technologies: Implications for                   Carrillo, M. R. (2020). Artificial intelligence: From Ethics to law. Telecommunications
    employment and earnings. Handbook of Labor Economics, 4(PART B), 1043–1171.                           Policy, 44(6), Article 101937.
    https://doi.org/10.1016/S0169-7218(11)02410-5                                                    Chan, K. J. D., Papyshev, G., & Yarime, M. (2024). Balancing the tradeoff between
Acemoglu, D., Autor, D., Hazell, J., & Pascual, R. (2022). Artificial intelligence and jobs:              regulation and innovation for artificial intelligence: An analysis of top-down
    Evidence from online vacancies. Journal of Labor Economics, 40(S1), S293–S340.                        command and control and bottom-up self-regulatory approaches. Technology in
    https://doi.org/10.1086/718327                                                                        Society, 79, Article 102747. https://doi.org/10.1016/j.techsoc.2024.102747
Al-Jafari, M. K., & Altaee, H. H. A. (2023). The role of labor productivity in reducing              Chen, Y., & Jin, S. (2023). Artificial intelligence and carbon emissions in manufacturing
    carbon emission utilizing the method of moments quantile regression: Evidence from                    firms: The moderating role of green innovation. Processes, 11(9).
    top 40 emitter countries. International Journal of Economics and Finance, 15(3),                 Cohen, W. M., & Levinthal, D. A. (1990). Absorptive capacity: A new perspective on
    Article 1DOI.                                                                                         learning and innovation. Administrative Science Quarterly, 35(1), 128–152.
AlShebli, B., Memon, S., Evans, J., & Rahwan, T. (2023). China and the US produce more               Deng, Y., Ma, M., Zhou, N., Ma, Z., Yan, R., & Ma, X. (2024). China’s plug-in hybrid
    impactful AI research when collaborating. ArXiv Preprint ArXiv 2304.                                  electric vehicle transition: An operational carbon perspective. Energy Conversion and
Angrist, J. D., & Jörn-Steffen, P. (2009). Mostly harmless econometrics: An empiricist’s                 Management, 320, Article 119011. https://doi.org/10.1016/j.
    companion. Princeton university press.                                                                enconman.2024.119011
Autor, D. H., Levy, F., & Murnane, R. J. (2003). The skill content of recent technological           Deng, Y., Ma, M., Zhou, N., Zou, C., Ma, Z., Yan, R., & Ma, X. (2025). Provincial
    change: An empirical exploration. Quarterly Journal of Economics, 118(4),                             allocation of China’s commercial building operational carbon toward carbon
    1279–1333.                                                                                            neutrality. Applied Energy, 384, Article 125450. https://doi.org/10.1016/j.
Bergougui, B. (2025a). Industrial robots for a sustainable future: Uncovering the                         apenergy.2025.125450
    asymmetric effects of AI on ecological quality in G7 economies. Technology in Society,           Ding, T., Li, J., Shi, X., Li, X., & Chen, Y. (2023). Is artificial intelligence associated with
    83, 103021. https://doi.org/10.1016/j.techsoc.2025.103021                                             carbon emissions reduction? Case of China. Resources Policy, 85, Article 103892.
Bergougui, B. (2025b). Can artificial intelligence mitigate environmental inequality?                     https://doi.org/10.1016/j.resourpol.2023.103892
    Evidence from leading robotic-driven economies using quantile-based methods.                     Doğan, B., Tiwari, S., Bergougui, B., Ghosh, S., & Balsalobre-Lorente, D. (2025). Green
    Borsa Istanbul Review. doi:10.1016/j.bir.2025.07.012.                                                 innovation and fiscal spending: Decoding the path to sustainable development.
Bergougui, B., Ben-Salha, O., & Murshed, S. M. (2025). How income inequality drives                       Sustainable Development. https://doi.org/10.1002/sd.3464. n/a(n/a).
    climate inequality in the world’s largest emitting nations: Novel evidence from                  Dong, M., Wang, G., & Han, X. (2023). Artificial intelligence, industrial structure
    multivariate quantile-on-quantile and wavelet quantile methods. Journal of Cleaner                    optimization, and CO2 emissions. Environmental Science and Pollution Research, 30
    Production, 145666. https://doi.org/10.1016/j.jclepro.2025.145666                                     (50), 108757–108773. https://doi.org/10.1007/s11356-023-29859-x
Bergougui, B., & Said, M. (2025). Assessing the impact of green energy transition,                   El jaouhari, A., Samadhiya, A., Kumar, A., & Luthra, S. (2025). Integrating generative
    technological innovation, and natural resources on load capacity factor in Algeria:                   artificial intelligence into green logistics: A systematic review and policy-oriented
    Evidence from dynamic autoregressive distributed lag simulations and machine                          research agenda. Journal of Cleaner Production, 519, Article 146018. https://doi.org/
                                                                                                          10.1016/j.jclepro.2025.146018


                                                                                                17
B. Bergougui                                                                                                                                               Technology in Society 83 (2025) 103029

Feng, F., Li, J., Zhang, F., & Sun, J. (2024). The impact of artificial intelligence on green          Pimenow, S., Pimenowa, O., & Prus, P. (2024). Challenges of artificial intelligence
     innovation efficiency: Moderating role of dynamic capability. International Review of                 development in the context of energy consumption and impact on climate change.
     Economics & Finance, 96. https://doi.org/10.1016/j.iref.2024.103649                                   Energies, 17(23).
Ganguli, I., Lin, J., & Reynolds, N. (2020). The paper trail of knowledge spillovers:                  Porter, M. E., & Claas van der, L. (1995). Toward a new conception of the environment-
     Evidence from patent interferences. American Economic Journal: Applied Economics,                     competitiveness relationship. The Journal of Economic Perspectives, 9(4), 97–118.
     12(2), 278–302. https://doi.org/10.1257/app.20180017                                                  https://doi.org/10.1257/jep.9.4.97
Godil, D. I., Zhang, Y., Sharif, A., Usman, R., & Khan, S. A. R. (2021). Investigate the role          Qi, J., Tan, Y., & Zhang, Z. (2024). The influence of industrial robots on firm-level
     of technology innovation and renewable energy in reducing transport sector CO2                        pollution emissions: Evidence from China. Economic Modelling, 133, Article 106686.
     emission in China: A path toward sustainable development. Sustainable Development,                    https://doi.org/10.1016/j.econmod.2024.106686
     29(4), 694–707. https://doi.org/10.1002/sd.2167                                                   Qian, Y., Siau, K. L., & Nah, F. F. (2024). Societal impacts of artificial intelligence:
Goertzel, B. (2014). Artificial general intelligence: Concept, state of the art, and future                Ethical, legal, and governance issues. In Societal impacts, 3, Article 100040. https://
     prospects. Journal of Artificial General Intelligence, 5(1), 1.                                       doi.org/10.1016/j.socimp.2024.100040
Grant, R. M. (1996). Toward a knowledge-based theory of the firm. Strategic Management                 Rogers, E. M. (1964). Diffusion of innovations.
     Journal, 17(S2), 109–122.                                                                         Schumpeter, J. A., & Opie, R. (1934). The theory of economic development: An inquiry into
Gruetzemacher, R., Dorner, F. E., Bernaola-Alvarez, N., Giattino, C., & Manheim, D.                        profits, capital, credit, interest, and the business cycle. Harvard University Press.
     (2021). Forecasting AI progress: A research agenda. Technological Forecasting and                 Shadi, M. R., Mirshekali, H., & Hamid, R. S. (2025). Explainable artificial intelligence for
     Social Change, 170, Article 120909. https://doi.org/10.1016/j.                                        energy systems maintenance: A review on concepts, current techniques, challenges,
     techfore.2021.120909                                                                                  and prospects. Renewable and Sustainable Energy Reviews, 216, Article 115668.
Hao, K. (2019). Training a single AI model can emit as much carbon as five cars in their                   https://doi.org/10.1016/j.rser.2025.115668
     lifetimes. MIT Technology Review, 75, 103.                                                        Shang, Y., Yang, Q., Pu, Y., & Taghizadeh-Hesary, F. (2024). Employing artificial
Hötte, K., Somers, M., & Theodorakopoulos, A. (2023). Technology and jobs: A                              intelligence and enhancing resource efficiency to achieve carbon neutrality.
     systematic literature review. Technological Forecasting and Social Change, 194, Article               Resources Policy, 88, Article 104510. https://doi.org/10.1016/j.
     122750. https://doi.org/10.1016/j.techfore.2023.122750                                                resourpol.2023.104510
Hu, Z., Cao, Z., Du, A., & Qin, T. (2025). Where does it matter? Revisiting the role of                Smuha, N. A. (2021). From a ‘race to AI’ to a ‘race to AI regulation’: Regulatory
     proximity in knowledge spillovers. The American Journal of Economics and Sociology,                   competition for artificial intelligence. Law, Innovation and Technology, 13(1), 57–84.
     84(2), 297–322. https://doi.org/10.1111/ajes.12604                                                    https://doi.org/10.1080/17579961.2021.1898300
Hussain, M., Yang, S., Maqsood, U. S., & Ammar Zahid, R. M. (2024). Tapping into the                   Song, M., Pan, H., Shen, Z., & Tamayo-Verleene, K. (2024). Assessing the influence of
     green potential: The power of artificial intelligence adoption in corporate green                     artificial intelligence on the energy efficiency for sustainable ecological products
     innovation drive. Business Strategy and the Environment, 33(5), 4375–4396.                            value. Energy Economics, 131. https://doi.org/10.1016/j.eneco.2024.107392
IEA. 2023. “International Energy Agency.”.                                                             Tang, X., Li, X., & Ma, F. (2022). Internationalizing AI: Evolution and impact of distance
IEA. (2024). Electricity 2024: Analysis and forecast to 2026. IEA Publications.                            factors. Scientometrics, 127(1), 181–205.
IEA. (2025). Energy and AI.                                                                            Teece, D. J. (2018). Profiting from innovation in the digital economy: Enabling
Jaffe, A. B., Newell, R. G., & Stavins, R. N. (2002). Environmental policy and                             technologies, standards, and licensing models in the wireless world. Research Policy,
     technological change. Environmental and Resource Economics, 22(1), 41–70. https://                    47(8), 1367–1387.
     doi.org/10.1023/A:1015519401088                                                                   Traverso, S., Vatiero, M., & Zaninotto, E. (2023). Robots and labor regulation: A cross-
Jiao, A., Lu, J., Ren, H., & Jia, W. (2024). The role of AI capabilities in environmental                  country/cross-industry analysis. Economics of Innovation and New Technology, 32(7),
     management: Evidence from USA firms. Energy Economics, 134, Article 107653.                           977–999. https://doi.org/10.1080/10438599.2022.2063122
     https://doi.org/10.1016/j.eneco.2024.107653                                                       Wang, Q., Li, Y., & Li, R. (2023). Do industrial robots reduce carbon intensity? The role of
Kucharska, W., & Scott Erickson, G. (2023). Tacit knowledge acquisition & sharing, and                     natural resource rents and corruption control. Environmental Science and Pollution
     its influence on innovations: A polish/US cross-country study. International Journal of               Research, 30(49), 107549–107567. https://doi.org/10.1007/s11356-023-29760-7
     Information Management, 71, Article 102647. https://doi.org/10.1016/j.                            Wang, Q., Li, Y., & Li, R. (2024). Ecological footprints, carbon emissions, and energy
     ijinfomgt.2023.102647                                                                                 transitions: The impact of artificial intelligence (AI). Humanities and Social Sciences
Kwon, H.-S., Jihong, L., Sokbae, L., Ryungha, & Oh. (2022). Knowledge spillovers and                       Communications, 11(1), 1–18.
     patent citations: Trends in geographic localization, 1976–2015. Economics of                      Wang, T., Ma, M., Zhou, N., & Ma, Z. (2025). Toward net zero: Assessing the
     Innovation and New Technology, 31(3), 123–147. https://doi.org/10.1080/                               decarbonization impact of global commercial building electrification. Applied Energy,
     10438599.2020.1787001                                                                                 383, Article 125287. https://doi.org/10.1016/j.apenergy.2025.125287
Leal Filho, W., Mbah, M. F., Dinis, M. A. P., Trevisan, L. V., Lange, D.de, Mishra, A.,                Wang, Q., Zhang, F., Li, R., & Sun, J. (2024). Does artificial intelligence promote energy
     Rebelatto, B., Hassen, T. B., & Aina, Y. A. (2024). The role of artificial intelligence in            transition and curb carbon emissions? The role of trade openness. Journal of Cleaner
     the implementation of the UN sustainable development goal 11: Fostering                               Production, 447, Article 141298. https://doi.org/10.1016/j.jclepro.2024.141298
     sustainable cities and communities. Cities, 150, Article 105021. https://doi.org/                 Wang, Y., Zhao, W., & Ma, X. (2024). The spatial spillover impact of artificial intelligence
     10.1016/j.cities.2024.105021                                                                          on energy efficiency: Empirical evidence from 278 Chinese cities. Energy, 312.
Lee, C.-C. C., Qin, S., & Li, Y. (2022). Does industrial robot application promote green                   https://doi.org/10.1016/j.energy.2024.133497
     technology innovation in the manufacturing industry? Technological Forecasting and                Yan, R., Zhou, N., Ma, M., & Mao, C. (2025). India’s residential space cooling transition:
     Social Change, 183, Article 121893. https://doi.org/10.1016/j.                                        Decarbonization ambitions since the turn of millennium. Applied Energy, 391, Article
     techfore.2022.121893                                                                                  125929. https://doi.org/10.1016/j.apenergy.2025.125929
Lin, B., & Xu, C. (2024). The effects of industrial robots on firm energy intensity: From              Yu, L., Wang, Y., Wei, X., & Zeng, C. (2023). Towards low-carbon development: The role
     the perspective of technological innovation and electrification. Technological                        of industrial robots in decarbonization in Chinese cities. Journal of Environmental
     Forecasting and Social Change, 203, Article 123373. https://doi.org/10.1016/j.                        Management, 330, Article 117216. https://doi.org/10.1016/j.jenvman.2023.117216
     techfore.2024.123373                                                                              Zhang, H., Ding, Y., Niu, J., & Jung, S. (2024). How artificial intelligence affects
Liu, J., Liu, L., Qian, Y., & Song, S. (2022). The effect of artificial intelligence on carbon             international industrial transfer — evidence from industrial robot application.
     intensity: Evidence from China’s industrial sector. Socio-Economic Planning Sciences,                 Journal of Asian Economics, 95, Article 101815. https://doi.org/10.1016/j.
     83, Article 101002. https://doi.org/10.1016/j.seps.2020.101002                                        asieco.2024.101815
Ma, M., Zhou, N., Feng, W., & Yan, J. (2024). Challenges and opportunities in the global               Zhang, Y. J., Lu Peng, Y., Ma, C. Q., & Shen, B. (2017). Can environmental innovation
     net-zero building sector. Cell Reports Sustainability, 1(8). https://doi.org/10.1016/j.               facilitate carbon emissions reduction? Evidence from China. Energy Policy, 100,
     crsus.2024.100154                                                                                     18–28. https://doi.org/10.1016/j.enpol.2016.10.005
Machin, S. (2008). An appraisal of economic research on changes in wage inequality.                    Zhao, Z., Li, Z., Tong, R., Gu, T., & Fang, D. (2025). Unveiling the spatial heterogeneity of
     Labour, 22(SUPPL. 1), 7–26. https://doi.org/10.1111/J.1467-9914.2008.00421.X                          factors influencing physical and perceived recovery disparities under extreme
Mhlanga, D. (2023). Artificial intelligence and machine learning for energy consumption                    rainstorms: A geographically weighted machine learning approach. Sustainable Cities
     and production in emerging markets: A review. Energies, 16(2). https://doi.org/                       and Society, 118, Article 106023. https://doi.org/10.1016/j.scs.2024.106023
     10.3390/EN16020745                                                                                Zheng, P., & Slaper, T. (2016). University knowledge spillovers, geographic proximity
Miller, T. (2019). Explanation in artificial intelligence: Insights from the social sciences.              and innovation: An analysis of patent filings across U.S. Counties. SSRN Electronic
     Artificial Intelligence, 267, 1–38. https://doi.org/10.1016/j.artint.2018.07.007                      Journal. https://doi.org/10.2139/ssrn.2857130
Müller, C., & Bill, M. (2023). World robotics 2023.                                                    Zhong, J., Zhong, Y., Han, M., Yang, T., & Zhang, Q. (2024). The impact of AI on carbon
Nahar, S. (2024). Modeling the effects of artificial intelligence (AI)-Based innovation on                 emissions: Evidence from 66 countries. Applied Economics, 56(25), 2975–2989.
     sustainable development goals (SDGs): Applying a system dynamics perspective in a                     https://doi.org/10.1080/00036846.2023.2203461
     cross-country setting. Technological Forecasting and Social Change, 201, Article                  Zhou, H., Wang, L., Cao, Y., & Li, J. (2025). The impact of artificial intelligence on labor
     123203. https://doi.org/10.1016/j.techfore.2023.123203                                                market: A study based on bibliometric analysis. Journal of Asian Economics, 98,
Oster, E. (2019). Unobservable selection and coefficient stability: Theory and evidence.                   Article 101926. https://doi.org/10.1016/j.asieco.2025.101926
     Journal of Business & Economic Statistics, 37(2), 187–204. https://doi.org/10.1080/               Zhou, W., Zhang, Y., & Li, X. (2024). Artificial intelligence, green technological progress,
     07350015.2016.1227711                                                                                 energy conservation, and carbon emission reduction in China: An examination based
Papagiannidis, E., Mikalef, P., & Conboy, K. (2025). Responsible artificial intelligence                   on dynamic spatial durbin modeling. Journal of Cleaner Production, 446, Article
     governance: A review and research framework. The Journal of Strategic Information                     141142. https://doi.org/10.1016/j.jclepro.2024.141142
     Systems, 34(2), Article 101885. https://doi.org/10.1016/j.jsis.2024.101885                        Zhou, W., Zhuang, Y., & Chen, Y. (2024). How does artificial intelligence affect pollutant
                                                                                                           emissions by improving energy efficiency and developing green technology. Energy
                                                                                                           Economics, 131, Article 107355. https://doi.org/10.1016/j.eneco.2024.107355




                                                                                                  18
