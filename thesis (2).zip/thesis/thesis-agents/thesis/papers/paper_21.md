Sustainable Development




   RESEARCH ARTICLE                     OPEN ACCESS




Climate Change and Energy Security Risk: Do Green
Patents, Institutional Quality, and Human Capital Make
a Difference?
Mohamed Sami Ben Ali                | Alanoud Al-Maadid | Brahim Bergougui

College of Business & Economics, Qatar University, Doha, Qatar

Correspondence: Mohamed Sami Ben Ali (msbenali@qu.edu.qa)

Received: 10 July 2025 | Revised: 3 September 2025 | Accepted: 9 September 2025

Funding: This work was supported by Qatar Research Development and Innovation Council, ARG01-­0508-­230093.

Keywords: climate change | energy security risk | green patents | human capital | institutional quality


  ABSTRACT
  Climate change poses a significant threat to global energy security, yet the mechanisms through which this relationship un-
  folds—and the factors that buffer their adverse impacts—remain underexplored. This study examines the link between climate
  change, proxied by CO2 emissions, and energy security risk (ESR), with a particular focus on the mediating roles of green patent,
  institutional quality, and human capital. Utilizing a newly compiled historical dataset encompassing ESR and climate indicators,
  and applying a suite of robust empirical strategies—including sensitivity tests, alternative variable specifications, and instru-
  mental variable techniques—we provide compelling evidence that rising CO2 emissions substantially elevate ESR across GCC
  countries between 1990 and 2023. Importantly, we find that the interaction between climate change and the tripartite mediating
  factors reduces ESR significantly. Additionally, the study establishes threshold levels for these mitigating factors, beyond which
  they effectively transform energy insecurity into energy security. Moreover, the efficacy of these mitigating effects appears to be
  conditioned by macroeconomic and demographic factors, manifesting more strongly in contexts characterized by higher levels of
  economic development and stable population dynamics. To enhance the buffering capacity of these factors, policy efforts should
  prioritize the development of resilient energy systems, demographic sustainability, and stringent environmental governance.
  These findings offer timely and actionable insights for GCC countries and other fossil fuel-­dependent economies striving to align
  energy security objectives with long-­term climate resilience.


1   |   Introduction                                                                worldwide (Al-­Maadid, Ben Ali, and Younis 2025; Ben Ali and
                                                                                    Al-­Maadid 2025). Such events challenge the reliability of en-
In recent decades, the critical importance of understanding the                     ergy systems, which are fundamental to economic activities,
direct impact of climate change on energy security risk (ESR)                       emphasizing the significance of integrating climate resilience
has come to the fore amid growing public policy concerns                            into energy security planning. Energy is a cornerstone of mod-
(Bashir et al. 2025; Bergougui et al. 2025; Rahman et al. 2025).                    ern economies, driving nearly every facet of societal function
The rapid escalation of climate-­related disasters—including                        from industrial production to personal well-­being (Mininni
extreme temperature variations, severe precipitation events,                        et al. 2024; Zhang et al. 2023). When climate change-­related
intense wind gusts, and prolonged droughts—has not only led                         disasters disrupt energy systems—through direct physical
to tragic losses of life and widespread social disruption but                       damages to infrastructure or by destabilizing market con-
has also inflicted substantial damage on energy infrastructure                      ditions—the resultant energy insecurity can ripple through


This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium,
provided the original work is properly cited.
© 2025 The Author(s). Sustainable Development published by ERP Environment and John Wiley & Sons Ltd.


Sustainable Development, 2025; 0:1–25                                                                                                                         1
https://doi.org/10.1002/sd.70244
                                                                                                                                                10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
economies, exacerbating social inequalities and impairing            by reducing carbon emissions and diversifying energy sources
growth (Salisu et al. 2025). Notably, the recent geopolitical        (X. Chen et al. 2021; Lim and Kim 2012). Conversely, reliance
crises such as the Russia–Ukraine war and COVID-­19 epi-             on dirty energy sources not only perpetuates vulnerability but
demic have further underscored the fragility of global energy        also accelerates the rate of global climatic shifts, thereby creat-
supplies, with household energy costs nearly doubling in some        ing a vicious cycle of increasing energy insecurity (Gentile and
regions (Kim et al. 2025). This heightened uncertainty spot-         Gupta 2025; Mares and Moffett 2016).
lights the urgent need for countries to focus on sustainable
alternatives and robust policy mechanisms that mitigate these        Within the Gulf Cooperation Council (GCC) region, the stakes
vulnerabilities.                                                     are particularly high. The economies of these countries are deeply
                                                                     intertwined with energy production and exportation, making
Historically, climate change has been intricately linked with        them exceptionally susceptible to the risks associated with climate
a range of adverse outcomes: from economic disruptions and           change. Recent policy interventions have aimed to accelerate the
reduced labor productivity to environmental degradation and          shift toward cleaner energy—Europe alone has committed more
conflicts over natural resources. Scholarly work over the past       than $763 billion to support the transition—yet fossil fuel depen-
decades—from studies by Crowley (2000) and Tol (2002) to more        dencies persist.1 However, the GCC region faces unique challenges
recent analyses by Hegerl et al. (2019), Loucks (2021), and Neale    due to its heavy reliance on fossil fuels, limited diversification in
et al. (2025)—has delineated how carbon emissions, which un-         its energy mix, and the pressing need to balance short-­term en-
derlie climate change, accelerate the deterioration of the ozone     ergy security with long-­term sustainability goals. Effective policy
la1yer and trigger extreme weather events. These phenomena,          interventions in the region must therefore draw on both global best
in turn, disrupt energy supply chains and jeopardize the af-         practices and localized strategies, integrating advanced green pat-
fordability and accessibility of energy. Moreover, research has      ents, strong institutional support, and the development of human
pointed to the critical roles of green energy and energy storage     capital to build a more resilient energy infrastructure.
innovations in curbing carbon emissions and ensuring a more
resilient energy supply in the face of disruptive climate events     This study is designed with several key objectives in mind:
(Mideksa and Kallbekken 2010).
                                                                       • To quantify the direct impact of climate change on over-
Despite growing consensus on the dangers posed by climate                all ESR by analyzing CO2 emissions and extreme weather
change, there is a notable gap in our empirical understanding            events.
of how climate change directly influences overall ESR. While
previous studies have examined specific components—such                • To examine the mitigating role of green patents, institu-
as the impact on electricity production or energy expenditures           tional quality, and human capital in reducing ESR.
(Bui et al. 2024; Campagnolo and De Cian 2022)—a holistic              • To compare the efficacy of these mitigating factors in GCC
analysis that encompasses both the direct and indirect effects           economies of varying sizes, particularly contrasting the ex-
of climate-­induced disasters on energy systems has been elusive.        periences of higher GDP countries with those in the lower
Furthermore, the policy response, largely focused on adjust-             half.
ing energy portfolios by balancing fossil fuels with alternative
energy sources, often overlooks the potent role of institutional       • To provide tailored policy recommendations that address
frameworks, green patents, and human capital in mediating                both global trends and regional specifics, with a special
these risks.                                                             focus on the GCC region.

Current literature tends to explore the trade-­offs between renew-   The primary aim of this research is to bridge the empirical gap in
able and non-­renewable energy policies without fully address-       understanding the direct nexus between climate change and ESR.
ing how innovations in green technology, supported by robust         Through developing a robust theoretical framework and employ-
institutions and skilled human capital, might attenuate the ad-      ing comprehensive empirical analyses, this study demonstrates
verse impacts of climate change on energy security. Although         that while climate change exacerbates energy insecurity—partic-
exploratory studies (Bazilian et al. 2011; Ha 2025; King and         ularly in lower GDP economies—strategic enhancement of clean
Gulledge 2014; Vrochidis and Chalaris 2023) have shed light on       innovation, coupled with strong institutional support and human
certain facets of the climate–energy nexus, the empirical evi-       capital development, can significantly counterbalance these ad-
dence remains fragmented. There is a clear need for rigorous,        verse effects. Our work contributes both to the broader scholarly
comprehensive research that not only quantifies direct relation-     discourse on climate change impacts and offers practical policy
ships but also elucidates how targeted policy interventions can      guidance for fostering sustainable and resilient energy systems at
reduce ESR through enhanced technological and institutional          global and regional scales.
capacities.
                                                                     Our study makes four distinct contributions to the literature:
A growing body of research underscores the link between cli-
mate change and ESR. For example, extreme weather events               • Comprehensive ESR measurement framework: Our anal-
driven by climate change have been linked to significant inter-          ysis uses annual data from multiple integrated databases.
ruptions in energy production and distribution (Kahn et al. 2021;        Core energy security data comes from the Global Energy
X. Wang et al. 2012). Policy studies have also demonstrated              Institute's comprehensive international risk index, which
that investments in green energy, such as green patents and              assesses energy security across four key dimensions: eco-
sustainable infrastructure, can mitigate some of these impacts           nomic stability, geopolitical issues, environmental impact,

2                                                                                                               Sustainable Development, 2025
                                                                                                                                          10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
    and system reliability. These components include 29 dif-        uninterrupted access to reliable to energy—is increasingly
    ferent metrics covering power generation capacity, supply       jeopardized by the impacts of climate change. Rising global
    chain resilience, operational efficiency, consumption pat-      temperatures have intensified cooling demands in residential,
    terns, and emission levels.                                     commercial, and industrial sectors, placing unprecedented
                                                                    strain on energy grids during peak periods (Mideksa and
  • Holistic climate impact assessment: We create a compre-
                                                                    Kallbekken 2010). This heightened demand has already led to
    hensive climate metric including: CO2 emissions (million
                                                                    grid failures in regions experiencing extreme heatwaves, with
    tonnes), extreme temperature events, extreme precipita-
                                                                    cascading effects on critical services and economic activity.
    tion patterns, extreme wind conditions, and prolonged
                                                                    Additionally, the growing frequency and severity of extreme
    drought periods. This multidimensional approach cap-
                                                                    weather events—such as floods, hurricanes, droughts, and
    tures the full range of climate-­related threats to energy
                                                                    wildfires—pose direct threats to energy infrastructure, in-
    security.
                                                                    cluding transmission lines, power plants, and distribution net-
  • Mechanistic pathway analysis: Beyond establishing empiri-       works, resulting in prolonged supply disruptions that can last
    cal links between climate change and ESR, we identify and       for weeks or months (Ramião et al. 2023). The environmental
    examine three main transmission channels: green patent          economics literature further emphasizes that the effectiveness
    innovation, institutional quality, and human capital devel-     of different energy sources in achieving carbon neutrality var-
    opment. This mechanistic approach offers insights into spe-     ies considerably across countries and contexts. Research on
    cific policy intervention points.                               major nuclear power nations reveals that while nuclear energy
                                                                    can reduce carbon emissions in some countries like Russia,
  • Contextual heterogeneity analysis: We investigate system-       renewable sources such as solar and wind power show dif-
    atic differences by income level (high-­income versus lower-­   ferential impacts depending on national circumstances and
    income economies) and population size (large versus small       implementation strategies (Kartal et al. 2023). These findings
    populations), providing a detailed understanding of how         underscore the complexity of energy transition policies and
    climate-­energy security relationships differ across varied     highlight the need for country-­specific approaches to achiev-
    economic and demographic settings.                              ing both energy security and environmental sustainability
                                                                    (Ugur Korkut Pata and Hizarci 2022; U. K. Pata et al. 2025).
The structure of the paper is organized as follows: In Section 2,
the theoretical foundation is introduced along with the formu-      Hypothesis 1. Climate change positively affects energy secu-
lation of research hypotheses. Section 3 focuses on the data-       rity risks.
set and establishes a simplified model that connects climate
change, moderating factors, and energy security. Section 4          Compounding these challenges, climate change has accelerated
showcases the findings and delves into their interpreta-            the global transition from fossil fuels to cleaner energy sources
tion, while Section 5 offers additional examination. Finally,       (Hrnčić et al. 2021). While this shift is essential for long-­term
Section 6 wraps up with a summary of policy insights drawn          sustainability, it introduces new vulnerabilities, such as the high
from the research outcomes.                                         upfront costs of renewable technologies, intermittency issues
                                                                    with wind and solar generation, and reliability concerns during
                                                                    the early adoption phases (Ciarreta et al. 2014). Recent geopo-
2   |   Theoretical Mechanism and Research                          litical events, such as the Russia-­U kraine war, have further ex-
Hypotheses                                                          posed vulnerabilities in global energy markets, underscoring the
                                                                    urgent need for resilient and diversified energy systems (Z. Liu
2.1   |   Climate Change and Energy Security:                       et al. 2025).
Theoretical Foundations

The climate change–energy security risks nexus is intricate         2.2   |   Moderating Mechanisms in
and multifaceted, with green patents, institutional quality,        the Climate–ESR Nexus
and human capital emerging as pivotal mechanisms to miti-
gate these risks. The environmental economics literature has        Building on the resource-­based view and institutional the-
extensively examined the complex relationships between cli-         ory, we propose that the relationship between climate change
mate variables, technological innovation, and energy systems,       (measured by CO2 emissions) and ESR is contingent upon
providing crucial insights into how environmental degrada-          three critical moderating factors: green patents, institutional
tion and energy security intersect (Caglar et al. 2023; Pata,       quality, and human capital. These variables do not operate in
Kartal, et al. 2023). Studies have demonstrated that informa-       isolation but form an interconnected system of capabilities
tion and communication technologies (ICT) can effectively           and governance structures that collectively determine a na-
mitigate environmental degradation across technologically           tion's resilience to climate-­energy challenges. The theoretical
advanced nations, while the role of renewable energy tech-          foundation rests on the premise that climate change creates
nologies in emissions reduction remains contested (U. K. Pata       external pressures on energy systems, but the magnitude of
and Yurtkuran 2022). Furthermore, research on environmen-           resulting energy security risks depends on internal adaptive
tal regulations reveals their critical importance in promoting      capacities. Green patents represent technological capabili-
sustainability, though their effectiveness varies significantly     ties, institutional quality reflects governance capabilities, and
across different economic contexts and policy frameworks            human capital embodies knowledge capabilities. These three
(Caglar et al. 2023). Energy security—defined as affordable,        dimensions work synergistically: technological solutions

                                                                                                                                     3
                                                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
require institutional support for deployment and skilled                     reliant on fossil fuel exports (Albahouth and Tahir 2025;
human resources for development and implementation, while                    Cai et al. 2025).
strong institutions facilitate both innovation and human cap-
                                                                           • Second, risk management governance directly addresses
ital development.
                                                                             ESR by implementing disaster preparedness measures, en-
                                                                             forcing stricter standards for infrastructure resilience, and
2.2.1   |   Green Patents as Technological Moderator                         developing comprehensive emergency response capabili-
                                                                             ties. Better-­governed countries maintain energy security
Green patents play a pivotal role in alleviating the link between            during extreme weather events due to their ability to antici-
carbon dioxide emissions and energy security concerns through                pate disruptions and respond effectively (OECD 2019).
technological pathway moderation. They foster technological
                                                                           • Third, investment governance fosters predictable envi-
advancements designed to tackle the fundamental causes of
                                                                             ronments that attract long-­term investments in renewable
climate change while improving the resilience and sustainabil-
                                                                             energy infrastructure and grid modernization. By creating
ity of energy systems (Abbas et al. 2024). Green patents operate
                                                                             stable regulatory frameworks and transparent processes,
through two complementary channels.
                                                                             strong institutions reduce uncertainties for investors, en-
                                                                             abling the deployment of innovative solutions that enhance
    • First, they enable emission-­reduction pathways by foster-
                                                                             energy security (Giganti et al. 2025).
      ing the improvement of low-­carbon technologies—such as
      wind turbines, energy-­efficient appliances, energy storage
                                                                         Institutional quality amplifies the effectiveness of both green
      systems, and solar panels—that directly reduce CO2 emis-
                                                                         patents and human capital by providing the governance infra-
      sions. By transitioning away from fossil fuels, these inno-
                                                                         structure necessary for their optimal utilization.
      vations decelerate climate change, reducing the intensity
      of severe weather phenomena that pose risks to energy sys-
                                                                         Hypothesis 3. Higher institutional quality weakens the posi-
      tems (Acemoglu et al. 2016; Bergougui 2024b).
                                                                         tive climate change–energy security risk nexus.
    • Second, they enhance system resilience by contributing to
      building resilient energy systems capable of withstanding
      climate-­related stresses. For example, patented advance-          2.3   |   Human Capital as Knowledge Moderator
      ments in flood-­  resistant power grid designs, hurricane-­
      resistant wind turbines, and smart grid technologies               Human capital—the collective knowledge, skills, and adaptive
      enhance system flexibility and responsiveness, reducing            capabilities of individuals—plays a central role in addressing the
      vulnerability to extreme weather events. Innovations in en-        interlinked challenges through knowledge pathway moderation
      ergy storage address intermittency issues associated with          (Lenihan et al. 2019). Human capital operates through three
      renewable energy sources, improving reliability and ad-            complementary mechanisms.
      dressing key energy security concerns during the transition
      phase (Iyke 2024).                                                   • First, technological implementation capacity ensures that
                                                                             skilled workforces can advance technological innovation,
The effectiveness of green patents in moderating the climate–                deploy green energy solutions, and adapt to climate-­driven
ESR nexus depends on their interaction with institutional and                disruptions (Arcelay et al. 2021). Professionals such as engi-
human capital factors, as patents require supportive policy envi-            neers, scientists, and technicians are critical for designing,
ronments and skilled implementation.                                         operating, and maintaining renewable energy infrastruc-
                                                                             ture and smart grids that can withstand climate stresses
Hypothesis 2. Green patents significantly moderate the posi-                 (International Renewable Energy Agency 2022).
tive climate change–energy security risk nexus.
                                                                           • Second, adaptive capacity enhancement enables societ-
                                                                             ies to respond dynamically to climate-­related disruptions.
                                                                             Workers with problem-­solving abilities can devise emer-
2.2.2   |   Institutional Quality as Governance Moderator
                                                                             gency protocols, optimize resource allocation during crises,
                                                                             and manage renewable energy variability (Worku 2022).
Institutional quality plays a pivotal role in shaping the relationship
between CO2 emissions and ESR through governance pathway                   • Third, governance capacity building strengthens policy-­
moderation, establishing the frameworks, regulatory stability, and           making and advocacy efforts. Knowledgeable policymakers
policy environments essential for effective climate action and en-           and informed publics drive forward-­looking energy policies
ergy system adaptation (Nilsson 2011). Strong institutions operate           and ensure transitions align with resilience goals (Dehghan
through three interconnected channels.                                       Shabani 2024; Yao et al. 2020).

    • First, emission governance reduces CO2 emissions through           Human capital effectiveness is enhanced when combined with
      the implementation of robust policies, enforcement of              green technological solutions and strong institutional frame-
      higher environmental standards, and promotion of clean             works, creating synergistic effects.
      energy investments. Studies demonstrate that improve-
      ments in institutional quality lead to measurable reductions       Hypothesis 4. Higher levels of human capital reduce the pos-
      in emissions across various economies, particularly those          itive climate change–energy security risk nexus.



4                                                                                                                 Sustainable Development, 2025
                                                                                                                                                 10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 1    |    Analytical framework.


Incorporating these mechanism analyses, Figure 1 illustrates          variables in the study. The average ESR is 1356, with a maximum
this comprehensive framework of transmission channels link-           value of 1858, reflecting severe energy insecurity in nations such
ing climate change (measured by CO2 emissions) to ESR. It             as Qatar, Kuwait, and Saudi Arabia. These elevated ESR values in-
highlights how green patents, institutional quality, and human        dicate systemic vulnerabilities in energy systems across the sam-
capital serve as critical intervention points, transforming cli-      ple. Meanwhile, CO2 emissions average 11.5 million metric tons
mate challenges into opportunities for enhanced energy re-            (Mt), with peaks reaching 62.3 million Mt. Such high emission
silience. By strengthening these mechanisms, societies can            levels risk accelerating climate change, which could further de-
navigate the interplay between climate change and ESR, ensur-         stabilize energy security by intensifying resource scarcity and in-
ing reliable, affordable, and sustainable energy access in a rap-     frastructure disruptions. To address these intertwined challenges,
idly changing world.                                                  our empirical analysis evaluates the effect of climate change on
                                                                      energy security and highlights the critical role of green patents,
                                                                      strong institutions, and human capital as effective policy tools.
3   |   Data and Econometric Strategy
                                                                      To facilitate interpretation and meet modeling assumptions, all
3.1   |   Data                                                        variables are log-­linearized so coefficients can be read as elas-
                                                                      ticities. Variables that include zero values are transformed using
Our analysis employs yearly measurements drawn from multiple          log(x + 1), ensuring that observations with zero values remain in
databases. The core energy security data come from the Global         the sample without producing undefined log terms.
Energy Institute, which maintains a comprehensive interna-
tional risk index. This index evaluates energy security through
four critical dimensions: economic stability, geopolitical factors,   3.2   |   Model
environmental impact, and system reliability. These components
integrate 29 distinct metrics, encompassing aspects like power        We propose a practical framework to study how climate change
generation capacity, supply chains, operational efficiency, con-      and other factors influence ESR over time. The model is struc-
sumption patterns, and emission levels. To facilitate meaningful      tured as:
cross-­country comparisons, the institute standardized all 29 met-
rics by setting 1980 as the baseline year with a value of 1000.              ln ESRit = 𝛽 0 + 𝛽 1 ln CCit + 𝛽 2 ln GDPit + 𝛽 3 ln TNRRit
Subsequent years' measurements are calibrated proportionally
                                                                                         + 𝛽 4 ln TOit + 𝛽 5 ln REit + 𝛽 6 ln INDSit       (1)
against this reference point. A higher index score indicates ele-
vated ESR and reduced overall security.                                                  + 𝛽 6 ln POPit + 𝛿 i + 𝛾 t + 𝜀it

For compatibility with our climate analysis, we transformed the       In this model, ESR denotes the energy security risk for country
annual energy security data into monthly intervals.2 The climate      i at time t. The coefficients 𝛽 1 to 𝛽 6 capture the elasticity of ESR
dataset incorporates various indicators discussed in academic re-     with respect to each independent variable; for example, β₁ quan-
search (Ben Ali et al. 2025; Chen et al. 2021; Gortan et al. 2024)    tifies the percentage change in ESR resulting from a 1% increase
such as carbon dioxide output and extreme climate events (Al-­        in CC. This specification allows for an accurate evaluation of
Maadid, Ben Ali, and Si Mohammed 2025; Iyke 2024). This cli-          the impact of CC on ESR while holding other factors constant.
mate information covers six GCC countries from 1990 through           Additionally, δ i and γ t account for unobserved heterogeneity
2023. We enriched this combined dataset with contextual eco-          specific to each country and time period, respectively, and ε rep-
nomic indicators that prior research has linked to energy security    resents the stochastic error term.
concerns. These include measures of economic development,
foreign direct investment flows, international trade, and natural     In our analysis, we primarily assess climate change through
resource revenues. These factors provide crucial context about        the lens of CO2 emissions, selected for their direct association
energy accessibility, cost dynamics, usage patterns, and potential    with the core mechanisms driving climate change, their reflec-
vulnerabilities (Ahmadov and van der Borg 2019; Morikawa 2012;        tion of anthropogenic activity, their measurable and compara-
Sadorsky 2011). Table 1 presents descriptive statistics for the       ble nature across temporal and spatial dimensions, and their

                                                                                                                                            5
                                                                                                                                                               10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 1    |    Summary statistics.

    Variable                      Definition                          Source                Mean           Std. dev.           Min             Max
    Dependent variable
     ESR                   Energy Security Risk                     GEI (2025)             1356.403        196.2002         755.0384         1858.118
    Climate variables
     CO2              CO2 emissions (million tons)                  WDI (2025)             1.15E+07        1.40E+07         866838.6        6.23E+07
     TEM                  Extreme Temperatures                 Gortan et al. (2024)          4.032           2.206            0.000            8.552
     PRE                    Extreme Perception                 Gortan et al. (2024)         442.919         233.595           0.000          1094.130
     GUST                   Extreme Wind Gust                  Gortan et al. (2024)         13.901           9.526            0.000           35.400
     SPEI                    Extreme Droughts                  Gortan et al. (2024)          3.230           1.582            0.000            7.058
    Moderating variables
     GP                         Green patents                      OCDE (2025)               1.760           0.934            0.243            6.250
     IQ                     Institutional quality                   WGI (2025)               0.189           0.292           −0.466            0.844
     HC                         Human capital                      UNDP (2025)               0.809           0.053            0.687            1.026
    Control variables
     GDP                 Gross Domestic Product                     WDI (2025)             2855.253        1356.842         1234.410         6800.714
     TNRR             Total Natural Resource Rents                  WDI (2025)               2.584           0.930            0.689            4.922
     TO                        Trade Openness                       WDI (2025)               8.501           2.761            4.143            17.884
     RE                      Renewable Energy                       WDI (2025)               0.130           0.929           −0.056            11.921
     INDS                     Industrialization                     WDI (2025)               4.398           0.691            3.184            6.234
     POP                          Population                        WDI (2025)               7.307           0.749            5.509            8.333
Abbreviations: GEI, Global Energy Institute; OECD, Organization for Economic Co-­operation and Development; UNDP, United Nations Development Program; WDI,
World Development Indicators; WGI, Worldwide Governance Indicators.


interconnectedness with broader climate impacts. Additionally,                     In these models, 𝛽 3 quantifies the moderating effect, while CVit
we incorporate supplementary indicators of climate change,                         refers to control variables. The analytical process involves two
such as extreme weather events. Beyond climate-­related vari-                      stages:
ables, our model includes a suite of conditioning factors influenc-
ing energy security risk, such as GDP, TNRR, TO, POP, INDS,                          • Baseline regression: Estimate the model without interac-
and REN. These predictors are integrated to address potential                          tion terms (Equation 1) and record the significance of the
omitted variable bias, ensuring a robust empirical framework.                          coefficients.
                                                                                     • Extended regression: Introduce interaction terms into the
To explore how green patents, institutional quality, and human
                                                                                       model. A statistically significant interaction term confirms
capital might influence the link between climate change and
                                                                                       moderation; nonsignificant results imply no moderating
energy security risk, we construct interaction terms that com-
                                                                                       effect.
bine each of these potential moderators with a proxy for climate
change—namely, CO2 emissions. This approach follows the
                                                                                   We employ a fixed effects estimator to estimate both models,
moderation framework proposed by Baron and Kenny (1986).
                                                                                   which effectively controls unobserved heterogeneity across
We then assess these interaction effects across three distinct
                                                                                   countries and over time that could otherwise bias the pa-
models, which are outlined as follows:
                                                                                   rameter estimates if unaddressed. This approach is partic-
                                                     (                  )          ularly well suited to our analysis, as it enables us to focus
     ln ESRit = 𝛽 0 + 𝛽 1 ln CCit + 𝛽 2 ln GPit + 𝛽 3 ln CCit ∗ ln GPit
                                                                             (2)   on within-­country variations over time by estimating indi-
                  + 𝛽 4 CVit + 𝛿 i + 𝛾 t + 𝜀it                                     vidual country intercepts, without requiring assumptions
                                                                                   about the stationarity of the variables. This choice is further
                                                                                   justified by the structure of our data, where the number of
                                                      (                  )
      ln ESRit = 𝛽 0 + 𝛽 1 ln CCit + 𝛽 2 ln IQit + 𝛽 3 ln CCit ∗ ln IQit
                                                                             (3)   time periods (T) substantially exceeds the number of coun-
                   + 𝛽 4 CVit + 𝛿 i + 𝛾 t + 𝜀it
                                                                                   tries (N). To ensure robustness, we also used an alternative
                                                     (                  )          estimator tailored for scenarios where T > N, in order to con-
     ln ESRit = 𝛽 0 + 𝛽 1 ln CCit + 𝛽 2 ln HCit + 𝛽 3 ln CCit ∗ ln HCit            firm that our findings remain consistent across estimation
                                                                             (4)
                  + 𝛽 4 CVit + 𝛿 i + 𝛾 t + 𝜀it                                     methods.3


6                                                                                                                              Sustainable Development, 2025
                                                                                                                                                                           10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 2    |    Baseline direct effects of climate change on ESR.

                              (1)                         (2)                              (3)                              (4)                          (5)
  Variables                   CO2                 Extreme Temp                    Extreme Precip                   Extreme Wind                  Extreme SPEI
  CO2                      0.038***
                            (0.012)
  GDP                     −0.244***                   −0.259***                       −0.258***                        −0.277***                     −0.256***
                            (0.023)                     (0.018)                          (0.019)                         (0.019)                       (0.019)
  TNRR                     −0.033*                    −0.048***                         −0.037*                          −0.027                      −0.043**
                            (0.019)                     (0.018)                          (0.019)                         (0.019)                       (0.019)
  TO                      −0.060***                    −0.035**                       −0.049***                        −0.041***                    −0.048***
                            (0.018)                     (0.016)                          (0.017)                         (0.016)                       (0.018)
  REN                     −0.081***                   −0.095***                       −0.094***                        −0.095***                     −0.089***
                            (0.007)                     (0.007)                         (0.007)                          (0.007)                       (0.007)
  INDS                     0.185***                    0.207***                         0.198***                        0.201***                      0.200***
                            (0.024)                     (0.024)                          (0.024)                         (0.025)                       (0.024)
  POP                      2.475***                    2.372***                         2.581***                        1.803***                      2.486***
                            (0.143)                     (0.102)                          (0.100)                         (0.115)                       (0.101)
  TEM                                                  0.317***
                                                        (0.039)
  PRE                                                                                   0.005***
                                                                                         (0.001)
  GUST                                                                                                                  0.088***
                                                                                                                         (0.007)
  SPEI                                                                                                                                                0.018***
                                                                                                                                                       (0.003)
  R2                         0.569                       0.579                           0.569                            0.594                         0.570
Note: Column (1) uses CO2 emissions as the climate change measure, while Columns (2) to (5) use extreme temperature (TEMP), extreme precipitation (PRE), extreme
wind gust (GUST), and extreme drought (SPEI), respectively. Coefficients (S.E. in parentheses) are reported, with *, **, and *** indicating significance at 10%, 5%, and
1%.




4   |   Empirical Results and Discussion                                               This relationship is driven by several mechanisms. First, CO2
                                                                                       emissions can lead to extreme weather events that damage
4.1   |   Baseline Result                                                              energy infrastructure and disrupt supply chains (Zhang et al.
                                                                                       2023). Second, high emissions often signal heavy reliance on
This section explores how climate change impacts ESR by es-                            fossil fuels, thereby exposing nations to geopolitical risks—as
timating Equation (1) using a fixed effects approach, with the                         demonstrated by the global energy market disruptions following
results summarized in Table 2. Prior studies (Luft et al. 2010)                        the Russia-­U kraine conflict (Hille and Angerpointner 2025).
have suggested that the nexus between climate change and ESR                           Third, dependence on environmentally harmful energy sources
may be constrained by a trade-­off between cutting CO2 emis-                           increases vulnerability during unexpected events, as witnessed
sions and maintaining ESR. Accordingly, we use CO2 emissions                           during the COVID-­19 pandemic (Ezeaku et al. 2021). Lastly,
as our primary climate change indicator, with Column (1) of                            rising emissions heighten public demand for stricter emission
Table 2 presenting the corresponding estimates. For robustness,                        standards, prompting energy system transformations that re-
Columns (2) through (5) offer alternative measures—including                           quire significant investments and may increase operational
extreme temperature, precipitation, wind gusts, and drought                            costs for traditional producers, potentially affecting supply reli-
events—which consistently confirm that a 1% rise in CO2 emis-                          ability and market stability (Battisti 2023; IRENA 2019; Panos
sions is associated with a 0.038% increase in ESR.                                     et al. 2023).




                                                                                                                                                                       7
                                                                                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 2    |    Carbon Emissions per Capita in 15 Countries. Source: Our World in Data (2023).



In the GCC region, these dynamics have unique character-                   Furthermore, the abundant natural resources in the GCC sig-
istics. The region ranks among the world's top 10 highest per              nificantly bolster energy security by generating substantial
capita CO2 emitters, with Qatar leading in 2023 at 36.5 tons per           hydrocarbon revenues. These funds are reinvested in diver-
capita. This high emission rate is driven by energy-­intensive             sifying energy sources and upgrading infrastructure; for in-
desalination processes, extensive air conditioning in extreme              stance, Saudi Arabia's Vision 2030 aims to develop 60 GW of
desert climates, and fossil fuel-­dependent industrial sectors             renewable energy, while the UAE's Energy Strategy 2050 tar-
(Dawoud 2005; Moossa et al. 2022; WB 2013) (Figure 2).                     gets a 50% clean energy share (Al-­Mekaimi 2025). However,
                                                                           this resource wealth also poses challenges, such as overre-
Despite being major oil and gas exporters, GCC nations are in-             liance on hydrocarbons and potential environmental degra-
creasingly aware of the ESR posed by climate change. For in-               dation. Initiatives like Kuwait's Vision 2035 seek to address
stance, the UAE's Energy Strategy 2050 aims for a 50% clean                these challenges by promoting economic diversification and
energy mix, while Saudi Arabia's Vision 2030 plans to de-                  sustainable energy investments, an approach supported by
velop 60 GW of renewable energy capacity (Al-­Mekaimi 2025).               findings from Chen et al. (2024), who observed that in 27
Moreover, rising sea levels threaten critical coastal infrastruc-          highly energy-­  consuming economies, resource abundance
ture such as Qatar's Ras Laffan LNG terminal and the UAE's                 helps mitigate ESR. Nonetheless, the relationship between
Fujairah oil export hub (IRENA 2023). Initiatives like Saudi               natural resource endowments and energy security is complex.
Arabia's circular carbon economy framework, along with sig-                While resource rents can promote energy diversification and
nificant investments in solar projects (e.g., Abu Dhabi's 2 GW             support the development of infrastructure, they can also pose
Al Dhafra plant and Saudi Arabia's green hydrogen efforts                  risks such as the resource curse, sociopolitical unrest, and
at the NEOM project), exemplify the region's strategic efforts             ecological harm (Ahmadov and van der Borg 2019).
to balance hydrocarbon production with emission reduction
(IRENA 2023).                                                              Our econometric analysis indicates that renewable energy sig-
                                                                           nificantly reduces ESR in the GCC region; this can be explained
Turning to controlling factors, our analysis reveals that larger           through multiple interconnected channels, as supported by re-
GDP correlates with enhanced energy security, as wealthier                 cent studies (Giuli 2022; Khan et al. 2024; Tansel Tugcu and
nations have the financial capacity to invest in diverse and               Menegaki 2024): (1) Renewable energy decreases reliance on
resilient energy infrastructures. The International Monetary               imported fossil fuels, mitigating risks tied to price volatility
Fund (IMF) has noted that a robust economy facilitates the                 and supply disruptions. For example, countries expanding re-
green transition by reducing reliance on fossil fuels (Kim 2024;           newables like solar and wind reduce exposure to geopolitical
Tansel Tugcu and Menegaki 2024). In contrast, higher levels                tensions in oil and gas markets. This diversification enhances
of industrialization tend to increase ESR. Industrial growth—              energy independence and stabilizes supply chains—as seen in
especially in energy-­intensive sectors such as manufacturing              Saudi Arabia's 60 GW renewable target under Vision 2030, (2) By
and mining—escalates energy demand, potentially strain-                    curbing greenhouse gas emissions, renewables address climate-­
ing supplies and infrastructure. For example, research on                  related risks (e.g., extreme weather damaging infrastructure)
Turkey's energy security indicates that unchecked industrial               that threaten long-­term energy stability. This aligns with studies
expansion can exacerbate long-­    term energy vulnerabilities             showing renewables counteract energy security threats posed
(Karasoy 2023). Additionally, population growth intensi-                   by climate change, and (3) Electrification and renewable adop-
fies energy consumption patterns and can further stress en-                tion reduce weaponization risks associated with fossil fuels (e.g.,
ergy systems, contributing to higher vulnerability indices                 trade embargoes). Decentralized renewable systems also limit
(Morikawa 2012).                                                           vulnerability to centralized infrastructure attacks or market

8                                                                                                                   Sustainable Development, 2025
                                                                                                                                                                                 10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
manipulation. However, for the GCC to fully reap these bene-                             thereby reducing both CO2 emissions and the vulnerability of
fits, its transition must carefully balance its hydrocarbon-­based                       energy systems to climate impacts.
economy with sustainable investments.
                                                                                         To investigate these potential moderating effects, we exam-
Trade integration enhances energy security in the GCC region                             ine how green patents, institutional quality, and human cap-
by diversifying supply chains and attracting infrastructure in-                          ital influence the climate change–ESR nexus. We estimate
vestments. However, this integration also introduces vulner-                             Equations (2–4), which incorporate interaction terms between
abilities, such as heightened foreign energy dependency and                              CO2 emissions and each of these factors. The results are pre-
exposure to geopolitical disruptions—evident in recent global                            sented in Table 3.
conflicts. Additionally, trade-­driven energy consumption pat-
terns and environmental externalities, including transportation
emissions and ecological risks, amplify systemic pressures on                            4.2.1   |   Green Patents (Model 2)
energy systems (Sadorsky 2011).
                                                                                         Column (1) shows that while CO2 emissions retain their posi-
                                                                                         tive and significant coefficient (consistent with baseline find-
4.2   |   Mechanism Results                                                              ings), the interaction term (CO2 * Green Patents) is negative
                                                                                         and statistically significant (−0.065). This indicates that a
While our baseline results establish a clear link between CO2                            higher level of green patenting activity significantly weakens
emissions (as a proxy for climate change drivers) and increased                          the effect of CO2 emissions on ESR. Green patents signify a
ESR, it is crucial to understand factors that might mitigate this                        nation's capacity for technological innovation in areas like
adverse relationship. Climate change impacts, largely driven                             renewable energy generation, energy efficiency, and carbon
by fossil fuel energy systems, can theoretically be buffered by                          capture (Bergougui et al. 2024; Bergougui and Meziane 2025).
advancements in sustainable energy, effective governance, and                            Higher innovation capacity allows countries to deploy
a capable workforce. Energy generated using patented green                               low-­c arbon technologies more rapidly (Bergougui 2024a;
technologies avoids GHG emissions, while strong institutional                            Bergougui and Aldawsari 2024). This diversification away
frameworks and skilled human capital can facilitate the tran-                            from fossil fuels reduces exposure to both the direct physical
sition to cleaner energy and enhance adaptation capabilities,                            impacts of climate change on traditional energy infrastructure


TABLE 3    |    Effect of CO2 emissions on ESR.

                                                           Model (2)                                     Model (3)                                  Model (4)
                                                        Green patents                            Institutional quality                          Human capital
  CO2                                                       0.089***                                      0.092***                                   0.566***
                                                             (0.015)                                        (0.012)                                   (0.041)
  Green Patents                                             1.025***                                          —                                          —
                                                             (0.128)                                          —                                          —
  CO2*Green Patents                                        −0.065***                                          —                                          —
                                                             (0.008)                                          —                                          —
  Institutional Quality                                         —                                         0.806***                                       —
                                                                —                                          (0.284)                                       —
  CO2*Institutional Quality                                     —                                        −0.072***                                       —
                                                                —                                           (0.018)                                      —
  Human Capital                                                 —                                             —                                     15.645***
                                                                —                                             —                                       (1.194)
  CO2*Human Capital                                             —                                             —                                     −0.984***
                                                                —                                             —                                       (0.074)
  Controls                                                      Yes                                           Yes                                       Yes
  Fixed effect                                                  Yes                                           Yes                                       Yes
  R2                                                          0.732                                          0.784                                     0.752
Note: This table presents findings on the moderating effects of green patents (GP), institutional quality (IQ), and human capital (HC) on the relationship between
climate change and ESR. The analysis includes separate regression models for each moderator: GP (Column 1), IQ (Column 2), and HC (Column 3). Coefficient
estimates are shown outside parentheses, while standard errors appear inside parentheses. Statistical significance levels are indicated as follows: *p < 0.10, **p < 0.05,
and ***p < 0.01.


                                                                                                                                                                             9
                                                                                                                                             10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
(e.g., extreme weather damage) and the geopolitical volatility       4.2.3   |   Human Capital (Model 4)
associated with fossil fuel Abbas et al. 2024; Lin et al. 2023; Q.
Wang et al. 2024). Essentially, innovation provides the tools        Column (3) confirms the moderating role of human capital. The
to build a more resilient and less carbon-­intensive energy sys-     interaction term (CO2 * Human Capital) is strongly negative
tem, thus buffering against climate-­related risks. For GCC          and significant (−0.984), suggesting that a more educated and
nations, fostering and utilizing green patents is vital for trans-   skilled population substantially diminishes the negative effect
lating diversification goals (like those in the UAE's Energy         of CO2 emissions on energy security. A high level of human
Strategy 2050 and Saudi Vision 2030) into tangible reductions        capital provides the skilled workforce—engineers, technicians,
in energy system vulnerability (Al-­S arihi and Mansouri 2022;       researchers, policymakers, and managers—required to develop,
Alqahtani 2023).                                                     deploy, operate, and maintain advanced and resilient energy
                                                                     systems. It fosters innovation, enables the adoption of complex
                                                                     green technologies, supports effective climate risk assessment
4.2.2   |   Institutional Quality (Model 3)                          and adaptation planning within the energy sector, and facilitates
                                                                     public understanding and support for energy transitions. For the
Column (2) highlights a significant and negative interaction         GCC, investing oil wealth in education and specialized train-
term (CO2*Institutional Quality) of −0.072, underscoring the         ing is critical to building the human capital needed to manage
critical role of institutional quality in mitigating ESR asso-       large-­scale renewable projects, develop local green industries,
ciated with rising CO2 emissions. This finding suggests that         and adapt existing energy infrastructure to climate challenges
stronger institutions—characterized by regulatory effective-         like extreme heat and water scarcity (Bannaga and Lezar 2024;
ness, rule of law, government stability, and control of cor-         Kheyfets et al. 2020).
ruption—play a pivotal role in buffering against the adverse
impacts of climate change on energy systems (Almulhim
et al. 2025).                                                        4.2.4   |   Threshold Effect

High institutional quality fosters a stable and predictable envi-    To gain a clearer understanding of how green patents, in-
ronment that is essential for attracting long-­term investments      stitutional quality, and human capital mediate the climate
in complex energy projects, such as renewable energy infra-          change–ESR relationship, we calculated the conditional
structure and grid modernization. These projects are founda-         marginal effects of CO2 emissions on ESR at varying levels
tional to building climate-­resilient energy systems capable of      of these moderators (visualized in Figure 3, based on Table 3
withstanding the increasing frequency and severity of extreme        estimates). These plots compellingly illustrate that the det-
weather events (Azimi et al. 2025). Moreover, robust institu-        rimental impact of rising CO2 emissions on energy security
tions enable effective policy implementation, ensuring that          is not uniform; it is significantly conditioned by a country's
climate adaptation strategies, disaster response mechanisms,         innovative capacity, governance effectiveness, and workforce
and energy transition frameworks are not only designed but           skills. The analysis reveals distinct thresholds for each mod-
also executed efficiently. For instance, strong governance           erator: approximately 1.43 for green patents, 0.03 for institu-
frameworks facilitate the integration of intermittent renew-         tional quality, and 0.58 for human capital. These thresholds
able energy sources into national grids while maintaining re-        represent critical junctures.
liability and affordability (Azimi et al. 2025). In the context
of GCC nations, the importance of institutional quality be-            • Below the threshold: In countries where GP, IQ, or HC
comes even more pronounced. The GCC's ambitious energy                   levels fall below these respective thresholds, the marginal
diversification goals, such as the UAE's Energy Strategy 2050            effect of CO2 emissions on ESR remains positive and sig-
and Saudi Vision 2030, rely heavily on institutional capacity            nificant. In practical terms, this means that in environ-
to manage the transition away from oil dependence. Robust                ments with limited green innovation, weaker governance,
institutions are essential to oversee large-­scale renewable en-         or lower skill levels, the energy system is more directly
ergy projects like the Al Dhafra solar plant and the NEOM                vulnerable to climate change drivers—increased emis-
green hydrogen initiative, ensuring these investments are                sions translate more readily into heightened ESR (e.g.,
effectively implemented and aligned with long-­term energy               supply disruptions from extreme weather, instability from
security objectives. Furthermore, strong institutions help mit-          fossil fuel dependence).
igate risks associated with geopolitical uncertainties and vola-
tile fossil fuel markets, which have been exacerbated by recent        • Above the threshold: Conversely, once a country sur-
events such as the Russia–Ukraine war. Additionally, institu-            passes these threshold levels, the positive marginal ef-
tional quality contributes to reducing emissions by promoting            fect of CO2 emissions on ESR diminishes substantially,
cleaner energy practices and enforcing higher environmental              becoming statistically insignificant or potentially even
standards. Studies indicate that improvements in institutional           negative in some ranges according to the model. This
quality reduce CO2 emissions across different economies,                 signifies that possessing sufficient innovative capacity,
further reinforcing the link between governance and climate              robust institutions, or high human capital equips a na-
resilience (Stef et al. 2023). In regions like the GCC, where            tion with the necessary tools and resilience to effectively
economic structures have traditionally relied on fossil fuel ex-         counteract the energy security threats posed by climate
ports, strengthening institutional frameworks can help align             change. The energy system becomes buffered, capable of
energy policies with global sustainability goals while safe-             adapting through technological deployment, sound pol-
guarding domestic energy security.                                       icy, and skilled management, thus weakening or breaking

10                                                                                                           Sustainable Development, 2025
                                                                                                                                                         10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 3    |    Margins plots of the conditional effects of climate change (CO2 emissions) on ESR. The data reflect marginal effects derived from the
fixed effect regression detailed in Table 3.




     the direct link between rising emissions and increased                  necessitates rigorous econometric identification strategies to es-
     vulnerability.                                                          tablish causal relationships between climate change and ESR.

In conclusion, the existence of these thresholds dramatically                4.3.1.1   |   Instrumental Variable Strategy. We address
underscores that the impact of climate change on ESR is not                  these endogeneity concerns through a multi-­pronged instru-
predetermined. Proactive and strategic development of green                  mental variable approach comprising four complementary
innovation ecosystems, robust and adaptive institutions, and                 methodologies:
high levels of human capital can significantly mitigate associ-
ated risks. For the GCC, recognizing and strategically address-                • IV-­Lewbel: Leverages heteroskedasticity patterns for iden-
ing these thresholds is paramount to successfully navigating the                 tification following Lewbel (2012), generating internal in-
energy transition and building a resilient energy future in the                  struments when external instruments face limitations.
face of climate change.
                                                                               • IV-­GMM: Employs the Generalized Method of Moments
                                                                                 estimator to achieve efficient parameter estimation with
                                                                                 heteroskedasticity-­robust inference capabilities.
4.3   |   Robustness Test
                                                                               • IV-­DK: Incorporates Driscoll-­K raay standard errors to si-
4.3.1   |   Addressing Endogeneity Concerns                                      multaneously address cross-­sectional dependence and se-
                                                                                 rial correlation, following Hoechle (2007).
The nexus between ESR and climate change presents consider-                    • System-­GMM: Implements the Arellano-­       Bond System
able econometric challenges due to inherent simultaneity bias.                   GMM estimator to tackle dynamic panel bias and potential
Energy security policy decisions influence climate outcomes                      endogeneity across all regressors using lagged levels and
through their emission implications, while climate change                        differences as instruments, particularly effective for pan-
concurrently shapes energy security considerations through                       els with persistent variables and unobserved heterogeneity
environmental and economic feedback mechanisms. This bi-                         (Roodman 2009).
directional causality manifests in complex ways: fossil fuel
infrastructure investments may bolster immediate energy se-                  4.3.1.2   |   Instrument Design and Validation. For the first
curity but amplify long-­term climate vulnerabilities through                three approaches, we instrument country-­specific CO2 emis-
heightened emissions, whereas renewable energy investments                   sions using lagged cross-­sectional average emissions, exploiting
aimed at climate mitigation can simultaneously reduce emis-                  multiple theoretically grounded mechanisms that establish both
sions and diversify energy security portfolios. Such simultaneity            relevance and exogeneity conditions. This identification strategy

                                                                                                                                                   11
                                                                                                                                                 10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
operates through spatial spillover effects and regional atmo-           affect individual country energy security exclusively through
spheric dynamics that characterize carbon emissions patterns            domestic emission channels rather than direct pathways. This
in the environmental economics literature (Y. Liu et al. 2014).         theoretical foundation draws on the localized nature of energy
Regional CO2 emissions exhibit strong spatial correlation due           security risks, which primarily depend on local energy infra-
to shared atmospheric systems, prevailing wind patterns,                structure resilience, supply chain vulnerabilities, and demand–
and transboundary pollution transport mechanisms that cre-              supply balances within specific geographic boundaries. While
ate predictable regional emission clusters independent of local         neighboring regions may share some economic characteristics,
energy security considerations (Zhou et al. 2023).                      their historical emission patterns should not directly influence
                                                                        contemporary local energy security risks beyond their predictive
The theoretical exogeneity of our instrument stems from the             relationship with current local carbon intensity. Regional emis-
temporal and spatial separation embedded in its construction,           sions from previous periods cannot directly influence current
combined with established regional economic integration                 energy security through cross-­border supply disruptions (which
mechanisms. By utilizing emissions data from neighboring                operate through current conditions), regional market integra-
regions with appropriate time lags, the instrument captures             tion effects (captured in robustness checks), or neighboring pol-
regional atmospheric and industrial patterns that predate               icy spillovers (manifested through current policy variables). The
current energy security concerns while remaining geograph-              theoretical framework builds on insights from industrial organi-
ically removed from direct local energy policy influences.              zation and agglomeration economics, where regional industrial
This spatial dependence in carbon emissions reflects fun-               clusters create predictable patterns in resource utilization and
damental physical processes of atmospheric dispersion and               environmental outcomes. The spatial econometrics literature on
regional climate systems that operate according to meteoro-             environmental policy, particularly studies by Fredriksson and
logical principles rather than economic or energy security              Millimet (2002), demonstrates how regional similarities in envi-
imperatives. Regional technological diffusion creates cor-              ronmental outcomes reflect shared geographic and institutional
related emission trajectories as clean energy innovations and           characteristics rather than direct causal relationships to energy
carbon-­intensive processes spread through trade, investment,           security. However, we acknowledge potential limitations in the
and knowledge transfer networks (Dechezleprêtre et al. 2011;            exclusion restriction if regional energy markets are highly inte-
Keller 2004). Additionally, international climate policy coor-          grated or if neighboring regions face correlated energy security
dination generates synchronized emission patterns indepen-              shocks, making the instrument validity critically dependent on
dent of individual country energy security decisions (Aldy              regional emission patterns reflecting industrial and atmospheric
and Stavins 2012). These mechanisms operate through shared              characteristics rather than shared energy security vulnerabili-
industrial structures, energy systems, and regulatory envi-             ties. For System-­GMM, we employ standard instrumentation
ronments that emerge from historical economic development               of endogenous variables with lagged levels (in first-­difference
patterns and inter-­regional policy coordination, creating pre-         equations) and lagged differences (in level equations), effectively
dictable relationships between regional emission patterns as            addressing persistent time series bias and unobserved country-­
documented in the spatial econometrics literature on environ-           specific heterogeneity while maintaining the theoretical foun-
mental spillovers. The temporal lag structure provides addi-            dations established for the lagged regional averages approach.
tional theoretical justification by exploiting the persistence in
regional emission patterns while creating temporal distance             Table 4 presents IV estimation results across all methodological
from current energy security risks. Carbon emissions exhibit            approaches (Columns 1–3) alongside System-­GMM estimates
strong autocorrelation due to the long-­lived nature of energy          (Column 4) for robustness validation. The findings demonstrate
infrastructure, industrial capital stocks, and institutional            remarkable consistency across specifications, with climate
frameworks that determine regional carbon intensity. This               change maintaining statistically significant positive effects on
persistence means that historical regional emission patterns            ESR after controlling for endogeneity. This robustness across di-
contain predictive information about current local emissions            verse IV methodologies provides compelling evidence support-
through shared regional characteristics, while the temporal             ing our core hypothesis that climate change causally increases
lag ensures that the instrument reflects predetermined re-              energy security risks.
gional conditions rather than responses to current energy se-
curity concerns.
                                                                        4.3.2   |   Other Robustness Tests
The instrument satisfies relevance conditions through robust
first-­stage relationships, with F-­statistics consistently exceeding   To validate the reliability of our central finding—that climate
10, reflecting emission pattern persistence and gradual energy          change exhibits a positive association with ESR—we conducted
transition dynamics driven by shared technological trajectories,        several robustness checks.
similar industrial development paths, and coordinated environ-
mental policies among neighboring countries. This relevance               • Specification sensitivity analysis: We systematically tested
operates through established theories of regional economic in-              the stability of our baseline relationship by re-­estimating
tegration and industrial clustering effects, where neighboring              models with CO2 emissions (our primary climate proxy)
regions develop similar industrial structures and environmental             while varying the control variable configurations. The
profiles due to shared factor endowments and spillover effects, as          results in Table 5 demonstrate remarkable consistency,
demonstrated in Porter's (1998) work on industrial clusters and             with the CO2 coefficient remaining positive and statis-
Krugman's (1991) analysis of economic geography. The exclu-                 tically significant across all seven alternative specifica-
sion restriction holds because lagged regional average emissions            tions. This robustness spans from the most parsimonious

12                                                                                                               Sustainable Development, 2025
                                                                                                                                                                              10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 4    |    Tackling endogeneity issues by employing instrumental variable (IV) methods.

                                                   (1)                                (2)                               (3)                               (4)
  Variables                                   IV-­Lebwel                          IV-­GMM                             IV-­DK                      System-­GMM
  CO2                                           0.041***                           0.039***                          0.039***                         0.1338**
                                                 (0.003)                            (0.012)                           (0.014)                           (2.55)
  GDP                                          −0.032***                          −0.246***                         −0.246***                        0.7825***
                                                 (0.008)                            (0.023)                           (0.025)                           (5.01)
  TNRR                                         −0.164***                           −0.035*                           −0.035*                           0.6644
                                                 (0.015)                            (0.019)                           (0.019)                           (1.54)
  TO                                            0.072***                          −0.060***                         −0.060***                        −1.3676**
                                                 (0.009)                            (0.018)                           (0.021)                          (−2.02)
  REN                                           −0.002                            −0.080***                         −0.080***                        −1.6416**
                                                 (0.007)                            (0.007)                           (0.009)                          (−2.08)
  INDS                                          0.210***                           0.187***                          0.187***                          0.7297
                                                 (0.032)                            (0.024)                           (0.021)                           (1.15)
  POP                                           0.722***                           2.470***                          2.470***                          0.0000
                                                 (0.037)                            (0.144)                           (0.154)                             (.)
  R2                                              0.345                              0.569                             0.512
  FE                                               No                                 Yes                               Yes                              Yes
  CD Wald F                                     348,758                            179,243                           179,243
  KP Wald F                                   2.353e+06                             42,825                            43,126
  Hansen J: p-­value                                                                                                                                       1
  AR(2): p-­value                                                                                                                                       0.690
Note: This table presents findings from instrumental variable (IV) regressions that address endogeneity by using the lagged cross-­sectional average of CO2 emissions
as an instrument for a country's CO2 emissions. The models progress from a basic specification (IV-­L ebwel) to more robust ones (IV-­GMM and IV-­DK). IV-­L ebwel:
Implements the Lewbel (2012) IV approach, which exploits heteroskedasticity for identification. IV-­GMM leverages the Generalized Method of Moments (GMM)
estimator, delivering efficient estimates accompanied by robust standard errors. IV-­DK incorporates Driscoll-­K raay (DK) standard errors to address cross-­sectional
dependence and heteroskedasticity. Standard errors are presented within parentheses, while the Kleibergen-­Paap (KP Wald F) and Cragg-­Donald (CD Wald F)
F-­statistics evaluate the robustness of the instruments. Hansen overidentification p values greater than 0.05 for almost all of the specifications imply that we cannot
reject the null hypothesis which states that the instruments used are valid. Statistical significance is represented by *, **, and *** corresponding to the 10%, 5%, and 1%
thresholds, respectively.




       model (Column 1, including only CO2) to the fully satu-                              • Nonlinear specifications: We examined potential nonlin-
       rated specification (Column 2, incorporating all control                               ear relationships by incorporating a quadratic CO2 term
       variables). The coefficient stability across different condi-                          (Column 4), which reveals a significant inverted-­U rela-
       tioning sets confirms that the climate–ESR relationship is                             tionship while maintaining the positive primary effect of
       not driven by particular variable combinations or model                                climate change on ESR.
       specifications (Table A1).
                                                                                            • Major events: We tested model stability against significant
  • Cross-­ sectional dependence correction: Given the eco-                                   economic disruptions, including crisis period controls for
    nomic integration among GCC countries, we tested for                                      the 2009 financial crisis (Column 5), oil price shock ad-
    cross-­sectional dependence using Pesaran's CD test, which                                justments (Column 6), and COVID-­    19 pandemic effects
    revealed strong interdependence across the six nations (see                               (Column 7). These controls ensure our findings are not con-
    Table A2). To address this methodological concern, we re-­                                founded by major economic or health crises.
    estimated our key models using Pesaran's (2006) Common
    Correlated Effects (CCE) estimator, which accounts for un-                              • Dynamic modeling: We incorporated lagged dependent vari-
    observed common factors (Pesaran 2006). The CCE results                                   ables (Column 8) to account for potential persistence effects
    (Table 5, Column 3) not only maintain the positive and sig-                               and dynamic adjustment processes in ESR patterns.
    nificant climate–ESR relationship but actually strengthen
    the coefficient magnitude, reinforcing our core findings                             Across all specifications, the climate change coefficient remains
    (Table A3).                                                                          consistently positive and significant, with the relationship

                                                                                                                                                                         13
    14
                                    TABLE 5    |    Robustness analysis: Climate change (CO2) effects on ESR across model specifications.

                                                                     (1)                                       (2)                                        (3)                                      (4)                                 (5)                          (6)                          (7)                               (8)
                                                           Include only CO2                  Include all variables                            CCE estimator                         Nonlinear model                            Crisis 2009                    Oil shock                     Covid19                   Dynamic model
                                     ESR(t-­1)                                                                                                                                                                                                                                                                               1.6133***
                                                                                                                                                                                                                                                                                                                                (39.83)
                                     CO2                         0.0640***                                0.0246*                                   0.1565***                               1.2468***                            0.1013***                     0.1021***                   0.1150***                          0.0094**
                                                                   (3.68)                                   (1.72)                                      (2.67)                                 (17.00)                              (10.12)                       (8.84)                       (9.91)                            (2.15)
                                     CO2 _square                                                                                                                                           −0.0388***
                                                                                                                                                                                              (−16.46)
                                     GDP                                                               −0.2602***                                    −0.2980                               −0.3374***                           −0.1619***                   −0.1316***                   −0.1808***                            0.0077
                                                                                                          (−12.31)                                     (−1.20)                                (−16.93)                             (−6.67)                       (−5.72)                      (−8.18)                            (0.80)
                                     TNRR                                                                0.2122***                                     0.0303                                0.2795***                           0.5481***                    0.4349***                    0.5163***                        −0.0366***
                                                                                                            (6.62)                                      (0.40)                                 (10.03)                              (16.95)                      (16.50)                      (22.09)                          (−3.28)
                                     TO                                                                −0.1252***                                    −0.0029                               −0.1476***                               0.0330                   −0.1130***                   −0.1777***                         0.0519***
                                                                                                           (−7.46)                                    (−0.02)                                  (−9.82)                               (1.34)                      (−5.63)                     (−10.88)                            (3.89)
                                     REN                                                               −0.0396***                                    1.3870**                              −0.0227***                               1.4720                   −3.1614***                   −0.1218***                        −0.0459***
                                                                                                           (−4.80)                                      (1.97)                                 (−2.92)                               (0.66)                      (−7.72)                     (−3.50)                           (−5.26)
                                     INDS                                                                0.3074***                                     0.3638                                0.2950***                            0.0608**                     0.1414***                   0.1649***                            0.0052
                                                                                                           (13.48)                                      (1.57)                                 (14.03)                               (2.23)                       (6.72)                       (8.81)                            (0.27)
                                     POP                                                                 2.0393***                                 −12.3841**                                1.8902***                          −1.9379***                     2.7056***                   2.5949***                           −0.0142
                                                                                                           (27.38)                                    (−2.02)                                  (25.81)                             (−4.43)                       (15.10)                      (32.84)                          (−0.27)
                                     R2                             0.531                                   0.724                                                                                0.761                               0.771                        0.706                        0.767
                                    Note: The table presents findings on the effects of climate change on ESR, using CO2 emissions as the primary indicator of climate change. The regression analyses progress sequentially from the most basic model to the fully
                                    detailed specification.




    Sustainable Development, 2025
10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
                                                                                                                                                                                   10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 6    |    Lagged effects of climate extremes on ESR.

                                 (1)                          (2)                               (3)                              (4)                            (5)
  Variables                     CO2                  Extreme temp                     Extreme precip                    Extreme wind                   Extreme SPEI
  CO2 (t−1)                 0.0381***
                               (3.24)
  TEM(t−1)                                                0.3171***
                                                            (8.01)
  PRE (t−1)                                                                                0.0055***
                                                                                              (5.06)
  GUST(t−1)                                                                                                                  0.0889***
                                                                                                                               (13.32)
  SPEI(t−1)                                                                                                                                                0.0186***
                                                                                                                                                              (5.58)
  GDP                      −0.2402***                    −0.2562***                       −0.2549***                        −0.2741***                    −0.2536***
                             (−10.16)                      (−13.81)                         (−13.43)                          (−14.67)                      (−13.35)
  TNRR                       −0.0319                     −0.0468**                         −0.0359*                          −0.0260                       −0.0419**
                              (−1.64)                      (−2.54)                           (−1.85)                          (−1.36)                        (−2.16)
  TO                       −0.0550***                     −0.0312*                         −0.0449**                        −0.0371**                      −0.0445**
                              (−3.00)                      (−1.87)                           (−2.55)                          (−2.32)                        (−2.48)
  REN                      −0.0835***                    −0.0979***                       −0.0966***                       −0.0984***                     −0.0924***
                             (−11.89)                      (−14.43)                         (−13.94)                          (−14.11)                      (−13.58)
  INDS                      0.1778***                     0.1996***                        0.1909***                         0.1942***                     0.1928***
                               (7.37)                       (8.31)                            (8.03)                           (7.97)                         (8.09)
  POP                       2.4745***                     2.3682***                        2.5777***                         1.7923***                     2.4783***
                              (17.06)                       (22.89)                          (25.51)                           (15.38)                       (24.31)
  R2                           0.566                         0.576                            0.566                            0.592                          0.567
Note: This table presents fixed-­effects panel regression results examining the lagged relationships between climate variables and energy security risk (ESR). Column
(1) employs lagged CO2 emissions as the primary climate indicator, while Columns (2)–(5) utilize lagged extreme climate measures: temperature (TEM), precipitation
(PRE), wind gust (GUST), and standardized precipitation evapotranspiration index (SPEI), respectively. All climate variables are lagged by one period (t−1) to capture
delayed effects and address potential simultaneity bias. t-­statistics are reported in parentheses. Statistical significance is denoted by *, **, and *** at the 10%, 5%, and 1%
levels, respectively.



proving robust to various econometric concerns and alternative                             capture delayed impacts. The results provide compelling evi-
model formulations.                                                                        dence of persistent climate–ESR relationships even when ac-
                                                                                           counting for temporal displacement. The results highlight the
                                                                                           persistent influence of climate change and extreme weather
4.3.3   |   Lagged Effects Analysis                                                        on energy security risk. The lagged effect of CO2 emissions
                                                                                           confirms that past emissions continue to have a significant
To address potential temporal dynamics, we examine the                                     positive impact on current energy security risk, underscor-
lagged effects of climate variables on ESR by introducing one-­                            ing the delayed and enduring nature of climate-­related chal-
period lagged explanatory variables. This approach is meth-                                lenges. This persistence reflects the physical characteristics
odologically crucial for several reasons: first, it helps identify                         of the climate system, where the consequences of emissions
delayed impacts of climate change on energy security deci-                                 unfold over extended periods. Moreover, the analysis of lagged
sions; second, it mitigates simultaneity bias by using prede-                              extreme weather indicators reveals consistent and significant
termined values of climate variables; and third, it captures the                           impacts. Past temperature extremes exert the strongest influ-
realistic time lag between climate events and policy responses                             ence, substantially increasing current energy security risk.
in energy security planning. Table 6 presents our lagged ef-                               Drought conditions and extreme precipitation also contrib-
fects estimation across five model specifications (Columns                                 ute to heightened risk, though their effects are more moder-
1–5), where each climate indicator is lagged by one period to                              ate. Similarly, extreme wind events display notable delayed

                                                                                                                                                                             15
                                                                                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 7    |    Country-­by-­country fixed-­effects regression outcomes.

                       (1)                 (2)                  (3)            (4)                (5)                        (6)
                   Bahrain              Kuwait                Oman           Qatar          Saudi Arabia        United Arab Emirates
 ln_CO2            0.1626***            0.9436***           1.9029***      0.1341***           0.0815**                  0.0617***
                     (8.03)               (8.72)              (8.14)         (3.32)             (2.30)                     (3.03)
 GDP              −0.3470***            0.0578**            −0.2268**       −0.0696             0.1252                   −0.0209
                    (−5.99)               (2.23)              (−2.19)        (−1.21)            (1.17)                    (−0.24)
 TNRR             −0.1162***          −0.0837***           −0.2542***        0.0377          −0.2647***                  −0.0295
                    (−6.10)              (−4.04)              (−7.38)        (0.79)             (−3.08)                   (−0.93)
 TO                0.0992***            0.1325***          −0.1788***        0.0278          −0.5480***                  0.0701***
                     (3.47)               (4.46)              (−3.01)        (0.43)            (−4.88)                     (2.63)
 REN               0.8364***          −0.6245***            −0.3345*        1.0498*             0.0899                   −0.0203*
                     (6.58)             (−20.97)              (−1.68)        (1.85)             (0.53)                    (−1.87)
 INDS                0.0198             −0.0347*            0.5620***       −0.0349           1.0027***                   0.0076
                     (1.19)              (−1.78)              (5.10)         (−1.48)            (3.43)                     (0.09)
 POP                −3.6433             −0.1210               0.2730         0.4520           −5.9747***                 −0.2718
                    (−1.37)              (−0.13)              (0.69)         (0.21)             (−3.66)                   (−0.30)
 R2                  0.941                0.994                0.998         0.978              0.970                      0.988


impacts, emphasizing the importance of considering past                    system stress. In contrast, Bahrain, Qatar, Saudi Arabia, and the
climatic shocks in energy security planning. Together, these               UAE show more moderate but statistically significant climate
findings underscore the necessity of long-­term strategies to              impacts, with coefficients ranging from 0.062 to 0.163. Despite
address the compounding effects of climate variability on en-              these lower magnitudes, the consistent positive and signifi-
ergy systems.                                                              cant relationships across all six countries confirm that climate
                                                                           change poses universal energy security challenges throughout
                                                                           the GCC region, albeit with varying intensities.
4.3.4   |   Country-­By-­Country Analysis

To provide nuanced insights into the heterogeneous impacts                 4.4   |   Asymmetric Effect
of climate change across the GCC region, we conduct individ-
ual country-­level analyses using fixed-­effects regressions. This         This research implements the method of moments quantile
disaggregated approach is essential for understanding how                  regression (MMQR) framework established by Machado and
structural differences, economic characteristics, and energy               Santos Silva (2019) to evaluate the potentially asymmetric ef-
portfolios across GCC nations influence the climate-­E SR rela-            fects of climate change—operationalized through CO2 emis-
tionship. Table 7 presents country-­specific regression results,           sions—on ESR across GCC countries. While our previous
revealing substantial heterogeneity in both the magnitude and              analyses documented linear relationships between climate
significance of climate impacts on energy security risk.                   change indicators and ESR, this study advances the literature
                                                                           by investigating non-­linear patterns across the ESR distribu-
The country-­  specific analysis reveals striking variations in            tion spectrum. Given the substantial heterogeneity in ESR pro-
climate vulnerability across the GCC region. Oman exhibits                 files among GCC member states, we examine whether climate
the highest climate sensitivity, with a CO2 coefficient of 1.903           change impacts exhibit systematic variation across different
(significant at 1%), indicating that a 1% increase in emissions            ESR quantiles. The MMQR methodological approach allows us
corresponds to approximately a 1.9-­unit increase in ESR. This             to determine if climate change exerts differential effects contin-
exceptionally high sensitivity likely reflects Oman's relatively           gent upon underlying ESR conditions (Bergougui 2025b, 2025c).
limited energy infrastructure diversification and greater expo-            Our hypothesis of asymmetric relationships would be substan-
sure to climate-­related supply disruptions compared to its re-            tiated if the marginal impact of climate change on ESR demon-
gional counterparts. Kuwait demonstrates the second-­highest               strates dependence on the position within the ESR distribution.
climate vulnerability with a coefficient of 0.944, suggesting              To provide comprehensive coverage, our analytical framework
substantial energy security risks from climate change. This                encompasses the 10th through 90th percentiles of the ESR dis-
finding aligns with Kuwait's heavy dependence on fossil fuel               tribution. Figure 4 presents the outcomes of the panel quantile
infrastructure and limited renewable energy adoption, making               model, where the coefficients for CO2 emissions are consistently
the country particularly susceptible to climate-­induced energy            positive across all quantiles examined. These results corroborate

16                                                                                                                  Sustainable Development, 2025
                                                                                                                                          10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 4    |    MMQR results.



our baseline regression findings and indicate an intensification     us to assess whether economic size moderates the link between
of the marginal suppressive effect as one moves toward higher        climate change and ESR.
ESR quantiles. Consequently, this evidence suggests that the
positive nexus between climate change and ESR is particularly        Table 8, columns (1–2), display the outcomes of the regression
pronounced in regions with elevated ESR levels, potentially un-      analysis based on Equation (2), segmented by nations with
dermining energy security frameworks and resilience within           smaller and larger GDPs. For countries with lower GDPs, the
the energy sector.                                                   influence of climate change—quantified through CO2 emis-
                                                                     sions—on ESR shows no statistically significant effect (coeffi-
                                                                     cient = 0.0087, p > 0.10). This may reflect their limited capacity
5   |   Further Analysis                                             to invest in advanced energy infrastructure and their reliance
                                                                     on non-­renewable energy sources, which could buffer short-­
This section examines the varying effects of climate change on       term risks but increase long-­term vulnerabilities. In contrast,
ESR across different countries, taking into account disparities      for higher GDP countries, a one-­unit increase in the climate
in GDP size and population growth rates. By segmenting the           change variable is associated with a 0.1744 unit increase in ESR
sample, the analysis seeks to reveal the subtle ways in which        (p < 0.01). This suggests that despite greater resources, larger
economic magnitude and demographic dynamics influence the            economies are more exposed to the adverse effects of climate
interplay between climate change and EST.                            change on energy security.

                                                                     Further analysis in Columns (3) through (8) of Table 8 incorpo-
5.1   |   High vs. Low GDP Countries                                 rates interaction terms with institutional quality, green patents,
                                                                     and human capital. In higher GDP countries, investments in
GDP represents the economic scale of a nation, shaping its abil-     green patents, institutional quality, and human capital signifi-
ity to allocate resources for robust energy infrastructure while     cantly moderate the impact of climate change on ESR. For ex-
also reflecting its role in contributing to climate change via CO2   ample, the negative CO2*GP interaction term (−0.0452, p < 0.05)
emissions. Countries with higher GDP levels typically have           in Column (6) indicates that green innovations reduce vulner-
greater financial and institutional resources to develop robust      ability in wealthier nations. However, governance challenges
energy systems. However, these nations also tend to produce          such as corruption and political instability in some high GDP
higher CO2 emissions, exacerbating climate change and increas-       countries may undermine these benefits, as suggested by the
ing ESR. To examine these dynamics, we divide the sample into        positive CO2*IQ interaction term (0.0676, p < 0.01) in Column
two groups: countries with GDP above the median (top half) and       (4). These findings highlight the complex interplay between eco-
those below the median (bottom half). This stratification allows     nomic output, climate change, and energy security.



                                                                                                                                    17
                                                                                                                                                                           10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 8    |    Heterogeneous effects of climate change on ESR by economic output.

                         (1)                 (2)                 (3)                 (4)                 (5)                   (6)        (7)                (8)
  CO2                 0.0087             0.1744***          0.1839***           0.1026***            0.0363**           0.1201***      −2.5225***       −0.9211***
                       (0.59)              (6.54)             (14.82)              (6.31)              (2.40)                (4.05)     (−44.82)          (−6.02)
  GDP              −0.2498***          −0.4803***            −0.0487*          −0.1206***          −0.1086***          −0.3987***      −0.1423***       −0.3334***
                      (−9.58)            (−20.65)             (−1.76)             (−4.30)             (−2.92)            (−17.17)       (−7.23)          (−12.61)
  TNRR               0.2156***          0.0823***          −0.0579***          −0.0751***             0.0418*          −0.0795***      −0.1474***        −0.0540*
                       (5.20)              (2.71)             (−2.90)             (−3.75)              (1.84)                (−3.41)    (−9.42)           (−1.80)
  TO                 0.1294***         −0.2219***             0.0395              0.0183            −0.0760**          −0.0633***      0.1785***         0.0752***
                       (4.57)            (−10.97)              (1.42)              (0.73)             (−2.40)                (−3.04)     (8.06)            (3.64)
  ENERGY            −0.7316***          0.0364***          −0.5164***          −0.0337***          −0.6954***          −0.0319***      −1.3447***      −0.0487***
                      (−5.83)              (3.04)             (−6.22)             (−4.28)             (−6.05)                (−4.28)    (−20.38)          (−6.27)
  INDS               0.4752***           0.2341***           0.3101***         −0.1201***           0.3114***                0.0339    0.2733***         −0.0658
                       (17.92)             (7.42)             (14.43)             (−3.43)             (13.38)                (0.85)      (17.32)          (−1.26)
  POP               2.0992***             0.7715*           1.9547***           2.2396***           2.3381***                0.4618    1.7661***         0.8022**
                      (21.95)              (1.92)             (19.93)              (7.04)             (20.82)                (1.19)      (21.59)           (1.98)
  IQ                                                        5.4790***          −1.7074***
                                                              (15.48)             (−4.32)
  CO2*IQ                                                   −0.3783***           0.0676***
                                                             (−16.67)              (2.73)
  GP                                                                                               −1.8823***           0.7785***
                                                                                                      (−8.81)                (2.62)
  CO2*GP                                                                                            0.1254***           −0.0452**
                                                                                                       (8.76)                (−2.45)
  HC                                                                                                                                   −69.944***       −26.775***
                                                                                                                                        (−42.83)          (−6.43)
  CO2*HC                                                                                                                               4.7098***         1.5954***
                                                                                                                                        (44.52)            (6.16)
  R2                   0.745               0.515               0.852               0.691               0.766                  0.531      0.908             0.599
Note: Statistical significance is represented by *, **, and ***, corresponding to levels of 10%, 5%, and 1%, respectively.




5.2   |   High vs. Low Population Growth Countries                                          estimating Equation (2) for the specified groups. In countries
                                                                                            with slower population growth, the impact of climate change on
Population growth intensifies climate change by increasing re-                              ESR is statistically insignificant (coefficient = 0.0027, p > 0.10).
source demand, waste generation, and CO2 emissions, thereby                                 Conversely, in countries with faster population growth, a one-­
complicating efforts to maintain energy security (Ganivet 2020).                            unit increase in the climate change variable is associated with a
Since countries experience population growth at different rates,                            0.1773 unit increase in ESR (p < 0.01), indicating greater vulner-
these variations may influence the weakness of their energy                                 ability. Columns (3) and (4) of Table 9 include interaction terms
systems to climate change and the effectiveness of mitigation                               with institutional quality. In slower-­growing countries, strong
strategies such as institutional quality, green innovations, and                            institutions mitigate the impact of climate change on ESR, as
human capital.                                                                              shown by the negative and significant CO2*IQ interaction term
                                                                                            (−0.2246, p < 0.01).
To investigate this, we divide the sample into two groups:
countries with population growth rates above the median                                     However, in faster-­ growing countries, institutional quality
(faster growth) and those below the median (slower growth).                                 has little effect (CO2*IQ = −0.0288, p > 0.10), suggesting that
Columns (1–2) in Table 9 present the results obtained from                                  rapid population growth may overwhelm governance capacity.

18                                                                                                                                         Sustainable Development, 2025
                                                                                                                                                                            10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 9    |    Heterogeneous impacts of climate change on ESR by population growth rate.

                        (1)                (2)                (3)                (4)                (5)                (6)                 (7)                (8)
  CO2                 0.0027           0.1773***           0.0346**          0.1561***           −0.0093           0.0564***            0.0581          −1.0160***
                      (0.22)             (14.93)            (2.57)             (15.19)            (−0.69)             (3.18)             (1.10)           (−11.51)
  GDP              −0.4472***          0.1223***         −0.2690***          0.1563***         −0.4493***          0.1121***         −0.5075***          0.2373***
                     (−21.34)            (4.89)             (−9.93)             (8.38)           (−21.37)             (4.74)           (−24.88)             (9.44)
  TNRR             −0.1299***         −0.1159***         −0.1760***         −0.1704***         −0.1289***         −0.1017***           −0.0116          −0.2188***
                     (−8.71)            (−4.56)            (−11.60)            (−9.21)            (−8.59)            (−4.17)            (−0.74)            (−9.43)
  TO                0.0824***         −0.1347***          0.0776***          0.1512***          0.0753***         −0.1048***            0.0192          −0.3006***
                      (2.93)            (−6.40)             (2.82)              (8.08)             (2.62)            (−5.26)             (0.73)           (−14.58)
  ENERGY           −0.5730***           −0.0142           0.5995***            0.0026          −0.5939***          −0.0207**         −0.8819***         −0.0591***
                     (−8.60)            (−1.31)              (4.58)             (0.33)            (−8.81)            (−2.03)           (−13.78)            (−6.00)
 INDS               −0.0096            0.3461***           −0.0379           0.2071***           −0.0073           0.3205***         −0.1452***           0.4781***
                     (−0.42)             (8.99)             (−1.59)             (7.19)            (−0.32)             (8.75)            (−6.46)            (13.79)
  POP               2.9188***          1.7185***          1.7039***          1.2144***          2.9234***          1.5139***          3.3558***          0.9934***
                      (11.05)            (16.43)             (5.35)            (15.80)            (10.85)            (15.18)             (8.34)             (9.20)
  IQ                                                      3.3036***           −0.1094
                                                             (8.78)            (−0.24)
  CO2*IQ                                                 −0.2246***           −0.0288
                                                            (−9.14)            (−1.02)
  GP                                                                                             −0.1762          −2.4390***
                                                                                                  (−1.59)            (−9.21)
  CO2*GP                                                                                          0.0121*          0.1613***
                                                                                                   (1.68)             (9.49)
  HC                                                                                                                                   −1.4492          −33.838***
                                                                                                                                        (−0.90)           (−12.50)
  CO2*HC                                                                                                                                0.0057           2.2214***
                                                                                                                                         (0.06)            (13.16)
  N                    1224               1224               1224               1224               1224               1224               1224               1224
  R2                  0.579               0.728              0.615              0.859              0.581              0.760              0.651              0.789
Note: Columns (1) and (2) present baseline results for countries with population growth rates, respectively. Columns (3)–(8) include interaction terms with institutional
quality (IQ), green patents (GP), and human capital (HC). SE is in parentheses. *p < 0.10, **p < 0.05, ***p < 0.01.




Columns (5) through (8) further explore interactions with green                          6   |   Conclusion and Policy Suggestions
patents and human capital, revealing that eco-­friendly innova-
tions and skilled workforces demonstrate reduced effectiveness                           6.1   |   Conclusion
in mitigating ESR in nations experiencing accelerated growth.
For instance, the CO2*GP term (0.1613, p < 0.01) in Column                               The nexus between climate change and ESR represents a crit-
(6) indicates that green patents significantly moderate risks in                         ical challenge for the GCC region, with important theoretical
faster-­growing nations.                                                                 and practical implications for these hydrocarbon-­     dependent
                                                                                         economies. Within the GCC context, climate change threatens
Figure 5 has been developed to provide a detailed visual repre-                          energy infrastructure through extreme weather events and en-
sentation of the interplay between climate change and ESR. This                          vironmental disruptions, undermining the reliability, accessi-
diagram maps out the various channels through which climate                              bility, and affordability of energy supplies across these nations.
change influences ESR, thus offering a clearer understanding of                          Simultaneously, the region's traditional strategies to bolster
these multifaceted relationships.                                                        energy security through carbon-­heavy resources intensify CO2

                                                                                                                                                                      19
                                                                                                                                                  10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 5    |    Visualizing how climate change affects ESR.



emissions, perpetuating a cycle that accelerates climate change         ESR in higher-­GDP GCC economies, while its effect in relatively
and further destabilizes regional energy systems. For GCC coun-         lower-­GDP GCC countries remains statistically negligible. In
tries specifically, theoretical solutions such as advancements in       lower-­GDP GCC settings, stronger institutional quality mitigates
green technology, robust governance, and enhanced human                 climate change impacts, whereas in high-­GDP GCC countries,
capital development offer potential pathways to reduce climate-­        better governance unexpectedly amplifies risks—potentially re-
induced energy security pressures. However, empirical evidence          flecting these advanced GCC economies' greater reliance on com-
supporting these relationships within the GCC regional context          plex, climate-­sensitive energy systems. Our analysis of population
has been limited. To address this knowledge gap, our research           dynamics within the GCC reveals equally important regional
integrates newly compiled datasets on climate change indica-            insights. Climate change impacts on ESR are more pronounced
tors, energy security, green innovation, institutional quality, and     in GCC nations experiencing rapid population growth compared
human capital across GCC countries during 1990 to 2023.                 to those with slower demographic expansion. In GCC countries
                                                                        with lower population growth, institutional quality significantly
Our findings demonstrate that within the GCC region, climate            mitigates climate impacts, while in high-­growth GCC settings,
change markedly heightens ESR—a conclusion that holds ro-               governance improvements show limited effectiveness, likely over-
bustly across diverse model specifications, including sensitivity       whelmed by expanding population pressures on regional energy
analyses, alternative variable selections, and rigorous endogene-       demands and infrastructure.
ity checks. Moreover, our study reveals that for GCC economies,
green patents, strong institutions, and human capital can substan-
tially weaken the adverse effects of climate change on energy secu-     6.2   |   Policy Implications for GCC Countries
rity. Our analysis identifies critical thresholds specific to the GCC
context—namely, 1.43 for green patents, 0.03 for institutional          Our findings have significant policy implications specifically for
quality, and 0.58 for human capital—that act as turning points          GCC countries, where traditional reliance on fossil fuels has been
for these economies. Below these levels, rising emissions directly      central to economic prosperity and energy security strategies. The
amplify ESR across GCC nations. Once these thresholds are sur-          evidence clearly demonstrates that for the GCC region, climate
passed, however, GCC countries are better equipped to leverage          change is a major driver intensifying ESR, requiring GCC poli-
innovation, adaptive policies, and skilled human resources, effec-      cymakers to expedite transitions from carbon-­intensive sources
tively decoupling emissions from energy security risks. Further         to sustainable alternatives tailored to regional conditions. Given
analysis reveals that within the GCC regional context, the effec-       the GCC's abundant solar resources and expansive territories, di-
tiveness of these mediating factors depends heavily on economic         versifying the regional energy mix toward solar and wind power
and demographic conditions. Regarding economic development,             represents a critical opportunity to stabilize energy systems while
we observe patterns specific to GCC economies that challenge            contributing to global climate mitigation efforts. Recognizing
conventional assumptions. Climate change significantly elevates         the unique economic and demographic dynamics across GCC

20                                                                                                                Sustainable Development, 2025
                                                                                                                                                                 10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
economies, policy interventions must be specifically designed                   Role of Green Patents, R&D and Energy Use for Carbon Emissions.”
for regional realities, adapting strategies to the GCC's established            Technological Forecasting and Social Change 200: 123109. https://​doi.​
energy infrastructures and rapid population growth patterns. For                org/​10.​1016/j.​techf​ore.​2 023.​123109.
GCC countries, strengthening institutional frameworks and en-                   Acemoglu, D., U. Akcigit, D. Hanley, and W. Kerr. 2016. “Transition
hancing human capital have proven vital in buffering regional en-               to Clean Technology.” Journal of Political Economy 124, no. 1: 52–104.
ergy systems against emission-­related destabilization. Therefore,              https://​doi.​org/​10.​1086/​684511.
targeted investments in green technology, governance reforms,                   Ahmadov, A. K., and C. van der Borg. 2019. “Do Natural Resources
and education are paramount for the GCC region. To stimulate                    Impede Renewable Energy Production in the EU? A Mixed-­Methods
this transformation across GCC economies, governments should                    Analysis.” Energy Policy 126: 361–369. https://​doi.​org/​10.​1016/j.​enpol.​
                                                                                2018.​11.​0 44.
implement comprehensive supportive measures addressing re-
gional financial and institutional barriers. GCC-­specific recom-               Albahouth, A. A., and M. Tahir. 2025. “Institutional Quality and
mendations include: offering financial incentives like grants and               Climate Vulnerability: Empirical Evidence From GCC Economies.”
subsidies to attract investments in regional renewable energy                   Sustainability 17, no. 5: 2047. https://​doi.​org/​10.​3390/​su170​52047​.
projects; streamlining regulatory reforms to ensure renewable en-               Aldy, J. E., and R. N. Stavins. 2012. “The Promise and Problems of
ergy initiatives progress efficiently within GCC regulatory frame-              Pricing Carbon: Theory and Experience.” Journal of Environment &
works; and fostering public-­private partnerships that leverage the             Development 21, no. 2: 152–180. https://​doi.​org/​10.​1177/​10704​96512​
                                                                                442508.
region's capital markets and expertise for large-­scale clean energy
development. Additionally, creating specialized green financial                 Al-­Maadid, A., M. S. Ben Ali, and K. Si Mohammed. 2025. “The Effect of
instruments—such as Islamic green bonds aligned with regional                   Climate Risk on the Human Development Index Using the Panel Time-­
financial principles and GCC-­focused renewable energy invest-                  Varying Interactive Fixed Effects.” Environmental and Sustainability
                                                                                Indicators 27: 100757. https://​doi.​org/​10.​1016/j.​indic.​2 025.​100757.
ment funds—can enhance market stability across the region.
                                                                                Al-­Maadid, A., M. S. Ben Ali, and I. Younis. 2025. “Climate Change,
Complementing these measures, GCC countries should prior-                       Renewable Energy, and Gulf Cooperation Council Stock Market
                                                                                Dynamics: A Quantile Vector Autoregression and Wavelet Quantile
itize community engagement and public education initiatives
                                                                                Framework.” Energy Reports 14: 1403–1423. https://​doi.​org/​10.​1016/j.​
to foster regional acceptance of sustainable energy transitions.                egyr.​2 025.​07.​035.
Enhancing local workforce capabilities through targeted edu-
                                                                                Al-­
                                                                                   Mekaimi, H. 2025. “The Impact of Energy Security on Inter-­
cation and reskilling programs will reduce the region's reliance
                                                                                Relations Between the Gulf Cooperation Council Countries.” Journal of
on expatriate labor while building indigenous talent pools capa-                Politics and Development 15, no. 1: 67–81.
ble of sustaining clean energy sectors across GCC economies.
Finally, by strengthening regional cooperation on climate ini-                  Almulhim, A. A., N. Inuwa, M. Chaouachi, and A. Samour. 2025.
                                                                                “Testing the Impact of Renewable Energy and Institutional Quality
tiatives and actively participating in international agreements,
                                                                                on Consumption-­Based CO2 Emissions: Fresh Insights From MMQR
GCC countries can reinforce their collective role in sustainable                Approach.” Sustainability 17, no. 2: 704. https://​doi.​org/​10.​3390/​su170​
energy development, effectively balancing economic diversifica-                 20704​.
tion with environmental resilience to safeguard long-­term en-
                                                                                Alqahtani, S. N. 2023. “Can Strict Intellectual Property Laws Facilitate
ergy security across the region.                                                the Renewal of Energy Sector Growth? The Case of Saudi Arabia.”
                                                                                Access to Justice in Eastern Europe 6, no. 3: 132–146. https://​doi.​org/​10.​
                                                                                33327/​​A JEE-­​18-­​6.​3 -­​a000309.

Endnotes                                                                        Al-­Sarihi, A., and N. Mansouri. 2022. “Renewable Energy Development
                                                                                in the Gulf Cooperation Council Countries: Status, Barriers, and Policy
1 See: bloomberg.
                                                                                Options.” Energies 15, no. 5: 1923. https://​doi.​org/​10.​3390/​en150​51923​.
2 To address concerns about this temporal transformation, we use the qua-
                                                                                Arcelay, I., A. Goti, A. Oyarbide-­Zubillaga, T. Akyazi, E. Alberdi, and
 dratic match-­sum methodology (Bergougui 2025a; Pata, Luo, et al. 2023;        P. Garcia-­Bringas. 2021. “Definition of the Future Skills Needs of Job
 U. K. Pata 2025). This systematic temporal disaggregation preserves the        Profiles in the Renewable Energy Sector.” Energies 14, no. 9: 2609.
 integrity of the original annual series while enabling higher-­frequency       https://​doi.​org/​10.​3390/​en140​92609​.
 analysis. The procedure maintains consistency with annual benchmarks
 by ensuring the sum of the twelve-­monthly observations equals the cor-        Azimi, M. N., M. M. Rahman, and T. Maraseni. 2025. “Powering
 responding annual total, thus preventing artificial inflation of the sample    Progress: The Interplay of Energy Security and Institutional Quality in
 size. Unlike simple interpolation, this theory-­driven approach employs        Driving Economic Growth.” Applied Energy 378(PA): 124835. https://​
 relevant high-­frequency indicators to guide the monthly allocation and        doi.​org/​10.​1016/j.​apene​rgy.​2 024.​124835.
 to capture within-­year dynamics and cyclical variation that annual data       Bannaga, A. A., and M. Lezar. 2024. “Total Factor Productivity and
 obscure. As Shahbaz et al. (2017) demonstrate, the method also dampens         Economic Efficiency in the Gulf Cooperation Council (GCC) Countries.”
 erratic point-­to-­point fluctuations, producing more reliable estimates and   Cogent Economics & Finance 12, no. 1: 2426529. https://​doi.​org/​10.​1080/​
 effectively disentangling the underlying trend from seasonal effects.          23322​039.​2 024.​2 426529.
3 We employed the reghdfe command in Stata 18, which performs lin-
                                                                                Baron, R. M., and D. A. Kenny. 1986. “The Moderator-­Mediator Variable
 ear regression with multiple fixed effects, and the xtscc command for          Distinction in Social Psychological Research. Conceptual, Strategic, and
 robustness, which estimates regression with Driscoll-­K raay standard          Statistical Considerations.” Journal of Personality and Social Psychology
 errors with fixed effects.                                                     51, no. 6: 1173–1182. https://​doi.​org/​10.​1037/​0 022-­​3514.​51.6.​1173.
                                                                                Bashir, M. F., U. K. Pata, and L. Shahzad. 2025. “Linking Climate
                                                                                Change, Energy Transition and Renewable Energy Investments to
References
                                                                                Combat Energy Security Risks: Evidence From Top Energy Consuming
Abbas, S., N. Saqib, K. S. Mohammed, N. Sahore, and U. Shahzad.                 Economies.” Energy 314: 134175. https://​doi.​org/​10.​1016/j.​energy.​2 024.​
2024. “Pathways Towards Carbon Neutrality in Low Carbon Cities: The             134175.


                                                                                                                                                           21
                                                                                                                                                                       10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Battisti, L. 2023. “Energy, Power, and Greenhouse Gas Emissions for               Factor to Achieve Sustainability: Evidence From APEC Economies.”
Future Transition Scenarios.” Energy Policy 179: 113626. https://​doi.​           Journal of Cleaner Production 429: 139563. https://​doi.​org/​10.​1016/j.​
org/​10.​1016/j.​enpol.​2 023.​113626.                                            jclep​ro.​2 023.​139563.
Bazilian, M., B. F. Hobbs, W. Blyth, I. MacGill, and M. Howells. 2011.            Cai, Y., X. Li, X. Zhao, and Y. Huang. 2025. “Unveiling the Drivers of
“Interactions Between Energy Security and Climate Change: A Focus                 Environmental Performance by Investigating the Nexus of Energy,
on Developing Countries.” Energy Policy 39, no. 6: 3750–3756. https://​           Economic Complexity and Institutional Quality in G7 Nations.” Scientific
doi.​org/​10.​1016/j.​enpol.​2 011.​0 4.​0 03.                                    Reports 15, no. 1: 10904. https://​doi.​org/​10.​1038/​s4159​8-­​024-­​81727​-­​x.
Ben Ali, M. S., A. Al-­Maadid, and B. Bergougui. 2025. “How Does                  Campagnolo, L., and E. De Cian. 2022. “Distributional Consequences of
Climate Change Asymmetrically Affect Economic Policy Uncertainty                  Climate Change Impacts on Residential Energy Demand Across Italian
in the GCC Countries: A Multivariate Quantile-­On-­Quantile Analysis.”            Households.” Energy Economics 110: 106020. https://​doi.​org/​10.​1016/j.​
Sustainable Futures 10: 101063. https://​doi.​org/​10.​1016/j.​sftr.​2 025.​      eneco.​2 022.​106020.
101063.
                                                                                  Chen, P., S. Zhong, S. Y. Zheng, S. Ullah, and M. Musa. 2024.
Ben Ali, M. S., and A. Al-­Maadid. 2025. “Unveiling Sectoral Markets'             “Quantifying the Influence of Natural Resources Rent, Financial
Responses to Climate Risks in Qatar: A Quantiles Analysis.”                       Development, and Institutional Quality on Energy Security Risk.”
Sustainable Futures 10: 101035. https://​doi.​org/​10.​1016/j.​sftr.​2 025.​      Energy and Environment: 0958305X241266526. https://​doi.​org/​10.​1177/​
101035.                                                                           09583​05X24​1266526.
Bergougui, B. 2024a. “Algeria's Pathway to COP28 and SDGs:                        Chen, X., Q. Fu, and C. P. Chang. 2021. “What Are the Shocks of Climate
Asymmetric Impact of Environmental Technology, Energy Productivity,               Change on Clean Energy Investment: A Diversified Exploration.” Energy
and Material Resource Efficiency on Environmental Sustainability.”                Economics 95: 105136. https://​doi.​org/​10.​1016/j.​eneco.​2021.​105136.
Energy Strategy Reviews 55: 101541. https://​doi.​org/​10.​1016/j.​esr.​2 024.​
                                                                                  Ciarreta, A., M. P. Espinosa, and C. Pizarro-­Irizar. 2014. “Is Green Energy
101541.
                                                                                  Expensive? Empirical Evidence From the Spanish Electricity Market.”
Bergougui, B. 2024b. “Moving Toward Environmental Mitigation in                   Energy Policy 69: 205–215. https://​doi.​org/​10.​1016/j.​enpol.​2014.​02.​025.
Algeria: Asymmetric Impact of Fossil Fuel Energy, Renewable Energy
                                                                                  Crowley, T. J. 2000. “Causes of Climate Change Over the Past
and Technological Innovation on CO2 Emissions.” Energy Strategy
                                                                                  1000 Years.” Science 289, no. 5477: 270–277. https://​doi.​org/​10.​1126/​
Reviews 51: 101281. https://​doi.​org/​10.​1016/j.​esr.​2 023.​101281.
                                                                                  scien​ce.​289.​5 477.​270.
Bergougui, B. 2025a. “Can artificial intelligence mitigate environmen-
                                                                                  Dawoud, M. A. 2005. “The Role of Desalination in Augmentation of
tal inequality? Evidence from leading robotic-­driven economies using
                                                                                  Water Supply in GCC Countries.” Desalination 186, no. 1–3: 187–198.
quantile-­based methods.” Borsa Istanbul Review. https://​doi.​org/​10.​
                                                                                  https://​doi.​org/​10.​1016/j.​desal.​2 005.​03.​0 94.
1016/j.​bir.​2 025.​07.​012.
                                                                                  Dechezleprêtre, A., M. Glachant, I. Haščič, N. Johnstone, and Y.
Bergougui, B. 2025b. “Circular Pathways to Sustainability: Asymmetric
                                                                                  Ménière. 2011. “Invention and Transfer of Climate Change-­Mitigation
Impacts of the Circular Economy on the EU'S Capacity Load Factor.”
                                                                                  Technologies: A Global Analysis.” Review of Environmental Economics
Land 14, no. 6: 1216. https://​doi.​org/​10.​3390/​land1​4 061216.
                                                                                  and Policy 5, no. 1: 109–130. https://​doi.​org/​10.​1093/​reep/​req023.
Bergougui, B. 2025c. “Institutional Adaptability, Skill-­bias Technological
                                                                                  Dehghan Shabani, Z. 2024. “Renewable Energy and CO2 Emissions:
Shifts, and Energy Efficiency in Global Decarbonization Pathways:
                                                                                  Does Human Capital Matter?” Energy Reports 11: 3474–3491. https://​
Exploring the Role of Artificial Intelligence Patents.” Technology in
                                                                                  doi.​org/​10.​1016/j.​egyr.​2 024.​03.​021.
Society 83: 103029. https://​doi.​org/​10.​1016/j.​techs​oc.​2 025.​103029.
                                                                                  Ezeaku, H. C., S. A. Asongu, and J. Nnanna. 2021. “Volatility of
Bergougui, B., and M. I. Aldawsari. 2024. “Asymmetric Impact of
                                                                                  International Commodity Prices in Times of COVID-­19: Effects of Oil
Patents on Green Technologies on Algeria's Ecological Future.” Journal
                                                                                  Supply and Global Demand Shocks.” Extractive Industries and Society 8,
of Environmental Management 355: 120426. https://​doi.​org/​10.​1016/j.​
                                                                                  no. 1: 257–270. https://​doi.​org/​10.​1016/j.​exis.​2 020.​12.​013.
jenvm​an.​2 024.​120426.
                                                                                  Fredriksson, P. G., and D. L. Millimet. 2002. “Strategic Interaction and the
Bergougui, B., S. Mehibel, and R. H. Boudjana. 2024. “Asymmetric
                                                                                  Determination of Environmental Policy across U.S. States.” Journal of Urban
nexus Between Green Technologies, Economic Policy Uncertainty,
                                                                                  Economics 51, no. 1: 101–122. https://​doi.​org/​10.​1006/​juec.​2001.​2239.
and Environmental Sustainability: Evidence From Algeria.” Journal
of Environmental Management 360: 121172. https://​doi.​org/​10.​1016/j.​          Ganivet, E. 2020. “Growth in Human Population and Consumption
jenvm​an.​2 024.​121172.                                                          Both Need to Be Addressed to Reach an Ecologically Sustainable
                                                                                  Future.” Environment, Development and Sustainability 22, no. 6: 4979–
Bergougui, B., and S. Meziane. 2025. “Assessing the Impact of Green
                                                                                  4998. https://​doi.​org/​10.​1007/​s1066​8-­​019-­​0 0446​-­​w.
Energy Transition, Technological Innovation, and Natural Resources
on Load Capacity Factor in Algeria: Evidence From Dynamic                         Gentile, G., and J. Gupta. 2025. “Orchestrating the Narrative: The Role of
Autoregressive Distributed Lag Simulations and Machine Learning                   Fossil Fuel Companies in Delaying the Energy Transition.” Renewable
Validation.” Sustainability (Switzerland) 17, no. 5: 1815. https://​doi.​org/​    and Sustainable Energy Reviews 212: 115359. https://​doi.​org/​10.​1016/j.​
10.​3390/​su170​51815​.                                                           rser.​2 025.​115359.
Bergougui, B., S. M. Murshed, M. Shahbaz, M. A. Zambrano-­                        Giganti, P., C. Barra, and P. M. Falcone. 2025. “Unveiling the nexus of
Monserrate, A. Samour, and M. I. Aldawsari. 2025. “Towards Secure                 Institutional Quality and Renewable Energy Utilizing a Topic Modelling
Energy Systems: Examining Asymmetric Impact of Energy Transition,                 Approach.” Renewable and Sustainable Energy Reviews 214: 115516.
Environmental Technology and Digitalization on Chinese City-­L evel               https://​doi.​org/​10.​1016/j.​rser.​2 025.​115516.
Energy Security.” Renewable Energy 238: 121883. https://​doi.​org/​10.​
1016/j.​renene.​2 024.​121883.                                                    Giuli, M. 2022. “Geopolitics of the Energy Transition.” In Handbook
                                                                                  of Energy Transitions, 41–60. Springer. https://​doi.​org/​10.​1201/​97810​
Bui, T. H., H. P. Bui, and T. M. A. Pham. 2024. “Effects of Temperature           03315​353-­​4.
on Job Insecurity: Evidence From Australia.” Economic Analysis and
Policy 82: 264–276. https://​doi.​org/​10.​1016/j.​eap.​2 024.​03.​011.           Gortan, M., L. Testa, G. Fagiolo, and F. Lamperti. 2024. “A Unified
                                                                                  Dataset for Pre-­    Processed Climate Indicators Weighted by Gridded
Caglar, A. E., U. K. Pata, M. Ulug, and M. W. Zafar. 2023. “Examining             Economic Activity.” Scientific Data 11, no. 1: 533. https://​doi.​org/​10.​
the Impact of Clean Environmental Regulations on Load Capacity                    1038/​s 4159​7- ­​024- ­​03304 ​-­​1.


22                                                                                                                                   Sustainable Development, 2025
                                                                                                                                                                                10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Ha, L. T. 2025. “Rethinking Energy Security in the Condition of High                 King, M. D. B., and J. Gulledge. 2014. “Climate Change and Energy
Climate Risk: Fresh Insights From New Estimation.” Management                        Security: An Analysis of Policy Research.” Climatic Change 123, no. 1:
of Environmental Quality 36, no. 3: 741–773. https://​doi.​org/​10.​1108/​           57–68. https://​doi.​org/​10.​1007/​s1058​4 -­​013-­​0895-­​0.
MEQ- ­​0 6-­​2 024- ­​0235.
                                                                                     Krugman, P. 1991. “Increasing Returns and Economic Geography.”
Hegerl, G. C., S. Brönnimann, T. Cowan, et al. 2019. “Causes of Climate              Journal of Political Economy 99, no. 3: 483–499. https://​doi.​org/​10.​1086/​
Change Over the Historical Record.” Environmental Research Letters 14,               261763.
no. 12: 123006. https://​doi.​org/​10.​1088/​1748-­​9326/​ab4557.
                                                                                     Lenihan, H., H. McGuirk, and K. R. Murphy. 2019. “Driving Innovation:
Hille, E., and C. Angerpointner. 2025. “Did Geopolitical Risks in                    Public Policy and Human Capital.” Research Policy 48, no. 9: 103791.
Supplier Countries of Fossil Fuels Lead to Reduced Domestic Energy                   https://​doi.​org/​10.​1016/j.​respol.​2 019.​0 4.​015.
Consumption? Evidence From Europe.” Energy Policy 198: 114499.
                                                                                     Lewbel, A. 2012. “Using Heteroscedasticity to Identify and Estimate
https://​doi.​org/​10.​1016/j.​enpol.​2 025.​114499.
                                                                                     Mismeasured and Endogenous Regressor Models.” Journal of Business
Hoechle, D. 2007. “Robust Standard Errors for Panel Regressions With                 and Economic Statistics 30, no. 1: 67–80. https://​doi.​org/​10.​1080/​07350​
Cross-­Sectional Dependence.” Stata Journal 7, no. 3: 281–312. https://​             015.​2 012.​6 43126.
doi.​org/​10.​1177/​15368​67x07​0 0700301.
                                                                                     Lim, J. S., and Y. G. Kim. 2012. “Combining Carbon Tax and R&D
Hrnčić, B., A. Pfeifer, F. Jurić, N. Duić, V. Ivanović, and I. Vušanović.            Subsidy for Climate Change Mitigation.” Energy Economics 34, no.
2021. “Different Investment Dynamics in Energy Transition Towards a                  SUPPL. 3: S496–S502. https://​doi.​org/​10.​1016/j.​eneco.​2 012.​0 4.​012.
100% Renewable Energy System.” Energy 237: 121526. https://​doi.​org/​
                                                                                     Lin, S., X. Long, J. Huang, and R. Gao. 2023. “Green Technology
10.​1016/j.​energy.​2 021.​121526.
                                                                                     Diversification, Technology Vertical Spillovers, and Energy Intensity in
Internatioanl Renewable Energy Agency. 2022. “Renewable Energy and                   Chinese Cities.” Energy for Sustainable Development 76: 101281. https://​
Jobs: Annual Review 2022.” International Renewable Energy Agenc                      doi.​org/​10.​1016/j.​esd.​2 023.​101281.
(Issue October). https://​www.​aer.​gov.​au/​system/​files/​​AER. Guidance
                                                                                     Liu, Y., H. Xiao, P. Zikhali, and Y. Lv. 2014. “Carbon Emissions in China:
Note for coal production assessment – July 2023 – FINAL v1.02.pdf.
                                                                                     A Spatial Econometric Analysis at the Regional Level.” Sustainability 6,
IRENA. 2019. “National Policies and the Role of Communities,                         no. 9: 6005–6023. https://​doi.​org/​10.​3390/​su609​6 005.
Cities and Regions.” International Renewable Energy (June). www.​
                                                                                     Liu, Z., Y. Wang, X. Yuan, Z. Ding, and Q. Ji. 2025. “Geopolitical Risk
irena.​org.
                                                                                     and Vulnerability of Energy Markets.” Energy Economics 141: 108055.
IRENA. 2023. Renewable Energy Markets: GCC 2023. International                       https://​doi.​org/​10.​1016/j.​eneco.​2 024.​108055.
Renewable Energy Agency. https://​cisp.​cache​f ly.​net/​assets/​artic​les/​
                                                                                     Loucks, D. P. 2021. “Impacts of Climate Change on Economies,
attac​hments/​92195_​irena_​rnewa​ble_​energy_​marke​ts_​gcc_​2 023.​pdf.
                                                                                     Ecosystems, Energy, Environments, and Human Equity: A Systems
Iyke, B. N. 2024. “Climate Change, Energy Security Risk, and Clean                   Perspective.” In The Impacts of Climate Change: A Comprehensive Study
Energy Investment.” Energy Economics 129, no. November 2023:                         of Physical, Biophysical, Social, and Political Issues, edited by Letcher, T.
107225. https://​doi.​org/​10.​1016/j.​eneco.​2 023.​107225.                         M. B. T.-­T. I. of C. C, 19–50. Elsevier. https://​doi.​org/​10.​1016/​B978-­​0 -­​12-­​
                                                                                     82237​3 -­​4.​0 0016​-­​1.
Kahn, M. E., K. Mohaddes, R. N. C. Ng, M. H. Pesaran, M. Raissi, and J.
C. Yang. 2021. “Long-­Term Macroeconomic Effects of Climate Change:                  Luft, G., A. Korin, and E. Gupta. 2010. “Energy Security and Climate
A Cross-­Country Analysis.” Energy Economics 104: 105624. https://​doi.​             Change: A Tenuous Link.” In The Routledge Handbook of Energy
org/​10.​1016/j.​eneco.​2 021.​105624.                                               Security, 43–55. Routledge.

Karasoy, A. 2023. “Assessing the Impacts of Industrialization,                       Machado, J. A. F., and J. M. C. Santos Silva. 2019. “Quantiles via mo-
Deindustrialization and Financialization on Turkey's Energy Security:                ments.” Journal of Econometrics 213, no. 1: 145–173. https://​doi.​org/​10.​
Evidence From the Augmented NARDL Method.” International Journal                     1016/j.​jecon​om.​2 019.​0 4.​0 09.
of Energy Sector Management 17, no. 6: 1053–1073. https://​doi.​org/​10.​
                                                                                     Mares, D. M., and K. W. Moffett. 2016. “Climate Change and
1108/​I JESM​- ­​07-­​2 022-­​0 014.
                                                                                     Interpersonal Violence: A “Global” Estimate and Regional Inequities.”
Kartal, M. T., U. K. Pata, Ö. Depren, and S. Erdogan. 2023. “Effectiveness           Climatic Change 135, no. 2: 297–310. https://​doi.​org/​10.​1007/​s1058​
of Nuclear and Renewable Electricity Generation on CO2 Emissions:                    4- ­​015-­​1566- ­​0.
Daily-­Based Analysis for the Major Nuclear Power Generating
                                                                                     Mideksa, T. K., and S. Kallbekken. 2010. “The Impact of Climate
Countries.” Journal of Cleaner Production 426: 139121. https://​doi.​org/​
                                                                                     Change on the Electricity Market: A Review.” Energy Policy 38, no. 7:
10.​1016/j.​jclep​ro.​2 023.​139121.
                                                                                     3579–3585. https://​doi.​org/​10.​1016/j.​enpol.​2 010.​02.​035.
Keller, W. 2004. “International Technology Diffusion.” Journal of
                                                                                     Mininni, G. M., T. J. Foxon, C. Copeland, et al. 2024. “Increasing
Economic Literature 42, no. 3: 752–782. https://​doi.​org/​10.​1257/​0 0220​
                                                                                     Wellbeing Through Energy Demand Reduction for Net Zero: Citizen
51042​177685.
                                                                                     Perceptions of Co-­Benefits of Local Measures.” Energy Research and
Khan, K., A. Khurshid, J. Cifuentes-­Faura, and D. Xianjun. 2024. “Does              Social Science 118: 103799. https://​doi.​org/​10.​1016/j.​erss.​2 024.​103799.
Renewable Energy Development Enhance Energy Security?” Utilities
                                                                                     Moossa, B., P. Trivedi, H. Saleem, and S. J. Zaidi. 2022. “Desalination
Policy 87, no. January: 101725. https://​doi.​org/​10.​1016/j.​jup.​2 024.​101725.
                                                                                     in the GCC Countries-­a Review.” Journal of Cleaner Production 357:
Kheyfets, I., S. El-­      Saharty, C. H. Herbst, and M. I. Ajwad. 2020.             131717. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 022.​131717.
“Fostering Human Capital in the Gulf Cooperation Council Countries.”
                                                                                     Morikawa, M. 2012. “Population Density and Efficiency in Energy
In Fostering Human Capital in the Gulf Cooperation Council Countries.
                                                                                     Consumption: An Empirical Analysis of Service Establishments.”
World Bank Publications. The World Bank Group. https://​doi.​org/​10.​
                                                                                     Energy Economics 34, no. 5: 1617–1622. https://​doi.​org/​10.​1016/j.​eneco.​
1596/​978-­​1- ­​4 648-­​1582-­​9.
                                                                                     2012.​01.​0 04.
Kim, J. 2024. “Energy Security and the Green Transition.” IMF Working
                                                                                     Neale, P. J., S. Hylander, A. T. Banaszak, et al. 2025. “Environmental
Papers 2024(006): 1. https://​doi.​org/​10.​5089/​97984​0 0263​743.​0 01.
                                                                                     Consequences of Interacting Effects of Changes in Stratospheric Ozone,
Kim, J., F. Jaumotte, A. J. Panton, and G. Schwerhoff. 2025. “Energy                 Ultraviolet Radiation, and Climate: UNEP Environmental Effects
Security and the Green Transition.” Energy Policy 198: 114409. https://​             Assessment Panel, Update 2024.” Photochemical and Photobiological
doi.​org/​10.​1016/j.​enpol.​2 024.​114409.                                          Sciences 24, no. 3: 357–392. https://​doi.​org/​10.​1007/​s 4363​0 -­​025-­​0 0687​-­​x.


                                                                                                                                                                         23
                                                                                                                                                                    10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Nilsson, L. J. 2011. “Governing the Transition to Low-­Carbon Energy                 Salisu, A. A., A. O. Olaniran, and X. V. Vo. 2025. “Geopolitical Risk,
and Transport Systems.” Carbon Management 2, no. 2: 105–107. https://​               Climate Risk and Financial Innovation in the Energy Market.” Energy
doi.​org/​10.​4155/​cmt.​11.​7.                                                      315: 134365. https://​doi.​org/​10.​1016/j.​energy.​2 025.​134365.
OECD. 2019. “Governance Challenges for Critical Infrastructure                       Shahbaz, M., M. Shafiullah, V. G. Papavassiliou, and S. Hammoudeh.
Resilience.” In OECD Reviews of Risk Management Policies. Organisation               2017. “The CO2–Growth nexus Revisited: A Nonparametric Analysis for
for Economic Co-­operation and Development. https://​doi.​org/​10.​1787/​            the G7 Economies Over Nearly Two Centuries.” Energy Economics 65:
05338​892-­​en.                                                                      183–193. https://​doi.​org/​10.​1016/j.​eneco.​2 017.​05.​0 07.
Panos, E., R. Kannan, S. Hirschberg, and T. Kober. 2023. “An                         Stef, N., H. Başağaoğlu, D. Chakraborty, and S. Ben Jabeur. 2023.
Assessment of Energy System Transformation Pathways to Achieve                       “Does Institutional Quality Affect CO2 Emissions? Evidence From
Net-­Zero Carbon Dioxide Emissions in Switzerland.” Communications                   Explainable Artificial Intelligence Models.” Energy Economics 124:
Earth & Environment 4, no. 1: 157. https://​doi.​org/​10.​1038/​s 4324​7-­​023-­​    106822. https://​doi.​org/​10.​1016/j.​eneco.​2 023.​106822.
00813​- ­​6.
                                                                                     Tansel Tugcu, C., and A. N. Menegaki. 2024. “The Impact of Renewable
Pata, U. K. 2025. “Towards a Sustainable Future With Renewable                       Energy Generation on Energy Security: Evidence From the G7
Energy and Load Capacity Factor: Institutions, Technology, Energy and                Countries.” Gondwana Research 125: 253–265. https://​doi.​org/​10.​1016/j.​
Climate Policy Uncertainties.” Renewable Energy 254: 123710. https://​               gr.​2 023.​08.​018.
doi.​org/​10.​1016/j.​renene.​2 025.​123710.
                                                                                     Tol, R. S. J. 2002. “Estimates of the Damage Costs of Climate Change:
Pata, U. K., and A. E. Hizarci. 2022. “Investigating the Environmental               Part 1: Benchmark Estimates.” Environmental and Resource Economics
Kuznets Curve in the Five Most Complex Countries: Insights From a                    21, no. 1: 47–73. https://​doi.​org/​10.​1023/A:​10145​0 0930521.
Modified Ecological Footprint Model.” Energy & Environment 34, no. 8:
                                                                                     Vrochidis, C. K., and M. Chalaris. 2023. “Interactions Between Energy
2990–3019. https://​doi.​org/​10.​1177/​0 9583​05X22​1120255.
                                                                                     Security and Climate Crisis: A Focus on East Mediterranean.” In The
Pata, U. K., S. Karlilar, and B. S. Eweade. 2025. “An Environmental                  Challenges of Disaster Planning, Management. and Resilience.
Assessment of Non-­Renewable, Modern Renewable, and Combustible
                                                                                     Wang, Q., X. Wang, and R. Li. 2024. “Geopolitical Risks and Energy
Renewable Energy in Cameroon.” Environment, Development and
                                                                                     Transition: The Impact of Environmental Regulation and Green
Sustainability 27, no. 3: 7279–7296. https://​doi.​org/​10.​1007/​s1066​8-­​023-­​
                                                                                     Innovation.” Humanities and Social Sciences Communications 11, no. 1:
04192​-­​y.
                                                                                     1272. https://​doi.​org/​10.​1057/​s 4159​9 -­​024-­​03770​-­​3.
Pata, U. K., M. T. Kartal, and S. Erdogan. 2023. “Analyzing the EKC
                                                                                     Wang, X., M. G. Stewart, and M. Nguyen. 2012. “Impact of Climate
Hypothesis for Technologically Advanced Countries: The Role of ICT
                                                                                     Change on Corrosion and Damage to Concrete Infrastructure in
and Renewable Energy Technologies.” Journal of Cleaner Production
                                                                                     Australia.” Climatic Change 110, no. 3–4: 941–957. https://​doi.​org/​10.​
426: 139088. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 023.​139088.
                                                                                     1007/​s1058​4 -­​011-­​0124-­​7.
Pata, U. K., R. Luo, M. T. Kartal, T. S. Adebayo, and S. Ullah. 2023. “Do
                                                                                     WB. 2013. “Renewable Energy Desalination: An Emerging Solution
Technological Innovations and Clean Energies Ensure CO2 Reduction
                                                                                     to Close the Water Gap in MENA.” In Desalination Updates. World
in China? A Novel Nonparametric Causality-­In-­Quantiles.” Energy &
                                                                                     Bank Document. www.​world​bank.​org/​mna/​water​gap%​0Ahtt​p://​w ww.​
Environment 36, no. 6: 2815–2835. https://​doi.​org/​10.​1177/​0 9583​05X23​
                                                                                     awwa.​org/​store/​​produ​ctdet​ail.​aspx?​produ​ctid=​26639​.
1210993.
                                                                                     Worku, M. Y. 2022. “Recent Advances in Energy Storage Systems
Pata, U. K., and S. Yurtkuran. 2022. “Is the EKC Hypothesis Valid
                                                                                     for Renewable Source Grid Integration: A Comprehensive Review.”
in the Five Highly Globalized Countries of the European Union? An
                                                                                     Sustainability 14, no. 10: 5985. https://​doi.​org/​10.​3390/​su141​05985​.
Empirical Investigation With Smooth Structural Shifts.” Environmental
Monitoring and Assessment 195, no. 1: 17. https://​doi.​org/​10.​1007/​s1066​        Yao, Y., K. Ivanovski, J. Inekwe, and R. Smyth. 2020. “Human Capital
1-­​022-­​10660​-­​1.                                                                and CO2 Emissions in the Long Run.” Energy Economics 91: 104907.
                                                                                     https://​doi.​org/​10.​1016/j.​eneco.​2 020.​104907.
Pesaran, M. H. 2006. “Estimation and Inference in Large Heterogeneous
Panels With a Multifactor Error Structure.” Econometrica 74, no. 4: 967–             Zhang, Y., Y. Shan, X. Zheng, et al. 2023. “Energy Price Shocks Induced
1012. https://​doi.​org/​10.​1111/j.​1468-­​0262.​2 006.​0 0692.​x.                  by the Russia-­U kraine Conflict Jeopardize Wellbeing.” Energy Policy
                                                                                     182: 113743. https://​doi.​org/​10.​1016/j.​enpol.​2 023.​113743.
Porter, M. E. 1998. “Clusters and the New Economics of Competition.”
Harvard Business Review 76, no. 6: 77–90.                                            Zhou, K., J. Yang, T. Yang, and T. Ding. 2023. “Spatial and Temporal
                                                                                     Evolution Characteristics and Spillover Effects of China's Regional
Rahman, T., M. S. Hossain Lipu, M. M. Alom Shovon, I. Alsaduni, T. F.
                                                                                     Carbon Emissions.” Journal of Environmental Management 325: 116423.
Karim, and S. Ansari. 2025. “Unveiling the Impacts of Climate Change
                                                                                     https://​doi.​org/​10.​1016/j.​jenvm​an.​2 022.​116423.
on the Resilience of Renewable Energy and Power Systems: Factors,
Technological Advancements, Policies, Challenges, and Solutions.”
Journal of Cleaner Production 493: 144933. https://​doi.​org/​10.​1016/j.​
jclep​ro.​2 025.​144933.
Ramião, J. P., C. Carvalho-­Santos, R. Pinto, and C. Pascoal. 2023.
“Hydropower Contribution to the Renewable Energy Transition Under
Climate Change.” Water Resources Management 37, no. 1: 175–191.
https://​doi.​org/​10.​1007/​s1126​9 -­​022-­​03361​- ­​4.
Roodman, D. 2009. “How to Do xtabond2: An Introduction to Difference
and System GMM in Stata.” Stata Journal 9, no. 1: 86–136. https://​doi.​
org/​10.​1177/​15368​67x09​0 0900106.
Sadorsky, P. 2011. “Trade and Energy Consumption in the Middle East.”
Energy Economics 33, no. 5: 739–749. https://​doi.​org/​10.​1016/j.​eneco.​
2010.​12.​012.




24                                                                                                                                  Sustainable Development, 2025
                                                                                                                                                                                       10991719, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/sd.70244 by Brahim Bergougui - Qatar University , Wiley Online Library on [23/01/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Appendix A


TABLE A1    |    Cross-­sectionally augmented Dickey–Fuller (CADF) test.

  Variables                 CADF—Level I(0)                       CADF—Difference I(1)                        CIPS—Level I(0)                      CIPS—Difference I(1)
  ESR                             −2.900***                                −4.051***                                  0.287                                  −3.819***
  CO2                             −2.775***                                −4.696***                                 −2.264                                  −4.749***
  TEM                             −3.197***                                −4.580***                                 −0.377                                  −4.474***
  PRE                               −2.314                                 −5.756***                                 −0.004                                  −5.949***
  GUST                            −3.862***                                −4.968***                                 −0.791                                  −4.881***
  SPEI                            −3.007***                                −4.096***                                  0.405                                  −4.279***
  GP                              −2.718***                                −3.843***                                −3.037***                                −3.695***
  IQ                               −2.395**                                −4.783***                                  0.461                                  −4.862***
  HC                              −2.910***                                −4.736***                                 −1.322                                  −4.566***
  GDP                             −2.718***                                −3.843***                                −3.037***                                −3.695***
  TNRR                             −2.395**                                −4.783***                                  0.461                                  −4.862***
  TO                              −2.910***                                −4.736***                                 −1.322                                  −4.566***
  RE                              −4.204***                                −3.626***                                 −0.473                                  −3.900***
  INDS                            −3.759***                                −5.074***                                 −1.563                                  −4.976***
  POP                               −1.178                                 −3.041***                                 −0.763                                  −2.989***
Note: *** and ** denote rejection of the null hypothesis of unit root (i.e., stationarity) at the 1% and 5%, significance levels, respectively.



TABLE A2    |    Outcomes of Pesaran's test of cross sectional                              TABLE A3    |    Pedroni test for cointegration.
independence.
                                                                                              Estimates                                       Statistic                    p
  Models                            Pesaran CD                         Prob.                  Model 1 (CO2)
  CO2                                   8.212                         0.0000                    Modified Phillips–Perron t                        4.618***               0.0000
  TEM                                   8.505                         0.0000                    Phillips–Perron t                                 6.299***               0.0000
  PRE                                   8.392                         0.0000                  Augmented Dickey–Fuller t                       12.548***                  0.0000
  GUST                                  6.961                         0.0000                  Model 2 (Temperature)
  SPEI                                  8.208                         0.0000                    Modified Phillips–Perron t                        3.753***               0.0001

                                                                                                Phillips–Perron t                                 4.733***               0.0000

                                                                                                Augmented Dickey–Fuller t                         9.028***               0.0000

                                                                                              Model 3 (Precipitation)

                                                                                                Modified Phillips–Perron t                        4.024***               0.0000

                                                                                                Phillips–Perron t                                 4.989***               0.0000

                                                                                                Augmented Dickey–Fuller t                         8.104***               0.0000

                                                                                              Model 4 (Wind Gust)

                                                                                                Modified Phillips–Perron t                        4.227***               0.0000

                                                                                                Phillips–Perron t                                 5.460***               0.0000

                                                                                                Augmented Dickey–Fuller t                         8.426***               0.0000

                                                                                              Model 5 (SPEI)

                                                                                                Modified Phillips–Perron t                        3.656***               0.0001

                                                                                                Phillips–Perron t                                 4.079***               0.0000

                                                                                                Augmented Dickey–Fuller t                         2.443***               0.0073
                                                                                            Note: *** denotes statistical significance at the 1% level. H0: No cointegration. All
                                                                                            models include panel-­specific cointegrating vectors, panel means, Bartlett kernel
                                                                                            with 5 Newey-­West lags, and 1 augmented lag.


                                                                                                                                                                                  25
