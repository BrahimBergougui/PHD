Environment, Development and Sustainability
https://doi.org/10.1007/s10668-024-05715-x




Impact of environmental technology, economic complexity,
and geopolitical risk on carbon emission inequality
in developed and developing countries: evidence
from a PVAR‑GMM approach

Brahim Bergougui1,2          · Buhari Doğan3,4,5 · Sudeshna Ghosh6 · Hicham Ayad7

Received: 12 August 2024 / Accepted: 14 November 2024
© The Author(s) 2024


Abstract
Climate change and disparities among economic groups represent significant challenges
confronting the global community today. Inadequate action against climate change is likely
to worsen economic inequalities, while these inequalities can hinder the effective execu-
tion of climate change initiatives. Against this backdrop this study examines the impact
of ENT on carbon emissions inequality (CEI) to develop equitable and inclusive mitiga-
tion strategies. Using a unique GMM-PVAR approach, we analyze structural dynamics in a
panel dataset of 41 developing and developed countries for 1990–2020. This method is effi-
cient and robust. It is capable of taking into account the structural dynamism in the data.
Further this method can tackle the endogeneity in the concerned data sets. The empirical
models account for geopolitical risk, economic complexity, total natural resource rents, and
GDP growth as potential influencers of CEI. Our findings reveal that: (1) ENT negatively
impacts CEI, underscoring its importance in reduction efforts; (2) economic complexity
exhibits a negative relationship with CEI, implying it contributes to its reduction; (3) geo-
political risk, natural resources, and GDP growth all positively impact CEI, hindering its
reduction; (4) impulse response analysis shows that shocks to ENT induce an initial inverse
response in CEI, followed by oscillating inverse responses over ten periods; and (5) cau-
sality test corroborates these results and indicate no reverse causality. The robustness test
based on impulse response function and heterogeneous causality test confirm the earlier
findings. The empirical outcomes reveal a negative effect of ENT on CEI, showing that
any upsurge of one unit in ENT leads to a decline in the CEI by 1.09 units in the long run.
Remarkably, a unit increase in geopolitical risk will automatically contribute to an escala-
tion of CEI by 5.977 units. The results from Impulse Response Analysis documents how
CEI responds to the shocks in the independent variables over ten periods. The analysis
demonstrates that any shock in the ENT will stimulate an inverse response to CEI in the
first period and then oscillate across inverse response over a period of 10 periods Grounded
on these outcomes, the study concludes with potential policy implications to promote equi-
table and sustainable CEI reduction strategies. The government of the concerned countries
should embrace environmental policies to enhance the application of ENT to stimulate the
harmonious effects. The government can implement carbon pricing system that will create
economic incentive for individuals and companies to reduce emissions and invest in clean
technologies.

Extended author information available on the last page of the article


                                                                          Vol.:(0123456789)
                                                                               B. Bergougui et al.


Graphical abstract


                       Environmental Technology




                                    (-)
                 (+)                               (-)
                                Carbon
                              Inequality                 Economic Complexity




                                      (+)
                               Natural Resources




Keyword CO2 emissions inequality · Environmental technology · Developed and
developing economies · GMM-PVAR

Abbreviations
Carbon di oxide	CO2
Generalized method of moments for panel vector auto-regressive	GMM-PVAR
Environmental Technology	ENT
Carbon Emissions Inequality	CEI
Economic Complexity Index	ECI
Geopolitical Risk	GPR
Total natural resources	NR
Coefficient of variation	CV
Cross-sectional dependence	CSD
Ordinary Least Squares	OLS
Significance level	SL
Vector Autoregression	VAR


1 Introduction

The world today is concerned about the steps to be taken to mitigate climate change.
Climate change has caused natural disasters and health hazards upon human beings.
At the center of the mitigation lies the task of reducing carbon emissions (Zhao, et al.
2024a, 2024b). Again, there is an emerging problem of carbon emission inequality in
the case of carbon emission neutrality. The problem of carbon emission inequality is
associated with the concern for economic and social equity and fairness (Bergougui
et al., 2024c; Chancel, 2022; Dong et al. 2023). It focuses upon unequal allocations of
obligations for mitigation of wealth across the richer and poorer sections (Zhao et al.
2022; Wu & Chen, 2023). Across income groups there is disparity in carbon emana-
tions. Persons belonging to higher income countries are accountable for 30 times more
Impact of environmental technology, economic complexity,…


emissions in comparison to the low-income countries. Low-income countries have an
emission level of 0.6 per cent while the higher income countries are accountable for 34
per cent of the emissions (Zhao et al. 2024a, 2024b). Further there are 771 million peo-
ple who are top ten per cent emitters. In contrast the bottom 50 per cent emitters consist
of 3.8 billon individuals.
    The recently held Conference of Parties (COP 28) pledged to hasten the process of
energy transition. The Global Goal on Adaptation stressed to cover themes such as water,
food, livelihood and poverty eradication to achieve the climate change targets. The meeting
at the COP 28 agreed that progress towards reducing green house gas emissions have been
too slow. The summit agreed to strengthen resilience to get financial and technological sup-
port for the vulnerable nations. The COP 28 stressed the need to correct ongoing inequali-
ties and seek balanced responses to climate change.
    The carbon emission inequality brings to the forefront that the richer individuals
have higher footprints on carbon owing to higher doses of consumption. Such practices
lead to larger doses of energy intensive activities (Wang et al. 2022). The carbon emis-
sion inequality has adverse consequences on social equity. This is particularly because a
small section of the population is accountable for an excessive emission. Such processes
generates an unreasonable pressure on those who have minimal contribution to climate
variation(Allafta, and Opp,. 2024). Such activities can add to the existing inequalities, as
the vulnerable and marginalized sections of the society may put up with the problem of
climate change, though they do not contribute largely to the problem (Chen et al. 2019a,
2019b). There is an urgent need to address the concerns on carbon emanation inequality. It
is crucial to ensure that the cost and benefit of climate action have an equitable distribution.
Such course of action would lead to a just and sustainable society (Adebayo et al. 2024;
Lomborg, 2020).There is an pressing need to address carbon emanation inequality issues
for ensuring that the affluent sections of the society reduce emissions, and the poorer sec-
tions have access to clean technologies. Such practices will create sustainable and unbiased
society.
    The agreements in the Kyoto Protocol and Paris Agreements and the recent COP 28
have highlighted the importance of zero carbon production and consumption. To foster
zero carbon emissions the agreements highlighted the need to adopt ENT. The objective
of the current study is to scrutinize how ENT help to reduce carbon emission inequality.
ENT reduces emission levels and improves productivity (Hussain & Dogan, 2021, Has-
san et al. 2023). The environmental related technologies generate efficiency in the process
of production and also serves as the alternative to emission intensive technologies. The
Global ENT Market was around USD 576.39 billion in 2022 and it is expected to grow to
about USD 746.31 billion by 2028.The ENT are instrumental in promoting environmental
sustainability.
    Accordingly, the major research question that the paper addresses is how ENT help to
mitigate emission inequality. Some research have explored some impelling factors such as
structures of production (Adebayo et al. 2023a; Chen et al. 2017; Xu, 2023), intensity of
energy (Adebayo et al. 2023b; Chen et al. 2019a, 2019b; Xu et al. 2022), population (Wang
et al. 2022), transition of energy (Alola et al. 2023; Krey et al. 2012) that can impact car-
bon emission inequality. At the same time ENT is also believed to assist in carbon emis-
sion inequality through transition in production structure. To address the research question
panel data sets from developed and developing countries from 1980 to 2019 has been used.
Attention has been paid to control variables like ECI, GPR, NR and GDP growth.
    The study contributes to the extant literature in three major ways.
                                                                             B. Bergougui et al.


• First the study has delved into a relatively unexplored causal relation amid ENT and
  carbon emission inequality. While the literature deliberates on some other drivers of
  carbon emission inequality, the role of ENT has been largely unnoticed. In this situa-
  tion the extant literature is expanded on the impact of ENT on carbon emission inequal-
  ity by using number of granted green patents as a measure of ENT. The number of
  sanctioned green patents represent a tangible indicator of ENT.
• Second the empirical outcomes of the study offer crucial policy suggestions on the
  discourse on carbon intensive lifestyle and income inequality. The empirical outcomes
  provide policy directions for the trajectory on SDG-13 on climate change and SDG-10
  on social equity.
• Last there has been addition on to the empirical literature methodologically. The novel
  GMM-PVAR method as conducted by by Sigmund and Ferstl (2021) has been applied.
  This method is efficient and robust. It is capable of taking into account the structural
  dynamics in the data. Further this method can meticulously deal with the endogeneity
  in the concerned data sets. The amount of works applying this unique methodology is
  limited and this is the first study on ENT and carbon emission inequality harnessing the
  novel method.

   The study produces interesting findings. First, the outcomes reveal a negative effect
of ENT on carbon emission inequality. The rich are able to buy environmentally friendly
products because of their environmental awareness and purchasing power. Such processes
lead to the decline in emission levels and lessens the gap across the emission level of the
rich and the poor. Besides, the outcomes reveal a negative association amid economic com-
plexity and carbon emission inequality, indicating that economic complexity contributes
to lessening carbon emanation inequality in the sample countries over the period of study.
High levels of economic complexity contribute significantly to enhance energy efficiency
through the energy and carbon intensities channels. Nonetheless a unit increase in geo-
political risk contribute to the rise in carbon emission inequality by 5.977 units. Further
increase in GDP by one unit leads to escalation of carbon emission inequality by 3.859
units. Further the causality analysis reveal unidirectional casual link from ENT to carbon
emission inequality.
   The research subsequently is planned as follows. Section 2 elaborates on the major out-
comes in the literature. In Sect. 3 the data sets and methodology is discussed. The empiri-
cal findings are found in Sect. 4. The study concludes in Sect. 5.



2 Background Literature

Economic inequalities and climate change are the two most tenacious problems of recent
times. The inability to contain climate change will aggravate inequalities across countries
and further economic inequalities also tend to slowdown the enactment of the climate
change policies. To recognize how climate change inequality aggravates the climate mit-
igation problems, it is essential to identify the major drivers of climate change inequal-
ity. This study has used emission inequality of carbon dioxide as proxy for climate change
inequality. Based on the extent of the research this study explores the literature along two
major dimensions:

   1. On Carbon Emission Inequality
Impact of environmental technology, economic complexity,…


   2. On Environmental Technology

2.1 On Carbon Emission Inequality

Most countries across the globe are trying to address the two major sustainable develop-
ment goals namely social equity (SDG-10) and climate action mitigation (SDG-13). How-
ever, attaining both these goals is rather challenging (Rao et al. 2018). Many topical studies
have documented that the distribution of emanations of carbon and other greenhouse gases
are also largely unequal (Baiocchi et al. 2017, Hubacek, et al. 2017a, 2017b; Bruckner
et al. 2022). Some studies demonstrate that many poorest households just emit one ton
of carbon dioxide per year due to the production of basic staple food while the richest
households emit hundreds of tons by using yachts and private jets (Barros et al. 2021). The
substantial disparity in carbon inequality is due to income inequality. Since the 1990s the
global inequality in income has expanded. There is widening gap in intra country incomes.
However, the intercountry inequality has declined (Baiocchi et al. 2017, UN, 2020). The
Oxfam reports that the top 1 per cent richest had accumulated more than double the wealth
of common people amounting to 6.9 billion (Zheng et al. 2023). Such huge gap in the con-
text of inequality implies a large gap between the rich and poor as far as consumption is
concerned. This affects reaching the SDG 12 on sustainable consumption and production
(Aguiar & Bils, 2015). The inequality in the consumption patterns leads to inequality in the
distribution of carbon dioxide across the globe (Ivanova et al. 2020).; Oswald et al. 2020;
   Considering the case of justice and global climate policies, the unequal emanations of
carbon dioxide implies that the rich should shoulder the mitigation responsibility. A fistful
of studies have documented huge gap in the carbon dioxide footprint across countries in
the various stages of development or across varying economic classes in a country (Jor-
genson et al. 2016; Rojas-Vallejos et al. 2020; Wiedenhofer et al. 2017). It is crucial to note
that the standard carbon footprint in per capita terms for the most prosperous country was
23 times higher than the poverty-stricken country in 2007 (Ivanova, Stadler, Steen‐Olsen,
Wood 2016). The Oxfam (2015) demonstrates that the top one per cent of the population
had released 30 times more carbon dioxide than the bottom 50 per cent. Further the top one
per cent emitted carbon dioxide 175 times more than the bottom 10 per cent. It is crucial to
address inter and intra country emission inequality for framing suitable policy suggestions
(Lucas & Thomas, 2015).
   There are two methods by which inequality in income can impact environment. Tor-
ras and Boyce (1998) proposed the political economy model. According to this theory the
inequality in income impacts pollution indirectly from the perspective of the dissemina-
tion of political power. When the income distribution is more equal than it creates more
political power to more citizens. Such power enables the citizens to place their demand for
the quality of the environment. Likewise, the consumption theory posits that inequality in
income distribution impacts the pollution levels because there are changes in consumption.
The studies by Ravallion and et al. (2000) and Heerink and et al. (2001) have developed
the consumption theory related to income inequality and carbon emissions. The studies by
Ravallion and et al. (2000) and Heerink and et al. (2001) demonstrate a negative relation
amid inequality in income and emanations of carbon. Such descriptions imply that there
is a tradeoff across environmental protection and social justice. Nonetheless some stud-
ies have obtained mixed results. The study by Borghesi (2006) documents that the impact
of income inequality on carbon emanations is not significant statistically. Likewise, The
research conducted by Coondoo and Dinda in 2008. obtain heterogeneity in their results.
                                                                             B. Bergougui et al.


they discovered that inequality in income is insignificant when the study considers all the
countries in the sample. However, the results become significant when the countries are
divided in accordance with geographic classification. In a similar vein the results by Jor-
genson, et al. (2016) and Grunewald and et al. (2017) applying income inequality data
from Standardized World Income Inequality Data ( Solt, 2009) obtain mixed results.
    Several country level studies produce mixed results. For instance, in the context of
China the study by Hao et al. (2016) obtain that as the gap in income rises the per cap-
ita emissions also rise. The study by Uzar and Eyuboglu (2019) obtain similar results in
the context of Turkey. Thus, these studies posit that decreasing income inequality leads to
the reduction of emissions. The studies by Baek et al. (2013) and Jorgenson et al. (2017)
explore in the context of the United States how income inequality impacts emissions.
The study by Baek and Gweisah (2013) obtain a positive relationship across inequality
in income and dilapidation of the environment. In contrary the study by Jorgenson et al.
(2017) find a positive association between income inequality and environment when the
share of income of the top 10 per cent population is concerned. In another study Liu et al.
(2019) obtain that as the share of income by the top ten per cent raises the emission during
the short run but it declines during the long run.


2.2 On environmental technology

A wide-ranging literature has explored how environmental related technology and green
technology can be useful for the firm for developing competitive advantage and it has ben-
efits for the environment (Hart et al. 2011). The studies by (Ganda, 2019; Shao et al. 2021)
confirm on the significance of green innovations in expanding the relation amid economic
development and sustainability of the environment. The study by Ganda (2019) document
that expenditure on research and development negatively impacts the emanations of carbon
dioxide. Nonetheless the study also demonstrate that the number of patents has a positive
influence on carbon emanations for the OECD countries. The study by Shao et al.. (2021)
confirms that green technologies and renewables helps to lower carbon emanations in the
N-11 countries particularly in the long-run.
    Using quarterly data sets for the United States for the period 1990Q1 to 2016Q4 the
study by Xin et al. (2021) explored the cyclical effect of innovation in ENT on carbon
emissions. The study points out that the positive shocks in the innovations of ENT lead
to a decline in emissions. Further the study demonstrates that the negative shocks in the
innovation leads to a positive impact on emanations. The study suggests that innovations
in ENT during the recession and boom periods should be applied to help in decline in the
emission level in the context of United States. The study by Hussain, Mir, Usman, and
Mansoor (2022) explored the role of ENT in impacting the consumption-based carbon
dioxide in the case of emerging economies for the period 1990 to 2016. The study adopted
the Environmental Kuznets Curve Method. The study based on the state-of-the-art estima-
tion techniques support the role of the ENT in lowering emissions. The study suggests the
need to raise investments in ENT to reduce consumption-based emissions in the emerging
economies.
    Unarguably the study by Chang et al. (2023) examined how regulations in the envi-
ronment impacts the relationship across green innovations and decline of carbon ema-
nations in China. The study has used the data from 30 provinces for the period 2003 to
2019. The study has applied panel fixed model and the Spatial Durbin Model to tackle the
issue of endogeneity and take into consideration the spatial impact. The empirical results
Impact of environmental technology, economic complexity,…


demonstrate that regulations in the environment moderate the effect of green innovations
on carbon emissions. The study concludes that investment-related regulations is the best
instrument in fostering green innovation and assist in the reduction in emissions in the Chi-
nese provinces. In a similar vein the study by Töbelmann and et al. (2020) explored the
impact of environment related innovation on carbon emanations for the EU-27 countries
for the period 1992 to 2014. The patent counts of applications in environment patent are
used as an index of environmental innovation. The study found that environmental innova-
tion contribute towards reduction in emissions. Nonetheless economic activity reduces the
impact of environmental innovations.
   The study by Mongo et al. (2021) for 15 European nations for a period of 23 years
explored how green technologies affect carbon emissions. The results founded on autore-
gressive distributed lagged model document that in the long run environmental innova-
tion lower the emissions of carbon dioxide. In the short run the technological innovation
tends to raise emissions. Thus, there exists the rebound effect in the short run. The study
suggests on the need of environmental regulations and policy relevance whereby individu-
als consume products that are less harmful for the environment. Unarguably the study by
Mehmood et al. (2023) explored in the context of G7 countries for the period 1990 to 2020
how technological innovations, renewable energy and gross domestic product impact the
emission levels of carbon dioxide. The study found that technological innovations nega-
tively influence the emission level in the short run, but it has a positive influence in the
long run.

2.3 Research Gap

The existing literature discuss that emission inequality is a major problem that leads to the
hindrance of the attainment of the sustainability goals. Further ample studies have explored
the importance of ENT in mitigating emissions. Nonetheless there is lack of research on
the nexus between emission inequality and ENT. It is essential to explore the association
between emission inequality and ENT to ensure that adoption of ENT does not inadvert-
ently aggravate the existing inequalities. This study is the first of its kind that addresses
the issue on emission inequality and ENT. The study has important policy implications.
Effective policies can be designed to tackle technological upgradation and develop equita-
ble processes to meaningfully address climate change. Table 1 in the Appendix presents a
survey of recent literature on the nexus between carbon emissions and ENT.



Table 1   Explanation of variables
Variable               Notation Description                                       Source

Dependent Variable     CEI           CO2 emissions per person for the wealthi-    WID (2024)
                                      est 10%
Independent Variable ENT             Environmental Technology: Number of          OECD (2024)
                                       patents in environment-related technolo-
                                       gies
Control Variables      ECI           Economic Complexity Index                    Harvard University (2024)
                       GPR           Geopolitical Risk                            Caldara & Iacoviello (2022)
                       NR            natural resources revenue as % of GDP        WDI (2024)
                       GDP           GDP per capita                               WDI (2024)
                                                                              B. Bergougui et al.


2.3.1 Theoretical framework

The two major challenges the world is facing recently include climate change and eco-
nomic inequalities. The policy makers have realized that the failure to mitigate climate
change is likely to accelerate inequalities both within and across nations. Further the
advocates of the COP 28 recognize that inequalities will slow down the process of
realization of climate change. To properly understand the association between climate
change and inequality this study explores the importance of carbon emission inequality.
Information is currently missing how ENT impact carbon emission inequality. As policy
makers and researchers struggle to investigate which groups of population contribute or
mitigate emissions. A systematic understanding is necessary how ENT impacts emis-
sion inequality. The inability to understand the underpinning between ENT and emis-
sion inequality will jeopardize efforts towards sustainable living.




3 Methods

3.1 Data

This paper investigates the effect of ENT on CEI within a country-level framework. The
analysis spans is 1990–2020 for 41 developed and developing countries. This timeframe
matches with the most recent update for CEI data (2020), maximizing the available
research window. The sources of the data are from the World Bank Database (WDI)and
World Inequality Database (WID).

   I.   CEI serves as the dependent variable in this model. Prior research has explored CEI
        disparities between developed and developing nations (Chen et al. 2024a, 2024b),
        as well as across regions. However, this study emphasizes the critical importance
        of intra-national CEI due to its profound implications for social justice (Zhao et al.
        2024a, 2024b). While high emission levels often correlate with improved living
        standards, the benefits are not always equitably distributed within a nation. Margin-
        alized and low-income communities frequently shoulder a disproportionate burden
        of pollution and its associated climate change impacts. Addressing CEI, therefore,
        becomes a matter of safeguarding a fairer dissemination of both the burdens and
        benefits associated with emissions. Following Chancel (2022), who calculates the
        carbon footprint of the top 0.1 highest emitters, per capita carbon emissions from
        this population segment is employed for each sample economy as a proxy for CEI.
        This metric utilizes Chancel’ s (2022) estimates based on combined economic data.
  II.   The research scrutinizes the potential role of ENT in mitigating CEI. The amount
        of granted green patents within a country as a measure of its ENT level is utilized.
        Compared to patent applications, granted green patents offer a more robust indica-
        tor of innovation quality and capability(Bergougui & Aldawsari, 2024; Bergougui,
        2024a, 2024b, 2024c). The rationale for focusing on ENT lies in its potential to
        reduce carbon emissions. By offering solutions for various polluting sectors, ENT
        advancements can significantly contribute to environmental sustainability (Bergougui
        et al. 2024a, 2024b; Bergougui et al. 2024a, 2024b).
Impact of environmental technology, economic complexity,…


Table 2  Summary statistics                Mean        Std. dev     Min         Max       JB Stat   JB Prob

                                   CEI     27.8823     16.6917       3.2417     88.5961   193.01    0.000
                                   ENT        2.3053    0.4540        0.1398     3.8321   313.6     0.000
                                   ECI        0.7792    0.8406       -1.6797     2.8589   15.788    0.0003
                                   GPR        0.2000    0.4090        0.0036     4.3497   54,764    0.000
                                   GDP        9.4418    1.1840        6.2813    11.3751   59.819    0.000
                                   NR         1.1417    0.9520        0.0080     4.0258   75.74     0.000

                                    JB: Jarque–Bera



Table 3  Outcomes of the CSD       CSD test
and SH tests
                                                                  BP-LM                        PS-LM

                                   CEI                            6777.963***                  147.1214***
                                   ENT                            5068.169***                  104.9010***
                                   ECI                            9732.969***                  220.0901***
                                   GPR                            3423.475***                  64.28823***
                                   NR                             6601.919***                  142.7743***
                                   GDP                            15,457.27***                 361.4417***
                                   SH Test
                                   Model                          Coefficient                  P-value
                                   Delta                          18.858***                    0.000
                                   Adj. delta                     22.060***                    0.000
                                   SH Test
                                   Model                              Coefficient                    P-value

                                   Delta                              18.858***                      0.000
                                   Adj. delta                         22.060***                      0.000

                                    ***p < 0.01


 III.   To moderate estimate bias occurring from omitted variables, control variables
        demonstrably linked to CEI is employed, based on relevant studies on environmen-
        tal inequality and carbon intensity (Liao et al. 2023; Wang & Feng, 2022) These
        control variables include: Geopolitical Risk (GPR), Economic Complexity Index
        (ECI), Total Natural Resource Rents (NR), and GDP Growth (GDP) (Bergougui &
        Murshed, 2020, 2021, 2023). A comprehensive description of all variables is pro-
        vided in Table 2–3 presents.


   Table 3 shows that the CEI mean is 27.882 with a standard deviation (Std.dev) of
16.691, ranging from 3.241 to 88.596. This indicates high variability among the 41 nations
under consideration, as the coefficient of variation (CV) is 59.86%, signifying significant
disparity between the wealthiest 10% and the average population. Additionally, the mean
of ENT is 2.305, ranging from 0.139 to 3.832 with a Std.dev of 0.454, demonstrating
significant disparity among these nations, which include both developed and developing
                                                                                             B. Bergougui et al.


countries. Notably, the statistics reveal a high difference in ECI across the countries, with a
CV of 107.88%, implying a substantial variation among the sample countries in the field of
ECI. Regarding GPR, the outputs indicate a large difference between them, where the CV
was estimated at 204.5%, suggesting that the sample countries are exposed to strongly dif-
fering geopolitical risks. Moreover, the outcomes show that the NR mean is 1.1417, rang-
ing from 0.008 to 4.025, explaining a significant discrepancy between the sample coun-
tries, especially since it contains both developing and developed countries. Conversely, the
GDP statistics exhibit relative similarity between the sample countries through a low Std.
dev index, estimated at 1.184 compared to the average of 9.441, ranging between 6.281 and
11.375.

3.2 Model specifications

The following equation to assess the impact of ENT on CEI is used:

                                                                                                            (1)
                               (                                      )
                      CEIi,t = ENTit , ECIit , GPRit , TNNRit , GDPit

where:

• CEIi,t denotes level of C
                          ­ O2 inequality
• ENTi,t is the level of environmental technology
• ECI it ;GPR it ;TNNR it ; and GDPit represent control variables potentially influenc-
  ing CEI. These represent economic complexity index, geopolitical risk, total natural
  resource rents, and gross domestic product growth, respectively.

   To facilitate econometric estimation of the relationship between ENT and CEI, Eq. 1 is
transformed into a reduced-form model (Eq. 2):
  ln CEIi,t = 𝛼0 + 𝛼1 ln ENTi,t + 𝛼2 ECIi,t + 𝛼3 GPRi,t + 𝛼4 ln TNNRi,t + 𝛼5 ln GDPi,t + 𝜇i,t
                                                                                             (2)
  In Eq. (2):

• ln () signifies the natural logarithm transformation.
• The parameters 𝛼1 − 𝛼5 represent elasticity coefficients.
• 𝜇i,t represents the error term.

    The selection of an appropriate model is contingent upon data and variable character-
istics. In this case, CEI (the dependent variable) is derived from carbon emissions data,
which has been documented to exhibit a hysteretic effect (Zhao et al. 2021). This implies
that a nation’ s emissions in a given year might be influenced by its emission levels in the
preceding year. Consequently, CEI might possess similar hysteretic properties. To account
for this potential dynamic effect and ensure robust estimation of the ENT-CEI relationship,
the GMM-PVAR technique is employed. This model encompasses the lagged term of CEI
as set of instrument variables, yielding consistent estimation outcomes. The specific model
is illustrated in Eq. (03):
  ln CEIi,t = 𝛼0 + 𝛼1 ln CEIi,t + 𝛼2 ln ENTi,t + 𝛼3 ECIi,t + 𝛼4 GPRi,t + 𝛼5 ln TNNRi,t + 𝛼6 ln GDPi,t + 𝜇i,t
                                                                                                            (3)
Impact of environmental technology, economic complexity,…


3.3 Method

3.3.1 Cross‑sectional dependence (CSD) test

CSD is a frequent concern in panel data, where observations within a group (e.g., coun-
tries) are interrelated due to shared, unobserved factors (Pesaran, 2021). This interdepend-
ence can distort results. To address this, two diagnostic tests are utilized. The BP-LM test
is to unequal error variances across groups and makes few distributional assumptions
(Baum, 2001). It effectively detects various correlation patterns (Breusch & Pagan, 1980).
The PS-LM test excels at identifying even minor forms of spatial correlation, accommodat-
ing both equal and unequal error variances, and works with both complete and incomplete
datasets (Pesaran, 2021). By employing these tests, the reliability and validity of the find-
ings is enhanced.

3.3.2 Panel heterogeneity test

Panel data often exhibit heterogeneity, where individual units (e.g., countries) display sys-
tematic differences in behavior or relationships. Unobserved factors specific to each unit
can back to this variation, potentially influencing the outcome variable. To account for
such heterogeneity, the Blomquist and Westerlund, (2013) heterogeneity test is employed.
This test offers several advantages: robustness to heteroscedasticity and autocorrelation,
consistency as sample size increases, and the capability to control for CSD and individual
effects. By addressing these complexities, the Blomquist-Westerlund test enhances the reli-
ability and interpretability of the panel data analysis.

3.3.3 Unit root tests

Panel unit root tests are used to assess whether time series variables in a panel dataset
exhibit a unit root, which signals non-stationarity. Variables that are non-stationary do not
maintain a consistent mean over time. This study employs the CIPS and CADF tests. The
CIPS test improves upon the traditional IPS test by incorporating cross-sectional informa-
tion to address potential biases caused by CSD (Pesaran, 2007; Im et al. 2003). The CADF
test further enhances flexibility by allowing for individual lag lengths and coefficient con-
straints, adapting heterogeneous unit root behavior across panel countries (Pesaran, 2007).
These tests are chosen for identifying unit roots in panel data due to their capability to
handle CSD and heterogeneity.

3.3.4 GMM‑PVAR technique

This study leverages the recent advancements in PVAR analysis to explore the causal effect
of ENT on CEI. The GMM-PVAR framework developed by Sigmund and Ferstl (2021)
is applied. This technique offers a robust alternative to traditional Ordinary Least Squares
(OLS) methods, which can be susceptible to Nickell bias (Nickell, 1981) even with large
data (n) and limited periods (t). The foundation of PVAR models is rooted in VAR analy-
sis, introduced by Sims (1980), which is widely used to model interactions among mul-
tiple interrelated variables. However, OLS estimation in VAR frameworks often results
in biased and inefficient outcomes (Sigmund & Ferstl, 2021; Zambrano-Monserrate et al.
                                                                                       B. Bergougui et al.


2024). To mitigate these issues, researchers have turned to alternative estimation methods
such as GMM proposed by Hansen (1982). GMM estimators include several approaches,
with key methods being the first-difference GMM (Arellano et al. 1991) and the system
GMM (Blundell et al. 1998), which utilizes additional moment conditions for improved
estimation (Sigmund & Ferstl, 2021). The use of GMM-PVAR models is popular in social
sciences due to their ability to address OLS limitations in PVAR analysis.
   Building upon the work of Abrigo and Love (2016) who incorporated first-genera-
tion GMM estimators into PVAR models, Sigmund and Ferstl (2021) proposed a novel
GMM-PVAR framework that achieves the structural form required for causal inference.
Their method incorporates several key elements: (i) Inclusion of j lags of the p endogenous
variables within the system. (ii) Integration of m strictly exogenous variables that do not
Granger-cause the endogenous variables. (iii) Incorporation of d predetermined variables
(weakly exogenous) that may be correlated with the error terms. By employing the GMM-
PVAR framework, this study aims to obtain consistent and efficient estimates of the causal
effect of ENT on CEI, addressing the potential for endogeneity and bias often encountered
with traditional OLS methods. Based on this framework, Eq. (4) formally represents the
PVAR model::
                                      b
                                      ∑
                      y(i,t) = 𝛿i +         ∪a y(i,t−1) + Wv(i,t) + 𝜑x(i,t) + 𝜏(i,t)                  (4)
                                      a=1

    Expanding on the research by Binder et al. (2005), Sigmund and Ferstl (2021) intro-
duce an enhanced estimator that accommodates flexible lag structures for endogenous and
strictly exogenous factors within the GMM-PVAR model. This advancement enables the
integration of first-difference moment conditions using either a forward orthogonal trans-
formation or a basic differencing method. The detailed equation for this expanded GMM-
PVAR model is provided in Eq. (5), as discussed in Sigmund and Ferstl (2021):
                                  b
                                  ∑
                 Δy(i,t) = 𝛿i +         ∪a Δy(i,t−1) + WΔv(i,t) + 𝜑Δx(i,t) + Δ𝜏(i,t)                  (5)
                                  a=1

   In Eq. (5), the character "Δ" represents the advance differencing operator, which is uti-
lized to capture the relationships among the variables.
   A stable PVAR model is essential for accurate analysis. We ensure stability by checking
that all eigenvalues of the model’ s coefficients are within a specific range. To identify the
optimal lag length in the PVAR model, the approach proposed by Andrews and Lu (2001) is
employed, with emphasis on the BIC, as recommended by Sigmund and Ferstl (2021). The
analysis indicates a one-period lag is best suited for the models. Endogeneity, where error
terms and explanatory variables are related, is a common problem often overlooked in emis-
sions studies. While the standard GMM method has limitations, the GMM-PVAR approach
effectively addresses endogeneity by treating all variables as potentially interconnected.

3.3.5 Panel granger causality test

To examine the causal connections between CEI and its proposed determinants, this study
employs a PVAR Granger causality framework. This approach is particularly suited due to
the stationarity achieved for all variables through first-differencing. The identified causal
relationships will be instrumental in formulating targeted policy interventions for the
selected nations, aiming to optimize CEI levels in conjunction with the chosen factors. The
Impact of environmental technology, economic complexity,…


subsequent section outlines the application of the PVAR Granger causality test, following
the established methodological framework:
                                    a                          a
                                    ∑                          ∑
                    𝜌(i,t) = 𝜃i +          𝜃(1,j) K(i,t−1) +         𝜃(2,j) K(i,t−1) + 𝛾i + 𝜀(i,t)                 (6)
                                     q=1                       q=1


                                     a                         a
                                     ∑                         ∑
                     K(i,t) = 𝜃i +         ℵ(1,j) 𝜌(i,t−1) +          ℵ(2,j) 𝜌(i,t−1) + 𝜋i + ∫                     (7)
                                     q=1                       q=1                            (i,t)


   Equations (6) and (7) initiate the subsequent notation:

• a: lag length.
• 𝛾i and 𝜋i : Individual country fixed effects.
• 𝜖(i,t) and𝜀(i,t) are random disturbance terms.

   This analytical approach determines if past values of one metric help forecast another
metric’ s future values. The statistical evaluation employs distribution-based calcula-
tions to test the core premise. The baseline assumption states there are no predictive links
between variables. The alternative possibility suggests at least one predictive relationship
exists between the examined metrics.


4 Results and discussions

4.1 Tests of CSD and SH

In modern panel data analysis, the notion of CSD holds high importance, as it determines
the optimal tests and estimation procedures for subsequent steps of the analysis (Pesaran,
2021). Accordingly, as mentioned above, this paper employs two different tests presented
in Table 4. Notably, the outcomes confirm at a 1 per cent significance level (SL) that all the
variables suffer from the CSD issue. This indicates that any shock affecting any variable
could be transmitted to the same variable across the cross-section. Hence, it is necessary
to perform second-generation tests and estimation procedures in the following steps of this
analysis. Additionally, Table 4 presents the Blomquist and Westerlund (2013) outcomes
for the heterogeneity issue. Table 5 the findings showed heterogeneous slopes across the
cross-sections.

Table 4  CIPS and CADF test           Variable        CIPS test statistics                  CADF test statistics
outcomes
                                                      I(0)                I(1)              I(0)           I(1)

                                      CEI             -1.489              −4.784***         −1.394         −3.310***
                                      ENT             −3.909***           −5.444***         −3.102***      −4.320***
                                      ECI             −1.821              −5.523***         −1.352         −4.092***
                                      GPR             −3.249***           −5.698***         −2.430***      −4.499***
                                      NR              −2.071              −5.019***         −1.958         −3.723***
                                      GDP             −1.961              −2.912***         −2.345***      −2.737***

                                      *** p < 0.01
                                                                                  B. Bergougui et al.


Table 5  Selection Criteria for   lag      J p-value   MBIC            MAIC         MQIC
Panel VAR Lag Order
                                  1        0.0006      −1111.8070      −142.796     −518.494
                                  2        0.015731    −944.3068       −136.798     −449.879




4.2 Unit root test

Following confirmation of CSD, examining the integration order of the variables becomes
essential. Consequently, this study utilizes both the CIPS and CADF panel unit root tests.
The outcomes of both tests indicate that ENT and GPR are stationary at their level series.
However, in the case of the CEI, ECI, NR, and GDP series, the two tests fail to offer suf-
ficient support for the acceptance of ­H0 at a 10% SL, suggesting that these variables exhibit
unit root behavior. Nevertheless, these unit roots disappear when applying the first differ-
ences series. Accordingly, the CEI, ECI, NR, and GDP series are integrated of order 1,
while ENT and GPR are integrated of order 0.

4.3 Model PVAR‑GMM

4.3.1 PVAR lag order selection

In order to estimate the GMM-PVAR model, It is necessary to initially establish the ideal
lag for the PVAR. modeling using the MBIC, MAIC, and MQIC criteria to detect the mini-
mum values of these three criteria across different lags. According to Table 6, the min-
imum values are observed at lag 2, indicating that the optimal lag in the GMM-PVAR
model for this case is 2 lags.

4.3.2 PVAR stability

With respect to the stability of the estimated model, Fig. 1 and Table 7 reveal clearly that
all the modulus values resulting from the eigenvalues are below the unity (all less than
1) showing the stability of the estimated model. This finding provide statistical evidence
about the robustness of GMM-PVAR modeling since the parameters are reliable and will
not diverge over time (Dogan et al. 2022).



Table 6  Stability Condition of   Eigenvalue
Eigenvalues
                                  Real                     Imaginary                       Modulus

                                  -0.434                   0.771                           0.885
                                  -0.434                   -0.771                          0.885
                                  -0.507                   0.000                           0.507
                                  0.390                    0.000                           0.390
                                  -0.222                   0.000                           0.222
                                  -0.028                   0.000                           0.028
                                  -0.434                   0.771                           0.885
Impact of environmental technology, economic complexity,…


                              Roots of the companion matrix
             1




            .5
Imaginary




             0




            -.5




            -1
                  -1                 -.5                      0                       .5                       1
                                                             Real

Fig. 1  Roots of the associated matrix



Table 7  GMM-PVAR outcomes                                Slope              SE            Z               P

                                         d(CEI)t-1        −0.2180            0.0442        −4.9300         0.0000
                                         d(ENT)t-1        −1.0893***         0.1508        −7.2200         0.0000
                                         d(ECI)t-1        −5.9864***         0.8315        −7.2000         0.0000
                                         d(GPR)t-1        5.9772***          0.8123        7.3600          0.0000
                                         d(NR)t-1         1.1231***          0.4349        2.5800          0.0100
                                         d(GDP)t-1        3.8594***          0.1604        24.0700         0.0000

                                         *** shows significance at a 1% level. "d" indicates the first difference



4.3.3 PVAR‑GMM estimation

As stated in Sect. 3.3.4, this scrutiny relies on the modern procedure of GMM-PVAR to esti-
mate the reaction of CEI to the explanatory variables. The outcomes shown in Table 8 reveal
multiple outcomes.. First, the outcomes reveal a negative effect of ENT at a 1% SL on CEI,
showing that any upsurge of one unit in ENT leads to a reduction in the CEI by 1.09 units in
the long run. Research has consistently demonstrated that advancements in technology aimed at
environmental sustainability play a significant role in lowering carbon emissions across numer-
ous countries, regardless of their level of development., such as Chang et al. (2023) in China,
Jian and Afshan (2023) in G10 countries, Yahong et al. (2023) in 18 developing countries,
and Behera et al. (2023) in 18 emerging nations. Advancements in ENT led to the creation
of products that are more sustainable and yield satisfactory returns, particularly in the energy
sector (Bergougui et al., 2025). This includes innovations like wind turbines, solar panels, and
various renewable energy solutions (Ullah et al. 2021). Through the latter’ s access to the rich,
it contributes to reducing emissions by plummeting the use of high-emission energy sources
and narrowing the carbon inequality gap with the poor. Additionally, environmental techno-
logical development contributes to expanding the scope of energy efficiency methods, such as
LED lighting, smart grids, and energy-saving devices, which rich individuals are more able to
                                                                                       B. Bergougui et al.


Table 8  PVAR-Granger causality   H0                chi2             Df        p          Decision
outcomes
                                  ENT – > CEI       52.165 ***       1.000     0.000      ENT → CEI
                                  CEI—> ENT         1.298            1.000     0.255
                                  ECI – > CEI       29.767***        1.000     0.000      ECI ↔ CEI
                                  CEI – > ECI       51.837***        1.000     0.000
                                  GPR – > CEI       8.265***         1.000     0.004      GPR ↔ CEI
                                  CEI – > GPR       54.145***        1.000     0.000
                                  NR – > CEI        54.408***        1.000     0.000      NR ↔ CEI
                                  CEI – > NR        6.668***         1.000     0.010
                                  GDP – > CEI       16.196***        1.000     0.000      GDP ↔ CEI
                                  CEI – > GDP       579.155***       1.000     0.000

                                  → Unidirectional causality, ↔ bidirectional causality. *** p < 0.01,
                                  **p < 0.05, *p < 0.1


acquire, thus reducing their emissions (Paramati et al. 2022). In other words, with the availabil-
ity of technical development in the environmental field and the provision of environmentally
friendly products, the wealthy groups tend to acquire these goods and products due to their sub-
stantial purchasing power and heightened environmental awareness stemming from their level
of scientific knowledge. In contrast, the poor groups are unable to purchase these products due
to their high prices compared to traditional means, especially in the high-emission energy sector
(Ogiemwonyi, 2022), this will help close the emissions gap between wealthy and needy com-
munities. Besides, the outcomes reveal a negative association between ECI and CEI, indicat-
ing that ECI contributes to reducing CEI. In this context, several previous studies have shown
that ECI can reduce emissions, similar to Numan, Ma, Aslam, Bedru, Jiang. (2023) and Saqib,
Radulescu, Usman, Balsalobre-Lorente, (2023). Other studies have also shown that higher ECI
leads to increased efficiency and economic growth simultaneously (Pata, 2021). This means
that the ability of the rich to reduce their emissions will be at its highest level with the increase
of ECI, especially based on their ability to keep pace with this increase through their accumu-
lated knowledge and skills. Likewise, as Payne et al. (2023) pointed out, high levels of ECI
contribute significantly to enhancing energy efficiency through the energy and carbon intensi-
ties channels. This would reduce emissions that are issued mainly by wealthy groups with pro-
jects, investments, and large energy consumption, thus reducing the emissions gap with poorer
classes. Furthermore, high levels of ECI allow achieving zero carbon strategies by reducing
the carbon footprint as a result of the accumulation of knowledge and experience in the indus-
trial and environmental fields, thus contributing to achieving SDG11 and SDG12 by achieving
environmentally friendly production and consumption (Zheng, Zhou, Rahat, and Rubbaniy and
Khezri et al. 2022). Given the high rate of consumption and production among the wealthy
classes, often at the expense of the less affluent classes, this inevitably results in lower car-
bon emissions for the former category in comparison to the latter, consequently leading to a
decrease in the emissions inequality gap.
    Furthermore, the results confirm that GPR could be a pivotal factor influencing CEI, as
evidenced by the positive effect. Remarkably, a unit upsurge in GPR will automatically con-
tribute to an escalation of CEI by 5.977 units. This finding aligns with Chen et al. and and’
s (2024a, 2024b) study, where the authors demonstrate that GPR exacerbates CEI across a
sample of 38 developed and developing nations. Outstandingly, Situations of high geopoliti-
cal risks contribute significantly to the race for resources to avoid supply shortages as a reac-
tion to the accompanying risks and to preserve assets, especially among the wealthy classes,
Impact of environmental technology, economic complexity,…


who are considered the most vulnerable in such cases due to potential major losses. This will
greatly stimulate the consumption of energy, particularly fossil fuels, owing to their reduced
prices and availability (Sohag et al. 2022). The affluent groups also possess the financial
means to navigate these circumstances and political uncertainties, enabling them to meet their
requirements, even at the expense of the environmental situation. Moreover, individuals tend
to reduce costs by curtailing their spending on sustainable products and retreating from envi-
ronmentally friendly policies in such circumstances (Zhao et al. 2024a, 2024b). Conversely,
due to their limited financial capacity, the underprivileged classes are unable to expand their
consumption in such cases. Furthermore, wealthy individuals, by virtue of their influence,
financial power, and decision-making authority, may tend in high GPR situations to exploit
the situation by directing environmentally unfriendly investments to areas with weak environ-
mental regulations, thereby increasing emissions and further exacerbating CEI. In the case of
countries, those characterized by high GPR tend to increase their military expenditures and
reduce expenditures on environmentally friendly industries, fostering a consumer and pro-
duction climate with a substantial carbon footprint due to the decline in environmental con-
cerns in favor of security and political priorities (Dong et al. 2023).
    Similarly, the findings demonstrate a beneficial and detrimental effect of GDP on CEI,
signifying that an increase in GDP by one unit is accompanied by an escalation in CEI by
3.859 units. This result corroborates the outcomes of Chen et al. (2024a, 2024b) across
38 nations. As nations, governments, and individuals pursue economic development, they
often place greater emphasis on financial benefits than on environmental issues, resulting in
a rise in emissions, particularly in developing nations that have yet to attain the economic
growth necessary for sustainable development, as per the EKC hypothesis. On one hand,
driven by economies of scale, the wealthy classes with the greatest influence on economic
activity seek to maximize profits and direct their capital towards highly profitable ventures,
often characterized by negative environmental impacts. On the other hand, in an attempt
to reduce costs, these classes may neglect sustainable practices and minimize the adoption
of renewable energies due to their limited availability, high prices, and lack of efficiency.
Therefore, these factors contribute significantly to the long-term exacerbation of CEI, espe-
cially since the impoverished classes wield a weak influence on economic growth.
    Ultimately, the results indicate that a one-unit increase in NR corresponds to a 1.123-unit
rise in CEI, demonstrating a positive relationship. Logically, several studies, such as those
by Nwani and Adams (2021) and Shang et al. (2024), demonstrate that NR promotes sig-
nificantly to emissions and environmental degradation. Precisely, natural resources like oil,
coal, and gas are characterized by high emissions and high economic importance. Hence, the
upsurge in NR generates more emissions, especially in developing nations where the share of
NR in GDP ranges from 10 to 19% (Nwani & Adams, 2021). Similar to economic growth,
the wealthy classes, due to inequality in the economy, are the largest beneficiaries of NR and
are also actively involved in this sector, implying that they have the greatest impact compared
to the poor classes. Conversely, the poor classes’ contribution is limited to the labor force
only, and this is what causes the largest share of emissions from NR to come from wealthy
individuals, largely explaining the rise in CEI in response to the increase in NR (Sawadogo
& Ouoba, 2024). On the other hand, countries with high NR ratios to GDP heavily rely on
income resulting from the mining and export of NR, creating a "lock-in effect" and intro-
ducing the country to the Dutch disease by giving high priority to these resources and their
incomes (Asiamah et al. 2022). This hinders investment in cleaner alternatives, obstructing
the energy transition and reducing consumer and production options for citizens (Shinwari
et al. 2022). Consequently, this will necessarily exacerbate the CEI problem, given that indi-
viduals do not have many alternatives to reduce their emissions.
                                                                                 B. Bergougui et al.


4.4 Functions impulse response

By conducting the Impulse Response Analysis (IRA), it is examined how CEI responds to
shocks in the independent variables over the subsequent 10 periods. First, through Fig. 2, it
is evident that any shock affecting ENT will stimulate an inverse response to CEI in the first
period directly, and then oscillate between an inverse and repulsive response over the subse-
quent 10 periods. However, it is crucial to note that the inverse and negative response is domi-
nant, confirming that ENT effectively contributes to reducing CEI ratios. Similarly, the figure
for ECI shows that the overall response of CEI to ECI was negative and inverse over 10 peri-
ods, despite some fluctuations in the second, fifth, and eighth periods, confirming the possibil-
ity of reducing CEI by raising ECI in the long run. Conversely, the figures demonstrate that
both GDP and GPR stimulate a positive response in CEI in most periods. Any positive change
in either variable will result in an raise in CEI, corroborating the results previously obtained
using GMM-PVAR. As for NR, the results show an inverse response in the first two periods
of CEI in response to any positive shock in NR, but the response will turn positive in the third
period, and it will then approach zero as the periods progress, reaching the tenth period. Over-
all, the IRA outputs largely confirmed the results obtained previously, showing that both ENT
and ECI have an important role in reducing CEI, in contrast to GPR, GDP, and NR, which are
highly likely to contribute to increasing CEI levels in the long term.

4.5 PVAR‑granger causality

The last phase of this study involves analyzing the causal relationships between the variables by
employing the PVAR Granger causality method. The findings inspired from Table 9 and Fig. 3



                  d(GDP) : d(CEI)                                   d(ECI) : d(CEI)
  1
                                                     1
 .5                                                 .5
                                                     0
  0
                                                    -.5
-.5                                                 -1


                   d(NR) : d(CEI)                                   d(ENT) : d(CEI)
  2                                                 .5

  1
                                                     0
  0

 -1                                                 -.5

                                                          0                5                   10

                  d(GPR ): d(CEI)
  1
 .5
  0                                                           95% CI
-.5                                                           Orthogonalized IRF
 -1

      0                   5              10


Fig. 2  Impulse response analysis
Impact of environmental technology, economic complexity,…


show a unidirectional causal link from ENT to CEI, highlighting the importance of actual (past)
ENT values in determining future (present) values of CEI. Additionally, the outcomes reveal
bidirectional causality between ECI, GPR, NR, and GDP on one hand, and CEI on the other
hand. Generally, the causality analysis confirms the important role of the explanatory variables
in influencing CEI, indicating that these variables are crucial in shaping the future values of CEI.
Accordingly, it is imperative to address ENT, ECI, GPR, NR, and GDP in any strategies or plans
aiming to reduce CEI, especially ENT and ECI, which have shown promising effects in reducing
inequality and emissions, particularly from the wealthy classes, thereby improving environmen-
tal conditions, facilitating the energy transition, and ensuring the accomplishment of SDGs.

4.6 Discussion

The empirical outcomes reveal a negative effect of ENT at a 1% significance on CEI, show-
ing that any upsurge of one unit in ENT leads to a decline in the CEI by 1.09 units. Previous
research has consistently demonstrated that advancements in ENT have significantly contrib-
uted to the fall of carbon emissions across various countries, regardless of their development
status, such as Chang et al. (2023) in China, Jian and Afshan (2023) in G10 countries, Yahong
et al. (2023) in 18 developing nations, and Behera et al. (2023) in 18 emerging nations.
    Besides, the outcomes reveal a harmful association amid ECI and CEI, indicating that ECI
contributes to reducing CEI in the sample countries over the period of study. In this context,
prior findings have shown that ECI can reduce emissions, similar to Numan and et al. (2023)
and Saqib and et al. (2023) and Adebayo et al. (2024). Furthermore, the results confirm that
geopolitical could be a pivotal factor influencing CEI, as evidenced by the positive. Remark-
ably, a unit increase in geopolitical risk will automatically contribute to an escalation of CEI
by 5.977 units. Moreover, individuals tend to reduce costs by curtailing their spending on sus-
tainable products and retreating from environmentally friendly policies in such circumstances
( Adebayo, 2022; Zhao et al. 2024a, 2024b). Similarly, the findings demonstrate a positive and
detrimental effect of GDP on CEI indicating that a rise in GDP by one unit is accompanied
by an escalation in CEI by 3.859 units. This result corroborates the outcomes of Chen et al.
(2024a, 2024b) across 38 nations.

4.7 Policy implications

The empirical analysis shows that ENT significantly contributes to lowering CEI. The
government of the concerned countries should foster environmental policies to enhance
the adoption of ENT to stimulate the synergistic effects. The government can implement
carbon pricing system that will create economic incentive for individuals and compa-
nies to reduce emissions and invest in clean technologies.
    The authorities of the concerned nations must set renewable energy targets to
enhance the use of ENT. The setting up of targets generates the market of clean ENT
and fosters investment in these technologies. Further the state machinery can set energy
efficiency standards for vehicles and buildings that will reduce carbon emission inequal-
ity. There is a growing need to invest in research and development of ENT. The devel-
opment of research and development can make the concerned technologies more cost
effective. Further the governments of the concerned countries can work in collabora-
tion to reduce carbon emission inequality by sharing ENT and fostering best practices.
The ultimate goal is to generate an economic environment that creates incentives for the
implementation of ENT and reduce CEI.
                                                                               B. Bergougui et al.


    The concerned countries can implement policies to introduce strong patent protection.
The implementation of strong patent protection can provide motivations to invest in ENT.
The existence of strong patent protection instils confidence in inventors and investors that
their investments will be protected. Such processes may encourage investment in research and
development of ENT. Further countries through public funding may invest in research and
development of ENT. The public funding can support research in universities to develop ENT.
    Furthermore, to reduce the adversative implications of geopolitical index, natural
resources and GDP on carbon emission inequality the authorities of these nations must foster
appropriate policies. For example, the governments can improve the social insurance system
to reduce the implications of income inequality on carbon emanations. The central authorities
of the concerned countries should strengthen transfer payments in the low-income region. At
the provincial level, the local authorities need to foster market-oriented practices to enhance
the income of farming community. By doing so, the authorities be able to enhance the ability
of citizens to consume products from ENT. By stimulating the market demand for innovation,
the government can enhance the ability of the residents to consume products based on ENT.


5 Conclusion, limitations and directions for future research

5.1 Conclusion

This research examines the impact of ENT on CEI in both advanced and emerging
economies. The analysis covers the years from 1990 to 2020 and incorporates control
variables such as economic complexity, GPR, total natural resource rents, and GDP.
To investigate the structural dynamics, the study utilizes the innovative GMM-PVAR
method developed by Sigmund and Ferstl (2021). The empirical outcomes document
a negative effect of ENT on CEI. The study reveals that one per cent rise in ENT leads
to the reduction in CEI by 1.09 units. The expansion of ENT leads to the availability of
products and goods that are environmental friendly for example wind turbines and other
renewable energy sources. The rich utilizes these products which contributes to reduc-
tion in emissions and thus reducing the CEI between the rich and poor.
    Further the empirical outcomes document a negative relationship amid ECI and CEI.
It implies that ECI helps to reduce the CEI. Nonetheless the study further shows that
Geopolitical is a significant factor in influencing CEI. The study reveals that one unit
increase of GPR leads to the escalation of CEI by 5.977 units. The countries which have
high GPR they tend to raise their military expenditures and reduce the expenditure on
environmental friendly industries. Such set of practices lead to a production and con-
sumption of industries that lead to a increase emissions. The rise in the GPR leads to a
fall in the environmental concerns at the cost of security and political reasons.
    Similarly, the research indicates that GDP impacts CEI both positively and nega-
tively. It shows that an increase of one unit in GDP results in a arise of 3.859 units in
CEI. This is attributed to economies of scale, where wealthier segments of the pop-
ulation, exerting greater influence on economic activities, optimize such activities,
often leading to adverse environmental consequences. Additionally, the study finds
that natural resources also contribute positively to CEI. Specifically, an increase of
one unit in natural resources correlates with a rise of 1.123 units in CEI. The affluent
segments of society benefit from these natural resources, which in turn have detri-
mental effects on the environment.
Impact of environmental technology, economic complexity,…




Fig. 3  causal links between carbon inequality and the various independent variables




    The results from IRA documents how CEI responds to the shocks in the independent var-
iables over ten periods. The analysis demonstrates that any shock in the ENT will stimulate
an inverse response to CEI in the first period and then oscillate across inverse response over
a period of 10 periods. It is however crucial to note that the inverse and negative response
is dominant as far as the impact of ENT is concerned. Such empirical results demonstrate
the effective role of ENT in reducing CEI. Further as far as the ECI is concerned, the overall
response of CEI is negative and inverse for 10 periods except for fluctuations in the second,
fifth and eighth periods. Thus, the dominant role of ECI in reducing CEI.
    In sum IRA results in conformity with GMM-PVAR method document the crucial
roles of ENT and ECI in reducing CEI. However, the GPR, GDP and NR escalates the
CEI. The results demonstrate one directional causal link from ENT to CEI. Again, there is
bidirectional causality between ECI, Geopolitical Index, Natural resources, GDP and CEI.



5.2 Constraints and avenues for further investigation

While this paper has provided valuable insights it is not without limitations. Green-
house gas emissions include other gases apart from carbon dioxide. This study has
explored the CEI. Future studies can explore the association between ENT and ine-
quality emanating from other greenhouse gas emissions. Further research can be con-
ducted to consider asymmetries in the effect of ENT on CEI. further investigation
should focus on refined methodologies and add newer variables with availability of
data to draw policies on sustainable practices.


Appendix

See Table 9.
Table 9  Summary of recent literature on impact of emissions
Authors                           Countries, Year                  Variables                         Methods                            Research Outcomes
Doğan et al. (2020)               1995 to 2014,32 European         Renewable energy, FDI, and        Quantile regression                Renewable energy, FDI and trade
                                    Countries                       institution                                                           openness enhances economic
                                                                                                                                          growth
Dogan, B et al. (2020)            Developing and developed         Economic growth, urbanization,    Panel quantile estimation          growth and energy consumption
                                   economies                        total energy use                                                      raise the level of carbon emis-
                                                                                                                                          sions
Doğan et al. (2021)               1990–2014                        ECI, population growth and        Augmented Mean group estima-       ECI and renewable energy miti-
                                  28 OECD                           growth of economy, renewable      tion                                gates the carbon emissions
                                                                    energy
Doğan et al. (2022a, 2022b)       1994–2014                        Economic complexity, natural      Second generation panel            Marginal impact of environmental
                                  G7 nations                        resource rent, environmental      methods                            tax is noticeable
                                                                    tax
Xia et al. (2022)                 67 developed and developing      Globalization, GDP and energy     Panel methods                      Positive association between glo-
                                    nations,1971 to 2018                                                                                 balization and carbon emissions
Doğan, B et al. (2022)            G7 and E7;1991 to 2017           Eco-innovation, economic com-     FMOLS, DOLS and Canonical          Eco innovation reduces carbon
                                                                    plexity and globalization         method                             emissions in G7 countries
Kartal, M. T. (2022)              Top five countries in emis-      Nuclear energy, fossil fuel and   Multivariate adaptive regression   Coal, oil and natural gas most
                                   sion;1965 to 2019                renewable energy                                                     significant factors impacting
                                                                                                                                         emissions
Depren et al. (2022)              Turkey, February 20, 2019 to     Electricity related variables     Machnine learning algorithm        Machnine learning algorithm
                                   March 26, 2021                                                     and econometric methods            shows better results than econo-
                                                                                                                                         metric methods
Kartal, M. T. (2023)              USA; January 1973 to April       Fossil, nuclear and renewable     Kernel based regularized least     Fossil fuels and nuclear power
                                   2022                             energy                            squares                            contribute to an increase in
                                                                                                                                         carbon emissions
Doğan, B., et al. (2023)          Newly Industrialized Countries   Energy security, governance,      Dynamic Common Correlated          Energy insecurity drives emis-
                                                                     financial development            Effects                            sions
Ulussever et al. (2023)           GCC Countries                    energy use, energy and oil        Quantile based methods             Total income, total energy
                                  2000/1–2021/12                     prices, political risk                                              consumption and energy price
                                                                                                                                         index has harmful effects on the
                                                                                                                                         quality of e the environment
                                                                                                                                                                            B. Bergougui et al.
Table 9  (continued)
Authors                         Countries, Year                  Variables                         Methods                          Research Outcomes
Adebayo et al. (2023a, 2023b,   USA                              Water power, natural gas, eco- Wavelet local multiple local        Strong correlation between natural
 2023c)                         1965Q1-2020 Q4                    nomic expansion, energy usage  methods                              gas consumption and carbon
                                                                                                                                      emissions
Kartal, M. T. (2024)            USA                             R and D investments on energy     Quantile based methods            Heterogeneous impact of Rand D
                                1975/Q1-2020/Q4                                                                                       on emissions across sectors
Lin et al. (2024)               high- and middle-income nations Energy insecurity and environ-    Method of Moments Quantile        Energy insecurity and environ-
                                1996–2018                         ment related regulation          regression                         mental regulations positively
                                                                                                                                      influence the transition to
                                                                                                                                      sustainable energy sources
Usman et al. (2024)             USA, 2000-M6 to 2019-M7         Energy related uncertainty        Multivariate quantile on quantile Energy related shocks increase
                                                                  shocks on the US inflation       regression                         inflation
Özkan et al. (2024)             France,1985 to 2021             Renewable energy, energy          Kernel based regularized least    Policies promoting green energy
                                                                  efficiency                       squares                            reduce the level of emissions
Adebayo, T. S. (2024)           United States, January 1988 to  Impact of uncertainties of renew- M-QQR                             The enhancement of ecological
                                  May 2023                        able energy                                                         systems is driven by renewable
                                                                                                                                                                         Impact of environmental technology, economic complexity,…




                                                                                                                                      energy sources and reduced
                                                                                                                                      uncertainties
                                                                                               B. Bergougui et al.


Data availability Data will be made available on reasonable request.

Declarations
Conflict of interest The authors declare that they have no known competing financial interests or personal
relationships that could have appeared to influence the work reported in this paper.

Open Access This article is licensed under a Creative Commons Attribution-NonCommercial-NoDeriva-
tives 4.0 International License, which permits any non-commercial use, sharing, distribution and reproduc-
tion in any medium or format, as long as you give appropriate credit to the original author(s) and the source,
provide a link to the Creative Commons licence, and indicate if you modified the licensed material. You do
not have permission under this licence to share adapted material derived from this article or parts of it. The
images or other third party material in this article are included in the article’s Creative Commons licence,
unless indicated otherwise in a credit line to the material. If material is not included in the article’s Creative
Commons licence and your intended use is not permitted by statutory regulation or exceeds the permitted
use, you will need to obtain permission directly from the copyright holder. To view a copy of this licence,
visit http://creativecommons.org/licenses/by-nc-nd/4.0/.



References
Abrigo, M. R. M., & Love, I. (2016). Estimation of Panel Vector Autoregression in Stata. Symposium (Inter-
      national) on Combustion, 16, 778–804. https://​doi.​org/​10.​1177/​15368​67X16​01600​314
Adebayo, T. S. (2022). Environmental consequences of fossil fuel in Spain amidst renewable energy con-
      sumption: A new insights from the wavelet-based Granger causality approach. International Journal
      of Sustainable Development & World Ecology, 29(7), 579–592. https://​doi.​org/​10.​1080/​13504​509.​
      2022.​20548​77
Adebayo, T. S. (2024). Do uncertainties moderate the influence of renewable energy consumption on elec-
      tric power CO2 emissions? A new policy insights. International Journal of Sustainable Development
      & World Ecology, 31(3), 314–329. https://​doi.​org/​10.​1080/​13504​509.​2023.​22864​87
Adebayo, T. S., Kartal, M. T., Ağa, M., & Al-Faryan, M. A. S. (2023b). Role of country risks and renewable
      energy consumption on environmental quality: Evidence from MINT countries. Journal of Environ-
      mental Management, 327, 116884. https://​doi.​org/​10.​1016/j.​jenvm​an.​2022.​116884
Adebayo, T. S., Kartal, M. T., & Ullah, S. (2023c). Role of hydroelectricity and natural gas consumption on
      environmental sustainability in the United States: Evidence from novel time-frequency approaches.
      Journal of Environmental Management, 328, 116987. https://​doi.​org/​10.​1016/j.​jenvm​an.​2022.​116987
Adebayo, T. S., & Özkan, O. (2024). Investigating the influence of socioeconomic conditions, renewable
      energy and eco-innovation on environmental degradation in the United States: A wavelet quantile-
      based analysis. Journal of Cleaner Production, 434, 140321. https://​doi.​org/​10.​1016/j.​jclep​ro.​2023.​
      140321
Adebayo, T. S., Özkan, O., & Eweade, B. S. (2024). Do energy efficiency R&D investments and information
      and communication technologies promote environmental sustainability in Sweden? A quantile-on-
      quantile KRLS investigation. Journal of Cleaner Production, 440, 140832.
Adebayo, T. S., Ullah, S., Kartal, M. T., Ali, K., Pata, U. K., & Ağa, M. (2023a). Endorsing sustainable
      development in BRICS: The role of technological innovation, renewable energy consumption, and
      natural resources in limiting carbon emission. Science of the Total Environment, 859, 160181.
      https://​doi.​org/​10.​1016/j.​scito​tenv.​2022.​160181
Aguiar, M., & Bils, M. (2015). Has consumption inequality mirrored income inequality? American Eco-
      nomic Review, 105(9), 2725–2756. https://​doi.​org/​10.​1257/​aer.​20120​599
Allafta, H., & Opp, C. (2024). Climate Change Paradox: The Least Responsible for It Encounters the
      Most of Its Implications. Climate, 12(3), 38. https://​doi.​org/​10.​3390/​cli12​030038
Alola, A. A., & Adebayo, T. S. (2023). Analysing the waste management, industrial and agriculture
      greenhouse gas emissions of biomass, fossil fuel, and metallic ores utilization in Iceland. Science
      of the Total Environment, 887, 164115. https://​doi.​org/​10.​1016/j.​scito​tenv.​2023.​164115
Andrews, D. W. K., & Lu, B. (2001). Consistent model and moment selection procedures for GMM esti-
      mation with application to dynamic panel data models. J Econom, 101, 123–164. https://​doi.​org/​
      10.​1016/​S0304-​4076(00)​00077-4
Impact of environmental technology, economic complexity,…


Arellano, M., & Bond, S. (1991). Some Tests of Specification for Panel Data: Monte Carlo Evidence and
      an Application to Employment Equations. Review of Economic Studies, 58, 277–297. https://​doi.​
      org/​10.​2307/​22979​68
Asiamah, O., Agyei, S. K., Ahmed, B., & Agyei, E. A. (2022). Natural resource dependence and the
      Dutch disease: Evidence from Sub-Saharan Africa. Resources Policy, 79, 103042. https://​doi.​org/​
      10.​1016/j.​resou​r pol.​2022.​103042
Baek, J., & Gweisah, G. (2013). Does income inequality harm the environment?: Empirical evidence
      from the United States. Energy Policy, 62, 1434–1437. https://​doi.​org/​10.​1016/j.​enpol.​2013.​07.​
      097
Barros, B., & Wilk, R. (2021). The outsized carbon footprints of the super-rich. Sustainability: Science,
      Practice and Policy. https://​doi.​org/​10.​1080/​15487​733.​2021.​19498​47
Baum, C. F. (2001). Residual Diagnostics for Cross-section Time Series Regression Models. Stata J
      Promot Commun Stat Stata, 1, 101–104. https://​doi.​org/​10.​1177/​15368​67X01​00100​108
Behera, P., Haldar, A., & Sethi, N. (2023). Achieving carbon neutrality target in the emerging econo-
      mies: Role of renewable energy and green technology. Gondwana Research, 121, 16–32. https://​
      doi.​org/​10.​1016/j.​gr.​2023.​03.​028
Bergougui, B. (2024a). Investigating the relationships among green technologies, financial development
      and ecological footprint levels in Algeria: Evidence from a novel Fourier ARDL approach. Sus-
      tainable Cities and Society, 112, 105621. https://​doi.​org/​10.​1016/j.​scs.​2024.​105621
Bergougui, B. (2024b). Moving toward environmental mitigation in Algeria: Asymmetric impact of fos-
      sil fuel energy, renewable energy and technological innovation on CO2 emissions. Energy Strategy
      Reviews, 51, 101281. https://​doi.​org/​10.​1016/j.​esr.​2023.​101281
Bergougui, B. (2024c). Algeria’ s pathway to COP28 and SDGs: Asymmetric impact of environmental
      technology, energy productivity, and material resource efficiency on environmental sustainability.
      Energy Strategy Reviews, 55, 101541. https://​doi.​org/​10.​1016/j.​esr.​2024.​101541
Bergougui, B., & Aldawsari, M. I. (2024). Asymmetric impact of patents on green technologies on Alge-
      ria’ s Ecological Future. Journal of Environmental Management, 355, 120426. https://​doi.​org/​10.​
      1016/j.​jenvm​an.​2024.​120426
Bergougui, B., Ayad, H., Ghosh S., & Doğan B. (2024a). Do green total factor productivity and digital
      economy matter for energy transition: Evidence from Chinese cities. https://​doi.​org/​10.​2139/​ssrn.​
      47952​05
Bergougui, B., Mehibel, S., & Boudjana, R. H. (2024b). Asymmetric nexus between green technologies,
      economic policy uncertainty, and environmental sustainability: Evidence from Algeria. Journal of
      Environmental Management, 360, 121172. https://​doi.​org/​10.​1016/j.​jenvm​an.​2024.​121172
Bergougui, B., Boudjana, R. H., Mehibel, S., & Zambrano-Monserrate, M. A. (2024c). How do institu-
      tional quality and income asymmetrically affect carbon emissions inequality? A Quantile-on-Quantile
      assessment for six major global emitters. Journal of Cleaner Production, 144215. https://​doi.​org/​10.​
      1016/j.​jclep​ro.​2024.​144215
Bergougui, B., Murshed, S. M., Shahbaz, M., Zambrano-Monserrate, M. A., Samour, A., & Aldawsari, M. I.
      (2025). Towards secure energy systems: Examining asymmetric impact of energy transition, environ-
      mental technology and digitalization on Chinese city-level energy security. Renewable Energy, 238,
      121883. https://​doi.​org/​10.​1016/j.​renene.​2024.​121883
Bergougui, B., & Murshed, S. M. (2020). New evidence on the oil-democracy nexus utilising the Varie-
      ties of Democracy data. Resources Policy, 69, 101905. https://​doi.​org/​10.​1016/j.​resou​r pol.​2020.​
      101905
Bergougui, B., & Murshed, S. M. (2021). Revisiting the oil wealth-growth nexus: The role of economic
      norms in avoiding the oil curse. The Extractive Industries and Society, 8(3), 100929. https://​doi.​
      org/​10.​1016/j.​exis.​2021.​100929
Bergougui, B., & Murshed, S. M. (2023). Aggregate and disaggregate impact of natural resources on
      sustainable development: New evidence from the latest institutional data. Environmental and Sus-
      tainability Indicators, 20, 100302. https://​doi.​org/​10.​1016/j.​indic.​2023.​100302
Binder, M., Hsiao, C., & Pesaran, M. H. (2005). Estimation and inference in short panel vector autoregres-
      sions with unit roots and cointegration. Econom Theory. https://​doi.​org/​10.​1017/​S0266​46660​50504​13
Blomquist, J., & Westerlund, J. (2013). Testing slope homogeneity in large panels with serial correla-
      tion. Economic Letters, 121, 374–378. https://​doi.​org/​10.​1016/j.​econl​et.​2013.​09.​012
Blundell, R., & Bond, S. (1998). Initial conditions and moment restrictions in dynamic panel data mod-
      els. J Econom, 87, 115–143. https://​doi.​org/​10.​1016/​S0304-​4076(98)​00009-8
Borghesi, Simone (2000) : Income inequality and the environmental Kuznets curve, Nota di Lavoro,
      No. 83. 2000, Fondazione Eni Enrico Mattei (FEEM), Milano. https://​www.​econs​tor.​eu/​bitst​ream/​
      10419/​155136/​1/​NDL20​00-​083.​pdf.
                                                                                          B. Bergougui et al.


Breusch, T. S., & Pagan, A. R. (1980). The Lagrange Multiplier Test and its Applications to Model
      Specification in Econometrics. Review of Economic Studies, 47, 239. https://​doi.​org/​10.​2307/​
      22971​11
Bruckner, B., Hubacek, K., Shan, Y., Zhong, H., & Feng, K. (2022). Impacts of poverty alleviation on
      national and global carbon emissions. Nature Sustainability, 5(4), 311–320. https://​doi.​org/​10.​
      1038/​s41893-​021-​00842-z
Chancel, L. (2022). Global carbon inequality over 1990–2019. Nature Sustainability, 5(11), 931–938.
      https://​doi.​org/​10.​1038/​s41893-​022-​00955-z
Chang, K., Liu, L., Luo, D., & Xing, K. (2023). The impact of green technology innovation on carbon
      dioxide emissions: The role of local environmental regulations. Journal of Environmental Man-
      agement, 340, 117990. https://​doi.​org/​10.​1016/j.​jenvm​an.​2023.​117990
Chen, J., Cheng, S., & Song, M. (2017). Decomposing inequality in energy-related CO2 emissions by
      source and source increment: The roles of production and residential consumption. Energy Policy,
      107, 698–710. https://​doi.​org/​10.​1016/j.​enpol.​2017.​05.​003
Chen, J., Xu, C., Cui, L., Huang, S., & Song, M. (2019a). Driving factors of CO2 emissions and inequal-
      ity characteristics in China: A combined decomposition approach. Energy Economics, 78, 589–
      597. https://​doi.​org/​10.​1016/j.​eneco.​2018.​12.​011
Chen, L., Gozgor, G., Lau, C. K. M., et al. (2024a). The impact of geopolitical risk on CO2 emissions
      inequality: Evidence from 38 developed and developing economies. Journal of Environmental
      Management, 349, 119345. https://​doi.​org/​10.​1016/j.​jenvm​an.​2023.​119345
Chen, L., Gozgor, G., Lau, C. K. M., Mahalik, M. K., Rather, K. N., & Soliman, A. M. (2024b). The
      impact of geopolitical risk on CO2 emissions inequality: Evidence from 38 developed and devel-
      oping economies. Journal of Environmental Management, 349, 119345. https://​doi.​org/​10.​1016/j.​
      jenvm​an.​2023.​119345
Chen, L., Xu, L., & Yang, Z. (2019b). Inequality of industrial carbon emissions of the urban agglomera-
      tion and its peripheral cities: A case in the Pearl River Delta, China. Renewable and Sustainable
      Energy Reviews, 109, 438–447. https://​doi.​org/​10.​1016/j.​rser.​2019.​04.​010
Cheng, S., Fan, W., Zhang, J., Wang, N., Meng, F., & Liu, G. (2021). Multi-sectoral determinants of
      carbon emission inequality in Chinese clustering cities. Energy, 214, 118944. https://​doi.​org/​10.​
      1016/j.​energy.​2020.​118944
Chovancová, J., Zambrano-Monserrate, M. A., Bergougui, B., Ahakwa, I., & Dam, M. M. (2024). Global
      determinants of methane emissions in OECD countries: A dynamic panel approach. Research in
      Globalization, 9, 100232. https://​doi.​org/​10.​1016/j.​resglo.​2024.​100232
Clarke-Sather, A., Qu, J., Wang, Q., Zeng, J., & Li, Y. (2011). Carbon inequality at the sub-national
      scale: A case study of provincial-level inequality in CO2 emissions in China 1997–2007. Energy
      Policy, 39(9), 5420–5428. https://​doi.​org/​10.​1016/j.​enpol.​2011.​05.​021
Coondoo, D., & Dinda, S. (2008). Carbon dioxide emission and income: A temporal analysis of cross-
      country distributional patterns. Ecological Economics, 65(2), 375–385. https://​doi.​org/​10.​1016/j.​
      ecole​con.​2007.​07.​001
Depren, S. K., Kartal, M. T., Ertuğrul, H. M., & Depren, Ö. (2022). The role of data frequency and method
      selection in electricity price estimation: Comparative evidence from Turkey in pre-pandemic and pan-
      demic periods. Renewable Energy, 186, 217–225. https://​doi.​org/​10.​1016/j.​renene.​2021.​12.​136
Doğan, B., Balsalobre-Lorente, D., & Nasir, M. A. (2020). European commitment to COP21 and the
      role of energy consumption, FDI, trade and economic complexity in sustaining economic growth.
      Journal of Environmental Management, 273, 111146.
Doğan, B., Chu, L. K., Ghosh, S., Truong, H. H. D., & Balsalobre-Lorente, D. (2022a). How envi-
      ronmental taxes and carbon emissions are related in the G7 economies? Renewable Energy, 187,
      645–656. https://​doi.​org/​10.​1016/j.​renene.​2022.​01.​077
Doğan, B., Driha, O. M., Balsalobre Lorente, D., & Shahzad, U. (2021). The mitigating effects of eco-
      nomic complexity and renewable energy on carbon emissions in developed countries. Sustainable
      Development, 29(1), 1–12. https://​doi.​org/​10.​1002/​sd.​2125
Doğan, B., Ghosh, S., Hoang, D. P., & Chu, L. K. (2022b). Are economic complexity and eco-innovation
      mutually exclusive to control energy demand and environmental quality in E7 and G7 countries?
      Technology in Society, 68, 101867.
Dogan, B., Madaleno, M., Tiwari, A. K., & Hammoudeh, S. (2020). Impacts of export quality on envi-
      ronmental degradation: Does income matter? Environmental Science and Pollution Research, 27,
      13735–13772. https://​doi.​org/​10.​1007/​s11356-​019-​07371-5
Doğan, B., Shahbaz, M., Bashir, M. F., Abbas, S., & Ghosh, S. (2023). Formulating energy security strate-
      gies for a sustainable environment: Evidence from the newly industrialized economies. Renewable
      and Sustainable Energy Reviews, 184, 113551. https://​doi.​org/​10.​1016/j.​rser.​2023.​113551
Impact of environmental technology, economic complexity,…


Dogan, E., Chishti, M. Z., Alavijeh, N. K., & Tzeremes, P. (2022). The roles of technology and Kyoto Pro-
       tocol in energy transition towards COP26 targets: Evidence from the novel GMM-PVAR approach for
       G-7 countries. Technological Forecasting and Social Change, 181, 121756. https://​doi.​org/​10.​1016/j.​
       techf​ore.​2022.​121756
Dong, C., Wu, H., Zhou, J., Lin, H., & Chang, L. (2023). Role of renewable energy investment and geo-
       political risk in green finance development: Empirical evidence from BRICS countries. Renewable
       Energy, 207, 234–241. https://​doi.​org/​10.​1016/j.​renene.​2023.​02.​115
Ganda, F. (2019). The impact of innovation and technology investments on carbon emissions in selected
       organisation for economic Co-operation and development countries. Journal of Cleaner Production,
       217, 469–483. https://​doi.​org/​10.​1016/j.​jclep​ro.​2019.​01.​235
Grunewald, N., Klasen, S., Martínez-Zarzoso, I., & Muris, C. (2017). The trade-off between income ine-
       quality and carbon dioxide emissions. Ecological Economics, 142, 249–256. https://​doi.​org/​10.​
       1016/j.​ecole​con.​2017.​06.​034
Hansen, L. P. (1982). Large Sample Properties of Generalized Method of Moments Estimators. Economet-
       rica, 50, 1029–1054. https://​doi.​org/​10.​2307/​19127​75
Hao, Y., Chen, H., & Zhang, Q. (2016). Will income inequality affect environmental quality? Analysis based
       on China’ s provincial panel data. Ecological Indicators, 67, 533–542. https://​doi.​org/​10.​1016/j.​ecoli​
       nd.​2016.​03.​025
Hart, S. L., & Dowell, G. (2011). Invited editorial: A natural-resource-based view of the firm: Fifteen years
       after. Journal of Management, 37(5), 1464–1479. https://​doi.​org/​10.​1177/​01492​06310​390219
Heerink, N., Mulatu, A., & Bulte, E. (2001). Income inequality and the environment: Aggregation bias
       in environmental Kuznets curves. Ecological Economics, 38(3), 359–367. https://​doi.​org/​10.​1016/​
       S0921-​8009(01)​00171-9
Holtz-Eakin, D., Newey, W., & Rosen, H. S. (1988). Estimating Vector Autoregressions with Panel Data.
       Econometrica, 56, 1371. https://​doi.​org/​10.​2307/​19131​03
Hubacek, K., Baiocchi, G., Feng, K., Muñoz Castillo, R., Sun, L., & Xue, J. (2017b). Global carbon ine-
       quality. Energy, Ecology and Environment, 2, 361–369. https://​doi.​org/​10.​1007/​s40974-​017-​0072-9
Hubacek, K., Baiocchi, G., Feng, K., & Patwardhan, A. (2017a). Poverty eradication in a carbon constrained
       world. Nature Communications, 8(1), 912. https://​doi.​org/​10.​1038/​s41467-​017-​00919-4
Hussain, M., & Dogan, E. (2021). The role of institutional quality and environment-related technologies in
       environmental degradation for BRICS. Journal of Cleaner Production, 304, 127059. https://​doi.​org/​
       10.​1016/j.​jclep​ro.​2021.​127059
Hussain, M., & Khan, J. A. (2023). The nexus of environment-related technologies and consumption-based
       carbon emissions in top five emitters: Empirical analysis through dynamic common correlated effects
       estimator. Environmental Science and Pollution Research, 30(10), 25059–25068. https://​doi.​org/​10.​
       1007/​s11356-​021-​15333-z
Hussain, M., Mir, G. M., Usman, M., Ye, C., & Mansoor, S. (2022). Analysing the role of environment-
       related technologies and carbon emissions in emerging economies: A step towards sustainable devel-
       opment. Environmental Technology, 43(3), 367–375. https://​doi.​org/​10.​1080/​09593​330.​2020.​17881​
       71
Ivanova, D., Stadler, K., Steen-Olsen, K., Wood, R., Vita, G., Tukker, A., & Hertwich, E. G. (2016). Envi-
       ronmental impact assessment of household consumption. Journal of Industrial Ecology, 20(3), 526–
       536. https://​doi.​org/​10.​1111/​jiec.​12371
Ivanova, D., & Wood, R. (2020). The unequal distribution of household carbon footprints in Europe and its
       link to sustainability. Global Sustainability, 3, e18. https://​doi.​org/​10.​1017/​sus.​2020.​12
Jahanger, A., Hossain, M. R., Awan, A., et al. (2023). Linking tourist’ s footprint and environmental tragedy
       through transportation, globalization and energy choice in BIMSTEC region: Directions for a sus-
       tainable solution using novel GMM-PVAR approach. Journal of Environmental Management, 345,
       118551. https://​doi.​org/​10.​1016/j.​jenvm​an.​2023.​118551
Jian, X., & Afshan, S. (2023). Dynamic effect of green financing and green technology innovation on carbon
       neutrality in G10 countries: fresh insights from CS-ARDL approach. Economic Research-Ekonomska
       Istraživanja. https://​doi.​org/​10.​1080/​13316​77X.​2022.​21303​89
Jorgenson, A. K., Schor, J. B., Knight, K. W., & Huang, X. (2016). Domestic inequality and carbon emis-
       sions in comparative perspective. In Sociological Forum. https://​doi.​org/​10.​1111/​socf.​12272
Jorgenson, A., Schor, J., & Huang, X. (2017). Income inequality and carbon emissions in the United States:
       A state-level analysis, 1997–2012. Ecological Economics, 134, 40–48. https://​doi.​org/​10.​1016/j.​ecole​
       con.​2016.​12.​016
Kartal, M. T. (2024). Time, frequency, and quantile-based role of R&D investments in energy on sectoral
       degradation in the United States. Energy & Environment. https://​doi.​org/​10.​1177/​09583​05X24​12285​
       08
                                                                                               B. Bergougui et al.


Kartal, M. T. (2022). The role of consumption of energy, fossil sources, nuclear energy, and renewable
      energy on environmental degradation in top-five carbon producing countries. Renewable Energy, 184,
      871–880. https://​doi.​org/​10.​1016/j.​renene.​2021.​12.​022
Kartal, M. T. (2023). Production-based disaggregated analysis of energy consumption and CO2 emission
      nexus: Evidence from the USA by novel dynamic ARDL simulation approach. Environmental Sci-
      ence and Pollution Research, 30(3), 6864–6874. https://​doi.​org/​10.​1007/​s11356-​022-​22714-5
Khezri, M., Heshmati, A., & Khodaei, M. (2022). Environmental implications of economic complexity and
      its role in determining how renewable energies affect CO2 emissions. Applied Energy, 306, 117948.
      https://​doi.​org/​10.​1016/j.​apene​rgy.​2021.​117948
Krey, V., O’ Neill, B. C., van Ruijven, B., Chaturvedi, V., Daioglou, V., Eom, J., & Ren, X. (2012). Urban
      and rural energy use and carbon dioxide emissions in Asia. Energy Economics. https://​doi.​org/​10.​
      1016/j.​eneco.​2012.​04.​013
Liao, M., Jia, J., Han, G., et al. (2023). Reduced carbon footprint inequality in China: Evidence from latest
      household survey data. Journal of Cleaner Production, 384, 135342. https://​doi.​org/​10.​1016/j.​jclep​ro.​
      2022.​135342
Lin, K., Ghosh, S., Abbas, S., Shahbaz, M., Ferraz, D., & Doğan, B. (2024). Heterogenous impact of energy
      security and environmental regulations on energy transition: exploring the disparity between high-
      income and middle-income countries. Renewable Energy. https://​doi.​org/​10.​1016/j.​renene.​2024.​
      121610
Liu, C., Jiang, Y., & Xie, R. (2019). Does income inequality facilitate carbon emission reduction in the US?
      Journal of Cleaner Production, 217, 380–387. https://​doi.​org/​10.​1016/j.​jclep​ro.​2019.​01.​242
Lomborg, B. (2020). Welfare in the 21st century: Increasing development, reducing inequality, the impact of
      climate change, and the cost of climate policies. Technological Forecasting and Social Change, 156,
      119981. https://​doi.​org/​10.​1016/j.​techf​ore.​2020.​119981
Lucas, C., Thomas, P., (2015) Carbon and inequality: from Kyoto to Paris. Paris. https://​doi.​org/​10.​13140/​
      RG.2.​1.​3536.​0082
Mehmood, U., Tariq, S., Haq, Z. U., Nawaz, H., Ali, S., Murshed, M., & Iqbal, M. (2023). Evaluating the
      role of renewable energy and technology innovations in lowering CO2 emission: A wavelet coherence
      approach. Environmental Science and Pollution Research, 30(15), 44914–44927. https://​doi.​org/​10.​
      1007/​s11356-​023-​25379-w
Mongo, M., Belaïd, F., & Ramdani, B. (2021). The effects of environmental innovations on CO2 emis-
      sions: Empirical evidence from Europe. Environmental Science & Policy, 118, 1–9. https://​doi.​org/​10.​
      1016/j.​envsci.​2020.​12.​004
Nickell, S. (1981). Biases in Dynamic Models with Fixed Effects. Econometrica, 49, 1417. https://​doi.​org/​
      10.​2307/​19114​08
Numan, U., Ma, B., Aslam, M., Bedru, H. D., Jiang, C., & Sadiq, M. (2023). Role of economic complex-
      ity and energy sector in moving towards sustainability in the exporting economies. Energy Strategy
      Reviews, 45, 101038. https://​doi.​org/​10.​1016/j.​esr.​2022.​101038
Nwani, C., & Adams, S. (2021). Environmental cost of natural resource rents based on production and con-
      sumption inventories of carbon emissions: Assessing the role of institutional quality. Resources Pol-
      icy, 74, 102282. https://​doi.​org/​10.​1016/j.​resou​rpol.​2021.​102282
Ogiemwonyi, O. (2022). Factors influencing generation Y green behaviour on green products in Nigeria: An
      application of theory of planned behaviour. Environmental and Sustainability Indicators, 13, 100164.
      https://​doi.​org/​10.​1016/j.​indic.​2021.​100164
Oswald, Y., Owen, A., & Steinberger, J. K. (2020). Large inequality in international and intranational energy
      footprints between income groups and across consumption categories. Nature Energy, 5(3), 231–239.
      https://​doi.​org/​10.​1038/​s41560-​020-​0579-8
Oxfam, (2015). Extreme Carbon Inequality. Oxfam Media Briefing. https://​www.​oxfam​ameri​ca.​org/​explo​re/​
      resea​rch-​publi​catio​ns/​extre​me-​carbon-​inequ​ality/.
Özkan, O., Eweade, B. S., & Adebayo, T. S. (2024). Examining the effects of energy efficiency R&D and
      renewable energy on environmental sustainability amidst political risk in France. Politická Ekonomie,
      72(2), 331–356.
Paramati, S. R., Shahzad, U., & Doğan, B. (2022). The role of environmental technology for energy demand
      and energy efficiency: Evidence from OECD countries. Renewable and Sustainable Energy Reviews,
      153, 111735. https://​doi.​org/​10.​1016/j.​rser.​2021.​111735
Pata, U. K. (2021). Renewable and non-renewable energy consumption, economic complexity, CO 2
      emissions, and ecological footprint in the USA: Testing the EKC hypothesis with a structural
      break. Environmental Science and Pollution Research, 28, 846–861. https://​doi.​org/​10.​1007/​
      s11356-​020-​10446-3
Impact of environmental technology, economic complexity,…


Payne, J. E., Truong, H. H. D., Chu, L. K., Doğan, B., & Ghosh, S. (2023). The effect of economic
      complexity and energy security on measures of energy efficiency: Evidence from panel quantile
      analysis. Energy Policy, 177, 113547. https://​doi.​org/​10.​1016/j.​enpol.​2023.​113547
Pesaran, M. H. (2007). A simple panel unit root test in the presence of cross-section dependence. J Appl
      Econom, 22, 265–312. https://​doi.​org/​10.​1002/​jae.​951
Pesaran, M. H. (2021). General diagnostic tests for cross-sectional dependence in panels. Empirical Eco-
      nomics, 60, 13–50. https://​doi.​org/​10.​1007/​s00181-​020-​01875-7
Rao, N. D., & Min, J. (2018). Less global inequality can improve climate outcomes. Wiley Interdiscipli-
      nary Reviews: Climate Change, 9(2), e513. https://​doi.​org/​10.​1002/​wcc.​513
Ravallion, M., Heil, M., & Jalan, J. (2000). Carbon emissions and income inequality. Oxford Economic
      Papers, 52(4), 651–669. https://​doi.​org/​10.​1093/​oep/​52.4.​651
Rojas-Vallejos, J., & Lastuka, A. (2020). The income inequality and carbon emissions trade-off revisited.
      Energy Policy, 139, 111302. https://​doi.​org/​10.​1016/j.​enpol.​2020.​111302
Saqib, N., Radulescu, M., Usman, M., Balsalobre-Lorente, D., & Cilan, T. (2023). Environmental tech-
      nology, economic complexity, renewable electricity, environmental taxes and CO2 emissions:
      Implications for low-carbon future in G-10 bloc. Heliyon. https://​doi.​org/​10.​1016/j.​heliy​on.​2023.​
      e16457
Sawadogo, R., & Ouoba, Y. (2024). Do natural resources rents reduce income inequality? A finite mix-
      ture of regressions approach. Resources Policy, 91, 104870. https://​doi.​org/​10.​1016/j.​resou​r pol.​
      2024.​104870
Shang, T., Samour, A., Abbas, J., Ali, M., & Tursoy, T. (2024). Impact of financial inclusion, economic
      growth, natural resource rents, and natural energy use on carbon emissions: the MMQR approach.
      Environment, Development and Sustainability,. https://​doi.​org/​10.​1007/​s10668-​024-​04513-9
Shao, X., Zhong, Y., Liu, W., & Li, R. Y. M. (2021). Modeling the effect of green technology innovation and
      renewable energy on carbon neutrality in N-11 countries? Evidence from advance panel estimations.
      Journal of Environmental Management, 296, 113189. https://​doi.​org/​10.​1016/j.​jenvm​an.​2021.​113189
Shinwari, R., Yangjie, W., Payab, A. H., Kubiczek, J., & Dördüncü, H. (2022). What drives investment in
      renewable energy resources? Evaluating the role of natural resources volatility and economic perfor-
      mance for China. Resources Policy, 77, 102712. https://​doi.​org/​10.​1016/j.​resou​rpol.​2022.​102712
Sigmund, M., & Ferstl, R. (2021). Panel vector autoregression in R with the package panelvar. Q Rev
      Econ Financ, 80, 693–720. https://​doi.​org/​10.​1016/j.​qref.​2019.​01.​001
Sims, C. A. (1980). Macroeconomics and Reality. Econometrica, 48, 1. https://​doi.​org/​10.​2307/​19120​17
Sohag, K., Hammoudeh, S., Elsayed, A. H., Mariev, O., & Safonova, Y. (2022). Do geopolitical events
      transmit opportunity or threat to green markets? Decomposed measures of geopolitical risks.
      Energy Economics, 111, 106068. https://​doi.​org/​10.​1016/j.​eneco.​2022.​106068
Solt, F. (2009). Standardizing the world income inequality database. Social Science Quarterly, 90(2),
      231–242. https://​doi.​org/​10.​1111/j.​1540-​6237.​2009.​00614.x
Töbelmann, D., & Wendler, T. (2020). The impact of environmental innovation on carbon dioxide emis-
      sions. Journal of Cleaner Production, 244, 118787. https://​doi.​org/​10.​1016/j.​jclep​ro.​2019.​118787
Torras, M., & Boyce, J. K. (1998). Income, inequality, and pollution: A reassessment of the environ-
      mental Kuznets curve. Ecological Economics, 25(2), 147–160. https://​doi.​org/​10.​1016/​S0921-​
      8009(97)​00177-8
Ullah, S., Ozturk, I., Majeed, M. T., & Ahmad, W. (2021). Do technological innovations have symmetric
      or asymmetric effects on environmental quality? Evidence from Pakistan. Journal of Cleaner Pro-
      duction, 316, 128239. https://​doi.​org/​10.​1016/j.​jclep​ro.​2021.​128239
Ulussever, T., Kartal, M. T., & Kılıç Depren, S. (2023). Effect of income, energy consumption, energy
      prices, political stability, and geopolitical risk on the environment: evidence from GCC countries by
      novel quantile-based methods. Energy & Environment. https://​doi.​org/​10.​1177/​09583​05X23​11903​51
UN Department of Economic and Social Affairs, (2020). World Social Report https://​doi.​org/​10.​18356/​
      7f5d0​efc-​en.
Usman, O., Ozkan, O., Koy, A., & Adebayo, T. S. (2024). Energy-related uncertainty shocks and infla-
      tion dynamics in the US: A multivariate quantile-on-quantile regression approach. Structural
      Change and Economic Dynamics, 71, 235–247. https://​doi.​org/​10.​1016/j.​strue​co.​2024.​07.​012
Uzar, U., & Eyuboglu, K. (2019). The nexus between income inequality and CO2 emissions in Turkey.
      Journal of Cleaner Production, 227, 149–157. https://​doi.​org/​10.​1016/j.​jclep​ro.​2019.​04.​169
Wang, K., Cui, Y., Zhang, H., Shi, X., Xue, J., & Yuan, Z. (2022). Household carbon footprints inequal-
      ity in China: Drivers, components and dynamics. Energy Economics, 115, 106334. https://​doi.​org/​
      10.​1016/j.​eneco.​2022.​106334
                                                                                              B. Bergougui et al.


Wang, M., & Feng, C. (2022). Tracking the inequalities of global per capita carbon emissions from per-
      spectives of technological and economic gaps. Journal of Environmental Management, 315, 115144.
      https://​doi.​org/​10.​1016/j.​jenvm​an.​2022.​115144
Wiedenhofer, D., Guan, D., Liu, Z., Meng, J., Zhang, N., & Wei, Y. M. (2017). Unequal household carbon
      footprints in China. Nature Climate Change, 7(1), 75–80. https://​doi.​org/​10.​1038/​nclim​ate31​65
Wu, S., & Chen, Z. M. (2023). Carbon inequality in China: Evidence from city-level data. China Economic
      Review, 78, 101940. https://​doi.​org/​10.​1016/j.​chieco.​2023.​101940
Xia, W., Apergis, N., Bashir, M. F., Ghosh, S., Doğan, B., & Shahzad, U. (2022). Investigating the role
      of globalization, and energy consumption for environmental externalities: Empirical evidence from
      developed and developing economies. Renewable Energy, 183, 219–228. https://​doi.​org/​10.​1016/j.​
      renene.​2021.​10.​084
Xin, D., Ahmad, M., Lei, H., & Khattak, S. I. (2021). Do innovation in environmental-related technolo-
      gies asymmetrically affect carbon dioxide emissions in the United States? Technology in Society, 67,
      101761. https://​doi.​org/​10.​1016/j.​techs​oc.​2021.​101761
Xu, C. (2023). Economic inequality and carbon inequality: Multi-evidence from China’ s cities and coun-
      ties. Journal of Environmental Management, 327, 116871. https://​doi.​org/​10.​1016/j.​jenvm​an.​2022.​
      116871
Xu, C., Wang, B., Chen, J., Shen, Z., Song, M., & An, J. (2022). Carbon inequality in China: Novel driv-
      ers and policy driven scenario analysis. Energy Policy, 170, 113259. https://​doi.​org/​10.​1016/j.​enpol.​
      2022.​113259
Yahong, W., Cai, Y., Khan, S., & Chandio, A. A. (2023). How do clean fuels and technology-based energy
      poverty affect carbon emissions? New evidence from eighteen developing countries. Environmental
      Science and Pollution Research, 30(13), 37396–37414. https://​doi.​org/​10.​1007/​s11356-​022-​24798-5
Zambrano-Monserrate, M. A., Subramaniam, Y., Adnan, N., Bergougui, B., & Adebayo, T. S. (2024).
      Dynamic factors driving PM2.5 concentrations: Fresh evidence at the global level. Environmental
      Pollution, 362, 124940. https://​doi.​org/​10.​1016/j.​envpol.​2024.​124940
Zhao, C., Li, Y., Liu, Z., & Ma, X. (2024a). Artificial intelligence and carbon emissions inequality: Evi-
      dence from industrial robot application. Journal of Cleaner Production, 438, 140817. https://​doi.​org/​
      10.​1016/j.​jclep​ro.​2024.​140817
Zhao, D., Chaudhry, M. O., Ayub, B., Waqas, M., & Ullah, I. (2024b). Modeling the Nexus between geopo-
      litical risk, oil price volatility and renewable energy investment; evidence from Chinese listed firms.
      Renewable Energy, 225, 120309. https://​doi.​org/​10.​1016/j.​renene.​2024.​120309
Zhao, M., & Chan, H. S. (2022). Can inequality reduction decrease carbon emissions in China? A coun-
      terfactual analysis. Journal of Environmental Management, 322, 116089. https://​doi.​org/​10.​1016/j.​
      jenvm​an.​2022.​116089
Zheng, F., Zhou, X., Rahat, B., & Rubbaniy, G. (2021). Carbon neutrality target for leading exporting coun-
      tries: On the role of economic complexity index and renewable energy electricity. Journal of Environ-
      mental Management, 299, 113558. https://​doi.​org/​10.​1016/j.​jenvm​an.​2021.​113558
Zheng, H., Wood, R., Moran, D., Feng, K., Tisserant, A., Jiang, M., & Hertwich, E. G. (2023). Rising car-
      bon inequality and its driving factors from 2005 to 2015. Global Environmental Change, 82, 102704.
      https://​doi.​org/​10.​1016/j.​gloen​vcha.​2023.​102704

Publisher’s Note Springer Nature remains neutral with regard to jurisdictional claims in published maps and
institutional affiliations.




Authors and Affiliations

Brahim Bergougui1,2           · Buhari Doğan3,4,5 · Sudeshna Ghosh6 · Hicham Ayad7

* Brahim Bergougui
  bergougui@iss.nl; brahimbergougui@gmail.com
    Buhari Doğan
    doganbuhari@gmail.com
    Sudeshna Ghosh
    sudeshna.ghosh@scottishchurch.ac.in
Impact of environmental technology, economic complexity,…


    Hicham Ayad
    a_hichem210@hotmail.fr; h.ayad@cu-maghnia.dz
1
    International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague,
    The Netherlands
2
    National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
3
    Department of Economics, Suleyman Demirel University, Isparta, Turkey
4
    INTI International University, Kuala Lumpur, Malaysia
5
    MEU Research Unit, Middle East University, Amman, Jordan
6
    Department of Economics, Scottish Church College, Kolkata, West Bengal, India
7
    Department of Economics, LEPESSE Laboratory, University Centre of Maghnia, Maghnia,
    Algeria
