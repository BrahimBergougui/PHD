Natural Resources Forum




   ARTICLE          OPEN ACCESS




Heterogeneous Spillover Effects: How FDI in Resources
Extraction, Manufacturing, and Services Affect Sectoral
Carbon Emissions in the MENA Region
Brahim Bergougui1,2            | Syed Mansoob Murshed3

1National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria | 2 International Institute of Social Studies (ISS), Erasmus

University Rotterdam, The Hague, the Netherlands | 3Ho Chi Minh City University of Economics and Finance, Ho Chi Minh City, Vietnam

Correspondence: Brahim Bergougui (bergougui@iss.nl; brahimbergougui@gmail.com)

Received: 6 April 2024 | Revised: 2 April 2025 | Accepted: 18 August 2025

Keywords: environmental spillovers | manufacturing FDI | resource extraction FDI | sectoral carbon emission | service FDI


  ABSTRACT
  The MENA region faces a critical challenge: balancing economic growth spurred by foreign direct investment (FDI) with en-
  vironmental sustainability. While FDI can bring technological advancements and capital, concerns exist about its potential to
  exacerbate environmental degradation, particularly carbon emissions. This study addresses this knowledge gap by investigating
  the environmental consequences of disaggregated FDI inflows (resource extraction, manufacturing, and services) on emissions
  from various economic sectors in the MENA region from 1990 to 2022 by employing the system generalized method of moments
  to test the “pollution haven” and “pollution halo” hypotheses at both aggregate and sectoral levels. Our findings reveal that, at
  the aggregate level, total FDI reduces economy-­w ide and tertiary sector emissions, primarily due to services FDI promoting
  clean technologies and structural transformation, supporting the “pollution halo” hypothesis. However, a disaggregated analysis
  shows that resource extraction and manufacturing FDI increase emissions across all sectors by expanding pollutive production
  and outsourced activities, aligning with the “pollution haven” effect. Conversely, services FDI consistently decreases emissions
  across all sectors, enhancing environmental quality and conforming to the “pollution halo” hypothesis. These insights hold
  policy significance for targeted incentives: promote clean services FDI while regulating resource extraction and manufacturing
  flows to balance economic growth and environmental sustainability. By investigating FDI's disaggregated effects, this study
  refines our understanding of environmental impacts and informs tailored policy strategies in the MENA region.


1   |   Introduction                                                                delineating fundamental principles for fostering sustainable
                                                                                    development. Certain nations demonstrate steadfast commit-
Transitioning to a low-­c arbon future represents one of the                        ment to these objectives, even in the face of potential setbacks
most pressing imperatives of the 21st century. Anthropogenic                        to economic growth. Conversely, other nations persist in pri-
activities, specifically those contributing to heightened en-                       oritizing economic growth and actively seek to attract foreign
ergy usage, fill a central position in discussions surround-                        direct investment (FDI) as a means to expand their economies
ing climate change and constitute an essential part of the                          (Hao et al. 2020; Luo et al. 2021). FDI often brings innovative
global initiatives aimed at tackling climate change (Zheng                          technologies and promotes environmentally good practices to
et al. 2023; Bergougui and Meziane 2025; Bergougui 2025a;                           host countries. Nevertheless, the pursuit of competitive eco-
Bergougui and Satrovic 2025). These activities also hold sig-                       nomic advantages may lead to the exploitation of lenient en-
nificance within the context of the 2030 Agenda, a framework                        vironmental regulations. In such instances, FDI serves as a



This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium,
provided the original work is properly cited.
© 2025 The Author(s). Natural Resources Forum published by John Wiley & Sons Ltd on behalf of United Nations.


Natural Resources Forum, 2026; 50:1299–1319                                                                                                                   1299
https://doi.org/10.1111/1477-8947.70028
                                                                                                                                                  14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 1    |    The nexus between FDI and environmental quality: A comprehensive review of the literature. Source: Demena and
Afesorgbor (2020).



channel for the relocation of polluting industries, hindering            determinants is the tendency to treat FDI as a homogeneous
progress toward achieving sustainable development goals                  bloc, without considering the specific sectors in which it is in-
(Dong et al. 2021; Balaguer et al. 2022; Uche et al. 2023; Bashir        vested. This approach (i.e., using total FDI) is problematic be-
et al. 2023; Ali et al. 2023; Tsoy and Heshmati 2023).                   cause FDI in different sectors is linked with different goods
                                                                         and services, and its environmental impact is expected to vary
The extant body of empirical research concerning the explica-            accordingly (Caetano et al. 2022; Solarin and Sahu 2023). For
tion of the FDI-­environment nexus has yielded inconclusive              example, resources extraction FDI is likely to have different
and perplexing findings, characterized by divergent outcomes,            environmental implications than FDI in manufacturing (sec-
including positive, negative, and insignificant effects (Shahbaz         ondary sector) or services (tertiary sector). Research on growth
et al. 2015; Liu et al. 2018; Yu and Xu 2019; Adeel-­Farooq              has demonstrated that FDI directed toward various sectors has
et al. 2021; Muhammad et al. 2021; Opoku et al. 2021; Abbas              varying effects on sector-­specific and overall economic growth
et al. 2023; Khan et al. 2023; Wang et al. 2023; Saqib et al. 2023;      via spillovers to other activities (Bergougui and Murshed 2023a,
Guo et al. 2023; Tsoy and Heshmati 2023). Employing the                  2023b). Similarly, we expect different sectoral FDI inflows to
meta-­analysis to scrutinize the corpus of literature on the FDI-­       have different environmental impacts.1 Regarding the Middle
environment nexus, including 83 studies from 2001 to 2018,               East and North Africa (MENA) region, significant variations
Demena and Afesorgbor (2020) confirms the persistent hetero-             exist in the sectoral distribution of FDI inflows among coun-
geneity within the FDI-­environmental nexus. To be precise, this         tries. For instance, several MENA countries, including Algeria
meta-­analysis reveals that 54% of the examined studies assert a         and Saudi Arabia, allocate a substantial proportion, ranging
negative impact of FDI on environmental indicators, juxtaposed           from 40% to 54% of their primary FDI sector, primarily en-
against 46% of studies espousing a positive impact of FDI. The           compassing petroleum and mining production. However, other
ambiguous nature of these findings extends beyond the sign of            MENA nations, such as Yemen, tend to allocate a major portion
the FDI-­elasticity of emissions to encompass the statistical sig-       of their FDI toward the manufacturing sector. Notably, the ser-
nificance thereof. For those investigations positing a negative          vices sector captures a substantial share of FDI in most MENA
FDI-­environment relationship, 29% establish a statistically sig-        countries, including Egypt, Tunisia, Türkiye, and UAE. This
nificant relationship, while 25% fail to ascertain a statistically       trend is corroborated by Figure 2, which portrays the sectoral
significant effect. Analogously, this pattern manifests in studies       distribution of FDI inflows in the MENA region. As depicted,
advocating a positive FDI-­environment nexus (see Figure 1). A           FDI directed toward the services sector exceeded that allocated
recent meta-­analysis by Wei et al. (2022) corroborates the find-        to the resource extraction and manufacturing sectors in 2004
ings of Demena and Afesorgbor (2020). Their research revealed            and has consistently served as the predominant catalyst for FDI
that 38% of studies examining the relationship between FDI and           inflows, a phenomenon well-­established in previous scholarly
environmental pollution in China reported a negative relation-           investigations (Doytch and Uctum 2019). Accordingly, an exam-
ship, indicating that FDI can reduce pollution.                          ination of the nexus between FDI and environmental sustain-
                                                                         ability in the MENA region necessitates a nuanced approach,
Therefore, the issue remains unresolved. The inconsistent re-            distinguishing between the effects of FDI at both aggregate and
sults across studies may be due to data-­related concerns, as            sector-­specific levels. Our core research objective is to explore
highlighted in previous research (Doytch and Uctum 2016;                 the impact of FDI on environmental sustainability in the MENA
Pazienza 2019; Demena and Afesorgbor 2020; Doytch 2020). In              region, considering both overall and specific industry-­level in-
particular, one persistent challenge in studying environmental           vestments, from 2000 to 2022.

1300                                                                                                              Natural Resources Forum, 2026
                                                                                                                                              14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 2    |    Sectoral FDI in the MENA region, 1990–2022. Source: United Nations Conference on Trade and Development and authors'
calculations.




1.1   |   Research Gaps and Study Contribution                          1.1.2   |   Study Contribution

1.1.1   |   Research Gaps                                               This study addresses these gaps and contributes to the literature
                                                                        in six ways.
Based on the above discussion, this study identifies several gaps
in the existing research on the relationship between FDI and              • Innovatively, we use a unique dataset, encompassing sector-­
CO2 emissions:                                                              specific FDI information relating to 13 MENA countries
                                                                            from 1990 to 2022. The initial dataset, as sourced from the
  • Lack of Sectoral Analysis: Most prior studies rely on ag-               United Nations (UNCTAD 2021), has been subsequently
    gregate data, overlooking the specific composition of                   updated by incorporating data from the International Trade
    FDI and its varying environmental impacts across sec-                   Center (ITC 2023), thus ensuring a comprehensive and up-­
    tors (resources extraction, manufacturing, and services).               to-­date foundation for our analysis.
    This study addresses this gap by employing a sectoral
                                                                          • In contrast to earlier environmental studies that have em-
    approach.
                                                                            ployed aggregate-­    level analyses, this study represents a
  • Limited Focus on MENA Region: Existing research has pri-                pioneering effort by introducing a comprehensive sectoral
    marily focused on OECD countries or developing countries                approach to examining the environmental impact of FDI in
    as a whole. This study fills the gap by examining the FDI-­             MENA countries. As noted by Pazienza (2019) and Caetano
    pollution nexus specifically within the MENA region, char-              et al. (2022), it is somewhat remarkable that the majority of
    acterized by unique economic development patterns and                   empirical investigations have relied on aggregate data while
    environmental challenges.                                               overlooking the specific composition of FDI, particularly
                                                                            considering the sector-­specific nature of FDI's environmen-
  • Endogeneity and Simultaneity Issues: Previous research
                                                                            tal effects. Our research employs sectoral analysis, differ-
    has not adequately addressed potential biases arising from
                                                                            entiating between resource extraction, manufacturing, and
    omitted variables and reverse causality between FDI and
                                                                            services sectors, to evaluate its environmental effect at the
    environmental factors. This study tackles these issues by
                                                                            aggregate and sectoral levels. Hence, the results could be
    employing a dynamic panel data approach with instrumen-
                                                                            improved in terms of accuracy, enabling policymakers to
    tal variables and system-­GMM estimators.
                                                                            enact tailored policies for individual sectors separately, in-
  • Scarcity of Sectoral FDI-­Pollution Studies: The study high-            stead of implementing aggregate-­level policies that might
    lights the lack of research that specifically explores the              not be well-­suited.
    relationship between FDI in different sectors and CO2
                                                                          • This study tackled two crucial methodological challenges
    emissions.
                                                                            on the relationship between FDI and the environment,
  • Data Limitations: Many studies have been constrained by                 namely, endogeneity and simultaneity. To begin with,
    incomplete or outdated datasets, particularly for sector-­              we recognized the issue of omitted variable bias, where
    specific FDI information in MENA countries.                             a country's environmental choices might be influenced



Natural Resources Forum, 2026                                                                                                          1301
                                                                                                                                            14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
   by hidden factors. To mitigate this concern, we incor-                region exceeded 4 million metric tons of CO2 equivalent,
   porated country-­fixed effects to account for unchanging              accounting for over 7% of global emissions from fossil fuel
   variations over time (Baltagi 2005; Wooldridge 2010).                 combustion. Interestingly, the MENA economies did not
   Additionally, we acknowledged the potential for reverse               sign the Kyoto Protocol, which sought to cap emissions at
   causality between FDI and environmental factors, as                   specified levels (Shahbaz et al. 2019). These reasons render
   noted by Copeland and Taylor (1994), who argue that                   the MENA region a particularly interesting subject for this
   pollution policies can respond to changes in income and               study's examination of how FDI differentially affects carbon
   prices resulting from global activities like FDI and trade.           emissions across sectors. By abstaining from international
   This potential source of simultaneity bias demanded care-             commitments on emissions reductions and continually un-
   ful attention in our study. Previous research has grappled            derperforming on sustainability metrics related to climate
   with these challenges, which can introduce significant                change mitigation, these economies provide an interesting
   biases in estimates and render the results insignificant.             context for discerning the nuanced effects of diverse FDI
   In this study, we adopted a dynamic panel data approach,              inflows within the energy, industry, and service domains.
   following the methodologies proposed by Arellano and
   Bover (1995) and Blundell and Bond (1998). By employing             • Lastly, our research distinguishes itself from earlier stud-
   instrumental variables and the system-­GMM estimator,                 ies through its strategy for handling the problem of miss-
   our research effectively tackles endogeneity concerns as-             ing data in sectoral FDI inflow statistics, which arises from
   sociated with the relationship between economic growth,               incomplete coverage. To tackle this issue, we have used
   FDI, and pollution. This approach allows us to account                the multiple imputation (MI) method to complete missing
   for the dynamic nature of the data, capturing changes in              country-­level data, guaranteeing that every country has at
   sectoral FDI flows over time. Unlike conventional cross-­             least one instance of sectoral FDI data available.
   sectional time-­averaging methods, our methodology re-
   tains the time series dimension of the data, ensuring a           Our research finds that foreign direct investment (FDI) impacts
   more comprehensive analysis while controlling for endog-          on CO2 emissions depend on the type of investment. Overall,
   eneity and omitted variable bias.                                 FDI appears to benefit the environment in MENA economies.
                                                                     This is seen in reduced total CO2 emissions and lower emissions
 • Fourth, in terms of the dataset employed, there is a no-          specifically from the service sector. Taking a closer look at in-
   table paucity of studies that have scrutinized the sec-           dividual sectors, the results align with two opposing theories.
   toral FDI-­ pollution nexus. For example, Doytch and              Service sector FDI seems to follow the “pollution halo hypoth-
   Uctum (2016) and Doytch (2020) conducted their analyses           esis.” This means it leads to lower emissions by introducing
   using samples consisting of 177 and 132 countries, respec-        cleaner technologies, stricter environmental practices, and a
   tively, categorizing them based on their developmental            shift away from more polluting industries. On the other hand,
   stages. Pazienza (2019) and Caetano et al. (2022) focused         FDI in resource extraction and manufacturing tends to increase
   on countries within the Organization for Economic Co-­            CO2 emissions within those sectors, supporting the “pollution
   operation and Development (OECD) while Solarin and                haven hypothesis.”
   Sahu (2023) concentrating their investigation on the five
   BRICS economies. However, it is noteworthy that no prior
                                                                     These findings carry significant policy implications regarding
   research has specifically addressed this issue within the
                                                                     government incentives to attract FDI. Encouraging multina-
   MENA region.
                                                                     tional enterprises to invest in the services sector emerges as an
 • Our research on the economies of the MENA region is mo-           environmentally beneficial choice for the MENA region. Such
   tivated by their unique characteristics regarding disparities     investments not only lead to decreased CO2 emissions within
   in FDI as well as environmental impact. The region has            the services sector but also have spill-­over effects, positively
   seen considerable economic growth in recent years, mainly         reducing CO2 emissions in the primary and secondary sectors.
   attributable to its natural resource wealth (Saidi et al. 2020;   Consequently, policymakers should actively promote such in-
   Khalfaoui et al. 2023). This development involved a shift         vestments, tailoring their FDI promotion policies to incentivize
   from agriculture-­  based to industry-­focused and eventu-        different FDI categories appropriately. Simultaneously, regula-
   ally service-­sector-­driven economies, accompanied by ris-       tions are needed to curb emissions in resource-­intensive sectors
   ing FDI. However, this progress has been achieved at the          such as resource extraction and manufacturing, which often re-
   expense of strain on the region's ecological systems due          ceive FDI. Implementing economic incentives and performance
   to intensive energy usage and investments in dirty indus-         standards can encourage investors to adopt cleaner production
   tries (Kahia et al. 2017). Moreover, MENA economies are           over time, harmonizing growth with environmental sustain-
   still in the initial stages of industrialization, marked by       ability. Overall, this study provides a nuanced understanding of
   increased manufacturing output. There is broad consen-            FDI's differentiated environmental impacts to inform targeted
   sus on the urgent need for effective economic and energy          policy strategies.
   strategies to curb further deterioration of environmental
   quality (Shahbaz et al. 2019). These economies also account       This research enhances our understanding of the diverse en-
   for a substantial share of global crude oil, gas, and other       vironmental effects of FDI across sectors in the MENA region.
   fuel reserves, making energy production and usage major           However, it recognizes several significant limitations that high-
   contributors to greenhouse gas (GHG) emissions. In fact,          light opportunities for further exploration, such as its regional
   MENA accounts for about 85% of all GHG emissions from             focus exclusively on MENA countries. Moreover, while this
   such sources (Sun et al. 2022). In 2020, emissions from the       study differentiates environmental impacts across sectors, the

1302                                                                                                        Natural Resources Forum, 2026
                                                                                                                                            14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
broad categorization of the services sector remains a notable        2.1.1   |   Aggregate Level Evidence
limitation. The growing availability of disaggregated data on
services FDI within the MENA region presents an exciting op-         Empirical studies lend credence to the pollution haven hypothe-
portunity for future research to delve deeper into this area.        sis. For instance, Salahuddin et al. (2018) employed ARDL tech-
                                                                     niques to analyze data from Kuwait (1980–2013) and observed a
The structure of this paper is as follows. Section 2 provides a      positive association between FDI inflows and carbon emissions.
brief review of the relevant literature. Section 3 delineates the    Similarly, Blanco et al. (2013) utilized Granger causality tests for
model, the data, and the empirical methodology employed in           18 Latin American countries (1980–2007) and found that FDI
this study. Section 4 reports the empirical findings. Section 5      in polluting industries led to heightened environmental degra-
conducts a robustness analysis, and Section 6 concludes the          dation. This finding aligns with the pollution haven hypothesis,
paper with a summary and policy implications.                        further supported by Assamoi et al. (2020) who examined Cote
                                                                     d'Ivoire (1980–2014), and Djellouli et al. (2022) who investi-
                                                                     gated 20 African countries (2000–2015). Both studies employed
2   |   Literature Review                                            ARDL approaches and found a positive correlation between FDI
                                                                     and environmental degradation. Furthermore, recent litera-
A prominent area of inquiry within the scholarship on FDI            ture by Hanif et al. (2019), Waqih et al. (2019), and Chaudhry
and the environment concerns the influence of FDI on pollu-          et al. (2022) corroborates the pollution haven effect across di-
tion levels in host nations. However, a significant limitation of    verse countries, regions, and timeframes using various method-
extant research lies in its dependence on aggregate FDI data,        ologies and sample sizes.
neglecting the heterogeneity across industry sectors (Caetano
et al. 2022). This overreliance on aggregated analysis risks gen-    While the pollution haven hypothesis finds dedicated support,
erating misleading conclusions, as various sectors demonstrably      recent studies offer valuable refinements. Zhou et al. (2024) ex-
exhibit distinct environmental footprints. Consequently, schol-      amining Belt and Road Initiative (BRI) countries highlight the
ars have advocated for the utilization of disaggregated, sector-­    importance of environmental regulations. Their findings show
level FDI data to achieve a more nuanced understanding of the        a positive association between FDI and ecological footprint,
FDI-­pollution nexus. This section delves into the environmental     emphasizing the need for strong environmental standards to
implications of FDI for host countries, specifically focusing on     attract responsible investors and ensure sustainability within
two competing hypotheses: the pollution haven hypothesis and         BRI. Similarly, Ozturk et al. (2024) find evidence for the PHH
the pollution halo hypothesis. We will evaluate empirical evi-       in South Asian economies, but also suggest potential for FDI
dence for both propositions at both the aggregate and disaggre-      to contribute to environmental conservation efforts. Wang and
gated (sectoral) levels.                                             Uctum (2024) introduce a novel perspective by examining the
                                                                     role of income level. Their research suggests that FDI can have
                                                                     opposing environmental impacts depending on a country's in-
2.1   |   Pollution Haven Hypothesis                                 come level, potentially aligning with both the pollution haven
                                                                     and pollution halo hypotheses in different contexts. Finally, Zuo
The pollution haven hypothesis posits that multinational cor-        et al. (2024) using a global dataset find a significant positive as-
porations (MNCs) strategically relocate pollution-­intensive in-     sociation between FDI and carbon emissions, further support-
dustries to developing nations characterized by less stringent       ing the pollution haven hypothesis' concerns.
environmental regulations. This theoretical framework, initially
proposed by Walter and Ugelow (1979) and subsequently refined
by Baumol and Oates (1988), suggests that MNCs exploit reg-          2.1.2   |   Disaggregated Level Evidence
ulatory arbitrage opportunities to minimize compliance costs
associated with more rigorous environmental standards preva-         A burgeoning body of research delves into the nuanced effects
lent in developed economies. According to this paradigm, the         of FDI inflows on environmental quality within host coun-
disparities in environmental compliance costs and the internal-      tries, specifically examining the influence of FDI in different
ization of ecological externalities between developed and devel-     economic sectors. Several studies provide evidence supporting
oping economies serve as key determinants in shaping Foreign         the pollution haven hypothesis, which posits that FDI, par-
Direct Investment (FDI) flows. The hypothesis contends that ju-      ticularly in carbon-­intensive sectors, can exacerbate pollution
risdictions with comparatively weaker sustainability standards       in host countries. Blanco et al. (2013) present a seminal con-
may inadvertently become attractive “pollution havens” for in-       tribution by analyzing the relationship between sectoral FDI
dustries with high environmental impacts. Consequently, this         composition and environmental impacts in 18 Latin American
dynamic could potentially exacerbate environmental degrada-          nations (1980–2007). They differentiate FDI inflows into
tion in FDI recipient countries. A substantial body of literature    pollution-­intensive (“dirty”) categories (primary and manu-
supports this hypothesis, arguing that the regulatory leniency in    facturing industries) and low-­emission (“clean”) categories
developing countries facilitates the influx of emission-­intensive   (service sector) and assess their impact on per capita CO2
industries through FDI channels, thereby potentially contrib-        emissions. Their findings reveal a significant causal link be-
uting to environmental deterioration (Uche et al. 2023; Bashir       tween FDI in polluting activities and increased carbon emis-
et al. 2023; Ali et al. 2023). This phenomenon raises significant    sions, while no statistically significant association was found
concerns about the environmental implications of globalization       between service sector FDI and carbon emissions. Doytch
and the potential for a “race to the bottom” in environmental        and Uctum (2016) further buttress these findings through
standards.                                                           their study of 132 countries (1983–2011). They demonstrate

Natural Resources Forum, 2026                                                                                                       1303
                                                                                                                                          14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
that manufacturing FDI is most likely to elevate pollution lev-    Recent research sheds further light on the dynamics of the pol-
els, contradicting the “halo effect” theory suggesting cleaner     lution halo effect. Kharb et al. (2024) emphasize the importance
technology adoption by foreign firms. Their results indicate       of green FDI, which focuses on transferring environmentally
that “dirty” FDI, encompassing both manufacturing and non-­        friendly technologies. Their findings suggest that green FDI
financial services, detrimentally impacts the environment in       can promote both economic growth and reduced emissions.
less developed countries. For middle-­income countries, FDI in     This aligns with the pollution halo hypothesis by encouraging
agriculture and mining sectors contributes most significantly      the adoption of cleaner technologies. Hernández Soto (2024)
to rising emissions. Building upon this research, Caetano          examines the role of FDI in Latin America's transition towards
et al. (2022) analyze the environmental consequences of FDI        low-­carbon societies. While acknowledging mixed evidence
inflows across various sectors in 15 OECD countries (2005–         on its impact on renewable energy consumption, the study
2018). Their key findings illustrate that the environmental ef-    suggests that FDI can potentially reduce dependence on fossil
fects of FDI can vary by economic sector, even in developed        fuels, thereby supporting the pollution halo effect by promoting
nations with stricter environmental regulations. They observe      cleaner energy sources. However, their research underscores
that total FDI stock, along with FDI in manufacturing, con-        the need for targeted policies that attract green FDI to maximize
struction, and services, all contribute to increased emissions,    this effect. The effectiveness of the pollution halo effect may be
further solidifying the pollution haven hypothesis.                influenced by institutional frameworks. Boateng et al. (2024)
                                                                   suggest that FDI can lead to reduced emissions, but the magni-
                                                                   tude depends on the strength of a country's institutions. Stronger
2.2   |   Pollution Halo Hypothesis                                institutions allow for better regulation of foreign investors, po-
                                                                   tentially ensuring environmentally sound practices and sup-
Within the context of international trade, the pollution halo      porting the pollution halo effect. This highlights the importance
hypothesis posits that FDI can engender improvements in envi-      of robust institutions to maximize the environmental benefits
ronmental quality within host countries. This beneficial effect    of FDI.
is hypothesized to be driven by the transfer of cleaner tech-
nologies, the implementation of more rigorous environmental
practices, and the dissemination of heightened environmental       2.2.2   |   Disaggregated Level Evidence
awareness by MNCs. The concept was originally introduced by
Birdsall and Wheeler (1993).                                       The pollution halo hypothesis also finds support at the dis-
                                                                   aggregated (sectoral) level. Blanco et al. (2013) studied FDI
                                                                   in Latin American service sectors, considered “clean” indus-
2.2.1   |   Aggregate Level Evidence                               tries, and found no significant increase in CO2 emissions.
                                                                   This suggests that cleaner sectors might not contribute to
Several studies provide empirical support for the pollution halo   environmental degradation. Doytch (2020) investigated how
hypothesis, suggesting FDI can lead to improved environmen-        FDI in six sectors across developed and developing economies
tal quality in host countries. Eskeland and Harrison (2003)        affects ecological footprints. Notably, she identified a posi-
examined FDI inflows in Mexico, Venezuela, Morocco, and            tive environmental impact of FDI in financial services within
Côte d'Ivoire, finding that these investments were associated      developed economies, aligning with the notion of cleaner
with greater energy efficiency and cleaner production pro-         technologies and practices being transferred through FDI.
cesses. Similarly, Abdouli and Hammami (2017) employed a           Caetano et al. (2022) analyzed FDI flows into various sectors
dynamic GMM approach and confirmed a negative associa-             within 15 OECD countries (2005–2018) and observed a de-
tion between FDI and emissions in the MENA region (1990–           crease in pollution levels associated with FDI in the primary
2012). This positive impact of FDI on environmental quality        sector (agriculture). This finding adds to the evidence that FDI
extends to other developing economies. Merican et al. (2007)       in specific sectors can have a positive environmental impact.
utilized an ARDL technique in Indonesia and observed a sig-        Furthermore, recent studies by Solarin and Sahu (2023) and
nificant negative relationship between FDI and pollution lev-      Yi et al. (2023) provide evidence for reduced emissions with
els. Zameer et al. (2020) reached a similar conclusion through     increased manufacturing FDI in developing countries, par-
their analysis of the Indian economy (1985–2017). Likewise,        ticularly in less advanced subsectors. Solarin and Sahu (2023)
Hao et al. (2020) employed spatial econometric tools to inves-     analyzed nitrogen oxide emissions in BRICS countries (1992–
tigate 30 Chinese provinces (1998–2016), revealing a reduc-        2019) and found that increased FDI in manufacturing leads to
tion in environmental pollution with increased FDI. Apergis        lower pollution levels. Yi et al. (2023) examined carbon emis-
et al. (2023) conducted studies focusing on BRICS nations          sions across different subsectors within China's manufactur-
(1993–2012) and found evidence of a pollution halo effect, par-    ing sector (2003–2020). Their findings indicate a negative
ticularly concerning FDI from developed nations like France,       correlation, with FDI most effectively reducing emissions in
Germany, and Italy. Additionally, a meta-­a nalysis by Demena      labor-­intensive industries.
and Afesorgbor (2020) examining 65 studies strengthens the
case for FDI's positive impact on emissions reduction, even        These studies collectively suggest that FDI can indeed contribute
considering methodological variations. These findings are fur-     to positive environmental outcomes, supporting the pollution
ther corroborated by Yu and Li (2020) and Hamid et al. (2022),     halo hypothesis. They highlight the importance of considering
who highlight the beneficial environmental effects of FDI in       the sector, development level of the host country, and specific
developing countries.                                              industry characteristics when examining the environmental


1304                                                                                                      Natural Resources Forum, 2026
                                                                                                                                                       14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
impact of FDI. This research emphasizes the potential of FDI to      • Pi,t, Ai,t, and Ti,t denote the population, affluence, and tech-
transfer cleaner technologies and practices, particularly in de-       nology level of country i at time t, respectively.
veloping economies. Additionally, it suggests that well-­designed
                                                                     • 𝛼, B, γ, and 𝜔 are parameters to be estimated.
environmental regulations can amplify these benefits across
various industries.                                                  • 𝜀i,t is the residual term.

                                                                    For ease of research, a logarithmic transformation is often ap-
3   |   Methodology and Data                                        plied, resulting in:

3.1   |   Theoretical Framework                                          ln Ii,t = ln 𝛼 + B ln Pi,t + 𝛾 ln Ai,t + 𝜔 ln Ti,t + ln 𝜀i,t
                                                                                                                                                (2)
This study utilizes a novel analytical framework to investigate
the environmental implications of foreign direct investment         The STIRPAT model is used to analyze the environmental im-
(FDI) in the MENA region. Inspired by Markusen (1995), we ex-       pact of several factors, such as CO2 emissions. An extended form
tend the framework to two competing firms, one domestic and         of the model is2:
one foreign, operating in separate geographical markets. These        k
firms produce differentiated goods that are close substitutes for    Ei,t = 𝛼 0 + 𝛼 1 Ei,t−1 + 𝛼 2 FDIsi,t + 𝛼 3 GDPi,t + 𝛼 4 GDP2i,t + 𝛼 5 POPi,t
each other. Every firm has the strategic ability to influence the            + 𝛼 6 TECHi,t + 𝛼 7 IQi,t + 𝜇i + 𝛿 t + 𝛾 k + 𝜀i,t
price of its product within its respective market. Additionally,                                                                                 (3)
firms can choose between solely domestic production or es-          where
tablishing a local presence in the other country, effectively be-
coming multinational enterprises. This framework focuses on          • Ei,t
                                                                         k
                                                                            is CO2 emissions from sector k in million tons {the “k”
horizontal FDI, where firms replicate production processes             superscript represents carbon emissions from the primary,
across countries, reflecting the dominant FDI pattern observed         secondary, tertiary sectors, and the total}.
in the MENA region. Vertical FDI, involving fragmented pro-
duction stages across borders, is intentionally excluded to          • Ei,t−1 is the lagged CO2 emissions.3
align with the empirical evidence presented in prior research        • FDIsit refers to FDI inflows as a share of GDP {The super-
(Markusen 1995; Carr et al. 2001).                                     script “s” in this context represents the resources extraction,
                                                                       manufacturing, and service sectors, as well as the aggregate
To estimate the model's impact on the environment, we incorpo-         FDI}.
rate three key hypotheses:
                                                                     • GDPi,t and GDP2i,t represent economic growth and its square,
  • Environmental Kuznets Curve (EKC): This predicts an in-            respectively.
    verted U-­shaped relationship between economic growth            • POPi,t is population growth.
    and pollution (Grossman and Krueger 1991). Pollution may
    initially rise with growth but eventually decline.               • TECHi,t is technological innovation.

  • Pollution Haven Hypothesis (PHH): This suggests de-              • IQi,t is an institutional quality variable.
    veloping countries with higher levels of FDI (more open          • 𝜇i this signifies the fixed effects that are specific to each
    economies) experience increased environmental pollution            country, which encapsulate the unseen heterogeneity that
    (Copeland and Taylor 1994).                                        exists among the various nations included in the analysis.
  • Stochastic Impacts by Regression on Population, Affluence,       • 𝛿 t symbolizes the fixed effects that are time-­specific, em-
    and Technology (STIRPAT): This model examines how                  bodied by dummy variables for each year. These capture the
    population, technology, and affluence impact the environ-          universal shocks that impact the dependent variable across
    ment (Rosa and Dietz 1998; York et al. 2003).                      all nations under study.

By including FDI, economic growth, technology, and population        • 𝛾 k represents industry fixed effects.
as variables, our model allows us to analyze how FDI affects the     • The key parameter of interest is the sectoral coefficient of
environment, considering the predictions of the EKC, PHH, and          FDI [𝛼 2], which measures how the relationship between
STIRPAT hypotheses.
                                                                     • All variables are expressed in their natural logarithmic
The STIRPAT model, derived from the IPAT model proposed by             form.
Rosa and Dietz (1994), is formulated as follows:

                                 b                                  3.2   |   Methodology
                                     A𝛾 Ti,t                  (1)
                                         𝜔
                       Ii,t = 𝛼 Pi,t         𝜀i,t

                                                                    For the estimation of Equation (3), we have chosen the
In this model:                                                      system-­GMM method, offered by Blundell and Bond (1998)
                                                                    and Roodman (2009). Several factors underlie our selection.
  • i and t denote country and period, respectively.                To begin, this method aligns well with our analytical context
  • Ii,t represents the environmental impact.                       where the total of countries under investigation exceeds the


Natural Resources Forum, 2026                                                                                                                 1305
                                                                                                                                             14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
study's period (N > T), as recommended by Roodman (2009).4           emissions are a common proxy in EKC and PHH studies (Blanco
Second, this methodology aligns with adaptive specifications         et al. 2013; Anser et al. 2020; Caetano et al. 2022). The sectoral-­
that are vital for addressing incorrect assumptions in growth        level CO2 emissions data are classified into three sectors: pri-
models of this type by incorporating the preliminary phase           mary (agriculture emissions and other emissions), secondary
of development (Baltagi 2008). In our analysis, we account           (electricity and heat production emissions, manufacturing in-
for this by factoring in the first-­time lag of CO2 to represent     dustries emissions, and construction emissions), and tertiary
the initial level of pollution. However, this introduces possi-      (transport emissions, residential buildings emissions, and com-
ble reverse causation biases (Baum et al. 2003; Roberts and          mercial and public services emissions). The sources for these
Whited 2013). This concern stems from the fact that Et−1 relies      data were obtained from Hannah et al. (2020) and WDI (2023).
on 𝜀i,t , which is influenced by the country-­specific effect 𝜇i.
Roodman (2009) clarifies that this endogeneity emerges in the
first difference, as the GMM method removes country-­specific        3.3.2   |   Key Independent Variables
effects and thereby creates a link between lagged environmen-
tal levels and error terms.                                          In our study, we aim to advance the existing research on FDI by
                                                                     examining FDI inflows in a more detailed manner, specifically by
To address the econometric challenges mentioned earlier, a           breaking them down into different sectors. The rationale underly-
recommended approach by Arellano and Bond (1991) and                 ing this approach posits that FDI in heavily polluting sectors has
Wooldridge (2012) is to instrument the delayed result variable       the potential to exacerbate carbon emissions within a given region.
and other endogenous covariates with their own historical            Consequently, we seek to identify which types of investments have
values. This involves evaluating Equation (3) using the first-­      a greater adverse impact on the environment by categorizing FDI
difference GMM estimator. However, it is important to note           into three main sectors: resource extraction, manufacturing, and
that this method is not without its limitations. Specifically, as    services. This sectoral breakdown is a significant contribution to
highlighted by Ahn and Schmidt (1995), the first difference          the literature, particularly in the context of MENA, as most previ-
does not completely represent the potential data contained in        ous studies have primarily relied on aggregated measures of FDI.
the level connections and the connections between the levels
and their initial differences. This constraint is critical on the
                                                                     3.3.3   |   Other Independent Variables
grounds that, with solid endogeneity, the level factors prob-
ably would not function as solid instruments for their initial
                                                                       • Economic growth (GDP), quantified here as real GDP per
differences.5 Furthermore, in line with Roodman's (2009) rec-
                                                                         capita, serves as a fundamental measure for assessing the
ommendations, we combine the instruments to address the
                                                                         level of economic development within a given geographi-
spurious relationship between endogenous variables and model
                                                                         cal entity (Grossman and Krueger 1991; Bergougui 2025b).
outputs. Limiting the number of instruments in this approach
                                                                         The relationship between environmental degradation and
helps to prevent overfitting. Recent empirical studies, as ev-
                                                                         GDP is often described as an inverted U-­shape, meaning
idenced by research conducted by scholars such as Bergougui
                                                                         that pollution levels tend to increase as countries develop,
and Murshed (2020, 2021, 2023a, 2023b), Murshed et al. (2022),
                                                                         but then peak and start to decline as they become wealth-
and Ofori et al. (2022, 2023), have leveraged the Blundell and
                                                                         ier (Stern 2004). To accommodate for the EKC hypothesis
Bond (1998) and Roodman (2009) system GMM estimator to in-
                                                                         in the model, we incorporated a quadratic term, denoted as
form evidence-­founded conclusions.
                                                                         GDP2 (Grossman and Krueger 1991). The presence of the
                                                                         GDP2 term serves as a mathematical representation of the
                                                                         EKC's curvature (Opoku et al. 2021).
3.3   |   Data
                                                                       • Population (POP) is measured by population growth.
To assess the FDI-­pollution nexus, we tested 13 MENA coun-              Scholars such as Ehrlich and Holdren (1971) and Rosa and
tries from 1990 to 2022. Given the primary focus of this research,       Dietz (1994) have theorized that changes in population size
which is to investigate the effect of aggregate and disaggregate         exert a discernible impact on environmental dynamics.
FDI flows on environmental sustainability, our primary inde-             Notably, empirical evidence has indicated that countries
pendent variables comprised total FDI, as well as FDI segre-             characterized by larger population sizes tend to exhibit
gated into the Resource extraction, manufacturing, and services          higher levels of pollution (Martínez-­Zarzoso et al. 2007).
sectors. These FDI variables were examined with four individ-
                                                                       • Technological innovation (TECH) is measured in terms
ual environmental measures, serving as the primary dependent
                                                                         of patent applications, total (residents and non-­residents)
variables of interest. Detailed descriptions and the sources of
                                                                         (Sinha et al. 2020; Bergougui and Aldawsari 2024;
all variables employed in our analysis can be found in Table 1,
                                                                         Bergougui 2024; Doğan, Khalfaoui, et al. 2025; Doğan,
while Table 2 provides a comprehensive overview of their sum-
                                                                         Tiwari, et al. 2025).
mary statistics.
                                                                       • Institutional Quality: Recognizing the critical role that in-
                                                                         stitutional frameworks and legislation play in aligning eco-
3.3.1   |   Dependent Variables                                          nomic activity with environmental standards (Coe et al. 2009;
                                                                         Bournakis et al. 2018; Bergougui 2025c), we include an insti-
We primarily measure environmental impact using total carbon             tutional quality variable in our dataset. This variable captures
dioxide (CO2) emissions, quantified in kilotons. These emis-             differences in institutional development and environmental
sions include those released from fossil fuel combustion. CO2            legislation across MENA countries. Specifically, we use the

1306                                                                                                         Natural Resources Forum, 2026
                                                                                                                                                 14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 1    |    Variable descriptions.

 Variables                                                         Definition                                         Sources
 Dependent variables
   Total CO2 emissions                           Carbon dioxide emissions are those stemming                        WDI (2023)
                                                     from the burning of fossil fuels and the
                                                  manufacture of cement. They include carbon
                                                 dioxide produced during consumption of solid,
                                                       liquid, and gas fuels and gas flaring.
   Primary CO2 emissions                      CO2 emissions from the agriculture sector consist of
                                             activities in agriculture, hunting, forestry, and fishing.
   Secondary CO2 emissions                       CO2 emissions from manufacturing industries
                                                 and construction contain the emissions from
                                                      the combustion of fuels in industry.
   Tertiary CO2 emissions                         CO2 emissions from residential buildings and
                                                   commercial and public services contain all
                                                 emissions from fuel combustion in households.
 Independent variables
   Total FDI                                  The logarithm of total FDI flows in millions of USD.             Wright and Zhu (18) and
                                                                                                          International Trade Center (2023)
   Resources extraction FDI                    Resources extraction FDI flows as % total of FDI.
   Manufacturing FDI                              Manufacturing FDI flows as % total of FDI.
   Services FDI                                       Services FDI flows as % total of FDI.
 Control variables
   Real GDP per capita                               This variable denotes the logarithm of                         WDI (2023)
                                                    the gross domestic product per person of
                                                       each country (constant 2010 US$).
   Real GDP per capita square                 This represents the square of gross domestic product
                                                per person of each country (constant 2010 US$).
   Technological innovation                  Patent applications, total (residents and non-­residents).
   Population growth                                           Population growth.
   Institutional quality index                 Constructed index based on six indicators: Rule of
                                               law, government effectiveness, regulatory quality,
                                                 control of corruption, voice and accountability,
                                                 and political stability and absence of violence.
Note: WDI is World Development Indicators.



     institutional quality index from the World Bank's Worldwide               and Bergougui and Murshed (2023c). Following the imputation
     Governance Indicators. Incorporating this variable helps ac-              of this missing data, we successfully created a balanced panel
     count for the possibility that MNEs may place less emphasis               comprising 130 observations from 13 countries in the MENA re-
     on CO2 emissions in countries where institutional frame-                  gion, spanning the years 1990–2022.
     works are less developed.

                                                                               4   |   Empirical Results
3.4   |   Multiple Imputation
                                                                               The scrutiny of total FDI-­environment effects can be mis-
Upon the completion of our database construction for all vari-                 leading due to the differences among FDI sectors, as much of
ables under study, we noticed a considerable number of miss-                   FDI's effect is observed primarily in specific sectors (Blanco
ing observations in the independent variables for the years                    et al. 2013). Consequently, prior studies examining the spill-
1990–2022 across most countries. Excluding these values could                  over impacts of total FDI have produced inconclusive findings,
have resulted in the loss of valuable information for our study                with reports of “mixed evidence” and “no consistent relation-
model. Therefore, we tackled this issue of missing data in the                 ships” (Solarin and Sahu 2023). To mitigate these concerns, we
time series by employing multiple imputations (MI) to estimate                 delve into the impact of sector-­specific FDI, specifically FDI
these missing values, as suggested by Wright and Zhu (2018)                    within the resources extraction, manufacturing, and services

Natural Resources Forum, 2026                                                                                                            1307
                                                                                                                                                  14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 2    |    Summary statistics.

 Variable                                        N               Mean                     Std. dev.              Min                Max
 Dependent variables
   Total CO2 emissions                          117                  11.19                  1.166                9.013              13.35
   Primary sector CO2 emissions                 117                  2.891                  2.943                  0                17.14
   Secondary sector CO2 emissions               117                  65.58                  11.49                30.31             90.83
   Tertiary sector CO2 emissions                117                  31.53                  10.36                9.172              69.69
 Independent variables
   Total FDI                                    117                  22.05                  1.402                17.64              25.42
   Resources extraction FDI                     117                  35.47                  24.28                0.755              101.3
   Manufacturing FDI                            117                  25.21                  15.74               −0.659             78.97
   Services FDI                                 117                  39.31                  22.64               −8.378              87.21
 Control variables
   Real GDP per capita                          117                  25.37                  1.171                23.27              27.80
   Real GDP per capita square                   117                  78.06                  22.28                43.99             125.0
   Technological innovation                     117                  6.280                  1.454                2.276              9.621
   Population growth                            117                  16.62                  1.298                13.05              18.53
   Institutional quality                        117              −0.387                     0.625               −2.019             0.650



sectors, on environmental sustainability. We present the em-            Column 1 of Table 3, the system GMM estimates indicate that
pirical outcomes in Tables 3–6. Our analysis of the environ-            a 1% increase in total FDI inflows is associated with a 1.054%
mental effects of FDI considers three levels of disaggregation:         rise in CO2 emissions originating from the secondary sector.
(1) resources extraction FDI, (2) manufacturing FDI, and (3)            Our analysis also indicates that FDI hurts total CO2 emissions
service FDI, examining both within-­      sector and between-­          and tertiary sector CO2 emissions (Columns 1 and 4 of Table 3).
sector impacts alongside total FDI. Our evaluation of FDI's             A first-­in-­kind study provides evidence that total FDI in the
impact on environmental sustainability unfolds in two stages.           MENA region decreases both the total amount of CO2 emissions
First, we examine its impact on aggregate CO2 emissions                 as well as the level of CO2 emissions within the tertiary sector.
(Table 3). Then, we delve deeper into sector-­specific effects,
considering emissions from primary, secondary, and tertiary
sectors (Tables 4–6). This two-­pronged approach allows us to           4.2   |   FDI and Environment: Disaggregate Analysis
assess the overall contribution of FDI to CO2 emissions and its
nuanced impact across different economic sectors.                       The findings regarding the impact of total FDI indicate that it
                                                                        significantly affects the reduction of CO2 emissions, particu-
                                                                        larly in the case of tertiary sector emissions within the MENA
4.1   |   FDI and Environment: Aggregate Analysis                       region. However, relying solely on aggregated FDI data might
                                                                        mask important variations in the impact of FDI across dif-
This analysis begins with an investigation into the impact of           ferent economic sectors. However, relying solely on total FDI
aggregate FDI on environmental sustainability in the MENA               data might paint an incomplete picture, as the impact can vary
region. The study's findings show that total FDI has different          significantly across different economic sectors. To address
effects on aggregate and sector-­specific CO2 emissions (Table 3).      this, we conducted a sectoral analysis, evaluating how each
At the start, we observe that FDI has an insignificant impact           specific type of FDI (resources extraction, manufacturing,
on CO2 emissions from the primary sector (Column 2, Table 3).           and services) affects CO2 emissions. This analysis yielded two
This suggests that FDI insignificantly contributes to carbon            key findings:
emissions in this sector. This is because a large amount of FDI
movements in the MENA region are directed toward services,                   • First, the effect of FDI on CO2 emissions exhibits variability
manufacturing, or construction sectors. The primary sector is                  across sectors in the region, underscoring the importance of
less attractive to foreign investors than other sectors since it               a sectoral approach when analyzing the FDI-­environment
includes activities like agriculture and forestry, which are less              relationship.
beneficial. As a result, FDI has had a limited impact on pri-
mary sector emissions. Second, overall FDI inflows have a pos-               • Second, the positive environmental impact of total FDI on
itive impact on secondary sector CO2 emissions. As shown in                    the MENA region is primarily driven by FDI activities in



1308                                                                                                              Natural Resources Forum, 2026
                                                                                                                                                                               14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 3    |    The impact of total FDI on sector-­specific CO2 emissions.

                                                            Total CO2              Primary sector                 Secondary sector                 Tertiary sector
                                                            emissions              CO2 emissions                   CO2 emissions                   CO2 emissions
  Dependent variables                                            (1)                        (2)                             (3)                             (4)
  Total CO2 emissions (t − 1)                                  0.376*
                                                               (0.194)
  Primary sector CO2 emissions (t − 1)                                                    0.730
                                                                                          (1.439)
  Secondary sector CO2 emissions (t − 1)                                                                                 0.343***
                                                                                                                          (0.109)
  Tertiary sector CO2 emissions (t − 1)                                                                                                                 0.702***
                                                                                                                                                         (0.113)
  Total FDI                                                 −0.048***                     0.267                          2.146***                       −1.046*
                                                               (0.011)                    (1.474)                         (0.809)                        (0.622)
  Real GDP per capita                                         0.564**                     0.612                            0.540                          2.412
                                                              (0.224)                     (0.913)                         (3.800)                        (1.976)
  Real GDP per capita square                                  −0.003                     −0.010                           −0.227                         0.261**
                                                              (0.006)                    (0.065)                          (0.167)                        (0.118)
  Technological innovation                                     0.040                     −0.470                           −1.093                         −0.057
                                                               (0.025)                   (0.577)                          (0.805)                        (1.165)
  Population growth                                          0.040***                     0.009                           −0.261                         −0.943
                                                               (0.012)                   (0.093)                          (0.512)                        (0.624)
  Institutional quality                                       −0.070                     −0.101                           9.845**                      −9.418***
                                                               (0.146)                   (1.092)                          (4.495)                        (3.591)
  Constant                                                    −6.335*                    −17.278                          11.226                        −50.187
                                                               (3.443)                   (44.032)                        (91.926)                        (39.729)
  Observations                                                   104                        104                             104                            104
  No. of countries                                               13                         13                               13                             13
  Hansen J: p-­value                                            0.416                     0.828                            0.978                             1
  AR(2): p-­value                                               0.498                     0.690                            0.419                          0.787
Note: Standard errors are enclosed within brackets. Significance levels are indicated as follows: *p < 0.10, **p < 0.05, ***p < 0.01. All regression analyses were conducted
utilizing the system-­GMM methodology. It is noteworthy that the Hansen overidentification test yielded p-­values exceeding 0.05 for all specifications, implying the
validity of the instruments employed. Color shades indicated the results of the main independent variables.



     the services sector, while FDI in resources extraction and                          obtained in model 1. In contrast to the findings for total FDI, as
     manufacturing sectors exhibits a negative effect.                                   outlined in Table 3, it is noteworthy that resource extraction FDI
                                                                                         exhibits a positive impact on CO2 emissions in all specifications.
This highlights the need for policymakers to focus on attracting                         This observation is evident in Column 3 of Table 3, suggesting
FDI in the services sector as a pivotal strategy for fostering envi-                     that resource extraction FDI is inclined to hurt environmental
ronmental sustainability in the region.                                                  sustainability, both at the aggregate level (total CO2 emissions)
                                                                                         and the disaggregate level (primary, secondary, and tertiary
                                                                                         sector CO2 emissions). Our findings are consistent with the re-
4.2.1   |   Effect of Resources Extraction FDI on                                        search findings of Caetano et al. (2022) in the context of OECD
Sector-­Specific CO2 Emissions                                                           countries and Solarin and Sahu (2023) in the case of BRICS na-
                                                                                         tions, all of whom contend that resource extraction FDI exerts a
The findings from the system GMM regression analysis dis-                                deleterious influence on environmental quality, particularly in
played in Table 4 are consistent with the parameter estimates                            the context of the host country's oil sector.


Natural Resources Forum, 2026                                                                                                                                         1309
                                                                                                                                                             14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 4    |    The impact of resources extraction FDI on sector-­specific CO2 emissions.

                                                           Total CO2             Primary sector           Secondary sector         Tertiary sector
                                                           emissions             CO2 emissions             CO2 emissions           CO2 emissions
  Dependent variables                                           (1)                         (2)                   (3)                      (4)
  Total CO2 emissions (t − 1)                               0.618***
                                                             (0.224)
  Primary sector CO2 emissions (t − 1)                                                 0.624***
                                                                                           (0.076)
  Secondary sector CO2 emissions (t − 1)                                                                         0.168
                                                                                                                (0.141)
  Tertiary sector CO2 emissions (t − 1)                                                                                                  0.384**
                                                                                                                                         (0.196)
  Resources extraction FDI                                   0.002**                       0.038*               0.037*                   0.038**
                                                             (0.001)                       (0.021)              (0.022)                  (0.019)
  Real GDP per capita                                         0.390                        −1.097               −0.182                    2.046
                                                             (0.305)                       (2.759)              (2.351)                  (1.727)
  Real GDP per capita square                                 −0.009                        0.160                 0.198                   −0.081
                                                             (0.024)                       (0.135)              (0.281)                  (0.170)
  Technological innovation                                   −0.004                        −0.135               −0.526                   −0.127
                                                             (0.049)                       (0.559)              (0.726)                  (1.370)
  Population growth                                         0.040***                       0.105                 0.253                    0.011
                                                             (0.011)                       (0.229)              (0.169)                  (0.159)
  Institutional quality                                       0.220                        −1.779                5.713                   −5.718
                                                             (0.427)                       (2.312)              (3.756)                  (3.678)
  Constant                                                   −4.914                        14.423               48.229                  −28.126
                                                             (4.316)                   (62.586)                 (49.395)                (36.156)
  Observations                                                 104                          104                   104                      104
  No. of countries                                              13                           13                   13                        13
  Hansen J: p-­value                                          0.967                        0.932                   1                        1
  AR(2): p-­value                                             0.710                        0.156                 0.671                    0.227
Note: See Table 3. Color shades indicated the results of the main independent variables.



4.2.2   |   Effect of Manufacturing FDI on Sector-­Specific                            there is a positive spillover consequence on CO2 emissions, im-
CO2 Emissions                                                                          pacting both the primary and tertiary industries in the MENA
                                                                                       economic system. These results endorse the perspective that FDI
Table 5 presents a summary of our findings regarding the impact                        contributes to intensified carbon dioxide discharges, with these
of manufacturing FDI on CO2 emissions. Matching with the pat-                          influences primarily arising from investments in manufacturing
terns observed in the resources extraction FDI sector, manufac-                        and resource extraction across the region. This aligns with pre-
turing FDI has a positive and significant association with total                       ceding academic studies that have determined a comparable by-
CO2 emissions (Column 1). Moreover, manufacturing FDI also                             product on carbon dioxide outputs, which lends credence to the
contributes to CO2 emissions in the manufacturing sector itself,                       pollution haven hypothesis (Xing and Kolstad 2002; Doytch and
as well as in the primary and tertiary sectors through positive                        Uctum 2016; Hille et al. 2019; Marques and Caetano 2020; Yu
spillover effects (Columns 2, 3, and 4). This is because manufac-                      and Wang 2021; De Vita et al. 2021). Nonetheless, our findings
turing FDI creates a web of interactions within an economy. It                         contradict the conclusions drawn by Caetano et al. (2022) and
leads to increased transportation in the tertiary sector, primarily                    Solarin and Sahu (2023), which suggest that an increase in FDI
relying on fossil fuels, and drives up demand for primary sec-                         in the manufacturing sectors leads to a reduction in CO2 emis-
tor resources that entail energy-­intensive activities. As a result,                   sions, thus exerting a beneficial impact on the environment. The

1310                                                                                                                         Natural Resources Forum, 2026
                                                                                                                                                           14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 5    |    The impact of manufacturing FDI on sector-­specific CO2 emissions.

                                                           Total CO2             Primary sector             Secondary sector        Tertiary sector
                                                           emissions             CO2 emissions               CO2 emissions          CO2 emissions
  Dependent variables                                           (1)                         (2)                    (3)                     (4)
  Total CO2 emissions (t − 1)                                0.409**
                                                             (0.167)
  Primary sector CO2 emissions (t − 1)                                                     −0.079
                                                                                           (0.328)
  Secondary sector CO2 emissions (t − 1)                                                                         0.272
                                                                                                                 (0.346)
  Tertiary sector CO2 emissions (t − 1)                                                                                                  0.754**
                                                                                                                                         (0.339)
  Manufacturing FDI                                          0.002**                   0.097***                  0.086*                  0.056*
                                                             (0.001)                       (0.033)               (0.049)                 (0.031)
  Real GDP per capita                                        0.501**                       0.484                 0.047                    1.637
                                                             (0.210)                       (0.774)               (3.684)                 (2.084)
  Real GDP per capita square                                 −0.005                        −0.053                −0.223                  −0.133
                                                             (0.003)                       (0.039)               (0.458)                 (0.261)
  Technological innovation                                    0.026                    2.048**                   0.012                    0.528
                                                             (0.052)                       (0.813)               (1.142)                 (0.849)
  Population                                                 0.014**                   0.329***                  −0.161                  −0.065
                                                             (0.007)                       (0.118)               (0.319)                 (0.068)
  Institutional quality                                      −0.034                        2.034                 7.905                   −0.545
                                                             (0.172)                       (1.257)               (7.419)                 (6.577)
  Constant                                                   −5.961*                   −17.110                   53.908                 −27.852
                                                             (3.512)                   (14.822)                 (60.376)                (42.596)
  Observations                                                 104                          104                   104                     104
  No. of countries                                              13                           13                    13                      13
  Hansen J: p-­value                                             1                           1                     1                      0.993
  AR(2): p-­value                                            0.0948                        0.0610                0.786                    0.408
Note: See Table 3. Color shades indicated the results of the main independent variables.



disparity in our findings may be attributed to variations in the                       services has a positive impact on environmental quality, both
countries included in the study and the specific periods under                         in the sector where it is invested and in other sectors of the
scrutiny.                                                                              economy.


4.2.3   |   Effect of Services FDI on Sector-­Specific                                 5   |   Discussion
CO2 Emissions
                                                                                       This section analyzes the empirical results through the lens of
Table 6 summarizes the main findings on FDI in the service                             the pollution haven-­halo debate, examining how various FDI
sector. Unlike FDI in resource extraction and manufacturing,                           sectors (total, services, resource extraction, and manufacturing)
FDI in services is negatively and significantly associated with                        shape environmental outcomes. The analysis is particularly rel-
total CO2 emissions (Column 1). Additionally, FDI in services                          evant given the MENA region's economic development trajec-
also helps to reduce CO2 emissions in the service sector itself,                       tory, natural resource wealth, and susceptibility to exploitative
as well as in the primary and tertiary sectors through negative                        foreign investment practices. The key results are summarized
spillover effects (Columns 2, 3, and 4). This means that FDI in                        in Figure 3.

Natural Resources Forum, 2026                                                                                                                      1311
                                                                                                                                                             14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 6    |    The impact of services FDI on sector-­specific CO2 emissions.

                                                           Total CO2             Primary sector           Secondary sector         Tertiary sector
                                                           emissions             CO2 emissions             CO2 emissions           CO2 emissions
  Dependent variables                                           (1)                          (2)                  (3)                      (4)
  Total CO2 emissions (t − 1)                                 0.447
                                                             (0.341)
  Primary sector CO2 emissions (t − 1)                                                 0.574***
                                                                                           (0.105)
  Secondary sector CO2 emissions (t − 1)                                                                         0.443
                                                                                                                (0.292)
  Tertiary sector CO2 emissions (t − 1)                                                                                                   0.235
                                                                                                                                         (0.203)
  Services FDI                                              −0.007**                   −0.008*                  −0.066                  −0.066**
                                                             (0.003)                       (0.004)              (0.044)                  (0.026)
  Real GDP per capita                                         0.603                        0.424                 0.284                    0.591
                                                             (0.373)                       (0.370)              (1.586)                  (1.884)
  Real GDP per capita square                                  0.002                        0.008                 0.078                    0.012
                                                             (0.006)                       (0.025)              (0.260)                  (0.132)
  Technological innovation                                    0.026                        −0.057               −0.705                    0.395
                                                             (0.029)                       (0.190)              (0.744)                  (0.353)
  Population                                                0.041***                       0.046                 0.258                   −0.074
                                                             (0.011)                       (0.062)              (0.251)                  (0.082)
  Institutional quality                                      −0.112                        −0.646               −2.242                   −3.964
                                                             (0.172)                       (0.495)              (4.095)                  (2.964)
  Constant                                                   −9.232                        −9.879               27.698                    6.827
                                                             (6.030)                       (9.544)              (67.630)                 (37.591)
  Observations                                                 104                          104                   104                      104
  No. of countries                                              13                           13                   13                        13
  Hansen J: p-­value                                          0.996                          1                     1                      0.996
  AR(2): p-­value                                             0.348                        0.290                 0.999                    0.215
Note: See Table 3. Color shades indicated the results of the main independent variables.




First, the results regarding total FDI and service sector FDI on                       regulations due to economic constraints (Dechezleprêtre and
CO2 emissions generally support the pollution halo hypothe-                            Sato 2017). However, with recent economic improvements,
sis, aligning with Kahia et al. (2017) and Shahbaz et al. (2019).                      environmental concerns may be gaining traction, potentially
However, this contradicts Gorus and Aslan (2019) and Opoku                             influencing FDI-­related environmental outcomes. This shift
and Boachie (2020). A potential explanation for this discrep-                          could incentivize cleaner technologies and practices, support-
ancy might be the lack of sector-­specific CO2 emission analysis                       ing the pollution halo effect.
in the latter studies. Our findings suggest a contingent relation-
ship between FDI and CO2 emissions, dependent on the emit-                             Second, the negative contribution of resource extraction FDI
ting sector. The observed positive association between service                         to environmental quality has several potential explanations,
sector FDI and reduced CO2 emissions could be attributed to                            highlighting the potential for the pollution haven effect in
(i) the recent influx of MNCs in the MENA region might be                              the MENA region: (i) One of the main reasons is that FDI in
equipped with environmentally friendly technologies, as ev-                            the resource extraction industry can lead to physical environ-
idenced by Mahmood et al. (2023). (ii) Developing countries                            mental impacts, such as deforestation, loss of biodiversity, and
in the region may have historically relaxed environmental                              greenhouse gas emissions (Mcnally 1999). (ii) The influx of

1312                                                                                                                         Natural Resources Forum, 2026
                                                                                                                                          14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 3    |    Summary of results.



FDI into the resource extraction sector may have detrimen-           production of emission-­intensive goods to countries with stricter
tal environmental consequences, particularly in the MENA             environmental regulations (Egesa et al. 2022). This could create
region. The region's wealth of natural resources could poten-        a pollution haven effect in the MENA region.
tially attract foreign investors looking to take advantage of
less stringent environmental regulations, potentially resulting      Fourth, the negative spillover effect of service sector FDI on
in the formation of pollution havens. This perspective aligns        CO2 emissions in primary and secondary sectors can be ex-
with observations made by several researchers, including             plained by three factors, potentially mitigating the pollution
Borregaard and Dufey (2002) and Tienhaara (2006). (iii) The          haven effect in these sectors: (i) Foreign investors possess
industry's environmental performance depends on the com-             access to more advanced technologies and expertise when
pany's commitment and the strength of environmental reg-             compared to domestic companies. This technological advan-
ulations (Mcnally 1999; Tienhaara 2006). MENA's economic             tage can translate into emissions reduction within the re-
growth might allow for stricter regulations in the future, mit-      source extraction and manufacturing sectors by enhancing
igating this pollution haven effect. In summary, the insights        resource efficiency and diminishing energy consumption
gleaned from Table 4 lead to the conclusion that resource ex-        through the utilization of cleaner technologies (OECD 2002).
traction FDI in the region tends to harm environmental qual-         (ii) Investments in the service sector often entail stricter
ity within the sector itself. Furthermore, these investments         environmental standards and regulations. When resource
fail to generate any meaningful reduction in CO2 emissions           extraction and manufacturing companies seek foreign in-
across the primary, secondary, and tertiary sectors. In fact,        vestments, they may find themselves compelled to conform
they contribute to an increase in CO2 emissions, leading to          to these heightened environmental standards. Consequently,
further environmental degradation.                                   this compliance results in emissions reduction as these com-
                                                                     panies embrace cleaner technologies and sustainable practices
Third, as expected, manufacturing FDI often increases CO2            (Andersen and Noailly 2022). (iii) FDI in the service sector
emissions within the manufacturing sector itself. This is be-        can foster economic diversification in the MENA region. A
cause manufacturing FDI typically triggers an upswing in             diversified economy is less reliant on heavy manufacturing,
production and economic activity, consequently intensifying          which is typically associated with elevated emissions. By
energy consumption and, by extension, CO2 emissions (Egesa           channeling investments into services, the region can decrease
et al. 2022). Moreover, the MENA region boasts abundant nat-         its reliance on high-­emission industries, thus indirectly lower-
ural resources and a significant mineral sector within its econ-     ing CO2 emissions in the primary and secondary sectors (IMF
omies. This influx of economic activity in the manufacturing         and Manama 2016; Wang and Guo 2022). Our results provide
sector, spurred by FDI, naturally results in heightened energy       empirical support for the idea that FDI contributes positively
consumption and, correspondingly, increased CO2 emissions            to the reduction of CO2 emissions, primarily when directed to-
(Mahmood et al. 2023). Additionally, in regions with less-­skilled   wards the service industry in the MENA region. This is in line
labor, manufacturing FDI may act as a conduit for offshoring         with previous research, which has found similar effects on


Natural Resources Forum, 2026                                                                                                     1313
                                                                                                                                               14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
CO2 emissions, corroborating what is known as the Pollution            6.2   |   Policy Implication
Halo Hypothesis (Doytch and Uctum 2016). Investments in
services appear better positioned to cut CO2 emissions com-            The empirical findings of this study highlight several key pol-
pared to other sectors like resource extraction or manufactur-         icy directions that can help MENA countries leverage FDI for
ing according to our analysis and the existing literature.             economic growth and environmental sustainability. Given the
                                                                       region's economic structure and environmental challenges,
Briefly, our analysis shows that total FDI inflows do matter           policymakers must adopt targeted strategies to ensure that FDI
for the reduction of CO2 emissions in the MENA region, ex-             flows align with sustainability goals.
cept for emissions from the secondary industrial sector. When
considering the sectoral distribution of FDI, our results illus-       One of the primary policy implications relates to the prioriti-
trate a complex interplay between foreign investment and en-           zation of service-­sector investments as a means of promoting
vironmental outcomes. The nuances emphasize the need for               sustainable economic growth. The results indicate that FDI in
industry-­level examinations. MENA countries that have higher          services, particularly in sectors such as information technology
levels of FDI in the services industry tend to experience positive     and finance, not only reduces CO2 emissions within the sector
environmental gains, while countries with greater FDI in the           itself but also facilitates cleaner practices in resource-­intensive
resources extraction and manufacturing sectors seem to incur           industries through knowledge spillover effects. Unlike tradi-
negative environmental impacts. With a granular comprehen-             tional extractive and manufacturing industries, service-­oriented
sion of industry-­level effects, policymakers could target strategic   FDI is generally less carbon-­intensive and fosters digital trans-
FDI promotion to optimize both development and sustainabil-            formation and efficiency improvements across the economy.
ity goals.                                                             Therefore, policymakers should design specific incentives to
                                                                       attract investments in services, including tax benefits, stream-
                                                                       lined regulatory approvals, and targeted subsidies for green and
6   |   Conclusion and Policy Implications                             digital initiatives.

6.1   |   Conclusion                                                   At the same time, the study underscores the need for stricter
                                                                       environmental regulations in the resource extraction and
This study provides a novel examination of the different envi-         manufacturing sectors, where FDI has been linked to in-
ronmental impacts stemming from foreign direct investment              creased CO2 emissions. These industries, which play a signifi-
(FDI) that targets specific economic sectors in the Middle East        cant role in the economic structure of many MENA countries,
and North Africa (MENA) region from 1990 to 2022. By break-            pose notable environmental risks due to their reliance on
ing down total FDI into resource extraction, manufacturing,            fossil fuels and resource-­intensive production processes. To
and services, the analysis determined how overall and sector-­         mitigate these risks, governments should implement com-
specific carbon dioxide emissions are affected depending on            prehensive regulatory measures, including stricter emissions
which industry receives the investment. It also evaluated the          standards, mandatory adoption of cleaner technologies, and
“pollution haven” and “pollution halo” hypotheses at total and         rigorous environmental impact assessments for new projects.
sectoral levels, considering the type of FDI inflow to understand      Strengthening monitoring and enforcement mechanisms will
how these hypotheses play out within resource extraction, man-         also be crucial to ensuring compliance with environmental
ufacturing, and services FDI.                                          policies.

Our main findings indicate that diverse types of FDI compo-            Another critical policy recommendation involves fostering
nents can have varying effects on sectoral CO2 emissions. At the       innovation and facilitating knowledge transfer between for-
aggregate level, FDI enhances environmental quality in MENA            eign and domestic firms. The findings suggest that technolog-
economies, evidenced by reductions in total CO2 emissions and          ical advancements introduced by multinational enterprises
emissions from the tertiary sector. However, a more granular           can play a transformative role in reducing overall emissions.
analysis at the sector level reveals that the positive environ-        However, to maximize these benefits, governments should
mental impact of total FDI mainly stemmed from services FDI            create an enabling environment that encourages technology-­
specifically. Services FDI seemed to support the “pollution halo       sharing initiatives, joint research and development programs,
hypothesis” by lowering emissions through transfers of technol-        and public-­private partnerships aimed at promoting green in-
ogy and regulatory practices, as well as structural shifts away        novations. Establishing technology incubators and providing
from more polluting industries. In contrast, resource extraction       incentives for collaborative research can help accelerate the dif-
and manufacturing FDI tended to worsen environmental qual-             fusion of environmentally friendly technologies throughout the
ity within individual sectors by increasing CO2 emissions. This        economy.
supported the “pollution haven hypothesis.” Resources ex-
traction FDI poses physical impacts and establishes pollution          Institutional quality is another determinant that policymak-
havens in regions with lax environmental standards, influenced         ers must address to ensure long-­term sustainability. The study
by company policies and home country regulations. Similarly,           highlights the link between strong institutions and lower emis-
manufacturing FDI in resource-­rich MENA economies tends               sions, suggesting that governance quality plays a crucial role
to increase CO2 emissions by intensifying production, util-            in shaping the environmental impact of FDI. Governments
ity usage, and emissions—often driven by outsourcing high-­            should focus on strengthening institutional frameworks by
emission goods from stricter jurisdictions to mitigate domestic        enhancing regulatory transparency, combating corruption,
effects.                                                               and ensuring the effective enforcement of environmental

1314                                                                                                           Natural Resources Forum, 2026
                                                                                                                                                    14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
laws. Strong institutions not only improve environmental                    technologies and practices. This would enable policymak-
outcomes but also create a stable and predictable investment                ers to design targeted strategies for attracting FDI with
climate that attracts responsible investors committed to sus-               the greatest potential to contribute to positive environ-
tainable business practices.                                                mental outcomes.
                                                                         • Disaggregated Services FDI Analysis: As highlighted above,
Finally, a targeted and flexible approach to FDI incentives is
                                                                           the disaggregation of services FDI data unlocks new re-
necessary to align investment inflows with environmental and
                                                                           search opportunities. A more granular analysis could ex-
economic objectives. A uniform incentive structure may not be ef-
                                                                           amine the environmental impact of FDI within different
fective in achieving sustainability goals, as different sectors have
                                                                           service sub-­sectors, such as information technology, fi-
varying environmental footprints and economic contributions.
                                                                           nance, and healthcare. This could reveal important varia-
Policymakers should design sector-­specific incentive programs
                                                                           tions in the data and inform the development of targeted
that promote clean technologies, energy efficiency, and circular
                                                                           policies for attracting environmentally sustainable FDI
economy initiatives. For instance, tax breaks and subsidies could
                                                                           within specific service industries.
be offered to investors adopting low-­carbon technologies, while
resource-­intensive industries could face stricter environmental         • Environmental Policy and FDI: The role of environmental
requirements. Moreover, continuous monitoring and evaluation               policies in moderating the local pollution levels associated
of FDI's environmental impact should be integrated into policy             with FDI warrants further investigation, particularly as en-
frameworks. Tracking sectoral CO2 emissions and assessing the              vironmental regulations continue to evolve. This research
effectiveness of policy measures will enable governments to refine         could inform the development of effective policies that
their strategies and ensure that FDI contributes to both economic          promote environmentally responsible foreign investment
development and environmental protection.                                  practices.
                                                                         • Expanding Environmental Indicators: While CO2 emissions
By implementing these targeted policies, MENA countries can
                                                                           are a crucial indicator, a more comprehensive picture of
transition toward a more sustainable development path, lever-
                                                                           FDI's environmental impact requires the consideration of
aging FDI not only as a driver of economic growth but also as a
                                                                           a broader range of environmental metrics. Future studies
tool for reducing environmental degradation.
                                                                           could analyze additional indicators such as water usage,
                                                                           waste generation, and biodiversity impact to provide a
                                                                           richer understanding of FDI's sustainability implications
6.3   |   Study Limitations and Future Research                            across various economic sectors.
Directions
                                                                       By addressing these limitations and pursuing the suggested
This research contributes to the understanding of the heteroge-        future research avenues, we can gain a more comprehensive
neous environmental impacts of Foreign Direct Investment (FDI)         understanding of the complex interplay between FDI and envi-
across sectors within the Middle East and North Africa (MENA)          ronmental sustainability. This deeper understanding can ulti-
region. However, it acknowledges several key limitations that pres-    mately inform the development of effective policies that promote
ent valuable opportunities for further investigation.                  both economic growth and environmental protection within the
                                                                       MENA region and beyond.

6.3.1   |   Limitations
                                                                       Conflicts of Interest
  • The current study adopts a regional focus, solely examining
    MENA countries. Expanding the analysis to encompass a              The authors declare no conflicts of interest.
    broader geographical scope would allow for a more nuanced
    understanding of the global dynamics between FDI and en-           Data Availability Statement
    vironmental outcomes.
                                                                       Data will be made available on request.
  • While this research differentiates environmental impacts
    across sectors, the services sector itself remains a broad cat-    Endnotes
    egory. The increasing availability of disaggregated services       1 The environmental effects of FDI in so-­called “green” services are not
    FDI data within the MENA region presents an exciting ave-           predetermined, as increased economic activity and scale of operations
    nue for future research.                                            accompanying FDI could potentially generate environmental costs
                                                                        that offset the intended.
                                                                       2 Equation   (3) exhibits a notable correlation among its independent
6.3.2   |   Future Research Directions                                  variables, specifically between FDI and GDP, which may result in
                                                                        multicollinearity problems. Nevertheless, it is worth noting that mul-
  • Firm-­L evel Analysis: Delving deeper into firm-­ specific          ticollinearity does not introduce bias to the estimated coefficients,
                                                                        paralleling the impact of a small sample size, which inflates sampling
    characteristics could offer valuable insights into the en-
                                                                        variances. To address multicollinearity, one effective approach is to in-
    vironmental behavior of FDI. Future research could in-              crease the sample size (Wooldridge 2012). Given the substantial sample
    vestigate how factors such as firm size, the home country           size in this study (n = 117), we can confidently assert that our concerns
    of the investor, and their investment motives influence             regarding multicollinearity are alleviated, thereby enhancing the re-
    the adoption and diffusion of environmentally friendly              liability of our findings. Moreover, prior research has highlighted


Natural Resources Forum, 2026                                                                                                              1315
                                                                                                                                                                            14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
 the potential endogeneity of FDI when assessing its environmental                     Arellano, M., and S. Bond. 1991. “Some Tests of Specification for
 impacts (Baek 2016). To address the issue of endogeneity, we employ                   Panel Data: Monte Carlo Evidence and an Application to Employment
 two tests, the Hansen test for instrument validity (over-­identification              Equations.” Review of Economic Studies 58: 277–297. https://​doi.​org/​10.​
 restrictions) and Arrelano-­Bond test for serial correlation.                         2307/​2297968.
3 The inclusion of lagged CO
                              2 emissions addresses persistence effects                Arellano, M., and O. Bover. 1995. “Another Look at the Instrumental
 in environmental degradation by recognizing temporal continuity of                    Variable Estimation of Error-­     Components Models.” Journal of
 emissions' impact, enabling dynamic analysis of relationships with                    Econometrics 68: 29–51. https://​doi.​org/​10.​1016/​0304-­​4 076(94)​01642​-­​D.
 variables like FDI or GDP, mitigating endogeneity concerns where
                                                                                       Assamoi, G. R., S. Wang, Y. Liu, T. B. Y. Gnangoin, D. F. Kassi, and A.
 emissions might be both cause and effect of explanatory variables, and
                                                                                       J.-­R . Edjoukou. 2020. “Dynamics Between Participation in Global Value
 providing crucial insights for effective environmental policy design.
                                                                                       Chains and Carbon Dioxide Emissions: Empirical Evidence for Selected
4 As Roodman (2009) has pointed out, GMM estimators are generally                      Asian Countries.” Environmental Science and Pollution Research 27:
 intended for panel data sets where the total of countries is superior                 16496–16506. https://​doi.​org/​10.​1007/​s1135​6 -­​020-­​08166​-­​9.
 to the total of timeframes (N > T). In our study, we have addressed
                                                                                       Baek, J. 2016. “A New Look at the FDI-­Income-­Energy-­Environment
 this by taking the average over four-­year interims in the 1990–2022
                                                                                       Nexus: Dynamic Panel Data Analysis of ASEAN.” Energy Policy 91:
 panel. For instance, if t1 represents the years 1990–1993, then t2 cor-
                                                                                       22–27. https://​doi.​org/​10.​1016/j.​enpol.​2 015.​12.​0 45.
 responds to 1994–1996, and so on. Now, considering the total of time-
 frames (t) in this analysis consists of ten 4-­year intervals, the use of             Balaguer, J., A. Cuadros, and J. García-­Quevedo. 2022. “Does Foreign
 the System GMM estimator is defendable since it fulfills the condition                Ownership Promote Environmental Protection? Evidence From Firm-­
 (N = 13 > T = 10) as suggested by Roodman.                                            Level Data.” Small Business Economics 60: 227–244. https://​doi.​org/​10.​
5 To conquer the constraints of the first-­difference estimator, Blundell              1007/​s1118​7-­​022-­​0 0646​-­​1.
 and Bond (1998) propose utilizing the system GMM estimator. This                      Baltagi, B. 2005. Econometric Analysis of Panel Data. Springer.
 methodology includes assessing both the level and first-­difference re-
                                                                                       Baltagi, B. H. 2008. “Forecasting With Panel Data.” Journal of
 lapses as a framework. To execute this strategy, we hold fast to Blundell
                                                                                       Forecasting 27: 153–173. https://​doi.​org/​10.​1002/​for.​1047.
 and Bond's (1998) approach, where the level condition incorporates
 delayed first-­differenced covariates, and the first-­difference condi-               Bashir, M. A., Z. Dengfeng, M. Radulescu, et al. 2023. “Sustainable FDI
 tion incorporates delayed level factors. Analysts have contended the                  and Comparative Advantage for Product Export Survival: A Developing
 system GMM estimation system yields gauges that are asymptotically                    Countries Perspective.” Ekonomska Istraživanja 36: 1–25. https://​doi.​
 reliable and more solid, described by lower predisposition and stan-                  org/​10.​1080/​13316​77X.​2 022.​2164035.
 dard mistakes, contrasted with the first-­difference GMM technique
                                                                                       Baum, C. F., M. E. Schaffer, and S. Stillman. 2003. “Instrumental
 (Windmeijer 2005).
                                                                                       Variables and GMM: Estimation and Testing.” Stata Journal 3: 1–31.
                                                                                       https://​doi.​org/​10.​1177/​15368​67X03​0 0300101.
References                                                                             Baumol, W. J., and W. E. Oates. 1988. The Theory of Environmental
                                                                                       Policy. 2nd ed. Cambridge University Press.
Abbas, S. J., A. Iqbal, M. M. Hussain, and A. Anwar. 2023. “The
Environmental Cost of FDI and Spatial Implications of CO2 Emissions                    Bergougui, B. 2024. “Algeria's Pathway to COP28 and SDGs: Asymmetric
in Sub-­Saharan Africa.” Environmental Science and Pollution Research                  Impact of Environmental Technology, Energy Productivity, and
30: 74441–74451. https://​doi.​org/​10.​1007/​s1135​6 -­​023-­​27727​-­​2 .            Material Resource Efficiency on Environmental Sustainability.” Energy
                                                                                       Strategy Reviews 55: 101541. https://​doi.​org/​10.​1016/j.​esr.​2 024.​101541.
Abdouli, M., and S. Hammami. 2017. “Investigating the Causality
Links Between Environmental Quality, Foreign Direct Investment and                     Bergougui, B. 2025a. “Circular Pathways to Sustainability: Asymmetric
Economic Growth in MENA Countries.” International Business Review                      Impacts of the Circular Economy on the EU'S Capacity Load Factor.”
26: 264–278. https://​doi.​org/​10.​1016/j.​ibusr​ev.​2 016.​07.​0 04.                 Land 14, no. 6: 1216. https://​doi.​org/​10.​3390/​land1​4 061216.
Adeel-­Farooq, R. M., M. F. Riaz, and T. Ali. 2021. “Improving the                     Bergougui, B. 2025b. “Industrial Robots for a Sustainable Future:
Environment Begins at Home: Revisiting the Links Between FDI and                       Uncovering the Asymmetric Effects of AI on Ecological Quality in G7
Environment.” Energy 215: 119150. https://​doi.​org/​10.​1016/j.​energy.​              Economies.” Technology in Society 83: 103021. https://​doi.​org/​10.​1016/j.​
2020.​119150.                                                                          techs​oc.​2 025.​103021.
Ahn, S. C., and P. Schmidt. 1995. “Efficient Estimation of Models for                  Bergougui, B. 2025c. “Institutional Adaptability, Skill-­                   Bias
Dynamic Panel Data.” Journal of Econometrics 68: 5–27. https://​doi.​org/​             Technological Shifts, and Energy Efficiency in Global Decarbonization
10.​1016/​0304-­​4 076(94)​01641​- ­​C.                                                Pathways: Exploring the Role of Artificial Intelligence Patents.”
                                                                                       Technology in Society 83: 103029. https://​doi.​org/​10.​1016/j.​techs​oc.​2 025.​
Ali, N., K. Phoungthong, A. Khan, et al. 2023. “Does FDI Foster
                                                                                       103029.
Technological Innovations? Empirical Evidence From BRICS
Economies.” PLoS One 18: e0282498.                                                     Bergougui, B., and M. I. Aldawsari. 2024. “Asymmetric Impact of
                                                                                       Patents on Green Technologies on Algeria's Ecological Future.” Journal
Andersen, M., and J. Noailly. 2022. “Environmental Regulations in the
                                                                                       of Environmental Management 355: 120426. https://​doi.​org/​10.​1016/j.​
Mining Sector and Their Effect on Technological Innovation.” In Global
                                                                                       jenvm​an.​2 024.​120426.
Challenges for Innovation in Mining Industries, 142–171. Cambridge
University Press.                                                                      Bergougui, B., and S. Meziane. 2025. “Assessing the Impact of Green
                                                                                       Energy Transition, Technological Innovation, and Natural Resources
Anser, M. K., Z. Yousaf, S. S. Hishan, et al. 2020. “Dynamic Linkages
                                                                                       on Load Capacity Factor in Algeria: Evidence From Dynamic
Between Transportation, Waste Management, and Carbon Pricing:
                                                                                       Autoregressive Distributed Lag Simulations and Machine Learning
Evidence From the Arab World.” Journal of Cleaner Production 269:
                                                                                       Validation.” Sustainability 17: 1815. https://​doi.​org/​10.​3390/​su170​51815​.
122151. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 020.​122151.
                                                                                       Bergougui, B., and S. M. Murshed. 2020. “New Evidence on the Oil-­
Apergis, N., M. Pinar, and E. Unlu. 2023. “How Do Foreign Direct
                                                                                       Democracy Nexus Utilising the Varieties of Democracy Data.” Resources
Investment Flows Affect Carbon Emissions in BRICS Countries?
                                                                                       Policy 69: 101905. https://​doi.​org/​10.​1016/j.​resou​r pol.​2 020.​101905.
Revisiting the Pollution Haven Hypothesis Using Bilateral FDI Flows
From OECD to BRICS Countries.” Environmental Science and Pollution                     Bergougui, B., and S. M. Murshed. 2021. “Revisiting the Oil Wealth-­
Research 30: 14680–14692. https://​doi.​org/​10.​1007/​s1135​6 -­​022-­​23185​- ­​4.   Growth Nexus: The Role of Economic Norms in Avoiding the Oil


1316                                                                                                                                    Natural Resources Forum, 2026
                                                                                                                                                                      14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Curse.” Extractive Industries and Society 8: 100929. https://​doi.​org/​10.​    Dechezleprêtre, A., and M. Sato. 2017. “The Impacts of Environmental
1016/j.​exis.​2 021.​100929.                                                    Regulations on Competitiveness.” Review of Environmental Economics
                                                                                and Policy 11: 183–206. https://​doi.​org/​10.​1093/​reep/​rex013.
Bergougui, B., and S. M. Murshed. 2023a. “Spillover Effects of FDI
Inflows on Output Growth: An Analysis of Aggregate and Disaggregated            Demena, B. A., and S. K. Afesorgbor. 2020. “The Effect of FDI on
FDI Inflows of 13 MENA Economies.” Australian Economic Papers 62:               Environmental Emissions: Evidence From a Meta-­A nalysis.” Energy
668–692. https://​doi.​org/​10.​1111/​1467-­​8 454.​12320​.                     Policy 138: 111192. https://​doi.​org/​10.​1016/J.​ENPOL.​2 019.​111192.
Bergougui, B., and S. M. Murshed. 2023b. “A Sectoral Analysis of                Djellouli, N., L. Abdelli, M. Elheddad, R. Ahmed, and H. Mahmood.
Institutional Quality and Foreign Direct Investment in Mena Countries:          2022. “The Effects of Non-­          Renewable Energy, Renewable Energy,
Does Sector Type Matter?” Review of World Economics 159: 987–1012.              Economic Growth, and Foreign Direct Investment on the Sustainability
https://​doi.​org/​10.​1007/​s1029​0 -­​022-­​0 0486​-­​x.                      of African Countries.” Renewable Energy 183: 676–686. https://​doi.​org/​
                                                                                10.​1016/j.​renene.​2 021.​10.​0 66.
Bergougui, B., and S. M. Murshed. 2023c. “Aggregate and Disaggregate
Impact of Natural Resources on Sustainable Development: New Evidence            Doğan, B., R. Khalfaoui, B. Bergougui, and S. Ghosh. 2025. “Unveiling
From the Latest Institutional Data.” Environmental and Sustainability           the Impact of the Digital Economy on the Interplay of Energy Transition,
Indicators 20: 100302. https://​doi.​org/​10.​1016/j.​indic.​2023.​100302.      Environmental Transformation, and Renewable Energy Adoption.”
                                                                                Research in International Business and Finance 76: 102837. https://​doi.​
Bergougui, B., and E. Satrovic. 2025. “Towards Eco-­Efficiency of OECD
                                                                                org/​10.​1016/j.​ribaf.​2 025.​102837.
Countries: How Does Environmental Governance Restrain the Destructive
Ecological Effect of the Excess Use of Natural Resources?” Ecological           Doğan, B., S. Tiwari, B. Bergougui, S. Ghosh, and D. Balsalobre-­L orente.
Informatics 87: 103093. https://​doi.​org/​10.​1016/j.​ecoinf.​2025.​103093.    2025. “Green Innovation and Fiscal Spending: Decoding the Path to
                                                                                Sustainable Development.” Sustainable Development 33: 6307–6327.
Birdsall, N., and D. Wheeler. 1993. “Trade Policy and Industrial
                                                                                https://​doi.​org/​10.​1002/​sd.​3 464.
Pollution in Latin America: Where Are the Pollution Havens?” Journal
of Environment & Development 2: 137–149. https://​doi.​org/​10.​1177/​          Dong, Y., J. Tian, and J. Ye. 2021. “Environmental Regulation and
10704​96593​0 0200107.                                                          Foreign Direct Investment: Evidence From China's Outward FDI.”
                                                                                Finance Research Letters 39: 101611. https://​doi.​org/​10.​1016/j.​f rl.​2 020.​
Blanco, L., F. Gonzalez, and I. Ruiz. 2013. “The Impact of FDI on CO2
                                                                                101611.
Emissions in Latin America.” Oxford Development Studies 41, no. 1:
104–121. https://​doi.​org/​10.​1080/​13600​818.​2 012.​732055.                 Doytch, N. 2020. “The Impact of Foreign Direct Investment on the
                                                                                Ecological Footprints of Nations.” Environmental and Sustainability
Blundell, R., and S. Bond. 1998. “Initial Conditions and Moment
                                                                                Indicators 8: 100085. https://​doi.​org/​10.​1016/j.​indic.​2 020.​100085.
Restrictions in Dynamic Panel Data Models.” Journal of Econometrics
87: 115–143. https://​doi.​org/​10.​1016/​S 0304​- ­​4 076(98)​0 0009​-­​8.     Doytch, N., and M. Uctum. 2016. “Globalization and the Environmental
                                                                                Impact of Sectoral FDI.” Economic Systems 40: 582–594. https://​doi.​org/​
Boateng, E., C. B. Annor, M. Amponsah, and R. E. Ayibor. 2024. “Does
                                                                                10.​1016/j.​ecosys.​2 016.​02.​0 05.
FDI Mitigate CO2 Emissions Intensity? Not When Institutional Quality
Is Weak.” Journal of Environmental Management 354: 120386. https://​            Doytch, N., and M. Uctum. 2019. “Spillovers From Foreign Direct
doi.​org/​10.​1016/j.​jenvm​an.​2 024.​120386.                                  Investment in Services: Evidence at Sub-­Sectoral Level for the Asia-­
                                                                                Pacific.” Journal of Asian Economics 60: 33–44. https://​doi.​org/​10.​
Borregaard, N., and A. Dufey. 2002. “Environmental Effects of Foreign
                                                                                1016/j.​asieco.​2 018.​10.​0 03.
Investment Versus Domestic Investment in the Mining Sector in Latin
America.” Conf Foreign Direct Invest Environ Lessons to be Learn From           Egesa, K., G. Legoff, M. Borga, A. Pegoue, A. Sanchez Rodelgo, and
Min Sect OECD Glob Forum Int Investment, Paris 3341091–3341096.                 D. Entaltsev. 2022. “Measuring Carbon Emissions of Foreign Direct
                                                                                Investment in Host Economies.” IMF Working Papers 2022: 1. https://​
Bournakis, I., D. Christopoulos, and S. Mallick. 2018. “Knowledge
                                                                                doi.​org/​10.​5089/​97984​0 0206​863.​0 01.
Spillovers and Output Per Worker: An Industry-­  L evel Analysis for
OECD Countries.” Economic Inquiry 56: 1028–1046. https://​doi.​org/​10.​        Ehrlich, P. R., and J. P. Holdren. 1971. “Impact of Population Growth
1111/​ecin.​12458​.                                                             Complacency Concerning This Component of Man's Predicament Is
                                                                                Unjustified and Counterproductive.” Science 171: 1212–1217.
Caetano, R. V., A. C. Marques, T. L. Afonso, and I. Vieira. 2022. “A Sectoral
Analysis of the Role of Foreign Direct Investment in Pollution and Energy       Eskeland, G. S., and A. E. Harrison. 2003. “Moving to Greener
Transition in OECD Countries.” Journal of Environmental Management              Pastures? Multinationals and the Pollution Haven Hypothesis.” Journal
302: 114018. https://​doi.​org/​10.​1016/j.​jenvm​an.​2021.​114018.             of Development Economics 70: 1–23. https://​doi.​org/​10.​1016/​S 0304​-­​
                                                                                3878(02)​0 0084​-­​6.
Carr, D. L., J. R. Markusen, and K. E. Maskus. 2001. “Estimating the
Knowledge-­Capital Model of the Multinational Enterprise.” American             Gorus, M. S., and M. Aslan. 2019. “Impacts of Economic Indicators
Economic Review 91: 693. https://​doi.​org/​10.​1257/​aer.​91.3.​693.           on Environmental Degradation: Evidence from MENA Countries.”
                                                                                Renewable and Sustainable Energy Reviews 103: 259–268. https://​doi.​
Chaudhry, I. S., W. Yin, S. A. Ali, et al. 2022. “Moderating Role of
                                                                                org/​10.​1016/j.​rser.​2 018.​12.​0 42.
Institutional Quality in Validation of Pollution Haven Hypothesis in
BRICS: A New Evidence by Using DCCE Approach.” Environmental                    Grossman, G. M., and A. B. Krueger. 1991. Environmental Impacts of a
Science and Pollution Research 29: 9193–9202.                                   North American Free Trade Agreement. National Bureau of Economic
                                                                                Research.
Coe, D. T., E. Helpman, and A. W. Hoffmaister. 2009. “International
R&D Spillovers and Institutions.” European Economic Review 53: 723–             Guo, Y., J. Deng, and X. Liu. 2023. “None-­Linear Nexus Between Natural
741. https://​doi.​org/​10.​1016/j.​euroe​corev.​2 009.​02.​0 05.               Resources Dependency, Foreign Direct Investment, and Environmental
                                                                                Sustainability in Newly Industrialized Countries.” Resources Policy 83:
Copeland, B. R., and M. S. Taylor. 1994. “North-­South Trade and the
                                                                                103656. https://​doi.​org/​10.​1016/j.​resou​r pol.​2 023.​103656.
Environment.” Quarterly Journal of Economics 109: 755–787. https://​doi.​
org/​10.​2307/​2118421.                                                         Hamid, I., M. S. Alam, A. Kanwal, P. K. Jena, M. Murshed, and
                                                                                R. Alam. 2022. “Decarbonization Pathways: The Roles of Foreign
De Vita, G., C. Li, and Y. Luo. 2021. “The Inward FDI—Energy Intensity
                                                                                Direct Investments, Governance, Democracy, Economic Growth, and
Nexus in OECD Countries: A Sectoral R&D Threshold Analysis.”
                                                                                Renewable Energy Transition.” Environmental Science and Pollution
Journal of Environmental Management 287: 112290. https://​doi.​org/​10.​
                                                                                Research 29: 49816–49831. https://​doi.​org/​10.​1007/​s1135​6 -­​022-­​18935​-­​3.
1016/j.​jenvm​an.​2 021.​112290.



Natural Resources Forum, 2026                                                                                                                               1317
                                                                                                                                                                       14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Hanif, I., S. M. F. Raza, P. Gago-­de-­Santos, and Q. Abbas. 2019. “Fossil          European Countries.” Environmental and Resource Economics 38: 497–
Fuels, Foreign Direct Investment, and Economic Growth Have Triggered                512. https://​doi.​org/​10.​1007/​s1064​0 -­​0 07-­​9 096-­​5.
CO2 Emissions in Emerging Asian Economies: Some Empirical Evidence.”
                                                                                    Mcnally, R. 1999. Foreign Direct Investment and the Environment: From
Energy 171: 493–501. https://​doi.​org/​10.​1016/j.​energy.​2019.​01.​011.
                                                                                    Pollution Havens to Sustainable Development, 1–106. World Wildl Fund.
Hannah, R., R. Pablo, and R. Max. 2020. “Emissions by Sector.” https://​
                                                                                    Merican, Y., Z. Yusop, Z. M. Noor, and L. S. Hook. 2007. “Foreign Direct
OurWo​rldIn​Data.​org.
                                                                                    Investment and the Pollution in Five ASEAN Nations.” International
Hao, Y., Y. Y. Guo, Y. Y. Guo, H. Wu, and S. Ren. 2020. “Does Outward               Journal of Economics and Management 1: 245–261.
Foreign Direct Investment (OFDI) Affect the Home Country's
                                                                                    Muhammad, B., M. K. Khan, M. I. Khan, and S. Khan. 2021. “Impact
Environmental Quality? The Case of China.” Structural Change and
                                                                                    of Foreign Direct Investment, Natural Resources, Renewable Energy
Economic Dynamics 52: 109–119. https://​doi.​org/​10.​1016/j.​strue​co.​
                                                                                    Consumption, and Economic Growth on Environmental Degradation:
2019.​0 8.​012.
                                                                                    Evidence From BRICS, Developing, Developed and Global Countries.”
Hernández Soto, G. 2024. “The Role of Foreign Direct Investment                     Environmental Science and Pollution Research 28: 21789–21798. https://​
and Green Technologies in Facilitating the Transition Toward Green                  doi.​org/​10.​1007/​s1135​6 -­​020-­​12084​-­​1.
Economies in Latin America.” Energy 288: 129933. https://​doi.​org/​10.​
                                                                                    Murshed, S. M., B. Bergougui, M. Badiuzzaman, and M. H. Pulok. 2022.
1016/j.​energy.​2 023.​129933.
                                                                                    “Fiscal Capacity, Democratic Institutions and Social Welfare Outcomes
Hille, E., M. Shahbaz, and I. Moosa. 2019. “The Impact of FDI on                    in Developing Countries.” Defence and Peace Economics 33: 280–305.
Regional Air Pollution in the Republic of Korea: A Way Ahead to                     https://​doi.​org/​10.​1080/​10242​694.​2 020.​1817259.
Achieve the Green Growth Strategy?” Energy Economics 81: 308–326.
                                                                                    OECD. 2002. “Foreign Direct Investment and the Environment: Lessons
https://​doi.​org/​10.​1016/j.​eneco.​2 019.​0 4.​0 04.
                                                                                    From the Mining Sector.” OECD Global Forum on International
IMF, and B. Manama. 2016. “Economic Diversification in Oil-­E xporting              Investment, OECD Publishing, Paris. https://​doi.​org/​10.​1787/​97892​
Arab Countries.” In Annual Meeting of Arab Ministers of Finance.                    64199​026-­​en.
International Monetary Fund.
                                                                                    Ofori, I. K., E. Y. Gbolonyo, and N. Ojong. 2022. “Towards Inclusive
ITC. 2023. “International Trade Center.”                                            Green Growth in Africa: Critical Energy Efficiency Synergies and
                                                                                    Governance Thresholds.” Journal of Cleaner Production 369: 132917.
Kahia, M., M. Kadria, M. S. Ben Aissa, and C. Lanouar. 2017. “Modelling
                                                                                    https://​doi.​org/​10.​1016/j.​jclep​ro.​2 022.​132917.
the Treatment Effect of Renewable Energy Policies on Economic
Growth: Evaluation From MENA Countries.” Journal of Cleaner                         Ofori, I. K., E. Y. Gbolonyo, and N. Ojong. 2023. “Foreign Direct
Production 149: 845–855. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 017.​02.​030.   Investment and Inclusive Green Growth in Africa: Energy Efficiency
                                                                                    Contingencies and Thresholds.” Energy Economics 117: 106414. https://​
Khalfaoui, R., H. Arminen, B. Doğan, and S. Ghosh. 2023.
                                                                                    doi.​org/​10.​1016/j.​eneco.​2 022.​106414.
“Environment-­Growth Nexus and Corruption in the MENA Region:
Novel Evidence Based on Method of Moments Quantile Estimations.”                    Opoku, E. E. O., S. Adams, and O. A. Aluko. 2021. “The Foreign Direct
Journal of Environmental Management 342: 118146. https://​doi.​org/​10.​            Investment-­
                                                                                               Environment Nexus: Does Emission Disaggregation
1016/j.​jenvm​an.​2 023.​118146.                                                    Matter?” Energy Reports 7: 778–787. https://​doi.​org/​10.​1016/j.​egyr.​2 021.​
                                                                                    01.​035.
Khan, M., A. T. Rana, and W. Ghardallou. 2023. “FDI and CO2 Emissions
in Developing Countries: The Role of Human Capital.” Natural Hazards                Opoku, E. E. O., and M. K. Boachie. 2020. “The Environmental Impact
117: 1125–1155. https://​doi.​org/​10.​1007/​s1106​9 -­​023-­​05949​- ­​4.          of Industrialization and Foreign Direct Investment.” Energy Policy 137:
                                                                                    111178. https://​doi.​org/​10.​1016/j.​enpol.​2 019.​111178.
Kharb, R., V. Suneja, S. Aggarwal, et al. 2024. “The Relationship
Between Investment Determinants and Environmental Sustainability:                   Ozturk, I., S. Farooq, M. T. Majeed, and M. Skare. 2024. “An Empirical
Evidence Through Meta-­A nalysis.” Quarterly Review of Economics and                Investigation of Financial Development and Ecological Footprint
Finance 94: 267–280. https://​doi.​org/​10.​1016/j.​qref.​2 024.​02.​0 01.          in South Asia: Bridging the EKC and Pollution Haven Hypotheses.”
                                                                                    Geoscience Frontiers 15, no. 4: 101588. https://​doi.​org/​10.​1016/j.​gsf.​
Liu, Q., S. Wang, W. Zhang, D. Zhan, and J. Li. 2018. “Does Foreign
                                                                                    2023.​101588.
Direct Investment Affect Environmental Pollution in China's Cities? A
Spatial Econometric Perspective.” Science of the Total Environment 613:             Pazienza, P. 2019. “The Impact of FDI in the OECD Manufacturing
521–529. https://​doi.​org/​10.​1016/j.​scito​tenv.​2 017.​0 9.​110.                Sector on CO2 Emission: Evidence and Policy Issues.” Environmental
                                                                                    Impact Assessment Review 77: 60–68. https://​doi.​org/​10.​1016/j.​eiar.​
Luo, Y., M. Salman, and Z. Lu. 2021. “Heterogeneous Impacts of
                                                                                    2019.​0 4.​0 02.
Environmental Regulations and Foreign Direct Investment on Green
Innovation Across Different Regions in China.” Science of the Total                 Roberts, M. R., and T. M. Whited. 2013. Chapter 7: Endogeneity in
Environment 759: 143744. https://​doi.​org/​10.​1016/j.​scito​tenv.​2 020.​         Empirical Corporate Finance, edited by G. M. Constantinides, M.
143744.                                                                             Harris, and R. Stulz, 493–572. Elsevier.
Mahmood, H., N. Saqib, A. H. Adow, and M. Abbas. 2023. “FDI, Exports,               Roodman, D. 2009. “How to Do Xtabond2: An Introduction to Difference
Imports, and Consumption-­Based CO2 Emissions in the MENA Region:                   and System GMM in Stata.” Stata Journal 9: 86–136. https://​doi.​org/​10.​
Spatial Analysis.” Environmental Science and Pollution Research 30:                 1177/​15368​67X09​0 0900106.
67634–67646. https://​doi.​org/​10.​1007/​s1135​6 -­​023-­​27245​-­​1.
                                                                                    Rosa, E. A., and T. Dietz. 1994. “Rethinking the Environmental Impacts
Markusen, J. R. 1995. “The Boundaries of Multinational Enterprises and              of Population, Affluence and Technology.” Human Ecology Review 1,
the Theory of International Trade.” Journal of Economic Perspectives 9:             no. 2: 277–300.
169–189. https://​doi.​org/​10.​1257/​jep.9.​2 .​169.
                                                                                    Rosa, E. A., and T. Dietz. 1998. “Climate Change and Society:
Marques, A. C., and R. Caetano. 2020. “The Impact of Foreign Direct                 Speculation, Construction and Scientific Investigation.” International
Investment on Emission Reduction Targets: Evidence From High-­and                   Sociology 13: 421–455. https://​doi.​org/​10.​1177/​02685​80980​13004002.
Middle-­Income Countries.” Structural Change and Economic Dynamics
                                                                                    Saidi, H., G. El Montasser, and A. N. Ajmi. 2020. “The Role of Institutions
55: 107–118. https://​doi.​org/​10.​1016/j.​strue​co.​2 020.​08.​0 05.
                                                                                    in the Renewable Energy-­Growth Nexus in the MENA Region: A Panel
Martínez-­Zarzoso, I., A. Bengochea-­Morancho, and R. Morales-­Lage.                Cointegration Approach.” Environmental Modeling and Assessment 25:
2007. “The Impact of Population on CO2 Emissions: Evidence From                     259–276. https://​doi.​org/​10.​1007/​s1066​6 -­​019-­​0 9672​-­​y.



1318                                                                                                                                Natural Resources Forum, 2026
                                                                                                                                                                        14778947, 2026, 3, Downloaded from https://onlinelibrary.wiley.com/doi/10.1111/1477-8947.70028 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [11/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Salahuddin, M., K. Alam, I. Ozturk, and K. Sohag. 2018. “The Effects                Waqih, M. A. U., N. A. Bhutto, N. H. Ghumro, S. Kumar, and M. A.
of Electricity Consumption, Economic Growth, Financial Development                  Salam. 2019. “Rising Environmental Degradation and Impact of Foreign
and Foreign Direct Investment on CO2 Emissions in Kuwait.” Renewable                Direct Investment: An Empirical Evidence From SAARC Region.”
and Sustainable Energy Reviews 81: 2002–2010. https://​doi.​org/​10.​               Journal of Environmental Management 243: 472–480.
1016/j.​rser.​2 017.​0 6.​0 09.
                                                                                    WDI. 2023. “World Development Indicators 2023.”
Saqib, N., I. Ozturk, M. Usman, A. Sharif, and A. Razzaq. 2023. “Pollution
                                                                                    Wei, Y., S. Ding, and Z. Konwar. 2022. “The Two Faces of FDI in
Haven or Halo? How European Countries Leverage FDI, Energy, and
                                                                                    Environmental Performance: A Meta-­A nalysis of Empirical Evidence
Human Capital to Alleviate Their Ecological Footprint.” Gondwana
                                                                                    in China.” Journal of Chinese Economics and Business Studies 20: 65–94.
Research 116: 136–148. https://​doi.​org/​10.​1016/j.​gr.​2022.​12.​018.
                                                                                    https://​doi.​org/​10.​1080/​14765​284.​2 021.​1943735.
Shahbaz, M., D. Balsalobre-­L orente, and A. Sinha. 2019. “Foreign Direct
                                                                                    Windmeijer, F. 2005. “A Finite Sample Correction for the Variance of
Investment–CO2 Emissions Nexus in Middle East and North African
                                                                                    Linear Efficient Two-­Step GMM Estimators.” Journal of Econometrics
Countries: Importance of Biomass Energy Consumption.” Journal of
                                                                                    126: 25–51. https://​doi.​org/​10.​1016/j.​jecon​om.​2 004.​02.​0 05.
Cleaner Production 217: 603–614. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 019.​
01.​282.                                                                            Wooldridge, J. M. 2010. Econometric Analysis of Cross Section and Panel
                                                                                    Data. MIT Press.
Shahbaz, M., S. Nasreen, F. Abbas, and O. Anis. 2015. “Does Foreign
Direct Investment Impede Environmental Quality in High-­, Middle-­,                 Wooldridge, J. M. 2012. Introductory Econometrics: A Modern Approach.
and Low-­Income Countries?” Energy Economics 51: 275–287. https://​                 Cengage Learning.
doi.​org/​10.​1016/j.​eneco.​2 015.​0 6.​014.
                                                                                    Wright, J., and B. Zhu. 2018. “Monopoly Rents and Foreign Direct
Sinha, A., T. Sengupta, and R. Alvarado. 2020. “Interplay Between                   Investment in Fixed Assets.” International Studies Quarterly 62, no. 2:
Technological Innovation and Environmental Quality: Formulating                     341–356. https://​doi.​org/​10.​1093/​isq/​sqy010.
the SDG Policies for Next 11 Economies.” Journal of Cleaner Production
                                                                                    Xing, Y., and C. D. Kolstad. 2002. “Do Lax Environmental Regulations
242: 118549. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 019.​118549.
                                                                                    Attract Foreign Investment?” Environmental and Resource Economics
Solarin, S. A., and P. K. Sahu. 2023. “Sectoral Foreign Direct Investment           21: 1–22. https://​doi.​org/​10.​1023/A:​10145​37013353.
and Environmental Degradation: New Insights From Diversification
                                                                                    Yi, J., Y. Hou, and Z. Z. Zhang. 2023. “The Impact of Foreign Direct
of Energy Mix Containing Fossil Fuels and Renewable Energy.”
                                                                                    Investment (FDI) on China's Manufacturing Carbon Emissions.”
Environmental Science and Pollution Research 30: 91853–91873. https://​
                                                                                    Innovation and Green Development 2: 100086. https://​doi.​org/​10.​1016/j.​
doi.​org/​10.​1007/​s1135​6 -­​023-­​28741​- ­​0.
                                                                                    igd.​2 023.​100086.
Stern, D. I. 2004. “The Rise and Fall of the Environmental Kuznets
                                                                                    York, R., E. A. Rosa, and T. Dietz. 2003. “STIRPAT, IPAT and ImPACT:
Curve.” World Development 32: 1419–1439. https://​doi.​org/​10.​1016/j.​
                                                                                    Analytic Tools for Unpacking the Driving Forces of Environmental
world​dev.​2 004.​03.​0 04.
                                                                                    Impacts.” Ecological Economics 46: 351–365. https://​doi.​org/​10.​1016/​
Sun, Y., H. Li, Z. Andlib, and M. G. Genie. 2022. “How Do Renewable                 S0921​-­​8009(03)​0 0188​-­​5.
Energy and Urbanization Cause Carbon Emissions? Evidence From
                                                                                    Yu, X., and Y. Li. 2020. “Effect of Environmental Regulation Policy
Advanced Panel Estimation Techniques.” Renewable Energy 185: 996–
                                                                                    Tools on the Quality of Foreign Direct Investment: An Empirical Study
1005. https://​doi.​org/​10.​1016/j.​renene.​2 021.​12.​112.
                                                                                    of China.” Journal of Cleaner Production 270: 122346. https://​doi.​org/​
Tienhaara, K. 2006. “Mineral Investment and the Regulation of                       10.​1016/j.​jclep​ro.​2 020.​122346.
the Environment in Developing Countries: Lessons From Ghana.”
                                                                                    Yu, Y., and T. Wang. 2021. “New Urbanization, Energy-­    Intensive
International Environmental Agreements: Politics, Law and Economics
                                                                                    Industries Agglomeration and Analysis of Nitrogen Oxides Emissions
6: 371–394. https://​doi.​org/​10.​1007/​s1078​4 -­​0 06-­​9 010-­​6.
                                                                                    Reduction Mechanisms.” Atmosphere 12: 1244.
Tsoy, L., and A. Heshmati. 2023. “Is FDI Inflow Bad for Environmental
                                                                                    Yu, Y., and W. Xu. 2019. “Impact of FDI and R&D on China's Industrial
Sustainability?” Environment, Development and Sustainability 26:
                                                                                    CO2 Emissions Reduction and Trend Prediction.” Atmospheric Pollution
28843–28858. https://​doi.​org/​10.​1007/​s1066​8-­​023-­​03844​-­​3.
                                                                                    Research 10: 1627–1635. https://​doi.​org/​10.​1016/j.​apr.​2 019.​0 6.​0 03.
Uche, E., N. Das, P. Bera, and J. Cifuentes-­Faura. 2023. “Understanding
                                                                                    Zameer, H., H. Yasmeen, M. W. Zafar, A. Waheed, and A. Sinha. 2020.
the Imperativeness of Environmental-­Related Technological Innovations
                                                                                    “Analyzing the Association Between Innovation, Economic Growth,
in the FDI–Environmental Performance Nexus.” Renewable Energy 206:
                                                                                    and Environment: Divulging the Importance of FDI and Trade
285–294. https://​doi.​org/​10.​1016/j.​renene.​2023.​02.​060.
                                                                                    Openness in India.” Environmental Science and Pollution Research 27:
UNCTAD. 2021. World Investment Report 2021, 280. UNCTAD, United                     29539–29553. https://​doi.​org/​10.​1007/​s1135​6 -­​020-­​0 9112​-­​5.
Nations Conf Trade Dev.
                                                                                    Zheng, J., Z. Zhou, J. Liu, et al. 2023. “A Novel Framework for
Walter, I., and J. L. Ugelow. 1979. “Environmental Policies in Developing           Investigating the Mechanisms of Climate Change and Anthropogenic
Countries.” Ambio 8: 102–109.                                                       Activities on the Evolution of Hydrological Drought.” Science of the
                                                                                    Total Environment 900: 165685. https://​doi.​org/​10.​1016/j.​scito​tenv.​2 023.​
Wang, C., and X. Guo. 2022. “Spatio-­Temporal Effect of Provincial
                                                                                    165685.
Technological Innovation on Environmental Pollution in China.”
Frontiers in Public Health 10: 1073920. https://​doi.​org/​10.​3389/​f pubh.​       Zhou, D., M. Kongkuah, A. K. Twum, and I. Adam. 2024. “Assessing the
2022.​1073920.                                                                      Impact of International Trade on Ecological Footprint in Belt and Road
                                                                                    Initiative Countries.” Heliyon 10: e26459. https://​doi.​org/​10.​1016/j.​heliy​
Wang, C., and M. Uctum. 2024. “Ecological Footprint of FDI Inflows
                                                                                    on.​2 024.​e26459.
and Income Threshold Effect: New Results With a New Approach to
Income Classification.” Environmental and Sustainability Indicators 22:             Zuo, S., Y. Zhao, L. Zheng, Z. Zhao, S. Fan, and J. Wang. 2024. “Assessing
100356. https://​doi.​org/​10.​1016/j.​indic.​2 024.​100356.                        the Influence of the Digital Economy on Carbon Emissions: Evidence at
                                                                                    the Global Level.” Science of the Total Environment 946: 174242. https://​
Wang, M., J. Liu, S. Rahman, X. Sun, and S. Sriboonchitta. 2023.
                                                                                    doi.​org/​10.​1016/j.​scito​tenv.​2 024.​174242.
“The Effect of China's Outward Foreign Direct Investment on Carbon
Intensity of Belt and Road Initiative Countries: A Double-­Edged Sword.”
Economic Analysis and Policy 77: 792–808. https://​doi.​org/​10.​1016/j.​eap.​
2022.​12.​030.


Natural Resources Forum, 2026                                                                                                                                  1319
