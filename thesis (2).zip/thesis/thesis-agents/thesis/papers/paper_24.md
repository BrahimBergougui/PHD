            Energy Sources, Part B: Economics, Planning, and Policy



       Mitigating Energy Vulnerability with Industrial Robotics: When Institutions Matter,
               How Green Innovation Mediates, and Where Spillovers Concentrate




                       Submission ID      269271714

                         Article Type     Original Papers

                                          Robots, Energy Vulnerability, Industrial Structur
                           Keywords       e Transformation, Green Patent, Institutional Eff
                                          ectiveness

                             Authors      brahim bergougui




                                        For any queries please contact:

                                  UESB-peerreview@journals.tandf.co.uk




                                             Note for Reviewers:

                  To submit your review please visit https://mc.manuscriptcentral.com/UESB




For Peer Review Only - Non-Anonymous PDF                                                      Cover Page
1
2
3
4
5
6
7
8
     Title
9
10   Mitigating Energy Vulnerability with Industrial Robotics: When Institutions Matter, How




                                                                                                                w
11
12   Green Innovation Mediates, and Where Spillovers Concentrate
13




                                                                                                              e
14   1) Brahim Bergougui (Corresponding author)




                                                                                                 i
15
16   International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
17




                                                                                               v
18
     College of Business & Economics, Qatar University, Doha, Qatar
19




                                                                                       e
20
     bergougui@iss.nl / brahimbergougui@gmail.com
21
22
23   Abstract




                                                                R
24
25         Amid escalating geopolitical conflicts, environmental degradation, and persistent energy supply
     disruptions, energy vulnerability has become a first-order policy concern. This paper examines whether
26
     industrial robotics can mitigate energy vulnerability using panel data from 51 countries over 2000–2022.
27




                                                              r
     We estimate direct effects, investigate transmission mechanisms, test for institutional threshold effects, and
28   assess spatial spillovers. Four sets of results emerge. First, industrial robotics significantly reduces energy
29   vulnerability — a finding robust to instrumental variable estimation, alternative measures, and outlier




                                               e
30   treatment. Second, mediation analysis identifies two principal transmission channels: green patent
31   innovation. Third, threshold regression reveals a non-monotonic, three-regime relationship contingent on
     institutional effectiveness: robotics increases vulnerability under weak institutions, achieves its largest




                                             e
32
     reductions at intermediate levels, and exhibits diminishing — even adverse — returns at advanced stages,
33   consistent with rebound and saturation mechanisms. Fourth, energy gains concentrate geographically
34   around Japan, with proximate countries experiencing significantly larger reductions. Heterogeneity analysis
35




                        P
     reveals stronger effects in middle-income economies, digitally mature nations, and low-population
36   countries. These findings suggest that realizing automation's energy resilience dividends requires
37   simultaneous institutional strengthening, green innovation incentives, and regional cooperation.
38




                      r
39   Keywords: Robots; Energy Vulnerability; Green Patent; Institutional Effectiveness; Industrial Structure
     Transformation
40
41




       o
     Graphical abstract
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 1 of 35
1
2
3
4
5
6
7
8
9
10




                         w
11
12
13




                       e
14




                      i
15
16
17




                    v
18
19




                 e
20
21
22
23




                R
24
25
26
27




              r
28
29




             e
30
31




           e
32
33
34
35




          P
36
37
38




        r
39
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                          Page 2 of 35
1
2
3
4
5
6
7
8
     1. Introduction
9
10




                                                                                                               w
11           Energy vulnerability—the susceptibility of national energy systems to external shocks and their
12   limited capacity to recover equilibrium—has become a first-order concern for policymakers (Gatto &
13




                                                                                                             e
     Busato, 2020; Yang Liu et al., 2023; Song et al., 2024). The concept encompasses a spectrum of risks
14




                                                                                                 i
15   spanning supply adequacy, price stability, import dependence, and environmental sustainability, and its
16   salience has intensified markedly in recent years. Climate change has increased the frequency and severity
17




                                                                                               v
     of extreme weather events that disrupt power grids and energy infrastructure (Brás et al., 2023; V. Boivin
18
     et al., 2025; Xu et al., 2025). Geopolitical fragmentation—from the Russia-Ukraine conflict and its
19




                                                                                       e
20   exposure of precarious gas market interdependencies (Kuzemko et al., 2022) to escalating military
21   confrontations across the Middle East and sustained disruptions to critical maritime energy corridors in the
22
     Red Sea and Persian Gulf (Akadiri & Özkan, 2025; Notteboom et al., 2024)—has transformed energy
23




                                                                 R
24   vulnerability from a latent structural risk into an active, evolving crisis.
25
             Against this backdrop, a growing literature examines whether technological change can bolster
26
27   energy system resilience. Much of this work focuses on the role of digitalization and artificial intelligence




                                                               r
28   in optimizing energy markets (Della Valle et al., 2025; Gatto & Busato, 2020; Kajoskoski et al., 2025; Lieth
29




                                                e
     et al., 2025). Yet a critical distinction must be made between digital algorithms and physical automation.
30
31   Industrial robotics—defined by the International Federation of Robotics (IFR) as fully autonomous,




                                              e
32   reprogrammable machines capable of performing multiple manual tasks without a human operator—
33   represents the tangible interface where digital intelligence meets material production. Unlike general AI,
34
35   which primarily processes data, industrial robotics directly alters the physical efficiency of manufacturing




                         P
36   and infrastructure maintenance (Abdullayev et al., 2025; Graetz & Michaels, 2018). This distinction
37   matters: as Figure 1 illustrates, the geographic distributions of robotics density and energy vulnerability do
38
     not neatly overlap, suggesting that the relationship between the two is neither simple nor linear.




                       r
39
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                      Page 3 of 35
1
2
3
4
5
6
7
8                                              Energy Vulnerability Index
9                                         Higher values indicate greater vulnerability
10




                                                                                                               w
11
12
13




                                                                                                             e
14




                                                                                                  i
15
16
17




                                                                                                v
18
19    Vulnerability Level




                                                                                               e
           (-1.80,-1.27]
20         (-2.01,-1.80]
           (-2.14,-2.01]
21         (-2.23,-2.14]
           [-2.48,-2.23]
22         No data
23                                                 Industrial Robot Stock




                                                                   R
24                                      Darker colors indicate higher industrial robot stock
25
26
27




                                                                 r
28
29




                                                e
30
31




                                              e
32
33              Robot Stock (Units)
34                     (76; 3338]
                       (36; 76]
35




                              P
                       (3; 36]
                       (1; 3]
36                     [0; 1]
                       No data
37
38   Figure 1. Global distribution of energy vulnerability and industrial robot stock (2000-2022)




                            r
39
40            The theoretical case for robotics as a mitigating force against energy vulnerability rests on several
41   mechanisms. By replacing antiquated, energy-intensive machinery with automated systems capable of real-




       o
42
     time monitoring and load optimization, robotics can reduce the energy intensity of industrial production
43
44   (Buliesibaike et al., 2025; Graetz & Michaels, 2018; Huang et al., 2022; En-Ze Wang et al., 2022). Robotic




     F
45   automation also facilitates the integration of variable renewable energy sources by enabling demand-side
46
     management, allowing production cycles to adjust to fluctuations in solar and wind availability (Badareu
47
48   et al., 2024; Banad et al., 2025; Iqbal et al., 2019). Furthermore, robotics-driven innovation generates
49   spillovers in green technologies—from advanced energy storage to smart grid applications—that directly
50   strengthen system resilience (Xiaoqian Liu et al., 2025; Lei Wang et al., 2023; Yu et al., 2022). And at the
51
52   structural level, automation accelerates the transition from resource-intensive heavy industry toward
53
54
55
56
57
58
59
60



                                                                                                                      Page 4 of 35
1
2
3
4
5
6
7
8
     knowledge-intensive, service-oriented sectors with inherently lower energy footprints (Bergougui, 2025c,
9
10   2025b; Deng et al., 2025; Xin-gang & Jin, 2022).




                                                                                                                w
11
             Despite these theoretical connections, systematic empirical evidence linking industrial robotics
12
13   specifically to energy vulnerability remains sparse. The existing literature has extensively covered the




                                                                                                              e
14   energy–AI nexus (Gao & Wang, 2025; Umar et al., 2025) and the growth–energy nexus (Vasilescu et al.,




                                                                                                 i
15   2025), but these studies typically conflate robotics with general ICT or examine only labor market
16
17   consequences of automation, neglecting its implications for national energy security (Huang et al., 2022;




                                                                                               v
18   Iqbal et al., 2019; Liang Liu et al., 2021; Yong Wang et al., 2024). Moreover, existing work rarely
19   interrogates the transmission mechanisms through which automation affects energy outcomes, the




                                                                                       e
20
21   institutional preconditions under which such effects materialize, or the spatial dimensions of technology
22   diffusion in this context.
23




                                                                R
24           This paper addresses these gaps. We investigate the impact of industrial robotics on energy
25   vulnerability using a balanced panel of 51 countries over the period 2000–2022, a temporal scope that
26   encompasses the critical phases of the digital revolution, the 2008 financial crisis, the post-2015 SDG era,
27




                                                              r
     and recent geopolitical disruptions. Our empirical approach proceeds in several steps. We first establish the
28
29   baseline relationship using two-way fixed effects estimation with country-level clustered standard errors,




                                               e
30   then subject it to a battery of robustness checks including instrumental variable estimation, alternative robot
31
     measures, temporal lags, and outlier treatment. We then move beyond reduced-form estimates to test two




                                             e
32
33   specific mediation channels—green patent innovation and industrial structure transformation. Next, we
34   deploy Hansen’s (1999) threshold regression to determine whether the robotics–energy vulnerability
35




                        P
     relationship shifts fundamentally at critical levels of institutional effectiveness. Finally, we assess spatial
36
37   heterogeneity by exploiting variation in geographic proximity to Japan, the world’s leading robotics
38   innovation hub, and conduct stratified analyses by income level, digital infrastructure maturity, and




                      r
39   demographic scale.
40
41           This study makes several contributions to the literature on technology-driven energy resilience.




       o
42
     First, we construct a multidimensional energy vulnerability index drawing on annual data from multiple
43
44   integrated databases, capturing five core dimensions—energy accessibility, efficiency, renewable energy




     F
45   penetration, consumption structure, and supply security. Unlike prior indices that rely on cross-sectional
46   snapshots (Dong et al., 2021; Gatto & Busato, 2020), our balanced panel construction enables dynamic
47
48   tracking of vulnerability trajectories across 51 economies over more than two decades. Second, we move
49   beyond reduced-form correlations to interrogate the causal architecture linking industrial robotics to energy
50   outcomes. Specifically, we identify and empirically test two principal transmission channels—green
51
     technological innovation (proxied by environmental patent intensity) and industrial structure upgrading—
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 5 of 35
1
2
3
4
5
6
7
8
     thereby isolating actionable policy leverage points that generic technology–energy studies typically
9
10   overlook. Third, recognizing that the marginal effect of automation on energy systems is unlikely to be




                                                                                                                  w
11   constant across institutional contexts, we deploy Hansen’s (1999) panel threshold regression to
12   endogenously identify critical inflection points in institutional effectiveness at which the robotics–energy
13




                                                                                                                e
14   vulnerability relationship fundamentally shifts in sign and magnitude. Fourth, we exploit cross-country




                                                                                                   i
15   variation in geographic proximity to Japan to test whether spatial technology diffusion channels amplify
16   the energy resilience dividends of automation, contributing to the nascent literature on the geography of
17




                                                                                                 v
     technology-driven sustainability gains. Fifth, we conduct a systematic heterogeneity analysis stratified by
18
19   income classification, digital infrastructure maturity, and demographic scale, offering granular evidence on




                                                                                         e
20   the structural preconditions under which robotics adoption reliably translates into energy vulnerability
21
     reduction versus contexts in which such benefits remain unrealized.
22
23           The paper proceeds as follows. Section 2 sets out the theoretical framework and the hypotheses it




                                                                 R
24
     implies. Section 3 describes the data and econometric methodology. Section 4 reports empirical results.
25
26   Section 5 concludes.
27




                                                               r
28   2. Background
29




                                                e
30
     2.1 Industrial robots and energy vulnerability
31




                                              e
32
33   The proliferation of industrial robots (IR) within the energy sector and energy-intensive industries offers a
34   transformative pathway for bolstering system resilience and mitigating vulnerability (Zhu et al., 2025). This
35




                        P
     mitigation occurs through several physical and operational mechanisms: (1) Precision and operational
36
37   efficiency: Unlike manual labor, industrial robots execute tasks with deterministic precision. In energy
38   production, this translates to the optimization of raw material usage and the minimization of operational




                      r
39   waste (Răileanu et al., 2024; Soori et al., 2023). By streamlining production lines, IRs significantly reduce
40
     the energy intensity per unit of output, thereby lowering aggregate demand and relieving pressure on energy
41




       o
42   grids (Buliesibaike et al., 2025; Wei Li et al., 2025; Xiekui Zhang et al., 2022). (2) Infrastructure
43   resilience and maintenance: Robotic automation—including drones and autonomous crawlers—
44
     revolutionizes the maintenance of critical energy infrastructure. Robots can operate in hazardous




     F
45
46   environments to perform real-time inspections of pipelines, transmission lines, and offshore rigs (Mitchell
47   et al., 2022; Yi et al., 2021). This capability allows for the preemptive identification of structural fatigue or
48
     faults, preventing catastrophic failures and ensuring supply continuity. (3) Renewable energy scalability:
49
50   The widespread adoption of robotics is a prerequisite for scaling renewable energy. Automated
51   manufacturing cells are essential for the cost-effective mass production of photovoltaic panels and wind
52
53
54
55
56
57
58
59
60



                                                                                                                         Page 6 of 35
1
2
3
4
5
6
7
8
     turbine components, ensuring high fidelity and performance standards (Mitchell et al., 2022). Furthermore,
9
10   robotic systems are increasingly deployed to clean solar arrays and service wind turbines, optimizing the




                                                                                                              w
11   generation efficiency of renewable assets and reducing reliance on fossil fuels. Consequently, the
12   integration of robotics fortifies the energy system against both internal inefficiencies and external supply
13




                                                                                                            e
14   shocks.




                                                                                                i
15
     Hypothesis 1: Industrial robotics directly reduce energy vulnerability.
16
17




                                                                                              v
18   2.2 The role of green patents
19




                                                                                      e
20   Industrial robots are fundamental enablers of green patents, serving as the hardware execution layer for
21   sustainable industrial practices (Tian et al., 2023). (i) Enabling circular economy: Advanced robotics are
22
23   revolutionizing waste management. Robotic sorting systems, equipped with advanced sensors, can separate




                                                                R
24   recyclable materials from waste streams with a speed and accuracy unattainable by human sorters (Wilts et
25   al., 2021). This capability closes the loop on material usage, reducing the energy required to extract and
26
27   process virgin resources. (ii) Eco-efficient manufacturing processes: Robotics drive innovation in




                                                              r
28   production techniques, such as additive manufacturing (3D printing), which builds products layer-by-layer
29   rather than subtracting material. This significantly reduces scrap rates and energy consumption (Jung et al.,




                                               e
30
     2023). (iii) Development of new energy vehicles (NEVs): The mass production of NEVs and high-
31




                                             e
32   capacity batteries relies heavily on robotic automation to ensure safety and cost-competitiveness. By
33   accelerating the transition to electrified transport, robotics indirectly reduce the economy's dependence on
34
     imported oil (Villagrossi & Dinon, 2023). Through these innovations, robotics lower the carbon footprint
35




                       P
36   of the industrial sector and diversify energy sources.
37
38   Hypothesis 2: Industrial robotics indirectly reduce energy vulnerability through green patents pathway.




                     r
39
40   2.3 The role of industrial structure upgrading
41




       o
42   The wide-scale application of industrial robots acts as a primary engine for structural transformation within
43
     the economy, shifting the industrial base toward lower energy intensity (Graetz & Michaels, 2018; Song et
44




     F
45   al., 2024). (i) Transition from labor to tech-intensive: Robotic adoption facilitates a move away from
46   low-value, high-consumption heavy industries toward high-value, sophisticated manufacturing sectors
47
     (Antonioli et al., 2024; Leigh et al., 2022). These advanced sectors generally exhibit higher value-added
48
49   per unit of energy consumed. (ii) Growth of productive service sectors: The deployment of robots creates
50   demand for complementary service sectors, such as systems integration, software maintenance, and data
51   analytics. This expands the tertiary industry, which is typically less energy-intensive than primary
52
53
54
55
56
57
58
59
60



                                                                                                                     Page 7 of 35
1
2
3
4
5
6
7
8
     manufacturing (Filippucci et al., 2024; Wu et al., 2025). (iii) Substitution effect: As robots take over
9
10   repetitive, energy-intensive tasks, firms rationalize production lines. The resulting "smart factories" utilize




                                                                                                                w
11   energy-on-demand systems, automatically powering down equipment when idle—a feat difficult to achieve
12   in manual labor settings (Mohamed et al., 2019). This structural evolution ensures that economic growth
13




                                                                                                              e
14   creates a decoupled trajectory from energy consumption, reducing overall systemic vulnerability.




                                                                                                 i
15
     Hypothesis 3: Industrial robotics indirectly reduce energy vulnerability through the upgrading of the
16
17   industrial structure pathway.




                                                                                               v
18
19   2.4 The threshold role of institutional effectiveness




                                                                                       e
20
21   The adoption of industrial robotics exerts a distinct pressure on public institutions to modernize, thereby
22
23   enhancing institutional effectiveness (Acemoglu & Restrepo, 2020). This improvement in institutions




                                                                R
24   subsequently bolsters energy security through three channels: (i) Regulatory modernization and
25   standardization: The shift toward "Industry 4.0" necessitates that governments establish robust regulatory
26
27   frameworks regarding digital infrastructure, safety standards, and industrial protocols (Qiang Wang et al.,




                                                              r
28   2024). This modernization enhances the government's overall capacity to manage complex systems,
29   including energy markets. (ii) Infrastructure planning and execution: High-tech manufacturing requires




                                                e
30
     stable, high-quality power supplies. Governments keen on attracting robotic automation are compelled to
31




                                              e
32   upgrade grid infrastructure and improve utility management (Song et al., 2024). This "governance
33   response" leads to more robust energy networks capable of withstanding demand fluctuations. (iii) Crisis
34
     response and strategic coordination: The data integration required for robotic factories often links with
35




                        P
36   broader industrial IoT (Internet of Things) networks. Governments utilizing these networks gain better
37   visibility into industrial energy consumption patterns (Dharfizi, 2018). This transparency allows for more
38
     precise policy interventions during energy shortages and facilitates better inter-agency coordination to




                      r
39
40   prevent market manipulation. Therefore, the push for industrial automation acts as a catalyst for better
41   institutions, which in turn secures the energy landscape.




       o
42
43   Hypothesis 4: Institutional effectiveness creates threshold effects, causing robotics' impact on energy
44   vulnerability to shift fundamentally at critical effectiveness levels.




     F
45
46   Hypothesis 5 : Geographic proximity to Japan generates spatial spillover effects that amplify robotics'
47   energy capacity benefits.
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 8 of 35
1
2
3
4
5
6
7
8
9
10




                                                                                                               w
11
12
13




                                                                                                             e
14




                                                                                                 i
15
16
17




                                                                                               v
18
19




                                                                                       e
20
21
22
23




                                                               R
24
25
26
27




                                                             r
28         Figure 2. Integrated framework explaining the industrial robotics–energy vulnerability nexus
29




                                               e
30
     3. Methodological framework and empirical analysis
31




                                             e
32
33   3.1. Theoretical model construction
34
35   This study develops an integrated theoretical framework to examine the link between industrial robotics




                       P
36   implementation and energy vulnerability (ENV). The foundational econometric model is formulated as
37   follows:
38




                     r
39
40   𝐸𝑁𝑉𝑖𝑡 = 𝛽0 + 𝛽1 𝐼𝑅𝑖𝑡 + 𝛽2 𝑋𝑖𝑡 + 𝜃𝑖 + 𝛿𝑡 + 𝜀𝑖𝑡                                                (1)
41




       o
42   In Equation (1), the subscripts 𝑖and 𝑡refer to country and time dimensions, respectively. The dependent
43   variable, 𝐼𝐸𝑁𝑉, measures infrastructure energy vulnerability, whereas 𝐼𝑅 denotes the principal explanatory
44
     variable reflecting the degree of industrial robotics; The vector 𝑋includes a broad set of control variables




     F
45
46   that account for observable factors influencing infrastructure energy vulnerability. Country fixed effects (𝜃𝑖
47   ) absorb unobserved time-invariant national characteristics, while time fixed effects (𝛿𝑡 ) capture common
48
     shocks and global trends affecting all countries during each period. The disturbance term, 𝜀𝑖𝑡 , represents
49
50   the idiosyncratic error component. To ensure reliable statistical inference, all estimations employ standard
51   errors clustered at the country level, thereby mitigating potential biases arising from heteroskedasticity and
52
53
54
55
56
57
58
59
60



                                                                                                                      Page 9 of 35
1
2
3
4
5
6
7
8
     within-country serial correlation (Gao & Wang, 2025). To further investigate the channels through which
9
10   industrial robotics influences infrastructure energy vulnerability, this study implements a mediation




                                                                                                              w
11   analysis based on established empirical approaches (Chao et al., 2023; Dong et al., 2024). The mediation
12
     assessment follows a sequential two-step estimation strategy designed to identify both the direct effect of
13




                                                                                                            e
14   industrial robotics and its indirect effects operating through the proposed mediating variables.




                                                                                                i
15
16   𝑀𝐸𝐷𝑖𝑡 = 𝜋0 + 𝜋1 𝐼𝑅𝑖𝑡 + 𝜋2 𝑋𝑖𝑡 + 𝜃𝑖 + 𝛿𝑡 + 𝜀𝑖𝑡                                                       (2)
17




                                                                                              v
18
19   𝐸𝑁𝑉𝑖𝑡 = 𝛼0 + 𝛼1 𝑀𝐸𝐷𝑖𝑡 + 𝛼2 𝑋𝑖𝑡 + 𝜃𝑖 + 𝛿𝑡 + 𝜀𝑖𝑡                                                      (3)




                                                                                      e
20
21   In Equations (2) and (3), 𝑀𝐸𝐷 represents the proposed transmission channels, namely government
22   regulation, green technological innovation, and industrial structure transformation. A statistically
23




                                                              R
24   significant mediation effect is inferred when the estimated coefficients 𝜋1 and 𝛼1 are both significant,
25   demonstrating that the influence of industrial robotics (𝐼𝑅) on infrastructure energy vulnerability (𝐼𝐸𝑁𝑉) is
26   transmitted, at least in part, through these mediating pathways.
27




                                                            r
28
     3.2. Data construction and variable operationalization
29




                                               e
30
     3.2.1. Energy vulnerability (ENV) measurement
31




                                             e
32   The dependent variable, energy vulnerability, encapsulates the multidimensional nature of energy system
33
     fragility across accessibility, sustainability, and security dimensions. Unlike previous cross-sectional
34
35   analyses that provide limited temporal insights (Dong et al., 2021; Gatto & Drago, 2020), this study




                       P
36
     employs a balanced panel dataset spanning 51 nations over the period 2000-2022. The ENV composite
37
38   indicator integrates five fundamental components: energy accessibility, efficiency parameters, renewable




                     r
39   energy penetration, consumption patterns, and security indicators (Yang Liu et al., 2023). The
40
     construction methodology employs entropy weighting to determine objective importance weights for each
41




       o
42   sub-component, avoiding arbitrary weighting schemes that may introduce bias (Gatto & Busato, 2020).
43   Specifically:
44




     F
45
         •   Energy accessibility captures the proportion of population with reliable electricity access and
46
47           modern cooking facilities
48       •   Energy efficiency encompasses sectoral intensity ratios and economy-wide efficiency measures
49
         •   Renewable energy penetration reflects the share of sustainable sources in total energy
50
51           consumption and electricity generation
52
53
54
55
56
57
58
59
60



                                                                                                                     Page 10 of 35
1
2
3
4
5
6
7
8
         •   Energy consumption patterns examine per capita usage, sectoral distribution, and import
9
10           dependency ratios




                                                                                                            w
11       •   Security indicators incorporate supply diversification indices, strategic reserve levels, and
12           geopolitical risk assessments
13




                                                                                                          e
14




                                                                                                  i
15   Higher ENV values indicate greater vulnerability within national energy systems. The indicator undergoes
16   logarithmic transformation to address skewness and facilitate elasticity interpretation.
17




                                                                                                v
18   3.2.2. Industrial robotics (IRs) assessment
19




                                                                                      e
20   Industrial robotics development serves as the primary explanatory variable, representing technological
21
     sophistication and automation penetration within national economies. The measurement approach utilizes
22
23   robot density metrics from the International Federation of Robotics database, specifically the cumulative




                                                               R
24   stock of operational industrial robots per thousand manufacturing employees (Bergougui, 2025c, 2025d,
25
     2025a). This operationalization captures several theoretical advantages:
26
27




                                                             r
28       •   Deployment focus: Robot density reflects actual implementation rather than capacity or investment
29           intentions




                                               e
30
31       •   Sectoral relevance: Manufacturing sector focus aligns with primary industrial robotics applications




                                             e
32           where energy impacts are most pronounced
33       •   Cross-country comparability: Employment-adjusted metrics control for varying labor market sizes
34
             across countries.
35




                       P
36
37   As robustness validation, we employ alternative measurements including annual new robot installations
38   and cumulative installation flows (Lee et al., 2022). These alternative indicators provide different




                     r
39
40   temporal perspectives on robotics adoption patterns and technological diffusion rates.
41




       o
42   3.2.3. Mediating variable construction
43
44   •   Green patents: Green patent applications quantify technological innovation directed toward




     F
45       environmental sustainability and energy efficiency improvements (Bergougui, 2024a, 2024b;
46
         Bergougui et al., 2024; Bergougui & Aldawsari, 2024). Data compilation draws from WIPO Green
47
48       Technology Database and OECD patent statistics, focusing on patents classified under environmentally
49       sound technologies. The measurement captures innovation intensity through patents per million
50
         population, controlling demographic differences across countries. Green technology categories include
51
52       renewable energy technologies, energy storage systems, smart grid innovations, energy-efficient
53
54
55
56
57
58
59
60



                                                                                                                   Page 11 of 35
1
2
3
4
5
6
7
8
         transportation, and industrial process improvements. Patent indicators possess several empirical
9
10       advantages: they reflect actual innovative output rather than inputs like R&D expenditure; they undergo




                                                                                                                w
11       rigorous examination processes ensuring quality thresholds; and they provide detailed technological
12       classification enabling focused analysis (Ge Li & Wang, 2024).
13




                                                                                                              e
14   •   Industrial structure transformation: Industrial structure transformation measures the evolution from




                                                                                                 i
15       primary resource extraction toward knowledge-intensive service activities, incorporating both sectoral
16       composition changes and productivity improvements (Xin-gang & Jin, 2022). The theoretical
17




                                                                                               v
18       foundation recognizes that advanced industrial structures typically demonstrate greater energy
19       efficiency, reduced resource intensity, and enhanced adaptation capacity to external shocks. Service-




                                                                                       e
20       oriented economies generally exhibit lower energy vulnerability through diversified consumption
21
         patterns and reduced dependence on energy-intensive manufacturing (Yuan et al., 2018).
22
23




                                                                R
24   3.2.4. Threshold variable: institutional effectiveness (INST)
25
26   To capture institutional effectiveness, this study relies on the Worldwide Governance Indicators (WGI)
27




                                                              r
     developed by the World Bank (Kaufmann et al., 2011) , aggregating six governance dimensions: voice and
28   accountability, political stability and absence of violence, government effectiveness, regulatory quality, rule
29




                                               e
30   of law, and control of corruption. Each dimension receives standardized scores ranging from -2.5 (weakest)
31   to 2.5 (strongest governance). The composite measure aggregates these components using equal weights,




                                             e
32   following established practices in governance research (Song et al., 2024). Higher values indicate superior
33
34   regulatory frameworks, enforcement capacity, and institutional quality. The theoretical justification rests
35   on institutional capacity to design, implement, and enforce energy policies that enhance system resilience.




                        P
36   Effective institutions enable coordinated responses to energy disruptions, facilitate infrastructure
37
     investments, promote appropriate regulatory frameworks, and ensure that technological adoption—such as
38




                      r
39   industrial robotics—translates into measurable energy system improvements rather than implementation
40   failures. Table 1 presents comprehensive descriptive statistics for all variables employed in the analysis.
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 12 of 35
1
2
3
4
5
6
7
8
     Table 1. Statistical description of the variables.
9
10    Code      Variable                                     N        Mean       S.D.       Min.       Max.




                                                                                                            w
11    ENV       energy vulnerability                        1173      -2.022     0.291     -2.567     -1.118
      IRs       Industrial Robotics                         1173       0.018     0.072     0.000      0.783
12    GDP       Economic growth                             1173       0.214     0.187     0.004      0.809
13




                                                                                                          e
      POP       Population                                  1173      16.744     1.652     12.547     21.065
14    EMP       Employment                                  1173       0.563     0.088     0.350      0.806




                                                                                              i
15    FDI       Foreign investment                          1173       0.057     0.222     -0.401     4.491
16    EXC       exchange rate                               1173       0.007     0.037     0.000      0.420
17    INF       Inflation                                   1173       0.044     0.079     -0.045     1.686




                                                                                            v
      INST      Institutional effectiveness                 1173       2.441     0.527     -0.408     3.076
18    GP        Green patents                               1173       0.001     0.008     0.000      0.106
19    IST       Industrial structure transformation         1173      14.880     0.928     12.495     16.865




                                                                                    e
20
21   4. Empirical results and analysis
22
23   4.1. Baseline regression findings




                                                             R
24
25   Table 2 presents the core regression results examining industrial robotics effects on infrastructure energy
26   vulnerability using fixed-effects panel estimation. The progressive specification approach allows
27




                                                           r
     assessment of robustness across different control variable combinations. Column (1) establishes the
28
29   unconditional relationship without control variables, yielding a coefficient of -0.66, indicating that




                                                 e
30   industrial robotics significantly reduces infrastructure energy vulnerability. The negative coefficient
31   supports the theoretical prediction that automation technologies enhance energy system resilience. Column




                                               e
32
33   (2) incorporates demographic, economic, and international control variables. The industrial robotics
34   coefficient remains negative and significant with minimal magnitude reduction, suggesting robustness to
35




                        P
     observable confounding factors. Column (3) adds country and time fixed effects, providing the most
36
     rigorous specification. The coefficient becomes -0.345, maintaining statistical significance while showing
37
38   expected attenuation due to fixed effects absorption of time-invariant heterogeneity and common temporal




                      r
39   shocks.
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                   Page 13 of 35
1
2
3
4
5
6
7
8
9    Table 2. Basic regression results.
10    Variable                                              Dependent variable: Energy vulnerability
                                                   (1)                          (2)                            (3)




                                                                                                                    w
11
      IRs                                      -0.355***                    -0.522***                      -0.328***
12                                              (-8.185)                     (-8.044)                       (-5.709)
13




                                                                                                                  e
      GDP                                                                    -0.259**                       0.343**
14                                                                           (-2.158)                        (2.347)




                                                                                                     i
15    POP                                                                    -0.067**                         0.023
16                                                                           (-1.969)                        (0.302)
      EMP                                                                     -0.001                          0.239
17




                                                                                                   v
                                                                             (-0.003)                        (0.570)
18    FDI                                                                    0.033***                       0.027**
19                                                                            (3.824)                        (2.466)




                                                                                           e
20    EXR                                                                     -0.134                          0.397
21                                                                           (-0.268)                        (0.926)
      INF                                                                      0.100                         -0.029
22                                                                            (1.383)                       (-0.584)
23    Constant                                 -1.935***                      -0.843                        -2.487*




                                                                  R
24                                            (-103.234)                     (-1.353)                       (-1.943)
25    Country FE                                   ✓                            No                              ✓
26    Time FE                                      ✓                            No                              ✓
      N                                          1,173                         1,173                          1,173
27




                                                                r
      Adj-R2                                     0.337                        0.1304                          0.370
28   Notes: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.
29




                                                 e
30   4.2. Robustness verification procedures
31




                                               e
32   Table 3 summarizes multiple robustness exercises undertaken to assess the reliability of the empirical
33   results under alternative specifications that account for endogeneity, measurement error, temporal
34
     dependence, and outlier effects.
35




                          P
36
37       •   Instrumental variable estimation: Column (1) employs instrumental variable generalized method
38           of moments (IV-GMM) estimation using lagged industrial robotics variables as instruments (Dong




                        r
39
             et al., 2024). This approach addresses potential endogeneity arising from reverse causality or
40
41           omitted variable bias. The first-stage F-statistics (not reported) exceed conventional thresholds for




       o
42           weak instrument concerns. The IV-GMM coefficient maintains negative significance while
43
             showing expected magnitude reduction relative to OLS estimates. This pattern typically emerges
44




     F
45           when OLS suffers from positive endogeneity bias, supporting causal interpretation of the baseline
46           results.
47
         •   Alternative measurement approaches: Column (2) replaces robot stock measures with annual
48
49           installation flows (Lee et al., 2022), capturing technology adoption dynamics rather than
50           cumulative deployment. The alternative coefficient preserves negative significance with larger
51           magnitude, consistent with flow measures capturing immediate adoption effects.
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 14 of 35
1
2
3
4
5
6
7
8
         •       Temporal lag structure: Column (3) employs one-period lagged industrial robotics to address
9
10               contemporaneous correlation concerns and capture delayed adjustment processes. The lagged




                                                                                                                      w
11               coefficient maintains significance, indicating persistent effects of robotics deployment on energy
12
                 vulnerability.
13




                                                                                                                    e
14       •       Outlier treatment: Column (4) applies 1% and 99% winsorization to continuous variables,




                                                                                                      i
15               addressing potential outlier influences on coefficient estimates. The treated variable demonstrates
16               stability relative to baseline results.
17




                                                                                                    v
18   Table 3. Robustness tests.
19                                                     Dependent variable: Energy vulnerability




                                                                                             e
20           Variable                   IV-GMM      Robot installations      Lagged effect      Outlier treatment
21                                          (1)             (2)                   (3)                  (4)
22           IRs                         -0.146*
                                         (-1.796)
23           IRs(robot installations)                   -2.374***




                                                                      R
24                                                       (-8.768)
25           IRs(t-1)                                                          -0.329***
26                                                                              (-6.168)
27           IRs(Outlier treatment)                                                                  -0.489**




                                                                    r
                                                                                                     (-2.496)
28
             GDP                          -0.041          -0.141                0.286**              0.399**
29                                       (-1.046)        (-1.442)                (2.150)              (2.217)




                                                       e
30           POP                        0.024***         -0.238**                 0.020                0.025
31                                        (3.342)        (-2.429)                (0.264)              (0.331)




                                                     e
32           EMP                        1.677***           0.071                  0.282                0.291
33                                       (20.217)         (0.148)                (0.721)              (0.736)
             FDI                        0.084***         0.026***               0.027**              0.028**
34
                                          (4.868)         (3.009)                (2.360)              (2.655)
35




                                 P
             EXR                        1.101***          -0.019                  0.385                0.427
36                                        (6.588)        (-0.039)                (0.879)              (1.055)
37           INF                        0.366***           0.083                 -0.007               -0.032
38                                        (2.621)         (1.628)               (-0.066)             (-0.620)
             Constant                   -3.482***          1.956                -2.459*              -2.558**




                               r
39
                                        (-30.573)         (1.181)               (-1.935)             (-2.038)
40           Country FE                      ✓               ✓                      ✓                    ✓
41           Time FE                         ✓               ✓                      ✓                    ✓




       o
42           N                             1,122           1,020                  1,122                1,140
43           Adj-R2                       0.295            0.133                 0.370                0.370
44   Notes: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                       Page 15 of 35
1
2
3
4
5
6
7
8
     4.3. Mechanism analysis framework
9
10   4.3.1. Green patent channel




                                                                                                              w
11
12   Green technological innovation, as measured by green patent activity, constitutes the primary channel
13




                                                                                                            e
     through which industrial robotics contributes to reducing infrastructure energy vulnerability. First-stage
14




                                                                                                i
15   results (Column 3) reveal a robust positive relationship between industrial robotics and innovation. This
16   exceptionally strong relationship supports the hypothesis that automation technologies catalyze
17




                                                                                              v
     environmental innovation through multiple reinforcing channels. Industrial robotics deployment generates
18
19   substantial technological spillover effects that enhance innovative capacity across economic sectors. The




                                                                                      e
20   integration of energy efficiency considerations into automated manufacturing processes creates learning
21   effects that translate into broader green innovation applications. Additionally, robotics adoption often
22
23   reflects underlying technological orientation and investment capacity that naturally encompasses




                                                              R
24   environmental concerns and sustainability objectives. The coefficient magnitude suggests considerable
25   innovation impacts, where a one-standard-deviation increase in industrial robotics corresponds to
26
     meaningful enhancement in green patent intensity relative to baseline innovation levels. Second-stage
27




                                                            r
28   estimation (Column 4) demonstrates that green patent innovation significantly reduces infrastructure energy
29   vulnerability with a coefficient of -2.346. This substantial relationship reflects the direct contribution of




                                               e
30
     environmental technologies to energy system resilience, efficiency, and adaptive capacity. Green
31




                                             e
32   innovations encompass critical technologies including renewable energy systems, advanced energy storage
33   solutions, smart grid applications, and efficiency improvements that directly address core energy
34
     vulnerability dimensions.
35




                       P
36
37   4.3.2. Industrial structure transformation channel
38
     The industrial structure transformation pathway represents the third significant mediation mechanism in




                     r
39
40   our analysis framework. First-stage results (Column 5) demonstrate that industrial robotics significantly
41   promotes industrial structure advancement with a coefficient of 0.812. This relationship reflects




       o
42
     automation's fundamental role in facilitating economic transition toward higher value-added activities and
43
44   service-oriented economic structures (Chang et al., 2023). Industrial robotics enables substantial




     F
45   manufacturing productivity improvements that release human and capital resources for service sector
46
     development and knowledge-intensive activities. Automation reduces labor requirements in routine
47
48   production tasks, encouraging skill upgrading and the development of innovation-driven economic
49   activities. Additionally, robotics adoption typically accompanies broader technological modernization
50
     processes that support comprehensive structural transformation toward more sophisticated economic
51
52   structures (Xin-gang & Jin, 2022). Second-stage estimation (Column 6) indicates that industrial structure
53
54
55
56
57
58
59
60



                                                                                                                     Page 16 of 35
1
2
3
4
5
6
7
8
     advancement reduces energy vulnerability with a coefficient of -0.155. Advanced industrial structures
9
10   typically demonstrate superior energy efficiency characteristics, reduced resource intensity, and enhanced




                                                                                                                    w
11   adaptation capacity to external economic and environmental shocks. Service-oriented economies generally
12   exhibit lower energy vulnerability through diversified consumption patterns, reduced dependence on
13




                                                                                                                  e
14   energy-intensive manufacturing processes, and enhanced capacity for demand-side energy management




                                                                                                     i
15   strategies.
16
17   Table 4. Mechanism effect tests.




                                                                                                   v
18
                                               Green         Energy             Industrial           Energy
19
              Variable                         patent     vulnerability      transformation       vulnerability




                                                                                             e
20                                               (1)           (2)                  (3)                (4)
21            industrial robotics             0.120***                           0.812***
22                                            (30.454)                            (6.652)
23            Green patent                                   -2.346***




                                                                  R
24                                                            (-4.860)
25            Industrial transformation                                                              -0.155**
26                                                                                                   (-2.510)
27            GDP                              -0.002         0.336**              0.375             0.393***




                                                                r
                                              (-1.026)        (2.313)             (1.352)             (2.780)
28
              POP                              -0.003           0.016            -0.700***            -0.084
29
                                              (-1.533)         (0.204)            (-3.261)           (-0.846)




                                                 e
30            EMP                              -0.015           0.219             -1.523*              0.071
31                                            (-1.624)         (0.512)            (-1.790)            (0.164)




                                               e
32            FDI                             -0.000**        0.027**              -0.008            0.027**
33                                            (-2.172)         (2.390)            (-0.344)            (2.668)
34            EXR                               0.002           0.405              -0.215              0.381
35                                             (0.950)         (0.947)            (-0.571)            (0.984)




                           P
36            INF                               0.001          -0.027              -0.105             -0.047
37                                             (0.826)        (-0.547)            (-0.958)           (-0.893)
              Constant                         0.060*         -2.360*            27.168***             1.671
38
                                               (1.780)        (-1.796)             (6.985)            (0.676)




                         r
39
              Country FE                         ✓               ✓                  ✓                      ✓
40
              Time FE                            ✓               ✓                  ✓                      ✓
41




       o
              N                                1,173           1,173              1,173               1,173
42
              Adj-R2                           0.863           0.368              0.480               0.387
43   Notes: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.
44




     F
45   4.4. Threshold effects
46
47   The analysis in Table 4 shows that industrial robotics lowers energy vulnerability through these channels.
48   The relationship is unlikely to be strictly linear, though — it probably strengthens or weakens depending
49
50   on how effective domestic institutions are. The resilience-enhancing effect of industrial robotics (INR)
51   depends on institutional quality, indicating that governance structures serve as a threshold condition for its
52
53
54
55
56
57
58
59
60



                                                                                                                      Page 17 of 35
1
2
3
4
5
6
7
8
     effectiveness. Drawing on institutional economics theory (Acemoglu et al., 2005), we hypothesize that the
9
10   energy vulnerability aids of industrial robotics materialize differently across distinct phases of institutional




                                                                                                                 w
11   effectiveness. Weak institutional effectiveness—characterized by inadequate regulatory frameworks, poor
12   governance, and limited enforcement capacity—may constrain industrial robotics’ potential to optimize
13




                                                                                                               e
14   energy efficiency (Baldwin, 2016). Contrariwise, countries with moderate institutional effectiveness but




                                                                                                  i
15   insufficient complementary capabilities (e.g., skilled labor, digital infrastructure) may experience
16   implementation challenges before realizing the full energy benefits of automation (Tian et al., 2023; Qiang
17




                                                                                                v
     Wang et al., 2024). Following Hansen (1999), we use threshold regression to locate the point at which the
18
19   relationship between industrial robotics and energy vulnerability changes, conditional on the quality of a




                                                                                        e
20   country's institutions. This approach allows us to determine whether minimum institutional effectiveness
21
     thresholds must be achieved before industrial robotics can reliably reduce energy vulnerability, and whether
22
23   returns to robotics investment accelerate beyond certain institutional effectiveness levels.




                                                                R
24   Our empirical strategy employs Hansen's (1999) bootstrap approach to identify structural breakpoints in
25
     the institutional effectiveness-energy vulnerability relationship. Panel A of Table 5 presents strong evidence
26
27   of a non-linear relationship, with tests confirming the presence of two distinct thresholds while rejecting a




                                                              r
28   third. Overall, the empirical evidence supports a double-threshold specification, indicating that the
29




                                                e
     relationship is characterized by multiple regime shifts rather than a single transition. Panel B of Table 5
30
31   reports the estimated threshold values that define these regimes. The first threshold (γ₁) is identified at




                                              e
32   2.085, marking the critical institutional effectiveness level where the INR-energy vulnerability relationship
33   initially shifts. The second threshold (γ₂) occurs at 2.690, defining a higher institutional effectiveness
34
35   regime.




                        P
36   Figure 3 visually confirms threshold selection using likelihood-ratio (LR) statistics. The pronounced
37   troughs in the graph, falling below the 5% critical value line, confirm the statistical significance of both
38
     thresholds.




                      r
39
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                                        Page 18 of 35
1
2
3
4
5
6
7
8
     Table 5. Threshold effect and value tests.
9
10                                                       Panel A. Threshold effect test




                                                                                                                                            w
11                                                                                                             Critical values
       Threshold variable                    Threshold number                     F-statistic       P-value
12                                                                                                             1%          5%           10 %
13                                           Single                               21.701***         0.000      8.334       8.334        8.334




                                                                                                                                          e
14     Institutional effectiveness           Double                               50.357**          0.000      176.662     97.746       12.286
                                             Triple                               0.000             0.50       0.00        0.00         0.00




                                                                                                                          i
15
16                                                       Panel B. Threshold values test
17     Threshold variable                    Parameter                            Threshold value             95 % confidence interval




                                                                                                                        v
18                                           γ1                                   2.085                          [ 1.760 , 2.892 ]
       Institutional effectiveness           γ2                                   2.690                          [ 2.587 , 2.757 ]
19
                                             γ3                                   2.158                          [ 2.153 , 2.188 ]




                                                                                                               e
20
     Note: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.
21
22
23




                                                                                         R
                                                                                       40
24                    10
25                                                                                     30
      LR statistics




                                                                       LR statistics




26
27




                                                                                       r
                      5                                                                20
28
                                                                                       10
29




                                                           e
30                    0                                                                0
31                         1   1.5       2         2.5         3                                1      1.5      2          2.5      3




                                                         e
32                               First threshold                                                        Second threshold
33
     Figure 3. Threshold effect for institutional effectiveness.
34                                                                                     40
                      10
35




                                 P
     Table 6 reveals three distinct regimes in the industrial robotics-energy vulnerability relationship, contingent
36                                                                                     30
      LR statistics




                                                                       LR statistics




37   on institutional effectiveness. Two critical thresholds (γ₁ ≈ 2.085 and γ₂ ≈ 2.690) delineate low, moderate,
                      5                                                                20
38   and high institutional contexts, demonstrating a non-monotonic relationship where governance structures




                               r
39                                                        10
     fundamentally shape how technology affects energy outcomes (Acemoglu et al., 2005).
40
                      0                                                                0
41




       o
42   Regime 1: 1Low institutional
                     1.5     2    effectiveness
                                   2.5     3    (INST < 2.085)
                                                          1                                            1.5      2          2.5      3
                                 First threshold                                                        Second threshold
43
44   In poorly governed settings, industrial robotics paradoxically increases energy vulnerability, with a




     F
45   coefficient of 3.973. This counterintuitive finding reveals that technical upgrades can misfire without
46   adequate institutional foundations. Weak regulatory frameworks, limited enforcement capacity, and
47
48   insufficient complementary infrastructure create implementation failures where efficiency gains are
49   squandered or even backfire. Factories may deploy energy-inefficient robots or expand output unchecked
50   when oversight mechanisms are absent. Clifford Chance (2021) notes that inadequate regulatory
51
     frameworks lag behind technology advancement, unable to prevent abuse or mitigate market disruptions as
52
53
54
55
56
57
58
59
60



                                                                                                                                                 Page 19 of 35
1
2
3
4
5
6
7
8
     automation is rapidly introduced. Without skilled labor, proper infrastructure coordination, and quality
9
10   governance, automation alone cannot guarantee energy savings. Studies of energy policy consistently




                                                                                                              w
11   emphasize that in weak governance contexts, the impact of efficiency measures is diluted by poor
12   implementation and rebound effects. The positive coefficient underscores that robotics adoption in
13




                                                                                                            e
14   institutionally constrained environments may actually exacerbate energy vulnerabilities rather than alleviate




                                                                                                i
15   them.
16
17
     Regime 2: Moderate institutional effectiveness (2.085 ≤ INST ≤ 2.690)




                                                                                              v
18
19   Countries within this institutional "sweet spot" demonstrate the strongest vulnerability reduction, with a




                                                                                      e
20
21   coefficient of -4.300. Here, governance structures are sufficiently robust to regulate and integrate new
22   technology but not so mature that efficiency gains have plateaued. With competent policy frameworks and
23   complementary capabilities in place, firms can optimize robotics deployment for energy efficiency. This




                                                              R
24
     regime enables effective technology-institution synergy where regulatory oversight ensures energy
25
26   performance standards while supportive policies facilitate skill development, infrastructure coordination,
27




                                                            r
     and strategic energy planning. This finding aligns with empirical evidence that robotics adoption reduces
28
     emissions when properly governed. (Ma et al., 2025; Yongliang Zhang et al., 2025) demonstrate that the
29




                                               e
30   extensive application of industrial robot’s benefits carbon emission reduction through labor substitution
31   and global value-chain upgrading. In moderate-institution countries, similar mechanisms operate as




                                             e
32
     sufficiently robust governance amplifies gains from efficiency measures, ensuring that robotics translate
33
34   into measurable energy savings. The substantial negative coefficient magnitude indicates that countries
35




                       P
     achieving this institutional balance can leverage industrial automation to dramatically reduce energy system
36   vulnerabilities through improved productivity, optimized resource allocation, and enhanced energy-use
37
38   efficiency.




                     r
39
40   Regime 3: High institutional effectiveness (INST > 2.690)
41




       o
42   Surprisingly, highly institutionalized economies exhibit a positive coefficient of 3.808, indicating
43   diminishing or even adverse returns from additional robotics investment. This non-monotonic pattern
44




     F
45   reflects saturation and rebound effects characteristic of advanced economies operating near energy
46   efficiency frontiers. In these contexts, automation and smart manufacturing are already widespread, so
47   marginal robotics additions primarily fuel scale expansion and digital infrastructure demands rather than
48
     generating new efficiency gains. Rebound theory predicts that labor-saving technology can paradoxically
49
50   boost resource consumption. (Ertel & Bonenberger, 2025) highlight that strong rebound effects emerge in
51   high-wage countries as labor-saving automation encourages greater energy use in other economic activities.
52
53
54
55
56
57
58
59
60



                                                                                                                     Page 20 of 35
1
2
3
4
5
6
7
8
     Similarly, (Williams et al., 2022) caution that while individual machines may be efficient, scaled-up digital
9
10   manufacturing entails substantial energy demands for supporting infrastructure—5G networks, data




                                                                                                              w
11   centers, and cloud computing—causing rapid increases in aggregate energy consumption despite
12   component-level efficiency improvements. Additionally, stringent regulatory requirements in highly
13




                                                                                                            e
14   institutionalized environments may create compliance costs and implementation barriers that offset




                                                                                                i
15   efficiency benefits. The positive coefficient suggests that in very advanced economies, additional robotics
16   deployment may strain energy systems rather than reducing vulnerability.
17




                                                                                              v
18
19   Table 6. Estimated results of the threshold effect.




                                                                                      e
20                   Variables                        Dependent variable: EVI
21                                                                      (1)                 (2)
22                                                                       fe           fe-robust
23                                              INST < γ1           3.973***            3.973***




                                                               R
24                                                                    (3.75)              (3.39)
25                                            γ1 ≤ INST ≤ γ2        -4.300***          -4.300***
                     IRs
26                                                                    (-4.05)            (-3.66)
27                                              INST > γ2           3.808***            3.808***




                                                             r
28                                                                    (3.47)              (3.24)
29                   INCOM                                          0.329***            0.329***




                                               e
                                                                      (6.03)              (4.85)
30
                     POP                                             0.0168             0.0168
31
                                                                      (0.55)              (0.69)




                                             e
32
                     EMP                                             0.245**             0.245*
33                                                                    (2.14)              (1.67)
34                   FDI                                            0.0286**           0.0286***
35




                       P
                                                                      (2.10)              (3.40)
36                   EXR                                            0.387***            0.387***
37                                                                    (3.11)              (3.21)
38                   INF                                             -0.0309            -0.0309




                     r
39                                                                    (-0.74)            (-1.30)
40                   Constant                                       -2.504***          -2.504***
41                                                                    (-4.94)            (-6.21)




       o
42                 Country FE                                              YES           YES
43                 Time FE                                                 YES           YES
44                 N                                                       1173          1173
                   Adj-R2




     F
                                                                       0.921             0.921
45
     Note: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.
46
47
     These threshold effects underscore the critical nonlinear link between technology and governance. Effective
48
49   institutions are necessary to unlock the energy-saving potential of robotics, but beyond a certain maturity
50   level, additional gains taper off or reverse. The findings carry distinct implications for different country
51   contexts. Nations below the first threshold must prioritize strengthening regulatory frameworks, workforce
52
53
54
55
56
57
58
59
60



                                                                                                                     Page 21 of 35
1
2
3
4
5
6
7
8
     training, and infrastructure coordination before aggressive robotics promotion to avoid counterproductive
9
10   outcomes. Middle-range economies should capitalize on their institutional maturity to accelerate energy-




                                                                                                                 w
11   lean automation deployment. Advanced economies should implement policies to mitigate rebound
12   effects—such as energy taxation or enhanced efficiency standards—as they expand robotics adoption
13




                                                                                                               e
14   further. Overall, our global panel findings echo the institutional economics literature: governance structures




                                                                                                  i
15   fundamentally shape how technology affects resource use, creating distinct phases where robotics can either
16   enhance or undermine energy resilience.
17




                                                                                                v
18
     4.5. Spatial spillover effects
19




                                                                                        e
20
     Japan is the region's dominant force in industrial robotics, which raises an obvious question: does proximity
21
22   to Japan shape how automation affects energy vulnerability elsewhere? To test this, we split the sample
23   into countries close to Japan and countries far from it, then re-estimated the INR–energy vulnerability




                                                                R
24   relationship for each group separately (Table 7). The two groups diverge sharply. For distant countries, the
25
26   IRs coefficient is negative but not statistically significant — robotics adoption doesn't reliably move the
27   needle on energy vulnerability when a country sits far from Japan. For countries near Japan, the coefficient




                                                              r
28   is negative and highly significant: robotics diffusion consistently reduces energy vulnerability in this group.
29




                                                e
     This split fits standard accounts of technology diffusion. Economies near Japan — South Korea, China,
30
31   Singapore, Thailand, Malaysia — sit inside dense trade and supply-chain networks that give them faster,




                                              e
32   cheaper access to frontier robotics technology (OECD, 2013). That proximity also supports closer
33
     collaboration between firms, universities, and government bodies, which keeps knowledge moving between
34
35   them. It extends to people too: engineers, researchers, and technicians move more easily across these




                        P
36   markets, bringing the tacit, hands-on knowledge that robotics implementation actually depends on (Brey &
37
     van der Marel, 2024). Shared regulatory environments and compatible industrial standards add to this
38




                      r
39   advantage — adoption doesn't require reinventing institutional arrangements from scratch. Nearby
40   countries also reach technological upgrades sooner, and they sit inside a regional ecosystem of suppliers
41




       o
     and maintenance providers that keeps robotics systems running effectively over time. Taken together, this
42
43   is why the coefficient for nearby countries comes out both negative and significant: the conditions for
44   converting robotics investment into energy gains are largely already in place. Distant countries face the




     F
45   opposite set of constraints. Acquiring advanced robotics systems costs more; technical expertise and
46
     support are harder to reach; direct collaboration is rarer; and imported technology doesn't always match
47
48   local energy infrastructure or regulatory conditions. The insignificant coefficient for this group reflects that
49   mismatch — without the supporting infrastructure, institutional capacity, and transfer mechanisms that
50
     proximity provides, robotics adoption doesn't translate into a dependable reduction in energy vulnerability.
51
52
53
54
55
56
57
58
59
60



                                                                                                                        Page 22 of 35
1
2
3
4
5
6
7
8
     Table 7. Spatial spillover effect results.
9
10                       Variable                                 Dependent variable: EVI
                                                                (1)                       (2)




                                                                                                             w
11
                                                         Far from Japan           Close to Japan
12                       IRS                                  -0.202                  -0.150***
13




                                                                                                           e
                                                             (-1.310)                  (-3.298)
14                       INCOME                              0.280***                    0.051




                                                                                                     i
15                                                            (3.764)                   (0.334)
16                       POP                                   0.027                  1.182***
17                                                            (1.080)                   (3.413)




                                                                                                   v
                         EMP                                   0.244                    -0.113
18
                                                              (1.636)                  (-0.188)
19
                         FDI                                 0.031***                    0.179




                                                                                           e
20                                                            (3.776)                   (0.695)
21                       EXR                                 0.631***                -10.407***
22                                                           (11.277)                 (-10.683)
23                       INF                                 -0.062**                 1.818***




                                                                  R
24                                                           (-2.357)                   (3.829)
25                       Constant                           -2.699***                -23.087***
                                                             (-6.657)                  (-3.831)
26
                         Country FE                              ✓                         ✓
27




                                                                r
                         Time FE                                 ✓                         ✓
28                       N                                     1,035                      138
29                       Adj-R2                                0.933                     0.958




                                                 e
30   Notes: The symbols ***, *, and * indicate significance at the 1%, 5%, and 10% levels, respectively.
31




                                               e
32   4.6. Heterogeneity Analysis
33
34   This section examines how the impact of industrial robotics on energy vulnerability varies across
35




                        P
     development levels, digital infrastructure, and population scales.
36
37   Figure 4 reveals distinct variations based on income classification. Notably, Middle-Income
38   economies exhibit the most substantial reduction in energy vulnerability from industrial robotics.




                      r
39
40   This suggests that emerging economies, often in the midst of rapid industrialization, derive the
41   highest marginal energy efficiency gains from automation. Low-Income economies also




       o
42
     demonstrate a significant, albeit smaller, negative impact, indicating that robotics can aid in
43
44   "leapfrogging" energy constraints despite resource limitations. Conversely, High-Income




     F
45   economies show a statistically insignificant relationship. This suggests a saturation effect;
46
47   advanced economies may have already optimized their energy baselines, leaving less room for
48   marginal improvements through additional robotics adoption compared to developing nations
49
50   (Fatima et al., 2021; Yang Liu et al., 2023).
51
52
53
54
55
56
57
58
59
60



                                                                                                            Page 23 of 35
1
2
3
4
5
6
7
8
     The results also highlight the prerequisite role of digital readiness. As shown in Figure 4, countries
9
10   with more advanced digital infrastructure exhibit significantly lower levels of energy vulnerability.




                                                                                                       w
11   This confirms that robust digital ecosystems facilitate the precise monitoring and integration
12
13   required to translate robotics into reliable energy efficiency. Conversely, the effect observed for




                                                                                                     e
14   countries with relatively weak digital infrastructure is negative but fails to attain statistical




                                                                                          i
15
16   significance. This implies that while the potential impact of robotics in these regions is high, the
17   absence of supporting digital networks makes the energy benefits inconsistent. Thus, digital




                                                                                        v
18
     maturity appears to be a necessary condition for realizing the stable energy benefits of industrial
19




                                                                                 e
20   automation.
21   Furthermore, the analysis investigates the influence of demographic scale. Figure 4 reveals a
22
23   striking disparity: Low-Population countries demonstrate the strongest impact in the entire model,




                                                           R
24   with a massive and highly significant coefficient of -3.163. This suggests that in smaller
25
26   economies—where labor may be scarcer or industrial sectors more concentrated—the introduction
27




                                                         r
     of robotics yields transformative improvements in energy vulnerability. Conversely, High-
28
     Population countries show a statistically insignificant relationship. In these populous nations, the
29




                                            e
30   energy efficiency gains from robotics may be diluted by the sheer scale of energy demand or offset
31   by the continued reliance on labor-intensive, less energy-efficient practices. This indicates that




                                          e
32
33   demographic scale acts as a critical moderator, where the relative benefits of automation on energy
34   security are far more pronounced in smaller, more agile economies.
35




                      P
36
37
38




                    r
39
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                              Page 24 of 35
1
2
3
4
5
6
7
8
9
         Small Population
10




                                                                                                                           w
11
12       Large Population
13




                                                                                                                         e
14




                                                                                                           i
15         Limited Digital
16
17




                                                                                                         v
18      Advanced Digital
19




                                                                                                e
20
      Lower-Mid Income
21
22
23




                                                                      R
      Upper-Mid Income
24
25
26           High Income
27




                                                                    r
28
29                        0




                                                    e
30
                                       -4                              -2                                     0
31
                                                              Coefficients (Robot)




                                                  e
32
33                                             Figure 4. Heterogeneity analysis
34
35   Note: This forest plot illustrates the heterogeneous effects of industrial robotics on energy vulnerability partitioned




                         P
36   by income level, digital infrastructure, and population size. The square markers represent the point estimates of the
     coefficients, while the horizontal lines indicate the 95% confidence intervals. The vertical red line denotes the zero-
37   effect threshold. All estimations include a full set of control variables alongside relevant fixed effects. Standard errors
38   are robust or clustered where appropriate.




                       r
39
40   5. Conclusions and policy recommendations
41




       o
42            The spread of industrial robotics has raised important questions about its implications not
43   only for labor markets but also for the resilience of national energy systems. In this paper, we
44




     F
45   investigate the relationship between industrial robotics and energy vulnerability across 51
46   countries during 2000–2022. Our empirical strategy combines two-way fixed effects estimation
47
     with instrumental variable methods, mediation analysis, threshold regression, and spatial
48
49   heterogeneity tests. The approach enables us to move beyond simple correlations and examine
50   both the mechanisms through which automation affects energy outcomes and the conditions under
51
52   which these effects materialize.
53
54
55
56
57
58
59
60



                                                                                                                                   Page 25 of 35
1
2
3
4
5
6
7
8
             We report five principal findings. First, industrial robotics significantly reduces energy
9
10   vulnerability; this result survives a battery of robustness checks including IV-GMM estimation,




                                                                                                     w
11   alternative robot measures, temporal lag structures, and outlier treatment. Second, mechanism
12
13   analysis identifies two distinct transmission channels. Green patent innovation emerges as the




                                                                                                   e
14   dominant pathway, accounting for approximately 80 percent of the total effect: robotics




                                                                                        i
15
16   deployment generates technological spillovers that enhance environmental innovation capacity,
17   and these innovations—encompassing renewable energy systems, energy storage solutions, and




                                                                                      v
18
     smart grid technologies—directly address core vulnerability dimensions. Industrial structure
19




                                                                               e
20   upgrading constitutes the second channel, accounting for roughly 34 percent of the total effect, as
21   automation facilitates the transition toward less energy-intensive, higher-value-added economic
22
23   activities.




                                                          R
24
25           Third, and perhaps most consequentially for policy design, threshold regression reveals a
26   non-monotonic relationship contingent on institutional effectiveness. Below the first threshold (γ1
27




                                                        r
     ≈ 2.085), robotics modestly increases energy vulnerability—a finding consistent with the
28
29   proposition that weak governance capacity, inadequate regulatory frameworks, and insufficient




                                           e
30   complementary infrastructure generate implementation failures that dissipate or reverse potential
31
     efficiency gains. Within the intermediate regime (2.085 ≤ INST ≤ 2.690), robotics yields the largest




                                         e
32
33   vulnerability reductions, suggesting that this institutional range optimally balances regulatory
34
35   capacity with flexibility. Above the second threshold (γ2 ≈ 2.690), the coefficient turns positive,




                      P
36   consistent with saturation and rebound effects in advanced economies where automation and smart
37
     manufacturing are already widespread and marginal robotics additions primarily fuel scale
38




                    r
39   expansion and digital infrastructure demands rather than generating new efficiency gains. This
40   non-monotonic pattern underscores that the energy dividends of automation are fundamentally
41




       o
42   conditioned by the institutional environment—a result that resonates with the broader institutional
43   economics literature on the contingent nature of technology’s effects (Acemoglu et al., 2005).
44




     F
45           Fourth, our results indicate that the energy gains associated with robotics adoption vary
46
     considerably by location, rather than being spread evenly across regions. Countries in closer
47
48   proximity to Japan—the world’s leading robotics innovation hub—experience significantly larger
49   vulnerability reductions, while the coefficient for geographically distant countries is negative but
50
51   statistically insignificant. This spatial pattern is consistent with technology diffusion theories:
52   proximity facilitates access to frontier technologies through trade networks and integrated supply
53
54
55
56
57
58
59
60



                                                                                                            Page 26 of 35
1
2
3
4
5
6
7
8
     chains, enables knowledge exchange through bilateral collaboration and human capital mobility,
9
10   and supports long-term technology effectiveness through dense supplier relationships and




                                                                                                     w
11   technical support services. Fifth, heterogeneity analysis reveals that the mitigating effects of
12
13   robotics are significantly stronger in middle-income countries (where marginal energy efficiency




                                                                                                   e
14   gains from automation are largest), in economies with advanced digital infrastructure (a necessary




                                                                                        i
15
16   condition for translating robotics into reliable energy efficiency), and in smaller economies (where
17   the relative impact of automation on concentrated industrial sectors is more pronounced).




                                                                                      v
18
19          These results carry several implications for policy. Countries with weak institutional




                                                                               e
20   frameworks should prioritize governance reform—including regulatory modernization, workforce
21
22   training, and infrastructure coordination—before pursuing aggressive robotics promotion, since
23   our estimates suggest that automation in institutionally constrained environments may exacerbate




                                                          R
24
25   rather than alleviate energy vulnerabilities. Countries operating within the intermediate
26   institutional range are best positioned to capitalize on the energy dividends of robotics and should
27




                                                        r
     accelerate adoption while maintaining institutional flexibility. Advanced economies, where
28
29   rebound effects appear to offset efficiency gains at the margin, should consider complementary




                                           e
30   policies—such as energy taxation or enhanced efficiency standards—to ensure that further robotics
31
     deployment does not strain energy systems. The spatial concentration of benefits around




                                         e
32
33   innovation hubs underscores the importance of international cooperation, technology transfer
34
35   agreements, and regional integration initiatives in extending the energy resilience gains of




                      P
36   automation beyond the geographic core.
37
38          Several caveats deserve emphasis. Our analysis operates at the national level and may




                    r
39   obscure important subnational variation in how robotics adoption interacts with local energy
40
41   systems and industrial structures. The mediation analysis follows a two-stage approach that, while




       o
42   standard, does not fully resolve all identification concerns regarding the indirect effects. The
43
44   spatial analysis, based on distance-based sample splits rather than formal spatial econometric




     F
45   models, provides suggestive rather than definitive evidence on spillover mechanisms. Future
46
     research employing regional or firm-level data, formal spatial Durbin models, and more granular
47
48   energy disaggregation—distinguishing between fossil fuel and renewable energy contexts—would
49   strengthen and extend the present findings.
50
51
52
53
54
55
56
57
58
59
60



                                                                                                            Page 27 of 35
1
2
3
4
5
6
7
8
             We view this paper as contributing to a broader research agenda on the energy system
9
10   consequences of physical automation technologies. Whether the next wave of advances in robotics,




                                                                                                                       w
11   artificial intelligence, and industrial automation will strengthen or strain energy infrastructure is
12
13   an open question whose answer depends critically on institutional design, innovation policy, and




                                                                                                                     e
14   international coordination. The evidence presented here suggests that industrial robotics holds




                                                                                                        i
15
16   substantial promise for reducing energy vulnerability—but that realizing this promise requires
17   getting the institutional and policy conditions right.




                                                                                                      v
18
19   Appendix




                                                                                              e
20
21   Table A1. Countries Included in the Sample (2000–2022)
22
23             #      Country            #      Country                 #      Country




                                                                   R
24             1      Argentina          18     Hungary                 35     Peru
25
               2      Australia          19     Iceland                 36     Philippines
26
27             3      Austria            20     Indonesia               37     Poland




                                                                 r
28             4      Belarus            21     Iran                    38     Portugal
29




                                                  e
               5      Belgium            22     Ireland                 39     Russia
30
31             6      Brazil             23     Japan                   40     Saudi Arabia




                                                e
32             7      Canada             24     Kuwait                  41     Singapore
33
               8      Chile              25     Latvia                  42     Slovenia
34
35             9      China              26     Lithuania               43     Spain




                        P
36             10     Colombia           27     Malaysia                44     Sweden
37             11     Croatia            28     Malta                   45     Thailand
38




                      r
39             12     Denmark            29     Mexico                  46     Tunisia
40             13     Egypt              30     Morocco                 47     Turkey
41




       o
               14     Estonia            31     Netherlands             48     Ukraine
42
               15     Finland            32     New Zealand             49     United Kingdom
43
44             16     Germany            33     Oman                    50     United Arab Emirates




     F
45             17     Greece             34     Pakistan                51     Uzbekistan
46
47
     References
48
49   Abdullayev, Vugar, Faizal, Ajesh, Seyidova, Irada, Mikayilov, Seymur, Mammadova, Rubaba, Pirverdiyeva, Lala,
50
          & Guliyev, Etibar. (2025). Integration of Artificial Intelligence and Robotics into the industrial sector. Data
51
52        and Metadata, 4, 209. https://doi.org/10.56294/dm2025209
53
54
55
56
57
58
59
60



                                                                                                                            Page 28 of 35
1
2
3
4
5
6
7
8    Acemoglu, Daron, Johnson, Simon, & Robinson, James A. (2005). Chapter 6 Institutions as a Fundamental Cause of
9
           Long-Run Growth. In Handbook of Economic Growth (Vol. 1, Issue SUPPL. PART A, pp. 385–472).
10




                                                                                                                           w
11         Elsevier. https://doi.org/10.1016/S1574-0684(05)01006-3
12   Acemoglu, Daron, & Restrepo, Pascual. (2020). Robots and jobs: Evidence from us labor markets. Journal of
13




                                                                                                                         e
           Political Economy, 128(6), 2188–2244. https://doi.org/10.1086/705716
14




                                                                                                         i
15   Akadiri, Seyi Saint, & Özkan, Oktay. (2025). Energy Markets, Geopolitical Risks, and Global Trade: A High‐Stakes
16         Tug of War. Geological Journal. https://doi.org/10.1002/gj.70026
17




                                                                                                       v
18   Antonioli, Davide, Marzucchi, Alberto, Rentocchini, Francesco, & Vannuccini, Simone. (2024). Robot adoption and
19         product innovation. Research Policy, 53(6), 105002. https://doi.org/10.1016/j.respol.2024.105002




                                                                                              e
20
     Badareu, Gabriela, Doran, Marius D., Firu, Mihai A., Croitoru, Ionuț M., & Doran, Nicoleta M. (2024). Exploring
21
22         the Role of Robots and Artificial Intelligence in Advancing Renewable Energy Consumption. In Energies
23         (Vol. 17, Issue 17, p. 4474). https://doi.org/10.3390/en17174474




                                                                    R
24   Baldwin, Richard. (2016). The Great Convergence. Harvard University Press. https://doi.org/10.2307/j.ctv24w655w
25
26   Banad, Yaser M., Sharif, Sarah S., & Rezaei, Zahra. (2025). Artificial intelligence and machine learning for smart
27




                                                                  r
           grids: from foundational paradigms to emerging technologies with digital twin and large language model-
28         driven intelligence. Energy Conversion and Management: X, 28, 101329.
29




                                                   e
           https://doi.org/10.1016/j.ecmx.2025.101329
30
31   Bergougui, Brahim. (2024a). Algeria’s pathway to COP28 and SDGs: Asymmetric impact of environmental




                                                 e
32         technology, energy productivity, and material resource efficiency on environmental sustainability. Energy
33         Strategy Reviews, 55, 101541. https://doi.org/10.1016/j.esr.2024.101541
34
35




                         P
     Bergougui, Brahim. (2024b). Investigating the relationships among green technologies, financial development and
36         ecological footprint levels in Algeria: Evidence from a novel Fourier ARDL approach. Sustainable Cities and
37         Society, 112, 105621. https://doi.org/10.1016/j.scs.2024.105621
38




                       r
39   Bergougui, Brahim. (2025a). Can artificial intelligence mitigate environmental inequality? Evidence from leading
40         robotic-driven economies using quantile-based methods. Borsa Istanbul Review.
41         https://doi.org/10.1016/j.bir.2025.07.012




       o
42
43   Bergougui, Brahim. (2025b). Can Artificial Intelligence Technologies Advance Environmental Sustainability? The
44         Role of Institutional Adaptability and Skill‐Biased Technological Transformation. Sustainable Development,




     F
45         n/a(n/a). https://doi.org/10.1002/sd.70296
46
47   Bergougui, Brahim. (2025c). Industrial robots for a sustainable future: Uncovering the asymmetric effects of AI on
48         ecological quality in G7 economies. Technology in Society, 83, 103021.
49         https://doi.org/10.1016/j.techsoc.2025.103021
50
     Bergougui, Brahim. (2025d). Institutional adaptability, skill-bias technological shifts, and energy efficiency in
51
52         global decarbonization pathways: Exploring the role of artificial intelligence patents. Technology in Society,
53
54
55
56
57
58
59
60



                                                                                                                            Page 29 of 35
1
2
3
4
5
6
7
8          83, 103029. https://doi.org/10.1016/j.techsoc.2025.103029
9
10   Bergougui, Brahim, & Aldawsari, Mohammed Ibrahim. (2024). Asymmetric impact of patents on green




                                                                                                                     w
11         technologies on Algeria’s Ecological Future. Journal of Environmental Management, 355, 120426.
12         https://doi.org/10.1016/j.jenvman.2024.120426
13




                                                                                                                   e
14   Bergougui, Brahim, Doğan, Buhari, Ghosh, Sudeshna, & Ayad, Hicham. (2024). Impact of environmental




                                                                                                      i
15         technology, economic complexity, and geopolitical risk on carbon emission inequality in developed and
16         developing countries: evidence from a PVAR-GMM approach. Environment, Development and Sustainability.
17




                                                                                                    v
           https://doi.org/10.1007/s10668-024-05715-x
18
19   Brás, T. Armada, Simoes, S. G., Amorim, F., & Fortes, P. (2023). How much extreme weather events have affected




                                                                                            e
20         European power generation in the past three decades? Renewable and Sustainable Energy Reviews, 183,
21         113494. https://doi.org/10.1016/j.rser.2023.113494
22
23   Brey, Björn, & van der Marel, Erik. (2024). The role of human-capital in artificial intelligence adoption. Economics




                                                                   R
24         Letters, 244, 111949. https://doi.org/10.1016/j.econlet.2024.111949
25
     Buliesibaike, Kalixia, Zhao, Yuhuan, & Wang, Jiayang. (2025). The Impact of Industrial Robots on Energy
26
27         Efficiency: Evidence from Chinese Cities. Energies, 18(21), 5669. https://doi.org/10.3390/en18215669




                                                                 r
28   Chang, Hong, Ding, Qingyi, Zhao, Wanzheng, Hou, Na, & Liu, Wenwen. (2023). The digital economy, industrial
29




                                                  e
           structure upgrading, and carbon emission intensity —— empirical evidence from China’s provinces. Energy
30
31         Strategy Reviews, 50, 101218. https://doi.org/10.1016/j.esr.2023.101218




                                                e
32   Chao, Shujun, Wang, Shanyong, Li, Haidong, & Yang, Shu. (2023). The power of culture: Does Confucian culture
33         contribute to corporate environmental information disclosure? Corporate Social Responsibility and
34
           Environmental Management, 30(5), 2435–2456. https://doi.org/10.1002/CSR.2495
35




                        P
36   Della Valle, N., Maduta, C., D’Agostino, D., & Koukoufikis, G. (2025). Unpacking energy vulnerability in the
37         European Union: Linking thermal discomfort with adaptive capacity. Energy Research & Social Science, 129,
38
           104376. https://doi.org/10.1016/j.erss.2025.104376




                      r
39
40   Deng, Yating, Zou, Yueqing, & Guang, Fengtao. (2025). Unveiling the energy efficiency paradox: Industrial
41         automation and energy rebound in China. Energy, 328, 136482. https://doi.org/10.1016/j.energy.2025.136482




       o
42
43   Dharfizi, Awang Dzul-Hashriq. (2018). The Energy Sector and the Internet of Things – Sustainable Consumption
44         and Enhanced Security through Industrial Revolution 4.0. Journal International Studies, 14.




     F
45         https://doi.org/10.32890/jis2018.14.7
46
47   Dong, Kangyin, Dong, Xiucheng, Jiang, Qingzhe, & Zhao, Jun. (2021). Assessing energy resilience and its
48         greenhouse effect: A global perspective. Energy Economics, 104. https://doi.org/10.1016/j.eneco.2021.105659
49
     Dong, Kangyin, Liu, Yang, Wang, Jianda, & Dong, Xiucheng. (2024). Is the digital economy an effective tool for
50
           decreasing energy vulnerability? A global case. Ecological Economics, 216, 108028.
51
52         https://doi.org/10.1016/j.ecolecon.2023.108028
53
54
55
56
57
58
59
60



                                                                                                                            Page 30 of 35
1
2
3
4
5
6
7
8    Ertel, Wolfgang, & Bonenberger, Christopher. (2025). Rebound Effects Caused by Artificial Intelligence and
9
           Automation in Private Life and Industry. Sustainability, 17(5), 1988. https://doi.org/10.3390/su17051988
10




                                                                                                                       w
11   Fatima, Tehreem, Shahzad, Umer, & Cui, Lianbiao. (2021). Renewable and nonrenewable energy consumption,
12         trade and CO2 emissions in high emitter countries: does the income level matter? Journal of Environmental
13




                                                                                                                     e
           Planning and Management, 64(7), 1227–1251. https://doi.org/10.1080/09640568.2020.1816532
14




                                                                                                       i
15   Filippucci, Francesco, Gal, Peter, & Jona Lasinio, Cecilia Susanna. (2024). The impact of Artificial Intelligence on
16         productivity, distribution and growth.
17




                                                                                                     v
18   Gao, Lan, & Wang, Jing. (2025). Can artificial intelligence reduce energy vulnerability? Evidence from an
19         international perspective. Energy Economics, 145, 108491. https://doi.org/10.1016/j.eneco.2025.108491




                                                                                             e
20
     Gatto, Andrea, & Busato, Francesco. (2020). Energy vulnerability around the world: The global energy vulnerability
21
22         index (GEVI). Journal of Cleaner Production, 253, 118691. https://doi.org/10.1016/j.jclepro.2019.118691
23   Gatto, Andrea, & Drago, Carlo. (2020). Measuring and modeling energy resilience. Ecological Economics, 172.




                                                                   R
24         https://doi.org/10.1016/j.ecolecon.2019.106527
25
26   Graetz, Georg, & Michaels, Guy. (2018). Robots at Work. The Review of Economics and Statistics, 100(5), 753–
27




                                                                 r
           768. https://doi.org/10.1162/rest_a_00754
28
     Hansen, Bruce E. (1999). Threshold effects in non-dynamic panels: Estimation, testing, and inference. Journal of
29




                                                  e
30         Econometrics, 93(2), 345–368. https://doi.org/10.1016/S0304-4076(99)00025-1
31   Huang, Geng, He, Ling‐Yun, & Lin, Xi. (2022). Robot adoption and energy performance: Evidence from Chinese




                                                e
32
           industrial firms. Energy Economics, 107, 105837. https://doi.org/10.1016/j.eneco.2022.105837
33
34   Iqbal, Jamshed, Al-Zahrani, Ali, Alharbi, Soltan Abed, & Hashmi, Anas. (2019). Robotics Inspired Renewable
35




                         P
           Energy Developments: Prospective Opportunities and Challenges. IEEE Access, 7, 174898–174923.
36
           https://doi.org/10.1109/ACCESS.2019.2957013
37
38   Jung, Sangjin, Kara, Levent Burak, Nie, Zhenguo, Simpson, Timothy W., & Whitefoot, Kate S. (2023). Is Additive




                       r
39         Manufacturing an Environmentally and Economically Preferred Alternative for Mass Production?
40         Environmental Science & Technology, 57(16), 6373–6386. https://doi.org/10.1021/acs.est.2c04927
41




       o
42   Kajoskoski, Tuija, Matschoss, Kaisa, Heiskanen, Eva, & Laakso, Senja. (2025). Recent developments in the energy
43         poverty and vulnerability research in Europe: a systematic literature review. Energy Strategy Reviews, 61,
44         101855. https://doi.org/10.1016/j.esr.2025.101855




     F
45
46   Kaufmann, Daniel, Kraay, Aart, & Mastruzzi, Massimo. (2011). The worldwide governance indicators:
47         Methodology and analytical issues1. Hague Journal on the Rule of Law, 3(2), 220–246.
48
     Kuzemko, Caroline, Blondeel, Mathieu, Dupont, Claire, & Brisbois, Marie Claire. (2022). Russia’s war on Ukraine,
49
50         European energy policy responses &amp; implications for sustainable transformations. Energy Research &
51         Social Science, 93, 102842. https://doi.org/10.1016/j.erss.2022.102842
52
53
54
55
56
57
58
59
60



                                                                                                                            Page 31 of 35
1
2
3
4
5
6
7
8    Lee, Chien-Chiang Chiang, Qin, Shuai, & Li, Yaya. (2022). Does industrial robot application promote green
9
           technology innovation in the manufacturing industry? Technological Forecasting and Social Change, 183,
10




                                                                                                                      w
11         121893. https://doi.org/10.1016/j.techfore.2022.121893
12   Leigh, Nancey Green, Lee, Heonyeong, & Kraft, Benjamin. (2022). Disparities in robot adoption among U.S.
13




                                                                                                                    e
           manufacturers: a critical economic development challenge. Industry and Innovation, 29(9), 1025–1044.
14




                                                                                                         i
15         https://doi.org/10.1080/13662716.2021.2007757
16   Li, Ge, & Wang, Xiaoyu. (2024). Energy quota trading policy and energy efficiency: The role of government
17




                                                                                                       v
           supervision and public participation. Technological Forecasting and Social Change, 206.
18
           https://doi.org/10.1016/j.techfore.2024.123565
19




                                                                                              e
20   Li, Wei, Fan, Zhen, & Yao, Di. (2025). The impact of industrial robot on green total factor energy efficiency under
21         the “resource curse” perspective: Evidence from cities in China. Journal of Environmental Management, 385,
22
           125641. https://doi.org/10.1016/j.jenvman.2025.125641
23




                                                                    R
24   Lieth, Jonas, Abel, Dennis, & Jünger, Stefan. (2025). Between national trends and local realities: Spatializing energy
25         vulnerability in 16 EU countries. Energy Policy, 206, 114695. https://doi.org/10.1016/j.enpol.2025.114695
26
27   Liu, Liang, Yang, Kun, Fujii, Hidemichi, & Liu, Jun. (2021). Artificial intelligence and energy intensity in China’s




                                                                  r
28         industrial sector: Effect and transmission channel. Economic Analysis and Policy, 70, 276–293.
29         https://doi.org/10.1016/j.eap.2021.03.002




                                                   e
30
31   Liu, Xiaoqian, Cifuentes-Faura, Javier, Yang, Xiaodong, & Pan, Junyu. (2025). The green innovation effect of




                                                 e
32         industrial robot applications: Evidence from Chinese manufacturing companies. Technological Forecasting
33         and Social Change, 210, 123904. https://doi.org/10.1016/j.techfore.2024.123904
34
     Liu, Yang, Dong, Kangyin, & Jiang, Qingzhe. (2023). Assessing energy vulnerability and its impact on carbon
35




                         P
36         emissions: A global case. Energy Economics, 119. https://doi.org/10.1016/j.eneco.2023.106557
37   Ma, Yu, Ma, Yongqi, & Ding, Zijun. (2025). Can industrial robots boost carbon total factor productivity? –
38
           Evidence from China. Journal of Innovation & Knowledge, 10(6), 100857.




                       r
39
40         https://doi.org/10.1016/j.jik.2025.100857
41   Mitchell, Daniel, Blanche, Jamie, Harper, Sam, Lim, Theodore, Gupta, Ranjeetkumar, Zaki, Osama, Tang,




       o
42
           Wenshuo, Robu, Valentin, Watson, Simon, & Flynn, David. (2022). A review: Challenges and opportunities
43
           for artificial intelligence and robotics in the offshore wind sector. Energy and AI, 8, 100146.
44




     F
45         https://doi.org/10.1016/j.egyai.2022.100146
46   Mohamed, Nader, Al-Jaroodi, Jameela, & Lazarova-Molnar, Sanja. (2019). Leveraging the Capabilities of Industry
47
           4.0 for Improving Energy Efficiency in Smart Factories. IEEE Access, 7, 18008–18020.
48
49         https://doi.org/10.1109/ACCESS.2019.2897045
50   Notteboom, Theo, Haralambides, Hercules, & Cullinane, Kevin. (2024). The Red Sea Crisis: ramifications for vessel
51
           operations, shipping networks, and maritime supply chains. Maritime Economics & Logistics, 26(1), 1–20.
52
53
54
55
56
57
58
59
60



                                                                                                                              Page 32 of 35
1
2
3
4
5
6
7
8         https://doi.org/10.1057/s41278-024-00287-z
9
10   OECD. (2013). Innovation in Southeast Asia. OECD Reviews of Innovation Policy.




                                                                                                                      w
11        https://doi.org/10.1787/9789264128712-en
12
     Răileanu, Silviu, Borangiu, Theodor, Lențoiu, Ionuț, & Constantinescu, Mihnea. (2024). Optimizing Energy
13




                                                                                                                    e
14        Consumption of Industrial Robots with Model-Based Layout Design. Sustainability, 16(3), 1053.




                                                                                                      i
15        https://doi.org/10.3390/su16031053
16
     Song, Yuegang, Wang, Ziqi, Song, Changqing, Wang, Jianhua, & Liu, Rong. (2024). Impact of artificial intelligence
17




                                                                                                    v
18        on renewable energy supply chain vulnerability: Evidence from 61 countries. Energy Economics, 131,
19        107357. https://doi.org/10.1016/j.eneco.2024.107357




                                                                                            e
20
     Soori, Mohsen, Arezoo, Behrooz, & Dastres, Roza. (2023). Optimization of energy consumption in industrial robots,
21
22        a review. Cognitive Robotics, 3, 142–157. https://doi.org/10.1016/j.cogr.2023.05.003
23   Tian, Hongna, Zhao, Liyan, Yunfang, Li, & Wang, Wei. (2023). Can enterprise green technology innovation




                                                                   R
24        performance achieve “corner overtaking” by using artificial intelligence?—Evidence from Chinese
25
          manufacturing enterprises. Technological Forecasting and Social Change, 194.
26
27




                                                                 r
     Umar, Muhammad, Horobet, Alexandra, Negreanu, Cristina Carmencita, Belascu, Lucian, & Mirza, Nawazish.
28        (2025). Fintech adoption, AI development, and energy transition dynamics. Energy Economics, 151, 108905.
29




                                                  e
          https://doi.org/10.1016/j.eneco.2025.108905
30
31   V. Boivin, David, Boiral, Olivier, & Yuriev, Alexander. (2025). Can you really not see this black swan coming?




                                                e
32        Managing climate risks in an insurance company. Journal of Cleaner Production, 519, 145913.
33        https://doi.org/10.1016/j.jclepro.2025.145913
34
35   Vasilescu, Laura, Sichigea, Mirela, Sitnikov, Cătălina, & Mihai, Laurențiu-Stelian. (2025). Nexus Between




                        P
36        Artificial Intelligence, Renewable Energy, and Economic Development: A Multi-Method Approach. In
37        Economies (Vol. 13, Issue 9, p. 271). https://doi.org/10.3390/economies13090271
38




                      r
39   Villagrossi, Enrico, & Dinon, Tito. (2023). Robotics for electric vehicles battery packs disassembly towards
40        sustainable remanufacturing. Journal of Remanufacturing, 13(3), 355–379. https://doi.org/10.1007/s13243-
41        023-00134-z




       o
42
43   Wang, En-Ze, Lee, Chien‐Chiang, & Li, Yaya. (2022). Assessing the impact of industrial robots on manufacturing
44        energy intensity in 38 countries. Energy Economics, 105, 105748.




     F
45        https://doi.org/10.1016/j.eneco.2021.105748
46
47   Wang, Lei, Zhou, Yahong, & Chiao, Benjamin. (2023). Robots and firm innovation: Evidence from Chinese
48        manufacturing. Journal of Business Research, 162, 113878. https://doi.org/10.1016/j.jbusres.2023.113878
49
     Wang, Qiang, Zhang, Fuyu, Li, Rongrong, & Sun, Jiayi. (2024). Does artificial intelligence promote energy
50
          transition and curb carbon emissions? The role of trade openness. Journal of Cleaner Production, 447,
51
52        141298. https://doi.org/10.1016/j.jclepro.2024.141298
53
54
55
56
57
58
59
60



                                                                                                                         Page 33 of 35
1
2
3
4
5
6
7
8    Wang, Yong, Zhang, Ru, Yao, Kainan, & Ma, Xuejiao. (2024). Does artificial intelligence affect the ecological
9
          footprint? –Evidence from 30 provinces in China. Journal of Environmental Management, 370, 122458.
10




                                                                                                                        w
11        https://doi.org/10.1016/j.jenvman.2024.122458
12   Williams, Laurence, Sovacool, Benjamin K., & Foxon, Timothy J. (2022). The energy use implications of 5G:
13




                                                                                                                      e
          Reviewing whole network operational energy, embodied energy, and indirect effects. Renewable and
14




                                                                                                      i
15        Sustainable Energy Reviews, 157, 112033. https://doi.org/https://doi.org/10.1016/j.rser.2021.112033
16   Wilts, Henning, Garcia, Beatriz Riesco, Garlito, Rebeca Guerra, Gómez, Laura Saralegui, & Prieto, Elisabet
17




                                                                                                    v
          González. (2021). Artificial Intelligence in the Sorting of Municipal Waste as an Enabler of the Circular
18
          Economy. Resources, 10(4), 28. https://doi.org/10.3390/resources10040028
19




                                                                                           e
20   Wu, Kexu, Tang, Zhiwei, & Zhang, Longpeng. (2025). A Study on the Impact of Industrial Robot Applications on
21        Labor Resource Allocation. Systems, 13(7), 569.
22
23   Xin-gang, Zhao, & Jin, Zhu. (2022). Industrial restructuring, energy consumption and economic growth: Evidence




                                                                  R
24        from China. Journal of Cleaner Production, 335, 130242. https://doi.org/10.1016/j.jclepro.2021.130242
25
     Xu, Luo, Lin, Ning, Poor, H. Vincent, Xi, Dazhi, & Perera, A. T. D. (2025). Quantifying cascading power outages
26
27        during climate extremes considering renewable energy integration. Nature Communications, 16(1), 2582.




                                                                r
28        https://doi.org/10.1038/s41467-025-57565-4
29




                                                 e
     Yi, Xiongfeng, Wang, Furui, Zuo, Wenyu, Song, Gangbing, & Chen, Zheng. (2021). Robotics assisted smart-touch
30
31        pipeline inspection. International Journal of Intelligent Robotics and Applications, 5(3), 326–336.




                                               e
32        https://doi.org/10.1007/s41315-021-00191-2
33   Yu, Lingzheng, Zeng, Chenyu, & Wei, Xiahai. (2022). The impact of industrial robots application on air pollution in
34
          China: Mechanisms of energy use efficiency and green technological innovation. Science Progress, 105(4),
35




                        P
36        00368504221144093. https://doi.org/10.1177/00368504221144093
37   Yuan, Zhengnan, Huang, Jiaxing, Zhao, Zhiqin, Zahid, Adnan, Heidari, Hadi, Ghannam, Rami, & Abbasi, Qammer
38
          H. (2018). A Compact Wearable System for Detection and Estimation of Open Wound Status in Diabetic




                      r
39
40        Patient. Asia Pacific Conference on Postgraduate Research in Microelectronics and Electronics, 2018-
41        October, 60–63. https://doi.org/10.1109/PRIMEASIA.2018.8598064




       o
42
     Zhang, Xiekui, Liu, Peiyao, & Zhu, Hongfei. (2022). The Impact of Industrial Intelligence on Energy Intensity:
43
          Evidence from China. In Sustainability (Switzerland) (Vol. 14, Issue 12). https://doi.org/10.3390/su14127219
44




     F
45   Zhang, Yongliang, Zhu, Jianing, & Wang, Shali. (2025). Industrial robots reduce carbon emissions in manufacturing
46        through global value chains. Scientific Reports, 15(1), 27602. https://doi.org/10.1038/s41598-025-12958-9
47
48   Zhu, Qingyuan, Sun, Chenhao, Xu, Chengzhen, & Geng, Qianqian. (2025). The impact of artificial intelligence on
49        global energy vulnerability. Economic Analysis and Policy, 85, 15–27.
50        https://doi.org/10.1016/j.eap.2024.11.021
51
52
53
54
55
56
57
58
59
60



                                                                                                                           Page 34 of 35
1
2
3
4
5
6
7
8
     Data availability
9
10   The data that support the findings of this study are available from the author upon reasonable




                                                                                                 w
11
12   request.
13




                                                                                               e
14   Funding




                                                                                    i
15
     This research did not receive any funding.
16
17




                                                                                  v
     Contributions
18
19   Brahim Bergougui: writing—original draft (lead), data curtion; methadalogy, formal analysis




                                                                            e
20
     (lead), structuring.
21
22   Ethics declarations
23




                                                        R
24   Conflict of interest
25
26   The authors declare that they have no competing interests.
27




                                                      r
28   Ethical approval and consent to participate
29   Not applicable.




                                          e
30
31   Consent for publication




                                        e
32
33   Not applicable.
34
35




                       P
36
37
38




                     r
39
40
41




       o
42
43
44




     F
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60



                                                                                                      Page 35 of 35
