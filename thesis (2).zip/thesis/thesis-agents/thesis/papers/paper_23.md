                                                                             Energy Nexus 23 (2026) 100760


                                                                      Contents lists available at ScienceDirect


                                                                                 Energy Nexus
                                                            journal homepage: www.elsevier.com/locate/nexus


Full Length Article

Industrial robots and energy security risk: Asymmetric evidence from ten
leading automation-adopting economies
Brahim Bergougui a,b,c,* , Ousama Ben-Salha d, Syed Mansoob Murshed a,e
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
b
  College of Business & Economics, Qatar University, Doha, Qatar
c
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
d
  Humanities and Social Research Center, Northern Border University, Arar, 73213, Saudi Arabia
e
  Ho Chi Minh City University of Economics and Finance, Ho Chi Minh City, Vietnam




A R T I C L E I N F O                                       A B S T R A C T

Keywords:                                                   Industrial automation is reshaping the structural energy profile of advanced economies, yet its distributional
Energy security risk                                        consequences for Energy Security Risk (ESR) remain poorly understood. This paper estimates the asymmetric
Industrial automation                                       effects of industrial robot adoption on the ESR index across ten leading economies using annual data over
Quantile-on-quantile regression
                                                            2000–2019 and the multivariate quantile-on-quantile regression (m-QQR) framework. Our estimates reveal a
                                                            three-phase dynamic in six economies (China, Denmark, France, Germany, Italy, and the United States): at low
                                                            automation intensity, robot density elevates ESR because early-stage deployment imposes novel electricity loads
                                                            on existing grid infrastructure before efficiency gains materialize, generating transitional deterioration in energy
                                                            reliability; the relationship reverses at intermediate levels as efficiency gains and renewable grid integration
                                                            dominate; and high automation intensity yields sustained ESR improvements. Sweden stands apart, exhibiting
                                                            uniform ESR reductions across the entire automation distribution, attributable to the complementarity between
                                                            its mature renewable energy base and automated manufacturing. In contrast, Japan, South Korea, and Singapore
                                                            display a sign reversal at the automation frontier, where rising robot density deteriorates energy security —
                                                            consistent with a tipping-point dynamic in which automation-intensive electricity demand outpaces efficiency
                                                            gains in structurally import-dependent economies. These findings demonstrate that the automation–ESR rela­
                                                            tionship is non-monotonic, asymmetric, and context-contingent. Effective energy security policy must be cali­
                                                            brated to each economy's stage in the automation transition and its structural position in global energy trade.




1. Introduction                                                                                    shocks — COVID-19, the 2020 Russia–Saudi Arabia price war, and the
                                                                                                   Russia–Ukraine conflict — each of which exposed how fragile energy
   Industrial robots have become central to advanced manufacturing                                 supply chains actually are [4–6]. For import-dependent economies, that
economies, yet whether they make those economies more or less energy-                              fragility is structural, not episodic. Whether industrial automation can
secure remains an open and surprisingly unresolved question [1]. The                               serve as a buffer against it — by reducing energy intensity, supporting
rapid diffusion of robots across automotive, electronics, and metal                                renewable integration, and improving grid management — or whether it
fabrication has introduced a consequential new dimension to energy                                 deepens vulnerability by escalating electricity demand and concen­
security management — one whose answer, this paper shows, depends                                  trating exposure to supply disruptions, is a question with direct policy
on where an economy sits in the automation transition and how it is                                stakes.
positioned in global energy trade.                                                                     The energy implications of industrial automation are genuinely
   The urgency is real. Over the past decade, Energy Security Risk (ESR)                           ambiguous. The global robot stock exceeded 3.9 million units by 2022
has moved from a resource-management footnote to a core parameter of                               (IFR, 2023), concentrated in the most energy-hungry manufacturing
national economic policy [2,3], driven by a sequence of compounding                                sectors. The direct electricity draw of robots is modest — roughly 8% of



  * Corresponding author.
    E-mail addresses: brahimbergougui@gmail.com, bergougui@iss.nl (B. Bergougui), ousama.bensalha@nbu.edu.sa (O. Ben-Salha), mansoobms@uef.edu.vn
(S.M. Murshed).

https://doi.org/10.1016/j.nexus.2026.100760
Received 7 March 2026; Received in revised form 10 May 2026; Accepted 6 July 2026
Available online 7 July 2026
2772-4271/© 2026 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                                               Energy Nexus 23 (2026) 100760


energy use in automotive production [7,8] — but that is not where the            heterogeneity across the joint distribution of automation and ESR. That
argument lies. Robots matter for ESR through indirect structural chan­           gap matters for policy: if automation's ESR-reducing effects are
nels: they reshape production energy intensity, alter sectoral output            concentrated at high-risk states — precisely when energy security
composition, and change how industrial demand interacts with the grid.           management is most urgent — mean-based estimators will systemati­
Manufacturing accounts for 37% of global final energy consumption                cally understate the policy-relevant impact.
(IEA, 2018), so even modest robot-driven shifts in energy intensity carry            The paper contributes to literature along three dimensions. First, it
real aggregate weight. On the ESR-reducing side, smart automation                provides the first systematic country-level evidence on the distributional
improves load forecasting, reduces process waste, and supports variable          effects of industrial robot density on the ESR index, shifting the empir­
renewable integration [9–12]. On the ESR-elevating side, deep auto­              ical focus to a precisely defined, policy-actionable outcome variable
mation concentrates industrial demand on grid electricity — a fully              distinct from the energy efficiency, renewable adoption, or poverty
automated automotive plant can exceed 500 gigawatt-hours annually                outcomes examined in prior work. Second, the m-QQR framework re­
[13,14] — and the rebound effect can offset firm-level efficiency gains at       covers the full non-linear response surface of ESR to automation,
the sectoral level [10,15,16]. The net effect on ESR is empirical, and the       revealing whether the ESR-ameliorating effects of robot adoption are
answer depends on the structural energy trade position of the economy            concentrated at high-risk states — where they matter most — or at low-
in question.                                                                     risk states where they are largely redundant. Third, by focusing on the
    How robots actually affect energy security differs across the ten            ten economies at the global frontier of robot adoption, the findings
economies we study. In China, Germany, and the United States, rising             provide the most informative available signal about the ESR conse­
robot density at intermediate-to-high adoption levels reduces ESR                quences that other nations will confront as their own Industry 4.0
through improved grid management, AI-assisted demand forecasting,                transitions mature, carrying forward-looking policy relevance well
and structural shifts toward less energy-intensive output. In Sweden, the        beyond the sample countries.
complementarity between automated manufacturing and a predomi­                       The paper proceeds as follows. Section 2 reviews the empirical
nantly renewable energy base means efficiency gains materialize from             literature. Section 3 presents data, the ESR index construction, and the
the earliest deployment stages, with no transitional cost phase. Japan,          econometric framework. Section 4 reports results. Section 5 discusses
South Korea, and Singapore tell a different story: at the automation             findings. Section 6 concludes with policy recommendations.
frontier, electricity demand from high-density robotic systems outpaces
what these structurally import-dependent economies can supply cleanly,           2. Literature review
pushing ESR upward rather than down. Each economy's position in
global energy trade is the critical moderating factor that prior work has            Industrial automation is reshaping the energy sector and, by exten­
missed.                                                                          sion, the ESR index in ways that have attracted rapidly growing schol­
    For net importers like Japan, South Korea, and Singapore,                    arly attention. A bibliometric analysis by Entezari et al. [17]
automation-driven efficiency gains compress import volumes and                   documented exponential growth in this research domain, with publi­
attenuate — but do not eliminate — external supply shock transmission.           cations climbing from near zero in the early 2000s to over 1500 papers
Two dimensions of energy security must be distinguished here: long-run           on automation-related technologies and 4000 papers on machine
structural vulnerability, which automation can reduce by lowering en­            learning applications by 2020. As established in the preceding section,
ergy intensity over time, and short-run shock resilience, which depends          industrial automation — operationalized through IFR robot density —
on geopolitical circumstances and strategic reserves that lie outside            has the theoretical capacity to either reduce or amplify the ESR index,
what automation policy can address. Japan's drawdown of petroleum                depending on the structural context and the specific transmission
reserves following the 2026 Strait of Hormuz closure is a short-run crisis       channel through which it operates. The following subsections provide a
response — not evidence against the long-run structural argument this            systematic overview of these mechanisms, drawing on both the theo­
paper advances. Our empirical analysis covers 2000–2019 annual data              retical and empirical strands of literature.
and identifies medium-to-long-run structural relationships only. For the
United States, efficiency gains may compress production incentives in            2.1. Beneficial effects of industrial automation on energy security risk
energy-intensive sectors while productivity-led expansion simulta­
neously raises aggregate demand. China, despite its scale as the world's             Industrial automation can reduce energy security risk through four
largest energy producer, remains structurally import-dependent given             principal channels. The first and most extensively documented is the
its coal reliance and industrial energy appetite. Sweden exports elec­           optimization of energy systems. Automation-driven solutions enhance
tricity but imports fossil fuels. Pooling these economies under a common         energy flow management across interconnected grid components —
slope conflates fundamentally distinct transmission mechanisms —                 including consumers, storage batteries, and microgrids — by enabling
country-specific estimation is an empirical necessity, not a robustness          real-time monitoring, adaptive load balancing, and predictive control
check.                                                                           [18]. Key application domains include smart grid management, building
    This paper asks: does robot adoption reduce or amplify energy se­            automation systems, integrated renewable energy system development,
curity risk, and does the answer vary systematically with automation             industrial process optimization, and efficient transport systems [19,20].
intensity and energy trade position? We use annual data over                     Kanase-Patil et al. [21] underscored the centrality of automation in
2000–2019 and the multivariate Quantile-on-Quantile Regression (m-               managing these systems and safeguarding energy security in smart city
QQR) framework, which conditions simultaneously on quantiles of both             environments, while a complementary body of work has demonstrated
robot density and the ESR index, recovering the full non-linear, asym­           that automation-based optimization techniques help resolve energy
metric response surface across the joint distribution. This goes beyond          supply and demand mismatches in power systems [22–24]. At the
standard quantile regression, which treats the regressor symmetrically.          sub-grid level, recent studies have highlighted automation-based solu­
Country-specific estimation ensures that results reflect each economy's          tions for smart microgrid energy flow management and demand opti­
actual structural context rather than an average over incompatible               mization. Microgrids are reshaping energy distribution as foundational
institutional settings.                                                          components of grid decentralization [25], providing energy autonomy,
    No prior study has taken the ESR index as its primary dependent              cost-effectiveness, operational efficiency, and sustainability, with most
variable. Existing empirical work examines robots' effects on energy             output derived from renewable sources [26]. Automation techniques
efficiency, renewable adoption, and energy poverty — related but                 have been shown to improve the management and stability of smart
conceptually distinct outcomes that do not straightforwardly generalize          microgrid networks [27–29]. More broadly, Awogbemi et al. [30]
to ESR. Crucially, no prior study has examined distributional                    argued that automation-driven solutions contribute to the achievement

                                                                             2
B. Bergougui et al.                                                                                                                 Energy Nexus 23 (2026) 100760


of SDG7 (affordable and clean energy) through five transmission chan­              ten incidents in 2019 — a trend that underscores the ESR exposure
nels: data-driven decision-making, predictive modeling, optimization,              created by the digitalization accompanying industrial automation.
adaptability, and energy storage and grid integration.                                 The third adverse channel concerns the risk of system failure and
    The second beneficial channel operates through energy storage sys­             forecast inaccuracy. Although automation tools have demonstrated high
tems, which are essential for minimizing ESR and ensuring stable power             capacity in managing energy systems and forecasting electric load de­
system operations [31]. Mismatches between energy demand and sup­                  mand, they are susceptible to generating inaccurate or flawed outputs
ply during peak periods can strain the electrical grid and trigger                 under certain conditions [52]. Sources of failure include missing or
blackouts, directly elevating ESR [32]. An expanding body of literature            noisy energy data, biases in training datasets, inadequate implementa­
highlights the critical role of automation-driven solutions in developing          tion of learning algorithms, and the neglect of relevant external factors.
effective energy storage systems [33–35]. Olabi et al. [36] demonstrated           Alhamrouni et al. [53] identified four categories of impediment that
that automation-based techniques outperformed traditional modeling                 could undermine automation’s contribution to energy security man­
approaches, exhibiting superior flexibility, cost-effectiveness, resilience,       agement: technical challenges, security and privacy challenges, perfor­
and forecasting accuracy in storage management applications.                       mance and cost challenges, and social and ethical challenges.
    The third channel through which industrial automation reduces ESR
concerns electricity theft detection. Electricity theft generates substan­         2.3. Empirical literature on industrial automation and energy security risk
tial economic losses and poses serious energy security risks [37].
Wabukala et al. [38] established that electricity theft adversely affects              Despite the substantial theoretical literature examining the trans­
the ESR index through supply interruptions, compromised electricity                mission channels through which industrial automation affects energy
quality, and financial losses that discourage future infrastructure in­            security — both beneficially and adversely — there remains a pro­
vestment. The scale of this problem is significant: according to Jokar             nounced shortage of rigorous empirical studies that quantify the sign,
et al. [39], electricity theft generates losses of approximately $6 billion        magnitude, and distributional heterogeneity of this relationship. A small
annually in the United States alone. Automation-driven detection tech­             but growing body of empirical work has begun to address adjacent di­
nologies — deploying deep learning and machine learning algorithms —               mensions of the automation–energy nexus. Li et al. [54] assessed the
have emerged as effective instruments for identifying power theft with             implications of industrial robot adoption for the energy and resource
high precision. Žarković and Dobrić [40] found that artificial neural           efficiency of Chinese firms over 2005–2014, demonstrating that robot
networks outperformed competing algorithms with a frequency error of               adoption enhanced efficiency primarily through structural trans­
7.62%, while Lin et al. [41] achieved a 93.6% accuracy rate using                  formation and within-firm efficiency effects. Yin et al. [55] explored the
Adaptive Tuning Recurrent Neural Networks.                                         repercussions of automation software development for energy transition
    The fourth beneficial channel is energy demand forecasting.                    across 62 countries over 2011–2020, confirming that automation exerts
Consistent access to electric power requires accurate forward-looking              beneficial effects on renewable energy adoption by improving innova­
assessment of demand trajectories, particularly in uncertain economic              tion performance. Zhao et al. [56] examined the implications of auto­
and climatic environments [42]. Automation-based forecasting tech­                 mation adoption for renewable energy use in 63 countries over
niques are regarded as highly effective instruments for load demand                2000–2019, finding that higher robot density is associated with
prediction and ESR management [43–45]. These techniques have                       increased renewable energy uptake. Wang et al. [57] analyzed the ef­
demonstrated systematic superiority over traditional statistical methods           fects of robot adoption on high-quality energy development across 30
such as ARIMA models in terms of forecast accuracy, adaptability to                Chinese provinces between 2007 and 2017, estimating that a 1% rise in
structural breaks, and capacity to incorporate non-linear demand                   robot density leads to a 0.032% improvement in the quality of energy
drivers [46].                                                                      development. Song et al. [58] investigated the influence of industrial
                                                                                   automation on renewable energy supply chain vulnerability across 61
2.2. Adverse effects of industrial automation on energy security risk              countries, revealing that greater automation generally reduces associ­
                                                                                   ated supply chain risks. Finally, Ding et al. [18] assessed the re­
    A growing strand of the literature cautions that industrial automa­            percussions of robot adoption on energy poverty across 64 countries
tion and its associated technologies may, under certain conditions,                between 2000 and 2019, concluding that robot density exerts a negative
exacerbate rather than ameliorate the ESR index. Three principal                   and statistically significant direct impact on energy poverty, effectively
adverse channels have been identified. The first and most extensively              reducing it.
documented concerns the substantial computational energy consump­                      The broader environmental economics literature provides important
tion inherent in advanced automation systems. Patterson et al. [14]                contextual grounding for these findings. Across BRICS economies,
documented that the energy demands of training and operating auto­                 renewable energy consumption, green technology innovation, and
mated systems have grown dramatically in line with model complexity.               institutional quality collectively reduce ecological footprint, while fossil
Verdecchia et al. [47], in a systematic review of 98 articles, concluded           fuel dependence intensifies environmental pressures — underscoring
that the training stage is both the most frequently studied and the most           that the energy mix and governance context in which automation
energy-intensive phase of the automation lifecycle [13]. The cumulative            operates are first-order determinants of its environmental outcomes [59,
energy footprint of industrial automation infrastructure — encompass­              60]. Financialization research further demonstrates that institutional
ing robotic systems, coordinating software platforms, and supporting               quality and renewable energy consumption reduce carbon emissions in
data centers — thus represents a non-trivial addition to aggregate in­             the long run, with effects varying heterogeneously across quantiles [59,
dustrial energy demand, potentially tightening domestic supply margins             61] — a pattern directly analogous to the distributional heterogeneity
and elevating ESR, particularly in net energy-importing economies.                 this study recovers for the automation–ESR relationship. For G7 econ­
    The second adverse channel operates through cybersecurity vulner­              omies, energy innovations and environmental regulations reduce
abilities. Automated energy management systems — by virtue of their                ecological damage with quantile-varying magnitudes [62], while
connectivity and digital architecture — are inherently exposed to                  country-specific evidence from the United States and China confirms
cyberattacks, which can induce power outages and generate acute ESR                that the carbon and energy implications of technological change depend
challenges [48–50]. Smith [51] documented thousands of attacks on the              critically on whether clean energy complements or substitutes for fossil
energy sector, while the International Energy Agency (2020) reported               fuel inputs [63–65]. Taken together, this body of evidence reinforces the
substantial and growing cyberattack risks on power systems globally.               present study's central premise: the energy security consequences of
The frequency of annual cyberattacks targeting the electricity sector              industrial automation are not uniform but are conditioned by the
escalated dramatically, rising from a single recorded incident in 2008 to          structural, institutional, and energy-trade context in which automation

                                                                               3
B. Bergougui et al.                                                                                                                    Energy Nexus 23 (2026) 100760


is deployed.                                                                     increased renewable energy uptake [50]. These findings collectively
                                                                                 support the hypothesis that automation, at sufficient depth of integra­
2.4. Research gaps and positioning of the present study                          tion, compresses the import dependence and price exposure components
                                                                                 of the ESR index.
    The foregoing review of the literature reveals several important gaps
that motivate the present study.                                                 3.1.2. The scale and transitional cost channel
    First, while the theoretical literature provides strong grounds for              Conversely, robotic automation imposes substantial and continuous
expecting industrial automation to exert net beneficial effects on the ESR       baseload electricity demands — encompassing robotic actuators, servo
index — through energy system optimization, storage management,                  systems, server cooling infrastructure, and real-time data processing —
theft detection, and demand forecasting — this expectation is not un­            that can strain existing grid capacity, particularly during early adoption
qualified: the adverse channels operating through energy-intensive               phases [13,14]. At the onset of automation transitions, these novel
computation, cybersecurity vulnerabilities, and system failure risks             electrical loads introduce transitional costs on grid infrastructure that
introduce meaningful countervailing forces whose relative magnitudes             precede the efficiency gains from full operational integration, gener­
are context-dependent and empirically unresolved.                                ating a temporary deterioration in the reliability dimension of ESR [10].
    Second, and more critically, the empirical literature on industrial          At the automation frontier, if the surge in electricity demand outpaces
automation and energy security is markedly thin. While a small number            domestic renewable deployment capacity, net energy-importing econ­
of studies have examined robot adoption’s effects on energy transition,          omies face heightened pressure to expand fossil fuel imports, mechani­
renewable energy adoption, energy efficiency, and energy poverty, no             cally elevating both the geopolitical and reliability sub-components of
prior study has directly examined the relationship between IFR robot             the ESR index (IEA, 2023; [67]). The rebound effect — whereby
density and the ESR index as the primary dependent variable. The                 firm-level efficiency gains are offset by output expansion and the
absence of such evidence is particularly consequential given that energy         emergence of new energy-intensive production capabilities — may
transition, efficiency, and poverty are conceptually distinct dimensions         further neutralize aggregate energy savings at the sectoral level [15,16].
of the broader energy security construct — and evidence on one does not              To isolate the true structural impact of automation on ESR, it is
straightforwardly generalize to another.                                         necessary to control for broader macroeconomic forces that indepen­
    Third, and most importantly from a methodological standpoint, no             dently shape energy vulnerability. We therefore incorporate Economic
prior empirical study has examined the distributional heterogeneity of           Growth (GDP) and Energy Consumption (EC) as control variables. GDP
the automation–ESR relationship across different quantiles of the ESR            captures the dual role of economic scale: higher output generally ele­
index and robot density distributions simultaneously. The existing               vates aggregate energy demand and import pressure, raising ESR, but
empirical studies rely predominantly on mean-based panel estimators —            simultaneously generates the capital required to invest in resilient en­
including fixed-effects OLS, system-GMM, and standard panel cointe­              ergy infrastructure and clean technology deployment, potentially miti­
gration — which by construction recover only average effects and                 gating risk over the longer run [68,69]. Total Energy Consumption (EC)
cannot reveal whether automation’s ESR implications differ systemati­            controls for the baseline physical pressure placed on national energy
cally between high-ESR and low-ESR states, or between high-                      systems, absorbing the scale effect of aggregate demand growth and
automation and low-automation states. This methodological limitation             ensuring that the automation coefficient isolates the structural efficiency
is especially consequential for policy: if automation’s ESR-reducing ef­         mechanism from the broader demand-expansion effect (BP Statistical
fects are concentrated at high ESR states (precisely when energy security        Review, 2023; IEA, 2023). By jointly controlling for the absolute size of
management is most urgent), average-effect estimators will systemati­            the economy (GDP) and its total energy footprint (EC), the model iso­
cally understate the policy-relevant impact. The present study addresses         lates the specific structural effect of how an economy produces goods —
all three of these gaps through country-specific m-QQR estimation,               captured by robot density — on its overall energy vulnerability, as
providing the first distributional, quantile-level evidence on the auto­         measured by the ESR index.
mation–ESR nexus across the world’s leading robot-adopting
economies.
                                                                                 3.2. Data
3. Data and econometric methods
                                                                                 3.2.1. Sample selection and data sources
3.1. Theoretical channels and context of variables                                   The analysis covers the ten economies at the global frontier of in­
                                                                                 dustrial robot adoption over the period 2000–2019, a temporal bound­
    Before detailing the empirical data, it is essential to establish the        ary dictated by the availability of IFR robot density data. Industrial
theoretical channels through which the variables interact. The core              automation data are drawn from the International Federation of Ro­
narrative of this study posits that industrial automation does not merely        botics (IFR); the ESR index is obtained from the Global Energy Institute's
alter the scale of production, but fundamentally reshapes the structural         International Energy Security Risk Index; and control variables — GDP
energy profile of an economy, thereby affecting Energy Security Risk             growth and energy consumption — are sourced from the World
(ESR) through two competing channels.
                                                                                 Table 1
3.1.1. The energy optimization channel                                           The list of variables.
    At mature stages of deployment, industrial robots operate with high            Symbols    Explanation            Data sources
precision, minimizing process waste and optimizing energy consump­                 Dependent variable
tion per unit of output [1,66]. Beyond direct process efficiency, smart            ESR        Energy security risk   Global Energy Institute's website
automation systems facilitate real-time integration with demand-side                          index                  https://www.globalenergyinstitute.org/ener
management platforms and variable renewable energy grids, enabling                                                   gy-security-risk-index
                                                                                   Independent variable
adaptive load balancing and predictive energy dispatch that reduce both
                                                                                   Robot       Industrial            International Federation of Robotics
the economic cost and supply volatility dimensions of ESR [9,19].                              automation            https://ifr.org/
Empirical evidence from Chinese manufacturing firms confirms that                  Control variables
robot adoption enhances energy and resource efficiency primarily                   GDP         Economic growth       World Development Indicators
through within-firm process optimization and structural transformation             EC          Energy consumption    https://databank.worldbank.org/source/
                                                                                                                     world-development-indicators
[54], while cross-country evidence links higher robot density to

                                                                             4
B. Bergougui et al.                                                                                                                Energy Nexus 23 (2026) 100760


Development Indicators. Table 1 summarizes all variables, definitions,            the 29 metrics is set to 1000 at its 1980 value, enabling direct com­
and sources.                                                                      parison of risk trajectories across countries and over time. The overall
                                                                                  ESR index inherits this convention: values below 1000 indicate
3.2.2. Dependent variable: the ESR index                                          improved energy security relative to the 1980 baseline, while values
    The dependent variable is the Energy Security Risk (ESR) index,               above 1000 signal deterioration. A higher score therefore denotes a less
published by the Global Energy Institute (GEI) of the U.S. Chamber of             energy-secure economy. The index covers 25 large energy-consuming
Commerce. The index measures energy security risk both in absolute                economies — accounting for well over half of global energy consump­
terms and relative to a 1980 OECD baseline, allowing standardized                 tion — all ten of which appear in our sample with complete annual
comparison of risk trajectories across countries and over time [70].              observations over 2000–2019.
    The index is built from 29 underlying metrics organized across eight              The ESR composite is particularly appropriate as the outcome vari­
broad categories (see Fig. 1). The first two — Global Fuels and Fuel              able for this study because automation's effects operate simultaneously
Imports — capture the reliability and diversity of global oil, natural gas,       through multiple dimensions that single-proxy measures would miss.
and coal reserves, and each economy's exposure to concentrated or                 Efficiency gains from robotization reduce energy use intensity (category
unreliable import sources. The third and fourth categories — Energy               5); renewable grid integration improves electric power sector diversity
Expenditures and Price and Market Volatility — measure the magnitude              (category 6); demand compression in import-dependent economies
of energy costs to the national economy and susceptibility to large price         lowers fuel import exposure (category 2); and demand escalation at the
swings. The fifth category, Energy Use Intensity, captures energy con­            automation frontier amplifies price volatility exposure (category 4).
sumption relative to population and economic output, where lower in­
tensity signals reduced risk. The sixth, Electric Power Sector, measures          3.2.3. Independent variable
the diversity and reliability of electricity generating capacity. The sev­            The key independent variable is industrial robot density — the stock
enth, Transportation, reflects the oil dependence of the transport sector.        of operational industrial robots per 10,000 manufacturing workers —
The eighth, Environment, captures carbon dioxide emissions intensity.             sourced from the IFR. The IFR provides country- and industry-
Each category is constructed from between two and six individual                  disaggregated data on both the cumulative stock and the annual flow
metrics, and the eight sub-indices are combined into an overall com­              of robot installations. We employ the stock measure as the primary
posite through a weighted aggregation procedure, with weights cali­               proxy for automation depth, a choice that reflects a standard method­
brated to reflect the relative economic significance of each risk                 ological convention in the empirical automation literature [18,71]. The
dimension [70].                                                                   stock captures the accumulated technological capital embedded in an
    The primary data source underlying the index is the EIA's Interna­            economy's productive structure, providing a more stable and analyti­
tional Energy Statistics database, supplemented by IEA energy price               cally appropriate measure of automation intensity than the volatile
data, World Bank transportation and power generation statistics, and              annual installation flow — a distinction that is particularly consequen­
Freedom House political rights and civil liberties indices — the last of          tial in a quantile-based estimation framework, where measurement
which is used to weight fuel supply metrics by the political reliability of       stability across the distribution directly conditions the reliability of the
source countries, providing a proxy for geopolitical supply security that         recovered coefficients.
cannot be measured directly.
    The normalization convention is central to interpretation. Each of




Fig. 1. Indicators of the energy security risk index.
Source: energy and climate security risk index.

                                                                              5
B. Bergougui et al.                                                                                                                                                Energy Nexus 23 (2026) 100760


3.3. Econometric method                                                                                        appropriate methodological approach. This method evaluates the null
                                                                                                               hypothesis H0: ρ(τ) = ρ as outlined in Eq. (3). The analysis employs the
    The empirical strategy adopted in this study is designed to address                                        supremum norm, expressed as V             ρ (τ) − ̂ρ ⌉, alongside the rele­
                                                                                                                                               ̂n (τ) = ⌈̂
three features of the automation–ESR relationship that standard panel                                          vant test statistics. To determine the validity of the null hypothesis,
estimators are ill-equipped to handle: non-linearity, distributional                                           critical values are generated through 1000 Monte Carlo simulations,
asymmetry, and structural heterogeneity across country-specific quan­                                          ensuring a robust statistical inference.
tile combinations. To this end, the econometric framework proceeds in
two stages. The first stage applies a quantile cointegration test to                                           3.3.2. Multivariate quantile-on-quantile regression (m-QQR) approach
establish whether long-run equilibrium relationships between industrial                                            The second and central stage of the empirical analysis employs the
robot density and the ESR index exist across different distributional                                          multivariate Quantile-on-Quantile Regression (m-QQR) approach
regimes — moving beyond the constant-vector assumptions that                                                   developed by Alola et al. [74]. This method is adopted to address the
constrain traditional cointegration tests. The second stage employs the                                        inherent asymmetries and non-linearities in the automation–ESR rela­
multivariate Quantile-on-Quantile Regression (m-QQR) method to es­                                             tionship that are systematically obscured by conventional estimators.
timate how different quantiles of robot density influence corresponding                                            Intuition and methodological positioning. The core insight of m-
quantiles of the ESR index, while controlling for economic growth and                                          QQR is that the effect of industrial automation on energy security risk
energy consumption. The theoretical framework underpinning the                                                 may differ not only depending on whether ESR is high or low — which
relationship between industrial automation, energy security, and output                                        standard quantile regression captures — but also depending on whether
is presented in Appendix B.                                                                                    robot density itself is high or low. Standard Quantile Regression (QR)
                                                                                                               conditions only on quantiles of the dependent variable while treating the
3.3.1. Quantile cointegration (Q-C) test                                                                       independent variable at its conditional mean, thereby suppressing the
    The first stage of the empirical analysis applies the quantile cointe­                                     distributional heterogeneity of the regressor. The m-QQR framework
gration (Q-C) test developed by Xiao [72]. This methodology is adopted                                         resolves this by simultaneously conditioning on the τ-th quantile of
to overcome a well-documented limitation of conventional cointegra­                                            robot density and the γ-th quantile of the ESR index, recovering a full
tion tests, which impose the restrictive assumption that cointegration                                         two-dimensional response surface of slope coefficients across the joint
vectors are constant and uniform across the entire data distribution. In                                       distribution of both variables. Relative to bivariate quantile-on-quantile
the context of the automation–ESR nexus, this assumption is theoreti­                                          regression (b-QQR), m-QQR further addresses omitted variable bias by
cally implausible: the long-run equilibrium relationship between robot                                         incorporating economic growth (GDP) and energy consumption (EC) as
density and the ESR index may differ systematically depending on                                               additional control variables within the joint estimation framework [75,
whether the economy is in a low-ESR or high-ESR state, or whether                                              76].
automation intensity is low or high. The Q-C framework addresses this                                              Baseline specification. The m-QQR specification models the γ-th
by analyzing the dynamics of the long-run relationship across quantiles                                        quantile of ESR as a function of robot density and the vector of control
of both the dependent and independent variable distributions, capturing                                        variables. The baseline structural relationship is:
transient behaviors, regime-specific adjustment dynamics, and asym­                                                                  ∑             ∑
metric cointegration errors that conventional methods cannot detect                                            ESRt = βγ (Robott ) +    αγ (Ut ) +  λγ (Robott ⋅Ut ) + εγ            (4)
                                                                                                                                       n               n
[72].
    The Q-C methodology also mitigates biases that can arise in long-run
                                                                                                               where ESRt denotes the Energy Security Risk index, Robott denotes IFR
relationship estimation when the conditional distribution of the data is
                                                                                                               industrial robot density, and Ut is the matrix of ncontrol variables. The
heterogeneous, by adapting the cointegration regression to the specific
                                                                                                               term λγ (Robott ⋅Ut )captures the interaction between robot density and
quantile being analyzed. The inclusion of asymmetric cointegration er­
                                                                                                               the control variables, allowing their moderating influence on the auto­
rors with lead-lag dynamics extends the capabilities of conventional
                                                                                                               mation–ESR relationship to vary across quantiles. Incorporating and
methods. To account for potential parameter heterogeneity, Saikkonen
                                                                                                               consolidating these terms, Eq. (4) is reformulated as:
[73] recommends incorporating a time-invariant vector, α(τ), into the                                                  (              )
Q-C regression model, enabling more precise quantile-specific estima­                                                        ∑                   ∑
tion. The baseline cointegration specification is given by:                                                    ESRt = βγ +       τγ Ut Robott +     αγ (Ut ) + εγ                     (5)
                                                                                                                                n                      n
                      k
                      ∑                                                                                                                ∑
Xi = ρ + ρʹXi +               ΔYʹi− k π k + ϑi                                                       (1)       ESRt = ργ (Robott ) +       αγ (Ut ) + εγ                                    (6)
                      k=− s                                                                                                            n

   The quantile-augmented cointegration regression, which conditions
                                                                                                               where ργ (⋅)is an unknown function that embeds the full moderating ef­
on the τ-th quantile of the conditional distribution of Xᵢ, is expressed as:
                                                                                                               fect of the control variables on the automation–ESR slope. The unknown
   (            )                   k
                                    ∑                                                                          nature of ργ (⋅) is the key methodological challenge: since this function
QXτ Xi MXi , Myi = β(τ) + ρ(τ)ʹYi +   ΔYʹi− k πj + Hu− 1 (τ)                                         (2)       has no closed form, it cannot be estimated directly.
                                                 k=− s
                                                                                                                   Local linear approximation via Taylor expansion. To recover the
    Following Xiao's (2009) interpretation, the inclusion of the persistent                                    dependence between the γ-th quantile of ESR and the τ-th quantile of
parameter H−u 1 (τ) addresses the presence of a drift term in the cointe­                                      robot density, ργ (⋅) is approximated through a first-order Taylor
gration analysis. The symbol β(τ) denotes the quantile residual within                                         expansion around the τ-th quantile of robot density:
the conditional distribution of the data. The mathematical form for the
                                                                                                               ργ (Robott ) ≈ ργ (Robotτ ) + ργ (Robotτ )(Robott − Robotτ )                 (7)
                                                                                                                                               ʹ
quadratic expressions in the cointegrated association can be represented
as:                                                                                                                 This expansion is the methodological heart of the m-QQR approach.
                                                         k                      k
                                                                                                               It linearizes the unknown function ργ (⋅) locally around each quantile τof
   (            )                                        ∑                      ∑
QXτ Xi MXi , Myi = β(τ) + ρ(τ)ʹYi + ρ(τ)ʹYi2 +                   ΔYʹi− k πk +           ΔYi−2 k πk             robot density, producing two quantile-indexed parameters: δ0 (γ, τ) =
                                                         k=− s                  k=− s                           ργ (Robotτ ), which captures the intercept of the automation–ESR rela­
                        + H−u 1 (τ)                                                                            tionship at the (γ, τ) quantile combination, and δ1 (γ, τ) = ργ (Robot τ ),
                                                                                                                                                                                 ʹ


                                                                                                     (3)       which captures the slope — that is, the marginal effect of robot density
                                                                                                               at the τ-th quantile on the γ-th quantile of ESR. Substituting into Eq. (6):
    In assessing cointegration coefficients, the use of a QC test is an

                                                                                                           6
B. Bergougui et al.                                                                                                                         Energy Nexus 23 (2026) 100760

                                                       ∑
ESRt = δ0 (γ, τ) + δ1 (γ, τ)(Robott − Robot τ ) +          α(γ)(Ut ) + εγ         (8)       close agreement between the two confirms that the local approximation
                                                       n                                    does not introduce systematic bias relative to the global estimator.
   Extending the Taylor approximation to incorporate the interaction
terms between control variables and robot density yields the full esti­                     4. Empirical results
mating equation:
                                                                                                This section of the study presents the results of our empirical anal­
ESRt = β0 (γ, τ) + β1 (γ, τ)(Robott − Robot τ )                                             ysis. We follow a structured approach, with each step of our analysis
          ∑
       +      {θ0 (γ, τ) + θ1 (γ, τ)(Ut Robott − Uτ Robot τ )}+                             corresponding to the sequence outlined in Fig. 2. This figure serves as a
                        a                                                                   visual roadmap, guiding readers through our analytical process.
∑
          α(γ)(Ut ) + εγ                                                          (9)       4.1. Preliminary outcomes
  n

    Here, β1 (γ, τ)is the primary parameter of interest: it measures how the                    Table A.1 in Appendix A reports descriptive statistics for robot
τ-th quantile of robot density influences the γ-th quantile of the ESR                      density and the ESR index. The Jarque-Bera and ARCH-LM tests reject
index, conditional on economic growth and energy consumption. A                             normality and homoscedasticity of model residuals, while skewness and
negative β1 (γ, τ)indicates that higher robot density reduces ESR at that                   kurtosis statistics confirm distributional asymmetry — corroborated by
particular quantile combination; a positive value indicates the opposite.                   the leptokurtic kernel density plots in Fig. 3. These departures from
   Estimation via kernel-weighted local regression. Since β1 (γ,                            normality provide an initial motivation for estimation methods robust to
τ)must be estimated separately for each of the 19 × 19 quantile com­                        non-Gaussian data.
binations, direct global estimation is infeasible. The solution is a kernel-                    To establish the integration properties of the series under these
weighted local regression that assigns greater weight to observations                       distributional conditions, we employ the Quantile Augmented Dickey-
where robot density is close to the τ-th quantile. The optimization                         Fuller (Q-ADF) test of Liu et al. [77], which evaluates stationarity
problem is:                                                                                 across the conditional distribution rather than assuming uniform
         ∑                                     τ                                            distributional properties. Quantile series are generated at quantiles 0.05
  min        ϑγ 〈ESRt − β0 − β1 ( Robot
                                   ̂ t − Robot
                                           ̂ )
                                                                                            to 0.95 in increments of 0.05, following Li et al. [78]. The results
{β0 ,β1 ,θ0 ,θ1 }
                    q
           ∑                                                                                (Figs. A.1 and A.2) confirm that the log-transformed series of robot
                                         γ
      −     {θ0 − θ1 (Ut Robot
                          ̂ t − Uγ Robot
                                    ̂ )}+                                                   density and ESR are stationary at first difference across nearly the entire
            n                                                                               conditional distribution.
                            (                                                                   Having established the integration order, we turn to the functional
∑                                     ̂ t ) − γ)
                                Dq ( Robot                                                  form of the underlying data-generating process. The BDS test
          α(γ)(Ut )〉K                                                            (10)
  n
                                        h                                                   (Table A.2), applied following Baum et al. [79], rejects the null hy­
                                                                                            pothesis of linear dependence across all variables, confirming the pres­
where ϑγ is the standard quantile loss function (check function) that                       ence of non-linear structures. Taken together with the evidence of
penalizes positive and negative residuals asymmetrically to recover the                     non-normality and asymmetry documented above, these results collec­
γ-th conditional quantile, K(⋅)is a Gaussian kernel that assigns weights                    tively validate the adoption of the m-QQR framework for examining the
based on proximity to the τ-th quantile of robot density, and his the                       automation–ESR relationship across varying quantiles.
bandwidth parameter controlling the degree of localization. The                                 Finally, Table 2 reports the Q-C test for parameter stability, focusing
empirical distribution function Dq ( Robot
                                      ̂ t ) is defined as:                                  on the β and γ supremum norm coefficients derived from Eq. (3). The
                                                                                            supremum norm values consistently exceed their critical thresholds
                                 q
                            1∑ ̂                                                            across all countries, confirming a significant, nonlinear, and asymmetric
Dq ( Robot
      ̂ t) =                      I( Robot b < Robot
                                                ̂ t)                             (11)
                            q b=1                                                           long-run relationship between robot density and the ESR index — and
                                                                                            establishing the empirical foundation for the m-QQR estimation results
which ranks each observation within the robot density distribution,                         that follow.
enabling the kernel to localize estimation around the τ-th quantile.
    Implementation. The number of quantiles is set at 19, with τ                            4.2. Key outcomes
ranging from 0.05 to 0.95 in increments of 0.05, yielding a 19 × 19
matrix of slope coefficients β1 (γ, τ)for each economy. To validate the                        Fig. 4 reports the m-QQR slope coefficients ρ₁(θ, τ) for each of the ten
reliability of the m-QQR estimates, mean QQ values at each τ are                            sample economies, mapping how the θ-th quantile of industrial robot
compared with the corresponding standard QR parameter estimates;                            density shapes the τ-th quantile of the ESR index. These two-




                                                                  Fig. 2. Flowchart of empirical analysis steps.

                                                                                        7
B. Bergougui et al.                                                                                                                        Energy Nexus 23 (2026) 100760




                                                 Fig. 3. Kernel density distribution plots of robots robot and ESR.



Table 2
Outcomes of Q-C test (robot and ESR).
  Country                                   Coefficients               Supτ |Vn(τ)|                  C1                       C5                           C10

  China: robot vs. ESR                      ρ                          392.71756                     299.73907                191.14429                    156.54199
                                            γ                          236.23924                     121.9316                 78.447815                    60.164612
  Denmark: robot vs. ESR                    ρ                          3523.9487                     3414.106                 1550.3422                    1225.7592
                                            γ                          2530.6174                     1037.0005                766.48279                    634.1734
  France: robot vs. ESR                     ρ                          40,567.617                    35,218.617               18,905.344                   12,841.42
                                            γ                          24,507.285                    7313.5479                5250.0923                    4377.7842
  Germany: robot vs. ESR                    ρ                          51,101.039                    27,581.318               11,212.807                   9008.2061
                                            γ                          25,401.092                    6851.5449                4181.7471                    3338.9907
  Italy: robot vs. ESR                      ρ                          27,380.654                    60,924.457               22,447.273                   17,250.594
                                            γ                          14,679.845                    9276.7803                6847.6704                    5735.105
  Japan: robot vs. ESR                      ρ                          60,237.613                    413,729.63               316,885.53                   277,025.06
                                            γ                          27,648.951                    117,109.09               68,266.453                   51,024.563
  Singapore: robot vs. ESR                  ρ                          8130.6196                     11,020.248               2694.0728                    2174.0815
                                            γ                          5360.9902                     1348.1096                895.23254                    697.82935
  South Korea: robot vs. ESR                ρ                          5299.4307                     1783.1956                1130.9583                    949.8894
                                            γ                          2636.3525                     541.17603                384.84039                    313.98996
  Sweden: robot vs. ESR                     ρ                          21,503.977                    12,344.096               7475.8032                    6430.4805
                                            γ                          14,105.604                    5661.4917                4115.0649                    3430.8738
  United States: robot vs. ESR              ρ                          19,382.488                    7314.2363                4189.5781                    3637.366
                                            γ                          9384.165                      2238.5298                1486.4451                    1143.5527

Note: T-statistics are calculated across 19 evenly spaced quantiles ranging from 0.05 to 0.95. The table presents estimates of the supremum norm (ρ and γ) alongside
critical values for significance levels of 1% (C1), 5% (C5), and 10% (C10).



dimensional coefficient surfaces capture the full non-linear, asymmetric                quantiles 0.05–0.40), the automation–ESR association is positive and
structure of the automation–ESR relationship across the joint distribu­                 statistically robust. This pattern is consistent with the transitional costs
tion — heterogeneity that mean-based estimators suppress by                             hypothesis: at low levels of deployment, industrial automation imposes
construction.                                                                           elevated and unfamiliar energy demands on the grid, disrupts estab­
    Three-Phase Economies: Germany, China, Denmark, France,                             lished energy management routines, and introduces new cybersecurity
Italy, and the United States                                                            exposure vectors in critical infrastructure — all of which generate a
    For six of the ten economies, the m-QQR estimates reveal a consistent               transitory deterioration in the ESR index.
three-phase dynamic. In the early integration phase (robot density                          The relationship undergoes a structural inflection during the


                                                                                    8
B. Bergougui et al.                                                         Energy Nexus 23 (2026) 100760




                      Fig. 4. m-QQR estimations of the slope coefficient.




                                               9
B. Bergougui et al.                                                                                                                Energy Nexus 23 (2026) 100760


transitional phase (quantiles 0.45–0.80), where the positive association          IFR stock variable. To address these concerns, we employ the instru­
weakens progressively and turns negative. This reversal reflects the              mental variable multivariate quantile regression (IVMQR) framework of
maturation of automation within energy systems: as robotic systems                Chernozhukov & Hansen [[80], 2008] and Kaplan & Sun [81], which
become more deeply integrated into production and grid management,                preserves distributional flexibility while correcting for endogeneity
their efficiency-enhancing properties — superior load forecasting,                across the full quantile range. Our instrument is the first lag of log robot
optimized energy dispatch, improved grid stability — begin to dominate            density. Historical automation levels capture the persistence of tech­
the transitional cost effects, producing net ESR improvements.                    nological diffusion and strongly predict current adoption, while being
    At the advanced integration phase (quantiles 0.85–0.95), the highest          determined prior to contemporaneous ESR realizations and therefore
robot density levels are associated with substantial and sustained ESR            plausibly exogenous to the current-period ESR distribution. This
reductions, representing a complete reversal of the initial relationship.         instrumentation strategy follows Bergougui [82] and Tao et al. [83]
At the automation frontier, sophisticated robotic systems deliver energy              The IVMQR results (Fig. 5) broadly corroborate the baseline findings.
security gains through precise demand prediction, efficient renewable             For China, Denmark, France, Germany, Italy, and the United States, the
integration, and advanced cybersecurity protections for critical infra­           coefficient on robot density remains near zero across low and interme­
structure. The three-phase progression collectively establishes that              diate quantiles before declining sharply at upper quantiles — consistent
while early automation adoption carries transitional ESR costs, the long-         with the three-phase dynamic, though IV estimates concentrate the ESR-
run trajectory is firmly ESR-reducing for these economies.                        reducing effect more heavily at the automation frontier. Sweden exhibits
    Sweden: Uniform ESR Reduction Across the Full Distribution                    a persistently negative and relatively flat coefficient profile, confirming
    Sweden exhibits a qualitatively distinct pattern. The automa­                 uniform ESR amelioration across the distribution. Singapore and Japan
tion–ESR association is negative across the entire range of robot density         display the predicted sign reversal beyond approximately the 0.75
quantiles (0.05–0.95), with no initial phase of ESR elevation. The                quantile, with coefficients rising sharply into positive territory —
magnitude of improvement increases monotonically with automation                  consistent with the tipping-point mechanism in import-dependent
intensity and is particularly pronounced at the highest quantiles                 economies. Korea presents a more muted but directionally consistent
(0.80–0.95), where advanced applications in smart manufacturing and               pattern, with coefficients hovering near zero before turning positive at
grid optimization demonstrate the greatest capacity for compressing the           the uppermost quantiles. The widening of confidence intervals at
ESR index. This exceptionalism is structurally interpretable: the                 distributional tails — particularly visible for the USA, Germany, and
complementarity between industrial automation and Sweden's well-                  Japan — reflects reduced effective sample size at extreme quantiles, a
developed renewable energy infrastructure — with renewables ac­                   standard feature of quantile-based IV estimation. The overall consis­
counting for approximately 60 percent of total energy supply — effec­             tency between m-QQR and IVMQR estimates strengthens the causal
tively eliminates the transitional costs that characterize the early              interpretation of the baseline findings.
integration phase elsewhere. Sweden's profile suggests that the institu­
tional and energy infrastructure conditions surrounding automation,               4.3.2. Kernel-based regularized least squares (KRLS)
rather than automation intensity per se, determine whether the early-                 To verify that the non-linearities identified by the m-QQR framework
stage ESR penalty is incurred.                                                    are not artifacts of the quantile specification, we apply the KRLS esti­
    Japan, South Korea, and Singapore: ESR Elevation at the Auto­                 mator of Hainmueller & Hazlett [84] as a cross-method validation
mation Frontier                                                                   check. KRLS is a machine learning approach that detects non-linear re­
    The three advanced Asian economies present a structurally distinct            lationships without imposing parametric functional form restrictions,
and policy-consequential pattern. At low to upper-middle robot density            making it a natural complement to m-QQR. The two estimators differ in
quantiles (0.05–0.75), all three display the expected negative automa­            one important respect: while m-QQR conditions simultaneously on
tion–ESR association, consistent with standard efficiency-enhancing               quantiles of both robot density and the ESR index — recovering a full
effects. At high to very high quantiles (0.80–0.95), however, this rela­          two-dimensional response surface of quantile-specific slope coefficients
tionship undergoes a sign reversal: robot density becomes positively and          — KRLS produces average marginal effects and percentile-specific de­
significantly associated with the ESR index. The result is consistent with        rivatives that capture non-linearity across the distribution of the
a tipping-point dynamic in which the energy-intensive computational               outcome variable without the dual-quantile conditioning. This distinc­
and operational demands of frontier automation systems outpace the                tion makes KRLS unsuitable as the primary estimator for our research
efficiency gains they generate, producing net ESR deterioration.                  question, which centers on the joint distribution of both variables, but
    This reversal is structurally amplified by all three economies' posi­         well-suited as a robustness check: if the non-linear structure identified
tion as net energy importers with limited domestic resource bases. Any            by m-QQR is genuine rather than a specification artifact, KRLS should
automation-driven escalation in aggregate energy demand translates                recover a directionally consistent pattern at corresponding percentiles.
directly into heightened import dependence and increased exposure to                  The results confirm this. Average marginal effects (Table 3) are
supply-chain disruptions and price volatility — vulnerabilities that the          statistically significant at the 1 percent level for all economies except
March 2026 Strait of Hormuz crisis brought into sharp relief, as Japan,           France, where the effect is negative but borderline significant (p =
South Korea, and Singapore were among the economies most acutely                  0.285), consistent with the attenuated automation–ESR relationship
affected by the blockade. The findings underscore the imperative for              documented in the m-QQR results. R-squared values exceed 0.92 for all
these economies to develop targeted strategies for managing the energy            economies except South Korea (R² = 0.652). The percentile-specific
footprint of frontier automation, including demand-side management                marginal effects at the 25th, 50th, and 75th percentiles closely mirror
frameworks calibrated to robotic system intensity, accelerated renew­             the quantile-dependent sign and magnitude structure from the m-QQR
able deployment to cushion import exposure, and strengthened cyber­               estimation. The non-linear structure holds across both methods, con­
security governance for automation-dependent energy infrastructure.               firming it is not an artifact of the quantile specification.

4.3. Robustness analysis                                                          4.3.3. Multivariate quantile regression (m-QR)
                                                                                      As a second robustness check, we compare m-QR slope estimates
4.3.1. Addressing endogeneity concerns                                            with mean m-QQR coefficients averaged across the τ dimension
   The automation–ESR relationship is subject to endogeneity from                 (Equation 12). Fig. 6 confirms strong consistency: mean m-QQR slopes
reverse causality — economies facing elevated ESR may accelerate robot            closely track m-QR coefficients at corresponding quantiles across all ten
adoption to reduce import dependence — omitted variable bias from                 economies. Both estimators identify a predominantly negative automa­
unobserved institutional characteristics, and measurement error in the            tion–ESR relationship, with effects notably stronger in France, Germany,

                                                                             10
B. Bergougui et al.                                                                                                                Energy Nexus 23 (2026) 100760




Fig. 5. IVMQR coefficient estimates of robot on the ESR index across quantiles, by country.
Notes: The solid line represents point estimates; shaded areas denote 95% confidence intervals.



Table 3
KRLS average marginal effects of robot density on the ESR index.
  Economy               Average            SE               t                   P>t               P25               P50              P75                R2

  China                 − 1.039            0.056            − 18.582            0.000             − 1.165           − 0.229          − 0.061            0.929
  Denmark               − 1.336            0.108            − 12.424            0.000             − 0.751           − 0.296          − 0.051            0.959
  France                − 0.179            0.167            − 1.072             0.285             − 0.204           0.002            0.364              0.994
  Germany               − 0.609            0.225            − 2.707             0.007             − 0.433           − 0.038          4.217              0.977
  Italy                 − 1.535            0.176            − 8.732             0.000             − 2.112           − 0.042          0.383              0.993
  Japan                 − 18.014           2.573            − 7.000             0.000             − 30.177          − 4.086          0.455              0.931
  Singapore             1.044              0.211            4.940               0.000             − 0.278           − 0.026          0.483              0.963
  South Korea           − 0.519            0.149            − 3.475             0.001             − 0.179           − 0.001          0.094              0.652
  Sweden                − 1.987            0.236            − 8.434             0.000             − 2.517           − 0.477          − 0.078            0.995
  USA                   − 1.520            0.182            − 8.355             0.000             − 2.660           − 0.193          − 0.039            0.982

Note: SE: Standard error.


Italy, Japan, South Korea, Singapore, Sweden, and the United States                 optimization generate offsetting efficiency gains — analogous to the J-
than in China and Denmark. This convergence across methodologically                 curve dynamics documented in technology adoption literature [1].
distinct estimators strengthens confidence in the robustness of the m-              Germany's pattern reflects the complexity of the Energiewende: early
QQR findings.                                                                       automation deployment generated transitional ESR pressures, but
                                                                                    AI-driven grid management progressively enhanced renewable inte­
5. Discussion of results                                                            gration capacity at higher robot density quantiles, stabilizing the grid
                                                                                    under conditions of high renewable variability [87]. This is consistent
    Fig. 7 summarizes the automation–ESR relationship across all                    with Yin et al. [55], who find that automation software development
quantile combinations and all ten economies. The aggregate pattern is               accelerates renewable energy adoption across 62 countries by improving
clear: in seven of the ten sample countries, the predominant effect of              innovation performance. China's trajectory captures the tension be­
robot density on the ESR index is negative, indicating that industrial              tween rapid automation scaling and massive industrial energy demand
automation contributes to improved energy security at the country level.            — the strong positive association at low quantiles reflects energy con­
The economic rationale is straightforward — as robot density matures,               sumption escalation during the early robotics rollout, consistent with Li
the energy intensity of manufacturing output declines, import depen­                et al. [54], who document that robot adoption initially intensifies energy
dence compresses, and grid management improves, collectively                        demand in Chinese manufacturing before within-firm efficiency effects
reducing the geopolitical, economic, and reliability dimensions of the              dominate at higher adoption levels. Denmark's rapid transition to
ESR index. This finding is broadly consistent with prior evidence doc­              negative correlation at mid-range quantiles aligns with Song et al. [58],
umenting automation's beneficial effects on energy efficiency, renew­               who find that greater automation reduces renewable energy supply
able integration, and system resilience [66,85,86], and extends it by               chain vulnerability — a finding particularly apt for Denmark given its
recovering the full distributional heterogeneity of these effects and               structural position as a wind energy leader. France's profile reflects the
identifying each economy's structural energy trade position as a                    dual role of automation in a nuclear-dominated system, where early
first-order determinant of whether advanced-stage automation reduces                cybersecurity and operational complexity concerns gave way to ESR
or elevates ESR.                                                                    improvements as AI-driven optimization matured [88] — consistent
    Three-Phase Economies. The six three-phase economies illustrate                 with the reliability channel identified in the theoretical framework.
the structural economic logic underlying the non-linear automa­                     Italy's heterogeneous regional energy mix produces correspondingly
tion–ESR relationship. The initial ESR elevation at low robot density               heterogeneous early-stage effects that converge toward ESR reduction at
quantiles reflects a well-established transition cost mechanism: early-             higher quantiles, mirroring the pattern Wang et al. [57] document for
stage automation imposes novel and unfamiliar electricity loads on                  Chinese provinces with differentiated energy profiles. The United States
grid infrastructure before operational integration and process                      displays the most pronounced non-linearity in the sample: large positive


                                                                               11
B. Bergougui et al.                                                                                                            Energy Nexus 23 (2026) 100760




Fig. 6. Comparison of m-QQR and m-QR slope estimates: validation across ESR quantiles.
Note: This analysis compares conventional m-QR results with mean m-QQR estimates across various ESR quantiles.




Fig. 7. Summary of m-QQR outcomes across automation quantiles and economies.
Note: Very Low (0.05–0.10); Low (0.10–0.20); Low–Mid (0.20–0.40); Moderate (0.40–0.60); High (0.60–0.80); Very High (0.80–0.95).


associations at low quantiles reflect the coordination challenges of              modernization and renewable deployment targets, compressing the
deploying automation across a vast and institutionally fragmented en­             duration of the initial positive-slope phase. Economies with fragmented
ergy infrastructure, followed by some of the largest ESR reductions at            regulatory environments experienced more prolonged early-stage ESR
frontier quantiles — consistent with Ding et al. [66], who find that robot        elevation because automation-driven demand was absorbed by existing
density significantly reduces energy poverty across 64 countries, with            fossil fuel infrastructure rather than redirected toward clean energy.
effects strongest at high adoption levels.                                        Second, AI and automation governance: Sweden's absence of an initial
    Policy and Institutional Factors in the Three-Phase Dynamic.                  positive phase is partly attributable to its 2018 national AI strategy,
The three-phase pattern is not purely technological — the policy and              which aligned automation deployment with energy sustainability ob­
institutional environment in which automation is deployed materially              jectives from the outset, pre-empting the transitional cost phase
shapes both the duration of the initial ESR-elevating phase and the speed         observed elsewhere. Third, decarbonization commitment credibility:
of convergence to the efficiency regime. Three mechanisms stand out.              economies with legally binding long-term decarbonization targets —
First, energy market governance: economies with coordinated energy-               Denmark's renewable energy laws, France's nuclear optimization
industrial policy frameworks — Germany's Energiewende and China's                 framework — saw the inflection from positive to negative automa­
Made in China 2025 strategy — entered the efficiency phase earlier                tion–ESR slopes arrive at lower robot density quantiles than economies
because automation investment was explicitly coupled with grid                    where policy commitments were less institutionally entrenched. Policy


                                                                             12
B. Bergougui et al.                                                                                                                Energy Nexus 23 (2026) 100760


credibility, not just technology adoption, determines how quickly the              management and supply diversification to prevent automation-driven
efficiency phase materializes.                                                     energy escalation from undermining broader security gains.
    Sweden: Uniform ESR Reduction. Sweden is the one economy in
the sample where robot density reduces ESR at every point in the dis­              6. Conclusion and policy implications
tribution — no initial penalty, no inflection, just a consistently negative
slope from the lowest to the highest automation quantiles. Four struc­             6.1. Summary of key findings
tural features explain why. The energy mix is the foundation. Hydro­
power accounts for roughly 45% of Sweden's electricity generation,                     This paper examines the asymmetric effects of industrial robot den­
nuclear for another 30%, with wind growing fast under a 2016 Energy                sity on the Energy Security Risk index across ten leading automation-
Agreement that targets fully renewable electricity by 2040. When                   adopting economies — China, Denmark, France, Germany, Italy,
automation raises industrial electricity demand in Sweden, that demand             Japan, Singapore, South Korea, Sweden, and the United States — using
lands on low-carbon domestic supply — not fossil fuel imports. The                 annual data over 2000–2019 and the multivariate quantile-on-quantile
geopolitical and reliability dimensions of the ESR index, which drive              regression framework. The estimation strategy recovers the full distri­
early-phase deterioration in other economies, simply have nowhere to               butional heterogeneity of automation's ESR effects across quantiles of
worsen. Grid flexibility compounds this advantage. Hydro reservoirs                both variables and across structurally distinct national energy trade
dispatch on demand. When robot-intensive facilities ramp upload, the               contexts.
system balances through hydro rather than fossil fuel activation. Ger­                 Four principal findings emerge. First, the automation–ESR relation­
many faces this problem too, but its grid has to manage high renewable             ship is non-linear, asymmetric, and context-contingent: no single coef­
variability without the same dispatchable backstop. Sweden does not                ficient characterizes it, and pooled or mean-based estimators are
have that problem, which is why the early-phase grid stress visible in             structurally unable to recover its distributional complexity. Second, in
Germany, Italy, and the United States never shows up in the Swedish                six economies — China, Denmark, France, Germany, Italy, and the
estimates. The institutional conditions matter just as much as the                 United States — automation follows a three-phase dynamic: ESR rises at
physical infrastructure. Sweden has taxed carbon since 1991 — one of               low robot density quantiles, reflecting transitional adjustment costs;
the world's highest rates — which means energy-inefficient automation              turns negative at intermediate quantiles as efficiency and grid optimi­
has always been expensive there. Its 2018 national AI strategy went                zation effects materialize; and delivers sustained ESR reductions at the
further, explicitly tying automation deployment to energy sustainability           highest automation intensities. Third, Sweden constitutes an instructive
goals. Robot adoption in Sweden was never decoupled from clean en­                 exception, exhibiting ESR reductions uniformly across the entire auto­
ergy investment the way it was in more fragmented policy environ­                  mation distribution — a pattern attributable to the complementarity
ments. Finally, Sweden exports electricity. Japan, South Korea, and                between its mature renewable energy infrastructure and automated
Singapore hit a tipping point at frontier automation because demand                manufacturing. Fourth, Japan, South Korea, and Singapore display a
growth amplifies import dependence. Sweden faces the opposite struc­               sign reversal at frontier automation quantiles, with robot density
tural position — additional demand competes for domestically gener­                becoming positively associated with ESR, consistent with a tipping-point
ated renewables, not foreign supply. The tipping-point reversal that               dynamic in which automation-intensive energy demand outpaces effi­
defines the Asian economies does not appear in Sweden even at the                  ciency gains in structurally import-dependent economies.
highest quantiles, for exactly this reason. The broader implication,                   These baseline findings are robust to endogeneity correction. The
which extends Zhao et al. [56], is that the causal pathway between                 instrumental variable multivariate quantile regression estimates —
automation and clean energy runs in both directions. It is not just that           using lagged robot density as an instrument within the Chernozhukov
automation drives renewable uptake — a clean energy system also de­                and Hansen [[80], 2008] framework — closely replicate the m-QQR
termines whether automation reduces or elevates energy security risk               coefficient profiles across all ten economies, confirming that the
from day one.                                                                      three-phase dynamic, Sweden's uniform ESR reductions, and the
    Japan, South Korea, and Singapore: Tipping-Point Dynamics.                     tipping-point reversal in Japan, South Korea, and Singapore reflect
The positive automation–ESR association at frontier quantiles in these             genuine structural relationships rather than artifacts of simultaneity or
three economies represents the study's most policy-consequential                   omitted variable bias. Cross-method validation via kernel-based regu­
finding and has a clear economic rationale. At the automation fron­                larized least squares and standard multivariate quantile regression
tier, the electricity demands of high-density robotic systems, data cen­           further corroborates the non-linear structure of the automation–ESR
ters, and digital coordination infrastructure outpace the domestic                 nexus.
capacity of energy-importing economies to supply clean alternatives,                   The acute relevance of these findings was underscored in early
forcing increased fossil fuel imports and amplifying geopolitical and              March 2026, when coordinated U.S.–Israeli military strikes on Iranian
price exposure ([14]; IEA, 2023). For Japan, advanced automation in                infrastructure triggered the effective closure of the Strait of Hormuz, the
critical energy infrastructure generates cybersecurity vulnerabilities             suspension of Qatar's Ras Laffan LNG facility, and a sharp spike in global
structurally acute given its dependence on tightly coordinated supply              energy prices. The crisis exposed precisely the structural vulnerabilities
chains. For South Korea, aggressive frontier adoption creates                      our results identify: Japan, South Korea, and Singapore — the three
over-reliance on integrated digital-physical systems, increasing                   economies in our sample where frontier automation elevates rather than
cascading failure risk. For Singapore, the binding constraint is domestic          reduces ESR — were among those most severely affected by the
resource scarcity: frontier automation demand risks exceeding the cit­             disruption, facing emergency reserve drawdowns and acute supply un­
y-state's limited capacity to expand domestic supply. This tipping-point           certainty. This episode constitutes a powerful out-of-sample validation
mechanism finds support in the broader environmental economics                     of the tipping-point mechanism our estimation recovers.
literature: Amin & Al Shammre [60] and Kamran et al. [62] both
document that the energy and environmental implications of techno­                 6.2. Policy implications
logical change become adverse when fossil fuel dependence is not
simultaneously addressed — precisely the condition prevailing in these                 The findings generate differentiated, evidence-based policy pre­
three import-dependent economies. The common thread across all three               scriptions calibrated to each economy's position in the automation–ESR
is the interaction between frontier automation intensity and structural            landscape.
energy import dependence, confirming the importer–exporter frame­                      For the six three-phase economies (China, Denmark, France, Ger­
work developed in Section 1 and providing direct empirical support for             many, Italy, and the United States), the core policy priority is com­
the proposition that net importers require targeted demand                         pressing the duration of the early-stage ESR elevation phase. The

                                                                              13
B. Bergougui et al.                                                                                                                  Energy Nexus 23 (2026) 100760


evidence shows that transitional automation costs are not permanent                agenda rather than separate ministerial mandates — the evidence
but are substantially reduced where energy system complementarities                clearly shows that the policy environment surrounding automation, not
are in place. Three concrete instruments follow directly from the find­            the technology itself, determines whether the ESR outcome is beneficial
ings. First, governments should implement automation-conditional grid              or adverse.
investment mandates — requiring firms accessing industrial robotiza­
tion subsidies to co-invest in on-site energy storage and demand                   6.3. Limitations and directions for future research
response systems, ensuring that new electricity loads are matched by
corresponding grid capacity additions rather than absorbed by existing                 Several limitations define productive avenues for future work. First,
fossil fuel infrastructure. Second, phased renewable deployment targets            the sample is confined to the ten leading robot-adopting economies,
linked to sectoral robot density thresholds would ensure that clean en­            limiting external validity to countries at or near the automation frontier.
ergy capacity scales alongside automation intensity, preventing the                Extending the analysis to broader groupings — including the G-20,
demand–supply gap that generates early-stage ESR deterioration. Third,             MENA region, the European Union, and BRICS economies — would
for the net energy importers in this group — France, Germany, and Italy            clarify whether the three-phase dynamic and the tipping-point mecha­
— energy import diversification agreements should be explicitly inte­              nism generalize to economies at earlier stages of the automation
grated into national automation strategies, ensuring that early-stage              transition.
import pressure is spread across multiple supply corridors rather than                 Second, while the m-QQR framework provides a comprehensive
concentrated in single-source dependencies.                                        characterization of the quantile-on-quantile relationship, it does not
    For Japan, South Korea, and Singapore, the policy imperative is                explicitly model dynamic adjustment pathways. Future work deploying
preventing automation-driven demand escalation from generating ESR                 quantile ARDL or quantile VAR frameworks would yield richer evidence
deterioration at frontier robot densities — the tipping-point mechanism            on the speed of adjustment across phases and the persistence of
our estimation identifies and which structural import dependence am­               automation-induced ESR changes, offering more precise guidance on the
plifies. Four targeted instruments are warranted. First, mandatory en­             time horizon over which the three-phase dynamic unfolds.
ergy footprint assessments for frontier robotic systems — analogous to                 Third, the aggregated ESR index encompasses four sub-dimensions
environmental impact assessments for large infrastructure projects —               — geopolitical, economic, reliability, and environmental — which
would require firms deploying high-density automation to quantify and              automation may affect through distinct and potentially offsetting
offset the associated electricity demand increase before installation              channels. Decomposing the analysis to the sub-index level would iden­
approval. Second, accelerated domestic renewable capacity expansion,               tify which dimensions are most responsive to automation and which are
prioritized in sectors with the highest robot density, would reduce the            most vulnerable to the tipping-point dynamic, enabling more precisely
import intensity of automation-driven demand growth and insulate                   targeted interventions. Addressing these limitations will deepen the
these economies from the price and supply volatility that frontier                 evidence base and support more robust, context-sensitive policy devel­
automation currently amplifies. Third, cybersecurity governance                    opment at both the national and multilateral levels.
frameworks specific to automation-dependent energy infrastructure
should be established at the national level, given that digital integration        CRediT authorship contribution statement
at the automation frontier creates systemic vulnerability in critical en­
ergy systems. Fourth, given the regional concentration of tipping-point               Brahim Bergougui: Writing – original draft, Visualization, Soft­
risk, multilateral energy security coordination within ASEAN energy                ware, Investigation, Formal analysis, Conceptualization. Ousama Ben-
cooperation frameworks or the Northeast Asia energy dialogue would                 Salha: Writing – original draft, Methodology. Syed Mansoob Murshed:
provide effective platforms for harmonizing governance standards,                  Writing – original draft.
sharing strategic reserves, and pooling demand management expertise
across economies facing structurally similar automation–ESR                        Declaration of competing interest
challenges.
    For all economies navigating the automation transition, Sweden's                   The authors declare that they have no known competing financial
experience provides the most actionable benchmark. The ESR-reducing                interests or personal relationships that could have appeared to influence
potential of industrial automation is most fully realized when three               the work reported in this paper.
institutional conditions are simultaneously in place: a clean energy base
that eliminates fossil fuel escalation during early adoption; coherent AI          Acknowledgement
governance aligned with energy sustainability objectives; and durable
decarbonization commitments that sustain automation–energy                            The authors extend their appreciation to Northern Border University,
complementarity over the long run. Policymakers should therefore treat             Saudi Arabia, for supporting this work through project number (NBU-
automation policy and energy transition policy as a single integrated              CRP-2026-2922).



Appendix A



Table A.1
Robot and ESR: Descriptive Statistics and Distributions.

  Panel A. robot

  Economy              Descriptive statistics                                        Distributional properties

                       Mean               S.D              Min.    Max.              Skewness             Kurtosis      Jarque-Bera Stats             ARCH-LM (1)

  China                0.875              0.158            0.541   1.068             − 0.443              1.999         17.87                         238.792
  Denmark              0.684              0.039            0.596   0.737             − 0.537              2.134         19.04                         238.802
  France               0.863              0.014            0.824   0.892             − 0.891              3.387         33.22                         238.408
                                                                                                                                            (continued on next page)


                                                                              14
B. Bergougui et al.                                                                                                                       Energy Nexus 23 (2026) 100760

Table A.1 (continued )
  Panel A. robot

  Economy                Descriptive statistics                                         Distributional properties

                         Mean               S.D              Min.       Max.            Skewness             Kurtosis        Jarque-Bera Stats          ARCH-LM (1)

  Germany                0.992              0.021            0.948      1.026           − 0.189              2.182           8.126                      238.668
  Italy                  0.914              0.013            0.876      0.938           − 1.040              3.806           49.74                      238.525
  Japan                  1.058              0.006            1.047      1.068           − 0.394              1.544           27.4                       236.196
  Singapore              0.732              0.045            0.676      0.834           1.035                3.005           42.85                      238.748
  South Korea            0.962              0.058            0.875      1.060           0.196                1.687           18.77                      238.768
  Sweden                 0.762              0.020            0.725      0.797           0.061                1.977           10.61                      238.611
  USA                    1.004              0.029            0.947      1.052           − 0.191              2.076           9.989                      238.730
  Panel B. ESR
  Economy                Descriptive statistics                                         Distributional properties
                         Mean               S.D              Min.       Max.            Skewness            Kurtosis         Jarque-Bera Stats          ARCH-LM (1)
  China                  0.265              0.079            0.194      0.820           5.032               29.185           7870                       238.702
  Denmark                0.259              0.075            0.188      0.787           5.040               29.356           7963                       238.684
  France                 0.268              0.077            0.193      0.809           5.038               29.358           7962                       238.681
  Germany                0.264              0.077            0.186      0.806           5.017               29.280           7913                       238.668
  Italy                  0.271              0.077            0.196      0.819           5.042               29.399           7986                       238.681
  Japan                  0.272              0.077            0.195      0.818           5.039               29.407           238.675                    7989
  Singapore              0.293              0.082            0.212      0.876           5.036               29.361           7964                       238.677
  South Korea            0.279              0.080            0.202      0.846           5.037               29.316           7940                       238.687
  Sweden                 0.267              0.077            0.193      0.808           5.036               29.307           7935                       238.687
  USA                    0.259              0.076            0.189      0.798           5.032               29.216           7886                       238.698
Note. Significance levels of 1% and 5% are denoted by * and **, respectively. Skewness and kurtosis values describe the data distribution, while the Jarque-Bera test
assesses normality of the model's parameters. The ARCH-LM(1) test checks for potential heteroscedasticity in the model.


Table A.2
Brock, Dechert, Scheinkman (BDS) test outcomes.

  Country                    Variable               Dim.2             Dim.3                Dim.4                    Dim.5            Dim.6                Conclusion

  China                      ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Denmark                    ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  France                     ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Germany                    ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Italy                      ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Japan                      ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Singapore                  ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  South Korea                ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  Sweden                     ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
  USA                        ESR                    0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
                             Robot                  0.0000            0.0000               0.0000                   0.0000           0.0000               Nonlinear
Note. Dim. denote dimension. Values indicate p-values.




                                                                                 15
B. Bergougui et al.                                                                      Energy Nexus 23 (2026) 100760




                      Fig. A.1. Outcomes of the Quantile ADF Unit Root Test for robot.




                                                     16
B. Bergougui et al.                                                                                                                         Energy Nexus 23 (2026) 100760




Fig. A.2. Outcomes of the Quantile ADF Unit Root Test for ESR.
Note: The green, blue, and red lines in the figures represent the critical values of − 2.58, − 2.89, and − 3.49, corresponding to the 10%, 5%, and 1% significance levels,
respectively. The robot and ESR series are analyzed at their first differences.


Appendix B

    We hypothesize a simple theoretical model with two equations:
Ṗ = Y(P, S) − Y N
   The equation above, akin to the Phillips curve, is a relation for aggregate supply in the economy. Output (Y) is a positive function of the ‘price’ (P)
level and energy supply (S), and when output exceeds the natural rate (Y N) the price level goes up. In other words, a boom in the economy is associated
with inflation, and recession with deflation. We can think of energy use as an intermediate input in production.
   We postulate another equation for energy demand:
Ṡ = S(P, E, A) − Y(P, S)
    The first term on the right-hand side is supply and the second term represents demand, corresponding to output in the economy. We assert that the
use of robots (A) boosts energy supply; it also responds positively to both the price level and energy demand.
    In equilibrium, the left-hand sides of both equations are equal to zero. Totally differentiating the two equations and arranging them in matrix form
(partial derivatives are indicated by subscripts):
[                        ][    ] ⌈        ⌉
      Y1          Y2        dP         0
                                 =          dA
  − Y 1 + S1 − Y 2 + S2 dS           − S3

    The sufficient condition for stability is that the determinant of the Jacobian matrix is positive:
DET = Y1 S2 − Y2 S1 > 0
    We assume stability. The effect of an exogenous increase in artificial intelligence is:
dP S3 Y 2
  =       >0
dA DET
    And



                                                                                   17
B. Bergougui et al.                                                                                                                                         Energy Nexus 23 (2026) 100760


dS − S3 Y 1
   =        <0
dA   DET
    In the new equilibrium the price level has increased, reflecting a rise in output; however, the equilibrium energy demand associated with this
increased output is smaller reflecting technological change and greater energy security.
    The results can be diagrammatically represented in Fig. B.1. The P schedule is downward sloping indicating that greater output has to be associated
with reduced energy use given fixed energy supplies. The S schedule is upward sloping if: Y1 > S1 ; S2 > Y2 . Greater energy supply leads to greater
energy use and higher output. From the initial equilibrium at A, greater artificial intelligence input shifts the S curve leftwards and the new equi­
librium is at point B.




                                                 Fig. B.1. Industrial automation and energy security: theoretical framework.




Data availability                                                                                [15] L. Liu, Z. Rasool, S. Ali, C. Wang, R. Nazar, Robots for sustainability: evaluating
                                                                                                      ecological footprints in leading AI-driven industrial nations, Technol. Soc. 76
                                                                                                      (2024) 102460, https://doi.org/10.1016/j.techsoc.2024.102460.
    Data will be made available on request.                                                      [16] S. Sorrell, The rebound effect: an assessment of the evidence for economy-wide
                                                                                                      energy savings from improved energy efficiency, UK Energy Res. Cent. (2007).
                                                                                                      https://ukerc.ac.uk/publications/the-rebound-effect-an-assessment-of-the-evide
References
                                                                                                      nce-for-economy-wide-energy-savings-from-improved-energy-efficiency/.
                                                                                                 [17] A. Entezari, A. Aslani, R. Zahedi, Y. Noorollahi, Artificial intelligence and machine
 [1] D. Acemoglu, P. Restrepo, Robots and jobs: evidence from US labor markets,                       learning in energy systems: a bibliographic perspective, Energy Strategy Rev. 45
     J. Polit. Econ. 128 (6) (2020) 2188–2244, https://doi.org/10.1086/705716.                        (2023) 101017, https://doi.org/10.1016/j.esr.2022.101017.
 [2] B.K. Sovacool, I. Mukherjee, Conceptualizing and measuring energy security: a               [18] C. Ding, J. Ke, M. Levine, N. Zhou, Potential of artificial intelligence in reducing
     synthesized approach, Energy 36 (8) (2011) 5343–5355, https://doi.org/10.1016/                   energy and carbon emissions of commercial buildings at scale, Nat. Commun. 15
     j.energy.2011.06.043.                                                                            (1) (2024) 5916, https://doi.org/10.1038/s41467-024-50088-4.
 [3] S. Ullah, G. Gozgor, Z. Lu, How do conflicts affect energy security risk? Evidence          [19] P.K. Goel, AI for Energy Efficiency and Conservation, in: B.A. Riswandi, B. Singh,
     from major energy-consuming economies, Econ. Anal. Policy 82 (2024) 175–187,                     C. Kaunert, K. Vig (Eds.), AI Applications for Clean Energy and Sustainability, IGI
     https://doi.org/10.1016/j.eap.2024.02.039.                                                       Global, 2024, pp. 32–49.
 [4] N. Aslam, W. Yang, R. Saeed, F. Ullah, Energy transition as a solution for energy           [20] A. Kristian, T.S. Goh, A. Ramadan, A. Erica, S.V. Sihotang, Application of AI in
     security risk: empirical evidence from BRI countries, Energy 290 (2024) 130090,                  optimizing energy and resource management: effectiveness of deep learning
     https://doi.org/10.1016/j.energy.2023.130090.                                                    models, Int. Trans. Artif. Intell. 2 (2) (2024) 99–105, https://doi.org/10.33050/
 [5] B.N. Iyke, Climate change, energy security risk, and clean energy investment,                    italic.v2i2.530.
     Energy Econ. 129 (2024) 107225, https://doi.org/10.1016/j.eneco.2023.107225.                [21] A.B. Kanase-Patil, A.P. Kaldate, S.D. Lokhande, H. Panchal, M. Suresh, V. Priya,
     November 2023.                                                                                   A review of artificial intelligence-based optimization techniques for the sizing of
 [6] B. Kruyt, D.P. van Vuuren, H.J.M. de Vries, H. Groenenberg, Indicators for energy                integrated renewable energy systems in smart cities, Environ. Technol. Rev. 9 (1)
     security, Energy Policy 37 (6) (2009) 2166–2181, https://doi.org/10.1016/j.                      (2020) 111–136, https://doi.org/10.1080/21622515.2020.1836035.
     enpol.2009.02.006.                                                                          [22] K.T. Chui, M.D. Lytras, A. Visvizi, Energy sustainability in smart cities: artificial
 [7] Aiming Liu, Huan Liu, Bitao Yao, Wenjun Xu, Ming Yang, Energy consumption                        intelligence, smart monitoring, and optimization of energy consumption, Energies
     modeling of industrial robot based on simulated power data and parameter                         11 (11) (2018) 2869, https://doi.org/10.3390/en11112869.
     identification, Adv. Mech. Eng. 10 (5) (2018) 1687814018773852, https://doi.                [23] T. Khan, M. Yu, M. Waseem, Review on recent optimization strategies for hybrid
     org/10.1177/1687814018773852.                                                                    renewable energy system with hydrogen technologies: state of the art, trends and
 [8] M. Brossog Paryanto, Bornschlegl M, J. Franke, Reducing the energy consumption                   future directions, Int. J. Hydrog. Energy 47 (60) (2022) 25155–25201, https://doi.
     of industrial robots in manufacturing systems Int. J. Adv. Manuf. Technol. 78 (5–8)              org/10.1016/j.ijhydene.2022.05.263.
     (2015) 1315–1328, https://doi.org/10.1007/s00170-014-6737-z.                                [24] A.T.D. Perera, P.U. Wickramasinghe, V.M. Nik, J.L. Scartezzini, Machine learning
 [9] O. Babayomi, Z. Zhang, T. Dragicevic, J. Hu, J. Rodriguez, Smart grid evolution:                 methods to assist energy system optimization, Appl. Energy 243 (2019) 191–205,
     predictive control of distributed energy resources—A review, Int. J. Electr. Power               https://doi.org/10.1016/j.apenergy.2019.03.202.
     Energy Syst. 147 (2023) 108812, https://doi.org/10.1016/j.ijepes.2022.108812.               [25] A. Joshi, S. Capezza, A. Alhaji, M.Y. Chow, Survey on AI and machine learning
[10] M. González Garibay, K. Primc, R. Slabe-Erker, Insights into advanced models for                techniques for microgrid energy management systems, IEEE/CAA J. Autom. Sin. 10
     energy poverty forecasting, Nat. Energy 8 (9) (2023) 903–905, https://doi.org/                   (7) (2023) 1513–1529, https://doi.org/10.1109/JAS.2023.123657.
     10.1038/s41560-023-01311-x.                                                                 [26] C. Wang, J. Yan, C. Marnay, N. Djilali, E. Dahlquist, J. Wu, H. Jia, Distributed
[11] K.I. Khan, A. Nasir, Application of artificial intelligence in solar and wind energy             energy and microgrids (DEM), Appl. Energy 210 (2018) 685–689, https://doi.org/
     resources: a strategy to deal with environmental pollution, Environ. Sci. Pollut.                10.1016/j.apenergy.2017.11.059.
     Res. 30 (24) (2023) 64845–64859, https://doi.org/10.1007/s11356-023-27038-6.                [27] A.J. Albarakati, Y. Boujoudar, M. Azeroual, R. Jabeur, A. Aljarbouh, H. El
[12] W. Zhang, M. Zeng, Is artificial intelligence a curse or a blessing for enterprise               Moussaoui, T. Lamhamdi, N. Ouaaline, Real-time energy management for DC
     energy intensity? Evidence from China, Energy Econ. 134 (2024) 107561, https://                  microgrids using artificial intelligence, Energies 14 (17) (2021) 5307, https://doi.
     doi.org/10.1016/j.eneco.2024.107561.                                                             org/10.3390/en14175307.
[13] A. de Vries, The growing energy footprint of artificial intelligence, Joule 7 (10)          [28] M. Talaat, M.H. Elkholy, A. Alblawi, T. Said, Artificial intelligence applications for
     (2023) 2191–2194, https://doi.org/10.1016/j.joule.2023.09.004.                                   microgrids integration and management of hybrid renewable energy sources, Artif.
[14] D. Patterson, J. Gonzalez, U. Hölzle, Q. Le, C. Liang, L.M. Munguia, D. Rothchild,              Intell. Rev. 56 (9) (2023) 10557–10611, https://doi.org/10.1007/s10462-023-
     D.R. So, M. Texier, J. Dean, The carbon footprint of machine learning training will              10410-w.
     plateau, then shrink, Computer 55 (7) (2022) 18–28, https://doi.org/10.1109/                [29] T. Wu, J. Wang, Artificial intelligence for operation and control: the case of
     MC.2022.3148714.                                                                                 microgrids, Electr. J. 34 (1) (2021) 106890, https://doi.org/10.1016/j.
                                                                                                      tej.2020.106890.




                                                                                            18
B. Bergougui et al.                                                                                                                                            Energy Nexus 23 (2026) 100760

[30] O. Awogbemi, D.V. Von Kallon, K.S. Kumar, Contributions of artificial intelligence             [55] H.T. Yin, J. Wen, C.P. Chang, Going green with artificial intelligence: the path of
     and digitization in achieving clean and affordable energy, Intell. Syst. Appl. 22                   technological change towards the renewable energy transition, Oecon. Copernic.
     (2024) 200389, https://doi.org/10.1016/j.iswa.2024.200389.                                          14 (4) (2023) 1059–1095, https://doi.org/10.24136/oc.2023.032.
[31] R. Uddin, H. Raza Khan, A. Arfeen, M.A. Shirazi, A. Rashid, U. Shahbaz Khan,                   [56] C. Zhao, K. Dong, K. Wang, R. Nepal, How does artificial intelligence promote
     Energy storage for energy security and reliability through renewable energy                         renewable energy development? The role of climate finance, Energy Econ. 133
     technologies: a new paradigm for energy policies in Turkey and Pakistan,                            (2024) 107493, https://doi.org/10.1016/j.eneco.2024.107493.
     Sustainability 13 (5) (2021) 2823, https://doi.org/10.3390/su13052823.                         [57] B. Wang, J. Wang, K. Dong, R. Nepal, How does artificial intelligence affect high-
[32] Y.H. Alsaedi, G.A. Tularam, The relationship between electricity consumption,                       quality energy development? Achieving a clean energy transition society, Energy
     peak load and GDP in Saudi Arabia: a VAR analysis, Math. Comput. Simul. 175                         Policy 186 (2024) 114010, https://doi.org/10.1016/j.enpol.2024.114010.
     (2020) 164–178, https://doi.org/10.1016/j.matcom.2019.06.012.                                  [58] Y. Song, Z. Wang, C. Song, J. Wang, R. Liu, Impact of artificial intelligence on
[33] D.H. Barrett, A. Haruna, Artificial intelligence and machine learning for targeted                  renewable energy supply chain vulnerability: evidence from 61 countries, Energy
     energy storage solutions, Curr. Opin. Electrochem. 21 (2020) 160–166, https://doi.                  Econ. 131 (2024) 107357, https://doi.org/10.1016/j.eneco.2024.107357.
     org/10.1016/j.coelec.2020.02.002.                                                              [59] W. Ameer, A. Amin, H. Xu, Does institutional quality, natural resources,
[34] Z. He, W. Guo, P. Zhang, Performance prediction, optimal design and operational                     globalization, and renewable energy contribute to environmental pollution in
     control of thermal energy storage using artificial intelligence methods, Renew.                     China? Role of financialization, Front. Public Health 10 (2022), https://doi.org/
     Sustain. Energy Rev. 156 (2022) 111977, https://doi.org/10.1016/j.                                  10.3389/fpubh.2022.849946.
     rser.2021.111977.                                                                              [60] A. Amin, A.S. Al Shammre, Towards sustainable development and net-zero
[35] N. Kumar, Prabhansu, Artificial intelligence and machine learning applications in                   emissions in BRICS: empirical perspectives on renewable and fossil fuel energy
     energy storage system: technology overview and perspectives. Prabhansu & N.                         consumption, green technological innovation, and institutional quality, Energy
     Kumar (Eds.) Emerging Trends in Energy Storage Systems and Industrial                               Strategy Rev. 65 (2026) 102228, https://doi.org/10.1016/j.esr.2026.102228.
     Applications, Academic Press, 2022, pp. 1–26.                                                  [61] A. Amin, E. Dogan, Z. Khan, The impacts of different proxies for financialization on
[36] A.G. Olabi, A.A. Abdelghafar, H.M. Maghrabie, E.T. Sayed, H. Rezk, M. Al Radi,                      carbon emissions in top-ten emitter countries, Sci. Total Environ. 740 (2020)
     K. Obaideen, M.A. Abdelkareem, Application of artificial intelligence for                           140127, https://doi.org/10.1016/j.scitotenv.2020.140127.
     prediction, optimization, and control of thermal energy storage systems, Therm.                [62] H.W. Kamran, M. Rafiq, A. Abudaqa, A. Amin, Interconnecting sustainable
     Sci. Eng. Prog. 39 (2023) 101730, https://doi.org/10.1016/j.tsep.2023.101730.                       development goals 7 and 13: the role of renewable energy innovations towards
[37] O.A. Abraham, H. Ochiai, M.D. Hossain, Y. Taenaka, Y. Kadobayashi, Electricity                      combating the climate change, Environ. Technol. 45 (17) (2024) 3439–3455,
     theft detection for smart homes: harnessing the power of machine learning with                      https://doi.org/10.1080/09593330.2023.2216903.
     real and synthetic attacks, IEEE Access 12 (2024) 26023–26045, https://doi.org/                [63] A. Amin, N.Y. bte Mohamed Yusoff, S. Peng, C. Magazzino, A. Sharif, H.W. Kamran,
     10.1109/ACCESS.2024.3366493.                                                                        Driving sustainable development: the impact of energy transition, eco-innovation,
[38] B.M. Wabukala, N. Mukisa, S. Watundu, O. Bergland, N. Rudaheranwa, M.                               mineral resources, and green growth on carbon emissions, Renew. Energy 238
     S. Adaramola, Impact of household electricity theft and unaffordability on                          (2025) 121879, https://doi.org/10.1016/j.renene.2024.121879.
     electricity security: a case of Uganda, Energy Policy 173 (2023) 113411, https://              [64] Amin, A., Yusoff, N. Y. bte M., Isik, C., & Osabohien, R. (2025). Decarbonizing the
     doi.org/10.1016/j.enpol.2022.113411.                                                                U.S economy: the roles of renewable energy, technology innovation, human
[39] P. Jokar, N. Arianpoo, V.C. Leung, Electricity theft detection in AMI using                         capital, and green growth. Clean Technologies and Environmental policy, 27(11),
     customers’ consumption patterns, IEEE Trans. Smart Grid 7 (1) (2015) 216–226,                       7395–7415. https://doi.org/10.1007/s10098-025-03283-w.
     https://doi.org/10.1109/TSG.2015.2425222.                                                      [65] A. Amin, N.Y.bte M. Yusoff, S. Peng, C. Işık, A. Ullah, M. Akbar, The influence of
[40] M. Žarković, G. Dobrić, Artificial intelligence for energy theft detection in                    energy transition, and natural resources on carbon emissions in China: an
     distribution networks, Energies 17 (7) (2024) 1580, https://doi.org/10.3390/                        augmented ARDL application. Environment, Dev. Sustain. 27 (6) (2025)
     en17071580.                                                                                         12605–12623, https://doi.org/10.1007/s10668-023-04398-0.
[41] G. Lin, H. Feng, X. Feng, H. Wen, Y. Li, S. Hong, Z. Ni, Electricity theft detection in        [66] T. Ding, H. Li, L. Liu, K. Feng, An inquiry into the nexus between artificial
     power consumption data based on adaptive tuning recurrent neural network,                           intelligence and energy poverty in the light of global evidence, Energy Econ. 136
     Front. Energy Res. 9 (2021) 773805, https://doi.org/10.3389/fenrg.2021.773805.                      (2024) 107748, https://doi.org/10.1016/j.eneco.2024.107748.
[42] R. Houimli, M. Zmami, O. Ben-Salha, Short-term electric load forecasting in                    [67] A. Cherp, J. Jewell, The concept of energy security: beyond the four As, Energy
     Tunisia using artificial neural networks, Energy Syst. 11 (2) (2020) 357–375,                       Policy 75 (2014) 415–421, https://doi.org/10.1016/j.enpol.2014.09.005.
     https://doi.org/10.1007/s12667-019-00324-4.                                                    [68] N. Apergis, J.E. Payne, Energy consumption and economic growth: evidence from
[43] S. Motepe, A.N. Hasan, R. Stopforth, Improving load forecasting process for a                       the Commonwealth of Independent States, Energy Econ. 32 (6) (2010) 1374–1376,
     power distribution network using hybrid AI and deep learning algorithms, IEEE                       https://doi.org/10.1016/j.eneco.2010.06.002.
     Access 7 (2019) 82584–82598, https://doi.org/10.1109/ACCESS.2019.2923796.                      [69] D.I. Stern, The rise and fall of the environmental Kuznets curve, World Dev. 32 (8)
[44] M.Q. Raza, A. Khosravi, A review on artificial intelligence-based load demand                       (2004) 1419–1439, https://doi.org/10.1016/j.worlddev.2004.03.004.
     forecasting techniques for smart grid and buildings, Renew. Sustain. Energy Rev.               [70] Global Energy Institute, International index of energy security risk: 2020 edition.
     50 (2015) 1352–1372, https://doi.org/10.1016/j.rser.2015.04.065.                                    U.S, Chamb. Commer. (2020). https://www.globalenergyinstitute.org/energy-s
[45] X. Wang, H. Wang, B. Bhandari, L. Cheng, AI-empowered methods for smart energy                      ecurity-risk-index.
     consumption: a review of load forecasting, anomaly detection and demand                        [71] S. Yang, F. Liu, Impact of industrial intelligence on green total factor productivity:
     response, Int. J. Precis. Eng. Manuf.-Green Technol. 11 (3) (2024) 963–993,                         the indispensability of the environmental system, Ecol. Econ. 216 (2024) 108021,
     https://doi.org/10.1007/s40684-023-00537-0.                                                         https://doi.org/10.1016/j.ecolecon.2023.108021.
[46] M. Valipour, M.E. Banihabib, S.M.R. Behbahani, Parameters estimate of                          [72] Z. Xiao, Quantile cointegrating regression, J. Econom. 150 (2) (2009) 248–260,
     autoregressive moving average and autoregressive integrated moving average                          https://doi.org/10.1016/j.jeconom.2008.12.005.
     models and compare their ability for inflow forecasting, J. Math. Stat. 8 (3) (2012)           [73] P. Saikkonen, Asymptotically efficient estimation of cointegration regressions,
     330–338, https://doi.org/10.3844/jmssp.2012.330.338.                                                Econom. Theory 7 (1) (1991) 1–21, https://doi.org/10.1017/
[47] R. Verdecchia, J. Sallou, L. Cruz, A systematic review of Green AI, Wiley                           S0266466600004217.
     Interdiscip. Rev.: Data Min. Knowl. Discov. 13 (4) (2023) e1507, https://doi.org/              [74] A.A. Alola, O. Özkan, O. Usman, Examining crude oil price outlook amidst
     10.1002/widm.1507.                                                                                  substitute energy price and household energy expenditure in the USA: a novel
[48] N. Kharlamova, C. Træhold, S. Hashemi, Cyberattack detection methods for battery                    nonparametric multivariate QQR approach, Energy Econ. 120 (2023) 106613,
     energy storage systems, J. Energy Storage 69 (2023) 107795, https://doi.org/                        https://doi.org/10.1016/j.eneco.2023.106613.
     10.1016/j.est.2023.107795.                                                                     [75] R. Ashley, C.W.J. Granger, R. Schmalensee, Advertising and aggregate
[49] D.C. Smith, Enhancing cybersecurity in the energy sector: a critical priority,                      consumption: an analysis of causality, Econometrica 48 (5) (1980) 1149, https://
     J. Energy Nat. Resour. Law 36 (4) (2018) 373–380, https://doi.org/10.1080/                          doi.org/10.2307/1912176.
     02646811.2018.1516362.                                                                         [76] W. Gao, H. Zhang, The role of education attention on high-tech markets in an
[50] A.P. Zhao, Q. Zhang, M. Alhazmi, P.J.H. Hu, S. Zhang, X. Yan, AI for science: covert                emerging economy: evidence from QQR and NCQ techniques, Technol. Forecast.
     cyberattacks on energy storage systems, J. Energy Storage 99 (2024) 112835,                         Soc. Change 207 (2024) 123603, https://doi.org/10.1016/j.
     https://doi.org/10.1016/j.est.2024.112835.                                                          techfore.2024.123603.
[51] D.C. Smith, Cybersecurity in the energy sector: are we really prepared? J. Energy              [77] L. Liu, T.S. Adebayo, J. Hu, M. Irfan, S. Abbas, Exploring resource blessing
     Nat. Resour. Law 39 (3) (2021) 265–270, https://doi.org/10.1080/                                    hypothesis within the coffin of technological innovation and economic risk:
     02646811.2021.1943935.                                                                              evidence from wavelet quantile regression, Energy Econ. 137 (2024) 107802,
[52] S.S. Chanda, D.N. Banerjee, Omission and commission errors underlying AI                            https://doi.org/10.1016/j.eneco.2024.107802.
     failures, AI Soc. 39 (3) (2024) 937–960, https://doi.org/10.1007/s00146-022-                   [78] G. Li, Y. Li, C.-L. Tsai, Quantile correlations and Quantile autoregressive modeling,
     01585-x.                                                                                            J. Am. Stat. Assoc. 110 (509) (2015) 246–261, https://doi.org/10.1080/
[53] I. Alhamrouni, N.H. Abdul Kahar, M. Salem, M. Swadi, Y. Zahroui, D.J. Kadhim, F.                    01621459.2014.892007.
     A. Mohamed, M. Alhuyi Nazari, A comprehensive review on the role of artificial                 [79] C.F. Baum, S. Hurn, K. Lindsay, The BDS test of independence, Stata J. 21 (2)
     intelligence in power system stability, Control Prot.: Insights Future Dir., Appl. Sci.             (2021) 279–294, https://doi.org/10.1177/1536867X211025796.
     14 (14) (2024) 6214, https://doi.org/10.3390/app14146214.                                      [80] V. Chernozhukov, C. Hansen, An IV model of quantile treatment effects,
[54] J. Li, S. Ma, Y. Qu, J. Wang, The impact of artificial intelligence on firms’ energy                Econometrica 73 (1) (2005) 245–261, https://doi.org/10.1111/j.1468-
     and resource efficiency: empirical evidence from China, Resour. Policy 82 (2023)                    0262.2005.00570.x.
     103507, https://doi.org/10.1016/j.resourpol.2023.103507.                                       [81] D.M. Kaplan, Y. Sun, Smoothed estimating equations for instrumental variables
                                                                                                         quantile regression, Econom. Theory 33 (1) (2017) 105–157, https://doi.org/
                                                                                                         10.1017/S0266466615000407.


                                                                                               19
B. Bergougui et al.                                                                                                                                    Energy Nexus 23 (2026) 100760

[82] B. Bergougui, Industrial robots for a sustainable future: uncovering the asymmetric        [85] Y. FU, Y. SHEN, M. SONG, W. WANG, Does artificial intelligence reduce corporate
     effects of AI on ecological quality in G7 economies, Technol. Soc. 87 (2025)                    energy consumption? New evidence from China, Econ. Anal. Policy 83 (2024)
     102118, https://doi.org/10.1016/j.techsoc.2025.103021.                                          548–561, https://doi.org/10.1016/j.eap.2024.07.005.
[83] W. Tao, S. Weng, X. Chen, F.B. Alhussan, M. Song, Artificial intelligence-driven           [86] L. Tian, X. Li, C.-W. Lee, C. Spulbăr, Investigating the asymmetric impact of
     transformations in low-carbon energy structure: evidence from China, Energy                     artificial intelligence on renewable energy under climate policy uncertainty,
     Econ. 136 (2024) 107719, https://doi.org/10.1016/j.eneco.2024.107719.                           Energy Econ. 137 (2024) 107809, https://doi.org/10.1016/j.eneco.2024.107809.
[84] J. Hainmueller, C. Hazlett, Kernel regularized least squares: reducing                     [87] R. Vakulchuk, I. Overland, D. Scholten, Renewable energy and geopolitics: a
     misspecification bias with a flexible and interpretable machine learning approach,              review, Renew. Sustain. Energy Rev. 122 (2020) 109547, https://doi.org/
     Polit. Anal. 22 (2) (2014) 143–168, https://doi.org/10.1093/pan/mpt019.                         10.1016/j.rser.2019.109547.
                                                                                                [88] L. Ashton, Fuelling the future building fuel supply chains for SMRs and advanced
                                                                                                     reactors, IAEA Bull. 64 (3) (2023) 16–17.




                                                                                           20
