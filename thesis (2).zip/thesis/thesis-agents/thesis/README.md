# Thesis agent system (LaTeX output)

## Requirements
- Claude Code
- A TeX distribution: TeX Live or MiKTeX, with latexmk (MiKTeX needs Perl for latexmk)
- Python 3 (only for scripts/make_part2.py)

## Setup
1. Put the 25 paper PDFs in papers/ as P01.pdf ... P25.pdf.
2. Put the Note de Synthèse and current chapters (docx or pdf) in source/.
3. Fill the contribution column in data/part2_papers.csv (co-authored papers).
4. Approve the main message of each chapter in data/main_messages.md (the orchestrator drafts them first).
5. Fill frontmatter/metadata.tex (jury, date) and frontmatter/acknowledgements.tex.
6. Open this folder in Claude Code and say, for example:
   "Mode B. Start the workflow in CLAUDE.md from step 1."

## Build the PDF yourself
./build.sh        (Linux or macOS)
latexmk -pdf main.tex   (any system, then open main.pdf)
Output: output/Memoire.pdf

## Where things end up
- Table of contents, lists of tables and figures: front matter
- References: one list, last section of the PDF
- Reports from the checkers: reports/
