Business Strategy and the Environment




   RESEARCH ARTICLE                    OPEN ACCESS




When Do Robots Go Green? Unveiling Mechanisms,
Thresholds, and Spillovers of Industrial Robotics on Global
Ecological Capacity
Brahim Bergougui1,2,3           | Hamid Ghazi H. Sulimany4
1College of Business & Economics, Qatar University, Doha, Qatar      | 2International Institute of Social Studies (ISS), Erasmus University Rotterdam, The
Hague, the Netherlands |   3National Higher School of Statistics and Applied Economics (ENSSEA), Kolea, Algeria          | 4Accounting Department, Business
Administration College, Taif University, Taif, Saudi Arabia


Correspondence: Brahim Bergougui (bergougui@iss.nl)

Received: 16 October 2025 | Revised: 3 February 2026 | Accepted: 10 February 2026

Keywords: ecological capacity | global value chains | green-­biased innovation | industrial robotics | industrial structure upgrading


  ABSTRACT
  This paper examines the relationship between industrial robotics adoption and ecological capacity, measured by biocapacity,
  using panel data from 50 countries over the period 2000–2024. We investigate the transmission mechanisms, non-­linearities,
  spatial spillovers, and heterogeneity characterizing this relationship. Our empirical analysis yields five principal findings. First,
  industrial robotics demonstrates a positive effect on biocapacity. Second, mechanism analysis reveals that robotics strengthens
  ecological capacity through two primary transmission channels: institutional flexibility via reduced transaction costs and ac-
  celerated green-­biased technological progress, with the latter representing the dominant pathway. Third, threshold regression
  models identify a three-­regime non-­linear relationship: Robotics exhibits modest positive effects at low levels of industrial up-
  grading, counterintuitively adverse effects during the intermediate transition phase, and substantially amplified positive effects
  at advanced stages of industrial upgrading. Fourth, spillover analysis shows that ecological gains from robotics are significantly
  larger in countries with geographic proximity to Japan, the global robotics innovation hub, while trade-­based heterogeneity
  reveals substantially amplified effects in high-­trade economies and significant effects exclusively in countries with deep global
  value chain integration. Fifth, heterogeneity analysis demonstrates that robotics' environmental benefits are greater in high-­
  income countries, those with advanced digital infrastructure, and high-­population-­density economies, while effects are atten-
  uated or negative in low-­income and digitally-­limited contexts. The results imply that policy sequencing—combining robotics
  deployment with structural upgrading, institutional strengthening, skills and infrastructure investments, and strategic trade
  integration—is essential to secure sustained improvements in ecological capacity.
  JEL Classification: O33, Q56, O14, C33


1   |   Introduction                                                                advanced manufacturing technologies to enhance biocapacity
                                                                                    while maintaining economic growth has become critical for
The convergence of biodiversity loss, climate change, and en-                       policymakers and researchers globally (Gabbi et al. 2021). With
vironmental degradation presents unprecedented challenges                           intensifying pressure on ecological reserves and declining per
requiring innovative technological solutions for sustainable                        capita availability of biologically productive resources, the im-
development (Harfouche et al. 2024; van der Woude et al. 2024;                      perative to analyze technological pathways toward environmen-
Bergougui et al. 2026). Understanding how nations can leverage                      tal sustainability has never been more urgent (Xu et al. 2023).


This is an open access article under the terms of the Creative Commons Attribution License, which permits use, distribution and reproduction in any medium,
provided the original work is properly cited.
© 2026 The Author(s). Business Strategy and the Environment published by ERP Environment and John Wiley & Sons Ltd.


Business Strategy and the Environment, 2026; 0:1–24                                                                                                           1
https://doi.org/10.1002/bse.70702
                                                                                                                                                         10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Biocapacity—the central measure of ecological capacity in                   biologically productive areas worldwide, distributed unevenly
this study—quantifies ecosystems' ability to regenerate re-                 across regions and under increasing pressure from human con-
newable resources and absorb waste, measured in global hect-                sumption patterns.
ares (Gha) per person. Specifically, biocapacity encompasses
the productivity of six types of ecological assets: cropland (for           Figure 1 illustrates the global distribution of ecological ca-
food and fiber production), grazing land (for livestock), forest            pacity and industrial robotics in 2024. The upper panel shows
areas (for timber and carbon sequestration), fishing grounds                that biocapacity per person is highest in North America, South
(for aquatic resources), built-­up land (for infrastructure), and           America, Russia, and Australia (3.62–14.76 Gha/person), while
carbon uptake capacity (primarily through forests and oceans                densely populated regions in Asia, Europe, and Africa exhibit
absorbing CO2 emissions). This comprehensive metric, stan-                  lower levels. The lower panel reveals that industrial robot
dardized to world-­average productivity levels, captures both               stocks concentrate in advanced manufacturing economies—
the resource-­generation dimension (how much biological ma-                 particularly North America, Western Europe, East Asia, and
terial ecosystems can produce) and the waste-­absorption di-                China (107,916–380,800 units)—with Japan, the United States,
mension (particularly crucial for climate change mitigation                 Germany, and China leading globally. Notably, an inverse geo-
through carbon sequestration). Unlike narrower indicators                   graphic pattern emerges: biocapacity-­rich regions exhibit min-
such as carbon emissions or ecological footprint that focus on              imal robotics deployment, while robotics-­intensive economies
specific environmental impacts, biocapacity provides a holistic             face constrained ecological capacity. Japan's position as a dom-
measure of a region's overall ecological endowment and regen-               inant robotics innovation hub, despite its moderate biocapacity,
erative ability, making it particularly suitable for assessing how          suggests potential cross-­border knowledge diffusion. This dis-
technological innovations influence comprehensive environ-                  connect motivates our investigation of how industrial robotics
mental sustainability (Gogonea et al. 2020; Bergougui 2025a).               influences ecological capacity and whether proximity to innova-
Global estimates indicate approximately 12 billion hectares of              tion centers amplifies environmental benefits.




FIGURE 1    |    Global distribution of ecological capacity and industrial robotics in 2024. Source: Authors' calculations (Global Footprint Network
2025; IFR).


2                                                                                                          Business Strategy and the Environment, 2026
                                                                                                                                               10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Industrial robotics (INRO) has emerged as a transformative force       Michaels 2018; Acemoglu and Restrepo 2020), this study dis-
in sustainable manufacturing, encompassing automated systems           tinguishes itself by shifting the focus to the biocapacity-­robotics
capable of executing complex production tasks with enhanced            nexus. Specifically, we advance the existing knowledge frontier
precision and environmental optimization (Li et al. 2022; Lee          in four specific dimensions:
et al. 2022; Bergougui 2025a). Contemporary INR technologies
promise revolutionary efficiency gains and resource-­optimization        • First, we expand the analytical scope from the “demand-­side”
capabilities that may fundamentally reshape biocapacity out-               of environmental degradation to the “supply-­side” of ecolog-
comes (Bergougui 2025b, 2025c). By transitioning from resource-­           ical regeneration. Existing studies have extensively docu-
intensive production to precision-­  controlled operations, INR            mented the impact of robotics on energy intensity and carbon
demonstrates the potential to optimize resource utilization,               emissions (Liu et al. 2024; Bergougui 2025c, 2025a). For in-
mitigate environmental challenges, and enhance sustainabil-                stance, Huang et al. (2022) provide robust firm-­level evidence
ity through green innovation and workforce skill optimization.             from China that robot adoption improves energy performance
However, INR integration presents multifaceted implementa-                 through technological efficiency. Similarly, Cheng et al. (2019)
tion challenges (Ghobakhloo et al. 2024; Xia and Ahmad 2025).              comprehensively analyze the rise of robots in China, focusing
Successful deployment requires substantial capital investment,             on productivity and labor outcomes. Our study complements
technical expertise, and specialized workforce capabilities com-           these works by pivoting to biocapacity—a holistic measure
plemented by environmental management competencies (Long                   of the ecosystem's ability to regenerate resources and absorb
et al. 2024). Technical constraints—particularly green technol-            waste. Unlike emission metrics that quantify environmen-
ogy bottlenecks in clean production and circular economy appli-            tal damage, biocapacity quantifies environmental resilience.
cations—combined with uncertain environmental returns may                  By demonstrating that industrial robotics (INRO) not only
deter adoption (Mondal et al. 2023). Market demand uncertainties           reduces the ecological footprint but actively enhances the
for sustainable products, alongside evolving regulatory frame-             regenerative productivity of natural assets (e.g., through pre-
works, create complex decision environments that affect the effec-         cision agriculture and automated forestry management), we
tiveness of strategic planning.                                            provide a more complete picture of sustainability that previ-
                                                                           ous carbon-­centric studies have overlooked.
However, as with the adoption of any transformative technology,
integrating INR into production systems raises complex questions         • Second, we introduce a dual-­mediation framework that inte-
about its environmental implications. While robotics can reduce            grates institutional quality with technological change. Prior
material waste, energy consumption, and emissions through pro-             research has largely treated technological innovation as the
cess optimization, its deployment also entails challenges such as          sole transmission channel. However, the efficacy of robotics is
high capital costs, technological skill requirements, and poten-           deeply embedded in the regulatory environment. Building on
tial rebound effects from increased production capacity (Cannas            the insights of Zhou, Fan, and Gan (2024), who demonstrate
et al. 2024). The environmental benefits of robotics are not auto-         that the impact of robotics on export stability is conditional on
matic; they depend on complementary factors such as government             global value chain (GVC) participation, we argue that envi-
policy, industrial upgrading, and the direction of technological           ronmental outcomes are similarly conditional on institutional
progress. For instance, without effective governance and environ-          adaptability. We empirically verify that government flexibil-
mental regulation, robotics adoption could reinforce unsustainable         ity acts as a critical parallel mediator alongside technological
production patterns or exacerbate resource extraction. Similarly,          progress. This finding bridges the gap between institutional
the environmental gains from robotics may be constrained in                economics and innovation studies, suggesting that the “insti-
economies with outdated industrial structures or limited capacity          tutional software” (governance) is just as critical as the “tech-
for technological innovation. To address these research gaps, this         nological hardware” (robotics) in achieving green transitions.
study develops an integrated analytical framework that simulta-
                                                                         • Third, we elucidate the non-­linear “structural threshold” ef-
neously examines mediation mechanisms, threshold effects, and
                                                                           fect of robotics deployment. While Cheng et al. (2019) high-
spatial spillovers. Using panel data from 50 countries over 2000–
                                                                           light the rapid accumulation of robot stock in developing
2024, we empirically investigate four interconnected research
                                                                           economies, the environmental efficacy of this accumulation
questions: (1) Does INRO directly enhance ecological capacity?
                                                                           remains debated. Our threshold analysis reveals a J-­curve
(2) Do government flexibility and technological progress mediate
                                                                           relationship conditioned by industrial structure upgrad-
this relationship, and what is their relative importance? (3) Does
                                                                           ing. We identify distinct regimes where the environmen-
industrial structure upgrading create threshold effects where ro-
                                                                           tal impact of robotics shifts from modest gains in nascent
botics effectiveness shifts fundamentally at critical upgrading lev-
                                                                           industries to temporary suppression due to “efficiency-­led
els? (4) Does geographic proximity to Japan—the global robotics
                                                                           expansion” (the rebound effect) in transitional industries,
innovation hub—generate spatial spillover effects that moderate
                                                                           and finally to exponential benefits in advanced industrial
the robotics-­ecological capacity relationship? (5) Do international
                                                                           structures. This resolves inconsistencies in the literature by
integration (trade openness and GVC participation) condition the
                                                                           showing that the environmental dividend of automation is
robotics–biocapacity relationship?
                                                                           not monotonic but is contingent on achieving a critical mass
                                                                           of structural sophistication.
1.1   |   Contribution of This Study                                     • Fourth, we pioneer the analysis of transnational spatial
                                                                           spillovers originating from global innovation hubs. Unlike
While a growing body of literature examines the economic                   standard cross-­country regressions that treat nations as
and labor market consequences of automation (Graetz and                    isolated units, we explicitly model the distance-­   decay

Business Strategy and the Environment, 2026                                                                                               3
                                                                                                                                             10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
    diffusion of technology. We provide novel evidence that        reductions in CO2 and greenhouse gas emissions following ro-
    geographic proximity to Japan—the global leader in robot-      botic adoption (Wang et al. 2024; Bergougui 2025b, 2025c; Khan
    ics innovation—significantly amplifies the biocapacity-­       et al. 2025). These reductions primarily result from gains in both
    enhancing effects of robotics in partner countries. This       environmental and economic efficiency, as demonstrated by
    adds a spatial-­economic dimension to the literature, sug-     Wang et al. (2025). Cross-­country analyses provide robust con-
    gesting that the environmental benefits of robotics diffuse    firmation of this relationship: Chen et al. (2022) examined 72
    through cross-­border knowledge networks and regional          countries from 1993 to 2019 and found that AI reduced ecologi-
    value chains.                                                  cal footprints through mechanisms such as time savings, green
                                                                   employment, and energy upgrades, with more potent effects in
The paper proceeds as follows: Section 2 presents a literature     countries with higher human capital and greater economic de-
review and develops the hypotheses. Section 3 describes meth-      velopment (notably OECD economies). Li et al. (2022) similarly
odology and data sources. Section 4 reports empirical results      reported that AI lowered carbon intensity across 35 countries
and analytical discussion. Section 5 presents conclusions and      (1993–2017) by boosting productivity, optimizing production
policy implications for formulating a sustainable development      structures, and fostering innovation—effects that were partic-
strategy.                                                          ularly pronounced in manufacturing, agriculture, and energy
                                                                   sectors of developed nations. Regional studies reinforce this pat-
                                                                   tern: using a spatial Durbin model across 30 Chinese provinces
2   |   Background                                                 (2006–2019), Ding et al. (2023) showed that AI development
                                                                   effectively reduces CO2 emissions and that these benefits were
The relationship between INRO and environmental outcomes           unexpectedly more substantial in central and western China
has emerged as a critical area of scholarly inquiry, particu-      than in the eastern provinces—likewise, Chen et al. (2023) used
larly as nations worldwide pursue sustainable development          quasi-­experimental methods on 282 Chinese cities (2008–2019)
goals while maintaining economic competitiveness. This lit-        to confirm that AI implementation accelerates CO2 reduction
erature review synthesizes existing research on how INRO in-       and progress toward carbon neutrality.
fluences various environmental metrics, revealing a complex
landscape of both beneficial and detrimental effects. Notably,     These carbon-­centric gains naturally extend to other dimen-
while extensive research has examined traditional environ-         sions of environmental quality—most notably air pollution.
mental indicators such as carbon emissions, air pollution, and     The optimistic perspective, therefore, also highlights improve-
ecological footprints, a significant gap exists in understand-     ments in air quality, particularly reductions in sulfur dioxide
ing the relationship between INRO and biocapacity—a crucial        (SO2). Evidence on SO2 is consistently positive: Kshirsagar and
measure of ecosystem regenerative capacity that remains un-        Shah (2022) argue that INRO enhances the prediction and mon-
explored in this context.                                          itoring of SO2 emissions, which contributes to better environ-
                                                                   mental performance through more effective control systems.
The theoretical foundation for understanding INRO's environ-       Several empirical studies (Chu et al. 2024; Zhou, Zhuang, and
mental impact stems from two competing perspectives. The           Chen 2024) documented negative relationships between robotic
technological optimism view, supported by early studies such       adoption and air pollution, with reductions in SO2 commonly
as those of Butler et al. (2018) and Dobbe et al. (2018), empha-   reported. For particulate matter (PM2.5), a growing literature
sizes robotics' potential to optimize production processes, re-    also supports the beneficial effects of robotics and related AI
duce waste, and enhance energy efficiency. Conversely, the         methods: Chen et al. (2025) show that INRO and machine learn-
technological skepticism perspective, exemplified by Strubell      ing tools can both predict and mitigate PM2.5 concentrations,
et al. (2020), who documented substantial carbon emissions         while Chu et al. (2024) find that improved process control and
from AI training processes, highlights the direct environmental    monitoring enabled by robotics are central to observed PM2.5
costs of these technologies. This foundational debate has shaped   improvements.
subsequent empirical investigations. Strubell et al. (2020) pro-
vided pioneering evidence that training a single large natural     Finally, the magnitude and consistency of these environmen-
language model could emit as much carbon dioxide as five cars      tal benefits vary by sector and region, producing notable suc-
over their lifetimes, fundamentally altering discourse around      cess stories where context amplifies impact. Sectoral evidence
AI's environmental implications. Their work catalyzed exten-       indicates that high-­polluting industries and energy-­intensive
sive research examining AI's environmental footprint, with         manufacturing tend to register larger CO2 reductions after
Schwartz et al. (2020) documenting a 300,000-­fold increase in     adopting intelligent technologies: For example, Lv et al. (2022)
computation requirements for advanced AI systems between           find meaningful declines in industrial CO2 emissions in
2012 and 2018.                                                     China (2000–2017) driven by intelligent industrial manu-
                                                                   facturing, especially in industries reliant on primary fossil
                                                                   fuels. Firm-­level studies corroborate this: Song et al. (2023)
2.1   |   The Optimistic View: Robotics as a Catalyst              show that Chinese firms adopting automation and intelli-
for Environmental Improvement                                      gent technologies—often in response to tighter environmen-
                                                                   tal regulation—significantly strengthen their environmental
Beginning with carbon emissions reduction, a substantial body      management. City-­level analyses further illustrate the spatial
of empirical evidence supports INRO's potential to reduce emis-    concentration of benefits: Yu et al. (2023), using IFR industry
sions, positioning it as an important catalyst for environmental   data (2010–2018), report substantial CO2 reductions in cities
improvement. Multiple studies have documented significant          that implemented AI technologies, with the most significant

4                                                                                              Business Strategy and the Environment, 2026
                                                                                                                                             10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
impacts in large urban centers, advanced manufacturing                 2.3   |   Robotics, GVCs, and Environmental
hubs, and designated low-­c arbon zones. Taken together, these         Implications
findings suggest that robotics delivers the most significant
environmental returns in contexts with complementary capa-             An emerging yet underexplored dimension of the robotics-­
bilities—advanced infrastructure, skilled labor, and targeted          environment nexus concerns how automation technologies in-
policy support—which help translate technological adoption             teract with international trade patterns and GVCs to influence
into measurable environmental gains.                                   environmental outcomes. Recent theoretical and empirical ad-
                                                                       vances suggest that industrial robotics may enhance ecological
                                                                       capacity not only through direct efficiency gains but also through
2.2   |   The Critical View: Robotics as a Source                      fundamental restructuring of production geography and trade
of Environmental Pressure                                              relationships. Zhou, Fan, and Gan (2024) demonstrate that in-
                                                                       dustrial robot adoption significantly alters countries' export sta-
The critical perspective challenges the optimistic narrative by        bility and GVC participation patterns, with automation enabling
emphasizing the environmental costs associated with wide-              firms to reduce dependence on imported intermediate goods
spread INRO deployment. A core concern is electricity con-             through reshoring and nearshoring of production activities. This
sumption: Luan et al. (2022) note that many robotic systems and        reconfiguration of production geography carries profound en-
automated production lines demand substantial power, which             vironmental implications. When robotics enables high-­income
can increase greenhouse gas emissions—especially in coun-              countries to reshore manufacturing activities previously off-
tries or regions where electricity generation remains carbon-­         shored to regions with weaker environmental regulations, the
intensive. This point underscores the need to look beyond direct       net global environmental impact depends critically on the rel-
emissions and to account for indirect effects that depend cru-         ative pollution intensity of production locations (Shapiro 2021).
cially on the local energy mix.                                        Shapiro's analysis of the environmental bias in trade policy re-
                                                                       veals that international trade patterns systematically disadvan-
Closely related to energy use are the computational demands            tage environmental quality when production migrates toward
of AI and robotics systems, which have grown rapidly. Strubell         countries with lax environmental standards—a phenomenon
et al. (2020) showed that training a single large natural-­language    robotics-­driven reshoring could potentially reverse.
model can produce a carbon footprint comparable to several cars
over their lifetimes, and subsequent work by Schwartz et al. (2020)    The GVC repositioning mechanism operates through several
documented an exponential rise in computation requirements             channels relevant to biocapacity. First, automation reduces
for advanced AI between 2012 and 2018. These findings shift the        the labor-­ cost advantage that historically drove production
focus from device-­level electricity consumption to the broader        offshoring to developing economies, potentially enabling ad-
lifecycle and infrastructure costs of AI: data centers, model train-   vanced economies to recapture manufacturing activities in
ing, and continuous updates all add to the sector's energy burden.     cleaner, more regulated production environments (De Backer
                                                                       et al. 2018). Second, robotics integration may facilitate vertical
Empirical evidence, therefore, appears mixed and highly context-­      integration of supply chains, reducing transportation-­intensive,
dependent. Zhong et al. (2024), using quantile regressions across      fragmented production networks and associated emissions from
66 countries (1993–2019), find that robotics and AI can both de-       international freight (Baldwin and Venables 2013). Third, the
crease and increase CO2 emissions depending on factors such as         precision and monitoring capabilities of robotic systems align
national income and industrial structure; notably, the carbon-­        well with stringent environmental compliance requirements
reducing effect of AI weakens in economies with larger second-         that characterize advanced economies, potentially concentrating
ary (manufacturing) sectors and is stronger in countries with          pollution-­intensive production stages in countries with superior
older populations. These heterogeneous results indicate that           environmental governance (Copeland et al. 2022).
technological adoption alone does not guarantee environmental
gains—complementary conditions matter.                                 However, the environmental consequences of robotics-­induced
                                                                       GVCs restructuring remain theoretically ambiguous. If reshor-
This context dependence is evident in studies of particulate mat-      ing primarily affects cleaner production stages while pollution-­
ter. For example, Luan et al. (2022) argue that increased robot        intensive processes remain offshore, the net environmental
usage can directly raise PM2.5 emissions in specific produc-           benefit may be limited. Alternatively, if automation enables ad-
tion settings, undermining environmental performance. Such             vanced economies to reclaim pollution-­intensive manufacturing
contradictory findings for PM2.5 (and other pollutants) suggest        under stringent environmental regulation, global environmental
that whether robotics improves or harms air quality depends on         outcomes could improve substantially (Antràs and Chor 2022).
specific production processes, the energy sources that power           The spatial spillover effects we identify—where proximity to
them, and the regulatory environment that governs emissions            robotics innovation hubs, such as Japan, generates larger eco-
controls.                                                              logical benefits—may operate partially through enhanced
                                                                       integration into regional value chains that embody superior en-
Taken together, the critical literature stresses that the environ-     vironmental standards. For countries in our sample, the inter-
mental consequences of robotics are not uniform: they hinge on         action between robotics adoption and GVC participation likely
the energy mix, computational infrastructure, industry compo-          influences biocapacity through several pathways: (1) reduced re-
sition, and governance. Recognizing this complexity is essential       liance on imports from high-­pollution trading partners through
for crafting policies that steer robotics and AI toward net envi-      automation-­enabled domestic production; (2) repositioning to-
ronmental benefits rather than inadvertent harm.                       ward less pollution-­intensive stages within existing value chains;

Business Strategy and the Environment, 2026                                                                                             5
                                                                                                                                                           10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
FIGURE 2    |    Conceptual framework for industrial robotics and ecological capacity.



(3) enhanced bargaining power to demand environmental stan-                 spillover effects that amplify the impact of industrial robotics on
dards from remaining trading partners; and (4) accelerated adop-            ecological capacity through knowledge diffusion and technology
tion of clean production technologies through integration into              transfer.
robotics-­intensive regional value chains. These dynamics suggest
that robotics' environmental benefits may be amplified in econo-            H5. (International integration moderation): The effect of in-
mies heavily integrated into international trade networks, where            dustrial robotics on ecological capacity is conditional on interna-
automation facilitates strategic repositioning toward environ-              tional economic integration, with stronger positive effects observed
mentally advantageous production configurations.                            in countries with higher trade openness and deeper participation
                                                                            in GVCs.

2.4   |   Research Hypotheses                                               This framework depicts the theoretical pathways linking indus-
                                                                            trial robotics to ecological capacity. The model encompasses
Building on the mechanistic analysis and the theoretical links              (Figure 2): (1) a direct effect of robotics on biocapacity, (2) two
identified above, we formulate four testable hypotheses:                    mediation channels—government flexibility and technological
                                                                            progress, (3) industrial structure upgrading as a threshold mod-
H1. (Direct effect): Industrial robotics (INRO) adoption has a              erator, and (4) spatial spillover effects from geographic proximity
positive and significant effect on ecological capacity (biocapacity).       to robotics innovation centers. The framework provides the ana-
                                                                            lytical foundation for hypothesis testing.
H2. (Mediation mechanisms): The positive effect of industrial
robotics on ecological capacity is mediated through (a) enhanced
government flexibility and (b) accelerated technological progress,          3   |   Methodological Framework
with technological progress constituting the dominant transmis-
sion channel.                                                               3.1   |   Theoretical Model

H3. (Threshold effects): The impact of industrial robotics on               3.1.1   |   Baseline Regression Model
ecological capacity is non-­linear and subject to threshold effects
associated with industrial structure upgrading, such that the               This investigation establishes a comprehensive theoretical
magnitude and direction of the effect differ across low, intermedi-         framework to analyze the relationship between INRO and bio-
ate, and advanced stages of industrial upgrading.                           capacity per capita. The foundational econometric model is for-
                                                                            mulated as follows:
H4. (Spatial spillover effects): Geographic proximity to Japan,
as the global hub of robotics innovation, generates positive spatial                     BIOit = 𝛼 0 + 𝛼 1 INROit + 𝛼 2 Xit + 𝛾 i + ϑt + 𝜀it        (1)

6                                                                                                            Business Strategy and the Environment, 2026
                                                                                                                                                   10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
where subscript i denotes individual nations and subscript t                  productivity benchmarks, thereby illustrating ecosystems'
represents temporal periods; BIO constitutes the dependent                    ability to replenish resources amid human consumption pres-
variable measuring biocapacity per capita; INRO signifies the                 sures (Bergougui 2025d, 2025a; Meziane and Bergougui 2026).
explanatory variable representing INRO development; X en-                     Commonly applied in environmental assessments, it high-
compasses a comprehensive vector of control variables; 𝛾 i cap-               lights the equilibrium—or lack thereof—between natu-
tures unobserved country-­specific heterogeneity through fixed                ral supply and human ecological demands (Moros-­         Ochoa
effects; 𝜗t controls for time-­invariant temporal dynamics; and               et al. 2022). Our choice stems from pressing global issues
𝜀it represents the idiosyncratic error component. This specifi-               like climate change, habitat destruction, and resource deple-
cation follows established econometric practices in panel data                tion, which increasingly threaten societal stability, economic
analysis, incorporating robust standard errors clustered at the               growth, and ecological integrity at multiple scales.
national level to address potential heteroscedasticity and serial
correlation concerns (Gao and Wang 2025). Thus, making the
regression estimates consistent and reliable.                                 3.2.2   |   Core Predictor: Industrial Robots (INRO)

                                                                              The extent of industrial robot integration stands as our key in-
3.1.2   |   Mediating Model                                                   dependent variable, proxying for advancements in manufac-
                                                                              turing efficiency and technological maturity across economies.
To comprehensively examine the underlying transmission                        We derive this from the International Federation of Robotics
mechanisms, we adopt a mediation analysis framework follow-                   repository, calculating the total active robots per 1000 workers
ing contemporary empirical methodologies. The mechanism                       in manufacturing sectors (Bergougui 2025b, 2025c, 2025a). This
testing employs a two-­stage approach:                                        metric offers distinct benefits:

           MEDit = 𝛽 0 + 𝛽 1 INROit + 𝛽 2 Xit + 𝛾 i + 𝜗t + 𝜀it          (2)    • It emphasizes real-­world implementation over potential or
                                                                                 planned investments.

            BIOit = 𝜌0 + 𝜌1 MEDit + 𝜌2 Xit + 𝛾 i + 𝜗t + 𝜀it             (3)    • Its emphasis on manufacturing mirrors the predominant
                                                                                 use cases for robotic systems.
In this framework, MED represents the mediating variables                      • Normalization by workforce size accounts for differences
encompassing government regulation and green patents. The                        in national labor pools. For sensitivity analyses, we incor-
mediation effect is established when 𝛽 1 and 𝜌1are statistically                 porate substitute proxies such as yearly robot additions and
significant, indicating that INR influences BIO through these                    overall installation trends (Lee et al. 2022), which shed light
intermediary channels.                                                           on the varying speeds of adoption and the spread of innova-
                                                                                 tion over time.

3.1.3   |   Threshold Model
                                                                              3.2.3   |   Mediating Variables
We further examine whether the relationship is contingent on
a nation's commitment to climate policy, measured by its levels                • Government flexibility: Drawing from the World
of climate change adaptation and mitigation. For this purpose,                   Bank's Worldwide Governance Indicators (Kaufmann
we employ a panel threshold model (Hansen 1999). The model                       et al. 2011), we construct a governance index by averag-
is specified as follows:                                                         ing six key pillars: citizen participation and accountabil-
BIOit = 𝜌0 + 𝜌1 INROit ⋅ I(Thre ≤ 𝛾) + 𝜌2 INROit I(Thre > 𝛾) + 𝜌3 Xit + 𝜀it      ity, political stability without violence, administrative
                                                                                 efficacy, oversight standards, legal adherence, and anti-­
                                                                        (4)
                                                                                 corruption measures. Scores span from −2.5 (poorest
                                                                                 performance) to 2.5 (optimal), with equal weighting per
Here, Thre is the threshold variable (industrial structure upgrad-
                                                                                 pillar as per standard methodologies (Song et al. 2024).
ing), 𝛾 is the estimated threshold value, and I(·) is the indicator
                                                                                 Elevated scores signify robust institutional environments.
function. This specification allows the effect of INROit on BIOit
                                                                                 This variable is grounded in the premise that strong gov-
to differ based on whether the threshold variable is above or
                                                                                 ernance supports the formulation, execution, and moni-
below the estimated value 𝛾 .
                                                                                 toring of policies that bolster energy reliability, enabling
                                                                                 strategic investments, crisis management, and efficient
                                                                                 resource allocation.
3.2   |   Dataset Assembly and Variable Definitions
                                                                               • Green-­biased technological innovation: Aligned with
3.2.1   |   Outcome Measure                                                      our theoretical framework, we designate green energy tech-
                                                                                 nological progress (TP) as a mediator, quantified through
We select per capita biocapacity, denoted BIO, in global                         patent filings in green energy domains. This captures tan-
hectares (Gha) as our primary outcome variable. This index                       gible results from R&D efforts, consistent with prior litera-
quantifies the biologically productive terrestrial and aquatic                   ture (Song et al. 2024). Data are sourced from the WIPO and
areas available to each individual, normalized to global                         OECD patent archives.



Business Strategy and the Environment, 2026                                                                                                   7
                                                                                                                                                          10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 1    |    Descriptive statistics and multicollinearity test.

    Code                                     Variable                  Mean                SD                Min.               Max.               VIF
    BIO                    Biocapacity (Gha per person) (LOG)          1.205             0.714               0.030               2.932             1.31
    INRO                                 Industrial robotics           0.020             0.078               0.000               0.783             3.00
    INCOME                          GDP per person (LOG)               0.211             0.184               0.004               0.809             4.15
    POP                                  Population (LOG)              16.832            1.564              12.874              21.065             1.80
    EMP                                 Employment (LOG)               0.561             0.086               0.350               0.806             1.25
    FDI                                 Foreign investment             0.057             0.216              −0.401               4.491             1.10
    EXR                                 Exchange rate (LOG)            0.008             0.041               0.000               0.420             1.24
    INF                                      Inflation                 0.043             0.078              −0.045               1.686             1.35
    GOV                             Government flexibility             2.431             0.523             −0.408                3.076             3.93
    TP                   Green-­biased technological innovation        0.002             0.009               0.000               0.106             2.68
    INDSU                        Industrial structure (LOG)            14.869            0.925              12.495              16.865             4.27
Note: VIF: variance inflation factor.



                                                                        TABLE 2    |    Basic regression results.
3.2.4   |   Threshold Variable
                                                                                                                Dependent variable:
    • Industrial structure upgrading: This variable (INDSU)                                                    Biocapacity per person
      tracks shifts toward higher-­value sectors, from agriculture        Variables                              (1)                         (2)
      to services, alongside productivity gains. It encapsulates
      broader transformations in production paradigms that may            INRO                                0.065***                   0.038***
      influence environmental outcomes (Chang et al. 2023).                                                    (5.264)                    (3.331)

Table 1 summarizes the key descriptive metrics for our dataset.           INCOME                                                         −0.176***
Based on Table 1, the VIF values indicate that multicollinearity                                                                         (−4.577)
is not a serious concern in this analysis. All VIF values remain
well below the conventional threshold of 5, with the highest              POP                                                            −0.542***
being 4.27 for industrial structure, followed by 4.15 for income.                                                                        (−22.187)
The majority of variables exhibit VIF values below 3, suggesting
                                                                          EMP                                                            0.194***
minimal correlation among the explanatory variables.
                                                                                                                                          (3.111)
                                                                          FDI                                                              0.006
4   |   Empirical Results and Discussion
                                                                                                                                          (1.579)
4.1   |   Baseline Regression Analysis                                    EXR                                                             −0.020

Table 2 presents the fundamental regression outcomes investi-                                                                            (−0.475)
gating how INRO affects biocapacity as measured by biocapacity            INF                                                             −0.014
per capita. The progressive specification methodology enables
robustness assessment across varying control variable config-                                                                            (−0.846)
urations. The unconditional relationship in Column (1) yields             Constant                            1.203***                   10.249***
a coefficient of 0.065. Given the log-­linear specification of our
model, this indicates that a one-­unit increase in industrial robot-                                          (641.618)                   (25.662)
ics density is associated with an approximately 6.5% increase in          Country FE                              ✓                           ✓
biocapacity per capita. This positive semi-­elasticity suggests that
automation technologies contribute to biocapacity by improv-              Time FE                                 ✓                           ✓
ing resource efficiency and reducing environmental pressures              Observations                          1250                        1250
relative to economic output. The strong statistical significance
                                                                          R-­squared                            0.987                      0.990
provides initial evidence for a meaningful relationship between
manufacturing automation and environmental outcomes.                    Note: Reported t-­statistics (in parentheses) are computed using country-­level
                                                                        clustered standard errors. Significance levels are denoted as follows:
                                                                        *p < 0.10
After incorporating comprehensive demographic, economic,                **p < 0.05, and
and international control variables in Column (2), the INRO             ***p < 0.01.



8                                                                                                          Business Strategy and the Environment, 2026
                                                                                                                                          10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
coefficient remains positive and significant at 0.038. This im-        • The instrumental variable approach in Column (1) yields a
plies that, ceteris paribus, robotics adoption generates a 3.8%          coefficient of 0.038, virtually identical to the baseline OLS
improvement in ecological capacity for every unit increase in            result. This remarkable consistency suggests minimal en-
robot density. While the magnitude reduction indicates some              dogeneity bias in the original specification, providing strong
confounding from observable factors, the persistent significance         support for the causal interpretation of robotics' positive
confirms the robustness of the core proportionate relationship.          impact on biocapacity. The IV-­GMM estimation addresses
The inclusion of fixed effects captures unobserved country-­             concerns about reverse causality or omitted-­variable bias
specific characteristics and standard temporal shocks that might         that could confound the relationship.
otherwise bias the estimates.
                                                                       • Column (2) employs robot installation flows rather than
                                                                         stock measures, producing a coefficient of 0.192. The sub-
While our analysis employs aggregate biocapacity as the de-
                                                                         stantially larger magnitude reflects how flow measures cap-
pendent variable, robotics likely generates differential impacts
                                                                         ture immediate adoption effects and technology diffusion
across the six constituent ecological assets. We theorize that
                                                                         dynamics, while maintaining the positive significance pat-
carbon uptake capacity serves as the primary beneficiary, as
                                                                         tern observed in the baseline specifications. This alternative
robotics-­driven emission reductions and renewable energy man-
                                                                         measurement approach confirms that the relationship holds
ufacturing create substantial atmospheric absorption gains. By
                                                                         across different conceptualizations of robotics deployment.
optimizing power consumption in real time (Duflou et al. 2012)
and lowering the production costs of green energy technologies         • The temporal lag structure examined in Column (3) shows
(Acemoglu et al. 2012), automation effectively reduces the forest        that the one-­period lagged robotics variable yields 0.038,
area required to sequester national emissions, thereby expand-           identical to contemporaneous effects. This temporal per-
ing the effective biocapacity reserve.                                   sistence indicates lasting benefits of robotics deployment
                                                                         on biocapacity, suggesting that automation investments
Cropland and forest land likely experience moderately positive           generate sustained rather than merely temporary envi-
effects through “Precision Agriculture” and “Forestry 4.0” prac-         ronmental improvements. The consistency across time
tices. Technologies such as autonomous soil monitoring and ro-           periods strengthens the interpretation of a genuine causal
botic harvesters enhance bioproductivity (yield per hectare) by          relationship.
minimizing soil degradation and optimizing input use (Finger
                                                                       • After applying 1% winsorization for outlier treatment in
et al. 2019), while automated planting systems improve forest
                                                                         Column (4), the coefficient becomes 0.116, actually stron-
density and health (Müller et al. 2019). Conversely, built-­up
                                                                         ger than baseline results. This finding suggests that outliers
land expansion for robotic infrastructure contributes negatively,
                                                                         were not driving the core relationship and may have been
partially explaining the negative direct effect identified in our
                                                                         masking even stronger positive effects. The robustness to
mediation analysis. The construction of automated fulfillment
                                                                         outlier treatment provides additional confidence in the reli-
centers and data centers necessitates land conversion, often dis-
                                                                         ability of the estimated relationship.
placing fertile arable land and creating a “displacement effect”
on aggregate biocapacity (Seto et al. 2012). This negative channel
                                                                     This stability across different model specifications reinforces
is compounded by the resource intensity of AI-­supporting infra-
                                                                     confidence in the overall empirical approach and the validity of
structure, including elevated water consumption for cooling and
                                                                     the estimated relationships.
substantial carbon emissions from electricity generation (Siddik
et al. 2021; de Vries-­Gao 2026).
                                                                     These robustness checks collectively support the reliability and
                                                                     validity of the core empirical findings across multiple specifica-
Regarding the remaining assets, fishing grounds present am-
                                                                     tion variations and potential confounding factors.
biguous impacts depending on governance quality; while un-
derwater drones improve stock monitoring, automated catch
efficiency risks accelerating depletion if not strictly regulated
(Dunn et al. 2018). Grazing land currently shows minimal di-         4.3   |   Mechanism Analysis Framework
rect technological penetration, with impacts confined largely to
dairy facilities rather than open land management (Eastwood          The mediation analysis reveals three primary pathways through
et al. 2012). This heterogeneity suggests that robotics subsidies    which INRO enhances biocapacity, providing critical insights
should prioritize carbon-­centric applications while implement-      into the underlying processes driving the observed relation-
ing safeguards against land-­intensive infrastructure expansion.     ship. These findings contribute to the growing literature on the
Future research should empirically decompose these sub-­             technology-­environment nexus by identifying specific trans-
component effects to identify asset-­specific thresholds and tar-    mission mechanisms that explain how automation technologies
geted policy interventions.                                          translate into measurable environmental outcomes (Graetz and
                                                                     Michaels 2018; Acemoglu and Restrepo 2020).

4.2   |   Robustness Procedures
                                                                     4.3.1   |   Institutional Flexibility and Transaction
Table 3 demonstrates comprehensive robustness testing ad-            Cost Reduction
dressing potential econometric concerns, including endog-
eneity, measurement error, temporal dynamics, and outlier            The governance pathway demonstrates how automation tech-
sensitivity.                                                         nologies enhance institutional capacity by fundamentally

Business Strategy and the Environment, 2026                                                                                          9
                                                                                                                                                                           10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 3    |    Robustness tests.

                                                              Dependent variable: Biocapacity per person
  Variable                       IV-­GMM (1)            Robot installations (2)               Lagged effect (3)            Outlier treatment (4)            LCF (5)
  INRO                              0.038***                                                                                                               0.305***
                                     (3.210)                                                                                                                (10.258)
  INRO(robot installations)                                        0.192***
                                                                    (3.329)
  INRO(t-­1)                                                                                        0.038***
                                                                                                     (3.279)
  INRO(Outlier treatment)                                                                                                            0.116***
                                                                                                                                      (4.032)
  Control                               ✓                              ✓                                 ✓                                ✓                    ✓
  Country FE                            ✓                              ✓                                 ✓                                ✓                    ✓
  Time FE                               ✓                              ✓                                 ✓                                ✓                    ✓
  N                                   1200                           1250                              1200                             1250                  1250
  Adj-­R 2                            0.500                          0.996                            0.996                            0.996                 0.991
Note: Reported t-­statistics (in parentheses) are computed using country-­level clustered standard errors. Significance levels are denoted as follows:
*p < 0.10
**p < 0.05, and
***p < 0.01.


reducing the transaction and compliance costs associated                                 accelerate permitting processes, and adopt risk-­based rather
with environmental protection. Drawing on transaction cost                               than prescriptive regulatory approaches—reforms that reduce
economics (Williamson 1979; Coase 2013), we argue that ro-                               compliance costs not only for robotics adopters but across the
botics adoption does not merely correlate with better gover-                             entire industrial ecosystem (Coglianese and Nash 2001). The
nance but actively catalyzes regulatory reforms that lower the                           fiscal resources generated through enhanced productivity in
institutional barriers to environmental sustainability. This                             robotics-­intensive sectors further enable governments to in-
reframing positions institutional flexibility not as a passive                           vest in institutional capacity—training environmental inspec-
byproduct but as an active mechanism through which robot-                                tors, upgrading monitoring infrastructure, and developing
ics transforms environmental governance. INRO adoption sig-                              evidence-­based policy frameworks (Evans and Rauch 1999).
nificantly improves government flexibility with a first-­stage                           Third, the knowledge infrastructure created by robotics im-
coefficient of 0.202, consistent with theoretical predictions                            plementation fundamentally reduces information costs in
that technological advancement reduces institutional friction.                           environmental governance. Advanced manufacturing sys-
This relationship reflects several interconnected transaction-­                          tems generate granular data on material flows, energy con-
cost-­reduction mechanisms. First, the digitalization inherent                           sumption patterns, and process efficiencies that enable what
in modern robotic systems generates comprehensive, real-­                                scholars term “smart governance”—regulatory approaches
time operational data that drastically reduces monitoring                                that leverage big data and analytics for continuous policy opti-
costs for environmental regulators (Laffont and Tirole 1993).                            mization rather than static, one-­size-­f its-­a ll rules (Gil-­Garcia
Traditional environmental oversight relies on costly inspec-                             et al. 2013). This data infrastructure reduces the costs of identi-
tions, self-­reporting subject to manipulation, and ex post en-                          fying optimal environmental policies, targeting interventions
forcement—all characterized by high transaction costs and                                where they are most effective, and evaluating policy outcomes
information asymmetries between regulators and regulated                                 in near-­real-­time. The reduction in policy uncertainty rep-
entities. Robotic systems, equipped with IoT sensors and au-                             resents a substantial decrease in the transaction costs that
tomated data collection, create transparent, verifiable records                          typically impede environmental innovation and investment
of resource consumption, waste generation, and emissions                                 (Pindyck 1991). Fourth, robotics adoption correlates with
in real-­time, effectively transforming environmental com-                               workforce skill upgrading that strengthens citizen demand for
pliance from a costly, adversarial process into an automated,                            institutional quality and environmental protection. As work-
low-­friction system (Porter and Heppelmann 2014). Second,                               ers transition from routine manual tasks to supervisory and
robotics-­d riven automation creates strong demand-­side pres-                           programming roles, their increased human capital correlates
sure for regulatory modernization and institutional streamlin-                           with greater awareness of environmental issues and stronger
ing. Technology-­intensive industries require clear, predictable                         preferences for effective governance (Dasgupta et al. 2002).
regulatory frameworks to justify capital-­intensive automation                           This creates bottom-­up pressure for institutional reform that
investments (Acemoglu and Robinson 2019). This demand                                    complements the top-­down efficiency gains described above,
incentivizes governments to reduce bureaucratic complexity,                              generating a virtuous cycle of governance improvement.

10                                                                                                                           Business Strategy and the Environment, 2026
                                                                                                                                          10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
The second-­stage results confirm that enhanced government            institutional frameworks adapt to leverage the transparency and
flexibility significantly increases biocapacity with a coefficient    efficiency gains that automation technologies enable.
of 0.033. This finding validates extensive literature demonstrat-
ing that institutional quality constitutes a critical determinant
of environmental outcomes (La Porta et al. 1999; Kaufmann             4.3.2   |   Green-­Biased Technological Innovation
et al. 2011). Lower transaction costs in environmental gover-
nance translate into measurable ecological benefits through           The technological progress pathway emerges as the dominant
several channels:                                                     transmission mechanism linking INRO to biocapacity, but
                                                                      the nature of this innovation is not technologically neutral.
  • Improved property rights and resource management:                 Rather, we argue that robotics adoption catalyzes specifically
    Reduced institutional friction enables more precise defi-         green-­biased technological change—innovation directed to-
    nition and enforcement of property rights over natural            ward developing and adopting environmentally friendly pro-
    resources, addressing the tragedy of the commons that             cesses and products. This theoretical distinction, rooted in
    often drives environmental degradation (Ostrom 2009;              directed technical change theory (Acemoglu 2002a, 2002b;
    Barbier 2019). When monitoring and enforcement costs de-          Aghion et al. 2016), explains why robotics generates dispro-
    cline, sustainable resource management becomes econom-            portionate environmental benefits relative to technological
    ically viable even for resources previously characterized by      progress. The first-­stage results reveal that INRO strongly
    open-­access problems.                                            promotes green patent innovation with a coefficient of 0.116,
                                                                      providing empirical support for the directed nature of robotics-­
  • Enhanced policy coordination: Lower compliance costs
                                                                      induced innovation. Our measurement strategy—using green
    facilitate coordination of sustainability initiatives across
                                                                      energy patents specifically rather than total patents—inten-
    different sectors, government levels, and jurisdictions—
                                                                      tionally captures this environmental bias in technological
    addressing what scholars term the “environmental pol-
                                                                      change. The exceptionally robust relationship demonstrates
    icy integration” challenge (Lafferty and Hovden 2003).
                                                                      that automation generates significant technological spillovers
    Robotics-­generated data infrastructure provides common
                                                                      specifically in environmental domains, not merely general in-
    information foundations that reduce coordination costs
                                                                      novation. This green bias operates through several intercon-
    among multiple stakeholders.
                                                                      nected mechanisms that structurally orient robotics-­induced
  • Accelerated environmental innovation: Reduced reg-                innovation toward sustainability applications.
    ulatory uncertainty and streamlined approval processes
    lower the transaction costs of environmental innovation,            • Embedded energy optimization in robotic systems:
    encouraging firms to invest in novel sustainability solu-             Modern industrial robots are inherently energy-­intensive
    tions (Porter and van der Linde 1995). When compliance be-            capital goods whose operational costs depend critically
    comes automated and predictable rather than discretionary             on power consumption. This creates strong economic
    and costly, firms can focus resources on innovation rather            incentives for robotics manufacturers and adopters to
    than navigating bureaucratic complexity.                              prioritize energy efficiency improvements—not for en-
                                                                          vironmental reasons per se, but for cost minimization
  • More efficient environmental markets: Lower trans-
                                                                          (Duflou et al. 2012). However, the learning-­by-­doing gen-
    action costs enable development of sophisticated envi-
                                                                          erated through solving energy optimization challenges in
    ronmental markets (emissions trading, payments for
                                                                          robotic applications creates knowledge spillovers applicable
    ecosystem services) that require substantial institutional
                                                                          to broader environmental technology domains. Engineers
    infrastructure and monitoring capabilities (Stavins 2003).
                                                                          developing energy-­efficient servo motors, adaptive control
    Robotics-­generated data reduces the costs of measure-
                                                                          algorithms, and regenerative braking systems for robots
    ment, reporting, and verification—traditionally the most
                                                                          accumulate expertise directly transferable to renewable en-
    expensive components of market-­   based environmental
                                                                          ergy systems, electric vehicle technologies, and grid optimi-
    policies.
                                                                          zation applications (Brunnermeier and Cohen 2003). Thus,
                                                                          the green bias emerges from the inherent economic logic of
The calculated mediation effect of 0.202 × 0.033 = 0.0067 ac-
                                                                          automation rather than requiring explicit environmental
counts for approximately 18% of the total robotics effect on bio-
                                                                          motivation.
capacity. While secondary to the technological progress channel,
this institutional pathway represents a crucial complementary           • Data infrastructure enabling environmental moni-
mechanism. The transaction-­cost framework reveals that robot-            toring innovation: The sensor networks, data collection
ics enhances environmental outcomes not only through direct               systems, and analytical capabilities required for robotic
technical improvements but also by reducing the institutional             operation create a technological platform with direct ap-
friction that traditionally impedes environmental protection.             plications in environmental monitoring and management.
This finding carries important policy implications: strategies            Robotics integration necessitates real-­time tracking of ma-
promoting industrial automation should simultaneously target              terial flows, energy consumption, process parameters, and
institutional modernization that capitalizes on robotics' potential       quality metrics—precisely the information infrastructure
to reduce governance costs. Investments in digital government             needed for sophisticated environmental management sys-
infrastructure, regulatory modernization, and evidence-­based             tems (Porter and Heppelmann 2014). The same IoT sen-
policymaking represent high-­return complements to robotics               sors monitoring robotic performance can detect emissions
promotion, amplifying environmental benefits by ensuring that             anomalies, identify energy waste, and optimize resource


Business Strategy and the Environment, 2026                                                                                         11
                                                                                                                                                 10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
     utilization. Consequently, robotics deployment creates a          the institutional flexibility channel. Green innovations directly
     natural pathway toward what Acemoglu (2002b) terms                contribute to biocapacity through multiple channels: renewable
     “directed technical change”—where the trajectory of inno-         energy system development reducing fossil fuel dependence and
     vation systematically favors technologies complementary           associated land degradation; resource efficiency improvements
     to existing capital investments, in this case environmental       through advanced materials and process optimization technol-
     monitoring and optimization tools.                                ogies that reduce pressure on cropland and forests; pollution
                                                                       reduction technologies addressing chemical contamination of
  • Circular economy and material efficiency impera-
                                                                       agricultural land and aquatic ecosystems; and enhanced envi-
    tives: Advanced robotic systems enable precision man-
                                                                       ronmental monitoring capabilities enabling precision ecosystem
    ufacturing that minimizes material waste, facilitates
                                                                       management and restoration (Turner et al. 2015).
    product disassembly for recycling, and enables closed-­loop
    production systems characteristic of circular economy
                                                                       The calculated mediation effect of 0.116 × 0.511 = 0.059 ac-
    models (Ghisellini et al. 2016). The technical require-
                                                                       counts for approximately 155% of the total robotics effect on
    ments of robotic manipulation—precise force control,
                                                                       biocapacity. This effect exceeding 100% is not an error but
    adaptive grasping, and sensor-­  g uided assembly—align            rather indicates inconsistent mediation (MacKinnon et al. 2000;
    naturally with the delicate operations required for prod-          Shrout and Bolger 2002; Pesigan et al. 2025)—a statistically
    uct refurbishment, component remanufacturing, and ma-              valid phenomenon where competing mechanisms operate si-
    terial recovery. This alignment creates strong incentives          multaneously. Specifically, robotics generates direct negative
    for innovation in materials science, product design for            environmental pressures through manufacturing resource in-
    disassembly, and recycling technologies—all inherently             tensity, embodied energy in production, and electronic waste,
    green-­biased innovations (Lasi et al. 2014). The robot-           but these costs are overwhelmed by the positive indirect effects
    ics sector thus becomes a focal point for environmental            through green-­biased innovation (0.059). This pattern reflects
    innovation not because firms prioritize sustainability             innovation offsets (Porter and van der Linde 1995), where in-
    abstractly, but because the technical challenges of auto-          duced technological change generates environmental benefits
    mation push innovation toward solutions with favorable             exceeding initial resource costs—a core prediction of directed
    environmental characteristics.                                     technical change models (Acemoglu et al. 2012). The suppres-
  • Regulatory complementarity and induced innovation:                 sion effect is theoretically consistent with ecological moderniza-
    The stringent environmental regulations increasingly               tion frameworks emphasizing technology's potential to generate
    characterizing advanced manufacturing economies create             environmental improvements surpassing direct resource costs
    market demand specifically for technologies that achieve           (Mol and Sonnenfeld 2000) and empirically parallels docu-
    compliance at lower cost. Robotics, by enabling precise pro-       mented spillover effects in energy R&D (Popp 2006) and renew-
    cess control and comprehensive monitoring, demonstrates            able technology adoption (Verdolini and Galeotti 2011), where
    strong complementarity with environmental regulation               innovation-­induced benefits have been documented to substan-
    (Porter and van der Linde 1995). This complementarity              tially exceed embodied costs through spillover mechanisms.
    induces what economists term “regulation-­driven innova-
    tion”—where firms invest specifically in technologies that         This dominant effect establishes green-­    biased technological
    simultaneously improve productivity and environmental              innovation as the primary mechanism translating industrial
                                                                       automation into measurable environmental benefits, validat-
    performance because regulatory constraints make such in-
                                                                       ing theoretical models emphasizing directed technical change
    novations economically valuable (Jaffe et al. 2000). The di-
                                                                       as the key driver of environmental improvement (Aghion
    rection of innovation effort thus tilts systematically toward
                                                                       et al. 2016). The green-­bias framing fundamentally shifts pol-
    green technologies in contexts where robotics adoption co-
                                                                       icy implications. Rather than promoting robotics and hoping for
    incides with environmental policy pressure.
                                                                       environmental co-­benefits, policymakers should recognize and
  • Skill composition effects: Robotics deployment shifts              deliberately amplify the structural factors that orient robotics-­
    workforce composition toward higher-­        skilled technical     induced innovation toward sustainability applications. This
    personnel—engineers, programmers, data analysts—who                includes (1) performance-­based environmental standards that
    characteristically exhibit stronger environmental prefer-          reward precision manufacturing and automated monitoring; (2)
    ences than general manufacturing workers (Franzen and              R&D subsidies specifically targeting green robotics applications
    Vogl 2013). As robotics penetration increases, firms' human        in renewable energy manufacturing, recycling automation, and
    capital bases develop stronger intrinsic motivation to pur-        precision agriculture; (3) public procurement prioritizing ro-
    sue environmental innovation, creating organizational              botic systems with demonstrated environmental performance;
    cultures that systematically favor green technology devel-         (4) training programs emphasizing environmental engineering
    opment. The resulting innovation portfolio reflects not only       competencies within robotics education; and (5) intellectual
    the technical complementarities described above but also           property policies that facilitate knowledge spillovers from robot-
    the values and priorities of the robotics-­era workforce.          ics to environmental technology sectors.

The second-­stage results confirm that this green-­biased tech-
nological progress significantly enhances biocapacity with a           4.4   |   Threshold Effects
coefficient of 0.511. Interpreted as a semi-­elasticity, this magni-
tude indicates that green innovation drives substantial propor-        While our previous analysis establishes that INRO signifi-
tionate gains in ecological capacity, considerably outperforming       cantly increases biocapacity through crucial transmission

12                                                                                                 Business Strategy and the Environment, 2026
                                                                                                                                                                          10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 4    |    Mechanism effect tests.

                                             GOV                                    BIO                                    TP                              BIO
  Variable                                     (1)                                   (2)                                   (3)                              (4)
  INRO                                     0.202***                                                                     0.116***
                                            (6.587)                                                                     (23.064)
  GOV                                                                            0.033***
                                                                                  (3.443)
  TP                                                                                                                                                     0.511***
                                                                                                                                                          (6.947)
  INCOME                                     0.024                              −0.175***                              −0.002**                          −0.176***
                                            (0.396)                              (−4.540)                               (−2.244)                         (−4.595)
  POP                                     −0.092***                             −0.539***                              −0.003***                         −0.540***
                                           (−2.783)                              (−22.131)                              (−4.833)                         (−22.119)
  EMP                                       0.303**                              0.171***                              −0.015***                         0.210***
                                            (2.048)                               (2.848)                               (−5.220)                          (3.333)
  FDI                                      0.030***                                0.005                              −0.000***                            0.006
                                            (3.768)                               (1.283)                               (−3.120)                          (1.643)
  EXR                                        0.097                                −0.026                                0.002**                           −0.018
                                            (0.281)                              (−0.678)                                (2.084)                         (−0.450)
  INF                                     −0.220**                                −0.006                                  0.001                           −0.015
                                           (−2.188)                              (−0.336)                                (1.288)                         (−0.897)
  Constant                                 3.802***                              10.133***                              0.058***                         10.211***
                                            (7.434)                               (25.582)                               (5.567)                          (25.518)
  Country FE                                   ✓                                      ✓                                     ✓                                ✓
  Time FE                                      ✓                                      ✓                                     ✓                                ✓
  N                                          1250                                   1250                                  1250                             1250
  Adj-­R 2                                   0.955                                 0.996                                  0.955                            0.996
Note: Reported t-­statistics (in parentheses) are computed using country-­level clustered standard errors. Significance levels are denoted as follows:
*p < 0.10
**p < 0.05, and
***p < 0.01.



mechanisms (as supported in Table 4), theoretical consider-                                dynamics, we employed Hansen's (1999) threshold regression
ations suggest that this relationship may exhibit non-­linear                              methodology to identify critical inflection points where the
characteristics across different levels of industrial upgrading.                           INRO-­biocapacity relationship fundamentally shifts in re-
The effectiveness of INRO in enhancing ecological capacity                                 sponse to varying levels of industrial structure upgrading.
depends critically on the structural composition and sophis-
tication of the economy within which it operates. Drawing
on structural transformation theory (Syrquin 1988; Ngai and                                4.4.1   |   Threshold Identification and Validation
Pissarides 2007), we hypothesize that INRO's ecological bene-
fits materialize differently across distinct phases of industrial                          Our empirical strategy began with comprehensive thresh-
development. Insufficient industrial diversification and tech-                             old effect and value tests to determine the optimal number
nological infrastructure may limit INRO's potential to opti-                               of breakpoints and validate their statistical significance.
mize resource allocation and integrate sustainable production                              Using Hansen's (1999) Bootstrap approach with 1000 replica-
systems (Baldwin 2016). Conversely, economies undergoing                                   tions, we tested for threshold effects across industrial struc-
structural transitions without adequate complementary capa-                                ture dimensions. The results, presented in Table 5 Panel A,
bilities may experience temporary disruptions before realizing                             provide compelling evidence for non-­linearity in the INRO-­
the full ecological benefits of INRO. To examine these complex                             biocapacity relationship. The single threshold test yields an


Business Strategy and the Environment, 2026                                                                                                                          13
                                                                                                                                                                        10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 5    |    Threshold effect and value tests.

  Panel A. Threshold effect test
  Threshold variable                            Threshold number                  F-­statistic          p                       Critical values
                                                                                                                        1%                   5%            10%
  Industrial structure upgrading                        Single                    161.995***          0.000           95.464               89.149         79.116
                                                        Double                    143.187***          0.000          −129.568            −130.237       −137.729
                                                        Triple                       0.000            0.500            0.000               0.000          0.000
  Panel B. Threshold values test
  Threshold variable                                 Parameter                      Threshold value                       95% confidence interval
  Industrial structure upgrading                           γ1                             13.237                                [13.010, 13.237]
                                                           γ2                             15.553                                [14.196, 15.654]
                                                           γ3                             15.900                               [15.900, 15.900]
Note: ***, *, and *represent statistical significance at 1%, 5%, and 10% levels, respectively.




FIGURE 3    |    Threshold effect for industrial upgrading.



F-­statistic of 161.995, decisively rejecting the null hypothesis                           troughs in both panels, falling well below the critical value line,
of no threshold effect. The double-­t hreshold test yields an F-­                           confirm the statistical significance of both identified thresholds
statistic of 143.187, supporting the presence of two distinct                               at the 5% level. The sharp, well-­defined minima indicate clear
structural breakpoints. Notably, the triple-­      t hreshold test                          structural breaks rather than gradual transitions, validating the
yields a zero F-­statistic, indicating that a third threshold pro-                          appropriateness of the threshold regression framework for mod-
vides no additional explanatory power. These results confirm                                eling this relationship.
that a double-­threshold specification optimally captures the
non-­l inear dynamics in our data.
                                                                                            4.4.2   |   Regime-­Specific Effects: A Three-­Phase Analysis
Panel B of Table 5 reports the estimated threshold values and
their 95% bootstrap confidence intervals. The first threshold (γ1)                          The threshold regression results, presented in Table 6, reveal
is estimated at 13.237 with a tight confidence interval [13.010,                            striking non-­linearities in how industrial structure upgrad-
13.237], indicating precise identification of this structural break-                        ing moderates INRO's effectiveness in enhancing biocapacity.
point. The second threshold (γ2) is estimated at 15.553 with a                              Rather than exhibiting uniform impacts across all develop-
confidence interval [14.196, 15.654]. The narrow confidence                                 ment stages, we observe three distinct structural regimes where
intervals for both thresholds demonstrate the robustness of our                             INRO's ecological influence undergoes dramatic transforma-
threshold estimates and provide strong statistical validation for                           tions, as defined by the estimated thresholds (γ1 = 13.237 and
the regime-­switching model.                                                                γ2 = 15.553).

Figure 3 provides visual confirmation of our threshold selection                            4.4.2.1   |   Regime I: Nascent Industrial Development
using likelihood-­ratio (LR) test statistics. The graphs plot the LR                        (INDUS < 13.237). In the first regime, INRO demonstrates a
statistics against potential threshold values, with the horizontal                          positive but modest effect on biocapacity with a coefficient of 0.599,
dotted line representing the 5% critical value. The pronounced                              translating to a proportionate increase in ecological capacity. This


14                                                                                                                        Business Strategy and the Environment, 2026
                                                                                                                                                      10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 6    |    Estimated results of the threshold effect.                      contributes meaningfully to biocapacity through foundational
                                                                                efficiency gains. Crucially, in this regime, rebound effects re-
                                   Dependent variable:
                                                                                main structural contained. The potential for “efficiency-­     led
                                  Biocapacity per person
                                                                                expansion” is naturally dampened by (a) production capacity
 Variables                                      (1) fe        (2) fe-­robust    constraints that limit rapid volume scaling, (b) infrastructure
                                                                                bottlenecks that act as a check on aggregate output growth, and
 INRO                  INDUS < γ1              0.599***           0.599***
                                                                                (c) the fact that incremental efficiency improvements do not
                                                (3.36)                (4.41)    generate the massive cost savings required to trigger significant
                                                                                consumption rebounds. Thus, while the environmental bene-
                    γ1 ≤ INDUS ≤ γ2          −0.540***          −0.540***
                                                                                fits are not transformative (0.599), they are positive because the
                                               (−3.06)            (−3.96)       “scale effect” has not yet accelerated enough to offset the initial
                                                                                “technique effect.”
                       INDUS > γ2              5.093***           5.093***
                                                (5.13)                (4.96)
                                                                                4.4.2.2   |   Regime II: Structural Transition Phase
 INCOM                                       −0.232***           −0.232***      (13.237 ≤ INDUS ≤ 15.553). The second regime presents a
                                                                                counterintuitive finding: the robotics coefficient becomes neg-
                                                (−7.14)           (−6.42)
                                                                                ative at −0.540. This indicates a relative contraction in bioca-
 POP                                          −0.553***          −0.553***      pacity during the intermediate upgrading phase, reflecting
                                                                                the dominance of scale effects over technique effects. This
                                               (−35.29)           (−22.32)
                                                                                regime characterizes economies undergoing deep structural
 EMP                                          0.240***           0.240***       transformation, shifting from simple manufacturing toward
                                                (4.04)                (3.77)    diversified, technology-­
                                                                                                        intensive systems. We identify four
                                                                                interconnected mechanisms that generate these short-­run envi-
 FDI                                           0.00363            0.00363       ronmental trade-­offs:
                                                (0.50)                (1.02)
                                                                                  • Structural adjustment and creative destruction: First, the
 EXR                                           −0.0229            −0.0229           reallocation of resources from declining traditional indus-
                                               (−0.38)            (−0.55)           tries to emerging sectors generates transitional inefficien-
                                                                                    cies (Ngai and Pissarides 2007). The rapid deployment of
 INF                                          −0.00976           −0.00976           robotics accelerates the contraction of established activities
                                               (−0.44)            (−0.60)           before sufficient complementarities are achieved in new sec-
                                                                                    tors, producing the friction associated with Schumpeterian
 Constant                                      10.42***           10.42***          creative destruction (Schumpeter 2021).
                                                (40.15)               (25.75)
                                                                                  • The rebound effect and efficiency-­led expansion: Crucially,
 Country FE                                      YES                   YES          this phase is susceptible to the rebound effect, where effi-
                                                                                    ciency gains paradoxically increase aggregate environmen-
 Time FE                                         YES                   YES
                                                                                    tal pressures through volume expansion (Sorrell et al. 2009).
 N                                               1250                 1250          As automation reduces per-­   unit production costs, firms
                                                                                    capitalize on higher margins to scale capacity aggressive-
 Adj-­R2                                         0.996                0.996
                                                                                    ly—a phenomenon known as the Jevons Paradox. This
Note: Standard errors reported in parentheses. Significance levels:                 “efficiency-­
                                                                                                led expansion” is particularly pronounced in
***p < 0.01
**p < 0.05.                                                                         transitional economies where emerging market opportuni-
*p < 0.10.                                                                          ties incentivize the reinvestment of cost savings into output
                                                                                    growth rather than sustainability (A. Greening et al. 2000).
                                                                                    Consequently, the “volume effect” of increased industrial
initial phase represents economies in the early stages of industrial                output temporarily outpaces the “technique effect” of effi-
diversification, where manufacturing sectors remain relatively                      ciency gains.
simple in terms of technological complexity. Robotic applications
                                                                                  • Embodied energy and capital intensity: The capital-­
primarily support incremental improvements by automating
                                                                                    intensive nature of robotic investment diverts financial
routine production processes. The moderate magnitude reflects
                                                                                    resources from mature environmental technologies.
several structural constraints. Nascent industrial structures
                                                                                    Furthermore, the embodied energy required to manu-
often lack complementary infrastructure—reliable power sup-
                                                                                    facture, transport, and install complex robotic systems
plies, maintenance facilities, and skilled technicians (Acemoglu
                                                                                    represents a substantial upfront ecological cost. This
and Restrepo 2020). These economies exhibit limited absorptive
                                                                                    “composition rebound” temporarily increases economy-­
capacity for advanced automation technologies (Cohen and Levin-
                                                                                    wide material intensity, which subsides only when
thal 1990), and the absence of sophisticated supply chain networks
                                                                                    long-­
                                                                                         r un productivity gains materialize (Graedel and
limits opportunities for robotics-­driven optimization.
                                                                                    Allenby 2010; Font Vivanco et al. 2016)
Despite these limitations, the positive and significant coeffi-                   • Adaptation lags: Finally, structural upgrading gener-
cient indicates that even at early stages, robotic deployment                       ates mismatches in both human capital and institutions.


Business Strategy and the Environment, 2026                                                                                                     15
                                                                                                                                               10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
     Workforce capabilities often adjust more slowly than tech-          governance ensure that the efficiency gains from robotics
     nological change, leading to skill gaps and productivity            are directed toward sustainability rather than mere output
     disruptions (Acemoglu 1998). Similarly, regulatory frame-           expansion (Acemoglu et al. 2005). High-­quality institutions
     works designed for traditional industrial systems may lag           create the economic incentives necessary to internalize
     behind robotics-­intensive environments, creating coordi-           environmental externalities, ensuring that robotic deploy-
     nation frictions that hinder efficient resource allocation          ment aligns with biocapacity preservation.
     (North 1990).
                                                                     The sharp increase in the coefficient empirically confirms the
Taken together, these mechanisms align with J-­curve patterns        non-­l inear relationship between structural sophistication and
in technological transitions (Brynjolfsson et al. 2021), explain-    technological effectiveness. It suggests that once an economy
ing why the environmental payoff of robotics declines during         surpasses the critical threshold of industrial upgrading, the
the structural transition. The negative coefficient reflects a pe-   interaction between robotics and advanced infrastructure
riod where scale effects, embodied costs, and adaptation lags        leads to exponential improvements in biocapacity, definitively
temporarily overwhelm the efficiency gains before stronger           overcoming the transitional trade-­offs of the structural adjust-
complementarities and institutional alignment allow positive         ment phase.
effects to dominate in the advanced regime.

4.4.2.3   |   Regime III: Advanced Industrial Structure              4.5   |   Spatial Spillover Effects
(INDUS > 15.553). The third regime reveals a dramatic
transformation in the ecological impact of robotics, with            We next explore geographic spillovers from Japan—the re-
the coefficient surging to 5.093. Crucially, given the logarith-     gion's principal hub for INR innovation—to assess whether
mic nature of the dependent variable, this coefficient represents    proximity conditions the environmental returns to INRO.
a semi-­elasticity, implying that in advanced industrial struc-      Countries were split into two groups based on their distance to
tures, the marginal impact of robotics adoption leads to an          Japan (closer than the sample mean versus farther away), and
exponential proportionate expansion in biocapacity. This mag-        the INR-­biocapacity relationship was estimated separately for
nitude—approximately eight times larger than in the nascent          each group (see Table 7). The results reveal a pronounced spa-
phase—confirms that once an economy surpasses critical struc-        tial heterogeneity. Countries closer to Japan exhibit a positive,
tural thresholds, the interaction between robotics and advanced      statistically significant INR coefficient (0.053), indicating that
infrastructure unlocks massive relative gains in ecological          robotics adoption in these countries is associated with mea-
regeneration. We attribute this exponential improvement to four      surable improvements in biocapacity. By contrast, countries
reinforcing mechanisms:                                              farther from Japan display a large, negative, and highly sig-
                                                                     nificant INR coefficient (−1.429), implying that robotics diffu-
  • Systemic complementarities and industry 4.0: Advanced            sion in more distant economies is correlated with substantial
                                                                     reductions in biocapacity.
    structures exhibit strong synergies between robotics and
    complementary digital assets. The integration of collabo-
                                                                     This pronounced spatial gradient reflects several intercon-
    rative robots with IoT sensor networks and predictive ana-
                                                                     nected mechanisms that facilitate technology transfer and
    lytics creates “smart ecosystems” where efficiency gains are
                                                                     knowledge diffusion (Baptista 2001). Countries in Japan's geo-
    systemic rather than isolated (Brynjolfsson and Hitt 2000).
                                                                     graphic vicinity benefit from enhanced access to cutting-­edge
    Unlike the nascent phase, modern digital infrastructure al-
                                                                     robotics technologies through established trade networks and
    lows for predictive maintenance and adaptive energy man-
                                                                     supply chain relationships (Li et al. 2019). These nations expe-
    agement, maximizing resource productivity.
                                                                     rience more frequent and intensive bilateral collaborations be-
  • Value chain dematerialization: Complex, integrated value         tween firms, research institutions, and government agencies,
    chains enable robotics to drive system-­level optimization.      creating robust channels for knowledge exchange and joint in-
    Automated logistics, robotic warehouse management, and           novation initiatives. The proximity advantage extends to human
    synchronized just-­in-­time production significantly reduce      capital mobility, enabling more effortless movement of skilled
    material buffers, inventory waste, and transportation dis-       professionals, researchers, and technical specialists who carry
    tances (Baldwin 2016). In this regime, robotics facilitates      valuable tacit knowledge essential for successful robotics imple-
    a shift from “mass production” to “precision production,”        mentation (Castellani et al. 2022; Brey and van der Marel 2024).
    decoupling value creation from material throughput.              The geographic advantage becomes particularly pronounced in
                                                                     the transfer of sophisticated environmental applications of ro-
  • Rapid knowledge diffusion: Mature industrial structures
                                                                     botics technology. Countries such as South Korea, Taiwan, and
    function as efficient networks for knowledge transmission
                                                                     Singapore can more readily access, adapt, and deploy Japan's ad-
    (Romer 1990). Environmental best practices and green robotic
                                                                     vanced robotics solutions to optimize energy use, reduce waste,
    innovations propagate rapidly through established supplier
                                                                     and improve resource efficiency. These nations benefit from
    relationships and inter-­industry collaborations, accelerating
                                                                     similar regulatory environments, compatible industrial stan-
    the economy-­wide adoption of sustainable technologies.
                                                                     dards, and established institutional relationships that facilitate
  • Institutional alignment and rebound mitigation: Crucially,       seamless technology adoption and adaptation. Furthermore,
    advanced economies typically possess robust institutional        proximity to Japan enables faster access to technological up-
    frameworks that curb the rebound effect. Stringent en-           grades and innovations, ensuring that robotics systems remain
    vironmental regulations, carbon pricing, and effective           at the forefront of technology and maximize environmental

16                                                                                               Business Strategy and the Environment, 2026
                                                                                                                                                        10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 7    |    Spatial spillover effect results.                                 The spatial spillover analysis provides compelling evidence that
                                                                                  the environmental benefits of INRO are not uniformly distrib-
                                     Dependent variable:
                                                                                  uted across geographic space. Instead, they concentrate around
                                    Biocapacity per person
                                                                                  innovation hubs, creating a core-­periphery pattern in which
                                    (1)                           (2)             proximity to technological leaders yields substantial advan-
                                                                                  tages in realizing the environmental potential of automation
  Variable                 Close to Japan                Far from Japan
                                                                                  technologies.
  INRO                          0.053***                      −1.429***
                                 (3.188)                       (−7.464)
                                                                                  4.6   |   Robotics, Trade Patterns, and Value Chain
  INCOME                       −0.209***                      −0.191***           Repositioning
                                (−2.757)                       (−5.109)
                                                                                  To explore whether robotics' environmental benefits operate
  POP                          −0.198***                      −0.569***           partially through reconfiguration of international trade and
                                (−2.981)                      (−22.877)           GVC participation, we conduct supplementary heterogeneity
                                                                                  analysis examining how trade intensity and GVC integration
  EMP                          −0.718***                       0.282***           moderate the robotics-­biocapacity relationship. This investiga-
                                (−4.892)                        (4.155)           tion addresses how automation may enhance ecological capacity
                                                                                  by enabling the reshoring of production from high-­pollution to
  FDI                           0.710***                         0.006            low-­pollution jurisdictions and facilitating value chain reposi-
                                 (3.896)                        (1.431)           tioning (Shapiro 2021; Zhou, Fan, and Gan 2024).

  EXR                           1.106***                        −0.063
                                                                                  Table 8 presents results stratified by trade openness and GVC
                                 (4.744)                       (−1.473)           participation intensity. Following established methodologies
                                                                                  in international economics literature, we classify countries as
  INF                             0.158                          0.000
                                                                                  “high trade intensity” if their trade-­to-­GDP ratio exceeds the
                                 (0.827)                        (0.003)           sample median, and “high GVC participation” if their foreign
                                                                                  value-­added share of exports exceeds the median threshold.
  Constant                      4.998***                      10.595***
                                                                                  This classification enables examination of whether international
                                 (4.278)                       (26.302)           economic integration moderates robotics' ecological effective-
  Country FE                         ✓                             ✓              ness. For trade intensity, low-­trade economies show a positive,
                                                                                  highly significant robotics coefficient of 0.106, while high-­trade
  Time FE                            ✓                             ✓              economies exhibit a substantially larger coefficient of 1.031. This
  N                                225                           1025             suggests that the rate of biocapacity improvement derived from
                                                                                  robotics is approximately 10 times higher in economies with ex-
  Adj-­R 2                        0.998                          0.996            tensive international trade networks.
Note: Reported t-­statistics (in parentheses) are computed using country-­level
clustered standard errors. Significance levels are denoted as follows:            The GVC participation dimension presents a complementary pat-
*p < 0.10
**p < 0.05, and
                                                                                  tern. Countries with high GVC integration show a positive and
***p < 0.01.                                                                      statistically robust effect of 0.065, while low-­GVC-­participation
                                                                                  countries exhibit a non-­significant coefficient of 0.088. This in-
                                                                                  dicates that deep integration into global production networks—
benefits. The dense network of supplier relationships, technical                  characterized by substantial foreign value-­     added content in
support services, and maintenance capabilities in the region cre-                 exports—creates conditions under which robotics adoption re-
ates an ecosystem that sustains the long-­term effectiveness of                   liably translates into measurable improvements in biocapacity.
robotics investments in environmental applications (Potter and                    The lack of statistical significance in low-­GVC contexts suggests
Graham 2019).                                                                     that without dense international production linkages, robotics'
                                                                                  environmental benefits may be attenuated or more variable
Conversely, countries distant from Japan face multiple barriers                   across countries. These differentiated patterns support the hy-
that impede effective technology transfer. These include higher                   pothesis that robotics influences biocapacity partially through
transaction costs for acquiring advanced robotics systems,                        trade and value chain reconfiguration mechanisms, though the
limited access to specialized technical expertise and support                     specific channels differ between trade intensity and GVC partic-
services, reduced opportunities for direct collaboration and                      ipation dimensions.
knowledge exchange, and potential mismatches between avail-
able technologies and local environmental conditions or regula-                   These differentiated patterns support the hypothesis that robot-
tory frameworks. The substantial negative coefficient for distant                 ics influences biocapacity through trade and value chain recon-
countries suggests that, without adequate supporting infra-                       figuration, operating through five complementary mechanisms:
structure and institutional capacity, robotics adoption may lead
to suboptimal deployment that fails to generate environmental                       • Reshoring and nearshoring dynamics: Automation re-
benefits or, in some cases, may even result in counterproductive                      duces labor-­cost advantages that drove production offshoring
outcomes (Tao and Wu 2025).                                                           to weakly-­regulated economies. High-­   trade countries that

Business Strategy and the Environment, 2026                                                                                                       17
                                                                                                                                                                           10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
TABLE 8    |    Trade intensity heterogeneity.

                                                                     Dependent variable: Biocapacity per person
                                            (1)                                 (2)                                    (3)                                  (4)
                                                                                                                                                    High GVCs
  Variable                     Low trade intensity                 High trade intensity                Low GVCs participation                      participation
  INRO                                  0.106***                              1.031*                                 0.088                               0.065***
                                         (7.834)                              (1.842)                                (0.213)                              (4.399)
  INCOME                               −0.272***                               0.078                                0.092**                               −0.132*
                                        (−4.784)                              (1.486)                                (2.476)                             (−1.929)
  POP                                  −0.425***                            −0.874***                             −0.809***                              −0.444***
                                        (−6.604)                            (−19.165)                              (−12.969)                             (−8.714)
  EMP                                    −0.128                              0.475***                              0.549***                                0.023
                                        (−1.577)                              (4.850)                                (6.733)                              (0.227)
  FDI                                    −0.020                                0.007                                0.006**                                0.013
                                        (−0.255)                              (1.566)                               (2.233)                               (0.366)
  EXR                                   1.215***                              −0.018                               1.543***                              −4.005***
                                         (6.287)                             (−0.002)                                (5.496)                             (−4.657)
  INF                                    −0.091                                0.185                                −0.206                               −0.389***
                                        (−0.932)                              (1.228)                               (−1.611)                             (−4.291)
  Constant                              9.036***                            14.735***                              14.268***                             8.873***
                                         (7.942)                             (20.623)                               (14.297)                              (10.144)
  Country FE                                ✓                                    ✓                                      ✓                                    ✓
  Time FE                                   ✓                                    ✓                                      ✓                                    ✓
  N                                        488                                  485                                    486                                  486
  Adj-­R 2                                0.998                                0.997                                 0.997                                 0.998
Note: Reported t-­statistics (in parentheses) are computed using country-­level clustered standard errors. Significance levels are denoted as follows:
*p < 0.10
**p < 0.05, and
***p < 0.01.



      previously offshored substantial capacity demonstrate greater                            repositioning within existing value chains toward environ-
      potential for robotics-­enabled reshoring to jurisdictions with                          mentally favorable specialization.
      superior environmental governance (De Backer et al. 2018).
                                                                                            • Supply chain compression: Robotics-­enabled vertical in-
      When pollution-­   intensive manufacturing returns to coun-
                                                                                              tegration reduces geographic fragmentation, potentially de-
      tries with stringent regulation under automated oversight, net
                                                                                              creasing transportation-­intensive intermediate goods trade
      global environmental pressure may decrease. The larger coef-                            (Baldwin and Venables 2013). High-­trade economies with
      ficient in high-­trade economies (1.031 vs. 0.106) reflects this                        extensive international networks may realize larger envi-
      beneficial reallocation of production.                                                  ronmental benefits from robotics-­driven supply chain com-
  • Value chain upgrading: Countries deeply integrated                                        pression that reduces freight emissions. The localization of
    into GVCs leverage robotics to reposition toward cleaner                                  previously dispersed production stages represents an ad-
    production stages. Shapiro (2021) documents how trade                                     ditional pathway enhancing biocapacity in trade-­intensive
    systematically concentrates pollution-­  intensive activities                             economies.
    in weakly-­regulated countries—a pattern robotics may dis-                              • Technology transfer through trade channels: High-­
    rupt. Automation enables specialization in cleaner, higher-­                              trade economies maintain denser international business
    value activities (design, precision manufacturing, quality                                networks, facilitating technology transfer, including the
    control) while reducing dependence on pollution-­intensive                                best environmental practices embodied in imported ro-
    imports. The significant effect, exclusively in high-­GVC                                 botic systems (Grossman and Helpman 1991). Countries
    countries (0.065), suggests that robotics facilitates strategic                           actively participating in international trade may more



18                                                                                                                           Business Strategy and the Environment, 2026
                                                                                                                                                                          10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
      rapidly adopt cutting-­edge environmental management                               Countries with limited digital infrastructure demonstrate a
      practices through equipment imports and technical col-                             significant negative coefficient (−0.307), indicating imple-
      laborations. This mechanism connects our trade findings                            mentation barriers that prevent effective automation deploy-
      to spatial spillover results (Section 4.4), as both reflect                        ment and a lack of complementary digital systems necessary
      knowledge diffusion—operating through geographic                                   for optimizing environmental benefits (Almusharraf 2025).
      proximity versus trade relationships.                                              Surprisingly, countries with advanced digital infrastructure
                                                                                         show a non-­significant coefficient (−0.109), potentially re-
  • Environmental standard transmission: GVC integra-
                                                                                         flecting saturation effects where additional automation pro-
    tion increasingly requires adopting environmental stan-
                                                                                         vides diminishing marginal returns, or where other factors
    dards demanded by lead firms, particularly multinationals
                                                                                         become more important once basic digital needs are satisfied
    headquartered in environmentally stringent jurisdictions
                                                                                         (Ferreira et al. 2023).
    (Gereffi et al. 2005). Robotics adoption strengthens coun-
    tries' ability to meet these standards, maintaining or en-
                                                                                         High-­population countries demonstrate a modest but signifi-
    hancing GVC participation. Where export markets require
                                                                                         cant positive coefficient (0.034), reflecting a 3.4% proportionate
    environmental certification, robotics represents an en-
                                                                                         gain driven by economies of scale in automation deployment,
    abling technology for compliance, creating virtuous cycles
                                                                                         more substantial incentives for efficiency-­enhancing technolo-
    in which automation facilitates trade access, thereby incen-
                                                                                         gies due to acute environmental pressures, and knowledge spill-
    tivizing further environmental improvement.
                                                                                         overs that amplify environmental benefits (Goddard et al. 2021).
                                                                                         Low-­ population countries show a non-­     significant coefficient
                                                                                         (−1.256), suggesting that robotics may not yield efficiency mul-
4.7   |   Heterogeneity Analysis                                                         tipliers due to abundant resources or underutilized infrastruc-
                                                                                         ture, absent sufficient scale.
The relationship between industrial robotics and biocapacity ex-
hibits considerable heterogeneity across economic development
levels, digital infrastructure sophistication, and population den-                       5   |   Conclusions and Policy Recommendations
sity, as evidenced in Table 9.
                                                                                         5.1   |   Research Summary
High-­income economies exhibit a strong positive coefficient
(0.073), reflecting a consistent 7.3% relative improvement in                            Global environmental challenges—including resource depletion,
biocapacity associated with robotics adoption (Fu et al. 2021).                          climate change, and geopolitical instability—have made bioca-
Conversely, low-­income economies show a negative coefficient                            pacity management increasingly critical for sustainable devel-
(−0.866), suggesting a substantial percentage decline in bio-                            opment. Industrial robotics (INRO) has emerged as a potentially
capacity through technology-­skill mismatches, displacement                              important technology in this context, prompting substantial
of sustainable traditional practices, and lack of complemen-                             interest among researchers examining environment-­technology
tary green infrastructure. This stark contrast indicates that                            linkages. This study investigates the relationship between INRO
robotics investments in low-­income countries require simul-                             and biocapacity using panel data from 50 countries over the pe-
taneous investments in education, institutional capacity, and                            riod 2000–2024. We examine how robotics affects ecological ca-
sustainable technology frameworks to realize environmental                               pacity and test the transmission channels, non-­linear dynamics,
benefits.                                                                                and spatial interactions that shape this relationship. Our results


TABLE 9    |    Heterogeneity test.

                                                                 Dependent variable: Biocapacity per person
                             (1)                  (2)                 (3)                  (4)                     (5)                      (6)             (7)
                                              Middle-­                                Advanced                                         High                 Low
  Variable            High-­Income            Income          Low-­Income              Digital            Limited Digital            population          population
  INRO                    0.073***              0.145            −0.866***               −0.109                −0.307**                 0.034***           −1.256
                           (4.924)             (0.407)            (−5.968)              (−1.113)                (−2.329)                 (3.461)          (−0.834)
  Control                     ✓                    ✓                  ✓                     ✓                       ✓                       ✓                ✓
  Country FE                  ✓                    ✓                  ✓                     ✓                       ✓                       ✓                ✓
  Time FE                     ✓                    ✓                  ✓                     ✓                       ✓                       ✓                ✓
  N                          605                 205                 190                   523                     671                     625              625
  Adj-­R 2                  0.997               0.999               0.999                 0.998                   0.996                   0.996            0.996
Note: Reported t-­statistics (in parentheses) are computed using country-­level clustered standard errors. Significance levels are denoted as follows:
*p < 0.10
**p < 0.05, and
***p < 0.01.


Business Strategy and the Environment, 2026                                                                                                                          19
                                                                                                                                                10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
yield several key findings that shed light on when and how ro-      5.2   |   Strategic Policy Recommendations
botics can contribute to environmental sustainability.
                                                                    The mediation analysis reveals that INRO enhances environmental
 • First, the analysis demonstrates that INRO contributes to        sustainability through complementary and mutually reinforcing
   biocapacity enhancement.                                         mechanisms. The dominance of technological progress and indus-
                                                                    trial structure upgrading channels, each representing 155% of the
 • Second, mechanism analysis reveals that robotics
                                                                    total effect, indicates synergistic interactions that amplify environ-
   strengthens ecological capacity through two primary
                                                                    mental benefits beyond simple additive effects. For policymakers,
   transmission channels: institutional flexibility via trans-
                                                                    strategies promoting industrial automation should be designed to
   action cost reduction and accelerating green-­      biased
                                                                    maximize synergies across all three identified pathways, ensuring
   technological progress, with the latter representing the
                                                                    robotics investments occur within institutional frameworks that ef-
   dominant pathway.
                                                                    fectively channel technological capabilities toward environmental
 • Third, our threshold analysis uncovers striking non-­            objectives while facilitating structural transitions toward sustain-
   linearities, identifying two critical structural breakpoints     able economic activities. From a technological standpoint, robotic
   that delineate three distinct effectiveness regimes. In the      automation should be strategically deployed to advance green
   nascent industrial development regime, robotics demon-           patent development in renewable energy manufacturing, clean
   strates modest positive effects. The intermediate transition     production systems, and waste-­reduction solutions. Governments
   regime exhibits a temporary negative relationship, reflect-      should establish innovation incentives targeting robotics applica-
   ing adjustment costs and institutional friction during eco-      tions in environmental technology, create R&D tax credits for green
   nomic restructuring. This transforms dramatically into the       automation solutions, and facilitate knowledge transfer between
   advanced industrial structure regime, where the coefficient      robotics manufacturers and environmental firms. The threshold
   surges to an eight-­fold amplification. This threshold effect    findings indicate technological innovation effects are maximized
   reveals that robotics' ecological benefits are fundamentally     in Regime III, where knowledge spillovers rapidly diffuse across
   path-­dependent, with industrial structural sophistication       sectors. Consequently, countries approaching the second threshold
   serving as a critical moderating factor.                         should invest heavily in innovative ecosystems that will amplify ro-
                                                                    botics' environmental benefits once structural conditions mature.
 • Fourth, spatial analysis reveals that geographic proximity
   to Japan—the global robotics innovation hub—generates            Regarding the industrial structure upgrading perspective, the
   significant spillover effects that amplify ecological capacity   threshold analysis reveals that optimal robotics deployment
   benefits through regional knowledge diffusion and technol-       strategies must be calibrated to match countries' industrial de-
   ogy transfer.                                                    velopment stages, necessitating differentiated policy approaches:
 • Fifth, international economic integration emerges as a
   crucial moderating factor. Trade intensity heterogeneity           • Nascent Industrial Economies (INDUS < 13.237) should pur-
   reveals that high-­trade economies experience substantially          sue foundational strategies focusing on building complemen-
   greater robotics effects than low-­trade economies. GVC par-         tary capabilities: investing in reliable digital infrastructure
   ticipation analysis shows that countries deeply integrated           (stable electricity, broadband networks, automation training
   into global production networks demonstrate significant              centers); promoting basic robotic applications in warehous-
                                                                        ing and simple assembly; establishing technical education
   positive effects, while those with limited GVC engagement
                                                                        programs; and avoiding premature adoption of sophisticated
   exhibit non-­significant results.
                                                                        systems requiring extensive support infrastructure.
 • Sixth, contextual heterogeneity analysis demonstrates that
                                                                      • Transitional Economies (13.237 ≤ INDUS ≤ 15.553) face the
   robotics' environmental effectiveness varies systematically
                                                                        most significant challenges given the temporary negative
   across development levels, digital infrastructure sophistica-
                                                                        coefficient (−0.540). These countries should implement
   tion, and population density. High-­income economies with
                                                                        comprehensive support mechanisms: extensive workforce
   advanced digital capabilities and dense populations realize
                                                                        retraining programs anticipating future skill requirements;
   more substantial positive effects, while low-­income coun-
                                                                        temporary subsidies offsetting upfront environmental costs;
   tries with limited digital infrastructure experience attenu-
                                                                        adaptive regulatory frameworks accommodating robotics-­
   ated or negative outcomes.
                                                                        intensive production; strengthened social safety nets sup-
                                                                        porting displaced workers; and phased adoption roadmaps
Collectively, these findings establish that the robotics-­
                                                                        minimizing production disruptions. The objective is to mini-
biocapacity relationship is neither uniform nor straightfor-
                                                                        mize both the magnitude and duration of temporary adverse
ward, but rather characterized by complex interactions among
                                                                        effects while preparing for advancement to Regime III.
technological capabilities, institutional quality, industrial
structure, geographic position, international integration, and        • Advanced Industrial Economies (INDUS > 15.553) should
development context. The implications for policy design are             pursue aggressive deployment strategies: substantial R&D
profound: Effective strategies must move beyond promoting               funding for green robotics technologies; performance-­
robotics adoption in isolation toward integrated approaches             based environmental standards rewarding automated sys-
that simultaneously address complementary factors deter-                tems; strategic public procurement demonstrating demand
mining whether automation translates into environmental                 for environmentally advanced robotics; international tech-
benefits.                                                               nology transfer facilitating knowledge sharing; and circular



20                                                                                                Business Strategy and the Environment, 2026
                                                                                                                                                                10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
     economy integration promoting robotic systems for product             Acemoglu, D. 2002a. “Technical Change, Inequality, and the Labor
     disassembly and material recovery.                                    Market.” Journal of Economic Literature 40: 7–72. https://​doi.​org/​10.​
                                                                           1257/​0 0220​51026976.
Policymakers should treat robotics and trade integration as com-           Acemoglu, D. 2002b. “Directed Technical Change.” Review of Economic
plementary tools for environmental improvement. Our results                Studies 69: 781–809. https://​doi.​org/​10.​1111/​1467-­​937X.​0 0226​.
show that robotics delivers far larger ecological gains in highly          Acemoglu, D., P. Aghion, L. Bursztyn, and D. Hemous. 2012. “The
traded economies (about 10-­     fold larger effects) and produces         Environment and Directed Technical Change.” American Economic
only statistically robust benefits in countries deeply integrated          Review 102: 131–166. https://​doi.​org/​10.​1257/​aer.​102.1.​131.
into GVCs (high-­GVC). To harness this potential, governments              Acemoglu, D., S. Johnson, and J. A. Robinson. 2005. “Chapter 6
should: (1) lower barriers to imports of advanced robotic equip-           Institutions as a Fundamental Cause of Long-­  Run Growth.” In
ment from innovation hubs so firms access both automation and              Handbook of Economic Growth, vol. 1, 385–472. Elsevier. https://​doi.​
embedded environmental best practices; (2) promote GVC partic-             org/​10.​1016/​S1574​- ­​0 684(05)​01006​-­​3.
ipation while embedding environmental conditionality in trade              Acemoglu, D., and P. Restrepo. 2020. “Robots and Jobs: Evidence From
and investment agreements—e.g. technology-­transfer clauses and            US Labor Markets.” Journal of Political Economy 128: 2188–2244.
standards alignment—to ensure integration amplifies, not dilutes,          https://​doi.​org/​10.​1086/​705716.
robotics' green effects; (3) design targeted reshoring incentives          Acemoglu, D., and J. A. Robinson. 2019. The Narrow Corridor: States,
that attract pollution-­intensive stages back to well-­regulated juris-    Societies, and the Fate of Liberty: Winners of the 2024 Nobel Prize in
dictions (rather than broad subsidies), enabling cleaner domestic          Economics. Penguin UK.
production; (4) use regional and bilateral agreements to fund joint        Aghion, P., A. Dechezleprêtre, D. Hémous, R. Martin, and J. Van Reenen.
R&D in green robotics, mutual recognition of environmental cer-            2016. “Carbon Taxes, Path Dependency, and Directed Technical Change:
tifications, and technical cooperation that helps developing part-         Evidence From the Auto Industry.” Journal of Political Economy 124:
ners adopt clean automation; and (5) support low-­GVC countries            1–51. https://​doi.​org/​10.​1086/​684581.
with complementary investments in industrial capacity, institu-            Almusharraf, A. I. 2025. “Automation and Its Influence on Sustainable
tional strengthening, and regional integration so they can realize         Development: Economic, Social, and Environmental Dimensions.”
robotics' environmental benefits. In short, sequencing automation          Sustainability 17, no. 4: 1754. https://​doi.​org/​10.​3390/​su170​41754​.
policy with strategic trade and GVC policies is essential to convert       Antràs, P., and D. Chor. 2022. “Global Value Chains.” In Handbook of
robotics adoption into measurable gains in ecological capacity.            International Economics: International Trade, edited by G. Gopinath, E.
                                                                           Helpman, and K. B. T.-­H. o. I. E. Rogoff, vol. 5, 297–376. Elsevier.
                                                                           Baldwin, R. 2016. The Great Convergence: Information Technology and
5.3   |   Limitations and Future Research                                  the New Globalization. Harvard University Press.
                                                                           Baldwin, R., and A. J. Venables. 2013. “Spiders and Snakes: Offshoring
Several limitations warrant attention. This investigation does not         and Agglomeration in the Global Economy.” Journal of International
comprehensively analyze how robotic automation effects differ be-          Economics 90: 245–254. https://​doi.​org/​10.​1016/j.​jinte​co.​2 013.​02.​0 05.
tween environmental contexts and industrial sectors. Subsequent            Baptista, R. 2001. “Geographical Clusters and Innovation Diffusion.”
studies might investigate whether automated systems deliver                Technological Forecasting and Social Change 66: 31–46. https://​doi.​org/​
greater sustainability benefits in clean technological sectors than        10.​1016/​S 0040​-­​1625(99)​0 0057​-­​8.
in traditional manufacturing. The threshold analysis assumes dis-          Barbier, E. B. 2019. “The Concept of Natural Capital.” Oxford Review of
crete regime switches; future research should investigate smooth           Economic Policy 35: 14–36. https://​doi.​org/​10.​1093/​oxrep/​​gry028.
adjustment paths using smooth transition regression models. The            Bergougui, B. 2025a. “Industrial Robots for a Sustainable Future:
specific threshold values may not apply universally; comparative           Uncovering the Asymmetric Effects of AI on Ecological Quality in G7
studies examining threshold variation across regions would en-             Economies.” Technology in Society 83: 103021. https://​doi.​org/​10.​1016/j.​
hance understanding. The relatively short time dimension limits            techs​oc.​2 025.​103021.
observation of long-­run dynamics; extended time series following          Bergougui, B. 2025b. “Institutional Adaptability, Skill-­                   Bias
countries through complete transformation cycles would provide             Technological Shifts, and Energy Efficiency in Global Decarbonization
deeper insights. Future research should examine temporal dy-               Pathways: Exploring the Role of Artificial Intelligence Patents.”
namics of pathway importance evolution, conduct sector-­specific           Technology in Society 83: 103029. https://​doi.​org/​10.​1016/j.​techs​oc.​2 025.​
                                                                           103029.
analyses, perform cross-­ cultural institutional comparisons, and
investigate threshold effects across multiple environmental indica-        Bergougui, B. 2025c. “Can Artificial Intelligence Mitigate
tors beyond biocapacity.                                                   Environmental Inequality? Evidence From Leading Robotic-­      Driven
                                                                           Economies Using Quantile-­Based Methods.” Borsa Istanbul Review 25:
                                                                           1316–1336. https://​doi.​org/​10.​1016/j.​bir.​2 025.​07.​012.
                                                                           Bergougui, B. 2025d. “Circular Pathways to Sustainability: Asymmetric
Funding                                                                    Impacts of the Circular Economy on the EU'S Capacity Load Factor.”
The authors would like to acknowledge the Deanship of Graduate             Land 14: 1216. https://​doi.​org/​10.​3390/​land1​4 061216.
Studies and Scientific Research, Taif University, for funding this work.   Bergougui, B., S. Ghosh, B. Doğan, A. Samour, and R. Nepal. 2026.
                                                                           “When Does High-­Tech Research Investment Enable Green Energy
                                                                           Transition?” Energy Conversion and Management: X 30: 101598. https://​
References                                                                 doi.​org/​10.​1016/j.​ecmx.​2 026.​101598.
Acemoglu, D. 1998. “Why Do New Technologies Complement Skills?             Brey, B., and E. van der Marel. 2024. “The Role of Human-­Capital
Directed Technical Change and Wage Inequality.” Quarterly Journal of       in Artificial Intelligence Adoption.” Economics Letters 244: 111949.
Economics 113: 1055–1089.                                                  https://​doi.​org/​10.​1016/j.​econl​et.​2 024.​111949.


Business Strategy and the Environment, 2026                                                                                                              21
                                                                                                                                                                     10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Brunnermeier, S. B., and M. A. Cohen. 2003. “Determinants of                      De Backer, K., T. DeStefano, C. Menon, and J. R. Suh. 2018. Industrial
Environmental Innovation in US Manufacturing Industries.” Journal of              Robotics and the Global Organisation of Production. OECD.
Environmental Economics and Management 45: 278–293.
                                                                                  de Vries-­Gao, A. 2026. “The Carbon and Water Footprints of Data
Brynjolfsson, E., and L. M. Hitt. 2000. “Beyond Computation:                      Centers and What This Could Mean for Artificial Intelligence.” Patterns
Information Technology, Organizational Transformation and Business                7: 101430. https://​doi.​org/​10.​1016/j.​patter.​2 025.​101430.
Performance.” Journal of Economic Perspectives 14: 23–48. https://​doi.​
                                                                                  Ding, T., J. Li, X. Shi, X. Li, and Y. Chen. 2023. “Is Artificial Intelligence
org/​10.​1257/​jep.​14.4.​23.
                                                                                  Associated With Carbon Emissions Reduction? Case of China.”
Brynjolfsson, E., D. Rock, and C. Syverson. 2021. “The Productivity J-­           Resources Policy 85: 103892. https://​doi.​org/​10.​1016/j.​resou​r pol.​2 023.​
Curve: How Intangibles Complement General Purpose Technologies.”                  103892.
American Economic Journal: Macroeconomics 13: 333–372. https://​doi.​
                                                                                  Dobbe, R., O. Sondermeijer, D. Fridovich-­Keil, D. Arnold, D. Callaway,
org/​10.​1257/​mac.​2 0180386.
                                                                                  and C. Tomlin. 2018. “Towards Distributed Energy Services:
Butler, K. T., D. W. Davies, H. Cartwright, O. Isayev, and A. Walsh. 2018.        Decentralizing Optimal Power Flow With Machine Learning.” IEEE
“Machine Learning for Molecular and Materials Science.” Nature 559:               Transactions on Smart Grid 11: 1296–1306. https://​doi.​org/​10.​1109/​
547–555. https://​doi.​org/​10.​1038/​S 4158​6 -­​018-­​0337-­​2 .                TSG.​2 019.​2935711.
Cannas, V. G., M. P. Ciano, M. Saltalamacchia, and R. Secchi. 2024.               Duflou, J. R., J. W. Sutherland, D. Dornfeld, et al. 2012. “Towards
“Artificial Intelligence in Supply Chain and Operations Management:               Energy and Resource Efficient Manufacturing: A Processes and
A Multiple Case Study Research.” International Journal of Production              Systems Approach.” CIRP Annals 61: 587–609. https://​doi.​org/​10.​1016/j.​
Research 62: 3333–3360. https://​doi.​org/​10.​1080/​00207​543.​2023.​2232050.    cirp.​2 012.​05.​0 02.
Castellani, D., A. Perri, and V. G. Scalera. 2022. “Knowledge Integration         Dunn, D. C., C. Jablonicky, G. O. Crespo, et al. 2018. “Empowering
in Multinational Enterprises: The Role of Inventors Crossing National             High Seas Governance With Satellite Vessel Tracking Data.” Fish and
and Organizational Boundaries.” Journal of World Business 57: 101290.             Fisheries 19: 729–739. https://​doi.​org/​10.​1111/​faf.​12285​.
https://​doi.​org/​10.​1016/j.​jwb.​2 021.​101290.
                                                                                  Eastwood, C. R., D. F. Chapman, and M. S. Paine. 2012. “Networks
Chang, H., Q. Ding, W. Zhao, N. Hou, and W. Liu. 2023. “The Digital               of Practice for co-­
                                                                                                     C onstruction of Agricultural Decision Support
Economy, Industrial Structure Upgrading, and Carbon Emission                      Systems: Case Studies of Precision Dairy Farms in Australia.”
Intensity —— Empirical Evidence From China's Provinces.” Energy                   Agricultural Systems 108: 10–18. https://​doi.​org/​10.​1016/j.​a gsy. ​2 011.​
Strategy Reviews 50: 101218. https://​doi.​org/​10.​1016/j.​esr.​2 023.​101218.   12.​0 05.
Chen, J., C. Zhao, S. Liu, and Y. Li. 2025. “How Do Digitalizing ICT              Evans, P., and J. E. Rauch. 1999. “Bureaucracy and Growth: A Cross-­
and Supply Chain Globalization Affect Renewable Energy in ASEAN                   National Analysis of the Effects of “Weberian” State Structures on
Nations? The Mediating Role of Sustainable Environmental Practices                Economic Growth.” American Sociological Review 64: 748–765.
Using the MMQR and PCSEs Model.” Energy Economics 142: 108166.
                                                                                  Ferreira, J. J., J. M. Lopes, S. Gomes, and H. G. Rammal. 2023.
https://​doi.​org/​10.​1016/J.​ENECO.​2 024.​108166.
                                                                                  “Industry 4.0 Implementation: Environmental and Social Sustainability
Chen, S., S. Zhang, Q. Zeng, J. Ao, and X. Chen. 2023. “Can Artificial            in Manufacturing Multinational Enterprises.” Journal of Cleaner
Intelligence Achieve Carbon Neutrality? Evidence From a Quasi-­                   Production 404: 136841. https://​doi.​org/​10.​1016/j.​jclep​ro.​2 023.​136841.
Natural Experiment.” Frontiers in Ecology and Evolution 11: 1151017.
                                                                                  Finger, R., S. M. Swinton, N. El Benni, and A. Walter. 2019. “Precision
https://​doi.​org/​10.​3389/​fevo.​2 023.​1151017.
                                                                                  Farming at the Nexus of Agricultural Production and the Environment.”
Chen, Y., L. Cheng, and C. C. Lee. 2022. “How Does the Use of Industrial          Annual Review of Resource Economics 11: 313–335. https://​doi.​org/​10.​
Robots Affect the Ecological Footprint? International Evidence.”                  1146/​annur​ev-­​resou​rce-­​10051​8-­​0 93929.
Ecological Economics 198: 107483. https://​doi.​org/​10.​1016/j.​ecole​con.​
                                                                                  Font Vivanco, D., R. Kemp, and E. van der Voet. 2016. “How to Deal
2022.​107483.
                                                                                  With the Rebound Effect? A Policy-­Oriented Approach.” Energy Policy
Cheng, H., R. Jia, D. Li, and H. Li. 2019. “The Rise of Robots in China.”         94: 114–125. https://​doi.​org/​10.​1016/j.​enpol.​2 016.​03.​054.
Journal of Economic Perspectives 33: 71–88. https://​doi.​org/​10.​1257/​jep.​
                                                                                  Franzen, A., and D. Vogl. 2013. “Two Decades of Measuring
33.2.​71.
                                                                                  Environmental Attitudes: A Comparative Analysis of 33 Countries.”
Chu, Z., P. Chen, Z. Zhang, and Z. Chen. 2024. “Other's Shoes Also                Global Environmental Change 23: 1001–1008. https://​doi.​org/​10.​1016/j.​
Fit Well: AI Technologies Contribute to China's Blue Skies as Well as             gloen​vcha.​2 013.​03.​0 09.
Carbon Reduction.” Journal of Environmental Management 353: 120171.
                                                                                  Fu, X., Q. Bao, H. Xie, and X. Fu. 2021. “Diffusion of Industrial Robotics
https://​doi.​org/​10.​1016/J.​J ENVM​A N.​2 024.​120171.
                                                                                  and Inclusive Growth: Labour Market Evidence From Cross Country
Coase, R. H. 2013. “The Problem of Social Cost.” Journal of Law and               Data.” Journal of Business Research 122: 670–684. https://​doi.​org/​10.​
Economics 56: 837–877. https://​doi.​org/​10.​1086/​674872.                       1016/j.​jbusr​es.​2 020.​05.​051.
Coglianese, C., J. Nash. 2001. Regulating From the Inside: Can                    Gabbi, G., M. Matthias, N. Patrizi, F. M. Pulselli, and S. Bastianoni.
Environmental Management Systems Achieve Policy Goals? Resources for              2021. “The Biocapacity Adjusted Economic Growth. Developing a New
the Future. Routledge.                                                            Indicator.” Ecological Indicators 122: 107318. https://​doi.​org/​10.​1016/j.​
                                                                                  ecoli​nd.​2 020.​107318.
Cohen, W. M., and D. A. Levinthal. 1990. “Absorptive Capacity: A
New Perspective on Learning and Innovation.” Administrative Science               Gao, L., and J. Wang. 2025. “Can Artificial Intelligence Reduce
Quarterly 35: 128. https://​doi.​org/​10.​2307/​2393553.                          Energy Vulnerability? Evidence From an International Perspective.”
                                                                                  Energy Economics 145: 108491. https://​doi.​org/​10.​1016/j.​eneco.​2 025.​
Copeland, B. R., J. S. Shapiro, and M. Scott Taylor. 2022. “Globalization
                                                                                  108491.
and the Environment.” In Handbook of International Economics:
International Trade, edited by G. Gopinath, E. Helpman, and K. B. T.-­H.          Gereffi, G., J. Humphrey, and T. Sturgeon. 2005. “The Governance of
o. I. E. Rogoff, vol. 5, 61–146. Elsevier.                                        Global Value Chains.” Review of International Political Economy 12:
                                                                                  78–104. https://​doi.​org/​10.​1080/​0 9692​29050​0 049805.
Dasgupta, S., B. Laplante, H. Wang, and D. Wheeler. 2002. “Confronting
the Environmental Kuznets Curve.” Journal of Economic Perspectives                Ghisellini, P., C. Cialani, and S. Ulgiati. 2016. “A Review on Circular
16: 147–168.                                                                      Economy: The Expected Transition to a Balanced Interplay of


22                                                                                                                  Business Strategy and the Environment, 2026
                                                                                                                                                                        10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
Environmental and Economic Systems.” Journal of Cleaner Production                     Lafferty, W., and E. Hovden. 2003. “Environmental Policy Integration:
114: 11–32.                                                                            Towards an Analytical Framework.” Environmental Politics 12: 1–22.
                                                                                       https://​doi.​org/​10.​1080/​0 9644​01041​23313​08254​.
Ghobakhloo, M., M. Fathi, M. Iranmanesh, M. Vilkas, A.
Grybauskas, and A. Amran. 2024. “Generative Artificial Intelligence                    Laffont, J.-­J., and J. Tirole. 1993. A Theory of Incentives in Procurement
in Manufacturing: Opportunities for Actualizing Industry 5.0                           and Regulation. MIT press.
Sustainability Goals.” Journal of Manufacturing Technology
                                                                                       Lasi, H., P. Fettke, H.-­G. Kemper, T. Feld, and M. Hoffmann. 2014.
Management 35: 94–121.
                                                                                       “Industry 4.0.” Business & Information Systems Engineering 6: 239–242.
Gil-­Garcia, J. R., T. A. Pardo, and A. Aldama-­Nalda. 2013. “Smart Cities
                                                                                       Lee, C.-­C. C., S. Qin, and Y. Li. 2022. “Does Industrial Robot Application
and Smart Governments: Using Information Technologies to Address
                                                                                       Promote Green Technology Innovation in the Manufacturing Industry?”
Urban Challenges.” In Proceedings of the 14th Annual International
                                                                                       Technological Forecasting and Social Change 183: 121893. https://​doi.​
Conference on Digital Government Research, 296–297. ACM.
                                                                                       org/​10.​1016/j.​techf​ore.​2 022.​121893.
Global Footprint Network. 2025. National Footprint and Biocapacity
                                                                                       Li, Y., Y. Peng, J. Luo, Y. Cheng, and E. Veglianti. 2019. “Spatial-­Temporal
Accounts. Footprint Data Foundation & York University Ecological
                                                                                       Variation Characteristics and Evolution of the Global Industrial Robot
Footprint Initiative. Available at https://​footp​rint.​info.​yorku.​ca/​data/​.
                                                                                       Trade: A Complex Network Analysis.” PLoS ONE 14: e0222785. https://​
Goddard, M. A., Z. G. Davies, S. Guenat, et al. 2021. “A Global Horizon                doi.​org/​10.​1371/​journ​al.​pone.​0222785.
Scan of the Future Impacts of Robotics and Autonomous Systems on                       Li, Y., Y. Zhang, A. Pan, M. Han, and E. Veglianti. 2022. “Carbon Emission
Urban Ecosystems.” Nature Ecology & Evolution 5: 219–230. https://​doi.​               Reduction Effects of Industrial Robot Applications: Heterogeneity
org/​10.​1038/​s 4155​9 - ­​020- ­​01358​-­​z.                                         Characteristics and Influencing Mechanisms.” Technology in Society
Gogonea, R.-­M., S. I. Ghita, and A. S. Saseanu. 2020. “Biocapacity—                   70: 102034. https://​doi.​org/​10.​1016/j.​techs​oc.​2 022.​102034.
Premise of Sustainable Development in the European Space.”                             Liu, L., Z. Rasool, S. Ali, C. Wang, and R. Nazar. 2024. “Robots for
Sustainability 12: 1037. https://​doi.​org/​10.​3390/​su120​31037​.                    Sustainability: Evaluating Ecological Footprints in Leading AI-­Driven
Graedel, T. E., and B. R. Allenby. 2010. Industrial Ecology and                        Industrial Nations.” Technology in Society 76: 102460. https://​doi.​org/​10.​
Sustainable Engineering: International Edition. Pearson Education Inc.                 1016/j.​techs​oc.​2 024.​102460.

Graetz, G., and G. Michaels. 2018. “Robots at Work.” Review of Economics               Long, G., D. Duan, H. Wang, and S. Chen. 2024. “The Impact of
and Statistics 100: 753–768. https://​doi.​org/​10.​1162/​rest_a_​0 0754​.             Industrial Robots on Low-­Carbon Green Performance: Evidence From
                                                                                       the Belt and Road Initiative Countries.” Technology in Society 79:
Greening, A. L., D. L. Greene, and C. Difiglio. 2000. “Energy Efficiency               102712. https://​doi.​org/​10.​1016/j.​techs​oc.​2 024.​102712.
and Consumption—The Rebound Effect—A Survey.” Energy Policy 28:
389–401. https://​doi.​org/​10.​1016/​S 0301​- ­​4215(00)​0 0021​-­​5.                 Luan, F., X. Yang, Y. Chen, and P. J. Regis. 2022. “Industrial Robots and
                                                                                       Air Environment: A Moderated Mediation Model of Population Density
Grossman, G. M., and E. Helpman. 1991. “Trade, Knowledge Spillovers,                   and Energy Consumption.” Sustainable Production and Consumption
and Growth.” European Economic Review 35: 517–526. https://​doi.​org/​                 30: 870–888. https://​doi.​org/​10.​1016/J.​SPC.​2 022.​01.​015.
10.​1016/​0 014-­​2921(91)​9 0153​-­​A .
                                                                                       Lv, H., B. Shi, N. Li, and R. Kang. 2022. “Intelligent Manufacturing
Hansen, B. E. 1999. “Threshold Effects in Non-­                     D ynamic Panels:   and Carbon Emissions Reduction: Evidence From the Use of Industrial
Estimation, Testing, and Inference.” Journal of Econometrics 93: 345–                  Robots in China.” International Journal of Environmental Research and
368. https://​doi.​org/​10.​1016/​S 0304​- ­​4 076(99)​0 0025​-­​1.                    Public Health 19: 15538.
Harfouche, A., M. Merhi, A. Albizri, M. I. Merhi, D. Dennehy, and J.                   MacKinnon, D. P., J. L. Krull, and C. M. Lockwood. 2000. “Equivalence
B. Thatcher. 2024. “Sustainable Development Through Technological                      of the Mediation, Confounding and Suppression Effect.” Prevention
Innovations and Data Analytics.” Information Systems Frontiers 26:                     Science 1: 173–181.
1989–1996. https://​doi.​org/​10.​1007/​s1079​6 -­​024-­​10570​-­​2 .
                                                                                       Meziane, S., and B. Bergougui. 2026. “Aggregate and Disaggregate
Huang, G., L. He, and X. Lin. 2022. “Robot Adoption and Energy                         Natural Resources Impacts on Environmental Sustainability: An
Performance: Evidence From Chinese Industrial Firms.” Energy                           Asymmetric NARDL Analysis.” Resources Policy 113: 105830. https://​
Economics 107: 105837. https://​doi.​org/​10.​1016/j.​eneco.​2 022.​105837.            doi.​org/​10.​1016/j.​resou​r pol.​2 026.​105830.
Jaffe, A., R. G. Newell, and R. N. Stavins. 2000. “Technological Change                Mol, A. P. J., and D. A. Sonnenfeld. 2000. “Ecological Modernisation
and the Environment.” In Environmental Degradation and Institutional                   Around the World: An Introduction.” Environmental Politics 9: 1–14.
Responses, Vol. 1, 461–516. Elsevier. https://​doi.​org/​10.​1016/​S1574​-­​           https://​doi.​org/​10.​1080/​0 9644​01000​8 414510.
0099(03)​01016​-­​7.
                                                                                       Mondal, S., S. Singh, and H. Gupta. 2023. “Green Entrepreneurship and
Kaufmann, D., A. Kraay, and M. Mastruzzi. 2011. “The Worldwide                         Digitalization Enabling the Circular Economy Through Sustainable
Governance Indicators: Methodology and Analytical Issues1.” Hague                      Waste Management—An Exploratory Study of Emerging Economy.”
Journal on the Rule of Law 3: 220–246.                                                 Journal of Cleaner Production 422: 138433. https://​doi.​org/​10.​1016/j.​
                                                                                       jclep​ro.​2 023.​138433.
Khan, I. A., S. I. Abba, J. Usman, M. M. Jibril, A. G. Usman, and
I. H. Aljundi. 2025. “Optimization of CO2 Absorption Rate for                          Moros-­Ochoa, M. A., G. Y. Castro-­Nieto, A. Quintero-­Español, and
Environmental Applications and Effective Carbon Capture.” Journal                      C. Llorente-­Portillo. 2022. “Forecasting Biocapacity and Ecological
of Cleaner Production 490: 144707. https://​doi.​org/​10.​1016/J.​JCLEP​RO.​           Footprint at a Worldwide Level to 2030 Using Neural Networks.”
2025.​144707.                                                                          Sustainability 14: 10691.
Kshirsagar, A., and M. Shah. 2022. “Anatomization of Air Quality                       Müller, F., D. Jaeger, and M. Hanewinkel. 2019. “Digitization in Wood
Prediction Using Neural Networks, Regression and Hybrid Models.”                       Supply – A Review on How Industry 4.0 Will Change the Forest Value
Journal of Cleaner Production 369: 133383. https://​doi.​org/​10.​1016/J.​             Chain.” Computers and Electronics in Agriculture 162: 206–218. https://​
JCLEP​RO.​2 022.​133383.                                                               doi.​org/​10.​1016/j.​compag.​2 019.​0 4.​0 02.
La Porta, R., F. Lopez-­de-­Silanes, A. Shleifer, and R. Vishny. 1999. “The            Ngai, L. R., and C. A. Pissarides. 2007. “Structural Change in a
Quality of Government.” Journal of Law, Economics, and Organization                    Multisector Model of Growth.” American Economic Review 97: 429–443.
15: 222–279.                                                                           https://​pubs.​aeaweb.​org/​doi/​10.​1257/​aer.​97.1.​429.



Business Strategy and the Environment, 2026                                                                                                                       23
                                                                                                                                                                     10990836, 0, Downloaded from https://onlinelibrary.wiley.com/doi/10.1002/bse.70702 by Brahim Bergougui - Erasmus University Rotterdam U , Wiley Online Library on [09/09/2026]. See the Terms and Conditions (https://onlinelibrary.wiley.com/terms-and-conditions) on Wiley Online Library for rules of use; OA articles are governed by the applicable Creative Commons License
North, D. C. 1990. Institutions, Institutional Change and Economic                Strubell, E., A. Ganesh, and A. McCallum. 2020. “Energy and Policy
Performance. Cambridge University Press. https://​doi.​org/​10.​1017/​            Considerations for Modern Deep Learning Research.” In AAAI 2020-­
cbo97​80511​808678.                                                               34th AAAI Conference on Artificial Intelligence, 13693–13696. AAAI
                                                                                  Press. https://​doi.​org/​10.​1609/​aaai.​v34i09.​7123.
Ostrom, E. 2009. “A General Framework for Analyzing Sustainability of
Social-­Ecological Systems.” Science 325: 419–422.                                Syrquin, M. 1988. “Patterns of Structural Change.” Handbook of
                                                                                  Development Economics 1: 203–273. https://​doi.​org/​10.​1016/​S1573​-­​
Pesigan, I. J. A., M. A. Russell, and S.-­M. Chow. 2025. “Inferences and
                                                                                  4471(88)​01010​-­​1.
Effect Sizes for Direct, Indirect, and Total Effects in Continuous-­Time
Mediation Models.” Psychological Methods. https://​doi.​org/​10.​1037/​           Tao, M., and S. Wu. 2025. “Unveiling the Environmental Implications
met00​0 0779​.                                                                    of China's Industrial Robots: Empirical Investigation and Mechanism
                                                                                  Discussion.” Journal of Cleaner Production 492: 144897. https://​doi.​org/​
Pindyck, R. S. 1991. “Irreversibility, Uncertainty, and Investment.”
                                                                                  10.​1016/j.​jclep​ro.​2 025.​144897.
Journal of Economic Literature 29: 1110–1148. https://​w ww.​jstor.​org/​
stable/​2727613.                                                                  Turner, W., C. Rondinini, N. Pettorelli, et al. 2015. “Free and Open-­
                                                                                  Access Satellite Data Are Key to Biodiversity Conservation.” Biological
Popp, D. 2006. “International Innovation and Diffusion of Air Pollution
                                                                                  Conservation 182: 173–176. https://​doi.​org/​10.​1016/j.​biocon.​2014.​11.​048.
Control Technologies: The Effects of NOX and SO2 Regulation in the
US, Japan, and Germany.” Journal of Environmental Economics and                   van der Woude, D., G. Y. Castro Nieto, M. A. Moros Ochoa, C. Llorente
Management 51: 46–71. https://​doi.​org/​10.​1016/j.​jeem.​2 005.​0 4.​0 06.      Portillo, and A. Quintero. 2024. “Artificial Intelligence in Biocapacity
                                                                                  and Ecological Footprint Prediction in Latin America and the
Porter, M. E., and J. E. Heppelmann. 2014. “How Smart, Connected
                                                                                  Caribbean.” Environment, Development and Sustainability 27: 22925–
Products Are Transforming Competition.” Harvard Business Review 92:
                                                                                  22946. https://​doi.​org/​10.​1007/​s1066​8-­​024-­​05101​-­​7.
64–88.
                                                                                  Verdolini, E., and M. Galeotti. 2011. “At Home and Abroad: An Empirical
Porter, M. E., and C. van der Linde. 1995. “Toward a New Conception of
                                                                                  Analysis of Innovation and Diffusion in Energy Technologies.” Journal
the Environment-­Competitiveness Relationship.” Journal of Economic
                                                                                  of Environmental Economics and Management 61: 119–134. https://​doi.​
Perspectives 9: 97–118. https://​doi.​org/​10.​1257/​jep.9.​4.​97.
                                                                                  org/​10.​1016/j.​jeem.​2 010.​08.​0 04.
Potter, A., and S. Graham. 2019. “Supplier Involvement in Eco-­
                                                                                  Wang, Q., F. Zhang, R. Li, and J. Sun. 2024. “Does Artificial Intelligence
Innovation: The Co-­Development of Electric, Hybrid and Fuel Cell
                                                                                  Promote Energy Transition and Curb Carbon Emissions? The Role of
Technologies Within the Japanese Automotive Industry.” Journal of
                                                                                  Trade Openness.” Journal of Cleaner Production 447: 141298. https://​
Cleaner Production 210: 1216–1228. https://​doi.​org/​10.​1016/j.​jclep​ro.​
                                                                                  doi.​org/​10.​1016/j.​jclep​ro.​2 024.​141298.
2018.​10.​336.
                                                                                  Wang, X., M. U. Khan, and F. W. Mir. 2025. “Artificial Intelligence as
Romer, P. M. 1990. “Endogenous Technological Change.” Journal of
                                                                                  Heterogeneous Agents in Environmental Performance: The Mediating
Political Economy 98: S71–S102. https://​doi.​org/​10.​1086/​261725.
                                                                                  Role of Energy Transition and the Moderating Effect of Green Technology
Schumpeter, J. 2021. The Theory of Economic Development. Routledge.               Adoption in Belt and Road Initiative Countries.” Journal of Cleaner
https://​doi.​org/​10.​4324/​97810​03146766.                                      Production 523: 146331. https://​doi.​org/​10.​1016/J.​JCLEP​RO.​2025.​146331.
Schwartz, R., J. Dodge, N. A. Smith, and O. Etzioni. 2020. “Green AI.”            Williamson, O. E. 1979. “Transaction-­Cost Economics: The Governance
Communications of the ACM 63: 54–63. https://​doi.​org/​10.​1145/​3381831.        of Contractual Relations.” Journal of Law and Economics 22: 233–261.
                                                                                  https://​doi.​org/​10.​1086/​4 66942.
Seto, K. C., B. Güneralp, and L. R. Hutyra. 2012. “Global Forecasts
of Urban Expansion to 2030 and Direct Impacts on Biodiversity and                 Xia, Y., and M. Ahmad. 2025. “Industrial Robotics, Resource
Carbon Pools.” Proceedings of the National Academy of Sciences 109:               Efficiency, Energy Transition, and Environmental Quality: Designing
16083–16088. https://​doi.​org/​10.​1073/​pnas.​12116​58109​.                     a Sustainable Development Goals Framework for G7 Countries in the
                                                                                  Presence of Geopolitical Risk.” Sustainability 17, no. 5: 1960. https://​doi.​
Shapiro, J. S. 2021. “The Environmental Bias of Trade Policy*.” Quarterly
                                                                                  org/​10.​3390/​su170​51960​.
Journal of Economics 136: 831–886. https://​doi.​org/​10.​1093/​q je/​q jaa042.
                                                                                  Xu, D., S. Abbas, K. Rafique, and N. Ali. 2023. “The Race to Net-­Zero
Shrout, P. E., and N. Bolger. 2002. “Mediation in Experimental and
                                                                                  Emissions: Can Green Technological Innovation and Environmental
Nonexperimental Studies: New Procedures and Recommendations.”
                                                                                  Regulation Be the Potential Pathway to Net-­Zero Emissions?” Technology
Psychological Methods 7: 422–445.
                                                                                  in Society 75: 102364. https://​doi.​org/​10.​1016/j.​techs​oc.​2023.​102364.
Siddik, M. A. B., A. Shehabi, and L. Marston. 2021. “The Environmental
                                                                                  Yu, L., Y. Wang, X. Wei, and C. Zeng. 2023. “Towards Low-­Carbon
Footprint of Data Centers in the United States.” Environmental Research
                                                                                  Development: The Role of Industrial Robots in Decarbonization in
Letters 16: 064017. https://​doi.​org/​10.​1088/​1748-­​9326/​abfba1.
                                                                                  Chinese Cities.” Journal of Environmental Management 330: 117216.
Song, J., Y. Chen, and F. Luan. 2023. “Air Pollution, Water Pollution,            https://​doi.​org/​10.​1016/j.​jenvm​an.​2 023.​117216.
and Robots: Is Technology the Panacea.” Journal of Environmental
                                                                                  Zhong, J., Y. Zhong, M. Han, T. Yang, and Q. Zhang. 2024. “The Impact
Management 330: 117170. https://​doi.​org/​10.​1016/j.​jenvm​an.​2 022.​
                                                                                  of AI on Carbon Emissions: Evidence From 66 Countries.” Applied
117170.
                                                                                  Economics 56: 2975–2989. https://​doi.​org/​10.​1080/​0 0036​8 46.​2 023.​
Song, Y., Z. Wang, C. Song, J. Wang, and R. Liu. 2024. “Impact of                 2203461.
Artificial Intelligence on Renewable Energy Supply Chain Vulnerability:
                                                                                  Zhou, H., J. Fan, and T. Gan. 2024. “The Impact of Industrial Robots
Evidence From 61 Countries.” Energy Economics 131: 107357. https://​
                                                                                  on Export Stability.” World Economy 47: 3780–3808. https://​doi.​org/​10.​
doi.​org/​10.​1016/j.​eneco.​2 024.​107357.
                                                                                  1111/​t wec.​13602​.
Sorrell, S., J. Dimitropoulos, and M. Sommerville. 2009. “Empirical
                                                                                  Zhou, W., Y. Zhuang, and Y. Chen. 2024. “How Does Artificial
Estimates of the Direct Rebound Effect: A Review.” Energy Policy 37:
                                                                                  Intelligence Affect Pollutant Emissions by Improving Energy Efficiency
1356–1371. https://​doi.​org/​10.​1016/j.​enpol.​2 008.​11.​026.
                                                                                  and Developing Green Technology.” Energy Economics 131: 107355.
Stavins, R. N. 2003. “Experience With Market-­Based Environmental                 https://​doi.​org/​10.​1016/j.​eneco.​2 024.​107355.
Policy Instruments.” In Environmental Degradation and Institutional
Responses, edited by K.-­G. Mäler and J. R. B. T.-­H. o. E. E. Vincent, 355–
435. Elsevier. https://​doi.​org/​10.​1016/​S1574​- ­​0 099(03)​01014​-­​3.



24                                                                                                                 Business Strategy and the Environment, 2026
