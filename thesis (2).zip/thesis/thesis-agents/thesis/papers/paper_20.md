                                                                     Renewable Energy 238 (2025) 121883


                                                                   Contents lists available at ScienceDirect


                                                                       Renewable Energy
                                                         journal homepage: www.elsevier.com/locate/renene




Towards secure energy systems: Examining asymmetric impact of energy
transition, environmental technology and digitalization on Chinese
city-level energy security
Brahim Bergougui a,b,* , Syed Mansoob Murshed a , Muhammad Shahbaz c,d,
Manuel A. Zambrano-Monserrate e, Ahmed Samour f, Mohammed Ibrahim Aldawsari g
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
b
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
c
  School of Economics, Beijing Institute of Technology, Beijing, China
d
  GUST Center for Sustainable Development (CSD), Gulf University for Science and Technology, Hawally, Kuwait
e
  Universidad Espíritu Santo, Samborondón, Ecuador
f
  Accounting Department, Dhofar University, Salalah, Sultanate of Oman
g
  Department of Education Policy and Economics, Education College, Taibah University, Medina, Saudi Arabia




A R T I C L E I N F O                                    A B S T R A C T

JEL classification:                                      This study aims to investigate the asymmetric impacts of energy transition (ETI), environmental technology
H20                                                      (ENT), and digitalization (DEI) on energy security (ESI) across Chinese cities, addressing a significant gap in
Q55                                                      empirical research at the city level. We employ the Method of Moments Quantile Regression (MMQR) to analyze
Q58
                                                         data from 275 Chinese cities over the period 2007–2020, examining the differential effects of positive and
Keywords:                                                negative shocks in ETI, ENT, and DEI on ESI across various quantiles. Utilizing MMQR, the analysis yields several
Energy security
                                                         key findings: (i) Positive shocks in ETI benefit cities with high pre-existing ESI, while negative shocks surprisingly
Energy transition
Environmental technology
                                                         provide a temporary boost to low-security cities but ultimately hinder progress at higher levels. (ii) Positive
Digitalization                                           shocks in DEI correlate with higher ESI, especially in cities with moderate to high baseline security, whereas
MMQR                                                     negative shocks in DEI exhibit minimal influence on ESI. (iii) Positive shocks in ENT generally enhance energy
Chinese cities                                           security across all quantiles except the lowest, indicating that advancements benefit cities at various security
                                                         levels. Notably, negative shocks initially decrease ESI at the lowest quantile but subsequently increase it at
                                                         moderate to high levels. These findings highlight the complex, non-linear relationships between ETI, ENT, DEI,
                                                         and ESI in Chinese cities. The study provides quantitative evidence for policymakers to develop nuanced stra-
                                                         tegies that balance energy transition, digitalization, and environmental technology advancements with energy
                                                         security goals. Future research should explore the mechanisms underlying these asymmetric effects and their
                                                         implications for sustainable urban development in China.



Acronym table                                                                                  (continued )
                                                                                                Acronym               Full Form
    Acronym                Full Form
                                                                                                CSD                   Cross-Sectional Dependence
    ARDL                   Autoregressive Distributed Lag                                       DEI                   Digital Economy Index
    CADF                   Cross-Sectional Augmented Dickey-Fuller                              ENT                   Environmental Technology
    CESY                   China Energy Statistical Yearbook                                    ESI                   Energy Security Index
    CSY                    China Statistical Yearbook                                           ETI                   Energy Transition Index
    CSYE                   China Statistical Yearbook of Environment                            GDP                   Gross Domestic Product
    CSYST                  China Statistical Yearbook of Science and Technology                 GEI                   Global Energy Institute
                                                            (continued on next column)                                                                (continued on next page)



 * Corresponding author. International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands.
   E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com (B. Bergougui), murshed@iss.nl (S.M. Murshed), muhdshahbaz77@gmail.com (M. Shahbaz),
manuelzambranom@uees.edu.ec (M.A. Zambrano-Monserrate), asamour@du.edu.om (A. Samour), mdawsari@taibahu.edu.sa (M.I. Aldawsari).

https://doi.org/10.1016/j.renene.2024.121883
Received 9 July 2024; Received in revised form 22 October 2024; Accepted 11 November 2024
Available online 12 November 2024
0960-1481/© 2024 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                                              Renewable Energy 238 (2025) 121883

(continued )                                                                          negative shocks in these three areas on energy security are examined
  Acronym               Full Form                                                     across the distribution of energy security outcomes in China, analyzing
  HC                    Human Capital
                                                                                      whether positive shocks reduce energy security and negative shocks
  INDS                  Industrialization                                             increase it at low, middle, and upper quantiles. Examining a prominent
  MMQR                  Method of Moments Quantile Regression                         global actor whose policies and decisions may profoundly influence the
  OECD                  Organisation for Economic Co-operation and Development        international energy supply chain, and consequently, risks related to
  PSYs                  Provincial Statistical Yearbooks
                                                                                      energy security is a judicious choice.
  QQR                   Quantile-on-Quantile Regression
  R&D                   Research and Development                                          Secondly, a novel energy security index is employed, constructed
  URB                   Urbanization                                                  using a composite measure that integrates energy industry investment,
  WEF                   World Economic Forum                                          energy supply, energy use, and environmental impact through the en-
                                                                                      tropy weighting method. This comprehensive index covers traditional
                                                                                      dimensions of energy security, such as affordability, acceptability, and
                                                                                      availability of energy supply, while also incorporating economic, social,
1. Introduction                                                                       and environmental dimensions.
                                                                                          Thirdly, the nonparametric MMQR (Method of Moments Quantile
     Climate change presents a significant challenge, primarily driven by             Regression) method is utilized to address misspecification bias and
rising greenhouse gas concentrations causing global warming, extreme                  capture the effects of energy transition, environmental technology, and
weather events, and ecological disturbances [1,2]. Proposed solutions                 digitalization on the distribution tails of energy security. This approach
include transitioning to renewable energy sources like solar, wind,                   not only mitigates misspecification bias but also highlights the differ-
hydro, and geothermal to reduce fossil fuel reliance and emissions [3].               ential impacts of these factors on the lower, middle, and upper ends of
Rapidly developing economies, like China, face surging energy demands                 the energy security distribution. Moreover, asymmetries are accounted
due to industrialization and urbanization, necessitating energy-efficient             for through partial sum decompositions of positive and negative changes
technologies and sustainable practices [4,5]. Energy consumption links                in the independent variables, enabling a clear distinction between the
closely to living standards and economic prosperity, with demand rising               effects of upward and downward trends. This methodological approach
as incomes and consumption increase [6]. Secure energy supplies are                   is particularly suited to the significant structural transformations in
vital for economic stability and industrial activities, with manufacturing            China’s macroeconomy in recent decades, offering a more nuanced
being particularly sensitive to energy availability and affordability [7].            understanding compared to traditional methods used in prior energy
China’s manufacturing sector drives economic growth, employment,                      security analyses. By incorporating these essential dimensions, the study
and exports, making it critical for the country’s development and global              provides a detailed and unbiased assessment of the key drivers affecting
competitiveness [8]. However, energy security faces compounding                       China’s energy security, offering valuable insights for policymakers in
threats from geopolitical tensions exacerbated by the recent                          shaping effective energy strategies.
Russia-Ukraine war and ongoing Middle Eastern conflicts. These dis-                       The rest of the paper is organized as follows: Section-II contains a
ruptions, coupled with the COVID-19 pandemic’s economic impact,                       brief relevant literature survey followed by an outline of the theoretical
have caused unprecedented energy price surges [9–11].                                 channels. This is followed by a methodological Section-III, which is
     Taking these factors into account, it is agreed that ensuring energy             important as there are many methodological pitfalls. Empirical results
security is a complex issue requiring efforts from all entities, especially           are presented in Section-IV. Conclusion and policy implications are
those lacking energy resources. In the latter instance, three distinctive             drawn in Section-V.
pathways emerge through which to pursue and secure energy security:
transitioning towards renewable energy [3]. Investing in and adopting                 2. Literature review
green technologies [12], and utilizing digital tools for energy manage-
ment [13]. All require varying levels of research and development in-                 2.1. Theoretical framework
vestment. Importantly, even resource-rich countries need to prioritize
environmental sustainability. Climate change and global warming are                       Energy security is a prime parameter for ensuring national security
global issues, and all nations have a responsibility to address them,                 [14]. Global Energy Institute (GEI) defined energy security as “unin-
regardless of their resource endowment. Energy security must be                       terrupted access to energy sources at an affordable price”. According to
reconsidered with a focus on environmental protection and adherence to                GEI, this concept combines four dimensions: geopolitical, reliability,
international agreements. In this sense, this study leverages a compre-               economic, and environmental (Global Energy Institute, 2020). Other
hensive panel dataset encompassing 275 Chinese cities over 14 years                   scholars have defined energy security based on short- and long-term
(2007–2020). The data captures city-level variations in energy security,              approaches. In the short-term approach, energy security is regarded as
economic activity, resource availability, and environmental pressures.                “an interrupted availability of energy sources at an affordable price”.
China serves as a compelling case due to its preeminent global ranking in             While energy security based on a long-term approach concerns energy
energy consumption and the substantial heterogeneity exhibited across                 supply security and other environmental issues related to energy de-
its cities. This marked inter-city variability facilitates a robust analysis of       mand and supply [15]. Based on these definitions, the main elements are
how energy transition initiatives, environmental technology adoption,                 (i) secure supplies of affordable energy resources, (ii) use of different
and digitalization efforts differentially influence energy security at the            foreign suppliers of energy and diversification of energy sources (iii)
city level. Additionally, the granular nature of the city-level data fosters          secure transportation of energy sources. Besides, energy security con-
the identification of nuanced patterns and trends, offering valuable in-              siders all prospective market changes and spillover effects that affect the
sights for policymakers crafting and implementing effective strategies.               energy supply chain [16]. To determine and capture energy security,
     Building upon the preceding analysis, this study offers several key              scholars have used single indicators such as Hirschman index, and
contributions to the existing literature on energy security. Firstly, it              comprehensive indicators by combining several factors to capture en-
pioneers an empirical investigation into the impact of energy transition,             ergy security [14]. However, energy security is a complex issue to which
environmental technology, and digitalization on city-level energy se-                 all governments and organizations need to pay more attention to meet
curity within the Chinese context. This exploration is particularly                   their energy demand [3]. One of the main factors affecting energy se-
pertinent given China’s status as the world’s foremost energy-                        curity in the energy transition process by moving from fuel consumption
consuming economy and its considerable interest in these de-                          to renewable energy use. Therefore, renewable energy is considered as
terminants of energy security. The differential effects of positive and               one of the main energy security determinates. In this line, Cergibozan

                                                                                  2
B. Bergougui et al.                                                                                                           Renewable Energy 238 (2025) 121883


(2018) stated that renewable energy can affect energy security by                 2.3. Environmental technology and energy security
securing the energy supply and supporting the country’s energy di-
versity. Hence, increasing the level of renewable energy will mitigate                Environmental technology has a positive role in energy and ecolog-
fossil fuel energy use and decrease energy dependency and imports.                ical sustainability. For instance, Zakari et al. (2022) found that ecolog-
However, fossil fuel sources such as oil or gas will be exhausted.                ical technology is positively associated with environmental quality in
Conversely, renewable energy sources are renewable sources that have              Australia’s context. Kirikkaleli et al. (2022) demonstrated that envi-
positive impacts on environmental quality and decrease the country’s              ronmental technologies are positively linked to ecological sustainability
dependency on fossil fuel imports. This fact affirms the importance of            by decreasing pollution in the case of the USA. Alola and Adebayo
energy transition in enhancing energy security by shifting the con-               (2022) suggested that environmental-related technology can play a
sumption from fossil-fuel sources to renewable energy sources.                    positive role in simulating environmental sustainability in the Nordic
    Another factor that may affect energy security is environmental               region by enhancing the level of green energy use and green technolo-
technology. This factor focuses on technology that catches and manages            gies. Sun et al. [29] assed that environmental-related technologies are
ecological pollution before they are released into the environment [17].          positively connected to load capacity factor, indicating that more
Hence, technological advances can positively promote energy transition            environmental-related technologies can play a positive role in
and environmental sustainability by enhancing the efficiency of other             enhancing environmental sustainability in the case of 17 APEC econo-
factors, such as green energy and ecological policies. As a type of               mies. Ahmed et al. [30] suggested that environmental-related technol-
technology, digitalization may affect energy security by its reinforcing          ogies are positively associated with green energy growth in the case of
effect on human capital and economic development. In this way, Ha                 top-polluted economies. Paramati et al. [31] used a data set for 28
[18] proposed that digitalization can play a positive role in simulating          OECD economies from 1990 to 2014 and found that environmental
energy production management and promoting energy efficiency and                  technology helps the OECD countries to promote energy efficiency.
security. In this context, the use of more modern digital technologies,           However, few empirical studies focused on the impact of technology on
such as cloud computing, can play a significant role in ensuring energy           energy security. For example, Lee et al. [13] utilized panel data for 66
security, especially energy availability. Likewise, digital technologies          economies from 1996 to 2019 to assess communication
may decrease the cost of energy investment and production and stimu-              technology-energy security linkage. They demonstrated that technology
late energy efficiency, thus enhancing the country’s energy security              strongly affects energy security via the human capital channel. Recently,
[19].                                                                             Aslam et al.assessed the effect of environmental regulations on energy
                                                                                  security risk in top energy-intensive economies, they indicated that
2.2. Energy transition and energy security                                        environmental regulations directly and indirectly decrease the level of
                                                                                  energy security risks by shifting to energy sources. Several studies
    During the last few decades, governments and environmental                    focused on the importance of green technological innovation on
scholars have been interested in energy security issues. Some scholars            ecological sustainability and energy efficiency. Most of these studies
assessed the benefits of renewable energy or energy transition (e.g. Refs.        ignored the role of green technological innovation in reducing the en-
[20–22]). Some of the studies focused on the importance of renewable              ergy security risk. Based on the author’s knowledge, no study focuses on
energy on energy security; Khan et al. [23] used the MMQR approach                environmental technology and energy security.
and found that an increase in renewable energy stimulates energy se-
curity in the case of G7 economies. Paravantis and Kontoulis [24] sug-            2.4. Digitalization and energy security
gested that more green energy sources positively influence energy
security in the context of the United States, China, and Russia. Pros-                Many scholars have investigated the impact of digitalization on en-
kuryakova [16] concluded that the energy technology in China, Russia,             ergy. For example, Shahbaz et al. [19] employed panel data from 72
and Germany significantly affects the energy security policy in these             economies from 2003 to 2019 and found that digitalization promotes
economies. Cergibozan [25] assessed the effect of renewable energy                the energy transition by enhancing governments’ governance capabil-
sources in the context of OECD on energy security risk and suggested              ities. Bagherian et al. (2023) suggested a positive interconnection be-
that hydroelectricity, wind, and total renewable energy decrease the              tween digitalization and energy sustainability in the European
energy security risk. Recently, Tugcu and Menegaki [3] suggested                  economies. Zhao et al. [14] examined the impact of digitization on en-
directional causal interconnection among clean energy sources and en-             ergy storage in Chinese provinces. They suggested that digitization
ergy security in G7 countries in the short run. Their findings also sug-          contributes to improving energy storage in China. Matthess et al. [32]
gested that renewable sources decrease the energy security risk. Bashir           found that digitalization positively affects energy intensity in
et al. [26] suggested that energy transition positively ensures ecological        manufacturing sectors in Europe. In this context, Das and Basu [33]
sustainability in the leading manufacturing economies. Razzaq et al.              suggested that linking distant connections to microgrids will improve
[27] illustrated that their energy transition positively impacts environ-         energy efficiency via optimized systems driven by the Internet of Things
mental governance in the case of 37 IEA economies. Recently, Aslam                and cloud servers. On the other hand, some scholars assessed the impact
et al. investigates the impact of energy transition on energy security risk       of digitalization on energy security. Ha et al. (2022) used the data set for
for 41 Belt and Road Initiative over the period from 1995 to 2018. The            24 European countries from 2011 to 2011. Their findings illustrated that
author suggests more energy transition reduces energy security risk for           digitalization significantly enhances the acceptability and development
tested BRI economies. Joof et al. [28] suggest that energy transition             of energy security in European countries. Using the ARDL approach,
reduces has a positive role in enhancing ecological sustainability. Even          Thanh et al. [15] assessed the link among digitalization and energy se-
though fossil fuels sources contribute more to economic development               curity in context of European countries, they indicated that trans-
than green energy sources, these sources are not renewable sources. In            formation positively impacts energy security in 27 European countries.
conclusion, renewable energy comes from a source that won’t run out,              Recently, Wang and Ullah [34] assessed the linkage among digitaliza-
suggesting the renewable energy transition can play a positive role in            tion and energy security in top energy-consuming developed and
refinancing energy security. Based on the current literature review,              developing economies. According to the authors, the energy security
several studies affirm that that non renewable energy sources such as oil,        risks can be mitigated by more shifting to renewable energy use and
coal and natural gas consumption adversely affect ecological sustain-             production.
ability and energy security by increasing the level of carbon emissions,
whereas renewable energy such as solar may play a positive role in
promoting ecological sustainability and energy security.

                                                                              3
B. Bergougui et al.                                                                                                                            Renewable Energy 238 (2025) 121883


2.5. Literature gap                                                                       decreases in these variables might have varying impacts [39]. To explore
                                                                                          this possibility, the study further divides the changes in each variable
    Several empirical assessed energy security determents. Some of these                  into positive and negative shocks, represented as:
empirical studies have focused on the influence of energy transition,                         The positive shocks 〈ETI+i,t , DEI+i,t , and ENT +i,t 〉 and the negative
environmental technology, and digitalization on energy security. For                      shocks 〈ETI− i,t , DEI− i,t , and ENT − i,t 〉.
example, some studies assessed the linkage among energy transition and                        where:
energy security (e.g., Ref. [23]; Paravantis and Kontoulis 202 [16];                      {                (          )                 (    )                      (        )
Tugcu and Menegaki,2024;). Other studies focused on the linkage                             ETI+i,t = max 0,ETIi,t ,DEI+i,t = max 0,DEIi,t ,and ENT +i,t = max 0,ENTi,t
                                                                                                            (         )                (     )                    (         )
among digitalization and energy efficiency [31,32]. While some studies                       ETI− i,t = min 0,ETIi,t ,DEI− i,t = min 0,DEIi,t ,and ENT − i,t = min 0,ENTi,t
focused on the linkage among technological innovation and energy ef-
ficiency [13]. Most of these studies focused on symmetries effects of                         Equation-2 is then improved as equation-3 below:
renewable energy transition, macroeconomic factor on energy security.
To fill the gap in the present literature, we use the novel nonparametric                 ESIi,t = β0 + α1,1 ETI+i,t + α1,2 ETI− i,t + α2,1 DEI+i,t + α2,2 DEI− i,t + α3,1 ENT+i,t
MMQR technique to assess asymmetries effects of energy transition,                          + α3,2 ENT − i,t + α4 GDPi,t + α5 HCi,t + α6 RDi,t + α7 URBi,t + μi,t
environmental technology, and digitalization on the distribution tails of
                                                                                                                                                                              (3)
energy security. This technique is a suitable method to address the
structural economic transformations in China. Besides, the present
research aims to fill the gap in the literature by testing the impact of the              3.2. Quantile regression via method of moments (MMQR)
energy transition, environmental technology, and digitalization on en-
ergy security in the context of China. Most of the studies ignored the                         The field of energy economics frequently encounters data with
impact of ecological technology, and digitalization on energy security in                 distinct peaks or heavy tails [40]. Existing studies often rely on panel
the case of China using a novel energy security index constructed using a                 data models based on conditional mean regression [41]. However, this
composite indicator. This measure integrates energy industry invest-                      approach disregards the inherent heterogeneity in the impact of driving
ment, supply, use, and environmental effects via the entropy weighting                    factors on energy security. Notably, neglecting this heterogeneity can
method.                                                                                   lead to biased estimates in panel data models [42]. To address this
                                                                                          limitation, panel quantile regression is employed for model estimation.
3. Methodology                                                                            This method offers a systematic approach to investigate the influence of
                                                                                          driving factors on the Energy Security Index (ESI) across the entire
3.1. Econometric model                                                                    conditional distribution of ESI for Chinese cities. Additionally,
                                                                                          compared to conditional mean regression, quantile regression can pro-
    This study builds upon the framework established by Ref. [35] and                     vide more robust estimates (Machado and Silva 2019). Traditional panel
integrates insights gleaned from prior research. It posits that energy                    quantile regression methodologies are insensitive to conditionally
security is likely influenced by a diverse range of factors, encompassing                 weakly associated variables, they fail to account for unobserved
population dynamics, economic activity, and technological advance-                        cross-sectional heterogeneity. This issue is effectively addressed by the
ments [36–38]. Building upon this foundation, three key independent                       MMQR approach (Machado and Silva, 2019). In contrast to
variables are introduced into the proposed theoretical model.                             location-shifting approaches, MMQR acknowledges the influence of
                                                                                          both the location and scale functions on the conditional distribution of
 • Energy Transition Index (ETI)                                                          ESI. Among non-linear models, MMQR stands out due to its ability to
 • Digital Economy Index (DEI)                                                            handle asymmetries in the location parameter, endogeneity, and het-
 • Environmental Technology (ENT)                                                         erogeneity [43,44]. These features provide distinct advantages over
                                                                                          existing panel data estimation techniques, making MMQR a particularly
    The model is represented by the following equation-1:                                 well-suited choice for this study. The basic quantile regression model is
                                                                      )                   specified in equation-4.
ESIi,t = f(ETIi,t , DEIi,t , ENTi,t , GDPi,t , HCi,t , RDi,t , URBi,t           (1)            ( ⃒ )
                                                                                          Qyi,t τ⃒Xi,t = βτ + Xʹi,t ατ                                          (4)
where i and t represent the 275 Chinese cities and year, respectively.                                                                       (    )
ESIi,t , energy security index, ETIi,t denotes energy transition index, DEIi,t            Within the context of the model, 0 < τ < 1, Qyi,t τ|xi,t denote the τ th
denotes the digital economy index, ENTi,t denotes environmental tech-                     conditional quantile. The parameter denoted by ατ serves as an estimate
nology, GDPi,t denotes economic development level, HCi,t denotes                          for the corresponding independent variable. In contrast, βτ captures the
human capital, RDi,t denotes R&D investment level, URBi,t denotes ur-                     influence of unobserved factors. The independent variable itself is rep-
banization level. To address potential heteroskedasticity, the natural                    resented by the symbol X. The process of estimating the coefficients
logarithm is applied to each variable. This transformed model is depic-                   associated with τ th conditional quantile is outlined in equation-5.
ted in equation-2:                                                                                        n
                                                                                                          ∑       (                     )
                                                                                          ̂ τ = arg min
                                                                                          α                     ρτ yi − βτ − Xʹi,t ατ                                         (5)
ESIi,t = β0 + α1 ETIi,t + α2 DEIi,t + α3 ENTi,t + α4 GDPi,t + α5 HCi,t + α6 RDi,t                         i=1

   + α7 URBi,t + μi,t
                                                                                          where ρτ = μ ( τ − I(μ < 0)) is defined as a check function. I(.) is denoted
                                                                                (2)       as the indicator function. Therefore, equation-6 represents the corre-
                                                                                          sponding quantile regression models arising from equation-3.
In this model, the parameters α1 to α7 represent elasticities, quantifying
                                                                                                 ( ⃒         )
the percentage change in ESI in response to a 1 % increase in the cor-
                                                                                          QESIi,t τ⃒βi , Xi,t = βi + α1,1 ETI+i,t + α1,2 ETI− i,t + α2,1 DEI+i,t + α2,2 DEI− i,t
responding independent variable. This study specifically focuses on
estimating α1, α2, and α3, which capture the impacts of ETI, DEI, and                                             + α3,1 ENT +i,t + α3,2 ENT − i,t + α4 GDPi,t + α5 HCi,t
ENT on ESI, respectively. Finally, β0 represents the constant term in the                                         + α6 RDi,t + α7 URBi,t + μi,t
model, and μi,t denotes the error term. Equation-1 assumes symmetric                                                                                                          (6)
effects of changes in ETI, DEI, and ENT on ESI, existing literature sug-
gests that these effects might be asymmetric, meaning that increases and                  In order to estimate quantile regression for equation-6, a set of quantile

                                                                                      4
B. Bergougui et al.                                                                                                           Renewable Energy 238 (2025) 121883


levels (τ): 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, and 0.90 are           oil price fluctuations [46]. However, as the understanding of climate
selected. These nine quantile levels are further categorized into three            change and sustainability deepened, the concept expanded to encom-
groups.                                                                            pass energy, environmental, economic, and social development di-
                                                                                   mensions. This shift led to the integration of multiple indicators into
 • Lower quantiles: τ = 0.10, 0.20, 0.30                                           detailed indices for measuring energy security, a practice now widely
 • Middle quantiles: τ = 0.40, 0.50, 0.60                                          adopted for tracking energy security within countries. In line with this
 • Upper quantiles: τ = 0.70, 0.80, 0.90                                           trend, researchers in China developed Energy Security Index (ESI) to
                                                                                   holistically evaluate the country’s energy security situation (Wang et al.,
    This categorization is employed to associate quantile levels with              2024). The ESI is a multi-dimensional metric that integrates 11 key
different levels of the energy security index.                                     parameters spanning energy generation capacity, supplies, operational
                                                                                   efficiency, end-use patterns, and emissions. The parameters cover fixed
 • Lower quantiles correspond to low energy security.                              asset investment in energy, foreign reserves, energy usage costs, energy
 • Middle quantiles correspond to moderate energy security.                        intensity, carbon intensity, government’s green development focus,
 • Upper quantiles correspond to high energy security.                             nitrogen/sulfur oxide emissions, industrial pollution, patents granted,
                                                                                   sectoral economic ratios, and population growth. The overarching goal
   By estimating the quantile regression at these different levels, This           of the Energy Security Index is to provide a comprehensive under-
approach provides insights into the relationship between the indepen-              standing of the temporal changes and trends in energy security within a
dent variables and the conditional distribution of the dependent variable          specific city or region. By integrating multiple dimensions, ESI offers a
across the spectrum of the energy security index.                                  holistic assessment of energy security, encompassing not only supply
                                                                                   and demand factors but also environmental considerations.
                                                                                       Figure 1 presents a visual representation of Energy Security Index
3.3. Data specification                                                            levels across 28 provinces in China for the years 2007 and 2019. It al-
                                                                                   lows for an examination of regional variations and temporal changes in
3.3.1. Sample selection and data sources                                           energy security within the country over this period. In 2007, higher ESI
    This study utilizes a 14-year dataset encompassing the period 2007             levels were concentrated in the provinces of Chongqing, Hainan, and
to 2019. The specific timeframe was chosen due to the availability of              Qinghai. However, by 2019, the regions with higher ESI had shifted
relevant statistical data. As of 2019, the People’s Republic of China              towards Tianjin, Anhui, and Neimenggu. This suggests a change in the
comprised 293 prefecture-level cities according to the administrative              geographical distribution of energy security over time. Notably, in 2007,
divisions statistical table. However, due to missing data in certain cities,       all Chinese provinces had an ESI score below 0, indicating complete
the final sample employed in this analysis incorporates data from 275              dependence on energy imports. However, the situation improved by
Chinese cities. All data were meticulously compiled from official sour-            2019, with Tianjin achieving an impressive ESI of 4.86. This significant
ces, including the China Energy Statistical Yearbook (CESY), China                 positive value implies that Tianjin has become an energy exporter
Statistical Yearbook (CSY), Provincial Statistical Yearbooks (PSYs),               capable of not only meeting its own energy consumption needs but also
China Statistical Yearbook of Science and Technology (CSYST), and                  exporting surplus energy to other provinces.
China Statistical Yearbook of Environment (CSYE).
                                                                                   3.3.3. Core independent variables
3.3.2. Dependent variable (energy security index)
   Assessing a nation’s energy security has evolved from simplistic                   (i) Energy Transition Index
single indicators to a multi-dimensional and comprehensive approach
[45]. Initially, energy security was evaluated using singular metrics like




                                       Fig 1. Mapping China’s Energy Security Index across Provinces: 2007 vs. 2019.

                                                                               5
B. Bergougui et al.                                                                                                          Renewable Energy 238 (2025) 121883


    Shen et al. [47] developed a comprehensive city-level Energy Tran-             in information technology and software services, internet broadband
sition Index (ETI) comprising two sub-indices, six dimensions, and 18              subscribers, mobile phone subscribers, and telecommunication business
components, with a total of 33 indicators. The energy system perfor-               revenue. To minimize subjective bias in weighting these components,
mance sub-index evaluates the current energy system status across en-              the Principal Component method is employed, ensuring an objective and
ergy system structure and environmental sustainability dimensions. The             data-driven approach to determining the weights of the diverse com-
transition readiness sub-index gauges a city’s preparedness for future             ponents of DEI. Figure 3 presents a visual representation of the level of
energy transition via economic development, capital & investment,                  Digital Economy Index (DEI) across 28 provinces in China for the years
technology capability, and human capital dimensions. Their compre-                 2007 and 2019. DEI refers to the economic activities and transactions
hensive definition of transition readiness offers an advantage over the            that are enabled by digital technologies and the internet. The data re-
World Economic Forum’s (WEF) methodology for national ETI frame-                   veals a notable rise in the overall level of digitalization within the
work at the city level, as decarbonization requires additional support             country over the past decade. However, the Fig. 3 also highlights a
from infrastructure, investment, technologies, governance, and public              significant disparity in development between different provinces. While
education. The ETI scores were calculated using an equal-weighting                 provinces like Beijing, Tianjin, and Qinghai showcase relatively
approach at each aggregation step, aligning with the WEF’s methodol-               advanced digital economies, certain regions in northwest and northeast
ogy and previous research suggesting no prior justification to favor any           China appear to lag in this domain (see Fig. 4).
sub-index, dimension, or component [48].                                               The extant literature highlights the significant influence of ENT on
    Figure-2 presents the distribution of Energy Transition Index scores           ESI. Previous studies have demonstrated that by adopting and investing
for 28 provinces across China in 2010 and 2019. ETI is a measure of a              in ENT, countries and regions can diversify their energy sources, reduce
city’s progress towards transitioning to a low-carbon energy system.               dependence on imported fossil fuels, improve energy efficiency, and
Figure 2 reveals that the national average ETI score for these 28 prov-            enhance the resilience of their energy systems, ultimately these factors
inces improved consistently from 2010 to 2019, indicating an overall               lead to increased energy security, reducing vulnerabilities to supply
positive trend in the energy transition process across China during this           disruptions, price fluctuations, and geopolitical risks associated with
period. However, a closer examination of the data unveils substantial              traditional energy sources [52]. Environmental patents are a widely
regional disparities among the provinces. While some provinces ach-                recognized indicator for measuring ENT [2,5,53,54,54,55]. In line with
ieved significant improvements in their ETI scores between 2010 and                established research, this study employs the number of patents granted
2019, others lagged behind, suggesting uneven progress in energy                   in environment-related technologies as a proxy for ENT [56].
transition across different regions of the country. This heterogeneity in
ETI scores among provinces highlights the need for city-specific low-              3.3.4. Control variables
carbon roadmaps and strategies, rather than adopting a uniform, one-                   To isolate the specific effects of ETI, DEI, and ENT on ESI, this
size-fits-all approach to energy transition. The unique circumstances,             research introduces a set of control variables. These variables account
resources, and challenges faced by each province necessitate tailored              for the potential influence of other relevant factors, as established in
solutions to effectively facilitate their transition toward a low-carbon           existing literature. Following the approach of [39], The impact of
energy system [47,49].                                                             several variables is examined.
    Recognizing the complex nature of the digital economy, as high-
lighted in previous research [50], the study acknowledges the limita-               • Economic Development Level (GDP): Measured by real GDP per
tions of relying on single indicators. Instead, it advocates for a composite          capita (constant 2010 US dollars), reflecting the overall economic
index approach to capture the comprehensive essence of the digital                    performance.
economy. Drawing from existing literature [51], DEI is constructed by               • Urbanization (URB): Represented by the urban population as a
integrating five relevant indicators: financial inclusion index, workforce            percentage of the total population.




                                      Fig 2. Mapping China’s Energy Transition Index across Provinces: 2007 vs. 2019.

                                                                               6
B. Bergougui et al.                                                                                                         Renewable Energy 238 (2025) 121883




                                       Fig 3. Mapping China’s Digital Economy Index across Provinces: 2007 vs 2019.




                                    Fig 4. Mapping China’s Environmental Technology across Provinces: 2007 vs. 2019.


 • Industrialization (INDS): Indicated by the value-added of the in-              4. Empirical results
   dustrial sector as a percentage of GDP, representing the level of
   industrialization.                                                             4.1. Normality test results
 • Human Capital (HC): Proxied by the average number of years of
   education attained by the population.                                             To evaluate the appropriateness of this approach for the analysis,
                                                                                  normality tests were conducted on the variables influencing energy se-
    The definitions of all variables are provided in Table 1. Descriptive         curity in Chinese cities, including ETI, DEI, and ENT. Two methods were
statistics for the variables are provided in Table 2, while the scatterplot       employed for normality assessment.
matrix, histogram, and correlation matrix are depicted in Figure 5.
                                                                                   • Visual Inspection: Quantile-quantile plot (Q-Q plot) was generated
                                                                                     for ESI. A diagonal line in the Q-Q plot indicates normality. Figure 6



                                                                              7
B. Bergougui et al.                                                                                                                        Renewable Energy 238 (2025) 121883


Table 1                                                                                      panel quantile regression approach.
Variable descriptions.
  Category            Variable name           Symbol   Calculation method                    4.2. Assessing cross-sectional dependence and slope heterogeneity
  Dependent           Energy Security         ESI      Comprehensive index
    variable                                                                                     The concept of cross-sectional dependence (CSD) has gained prom-
  Independent         Energy Transition       ETI      Comprehensive index                   inence in panel data analysis, following the seminal work of Pesaran
    variable          Digital Economy         TI       Comprehensive index                   (2004). CSD essentially refers to the correlation of variables across
                      Environmental           ENT      Number of green patents               different cross-sectional units (cities, in this case), suggesting that a
                      Technology                       granted
  Control             Economic                GDP      Real GDP per capita
                                                                                             variable x in one city might influence the same variable in another city
    variables         Development                                                            through shock transmission. Ignoring CSD can lead to distorted esti-
                      Human Capital           HC       Number of general                     mation results when using traditional econometric techniques, particu-
                                                       undergraduates and above as a         larly first-generation panel data methods (Pesaran and Baltagi, 2007).
                                                       proportion of the city’s
                                                                                             To address this issue, second-generation tests are necessary. In this
                                                       resident population
                      Urbanization Level      URB      The share of the populations          study, two tests were employed: the Breusch-Pagan LM (BP) test and the
                                                       living in the urban                   Pesaran CD (2007) test. The results, reported in Panel-A of Table 3,
                      Industrialization       INDS     Industrial value-added/total          indicate that all variables exhibit CSD, as all test statistics are significant
                      Level                            output value                          at the 1 % level. Consequently, the findings strongly confirm that shocks
                                                                                             affecting a variable in one city would likely propagate their effects to the
   displays the Q-Q plot for ESI. Deviations from the diagonal line                          same variable in other cities. Before estimating the MMQR model, it is
   suggest significant departures from normality.                                            essential to test for slope homogeneity using the test developed by
 • Statistical Testing: The Shapiro-Wilk normality test was performed.                       Blomquist and Westerlund (2013). This test evaluates the homogeneity
   Table 2 presents the test results. Rejection of the null hypothesis for                   behavior across cities, guiding the selection of appropriate tests and
   each variable implies a non-normal distribution.                                          estimation procedures. Panel-B of Table 3 summarizes the homogeneity
                                                                                             test results using two different statistics, Δ and adjusted Δ. Both test
   Based on both visual inspection and statistical tests, it is concluded                    statistics are significant at the 1 % level, as indicated by their very low p-
that the data exhibits non-normality. Consequently, traditional mean                         values. This result implies the presence of heterogeneity across the 275
regression methods, reliant on normality assumptions, may produce                            cities included in the analysis.
biased and unreliable results. Therefore, to address the issue of non-
normality and provide more robust estimates, this study adopts the

Table 2
Summary Statistics (After logarithm).
                      Mean                 Std. Dev.         Min.                 Max.               Skew.             Kurt.             Shapiro-Wilk Test           Prob.

  ESI                 − 7.675              2.064             − 11.713             6.657              3.525             20.260            16.776                      0.000
  ETI                 3.754                0.292             2.779                4.416              − 0.395           3.100             8.255                       0.000
  TI                  8.526                0.920             5.801                12.803             0.591             4.195             9.968                       0.000
  ENT                 4.664                1.793             0.000                10.507             0.224             2.918             5.507                       0.000
  GDP                 10.482               0.685             4.595                13.056             − 0.247           4.329             7.024                       0.000
  HC                  1.637                1.957             0.004                12.764             2.527             9.655             16.790                      0.000
  URB                 0.521                0.158             0.164                1.188              0.673             3.432             10.491                      0.000
  INDS                0.396                0.155             0.000                2.849              0.690             21.254            13.282                      0.000




                                                                            Fig 5. Correlation matrix.

                                                                                         8
B. Bergougui et al.                                                                                                                           Renewable Energy 238 (2025) 121883




                                                                  Fig 6. The normal quantile-quantile plot for ESI


                                                                                                exhibit stationarity after first differencing. Given the integration orders
Table 3
                                                                                                revealed by the unit root analysis, the focus shifted to testing for the
Outcomes of cross-sectional dependence and slope heterogeneity.
                                                                                                presence of a long-run cointegrating relationship among the variables.
  Panel (A). Outcomes of the CSD test.                                                          Establishing cointegration is crucial because it allows for the modelling
  Tests          Breusch-Pagan LM            Prob.           Pesaran CD          Prob.          of long-run equilibrium relationships among non-stationary variables,
  ESI            3.6e+05                     0.0000          266.654             0.0000         preventing the risk of spurious regressions.
  ETI            31092.69                    0.0000          11.890              0.0000
  TI             2.6e+05                     0.0000          87.101              0.0000
                                                                                                4.4. Panel cointegration test results
  ENT            14606.25                    0.0000          47.033              0.0000
  GDP            20192.42                    0.0000          157.565             0.0000
  HC             6.1e+05                     0.0000          42.961              0.0000             To validate the presence of a long-run equilibrium relationship
  URB            84558.96                    0.0000          43.664              0.0000         among the underlying variables, three cointegration tests were
  INDS           1.0e+06                     0.0000          53.215              0.0000         employed: [57,58], and (Westerlund 2007) (see Table 5). The results
  Panel (B). Outcomes of SH test.                                                               from the first-generation cointegration tests (Kao and Pedroni) and the
                                                Test value                       Prob.          second-generation test (Westerlund) provide evidence of a long-run
                                                                                                relationship among the variables across the 275 Chinese cities under
  Tilde (Delta)                                 5.584                            0.0000
  Adjusted tilde (Delta)                        10.067                           0.0000
                                                                                                study. These findings suggest that the variables under consideration
                                                                                                share the same long-term behavioral patterns, do not diverge, and are
Note: *** denotes the significant level at 1 %.                                                 influenced by common shocks. Consequently, estimating the long-run
                                                                                                effects of factors such as ETI, DEI, ENT, GDP, HC, URB and INDS on
4.3. Panel unit root test results                                                               ESI becomes imperative. To capture asymmetric effects, the study pro-
                                                                                                ceeds to employ the MMQR approach, which allows for a more nuanced
    After establishing the presence of cross-sectional dependence, the                          examination of these relationships across different quantiles of the
next step involved investigating the order of integration for the variables                     conditional distribution.
using second-generation panel unit root tests. These tests are designed to
produce robust results in the presence of cross-sectional dependence. To
                                                                                                4.5. Asymmetric MMQR estimation results
this end, two different tests were employed: the CIPS test developed by
Pesaran (2007) and the cross-sectional Augmented Dickey-Fuller
                                                                                                   Next, we examine the effects of positive and negative shocks in en-
(CADF) test. The findings from both unit root tests are presented in
                                                                                                ergy transition (ETI), the digital economy (DEI), and environmental
Table 4. The results confirm that the variables ETI, DEI, and ENT are
                                                                                                technology (ENT) on energy security (ESI) in Chinese cities. Due to the
stationary at their level form, while ESI, HC, GDP, URB, and INDS

                                                                                                Table 5
                                                                                                Panel cointegration analysis.
Table 4
Second-generation panel unit root analysis.                                                      Estimates                                     Statistic               p-value

                      CIPS                               CADF                                    Pedroni test for cointegration
                                                                                                 Modified Phillips–Perron t                    28.273***               0.000
  Variables           Level I(0)    Difference I(1)      Level I(0)       Difference I(1)        Phillips–Perron t                             − 23.051***             0.000
  ESI                 − 2.034       − 3.950a             − 0.900          − 2.749a               Augmented Dickey-Fuller t                     − 19.382***             0.000
  ETI                 − 2.293a      − 3.258a             − 2.381a         − 2.247a               Kao test for cointegration
  DEI                 − 2.854a      − 3.896a             − 2.441a         − 2.494a               Modified Dickey-Fuller t                      − 5.328***              0.000
  ENT                 − 2.674a      − 3.955a             − 2.078a         − 2.259a               Dickey-Fuller t                               − 3.017***              0.001
  GDP                 − 1.656       − 3.256a             − 1.287          − 2.206a               Augmented Dickey-Fuller t                     − 1.941**               0.026
  HC                  − 1.806       − 3.126a             − 1.550          − 2.052a               Unadjusted modified Dickey–Fuller             − 17.190***             0.000
  URB                 − 2.832       − 3.610a             − 1.721          − 2.150a               Unadjusted Dickey-Fuller t                    − 9.074***              0.000
  INDS                − 1.806       − 3.126a             − 2.081a         − 2.436a               Westerlund test for cointegration
                                                                                                 Variance ratio                                7.921***                0.0000
Notes.
 a
   Denotes the significant level at 1 %.                                                        Note: * and ** denote the statistical significance at 1 % and 5 % respectively.

                                                                                            9
B. Bergougui et al.                                                                                                            Renewable Energy 238 (2025) 121883


non-normal distribution of the data, the asymmetric MMQR method is                results suggest that investments in human capital and urbanization are
used, accounting for variations across different energy security levels.          important for improving energy security, while unchecked economic
The regression covers nine quantiles (10th, 20th, …, 90th) to show how            growth and industrialization present obstacles to achieving sustainable
these shocks impact energy security across cities with varying levels of          energy security at all levels.
energy stability (Table 6, Figure 7).
    The results from ETI shocks show distinct patterns. Positive shocks in
                                                                                  4.6. Heterogenous panel causality analysis
ETI increase energy security only in cities with already high energy se-
curity, as seen in the 80th and 90th quantiles. This suggests that cities
                                                                                      The final phase of this paper involves a detailed causality analysis
with strong infrastructure are better able to take advantage of advances
                                                                                  using the Dumitrescu and Hurlin [59] panel causality test, with the re-
in energy transition technologies. At the lower quantiles, such as the
                                                                                  sults presented in Table 7. This test provides important insights into the
10th and 20th, positive ETI shocks have no significant positive impact
                                                                                  directional relationships between the core variables under study, help-
and even show a negative effect (− 0.771) at the 10th quantile. This
                                                                                  ing to clarify whether changes in one variable predict changes in
indicates that cities with low energy security face difficulties in
                                                                                  another, and whether this effect is bidirectional or unidirectional.
benefiting from energy transition advancements. On the other hand,
                                                                                      The analysis shows that for most variable pairs, there is a bidirec-
negative ETI shocks initially increase energy security in cities with low
                                                                                  tional causal relationship, meaning that these variables influence each
energy security (2.927 at the 10th quantile), likely due to their
                                                                                  other. For example, a bidirectional relationship was found between
continued reliance on traditional energy sources. However, at higher
                                                                                  energy security (ESI) and the digital economy (DEI), as well as between
quantiles, these negative shocks lead to a significant drop in energy
                                                                                  ESI and environmental technology (ENT). This mutual influence in-
security (− 5.53 at the 90th quantile), indicating that setbacks in energy
                                                                                  dicates that changes in energy security levels can affect the development
transition severely harm cities with stronger energy security levels.
                                                                                  of the digital economy and environmental technology, while advance-
    Shocks in the digital economy (DEI) also show an asymmetric effect.
                                                                                  ments in these areas also strengthen energy security. Similarly, human
Negative DEI shocks, such as economic slowdowns, have little to no
                                                                                  capital (HC), urbanization (URB), and industrialization (INDS) also
impact on energy security across all quantiles. This suggests that de-
                                                                                  exhibit bidirectional causality with energy security, showing that the
clines in the digital economy do not significantly weaken energy secu-
                                                                                  growth of these factors and energy security reinforce each other over
rity. However, positive DEI shocks, such as digital advancements,
                                                                                  time.
significantly improve energy security, particularly in cities with mod-
                                                                                      However, there are two key unidirectional relationships that stand
erate to high levels of security. For example, at the 80th quantile, the
                                                                                  out. First, the link between energy transition (ETI) and energy security
effect is 0.772, showing that digitalization and related technological
                                                                                  (ESI) shows a one-way causal relationship: ETI Granger-causes ESI, but
improvements contribute positively to energy management and stability
                                                                                  ESI does not Granger-cause ETI. This suggests that progress in energy
in these cities.
                                                                                  transition directly influences energy security, but energy security does
    The impact of environmental technology (ENT) on energy security is
                                                                                  not significantly drive changes in energy transition. Second, the rela-
generally positive across most quantiles. Positive shocks in ENT improve
                                                                                  tionship between GDP and ESI is also unidirectional, where GDP
energy security across all levels, except in cities with very low energy
                                                                                  Granger-causes ESI, meaning that economic performance affects energy
security, where the effect is minimal (0.079 at the 10th quantile). In
                                                                                  security, but energy security does not appear to influence GDP. This
cities with moderate to high energy security, the benefits of environ-
                                                                                  result emphasizes the critical role of economic growth in shaping energy
mental technology become more pronounced, reaching 0.273 at the
                                                                                  security, while energy security itself does not directly impact economic
90th quantile. Negative ENT shocks, such as technological setbacks,
                                                                                  performance in the short term. These causal relationships are summa-
initially reduce energy security in cities with low levels (− 0.211 at the
                                                                                  rized in Figure 8.
10th quantile), but at higher levels, these shocks unexpectedly improve
energy security (e.g., 0.632 at the 90th quantile). This could indicate
that cities with stronger infrastructure may compensate for technolog-            4.7. Discussion
ical setbacks by optimizing other areas of energy management.
    The results show that the effects of ETI, DEI, and ENT on energy                 The findings of this research indicate that the effects of the energy
security vary depending on the existing level of security and whether the         transition on energy security vary depending on the level of energy se-
shock is positive or negative. Moreover, the control variables highlight          curity in different cities. Cities with strong energy resilience benefit
additional insights: human capital (HC) and urbanization (URB) posi-              more from advancements in the energy transition, as they can leverage
tively affect energy security across all quantiles, while economic growth         these improvements to further strengthen their energy infrastructure.
(GDP) and industrialization (INDS) have a negative impact. These                  On the other hand, cities with lower levels of energy security may
                                                                                  experience some short-term gains from delays in the transition to

Table 6
Panel quantile estimation analysis.
                  Lower Quantile                              Middle Quantile                                    Higher Quantile

                  10th             20th         30th          40th                50th           60th            70th              80th             90th

  Core independent variables
  ETI +          − 0.771**         − 0.381      − 0.138       0.108               0.316          0.537           0.834*            1.238**          2.029**
  ETI            2.927***          1.751***     1.019*        0.277               − 0.351        − 1.016         − 1.913**         − 3.131***       − 5.53***
  DEI +          − 0.212           − 0.021      0.098         0.219               0.320*         0.429**         0.574**           0.772***         1.160***
  DEI            − 0.108           − 0.137      − 0.155       − 0.173             − 0.188        − 0.204         − 0.226           − 0.255          − 0.313
  ENT +          0.079             0.106**      0.122***      0.139***            0.154***       0.169***        0.190***          0.218**          0.273**
  ENT            − 0.211***        − 0.093      − 0.020       0.054               0.117          0.183**         0.272***          0.394***         0.632***
  Control variables
  GDP            − 0.391***        − 0.430***   − 0.455***    − 0.480***          − 0.502***     − 0.524***      − 0.555***        − 0.596***       − 0.677***
  HC             0.014             0.031        0.042**       0.053**             0.062**        0.072**         0.085**           0.102**          0.137**
  URB            0.830**           1.028**      1.151***      1.275**             1.381**        1.492**         1.643**           1.848**          2.248***
  INDS           − 0.516*          − 0.757***   − 0.907***    − 1.059***          − 1.187***     − 1.324***      − 1.507***        − 1.757***       − 2.245***
  cons           − 5.225***        − 4.602***   − 4.214***    − 3.821***          − 3.488***     − 3.135***      − 2.660***        − 2.015***       − 0.751***


                                                                             10
B. Bergougui et al.                                                                                                         Renewable Energy 238 (2025) 121883




                                            Fig 7. Mmqr estimates at several quantile levels for energy security.


cleaner energy, but these gains tend to be temporary. Over time, relying          energy monitoring, and data-driven approaches to optimize energy
on traditional energy sources due to setbacks in the energy transition can        use. The bidirectional relationship between energy security and the
harm their energy security. The unidirectional causality from the Energy          digital economy means that as energy security improves, it can lead to
Transition Index (ETI) to the Energy Security Index (ESI) reinforces the          further investments in digital technologies, which in turn help
idea that policies aimed at promoting energy transition are crucial for           strengthen energy systems, creating a reinforcing cycle of progress.
improving energy security. Since energy security does not influence                   Additionally, advancements in environmental technology have a
energy transition, the focus needs to be on policies and actions that             positive impact on energy security across a range of cities. Those with
directly drive the transition to cleaner energy [60].                             higher levels of energy security are better positioned to adopt new
    The digital economy also plays a key role in energy security, espe-           technologies that lead to more sustainable and efficient energy use.
cially in cities with moderate to high levels of energy resilience. While         However, cities with very low energy security may initially struggle to
setbacks in the digital economy don’t appear to significantly affect en-          adapt to setbacks in environmental technology, possibly due to a lack of
ergy security, its continued growth is associated with stronger energy            infrastructure and resources. These cities may experience short-term
security outcomes. This is because the development of digital technol-            difficulties, but over time, they can benefit from adopting more effec-
ogies enhances energy infrastructure, promotes resource efficiency, and           tive and sustainable energy solutions in response to these challenges. In
supports better energy management. Cities that invest in the digital              cities with higher energy security, setbacks in environmental technology
economy can benefit from innovations such as smart grids, real-time               can encourage the development of even better solutions, ultimately

                                                                             11
B. Bergougui et al.                                                                                                           Renewable Energy 238 (2025) 121883


Table 7                                                                            progress in the other. As energy security improves, cities are more likely
Dumitrescu-hurlin panel causality analysis.                                        to invest in environmental technologies, recognizing the long-term
  Null Hypothesis              W-bar     Z-bar     p-       Decision               benefits of reducing environmental risks and enhancing energy resil-
                                                   value                           ience. At the same time, advancements in environmental technology
  ETI does not Granger-cause   3.2131    10.0583   0.0000   One way                help improve energy systems and reduce dependence on non-renewable
    ESI                                                     causality              energy sources, leading to stronger energy security. This reciprocal
  ESI does not Granger-cause   1.0304    0.3562    0.7217                          relationship highlights the importance of innovation and sustainability
    ETI                                                                            in achieving lasting energy resilience, as seen in earlier studies by [61,
  DEI does not Granger-cause   6.6074    38.2026   0.0000   Two ways
    ESI                                                     causality
                                                                                   62].
  ESI does not Granger-cause   1.6760    7.9272    0.0000
    DEI                                                                            5. Conclusion, policy implications and future directions
  ENT does not Granger-cause   3.1385    9.4403    0.0000   Two ways
    ESI                                                     causality
                                                                                   5.1. Conclusion
  ESI does not Granger-cause   1.3589    4.2090    0.0000
    ENT
  GDP does not Granger-        2.8168    6.7727    0.0000   One way                    This paper offers several important contributions to the literature on
    cause ESI                                               causality              energy security by empirically analyzing the effects of energy transition,
  ESI does not Granger-cause   1.1300    1.5246    0.1274                          digitalization, and environmental technology on energy security across
    GDP
  HC does not Granger-cause    3.9006    15.7592   0.0000   Two ways
                                                                                   275 Chinese cities from 2007 to 2020. As the first to investigate the
    ESI                                                     causality              impact of these factors at the city level within the Chinese context, this
  ESI does not Granger-cause   1.7479    8.7699    0.0000                          research fills a significant gap, particularly given China’s role as the
    CH                                                                             world’s largest energy-consuming economy. The differential effects of
  URB does not Granger-        6.7693    39.5452   0.0000   Two ways
                                                                                   positive and negative shocks on energy security outcomes across low,
    cause ESI                                               causality
  ESI does not Granger-cause   1.7165    8.4015    0.0000                          middle, and high quantiles provide a detailed understanding of how
    URB                                                                            cities with varying levels of energy security respond to these changes.
  INDS does not Granger-       8.7820    56.2331   0.0000   Two ways               This focus on China’s energy security is essential, as the country’s pol-
    cause ESI                                               causality              icies and decisions have far-reaching implications for the global energy
  ESI does not Granger-cause   11.3668   77.6656   0.0000
                                                                                   supply chain and associated risks.
    INDS
                                                                                       One of the major contributions of this study is the introduction of a
Note: The optimal lags P were chosen by the Akaike Information Criterion.          novel energy security index, constructed through the entropy weighting
                                                                                   method. This composite measure integrates energy investment, supply,
strengthening their energy systems.                                                use, and environmental impact, while also accounting for economic,
    The bidirectional relationship between energy security and envi-               social, and environmental dimensions. By offering a broader view of
ronmental technology shows how improvements in one area can drive




                                                    Fig 8. Graphical representation of causal relationships.

                                                                              12
B. Bergougui et al.                                                                                                                   Renewable Energy 238 (2025) 121883


energy security that extends beyond traditional metrics such as afford-            sustainable solutions in the long term.
ability, acceptability, and availability, this index provides a more
comprehensive tool for assessing energy security dynamics in China’s
                                                                                   5.3. Future directions
cities.
    Additionally, this work employs the nonparametric MMQR, which
                                                                                       The findings of this study have important implications in line with
addresses misspecification bias and effectively captures the varying ef-
                                                                                   the Sustainable Development Goals (SDGs) and the United Nations 2030
fects of energy transition, digitalization, and environmental technology
                                                                                   agenda. By examining nine deciles ranging from 10th to 90th, this study
across different levels of energy security. The MMQR approach not only
                                                                                   provides a comprehensive analysis of how positive and negative shocks
mitigates bias but also provides clearer insights into how these factors
                                                                                   in energy transition, digital economy, and environmental technology
affect different segments of the energy security distribution—lower,
                                                                                   impact energy security at different levels in Chinese cities. Future
middle, and upper quantiles. Through partial sum decompositions, the
                                                                                   research could further deepen the findings of this study using comple-
study distinguishes between positive and negative trends, offering a
                                                                                   mentary methodologies, such as Panel Vector Autoregression (PVAR).
more detailed analysis than traditional regression methods. This
                                                                                   Likewise, replicating this approach in other regions while considering
approach is particularly suited to capturing the effects of China’s
                                                                                   the unique characteristics of each country would be beneficial. Addi-
structural transformations in recent decades, providing deeper insights
                                                                                   tionally, exploring the impact of interactive factors on energy security
into the drivers of energy security under these changes.
                                                                                   presents an intriguing avenue for future research.
    The main findings show that cities with high energy security benefit
more from positive shocks in energy transition, while cities with low
energy security may experience temporary gains from negative shocks                CRediT authorship contribution statement
but face long-term challenges. Similarly, advancements in digitalization
improve energy security, particularly in cities with moderate to high                  Brahim Bergougui: Writing – review & editing, Writing – original
baseline levels, while setbacks in the digital economy have minimal                draft, Visualization, Validation, Supervision, Methodology, Investiga-
impact. Environmental technology advancements generally improve                    tion, Formal analysis, Conceptualization. Syed Mansoob Murshed:
energy security across most cities, though the effects are less pronounced         Writing – review & editing, Writing – original draft, Investigation.
in those with very low energy security. The Dumitrescu-Hurlin [59]                 Muhammad Shahbaz: Writing – review & editing, Supervision. Man-
panel causality test results also show bidirectional relationships for most        uel A. Zambrano-Monserrate: Writing – review & editing, Writing –
variable pairs, highlighting the interdependence between energy secu-              original draft, Validation, Methodology. Ahmed Samour: Writing –
rity, digitalization, and environmental technology. However, the uni-              review & editing, Methodology, Formal analysis, Conceptualization.
directional relationships between energy security and both energy                  Mohammed Ibrahim Aldawsari: Writing – original draft, Methodol-
transition and GDP further illustrate how these factors drive changes in           ogy, Formal analysis.
energy security outcomes.
                                                                                   Declaration of competing interest
5.2. Policy implications
                                                                                       The authors declare that they have no known competing financial
    Our results have important public policy implications. Since the ef-           interests or personal relationships that could have appeared to influence
fects of the energy transition vary according to the level of energy se-           the work reported in this paper.
curity of cities, policies should be tailored to address the specific needs
of each type of city. For example, cities with high energy security might          References
benefit more from incentives to invest in advanced and sustainable
technologies. While cities with low energy security might require pol-              [1] B. Bergougui, S.M. Murshed, Aggregate and disaggregate impact of natural
icies that provide an initial boost and support to upgrade their basic                  resources on sustainable development: new evidence from the latest institutional
                                                                                        data, Environmental and Sustainability Indicators 20 (2023) 100302, https://doi.
energy infrastructure. Moreover, given that the effects of the energy                   org/10.1016/j.indic.2023.100302.
transition may vary according to geographic location and the specific               [2] B. Bergougui, Investigating the relationships among green technologies, financial
characteristics of each city, it is important to encourage collaboration                development and ecological footprint levels in Algeria: evidence from a novel
                                                                                        Fourier ARDL approach, Sustain. Cities Soc. 112 (2024) 105621, https://doi.org/
between cities to share best practices and experiences [63]. This could
                                                                                        10.1016/j.scs.2024.105621.
facilitate the exchange of knowledge and resources, benefiting all cities           [3] C.T. Tugcu, A.N. Menegaki, The impact of renewable energy generation on energy
on their path to energy security [64]. Additionally, given that an in-                  security: evidence from the G7 countries, Gondwana Res. 125 (2024) 253–265.
crease in the digital economy is associated with higher levels of energy            [4] N. Fan, H. Ji, The dynamic change of energy supply and demand structure within
                                                                                        China: a perspective from the national value chain, Environ. Sci. Pollut. Res. 30
security in Chinese cities, policies can focus on promoting and sup-                    (2023) 11873–11892.
porting the development of the digital economy. This may include                    [5] B. Bergougui, Moving toward environmental mitigation in Algeria: asymmetric
implementing policies that encourage technological innovation, adopt-                   impact of fossil fuel energy, renewable energy and technological innovation on
                                                                                        CO2 emissions, Energy Strategy Rev. 51 (2024) 101281, https://doi.org/10.1016/
ing digital technologies in energy-related sectors, and improving digital               j.esr.2023.101281.
infrastructure in cities. Moreover, Chinese cities should encourage the             [6] H. Salami, K. Okpara, C. Choochuay, et al., Domestic energy consumption, theories,
integration of digital technologies into the management and operation                   and policies: a systematic review, Environ. Dev. Sustain. (2023).
                                                                                    [7] C.J. Axon, R.C. Darton, Energy Demand Reduction: supply chains and risk analysis,
of their energy systems. This could include the use of real-time data and               Energy Effic 16 (2023) 84.
analytics to optimize energy distribution and consumption, the imple-               [8] R. Zhou, D. Tang, D. Da, et al., Research on China’s manufacturing industry moving
mentation of digital-based demand-side management systems, and the                      towards the middle and high-end of the GVC driven by digital economy,
                                                                                        Sustainability 14 (2022).
promotion of smart energy solutions in the residential, commercial, and             [9] L. Cui, S. Yue, X.-H. Nghiem, M. Duan, Exploring the risk and economic
industrial sectors [65]. Furthermore, due to the complex pattern of                     vulnerability of global energy supply chain interruption in the context of Russo-
impact of environmental technology setbacks on energy security, pol-                    Ukrainian war, Resour. Pol. 81 (2023) 103373.
                                                                                   [10] S. Ullah, G. Gozgor, Z. Lu, How do conflicts affect energy security risk? Evidence
icies must be flexible and adaptive. For example, in cities with very low
                                                                                        from major energy-consuming economies, Econ. Anal. Pol. 82 (2024) 175–187.
levels of energy security, policies can focus on providing additional              [11] M.T. Kartal, The role of consumption of energy, fossil sources, nuclear energy, and
support to overcome initial challenges associated with environmental                    renewable energy on environmental degradation in top-five carbon producing
technology setbacks, such as a lack of infrastructure and resources. In                 countries, Renew. Energy 184 (2022) 871–880.
                                                                                   [12] C.-C. Lee, C. Wang, Financial development, technological innovation and energy
cities with moderate to high levels of energy security, policies can focus              security: evidence from Chinese provincial experience, Energy Econ. 112 (2022)
on promoting innovation and the adoption of more efficient and                          106161.


                                                                              13
B. Bergougui et al.                                                                                                                                    Renewable Energy 238 (2025) 121883

[13] C.-C. Lee, Z. Yuan, Q. Wang, How does information and communication technology              [38] T. Ulussever, S. Kılıç Depren, M.T. Kartal, Ö. Depren, Estimation performance
     affect energy security? International evidence, Energy Econ. 109 (2022) 105969.                  comparison of machine learning approaches and time series econometric models:
[14] X. Zhao, W. Tao, X. Ma, C. Wang, G. Mentel, Exploring the role of environmental                  evidence from the effect of sector-based energy consumption on CO2 emissions in
     regulation on energy security: contextual findings for sustainable development in                the USA, Environ. Sci. Pollut. Control Ser. 30 (18) (2023) 52576–52592.
     Chinese provinces, Gondwana Res. 116 (2023) 113–124.                                        [39] C.-C. Lee, Z. Yuan, Z.-W. He, F. Xiao, Do geopolitical risks always harm energy
[15] T.T. Thanh, L.T. Ha, H.P. Dung, T.T.L. Huong, Impacts of digitalization on energy                security? Their non-linear effects and mechanism, Energy Econ. 129 (2024)
     security: evidence from European countries, Environ. Dev. Sustain. 25 (10) (2023)                107245.
     11599–11644.                                                                                [40] B. Bergougui, R.H. Boudjana, S. Mehibel, M.A. Zambrano-Monserrate, How do
[16] L. Proskuryakova, Updating energy security and environmental policy: energy                      institutional quality and income asymmetrically affect carbon emissions
     security theories revisited, J. Environ. Manag. 223 (2018) 203–214.                              inequality? A Quantile-on-Quantile assessment for six major global emitters,
[17] W. Huo, B.U. Zaman, M. Zulfiqar, E. Kocak, K. Shehzad, How do environmental                      J. Clean. Prod. (2024) 144215. https://doi.org/10.1016/j.jclepro.2024.144215.
     technologies affect environmental degradation? Analyzing the direct and indirect            [41] R. Radmehr, S. Shayanmehr, E.A. Baba, A. Samour, T.S. Adebayo, Spatial spillover
     impact of financial innovations and economic globalization, Environ. Technol.                    effects of green technology innovation and renewable energy on ecological
     Innovat. 29 (2023) 102973.                                                                       sustainability: new evidence and analysis, Sustain. Dev. 32 (3) (2024) 1743–1761.
[18] L.T. Ha, Are digital business and digital public services a driver for better energy        [42] A. Samour, M. Ali, T. Tursoy, M. Radulescu, D. Balsalobre-Lorente, The nexus
     security? Evidence from a European sample, Environ. Sci. Pollut. Control Ser. 29                 between technological innovation, human capital and energy efficiency: evidence
     (18) (2022) 27232–27256.                                                                         from E7 countries, Gondwana Res. 135 (2024) 89–102.
[19] M. Shahbaz, J. Wang, K. Dong, J. Zhao, The impact of digital economy on energy              [43] U. Waris, U. Mehmood, S. Tariq, Analyzing the impacts of renewable energy,
     transition across the globe: the mediating role of government governance, Renew.                 patents, and trade on carbon emissions—evidence from the novel method of
     Sustain. Energy Rev. 166 (2022) 112620.                                                          MMQR, Environ. Sci. Pollut. Res. 30 (2023) 122625–122641.
[20] M.T. Kartal, A. Samour, T.S. Adebayo, S.K. Depren, Do nuclear energy and                    [44] M. Ali, A. Samour, S.A. Soomro, W. Khalid, T. Tursoy, A step towards a sustainable
     renewable energy surge environmental quality in the United States? New insights                  environment in top-10 nuclear energy consumer countries: the role of financial
     from novel bootstrap Fourier Granger causality in quantiles approach, Prog. Nucl.                globalization and nuclear energy, Nucl. Eng. Technol. (2024).
     Energy 155 (2023) 104509.                                                                   [45] L. Yao, Y. Chang, Energy security in China: a quantitative analysis and policy
[21] A.E. Caglar, B.E. Askin, A path towards green revolution: how do competitive                     implications, Energy Pol. 67 (2014) 595–604.
     industrial performance and renewable energy consumption influence                           [46] B.W. Ang, W.L. Choong, T.S. Ng, Energy security: definitions, dimensions and
     environmental quality indicators? Renew. Energy 205 (2023) 273–280.                              indexes, Renew. Sustain. Energy Rev. 42 (2015) 1077–1093.
[22] H.A. Fakher, Z. Ahmed, A.O. Acheampong, S.P. Nathaniel, Renewable energy,                   [47] Y. Shen, X. Shi, Z. Zhao, et al., A dataset of low-carbon energy transition index for
     nonrenewable energy, and environmental quality nexus: an investigation of the N-                 Chinese cities 2003–2019, Sci. Data 10 (2023) 906.
     shaped Environmental Kuznets Curve based on six environmental indicators,                   [48] S. Carley, T.P. Evans, M. Graff, D.M. Konisky, A framework for evaluating
     Energy 263 (2023) 125660.                                                                        geographic disparities in energy transition vulnerability, Nat. Energy 3 (2018)
[23] K. Khan, C.W. Su, A. Khurshid, M. Qin, Does energy security improve renewable                    621–627.
     energy? A geopolitical perspective, Energy 282 (2023) 128824.                               [49] M.T. Kartal, Production-based disaggregated analysis of energy consumption and
[24] J.A. Paravantis, N. Kontoulis, Energy security and renewable energy: a geopolitical              CO2 emission nexus: evidence from the USA by novel dynamic ARDL simulation
     perspective, in: Renewable Energy-Resources, Challenges and Applications,                        approach, Environ. Sci. Pollut. Control Ser. 30 (3) (2023) 6864–6874.
     IntechOpen, 2020.                                                                           [50] X. Lei, Z.Y. Shen, D. Štreimikienė, et al., Digitalization and sustainable
[25] R. Cergibozan, Renewable energy sources as a solution for energy security risk:                  development: evidence from OECD countries, Appl. Energy 357 (2024) 122480.
     empirical evidence from OECD countries, Renew. Energy 183 (2022) 617–626.                   [51] M. Zheng, C.Y. Wong, The impact of digital economy on renewable energy
[26] M.F. Bashir, Y. Pan, M. Shahbaz, S. Ghosh, How energy transition and                             development in China, Innov Green Dev 3 (2024) 100094.
     environmental innovation ensure environmental sustainability? Contextual                    [52] B. Xie, B. Xie, Assessing the impact of climate policy on energy security in
     evidence from Top-10 manufacturing countries, Renew. Energy 204 (2023)                           developed economies, Int. Rev. Econ. Finance 90 (2024) 265–282, https://doi.org/
     697–709.                                                                                         10.1016/j.iref.2023.11.006.
[27] A. Razzaq, A. Sharif, I. Ozturk, S. Afshan, Dynamic and threshold effects of energy         [53] B. Bergougui, Algeria’s pathway to COP28 and SDGs: asymmetric impact of
     transition and environmental governance on green growth in COP26 framework,                      environmental technology, energy productivity, and material resource efficiency
     Renew. Sustain. Energy Rev. 179 (2023) 113296.                                                   on environmental sustainability, Energy Strategy Rev. 55 (2024) 101541, https://
[28] F. Joof, A. Samour, M. Ali, M.A. Rehman, T. Tursoy, Economic complexity,                         doi.org/10.1016/j.esr.2024.101541.
     renewable energy and ecological footprint: the role of the housing market in the            [54] B. Bergougui, H. Ayad, S. Ghosh, B. Doğan, Do green total factor productivity and
     USA, Energy Build. 311 (2024) 114131.                                                            digital economy matter for energy transition: evidence from Chinese cities. https://
[29] Y. Sun, M. Usman, M. Radulescu, U. Korkut Pata, D. Balsalobre-Lorente, New                       doi.org/10.2139/ssrn.4795205, 2024.
     insights from the STIPART model on how environmental-related technologies,                  [55] B. Bergougui, M.I. Aldawsari, Asymmetric impact of patents on green technologies
     natural resources and the use of the renewable energy influence load capacity                    on Algeria’s Ecological Future, J. Environ. Manag. 355 (2024) 120426, https://doi.
     factor, Gondwana Res. 129 (2024) 398–411. https://doi.org/10.1016/j.gr.2023.0                    org/10.1016/j.jenvman.2024.120426.
     5.018.                                                                                      [56] B. Bergougui, B. Doğan, S. Ghosh, H. Ayad, Impact of environmental technology,
[30] M. Ahmed, M. Hafeez, M.A. Kaium, S. Ullah, H. Ahmad, Do environmental                            economic complexity, and geopolitical risk on carbon emission inequality in
     technology and banking sector development matter for green growth? Evidence                      developed and developing countries: evidence from a PVAR-GMM approach,
     from top-polluted economies, Environ. Sci. Pollut. Control Ser. 30 (6) (2023)                    Environ. Dev. Sustain. (2024).
     14760–14769.                                                                                [57] C. Kao, Spurious regression and residual-based tests for cointegration in panel data,
[31] S.R. Paramati, U. Shahzad, B. Doğan, The role of environmental technology for                   J. Econom. 90 (1999) 1–44.
     energy demand and energy efficiency: evidence from OECD countries, Renew.                   [58] P. Pedroni, Panel cointegration: asymptotic and finite sample properties of pooled
     Sustain. Energy Rev. 153 (2022) 111735.                                                          time series tests with an application to the PPP hypothesis, Econom theory 20
[32] M. Matthess, S. Kunkel, M.F. Dachrodt, G. Beier, The impact of digitalization on                 (2004) 597–625.
     energy intensity in manufacturing sectors–A panel data analysis for Europe,                 [59] E.-I. Dumitrescu, C. Hurlin, Testing for Granger non-causality in heterogeneous
     J. Clean. Prod. 397 (2023) 136598.                                                               panels, Econ. Modell. 29 (2012) 1450–1460.
[33] S. Das, M. Basu, Day-ahead optimal bidding strategy of microgrid with demand                [60] S. Carley, D.M. Konisky, The justice and equity implications of the clean energy
     response program considering uncertainties and outages of renewable energy                       transition, Nat. Energy 5 (8) (2020) 569–577.
     resources, Energy 190 (2020) 116441.                                                        [61] C. Ayoo, Towards Energy Security for the Twenty-First Century, in: Energy Policy,
[34] Y. Wang, S. Ullah, Effects of digitalization on energy security risk: do financial               IntechOpen, 2020.
     development and environmental trade matter? Environ. Sci. Pollut. Control Ser. 31           [62] Ü.O. Kahraman, A. Üçağaç, M. Çalışkan, V. İnal, A puzzle on environmental quality
     (1) (2024) 249–261.                                                                              and energy security, J. Environ. Manag. 366 (2024) 121903.
[35] N. Aslam, W. Yang, R. Saeed, F. Ullah, Energy transition as a solution for energy           [63] Z. Liu, C. Yu, Q.K. Qian, R. Huang, K. You, H. Visscher, G. Zhang, Incentive
     security risk: empirical evidence from BRI countries, Energy 290 (2024) 130090.                  initiatives on energy-efficient renovation of existing buildings towards carbon-
[36] M.T. Kartal, M. Shahbaz, D. Taşkın, S. Kılıç Depren, F. Ayhan, How are energy                   neutral blueprints in China: Advancements, challenges and perspectives, Energy
     transition and energy-related R&D investments effective in enabling                              Build. (2023) 113343.
     decarbonization? Evidence from Nordic Countries by novel WLMC model,                        [64] S. Sillak, K. Borch, K. Sperling, Assessing co-creation in strategic planning for urban
     J. Environ. Manag. 365 (2024) 121664.                                                            energy transitions, Energy Res. Soc. Sci. 74 (2021) 101952.
[37] M.T. Kartal, D. Taşkın, M. Shahbaz, D. Kirikkaleli, S. Kılıç Depren, Role of energy        [65] E. O’Dwyer, I. Pan, R. Charlesworth, S. Butler, N. Shah, Integration of an energy
     transition in easing energy security risk and decreasing CO2 emissions:                          management tool and digital twin for coordination and control of multi-vector
     disaggregated level evidence from the USA by quantile-based models, J. Environ.                  smart energy systems, Sustain. Cities Soc. 62 (2020) 102412. https://doi.
     Manag. 359 (2024) 120971.                                                                        org/10.1016/j.scs.2020.102412.




                                                                                            14
