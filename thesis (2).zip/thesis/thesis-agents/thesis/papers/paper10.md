                                                             Journal of Environmental Management 360 (2024) 121172


                                                                      Contents lists available at ScienceDirect


                                                   Journal of Environmental Management
                                                           journal homepage: www.elsevier.com/locate/jenvman


Research article

Asymmetric nexus between green technologies, economic policy
uncertainty, and environmental sustainability: Evidence from Algeria
Brahim Bergougui a, b, *, Samer Mehibel c, Reda Hamza Boudjana c
a
  International Institute of Social Studies (ISS), Erasmus University Rotterdam, The Hague, the Netherlands
b
  National Higher School of Statistics and Applied Economics (ENSSEA), Koléa, Algeria
c
  Centre de Recherche en Economie Appliquée pour le Développent, Alger, Algeria




1. Introduction                                                                                    2021). Having the same purpose, nuclear energy offers an alternative to
                                                                                                   achieve the target of carbon neutrality (See Fig. 1), especially when
    Sustainable development is now widely acknowledged as being                                    combined with renewable energy sources like wind, solar and hydro­
seriously imperiled by climate change worldwide. The rapid economic                                power, nuclear energy can help nations transition off fossil fuels and
growth experienced by certain countries has led to the extensive utili­                            meet their zero emissions goals by producing heat and low-carbon
zation of resources, resulting in significant environmental degradation,                           hydrogen (International Atomic Energy Agency (IAEA), 2022).
including high pollution and resource mismanagement (Bergougui and                                     The 2022 World Nuclear Industry Status Report states that the
Murshed, 2023; Miao et al., 2017). Without effective climate mitigation                            amount of nuclear power generated globally increased by 3.9 percent in
measures to limit global warming, the world could face severe envi­                                2021—the same percentage as it had decreased in 2020. There were 411
ronmental catastrophes (Obobisa, 2022). At the heart of this issue lies                            reactors in operation worldwide in 2022, which is 26 fewer than in
the world’s reliance on fossil fuels, the primary drivers of both economic                         2011. 53 are being built, with more than half of them taking place in
growth and CO2 emissions. Consequently, this dependency jeopardizes                                China and India, and another 29 are presently in long-term storage.
the present and future sustainability of the planet. Addressing this peril                         China has been using nuclear energy since the early 1990s and today
demands a radical transition from fossil fuels to clean energy sources,                            operates 55 nuclear reactors, the bulk of which have only been con­
ensuring a sustainable future where economic prosperity and ecological                             nected to the grid in the last ten years. This makes China’s nuclear en­
well-being can coexist harmoniously.                                                               ergy program the fastest expanding in the world, but it is also one of the
    Despite the technological advances, many environmental issues,                                 youngest. As of March 2024, the United States maintained its position as
including soil, water, and air pollution, climate change, biodiversity                             the world’s leading nuclear energy powerhouse, with 94 active reactor
loss, and overexploitation of natural resources, have gotten worse                                 units (See Fig. 2). The Japanese program, which has lost a staggering 36
(Javed et al., 2023a,b). Since the establishment of the concept of "sus­                           units since 2011, is nevertheless labeled as operating, despite the
tainable development", numerous market agents, including institutional                             reduction. With 12 nuclear reactors operating at the moment, it is
and private investors, have stated a wish to take environmental sus­                               anticipated that Japan will shortly formally stop building new nuclear
tainability into account in the process of investment decision-making.                             energy facilities.
However, the challenge for scholars and policy-makers is to improve                                    The way governments tackle energy-related environmental issues
environmental quality without sacrificing economic growth (Javed                                   around the world is impacted by rising global warming. As a result,
et al., 2023a,b). For instance, reaching carbon neutrality goals has                               encouraging sustainable development and combating climate change
resulted in the broad use of renewable energy, green technological                                 have been elevated to the status of essential considerations in both short-
innovation, and the circular economy concept (Senadheera et al., 2021).                            and long-term energy planning and policy development (International
These eco-friendly technologies have a significant impact on reducing                              Energy Agency (IEA), 2015). These issues are more common in nations
environmental degradation. Clean energy sources have started to                                    like Algeria where environmental sustainability, energy security, and
replace conventional ones in recent years. These sustainable energy                                economic growth are all prioritized simultaneously. In reality, the high
sources have numerous additional positive economic effects in addition                             reliance of Algeria’s economy on oil earnings and fossil fuel prices
to helping the environment (Charfeddine and Kahia, 2019; Doğan et al.,                            presents several concerns for the country’s future energy,


  * Corresponding author.
    E-mail addresses: bergougui@iss.nl, brahimbergougui@gmail.com (B. Bergougui), samer.mehibel@gmail.com (S. Mehibel), boudjana_reda@hotmail.fr
(R.H. Boudjana).

https://doi.org/10.1016/j.jenvman.2024.121172
Received 29 February 2024; Received in revised form 11 May 2024; Accepted 11 May 2024
Available online 20 May 2024
0301-4797/© 2024 The Author(s). Published by Elsevier Ltd. This is an open access article under the CC BY license (http://creativecommons.org/licenses/by/4.0/).
B. Bergougui et al.                                                                                        Journal of Environmental Management 360 (2024) 121172


environmental, and economic policies (Bélaïd and Abderrahmani,                  economic expansion, domestic energy consumption has been on a steady
2013).                                                                           rise in recent years. This surge in energy usage has contributed to
    Algeria has experienced rapid economic growth since 1970, largely            Algeria’s high CO2 emissions, with the country’s overall carbon dioxide
attributed to its abundant natural fuel resources. This growth was               emissions escalating from 78,925 thousand metric tons in 1990 to
particularly evident during the period between 2007 and 2013 when                121,755 thousand metric tons in 2011 (see Fig. 3). In response to
energy prices soared to unprecedented levels. Despite this economic              environmental concerns, Algeria has prioritized the development of
boon, Algeria remains heavily dependent on oil, with energy-intensive            renewable energy and environmentally friendly technologies to mitigate
industries such as construction and transportation playing significant           CO2 emissions from energy consumption. Initiatives such as the tran­
roles in its economy. However, the country has struggled to diversify its        sition to green energy and the implementation of comprehensive
economy and develop a non-hydrocarbon sector, primarily due to                   renewable energy programs were initiated in 2001. Notably, Algeria
stringent regulations and a focus on state-led growth initiatives.               ranks as the third-largest investor in renewable energy in Africa, ac­
Consequently, job creation in the private sector has been limited. To            cording to REPN (2015), and has maintained a feed-in policy since 2004,
maintain stability, the Algerian government has implemented minor                distinguishing it as a leader in the region. Moreover, Algeria has updated
political reforms and allocated a substantial portion of oil revenues to         its energy strategy to include long-term measures and set new renewable
public sector spending, including significant subsidies for energy, food,        energy targets to be achieved by 2030, as outlined by REPN (2015).
cooking gas, education, and housing. These subsidies, amounting to                    Algeria’s economy relies heavily on oil exports, making it highly
around 30% of the Gross Domestic Product (GDP), have played a crucial            vulnerable to fluctuations in oil prices, which in turn, lead to economic
role in supporting the population. Additionally, the sharp decline in oil        policy uncertainty and affect trade. Recent years have witnessed sig­
prices since mid-2014 has significantly impacted Algeria’s economy.              nificant volatility in oil prices, with prices declining since 2014 and
According to statistics from the Ministry of Finance, the country’s oil          experiencing further instability due to events such as the COVID-19
and gas export revenues, which account for approximately 95% of the              pandemic and the Russia-Ukraine conflict. As one of the world’s
total revenue, plummeted by 41% in 2015, from $60.3 billion in 2014 to           largest oil exporters, Algeria has been significantly affected by these
$35.72 billion. Consequently, economic growth contracted to 2.9% in              fluctuations. Economic uncertainty has also been exacerbated by global
2015 from 3.8% in 2014, reflecting the adverse effects of the global oil         events such as the Arab Spring, as well as domestic factors like the
price downturn. It is widely recognized among scholars a strong positive         weekly protests known as “Hirak” and popular uprisings against the
relationship between oil revenues and economic growth, yet what is               former president, Abdelaziz Bouteflika. These uncertainties underscore
more interesting is to look closely at the relationship between the              the challenges faced by Algeria’s economy, highlighting the need for
damage caused by massive oil consumption on the environment and                  diversification and resilience in the face of external shocks. In this re­
economic growth. In other words, testing the validity of the Environ­            gard, economic policy uncertainty (EPU) can have negative economic
mental Kuznets Curve (EKC) hypothesis will provide policymakers with             and environmental impacts. For example, the EPU could encourage
valuable insights into the environment’s response to economic growth             businesses to use traditional environmentally damaging construction
(Narayan and Narayan, 2010). In fact, there was a growing body of                methods, which could lead to increased environmental degradation.
literature studying the issue (Stern,2014) since the concept of EKC was          However, EPU can also have an impact on resource consumption and
introduced by Panayotou (1993). Al-Mulali et al. (2015) examined                 expenditure, which will reduce CO2 emissions. Additionally, environ­
several nations or groups of nations from all over the world. However,           mental damage may increase in terms of research and development
emerging countries have received less attention, particularly those in           (R&D), innovation and decreased use of renewable energy due to
Africa and the MENA region (Evans et al., 2014; Soytas and Sarı, 2009).          increased EPU (Javed et al., 2023a,b). On the opposite of the growing
    Algeria has witnessed a significant increase in domestic energy de­          literature studying the impact of EPU on various financial and macro­
mand, coinciding with a decline in oil exports. This trend has been              economic variables, including investment choices, oil prices (Olanipe­
exacerbated by the depletion of the country’s oil and gas reserves since         kun et al., 2019), and stock market conditions (Adebayo et al., 2022) as a
2005, attributed to insufficient investment in modernizing existing fields       response to the works of Bloom (2009) and later Baker et al. (2016),
and exploring new ones. Driven by demographic growth and sustained               there was no empirical evidence about the influence of EPU on the




                           Fig. 1. Impacts of renewable and nuclear technologies from the production of 1 kW h, Europe, 2020 11.

                                                                             2
B. Bergougui et al.                                                                                          Journal of Environmental Management 360 (2024) 121172




                                                           Fig. 2. Map of nuclear power reactors.21.


environment before Jiang et al. (2019)’s initial analysis; The last                to examine the asymmetric effects of economic policy uncertainty (EPU)
stressed the importance of taking EPU into account as a significant                and green technology (GT) on carbon dioxide (CO2) emissions in
influencing factor of environmental quality because it usually affects the         Algeria. The current study contributes to the literature in four primary
external environment of the businesses, which may have an impact on                ways.
their decisions about investment and production and, ultimately, their
performance about CO2 emissions. Furthermore, since global un­                       (1) Prior research has mostly ignored other nations, especially
certainties (like the recent COVID-19) can cause economic and political                  developing nations, in favor of concentrating on a few, like China
instability, it is important to emphasize how important EPU is to the                    and Turkey. The proposed study deals with the third-highest
environment and how business decisions are ultimately impacted by it.                    polluter in Africa, Algeria, and the opposite of previous studies
Further studies examined the connection between EPU and environ­                         examines the asymmetric impacts of EPU on Algerian CO2
mental quality after Jiang et al. (2019), with varying degrees of success                emissions. Assessing these potential asymmetric effects will pro­
(Adedoyin and Zakari, 2020; Amin and Dogan, 2021; Yu et al., 2021).                      vide greater insight into the interactions between the Algerian
    Recent years have seen several notable changes to Algeria’s econ­                    economy, energy system, and environment
omy, including rapid shifts and industrial transformations. Algeria’s                (2) The present paper, the opposite of previous research takes into
economy has undergone numerous phases and structural fractures as a                      consideration the non-linear relationships by employing NARDL
result of these developments. These breaks and policy changes are                        and asymmetric causality techniques to examine the asymmetric
crucial to comprehend the effects of economic policy uncertainty (EPU)                   link between EPU and GT on CO2 emissions in Algeria;
and renewable energy technology budgets on Algeria’s environment.                    (3) To deal with the shortcomings stemming from the imperfections
Inspired by the aforementioned analysis, this study aims to close the                    of the EPU, the World Uncertainty Index (WUI) was used instead.
current research gap by tackling the research questions listed below,                    Since the EPU index lacks precision, reliability, and potential
with EPU and renewable energy technology budgets acting as important                     ideological biases (Anser et al., 2021a,b; Javed et al., 2023a,b),
independent variables in the empirical assessment and revisiting the                     the WUI created by Ahir et al. (2022) and based on the country
EKC hypothesis for the Algerian case.                                                    reports of the EIU (Economist Intelligence Unit), presents the
                                                                                         advantage of covering different types of uncertainties (political
      (1) Does a positive (negative) shock in economic policy uncertainty                and economical) (Ahir et al., 2022; Javed et al., 2023a,b), which
          facilitate (impede) progress toward environmental sustainability               makes it more suitable as proxy;
          goals in Algeria?                                                          (4) The time frame in which the study is recorded is the most recent
      (2) Does a positive (negative) shock in green technologies precipitate             one. The last offers to academicians as well as policymakers fresh
          a decline (raise) in carbon dioxide emissions in Algeria?                      insights on the issue.
      (3) Does the EKC hypothesis undermine efforts to achieve environ­
          mental sustainability objectives in Algeria?                                To tackle the issue, the present paper is organized into five sections.
                                                                                   The second section covers the literature regarding economic policy un­
                                                                                   certainty, environmental sustainability, green technology, and the
                                                                                   response of the main socio-economic- aggregates. Section three is
1.1. Study contribution
                                                                                   dedicated to the presentation of the data as well as the adopted meth­
                                                                                   odology, while section four, presents and discusses the empirical results.
      Given the aforementioned background, the objective of this study is
                                                                                   The last section goes over the main conclusions of the study.

  1
      iaea-ccnp2022-body-web.pdf.

                                                                               3
B. Bergougui et al.                                                                                             Journal of Environmental Management 360 (2024) 121172




                                                           Fig. 3. CO2 emissions trends in Algeria.




                                                   Fig. 4. Scatter plot and data distribution visualizations.


2. Literature review                                                               CO2. The consumption effect refers to how EPU dampens energy and
                                                                                   pollution-intensive product usage, thereby mitigating emissions.
2.1. Theoretical underpinning                                                      Conversely, the investment effect describes how EPU discourages R&D,
                                                                                   renewables, and innovation investment, consequently increasing emis­
    This section elucidates the theoretical linkages between economic              sions. Given these counteracting forces, EPU may either escalate or
policy uncertainty, green technologies, and carbon dioxide (CO2)                   de-escalate CO2.
emissions. As described by Jiang et al. (2019), EPU impacts CO2 emis­                 Scholarly investigations into the emissions mitigation potential of
sions through two key channels - the direct policy adjustment effect and           advanced green technologies, including renewable energy generation
the indirect economic demand effect. The direct effect refers to how               and improved equipment efficiency, have produced ambiguous con­
heightened EPU shifts policymakers’ attention away from environ­                   clusions, despite strong theoretical support. The seminal work of Braun
mental protections towards economic stabilization measures, thereby                and Wield (1994) first conceptualized technological innovation as
increasing emissions. Meanwhile, the indirect effect relates to how EPU            techniques, activities, and products conferring environmental benefits.
alters economic conditions and decision-making, subsequently influ­                This paved the way for the related notion of Environmentally Sound
encing energy consumption and CO2 emissions. Additionally, existing                Technologies (Verhoosel, 1998), perceived as instrumental in simulta­
EPU literature highlights its effects on factors like foreign direct in­           neously achieving carbon neutrality and economic growth. Recent
vestment, overall investment, trade, stock markets, economic growth,               studies contend these technologies can offer firms competitive advan­
innovations, and oil prices (Canh et al., 2020; X. Sun et al., 2020).In            tages via enhanced production efficiency and lowered compliance costs
turn, prior studies demonstrate these same factors’ impacts on CO2                 (Lanoie et al., 2011; Lin and Ma, 2022). From a theoretical lens, Porter
emissions (Danish et al., 2019; Salahuddin et al., 2018). Therefore, EPU           and van der Linde (1995) linked innovation and emissions reductions,
can affect emissions indirectly through these mediating variables.                 arguing that well-designed regulations could catalyze green innovation
Recently, Wang et al. (2020) identified two specific channels - the                and competitiveness. However, empirical studies examining the decar­
consumption and investment effects - through which EPU influences                  bonization potential of both technological innovation and renewable
                                                                                   energy utilization have yielded equivocal findings. Further research is
                                                                                   imperative to elucidate the complex relationships between environ­
  2
                                                                                   mental technologies, renewable energy, and emissions mitigation.
      World Nuclear Power Reactors 1951–2024 (worldnuclearreport.org).

                                                                               4
B. Bergougui et al.                                                                                         Journal of Environmental Management 360 (2024) 121172


2.2. Economic policy uncertainty and environmental sustainability                period ranging from 1985 to 2017 for the case of the United Kingdom.
                                                                                 Adedoyin & Zakari (2020) concluded that that while economic policy
    The behavior of economic agents, including choices about in­                 uncertainty lowers CO2 emissions in the near term, appropriate policies
vestments and consumption, is influenced by the uncertainty sur­                 are needed to slow the rise in carbon emissions over time to maintain the
rounding economic policies, which include trade, monetary, fiscal, and           beneficial effects of EPU on CO2 emissions. The findings regarding
other interconnected policies (Tiwari et al., 2019). Recent world events         causality demonstrate the presence of unidirectional causality extending
have highlighted the uncertainty and volatility in economic policy­              from energy use to CO2 emissions, CO2 emissions to EPU, and energy
making. The global financial crisis that began in 2007 revealed weak­            consumption to EPU. A recent study by Ayad et al. (2023) examined the
nesses in financial regulation and oversight. The European debt crisis           relationship between economic policy uncertainty and environmental
that followed showcased the challenges of monetary integration. More             degradation in select Middle East and North Africa (MENA) countries.
recently, the US-China trade war demonstrated rising economic tensions           Using an enhanced Stochastic Impact by Regression on Population,
between major powers. Other disruptions like Brexit have added to the            Affluence, and Technology (STIRPAT) model and ARDL techniques, they
unpredictability. With major shocks like COVID-19 and the                        analyzed data from 1970 to 2020 for Algeria, Iran, Saudi Arabia,
Russia-Ukraine conflict, the global economy faces great uncertainty              Morocco, Egypt, and Turkey. Their results supported the validity of the
ahead. In this regard, Balsalobre-Lorente et al. (2024b) question                EKC hypothesis, indicating an inverted U-shaped relationship between
whether pollution issues will increase or decrease due to high levels of         economic development and environmental damage. The findings also
geopolitical risk and unpredictability in economic policy. To provide            revealed that increased policy uncertainty exacerbated CO2 emissions,
answers, the authors analyze how economic complexity, geopolitical               especially in Morocco, Turkey, and Iran which saw sharp rises. High
risk, uncertainty in economic policy, renewable energy consumption,              energy consumption and population growth over the study period
and economic growth affect environmental pollution in G20 countries              further escalated emissions across the sample. Given these findings, the
during 1997–2018. The estimated long-term coefficients produced by               authors recommend MENA policymakers account for prevailing eco­
the Fully Modified Ordinary Least Squares (FMOLS) estimator support              nomic uncertainty when devising environmental strategies. Promoting
the theory of inverted U-shaped EKC relationships between carbon                 renewable energy to improve the energy mix could also help mitigate
footprints & carbon dioxide emissions and economic complexity &                  emissions. The study provides useful insights for MENA countries
ecological footprint. Besides, environmental quality for G-20 countries          seeking to balance development goals with environmental
was found to be positively affected by geopolitical risks interplayed with       sustainability.
renewable energy use as well as with the degree of complexity con­                   A pertinent work from Esmaeili et al. (2023) in which they study the
cerning economy amid uncertain policies, which makes environmental               effects of trade openness, natural resource rents, social welfare, and
quality decrease along with economic growth as well as between                   economic policy uncertainty on ecological footprint. The latest is
regional political instability and increasing economic complexities.             considered the most complete indicator of environmental degradation.
Moreover, the results revealed the existence of a significant relationship       The above-mentioned study dealt with a panel comprising 19 nations
between carbon emissions about ecological impact and economic policy             with high energy consumption. In this paper, the authors assess how the
uncertainty. Lastly, causality analysis demonstrates that the explanatory        study’s variables affect ecological footprint using the conventional panel
variable is responsible for the pollution indicators. As a consequence,          ARDL and Cross-Sectionally Augmented Autoregressive Distributed Lag
policymakers must account for this unpredictability when charting a              (CS-ARDL) methodologies. Due to slope heterogeneity and
course forward (Al-Thaqeb and Algharabali, 2019).                                cross-sectional dependence issues, the CS-ARDL was chosen since it
    Bhowmik et al. (2022) investigated the environmental Phillips curve          yields results that are notably more robust. In their findings, the authors
(EPC) hypothesis between unemployment and CO2 emissions in the USA               highlighted the existence of a short-term negative impact of trade
using a dynamic Autoregressive Distributed Lag (ARDL) simulations                openness and economic policy uncertainty on the ecological footprint
model. They also looked at the influence of various uncertainty indices          but a positive one in the long term. Furthermore, neither in the short nor
(trade, fiscal, and monetary uncertainties) on environmental degrada­            long term does life expectancy have a major impact on ecological foot­
tion. The results confirmed the EPC hypothesis’s long-term validity.             print. Concurrently, the outcomes validated the two-way causal rela­
Furthermore, the results showed that whereas fiscal policy uncertainty           tionship between the study’s variable and ecological footprint. The
leads to a decrease in emissions, monetary policy uncertainty is posi­           results have cleared the path for the adoption of sensible legislation to
tively correlated with CO2 emissions. In contrast, the findings suggested        raise environmental standards. Furthermore, using the findings of this
that there may be no relationship at all between trade policy uncertainty        study, a thorough policy framework for more stringent environmental
and emissions. Similar to the previous, Syed and Bouri (2022) examined           control is anticipated to be constructed.
the effect of EPU on CO2 emissions in the USA from January 1985 to
December 2019 using the bootstrap ARDL model. Their findings indi­
                                                                                 2.3. Green technology and environmental sustainability
cated a range of short- and long-term consequences. On the one hand, it
is clear that EPU short-term increases CO2 emissions, which worsens
                                                                                    Green technology encompasses a diverse array of innovative ap­
environmental damage. EPU, on the other hand, reduces emissions,
                                                                                 proaches aimed at implementing sustainable practices in daily life.
enhancing environmental quality. Furthermore, using quantile regres­
                                                                                 These technologies prioritize the conservation of natural resources and
sion, Syed et al. (2022) examined the effects of EPU and geopolitical risk
                                                                                 minimize environmental impact throughout their production and use.
on CO2 emissions in the BRICS countries plus Turkey between 1990 and
                                                                                 By offering alternatives to fossil fuels, green technology promotes
2015. The findings showed that in contrast to higher quantiles where the
                                                                                 environmental, human, and ecological health3. Environmental sustain­
EPU increases emissions, lower and medium quantiles recorded a drop
                                                                                 ability emphasizes the responsible use of natural resources, recognizing
in CO2 emissions due to EPU. On the other hand, the emissions in the
                                                                                 their finite nature. It advocates for the preservation and responsible
middle and upper quantiles decrease while those in the lower quantiles
                                                                                 management of resources to ensure their availability for future
increase due to high geopolitical risk. Both Anser et al. (2021) and Anser
et al. (2021) examined the same subject as Syed et al. (2022) for the
same time frame but focused on a group of developing nations (Mexico,             3
                                                                                     Podesta, John, Todd Stern, and Kit Batten. "Capturing the energy oppor­
China, Brazil, and Colombia). The results unequivocally demonstrated             tunity: creating a low-carbon economy." (2007).
that energy use and EPU increase CO2 emissions in opposition to the
utilization of renewable energy sources and geopolitical risk.
    Based on the results of an ARDL model and Granger causality for a

                                                                             5
B. Bergougui et al.                                                                                           Journal of Environmental Management 360 (2024) 121172


generations.4 The concept of sustainability rests on three pillars: envi­          2.4. Alternative technologies for a sustainable environment
ronmental, social, and economic. These pillars are interconnected, and if
one is weak, it can undermine overall progress. Sustainable development                In the context of technical innovation, particularly in the area of
strives to maintain a balance among these pillars, ensuring that progress          manufacturing and production process innovation, Acemoglu et al.
is both liveable and equitable (Goodland, 1995; Slocum, 2015), but                 (2012) suggest two distinct categories for technologies: "green" and
because of the way these pillars interact, progress cannot be sustained.           "dirty.". While green technologies include inventions that have a bene­
    Although there has been research on green technologies (GTs) since             ficial environmental impact and provide practical solutions to pollution
the 1970s, environmental concerns have garnered more attention in                  problems, dirty technologies are those that exacerbate environmental
recent years. As a result, a thorough examination of the literature reveals        burdens and pollution. In this regard, Leon et al. (2017) shed light on the
a research deficit in certain current global literature related to the             possibility of identifying clean technologies using the IPC classification
discipline of GTs, which is necessary to address these growing concerns            that can be found in the “IPC Green Inventory” publication by The World
(Usmani et al., 2021). Furthermore, the GTs’ research was primarily                Intellectual Property Organization. These green inventories cover a va­
focused on a limited number of themes. The economic and social di­                 riety of activity sectors, such as nuclear power generation, trans­
mensions of sustainability were overlooked in this setting, with the               portation, energy production, and energy conservation. The ways
environmental sustainability of GTs receiving much of the attention.               through which green technologies could impact carbon footprint are
Moreover, there has been a dearth of research on important constructs              described by the literature as the influencing channels (Bergougui and
associated with GTs, such as the adoption of sustainable technologies              Aldawsari, 2024). Based on the previous, there is a need to distinguish
and green or environmental technology anxiety, which refers to stake­              between direct and indirect impacts. By focusing on the last, this can be
holders’ concerns about the idea’s use and commercialization at this               achieved through (1) improving energy efficiency, which was proved in
early stage of development. It follows that the literature about the               the contribution of Shabir et al. (2023) in which green patents have led
adoption of GTs is not fully covered by the prior studies. According to            to a decrease in energy intensity in industrial sectors across seventeen
Jeurissen (2000), the sustainable integration of the economic, environ­            OECD nations; (2) the structure of energy consumption; which accord­
mental, and social components present in manufacturing enterprises is              ing to Aydin and Degirmenci (2023) exerts an influence that helps to
known as the "triple bottom line" in the context of GTs. It is insufficient        make the cost of clean energy down, as a consequence gets the pro­
to concentrate solely on the environmental element of GTs to reap the              portion of the last higher in the whole structure; (3) boosting the
most benefits. To address the social and economic sustainability ele­              modernization of industrial structures by promoting the growth of
ments of GTs, several crucial tasks are needed. Furthermore, there is a            environmentally conscious and low-pollution industries (Yu et al., 2023)
consensus that incentives and rewards may hasten the early adoption of             and; (4) end-of-pipe treatments including carbon collection, use, and
GTs, which is advantageous for efficient green project management.                 storage are important factors in lowering carbon footprints (Hammar
However, some obstacles must be overcome before GTs can be widely                  and Löfgren, 2010; Z. Sun et al., 2023).
adopted. These obstacles may include worries about adopting new
technology, ideas that need to be commercialized, the cost of installa­            2.5. EKC hypothesis, GDP, and environmental sustainability
tion, and a tiny market share (Bollinger, 2015; Gollin et al., 2005;
Hottenrott et al., 2016). In this regard, another aspect that has been                 The Environmental Kuznets Curve (EKC) theory suggests a rela­
dealt with in the literature is related to the financing of these green            tionship between environmental degradation and per capita income.
technologies. For that matter, Koval et al. (2022) conducted a theoret­            Initially, pollution emissions rise, and environmental quality declines
ical analysis to identify and categorize green financial instruments as            during early economic growth. However, as per capita income surpasses
follows: (1) aimed at greening and eco-modernizing existing technolo­              a certain threshold (which varies depending on various factors), the
gies for the production of goods and services to reduce greenhouse gas             trend reverses. At higher income levels, environmental degradation
emissions; (2) aimed at developing and implementing innovative pro­                decreases. In essence, the relationship between per capita income and
jects that alter existing technologies for the production of goods and             environmental damage forms an inverted U-shape. The importance of
services to eliminate greenhouse gas emissions. For their side, Lorente            environmental preservation and deterioration has been highlighted by
et al. (2023) examined the relationships between the climate change                numerous studies that examined the connection between energy use,
index, green financial assets, renewable energy markets, and geopolit­             economic growth, and environmental effects without concentrating
ical risk index from June 1, 2012, to June 13, 2022, using Quantile                specifically on the EKC hypothesis. For instance, Salahuddin and Gow
Vector Autoregressive (QVAR) and Wavelet Coherence (WC). Their re­                 (2014) investigated the connection between the Gulf Cooperation
sults indicate that the climate change index, green financial assets, and          Countries (GCC) countries’ CO2 emissions, energy consumption, and
clean energy have a significant impact on financial markets.                       economic growth. Additionally, (Salahuddin et al., 2015) investigated
    In their study on Algeria, (Rahmane et al., 2021) investigated the             how the GCC countries’ financial development, electricity consumption,
energy-environment nexus, examining how renewable energy contrib­                  carbon dioxide emissions, and economic growth relate to one another.
uted to preserving Algeria’s ecological footprint between 1990 and                 Furthermore, Sweidan & Alwaked (2016) investigated how human
2017. Their analysis revealed a bidirectional causal relationship be­              well-being in the GCC countries was impacted by economic develop­
tween renewable energy use and ecological footprint over the sample                ment and energy intensity. Several studies have examined the rela­
period. However, they found that renewable energy did not decrease                 tionship between CO2 emissions, energy consumption, economic
ecological footprint, attributing this ineffectiveness to the limited              growth, and other factors. For example, Bekhet et al. (2017) used dy­
adoption of renewable energy sources. The authors emphasized the                   namic simultaneous equation models to analyze these connections in
critical importance of substantially scaling up renewable energy utili­            GCC countries. Saidi and Hammami (2017) simulated the link between
zation to mitigate environmental degradation in Algeria.                           transportation, growth, and environmental degradation in 75 nations.
                                                                                   Salahuddin et al. (2018) looked at how energy use, expansion, financial
                                                                                   development, and investment affected Kuwait’s emissions. Gorus and
                                                                                   Aydin (2019) studied the emissions-growth-energy nexus in MENA. For
                                                                                   the case of the countries of the North American Free Trade Agreement
                                                                                   (NAFTA), Jahanger et al. (2022) offer a fresh perspective by outlining
 4
    Tummala, S.K., Indira Priyadarshini, T., Morphological Operations and          how natural resources and the use of renewable energy affect carbon
Histogram Analysis of SEM Images using Python, Indian Journal of Engineering       emissions against the backdrop of the EKC hypothesis for the period
and Materials Sciences (2022), 29(6), pp. 794–798.                                 spanning from 1990 to 2018, and to evaluate the validity of the

                                                                               6
B. Bergougui et al.                                                                                         Journal of Environmental Management 360 (2024) 121172


pollution haven hypothesis, the analysis accounts for the Foreign Direct         CO2 emissions, the second stresses a negative effect of EPU on ecological
Investment (FDI) inflow. Their findings confirm an inverted U-shaped             footprint. As a consequence, the present study addresses this gap by
relationship between economic growth and carbon emissions, but only              evaluating the asymmetric influence of EPU on CO2 emissions in
over the long term, demonstrating the existence of the EKC hypothesis.           Algeria, the third-highest carbon emitter in Africa.
Furthermore, data supporting the environmental resource curse shows                  Second, existing literature examining determinants of CO2 emissions
that increased use of natural resources is linked to increased carbon            has predominantly used linear modeling approaches (Hussain et al.,
dioxide emissions in the short and the long-term. In addition, there is a        2022; Bouznit et al., 2016), which fail to account for potential non-linear
correlation between reduced carbon emissions and increasing renew­               relationships between variables and to find out any possible hidden
able energy usage only over an extended period and the pollution haven           co-integration as suggested by Granger and Yoon (2002). Reliance on
theory was found to be false in the short- and long-term. One of the most        these methods may produce unreliable findings. To address these limi­
catching results is the tradeoff NAFTA countries are facing between              tations, the current study employs the NARDL methodology to investi­
promoting economic development or becoming greener. On the other                 gate possible asymmetric effects of increases versus decreases in EPU
side of the globe, Li and Lu (2019) analyzed indicators from China’s             and GT on CO2 emissions.
economy, energy, and environment related to natural gas use by                       Third, Previous studies have utilized the economic policy uncer­
focusing on their efficaciousness. Usman et al. (2021) researched                tainty (EPU) index developed by Baker et al. (2016) as an indicator of
financial inclusion, renewables, growth, and environmental footprints in         policy uncertainty. However, the EPU index has some limitations. First,
top-emitting countries. Yang et al. (2021) examined globalization,               it only encompasses uncertainty related to monetary, trade, and fiscal
growth, industrialization, ecological footprint, and healthcare spending.        policies, excluding uncertainty stemming from political events (Ahir
Charfeddine and Kahia (2021) investigated whether renewables and                 et al., 2022). Additionally, the EPU index is not constructed from a
Information Communication Technologies (ICT) reduce CO2 in the                   common baseline across different countries, raising concerns about ac­
MENA region. In summary, numerous studies have investigated factors              curacy, reliability, and potential ideological biases (Ahir et al., 2022). To
influencing CO2 emissions in various countries and regions. Other pre­           address these shortcomings, Ahir et al. (2022) constructed the world
vious studies have also examined the EKC hypothesis, which posits an             uncertainty index (WUI) for 143 countries based on Economist Intelli­
inverted U-shaped relationship between economic development and                  gence Unit (EIU) country reports. The WUI offers advantages over the
environmental degradation, focusing on carbon dioxide (CO2) emissions            EPU index, as it is derived from a consistent baseline and incorporates
in Algeria (Bouznit et al., 2016; Sari SARİ HASSOUN et al., 2019). While        uncertainties related to both economic policies and political de­
Bouznit et al. (2016)found evidence supporting the EKC relationship in           velopments. Given these merits, the current study employs the WUI as a
Algeria from 1970 to 2010, Sari-Hassoun et al. (2019) rejected the EKC           proxy for economic policy uncertainty and investigates its impact on
hypothesis for Algeria from 1995 to 2016. Sari Hassoun et al. (2019)             CO2 emissions in Algeria.
utilized vector error correction and Granger causality modeling and                  Lastly, unlike previous studies (Amri, 2017; Ayad et al., 2023), this
determined bidirectional causality exists between CO2 emissions and              analysis utilizes the most recent data available from 1980 to 2022 to
renewable energy consumption, with unidirectional causality from                 assess the asymmetric and changing impacts of positive and negative
economic growth to emissions. Their findings suggest increasing eco­             shocks on pollution levels over time in Algeria. Consequently, Algerian
nomic growth, fossil fuel production, and consumption raise CO2                  policymakers can account for the differing pollution effects of positive
emissions while increasing renewable energy consumption lowers                   and negative shocks when crafting fiscal, monetary, and regulatory
emissions and economic growth. These contradictory conclusions reveal            policies aimed at pollution mitigation.
uncertainty regarding the empirical validity of the EKC hypothesis in
Algeria and call for further investigation. The asymmetric effects of            3. Data and econometric technique
explanatory variables like economic policy uncertainty and renewable
energy investments on environmental sustainability have yet to be                3.1. Data
explored.
    This represents a research gap the study aims to address by exam­                This study investigates the impacts of economic policy uncertainty
ining the asymmetric relationship between economic policy uncertainty,           (EPU) and green technology (GT) on pollution levels in Algeria. The
green technologies, and CO2 emissions in Algeria using nonlinear                 analysis covers data from Q1-1980 to Q4-2022. However, the green
autoregressive distributed lag modeling. Assessing these potential               technology data had missing values for 1995 and 1988, which were
asymmetric effects will provide greater insight into the interactions            addressed through interpolation to generate a continuous time series.
between the Algerian economy, energy system, and environment.                    While transforming the data from annual to quarterly frequencies
                                                                                 somewhat mitigated the limitations of a shorter period imposed by data
2.6. Evaluation of the literature                                                scarcity, accessibility of sufficient annual observations would have been
                                                                                 preferable. To further address the challenge posed by the limited period,
    The available literature examines EPU and GT’s, effects on CO2               the quadratic match-sum approach outlined by (Bergougui, 2024) was
emissions in great detail. However, this study attempts to fill in some of       employed, which adjusts for cyclical variations and seasonality in the
the gaps and limitations found in previous research. Based on a critical         data. This yielded more reliable results by reducing point-to-point
approach, this subsection discusses below in which area the paper’s              fluctuations and isolating the non-seasonal component, strengthening
contribution helps enhance the understanding of the issue compared to            confidence in the findings given data constraints.
what has been produced so far:                                                       Dependent Variable: CO2 emissions per capita, is a commonly used
    First, as far as can be determined, no existing research has investi­        measure of environmental pollution and greenhouse gas emissions. It is
gated the asymmetric impacts of EPU on Algerian CO2 emissions. The               typically reported in metric tons per capita and represents the total
relationship between EPU and CO2 has already been dealt with in the              carbon dioxide emissions from the burning of fossil fuels and the
literature. For instance, Ayad et al. (2023) investigated how certain            manufacture of cement, divided by the country’s population. The CO2
economic policies affect the quality of the environment in a few MENA            emissions per capita data for Algeria was obtained from the Global
nations based on an augmented STIRPAT model for the period from                  Carbon Project.
1970 to 2020. Their purpose was to identify any potential effect between             The control variable, GDP per capita, is a widely used measure of a
carbon dioxide (CO2) emissions and the uncertainty index. The results of         country’s economic output and standard of living. It is calculated by
this paper are in contradiction with the results of Hussain et al. (2022).       dividing a country’s gross domestic product (GDP) by its total popula­
While the first indicates the absence of any impact of uncertainties on          tion. For this analysis, the GDP per capita data for Algeria were obtained

                                                                             7
B. Bergougui et al.                                                                                                   Journal of Environmental Management 360 (2024) 121172


from world development indicators. The data is reported in constant                      Table 2
2010 US dollars, which adjusts for inflation and allows for consistent                   Descriptive statistics.
comparisons over time.                                                                                     CO2        EPU          GT            GDP          GDP2
    Independent Variables: Green Technology (GT) is measured by the
                                                                                           Mean            0.596357   4.704088     4.589987      24.01144     13.55079
number of patents related to technologies. Patent data is commonly used                    Median          0.523281   4.666783     4.488285      23.93604     13.53551
as a proxy for technological innovation and progress, as it represents the                 Maximum         0.838750   5.417820     5.429209      24.51365     13.93673
output of research and development efforts (Bergougui et al., 2024). The                   Minimum         0.356953   4.605170     3.388882      23.44851     13.10521
GT data for Algeria was obtained from world development indicators.                        Std. Dev.       0.134158   0.135775     0.610701      0.341205     0.254358
                                                                                           Skewness        0.536866   2.307776     − 0.173875    0.152065     − 0.050288
The World Uncertainty Index (WUI) is a proxy measure for economic                          Kurtosis        1.867186   9.711094     1.697667      1.565845     1.653765
policy uncertainty (EPU) used in this work. The WUI is calculated by                       Jarque-Bera     17.45922   475.4518     13.02185      15.40328     13.06100
measuring the frequency of the word "uncertainty" (and its variants) in                    Probability     0.000162   0.000000     0.001487      0.000452     0.001458
Economic Intelligence Unit (EIU) reports. The methodology for calcu­
lating the WUI involves the following steps.
                                                                                         presence of nonlinearity within each variable. To this end, the widely
                                                                                         employed BDS test was utilized. This ensures appropriate modeling
 • Data Source: The EIU reports, published [frequency, e.g., monthly,
                                                                                         techniques are employed.
   quarterly], provide country-level analyses and forecasts for the
   global economy.
 • Text Analysis: The reports are analyzed using text-mining techniques                  3.2.1. BDS test methodology
   to identify and count the occurrences of the word "uncertainty" and                       The BDS test is a nonparametric statistical test designed to detect
   its variants (e.g., uncertain, uncertainties).                                        nonlinear dependencies in time series data. Unlike linear models
 • Normalization: The raw count is normalized by the total number of                     restricted to considering only the immediate past value (lag 1), the BDS
   words in each report to account for varying report lengths.                           test examines dependencies across multiple lags. Specifically, the BDS
 • Aggregation: The normalized values are aggregated at the [specify the                 test calculates product moments, which quantify the deviations from
   level, e.g., country, region] level to obtain a single WUI value for                  independence in the product of multiple lagged terms. By analyzing
   each [period, e.g., month, quarter].                                                  these product moments across various lag combinations, the test sta­
 • Transformation: To account for potential volatility and provide a                     tistically assesses the presence of nonlinear relationships beyond those
   smoother representation, the WUI values are transformed using a                       expected in random data. Significant non-zero product moments indi­
   three-quarter moving average.                                                         cate the presence of nonlinear dependencies.

    Higher values of the WUI indicate greater economic policy uncer­                     3.2.2. The rationale for choosing the BDS test
tainty, as reflected in the frequency of "uncertainty" mentioned in the                     Several factors motivated the choice of the BDS test for this analysis.
Economic Intelligence unit reports. The used WUI data was obtained
from worlduncertaintyindex.com, which provides a comprehensive                            • Comprehensive nonlinearity detection: Unlike the RESET test, which
database of WUI values for various countries and regions. The variables                     primarily focuses on model misspecification due to omitted squared
are presented in Table 1, with all variables expressed in natural loga­                     terms, the BDS test can detect a broader spectrum of nonlinear re­
rithmic form.                                                                               lationships. This is crucial as the research question explores the po­
                                                                                            tential impact of EPU and GT on environmental degradation, which
3.2. Methodology                                                                            might involve complex, nonlinear interactions.
                                                                                          • Non-parametric nature: The BDS test does not require any assump­
    This study employs a methodological framework (see Fig. 5) to assess                    tions about the underlying data distribution, making it advantageous
the asymmetric and long-run impacts of EPU, GT, and GDP on CO2                              for potentially non-normal data, a common characteristic of envi­
emissions in Algeria. The multi-step process captures EPU and GT’s                          ronmental and economic time series.
differential effects on environmental degradation while accounting for                    • Moment-independence: The test is not reliant on the existence of
unknown structural breaks.                                                                  higher moments in the data, making it less vulnerable to outliers that
                                                                                            can affect these moments.
Step 1. Nonlinearity Assessment and the Brock-Dechert-Scheinkman
(BDS) Test                                                                                   These combined strengths make the BDS test a well-suited choice for
   Time series data in environmental and economic domains often                          this analysis, allowing for a comprehensive assessment of nonlinear re­
exhibit inherent nonlinear characteristics, such as time irreversibility                 lationships within the time series data.
and asymmetric distributions. Before investigating the impact of EPU,
GT, and GDP on CO2 emissions in Algeria, it is imperative to assess the                  Step 2. Unit root analysis
                                                                                             Following the BDS test, the analysis uses the Augmented Dickey-
                                                                                         Fuller test to assess the stationarity of the time series data. However,
Table 1
                                                                                         addressing a wide range of structural breaks within macroeconomic
Summary of data.
                                                                                         variables poses a significant challenge due to their unknown number,
  Abbreviation        Indicator name   Measurement                   Source
                                                                                         duration, and form. This could potentially affect the results of the ADF
  CO2                 Carbon dioxide   Metric ton per capita         Global carbon       test. Therefore, we employed The Fourier Augmented Dickey-Fuller
                      emissions                                      project             proposed by (Enders and Lee, 2012). the F-ADF test offers numerous
  EPU                 Economic         The index is computed based   World
                                                                                         advantages over the ADF test.
                      policy           on the frequency of           uncertainty
                      uncertainty      uncertainty-related           index
                                       terminology in Economic                            • The test can be used to control multiple smooth fractions of an un­
                                       Intelligence Unit (EIU)                              known functional form.
                                       reports.
                                                                                          • The test can often detect a process of gradual structural change.
  GT                  Green            Number                        WDI
                      technologies                                                        • The test often captures sharp breaks and various types of nonlinear
  GDP                 GDP per capita   Constant 2010 $ US            WDI                    trends.
Note. WDI: world development indicators. EIU: Economic Intelligence unit.

                                                                                     8
B. Bergougui et al.                                                                                      Journal of Environmental Management 360 (2024) 121172




                                                        Fig. 5. Design of the analysis process.


 • mitigate the risk of power loss commonly encountered in unit root            • Improved performance with smaller samples: The Fourier ADL
   tests when employing a large number of estimated dummy variables.              cointegration test demonstrates superior performance with smaller
                                                                                  sample sizes compared to the Vector Error Correction Model
    Identifying stationarity allows for appropriate specification of the          (VECM).
integration order for each variable in subsequent modeling stages.
                                                                                   The null hypothesis of the Fourier ADL cointegration test is that no
Step 3. Cointegration analysis
                                                                               cointegrating relationship exists between the variables. Conversely, the
   The study employs the Fourier Autoregressive Distributed Lag (ADL)
                                                                               alternative hypothesis suggests a cointegrating relationship is present
cointegration test proposed by Banerjee et al. (2017), incorporating
                                                                               (Kirikkaleli, 2023).
Gallant’s (1981) flexible Fourier function form. This approach offers
several advantages over traditional cointegration tests.                       Step 4. Asymmetry Analysis
                                                                                  In addition to the Fourier ADL cointegration test, the analysis im­
 • Overcomes limitations with structural breaks: The Fourier ADL               plements the NARDL bounds procedure proposed by Shin et al. (2014) to
   cointegration test utilizes Fourier terms to account for potential          investigate cointegration within the asymmetric modeling framework.
   structural breaks, unlike traditional methods which may suffer              Linear cointegration techniques are not well-suited to capture the
   power loss in their presence.                                               complex relationships between time series potentially influenced by
 • Avoids power distortions: The test incorporates dummy variables             sporadic external shocks. The NARDL approach offers several
   for structural changes, mitigating power distortions (Kirikkaleli,          advantages.
   2023).



                                                                           9
B. Bergougui et al.                                                                                            Journal of Environmental Management 360 (2024) 121172


 • Accommodates nonlinearity: The NARDL model can flexibly                          nonparametric Hatemi-j (2012) asymmetry causality test.
   accommodate nonlinearity in the data.
                                                                                    Step 7. Robustness Checks
 • Distinguish short-run and long-run asymmetries: The model al­
                                                                                       The study corroborates the findings from the Fourier NARDL model
   lows for the distinction between short-run and long-run asymmetric
                                                                                    by employing alternative estimation techniques, including the Fully
   effects (Kirikkaleli, 2023; Islam et al., 2023).
                                                                                    Modified Ordinary Least Squares (FMOLS), Dynamic Ordinary Least
 • Robustness and avoids limitations around integration order:
                                                                                    Squares (DOLS), and Canonical Cointegrating Regression (CCR)
   Compared to alternatives like the VECM model, NARDL exhibits
                                                                                    methods. Furthermore, the robustness of the results is assessed by
   superior robustness and avoids limitations associated with integra­
                                                                                    examining the impact of the dependent variable using a substitute
   tion order (Ayhan et al., 2023). This unrestricted framework allows
                                                                                    measure and evaluating the sensitivity of the results to the inclusion of
   for smoother empirical analysis regardless of the series’ integration
                                                                                    control variables by estimating the model without any control variables.
   properties.

                                                                                    3.3. Model specification
Step 5. diagnostic tests
    This section addresses the robustness of the NARDL estimates
                                                                                        Historical events like the 1997 Asian economic crisis, the 2008
through a battery of diagnostic tests. These tests ensure the model’s
                                                                                    financial crisis, and the COVID-19 pandemic have induced structural
validity and the reliability of the coefficient estimates.
                                                                                    breaks in time series data. However, most nonlinear ARDL studies with
                                                                                    structural breaks assume known break numbers and use dummy vari­
 • Breusch-Godfrey LM test: This Lagrange Multiplier (LM) test by
                                                                                    ables to capture sudden shifts. Yet time series often exhibit multiple
   (Breusch, 1978; Godfrey, 1978a,b) examines the residuals for serial
                                                                                    unknown breaks. Therefore, following (Yilanci et al., 2020; Zaghdoudi
   correlation. The presence of autocorrelation can lead to biased
                                                                                    et al., 2023), this study employs the Fourier nonlinear ARDL model, a
   standard errors and unreliable significance levels for the estimated
                                                                                    modified version of the nonlinear ARDL (Shin et al., 2014), by incor­
   coefficients.
                                                                                    porating Fourier trigonometric terms. This captures key features of
 • Breusch-Pagan-Godfrey test: This test, developed by (Breusch and
                                                                                    structural changes and both long-run asymmetric effects of economic
   Pagan, 1979; Godfrey, 1978a,b), detects heteroscedasticity, a con­
                                                                                    policy uncertainty (EPU) and green technology (GT) on pollution in
   dition where the error term’s variance is not constant across obser­
                                                                                    Algeria. The Fourier nonlinear ARDL flexibly models multiple unknown
   vations. Heteroscedasticity can also lead to inefficient estimates and
                                                                                    breaks while examining EPU and GT’s impacts on environmental
   inaccurate standard errors.
                                                                                    degradation.
 • Ramsey Reset test: This specification test by Ramsey (1969) offers a
   more general approach to identifying model misspecification. It in­                                                              (
                                                                                    EFt = α0 + α1 (EPU)t + α2 (GT)t + α3 (GDP)t + α4 GDP)2t + μt + εt  (1)
   vestigates whether relevant explanatory variables have been omitted
   from the model. Omitted variables can bias the estimates and limit                                                                (
                                                                                    In this analysis, EFt , (EPU)t , (GT)t , (GDP)t , GDP)2t represent CO2 emis­
   the model’s ability to capture the true relationships.
                                                                                    sions, economic policy uncertainty, green technologies, economic
 • CUSUM and CUSUM-Square tests: These cumulative sum (CUSUM)
                                                                                    growth, and the square of economic growth in Algeria over time t,
   tests, proposed by Brown et al. (1975), assess the stability of the
                                                                                    respectively. EPU enhances environmental sustainability, as measured
   model’s parameters over time. They detect structural breaks or
                                                                                    by lower CO2t, if α1 < 0. Conversely, α1 > 0 implies green technology
   parameter shifts that might have gone unnoticed during estimation.
                                                                                    advancement abandons atmospheric wellbeing by increasing CO2t.
   Unstable models can lead to unreliable forecasts and misleading
                                                                                    Hypothesizing α3 > 0 suggests that GDP degrades sustainability by
   inferences.
                                                                                    exerting positive pressure on emissions. Below is the long-run asym­
 • Wald test for asymmetric effects: This test targets the null hypoth­
                                                                                    metric CO2 emissions equation:
   esis of no asymmetric effects of the independent variables on the
                                                                                                  (             (               (         (
   dependent variable in both the short and long run. Rejection of this             CO2t = α0 + α1 EPU)+  t + α2 EPU)t + α3 GT)t + α4 GT)t
                                                                                                                        −            +          −
                                                                                                                 (                                           (2)
   null hypothesis indicates the presence of asymmetry, a key feature                                                     2
                                                                                               +α5 (GDP)t + α6 GDP)t + d(t) + μt
   the NARDL approach is designed to capture (Shin et al., 2014).
                                                                                    Where αi coefficients represent the long-run asymmetric effects of pos­
    By employing these diagnostic tests, the study strengthens the con­             itive (+) and negative (− ) changes in economic policy uncertainty
fidence in the NARDL estimates by ensuring they are not plagued by                  (EPU), green technology (GT), and GDP on CO2. Positive and negative
common econometric issues that could distort the results.                           changes are computed as the squared sums of EPU and GT’s positive and
Step 6. Causality Analysis                                                          negative partial sums. d(t) denotes the deterministic term:
                                                                                                      (      )          (     )
    Building on the established literature (Kirikkaleli, 2023), the analysis                            2πkt             2πkt
acknowledges that the conventional Toda-Yamamoto causality test does                d(t) = ∂1 + θ1 sin         + θ2 cos                                 (3)
                                                                                                         T                T
not necessitate pre-testing for cointegration. To account for potential
structural breaks, the study employs the gradual shift causality (GSC)              where k denotes the frequencies used to approximate unknown struc­
procedure developed by Nazlioglu et al. (2016). This approach in­                   tural break numbers at unknown points, t is the trend, and T is the
corporates Gallant’s (1981) flexible Fourier specification to integrate             sample size. Frequencies are fractional to identify permanent breaks and
smooth structural shifts within the Toda-Yamamoto causality frame­                  integers for transitory breaks. The Akaike Information Criterion de­
work. The GSC test offers advantages.                                               termines the optimal lag length and k value. Building on prior research
                                                                                    (Omay, 2015), Yilanci et al. (2020) explored Equation (3) using a range
 • Accounting for structural breaks: The inclusion of Fourier terms in              of complexity levels (k = 0.1 to 5) to capture potential shifts in the re­
   the causality equation allows for the inclusion of potential structural          lationships over time. They identified the most suitable complexity level
   breaks.                                                                          by minimizing the overall error (sum of squared residuals). This
 • Avoiding limitations around unexpected regime changes: The                       approach aligns with the established understanding that integer values
   GSC test circumvents limitations associated with assuming unex­                  of k represent temporary changes, while fractional values indicate per­
   pected regime changes.                                                           manent breaks (. To assess the statistical significance of their findings,
                                                                                    Yilanci et al. (2020) employed a bootstrap simulation technique to
    To validate the GSC results, the analysis additionally utilizes the             determine critical t-statistic values.

                                                                               10
B. Bergougui et al.                                                                                              Journal of Environmental Management 360 (2024) 121172


4. Empirical results and their discussion                                               − 0.050288 for GDP2 exhibit negative skewness, indicative of left-
                                                                                        skewed distributions. Negative skewness implies a higher fre­
    Before analysis, testing for nonlinearity and investigating the time                quency of data points towards the upper end of the distribution,
series properties of the data is critical. This facilitates appropriate esti­           accompanied by occasional negative outliers that can exert a
mator selection and model specification to evaluate EPU and GT’s effects                downward pull on the mean. For GT and GDP,2 this pattern suggests
on environmental degradation in Algeria over the sample period.                         that these variables might have experienced periods of relatively
                                                                                        high values, punctuated by occasional significant negative shocks
4.1. Preliminary analysis                                                               that could influence the interpretation of their trends over time.
                                                                                        Furthermore, an examination of kurtosis statistics provides addi­
4.1.1. Descriptive statistics                                                           tional insights into the normality of the data distributions. Kurtosis
   An initial exploration of the Algerian data revealed evidence of non-                measures the peakedness of a distribution relative to a normal dis­
normality ( see Table 2 and Fig. 4).                                                    tribution. A normal distribution has a kurtosis of 3. Most variables
                                                                                        exhibit platykurtic distributions, with kurtosis values less than 3
 • The descriptive statistics revealed asymmetric distributions across                  (CO2, GT, GDP, GDP2). Platykurtic distributions have flatter tails
   the variables under investigation. Notably, the mean values consis­                  compared to a normal distribution, suggesting there may be fewer
   tently exceeded the median values for CO2 emissions, EPU, GT, GDP,                   outliers than expected under normality. The exception is EPU, which
   and GDP.2 This discrepancy between the mean and median, com­                         has a kurtosis value of 9.711094, indicating a leptokurtic distribution
   bined with the computed skewness statistics, confirmed the presence                  with fatter tails and potentially more extreme values compared to a
   of asymmetric distributions. Specifically, the skewness coefficients of              normal distribution.
   0.536866 for CO2 emissions, 2.307776 for EPU, and 0.152065 for                     • The Jarque-Bera test was conducted to assess if the data for each
   GDP indicate positive skewness, signifying as right-skewed distri­                   variable follows a normal distribution. The null hypothesis is that the
   butions. Positively skewed distributions are characterized by a con­                 data is normally distributed. A smaller p-value (typically less than
   centration of data points towards the lower end of the spectrum, with                0.05) indicates that the data is unlikely to be normally distributed.
   occasional positive outliers that can exert a significant influence on               The p-value for all variables is less than 0.05, which means we can
   the mean. In the context of this study, this pattern suggests that while             reject the null hypothesis and conclude that the data for these vari­
   the majority of observations for these variables lie within a lower                  ables is not normally distributed.
   range, there have been instances of substantial positive deviations
   from this trend, potentially impacting their historical trajectories.                 These combined findings (descriptive statistics and the Jarque-Bera
   Conversely, the skewness coefficients of − 0.173875 for GT and                    test) highlight the non-normality of the data series, necessitating the




                                                  Fig. 6. The normal quantile-quantile plot for all variables.

                                                                                11
B. Bergougui et al.                                                                                                                 Journal of Environmental Management 360 (2024) 121172


Table 3
Nonlinearity BDS test results.
  Variables                       Dimensions

                                  m=2                                  m=3                                 m=4                             m=5                                m=6

  CO2                             0.200259***                          0.338209***                         0.433543***                     0.499826***                        0.546418***
  EPU                             0.057265***                          0.117626***                         0.14501***                      0.149937***                        0.139216***
  GT                              0.186607***                          0.311278***                         0.39264***                      0.44395***                         0.474986***
  GDP                             0.205508***                          0.347751***                         0.446749***                     0.516296***                        0.565407***
  GDP2                            0.196977***                          0.332134***                         0.424507***                     0.486498***                        0.527987***

Notes: ***, **, and * represent statistical significance at the 1%, 5%, and 10% levels, respectively. These significant levels are determined by rejecting the null hy­
pothesis of linearity at the corresponding levels.



Table 4                                                                                               Table 5
Fourier-ADF and ADF unit root tests.                                                                  Fourier-NARDL bounds tests.
              Fourier ADF unit root test (Enders and Lee, 2012)                                        Fourier-NARDL bound test result

              Fourier ADF-stat       Frequency        Fourier ADF-stat            Frequency            Model                                             F-statistics                  K
                                                                                                       CO2 = f (EPU, GT, GDP, GDP2)                      6.154408***                   6
              At Level                                At First Difference
                                                                                                      Note: The critical values from Banerjee et al. (2017) are employed as the
  CO2         − 2.0134                        1       − 5.513***          1
  EPU         − 1.3594                        1       − 5.923***          3                           benchmark for determining statistical significance.
  GT          − 2.2814                        1       − 4.704***          3
  GDP         − 1.3344                        1       − 5.924***          5
  GDP2        − 1.4124                        5       − 4.083***          1                           Table 6
                                                                                                      Fourier-NARDL long-run results.
  Fourier ADF Test Critical Values
                                                                                                       Dependent variable = CO2
  Frequency                      1%                      5%                             10%
  1                              − 4.42                  − 3.81                         − 3.49         Variables         Coefficient          Std. Error        t-Statistic        Prob.
  3                              − 3.77                  − 3.07                         − 2.71         CO2 t-1           − 0.448209***        0.100572          − 4.456584         0.0001
  5                              − 3.58                  − 2.93                         − 2.60         EPU positive      − 0.032616***        0.011495          − 2.837284         0.0067
                                                                                                           t -1
                                                                                                            negative
                                                                                                       EPUt-1            0.017477             0.013259          1.318140           0.1938
  ADF unit root test
                                                                                                       GT positive       − 0.012366**         0.005625          − 2.198484         0.0329
                                                                                                          t -1
                  At Level                                        At First Difference                     negative
                                                                                                       GT t-1            0.004361             0.009865          0.442080           0.6605
                  t-Statistic        Prob.          t-Statistic                         Prob.
  CO2             0.8352             0.8904         − 2.6266***                         0.0088         GDP               0.822003***          0.158057          5.200672           0.0000
  EPU             0.0276             0.6902         − 22.2967***                        0.0000         GDP2              − 0.280948***        0.070827          − 3.966694         0.0002
  GT              0.1982             0.7426         − 3.7436***                         0.0002        Notes: *, **, and *** denote statistically significant at the 10%, 5%, and 1%
  GDP             1.4037             0.9598         − 1.6856*                           0.0869
                                                                                                      levels, respectively.
  GDP2            0.4006             0.798          − 2.2128**                          0.0264

Note: *, **, and *** denote 10%, 5%, and 1% significance levels, respectively.                        EPU, GT, GDP, and GDP.2 In summary, the significant BDS test statistics
                                                                                                      justify the use of nonlinear models to examine the long-run associations
application of appropriate econometric techniques suitable for non-                                   between the variables under examination.
normal error distributions. This aligns with the chosen methodology
employed in this study.                                                                               4.1.3. Unit root test
    To further investigate normality visually, Quantile-Quantile (Q-Q)                                    Unit root tests are conducted in this study applying both the Fourier-
plots were constructed. Ideally, a normally distributed data series would                             ADF and ADF techniques, with the results presented in Table 4. The
yield a Q-Q plot closely resembling a straight diagonal line. However, as                             findings from these unit root tests demonstrate that the time series
illustrated in Fig. 6, the observed data points exhibited a significant                               variables CO2, EPU, GT, GDP, and GDP2 are integrated of order I(1).
departure from this linearity, suggesting a non-normal distribution for                               Given the I(1) order of integration evidenced in the time series data,
both the dependent variable (CO2 emissions) and the independent                                       implementation of Fourier-NARDL models becomes plausible within this
variables.                                                                                            analysis.
    Given the established non-normality of the data, the traditional
ARDL model might not be the most suitable choice for this analysis. The
                                                                                                      4.2. Fourier-NARDL bounds test
ARDL model’s estimation process can be sensitive to deviations from
normality, potentially leading to biased results. To address this limita­
                                                                                                          To investigate the presence of a long-run relationship between the
tion and capture potential nonlinear relationships within the data, the
                                                                                                      model variables, this study employs the Fourier-NARDL cointegration
Fourier NARDL approach is adopted. The Fourier NARDL framework is
                                                                                                      test. As depicted in Table 5, statistically significant evidence emerges at
specifically designed to accommodate non-normal error distributions
                                                                                                      the 99% confidence level to reject the null hypothesis of no long-run
and model nonlinear relationships, making it a more appropriate choice
                                                                                                      cointegration amongst the variables, based on the F-statistics
for this study.
                                                                                                      exceeding critical thresholds. This denotes the existence of a long-run
                                                                                                      linkage between CO2, EPU, GT, GDP, and GDP2 for the case of Algeria.
4.1.2. Nonlinearity test
    The BDS statistics presented in Table 3 show that for all variables in
the study in various dimensions, the null hypothesis of the BDS test was                              4.3. Fourier-NARDL outcomes
rejected, confirming the presence of nonlinearity in the series. Relying
solely on linear models therefore risks engendering biased estimations.                                   Once the nonlinear cointegration among the variables has been
Identifying these nonlinear properties substantiates the application of                               established, the subsequent task involves estimating the coefficient es­
nonlinear techniques to analyze the long-run equilibria between CO2,                                  timates for the long-run relationship. This estimation process will enable

                                                                                                 12
B. Bergougui et al.                                                                                                    Journal of Environmental Management 360 (2024) 121172


the analysis of the effects of both positive and negative shocks in EPU            packaging, transportation, usage, and recycling. Specifically, in­
and GT on EF.                                                                      novations in green technology can enhance the efficiency of natural
    The long-run asymmetric impacts reported in Table 6 demonstrate                resource utilization, optimize energy ratios, and continually refine fuel
that positive shocks in EPU mitigate emissions rather than intensify               decarbonization processes to maximize carbon emission reductions
them; specifically, a 1% positive EPU shock decreases emissions by                 across all energy types required for production. Green technology, vital
0.0326%. The theoretical background for this finding was already pre­              in the fight against climate change, is driving the ongoing scientific,
sented by Wang et al. (2020). The authors explain that economic policy             technological, and industrial revolutions, ushering human society into a
uncertainty affects CO2 emissions through two main channels: invest­               new era of low-carbon and environmentally sustainable growth (Liu
ment and consumption. On the one hand, as noted by Baker et al. (2016),            et al., 2024).
EPU adversely impacts the overall economy, making it more challenging                  Furthermore, the study’s results supported the existence of the
to recover from recessions. According to Jiang et al. (2019), EPU indi­            Environmental Kuznets Curve (EKC) hypothesis in the Algerian context.
rectly affects CO2 emissions through its impact on economic demand.                Economic growth, measured by GDP, exhibited a positive association
The economic slump caused by EPU alters the demand for energy use,                 with emissions, while the quadratic term for GDP displayed a negative
subsequently influencing CO2 emissions. On the contrary, higher levels             relationship. These findings lend support to the existence of the EKC in
of Economic Policy Uncertainty (EPU) can lead to delays in investments             the Algerian context and are partially consistent with the work of (Amri,
in renewable and green energy, resulting in increased CO2 emissions—a              2017), who found evidence for the EKC hypothesis in Algeria. However,
phenomenon known as the investment effect. Several studies examine                 the results contradict the recent study by (Elbadri et al., 2023) which did
the concept that uncertainty surrounding economic policies reduces                 not uncover an EKC for Algeria.
corporate investment (Chen et al., 2019; Dibiasi et al., 2018; Liu and
Zhang, 2020). According to real options theory, corporate investment
                                                                                   4.4. Diagnostic tests
projects are often irreversible and expensive; hence, economic policy
uncertainty elevates the value of waiting options, prompting firms to
                                                                                       The diagnostic tests for the Fourier-NARDL model presented in
adopt a more cautious approach and postpone investments until they
                                                                                   Table 7 demonstrate that the model is stable and correctly specified. The
have additional information to navigate the heightened uncertainty
                                                                                   Wald test revealed statistically significant asymmetry at the 1% level,
(Bernanke, 1983; ). Furthermore, signal theory suggests that increasing
                                                                                   indicating that positive and negative shocks among the regressors
the disclosure of carbon information may effectively encourage energy
                                                                                   asymmetrically influence CO2 emissions. This supports the rejection of
conservation       and     lower    emission     levels   (.    Using     a
                                                                                   the null hypothesis of no asymmetry. The Breusch-Godfrey LM test
difference-in-difference (DID) estimate, Pan et al. (2020) discovered that
                                                                                   statistic of 1.326930 with a p-value of 0.2755 failed to reject the null
policy uncertainty has a more pronounced inhibiting effect on corporate
                                                                                   hypothesis of no serial correlation, suggesting the model is free from
environmental information disclosure. When EPU is high, companies are
                                                                                   autocorrelation. Similarly, the Breusch-Pagan test yielded a chi-square
more inclined to reduce the transparency of carbon information sharing.
                                                                                   statistic of 38.84443 and p-value of 0.4775, failing to reject the null
Consequently, a decrease in carbon disclosure due to EPU could lead to
                                                                                   hypothesis of homoscedasticity and demonstrating an absence of het­
an increase in carbon emissions.
                                                                                   eroscedasticity among the variables. Finally, the Ramsey RESET test
    The finding above potentially relates to EPU negatively affecting
                                                                                   produced an F-statistic of 0.277444 with a p-value of 0.6009, confirming
economic conditions and dampening overall business activities, thereby
                                                                                   the appropriate model specification by failing to reject the null hy­
reducing energy utilization and CO2 emissions. Similar EPU effects were
                                                                                   pothesis of correct functional form. The CUSUM and CUSUMSQ tests
noted by Ahmed et al. (2021), where high EPU periods corresponded
                                                                                   evaluate model stability over time; CUSUM plots the cumulative sum of
with reduced vehicle miles traveled in the US. Interestingly, the impact
                                                                                   recursive residuals and CUSUMSQ charts the cumulative sum of squared
of negative EPU shock (decreases in uncertainty) is positive but statis­
                                                                                   recursive residuals. Plots within the 5% critical bounds denote stability.
tically insignificant. This suggests that the emission-dampening effect of
                                                                                   As depicted in Figs. 7 and 8, the CUSUM and CUSUMSQ plots reside
EPU is more pronounced during periods of rising uncertainty. This
                                                                                   within the critical bands, validating model stability. The long-run co­
intricate and novel finding is solely discernible through the application
                                                                                   efficients for EPU and GT exhibit marked differences between negative
of nonlinear techniques. It aligns with the findings of several prior
                                                                                   and positive changes, denoting a significant asymmetric impact on
studies, including those by Anser et al. (2021a,b), Ayhan et al. (2023),
                                                                                   pollutant emissions. However, to formally validate the statistical
and Liu and Zhang (2022), which collectively support the notion that
positive EPU shocks contribute to environmental quality improvements.
    Regarding GT, the study uncovered an asymmetric relationship be­               Table 7
tween GT and emissions. Positive shocks to GT resulted in a 0.0124%                Diagnostic test outcomes.
reduction in pollution levels in the long run. Conversely, negative shocks          Test description                      Test Statistics        Decision
in GT had no significant impact on pollution levels in Algeria. This im­                                                  (Prob-value)

plies that the response of CO2 emissions varies depending on whether                R2                                    0.895583               Model denotes a solid fit
GT increases or decreases, with positive changes in GT exhibiting a more            Serial Correlation LM test (χ 2)      1.326930               Absence of autocorrelation.
                                                                                                                          (0.2755)
pronounced effect on pollution mitigation compared to negative
                                                                                    Heteroskedasticity test (χ 2)         38.84443               Absence of Heteroscedasticity.
changes. These results align with prior studies on BRICS nations by                                                       (0.4775)
Chishti and Sinha (2022) and investigations specific to India by Rej et al.         Ramsey RESET test (F)                 0.277444               The specification is consistent.
(2023). This finding is in line with the new economic geography theory                                                    (0.6009)
stipulating that scientific and technical innovation is fundamental to              CUSUM                                 –                      Stability Verified (see Fig. 7)
                                                                                    CUSUM sq                                                     Stability Verified (see Fig. 8)
driving industrial green development. Such innovation plays a crucial
                                                                                                                          –

role in enhancing industrial structure and resource productivity (Huang             Wald test results for long-run asymmetries
et al., 2018). Specifically, innovation in green technologies can lead to a         Variable     F-statistic        Probability       Decision
reduction in carbon emissions through both direct (by using technolo­               EPU          24.16954***        0.0000            CO2 emissions are significantly and
gies capable of capturing and storing carbon emissions) and indirect (by                                                              asymmetrically affected by EPU
using friendly green technologies aiming at reducing carbon emissions)              GI           2.980196*          0.0909            CO2 emissions are significantly and
methods (Liu et al., 2024). For instance, in the domain of green tech­                                                                asymmetrically affected by GT
nology, energy conservation and emission reduction are achieved across             Notes: *, **, and *** denote statistically significant at the 10%, 5%, and 1%
the entire product life cycle, encompassing design, manufacturing,                 levels, respectively.

                                                                              13
B. Bergougui et al.                                                                                                 Journal of Environmental Management 360 (2024) 121172




                                                  Fig. 7. Cumulative sum of recursive residuals (CUSUM).




                                             Fig. 8. Cumulative sum of squared recursive residuals (CUSUMSQ).


significance of this asymmetric long-run effect from EPU and GT, a Wald
                                                                                   Table 8
test is conducted. The Wald test results presented in Table 7 confirm that
                                                                                   Symmetric and asymmetric causality tests.
both EPU and GT wield a statistically significant asymmetric influence
over emissions.                                                                     Panel A: Fourier symmetric gradual shift causality test (Nazlioglu et al., 2016)

                                                                                    Direction of causality   K             p              F-stat            Bootstrap p-value
                                                                                    EPU ⇒ CO2                4.000000      2.000000       13.93011***       0.007521
4.5. Symmetric and asymmetric causality                                             GT ⇒ CO2                 5.000000      2.000000       9.309102*         0.097352
                                                                                    GDP ⇏ CO2                7.000000      2.000000       17.40057**        0.014988
    A growing body of scholarship has utilized the symmetric gradual                Panel B: Fourier Asymmetric causality test (Hatemi-j, 2012)
shift causality (GSC) framework developed by (Nazlioglu et al., 2016)
                                                                                    Direction of        Wald test       Bootstrap CV        Bootstrap CV       Bootstrap CV
and the asymmetric causality techniques proposed by (Hatemi-j, 2012)
                                                                                    causality                           10%                 5%                 1%
to investigate environmental phenomena (Kirikkaleli, 2023; Mighri and
AlSaggaf, 2023). The current study’s Panel A presents the GSC analysis,             EPU + ⇏ CO+ 2       12.8719**       26.1319             9.3929             5.0109
                                                                                    EPU-⇒ CO−2          11.7139***      2.8109              4.1889             10.7709
demonstrating that EPU, GT, and GDP Granger cause carbon emissions                  GT+ ⇒ CO+           77.9269***      52.3519             17.4129            11.2639
                                                                                              2
in Algeria over time, underlining their critical role in driving ecological         GT-⇏ CO−2           0.4679          11.5079             7.5469             5.4029
degradation. Moreover, The asymmetric causality test findings confirm               GDP + ⇏ CO+ 2       10.6909**       2.8599              4.3639             14.3869
the GSC results. Taken together, both symmetric and asymmetric causal               GDP-⇏ CO−2          1.5429          2.9539              4.1059             7.2509
investigations underscore the impactful causal effects of EPU, GT, and             Note: The symbols ⇒ and ⇏ indicate one-way causality or no causality between
GDP on Algerian CO2 emissions over time.                                           the variables, respectively. Initial maximum lags k and p were set to 5 and 12
                                                                                   before the optimal lags were selected using the AIC. Bootstrap p-values were
                                                                                   calculated based on 1000 resamples. The optimal lag was chosen using the
4.6. Sensitive analysis
                                                                                   Hatemi-J Criterion (HJC).

    This section assesses the robustness of the core findings presented in

                                                                              14
B. Bergougui et al.                                                                                                  Journal of Environmental Management 360 (2024) 121172


Table 6 by employing a series of sensitivity analyses detailed in Table 8.              levels in Algeria. This observation aligns with the recommendations
The study explores the influence of methodological choices by utilizing                 outlined in the Report on Climate Change, which advocates for radical
alternative estimation techniques (FMOLS, DOLS, and CCR). Addition­                     transformations across various societal domains, such as transitioning
ally, the impact of the dependent variable is examined by employing a                   towards low-carbon technologies like renewable energy sources. To
substitute measure. Furthermore, the sensitivity of the results to the                  extra illumine this phenomenon, The study explores two plausible ex­
inclusion of control variables is evaluated by dropping all control vari­               planations for the observed decline in CO2 emissions associated with the
ables from the model. To ensure ease of comparison, the baseline results                increase in GT adoption in Algeria: (1) innovative technologies that
from Table 6 are replicated in the first column of Table 8.                             improve energy efficiency, thereby reducing direct emissions from fossil
    To assess endogeneity and serial correlation concerns, alternative                  fuel combustion and indirect emissions from electricity generation, as
estimation techniques – FMOLS, DOLS, and CCR – are employed                             noted by (Jordaan et al., 2017; Wang and Zhu, 2020); (2) development
(Table 9, Columns 2–4). These methods yield directionally consistent                    of environmentally-friendly goods and services or carbon capture and
and statistically significant results, with few exceptions such as EPU                  storage technologies, identified as effective climate change mitigation
becoming significance under CCR.                                                        strategies by Shu et al. (2023) and Wilberforce et al. (2021). In sum­
    To explore the dependence of the findings on the dependent variable,                mary, the GT-CO2 emissions relationship demonstrates asymmetry and
the natural log of total CO2 emissions is utilized as a substitute (Table 9,            depends on multiple factors. However, GT influences CO2 emissions,
Column 5). While the coefficient magnitudes remain largely unchanged,                   with both positive and negative repercussions. These results confirm
a previously insignificant positive effect of negative shocks in EPU on                 prior studies on the potential for GT to lower emissions, notably Chen
emissions becomes significant.                                                          and Lee (2020) who found GT in countries with high income, advanced
    Finally, the sensitivity of the results to control variables is evaluated           technology, and high emissions can substantially reduce CO2. Similar
by omitting them entirely from the model (Table 9, Column 6). The                       conclusions were reached in other studies by Razzaq et al. (2023), She
impact of EPU and GT on emissions remains consistent with the baseline,                 and Mabrouk (2023), Amin et al. (2023), Adebayo et al. (2022), and
further bolstering the robustness of the core findings.                                 Chen and Lee (2020). Nevertheless, other research has suggested GT
                                                                                        increases emissions, including Zhang et al. (2017), Adebayo et al.
                                                                                        (2022), and Rahman et al. (2022), indicating discrepancies likely due to
4.7. Discussion                                                                         differing methodologies. Overall, these findings underscore the critical
                                                                                        role of policymakers in Algeria to closely monitor GT, anticipate
    This section engages in a comprehensive analysis of the research                    changes, and devise appropriate strategies to address significant shifts,
findings. It critically examines the results in light of the initially stated           whether positive or negative. Policymakers should also incentivize
research objectives. Additionally, it provides theoretical and/or empir­                Algerian firms to invest in research and development and adopt envi­
ical support to elucidate the significance of these findings.                           ronmentally sustainable technologies.
    Firstly, the empirical analysis revealed that a positive shock in EPU                   Thirdly, the emergence of an EKC is plausible given Algeria’s
leads to decreased emission levels, whereas a negative shock does not                   continued dependence on conventional energy sources, with renewables
have any impact. Several factors can account for this decrease in CO2                   comprising just 1% of total energy consumption (Bergougui, 2024)(, .
emissions in resource-abundant economies such as Algeria: (i) As a                      Algeria’s GDP per capita has experienced impressive growth of
major exporter of oil and gas, Algeria’s economy relies heavily on fossil               approximately 7% since 2010. Economic expansion is contingent on
fuels. During times of uncertainty around economic policies, Algeria can                energy consumption, and Algeria is the third largest energy consumer in
experience reduced demand and lower prices for its oil and gas exports                  Africa; hence, the positive association between GDP and emissions levels
(Ayad et al., 2023). This decreases Algeria’s revenue and economic                      is understandable. The negative coefficient on GDP squared can be
production. It also causes Algeria’s domestic energy use and carbon                     attributed to Algeria’s burgeoning efforts towards an energy transition
dioxide emissions to decline. (ii) High uncertainty dampens economic                    by ramping up investments in green energy, gradually facilitating a shift
activity like investments, tourism, and growth (Akadiri et al., 2020;                   towards renewable energy uptake (Bergougui and Aldawsari, 2024).
Anser et al., 2021a,b), thereby directly reducing energy consumption                    The impetus to curb fossil fuel utilization is evidenced by the near
and emissions (Danish et al., 2019). (iii) uncertainty disrupts                         doubling of non-hydroelectric renewables and biofuels over 2000–2020,
decision-making among economic agents in ways that further decrease                     predominantly driven by national and subnational government in­
emissions, like promoting consumption over investment (Adedoyin and                     centives (EIA, 2020). The negative relationship indicates these en­
Zakari, 2020). The uncertainties make planning and long-term decisions                  deavors will eventually bear fruit, and higher economic growth will
more difficult, indirectly depressing emissions. In summary, the com­                   mitigate emissions, despite the currently high elasticity of the linear
plex asymmetric EPU effects underscore the necessity of nonlinear                       GDP term. This perspective abatement of environmental degradation
modeling.                                                                               also corroborates the notion that ecological damage alleviates at
    Secondly, the study’s findings provide compelling evidence that an                  advanced income levels due to innovation, clean technology adoption,
increase in GT adoption leads to a significant reduction in pollution

Table 9
Sensitivity analysis results.
  Variables           Baseline results   Alternative estimation methods                          Substitution of the dependent variable    Dropping all control variables

                                         FMOLS               DOLS            CCR

                      (1)                (2)                 (3)             (4)                 (5)                                       (6)

  EPU positive        − 0.032616***      0.074984**          0.072606**      0.075026***         − 0.016204***                             − 0.01266**
       t-1
  EPUtnegative        0.017477           0.059942            0.059018        0.061216*           0.003724*                                 − 0.01383
       -1
  GT positive         − 0.012366**       − 0.03808***        − 0.04214***    − 0.03801***        − 0.019223**                              − 0.00283***
     t-1
     negative
  GT t-1              0.004361           0.029737*           0.020881*       0.031119            0.030914                                  0.009691*
  GDP                 0.822003***        0.498978***         0.474092***     0.514319**          0.476634***                               /
  GDP2                − 0.280948***      − 0.072707***       − 0.101234***   − 0.065696***       − 0.156485***                             /

Note: The symbols *, **, and *** show the significance levels of 10%, 5%, and 1%, respectively. FMOLS stands for fully modified ordinary least squares; DOLS stands
for dynamic ordinary least squares; CCR stands for canonical cointegrating regression.

                                                                                   15
B. Bergougui et al.                                                                                           Journal of Environmental Management 360 (2024) 121172


societal demands for sustainability, pro-environment legislation, and the          5.2. Policy implications
transition to renewables. Thus, Algeria’s development trajectory ap­
pears aligned towards achieving green objectives.                                      Based on the findings of the paper, we can therefore present the key
                                                                                   policy implications for Algeria:
5. Conclusion and policy implications                                                  Firstly, this study revealed that a positive shock to EPU has a bene­
                                                                                   ficial effect on reducing emissions. Therefore, the government should
5.1. Conclusion                                                                    strive to optimize the positive outcomes of uncertainty and mitigate the
                                                                                   negative consequences of uncertainty. Positive shocks to EPU that result
    This study contributes to the under-explored area of research                  in a decrease in CO2 emissions have the potential to have positive policy
examining the asymmetric relationships between Economic Policy Un­                 implications for the environment. It can stem from greater government
certainty (EPU), Green Technology (GT), and CO2 emissions within the               support for environmental efforts or the passage of clean energy-friendly
Algerian context (Q1/1980 - Q4/2022). Bridging this gap, the research              regulations. This positive correlation between shocks to EPU and
investigates the influence of EPU and GT on Algeria’s CO2 emissions,               reduced CO2 emissions underscores the importance of proactive policy
controlling for the effect of economic growth (GDP). The analysis em­              actions in addressing environmental challenges. Governments can pro­
ploys a novel methodological approach: the Fourier Non-linear Autor­               mote a transition to a greener economy and combat climate change by
egressive Distributed Lag (NARDL) model coupled with bootstrap                     implementing policies that incentivize clean energy adoption, promote
asymmetric causality techniques. This framework offers a distinct                  sustainable practices, and prioritize environmental conservation, which
advantage by capturing non-linear and asymmetric effects between the               propels towards a more sustainable future. Hypothetically, A sudden
variables, which might be missed by traditional linear models. This is             surge in the level of EPU should not compromise the government’s
particularly relevant considering the potential for unforeseen events to           credibility. In the current context, the global economy is still suffering
disrupt the stability of these relationships. Additionally, the study in­          from the impact of COVID-19. The government should ensure economic
corporates sensitivity analyses (alternative estimation methods, substi­           stability and alleviate the negative effects of uncertainty in such a
tute dependent variable, and control variable exclusion) to validate the           challenging international economic scenario. The government’s
robustness of the core findings. The Fourier NARDL bound test confirms             commitment to environmental preservation and emission reduction
the existence of long-run equilibrium relationships between EPU, GT,               should remain firm even under high levels of uncertainty. Appropriate
GDP, and CO2 emissions in Algeria.                                                 supportive actions should be taken to lower uncertainty and preserve the
    The empirical analysis yielded three key values that shed light on the         consistency and clarity of policies. Following the 2014 oil price crash,
relationship between GT, EPU, GDP, and CO2 emissions in Algeria.                   Algeria could have directed stimulus funds towards solar panel in­
                                                                                   stallations for businesses and households, promoting energy indepen­
   (i). Positive shocks to EPU, signifying periods of reduced uncertainty,         dence and emissions reduction. Algeria’s heavy reliance on oil and gas
        lead to a decrease in CO2 emissions. This suggests that a more             exports makes it vulnerable to fluctuations in global energy prices.
        stable economic policy environment fosters investments in                  Promoting diversification into other sectors like tourism, agriculture,
        cleaner technologies and emission reduction strategies, poten­             and manufacturing can lessen the impact of EPU on the overall
        tially leading to long-term reductions in CO2 emissions. Inter­            economy.
        estingly, negative EPU shocks, representing periods of heightened              Second, despite the limited impact of current green technologies on
        uncertainty, do not exert a statistically significant impact on CO2        CO2 emission reduction in Algeria, a significant portion of the national
        emissions.                                                                 budget should be allocated towards research and development (R&D) in
  (ii). Positive shocks to GT, indicating periods of increased investment          renewable energy technologies, with a focus on areas such as energy
        in green technologies, are associated with a decrease in CO2               efficiency, energy storage, cross-cutting technologies, and nuclear and
        emissions. This reinforces the notion that green technology plays          renewable energy utilization. Dedicated research centers or institutes
        a crucial role in curbing emissions. Negative shocks to GT,                should be established to facilitate collaboration between academia, in­
        signifying periods of decreased investment, do not have a statis­          dustry, and government in developing innovative green technologies.
        tically significant effect on emissions. This suggests that CO2            Indeed, the promotion of new green technologies is an effective way to
        emissions might be more responsive to advancements and up­                 prevent environmental damage and reduce carbon emissions. However,
        swings in green technology adoption rather than downturns.                 government intervention through environmental legislation is necessary
 (iii). The findings provide empirical support for the existence of an             to ensure the effectiveness of green technologies in reducing CO2
        EKC in Algeria. This EKC hypothesis suggests that CO2 emissions            emissions. In this regard, the two types of environmental regulations
        might increase with initial economic growth (GDP) but eventu­              that have been most successful in establishing the link between green
        ally decline as economies mature and prioritize environmental              innovation and emissions reduction are investment-based regulations
        sustainability.                                                            (IER) and command-and-control-based regulations (CER) and Algeria
                                                                                   established a combination of command-and-control-based regulations
    Causality tests, employing both symmetric and asymmetric frame­                and market-incentive regulations. Additionally, funding opportunities
works, reveal that EPU, GT, and GDP all Granger-cause CO2 emissions in             and incentives should be provided to universities, research institutions,
Algeria. This implies that past values of these variables can statistically        and private companies to undertake cutting-edge research in green
predict future CO2 emissions. The core results demonstrate resilience              technologies in general and renewable energy and related fields in
when subjected to a battery of sensitivity tests. These tests employ               particular. Moreover, the implementation of green taxes and policy in­
alternative estimation methods and model specifications, strengthening             struments is crucial. This can include introducing carbon pricing
the confidence in the study’s findings.                                            mechanisms, such as carbon taxes or cap-and-trade systems, to incen­
    This study aligns with the growing body of empirical research sug­             tivize the adoption of cleaner technologies and discourage the use of
gesting that the variables under investigation may exhibit differential            fossil fuels. Tax credits or rebates can be offered to businesses and
responses to positive and negative economic or technological shocks.               households that invest in renewable energy systems or energy-efficient
Neglecting the inherent non-linear nature of these disturbances can lead           appliances. Furthermore, feed-in tariffs or other financial incentives
to misleading inferences. By leveraging these insights, Algeria can                can be implemented to encourage the deployment of renewable energy
establish a robust foundation for its environmental policy framework.              projects, such as solar and wind farms. Also, the government should
                                                                                   enhance R&D incentives for the renewable energy sector by providing
                                                                                   subsidies or tax benefits for companies engaged in renewable energy

                                                                              16
B. Bergougui et al.                                                                                             Journal of Environmental Management 360 (2024) 121172


research, development, and manufacturing. Grants or low-interest loans             boosted by ECI. Without a doubt, R&D significantly boosts the inven­
can be offered to support the commercialization and scaling of prom­               tiveness, efficiency, and competitiveness of industries and enterprises,
ising green technologies. Additionally, public-private partnerships can            which is linked to fundamental changes in economies and promotes
be facilitated to foster collaboration between the government, research            sustainable growth. R&D activities lower the cost of both generating and
institutions, and the private sector in developing and deploying green             consuming clean energy while also advancing technology, promoting
technologies.                                                                      economic growth, and encouraging the usage of clean energy in nations
    Overall, these policy recommendations highlight the need for a                 (Can and Gozgor, 2017). Therefore, if funding is required for in­
multifaceted approach that leverages economic policy uncertainty,                  vestments in green energy for sustainable energy development, ECI
strategic R&D investments, and targeted incentives to promote green                cradles environmentally friendly innovations and goods and improves
technology adoption and mitigate environmental pollution in Algeria.               the quality of the environment (Mealy and Teytelboym, 2022; Pata,
                                                                                   2021; Samour et al., 2022). Rafei et al. (2022) add that improving the
5.3. Limitations and future research                                               institutional quality of a country yields a positive critical effect on
                                                                                   environmental quality. The literature has already established a strong
    While this research sheds light on the crucial role of green technol­          relationship between institutional quality and human development
ogy and the impact of economic policies on reducing CO2 emissions in               (Ouedraogo et al., 2022).In turn, Balsalobre-Lorente et al. (2024a)
Algeria, it also faces certain limitations. These constraints pave the way         demonstrate that both of them help enhance the understanding of sus­
for potential directions in future studies. The study’s limitations include        tainable development and support that with some interesting results
a brief data timeframe, reliance on a single control variable, and a               indicating a significant and negative relationship between human
narrow focus solely on Algeria. To address these limitations, future               development index (HDI) and ecological footprint with a confirmed
research should consider.                                                          one-way causal relationship. Another angle of the analysis that was dealt
                                                                                   with by Jiang et al. (2022) deserves to be considered in future scientific
 • Extending the timeframes: investigating longer periods to capture               production for the case of Algeria. In this contribution, the authors
   more comprehensive trends.                                                      examine China’s power and heating industry’s structural emission
 • Incorporating relevant control variables: including additional                  reduction from 2007 to 2015 using the structural decomposition
   relevant factors to enhance the analysis.                                       method, input-output method extended form, and energy utilization
 • Cross-country analyses: examining emissions reduction strategies                methodology. Their results highlighted that energy composition, in­
   across multiple countries.                                                      tensity, and input all had a significant role in minimizing CO2 in China’s
 • Disaggregated impacts of green innovation: assessing the effects                power and heating sector and that the growth in CO2 emissions is
   of different types of green innovation separately.                              related to electricity and heating energy.
 • Evaluating various uncertainties: considering commercial, finan­                 List of acronyms
   cial, healthcare, geopolitical, and tax-related uncertainties and their          ADF           Augmented Dickey-Fuller
   impact on emissions.                                                             AIC           Akaike Information Criterion
 • Exploring other nonlinear techniques: techniques like quantile                   ARDL          Autoregressive Distributed Lag
   regression (which assesses variable impact across different quantiles            BDS           Brock, Dechert, and Scheinkman
                                                                                    CO2           Carbon dioxide emissions
   of the CO2 emissions distribution) and threshold models (which                   CO+           Positive Shocks (Carbon dioxide emissions)
                                                                                       2
   identify regime shifts) could provide valuable insights into the                 CO−2          Negative Shocks (Carbon dioxide emissions)
   complex relationships between uncertainties, fiscal policies, green              CS-ARDL       Cross-Sectionally Augmented Autoregressive Distributed Lag
   energy investments, and environmental outcomes over time and in                  CUSUM         Cumulative Sum for Recursive Residuals
                                                                                    CUSUMSQ       Cumulative Sum of Squared for Recursive Residuals
   diverse contexts.
                                                                                    ECI           Economic Complexity Index
                                                                                    EIA           U.S. Energy Information Administration
    From the previous, it should be pointed out the necessity of taking             EIU           Economist Intelligence Unit
into consideration the connectedness of all these research tracks (Lor­             EKC           Environmental Kuznets Curve
ente et al., 2023). For instance, including geopolitical risk as a control          EPC           Environmental Phillips Curve
                                                                                    EPU           Economic Policy Uncertainty
variable could help to review the design of the model and bring more                EPU +         Positive Shocks (Economic Policy Uncertainty)
clarity and precision in defining the spillover map of the different var­           EPU -         Negative Shocks (Economic Policy Uncertainty)
iables responsible for CO2 emissions in Algeria. The introduction of the            FDI           Foreign Direct Investment
geopolitical risk variable into the model requires an extra effort to               FMOLS         Fully Modified Ordinary Least Squares
                                                                                    GCC           Gulf Cooperation Countries
construct this variable for Algeria, which represents a promising
                                                                                    GDP           Gross Domestic Product
research advance in understanding the factors affecting the environment             GT            Green Technology
in Algeria. In addition to what has just been evoked, Rafei et al. (2022)           GT+           Positive Shocks (Green Technology)
highlight the importance of not ignoring the effect of economic                     GT -          Negative Shocks Green Technology
complexity on environmental degradation, given the fact that this var­              HDI           Human Development Index
                                                                                    IAEA          International Atomic Energy Agency
iable represents a measure that is closely linked to national economies
                                                                                    ICT           Information Communication Technologies
since it examines the relationship between a nation’s exports and the               IEA           International Energy Agency
export structure. According to international trade literature, the Eco­             LM            Lagrange Multiplier
nomic Complexity Index (ECI) is defined as the degree of manufacturing              MENA          Middle East and North Africa
                                                                                    NAFTA         North American Free Trade Agreement
process expertise and productivity. ECI concentrates on exporting
                                                                                    NARDL         Nonlinear Autoregressive Distributed Lag
knowledge- and technology-intensive items (Buhari et al., 2020; Doğan              QVAR          Quantile Vector Autoregressive
et al., 2021; Pata, 2021). As a result, varying ECI scores reflect the              R&D           Research and Development
complexity and diversity of different nations and have two potential                RE            Renewable Energy
effects on environmental quality: (1) Reducing reliance on fossil fuels             REPN          Renewable Energy Policy Network
                                                                                    RESET         Regression Equation Specification Error Test
can help achieve sustainable development, but increasing a nation’s
                                                                                    STIRPAT       Stochastic Impacts by Regression on Population, Affluence, and
output and manufacturing also calls for the extraction, exploitation, and                         Technology
use of natural resources and energy (Abumunshar et al., 2020). It has               WBG           World Bank Group
negative effects on the ecosystem and environmental contamination as a              WC            Wavelet Coherence
                                                                                    WUI           World Uncertainty Index
result. However, Research and development (R&D) efforts may also be

                                                                              17
B. Bergougui et al.                                                                                                               Journal of Environmental Management 360 (2024) 121172

                                                                                                      evidence from load capacity curve hypothesis for 10 European Union countries.
                                                                                                      Sustain Dev n/a. https://doi.org/10.1002/sd.2794.
                                                                                                 Ayhan, F., Kartal, M.T., Kılıç Depren, S., Depren, Ö., 2023. Asymmetric effect of
                                                                                                      economic policy uncertainty, political stability, energy consumption, and economic
CRediT authorship contribution statement                                                              growth on CO2 emissions: evidence from G-7 countries. Environ. Sci. Pollut. Control
                                                                                                      Ser. 30 (16), 47422–47437. https://doi.org/10.1007/s11356-023-25665-7.
                                                                                                 Baker, S.R., Bloom, N., Davis, S.J., 2016. Measuring economic policy uncertainty. Q. J.
   Brahim Bergougui: Writing – review & editing, Writing – original                                   Econ. 131 (4), 1593–1636. https://doi.org/10.1093/qje/qjw024.
draft, Visualization, Validation, Supervision, Software, Resources,                              Balsalobre-Lorente, D., Nur, T., Topaloglu, E.E., Evcimen, C., 2024a. Assessing the
                                                                                                      impact of the economic complexity on the ecological footprint in G7 countries: fresh
Project administration, Methodology, Investigation, Formal analysis,                                  evidence under human development and energy innovation processes. Gondwana
Data curation, Conceptualization. Samer Mehibel: Writing – review &                                   Res. 127, 226–245. https://doi.org/10.1016/J.GR.2023.03.017.
editing, Writing – original draft, Investigation, Formal analysis,                               Balsalobre-Lorente, D., Nur, T., Topaloglu, E.E., Evcimen, C., 2024b. The dampening
                                                                                                      effect of geopolitical risk and economic policy uncertainty in the linkage between
Conceptualization. Reda Hamza Boudjana: Visualization, Validation.
                                                                                                      economic complexity and environmental degradation in the G-20. J. Environ.
                                                                                                      Manag. 351, 119679 https://doi.org/10.1016/J.JENVMAN.2023.119679.
Declaration of competing interest                                                                Bekhet, H.A., Matar, A., Yasmin, T., 2017. CO2 emissions, energy consumption,
                                                                                                      economic growth, and financial development in GCC countries: dynamic
                                                                                                      simultaneous equation models. Renew. Sustain. Energy Rev. 70, 117–132. https://
    The authors declare that they have no known competing financial                                   doi.org/10.1016/J.RSER.2016.11.089.
interests or personal relationships that could have appeared to influence                        Bélaïd, F., Abderrahmani, F., 2013. Electricity consumption and economic growth in
the work reported in this paper.                                                                      Algeria: a multivariate causality analysis in the presence of structural change. Energy
                                                                                                      Pol. 55, 286–295. https://doi.org/10.1016/J.ENPOL.2012.12.004.
                                                                                                 Bergougui, B., 2024. Moving toward environmental mitigation in Algeria: Asymmetric
Data availability                                                                                     impact of fossil fuel energy, renewable energy and technological innovation on CO2
                                                                                                      emissions. Energy Strategy Reviews 51, 101281. doi:10.1016/j.esr.2023.101281.
                                                                                                 Bergougui, B., Aldawsari, M.I., 2024. Asymmetric impact of patents on green
    Data will be made available on request.                                                           technologies on Algeria’s Ecological Future. J. Environ. Manag. 355, 120426
                                                                                                      https://doi.org/10.1016/J.JENVMAN.2024.120426.
References                                                                                       Bergougui, B., Murshed, S.M., 2023. Aggregate and disaggregate impact of natural
                                                                                                      resources on sustainable development: new evidence from the latest institutional
                                                                                                      data. Environmental and Sustainability Indicators 20, 100302. https://doi.org/
Abumunshar, M., Aga, M., Samour, A., 2020. Oil price, energy consumption, and CO2
                                                                                                      10.1016/j.indic.2023.100302.
    emissions in Turkey. New evidence from a bootstrap ARDL test. Energies 13 (21).
                                                                                                 Bergougui, B., Ayad, H., Ghosh, S., Doğan, B., 2024. Do green total factor productivity
    https://doi.org/10.3390/en13215588.
                                                                                                      and digital economy matter for energy transition: evidence from Chinese cities.
Acemoglu, D., Aghion, P., Bursztyn, L., Hemous, D., 2012. The environment and directed
                                                                                                      https://doi.org/10.2139/ssrn.4795205.
    technical change. Am. Econ. Rev. 102 (1), 131–166. https://doi.org/10.1257/
                                                                                                 Bhowmik, R., Syed, Q.R., Apergis, N., Alola, A.A., Gai, Z., 2022. Correction to: applying a
    aer.102.1.131.
                                                                                                      dynamic ARDL approach to the Environmental Phillips Curve (EPC) hypothesis amid
Adebayo, T.S., Acheampong, A.O., 2022. Modelling the globalization-CO2 emission
                                                                                                      monetary, fiscal, and trade policy uncertainty in the USA. Environ. Sci. Pollut.
    nexus in Australia: evidence from quantile-on-quantile approach. Environ. Sci.
                                                                                                      Control Ser. 29 (10), 14929 https://doi.org/10.1007/s11356-021-17227-6.
    Pollut. Control Ser. 29 (7), 9867–9882. https://doi.org/10.1007/s11356-021-
                                                                                                 Bloom, N., 2009. The impact of uncertainty shocks. Econometrica 77, 623–685.
    16368-y.
                                                                                                 Bollinger, B., 2015. Green technology adoption: an empirical study of the Southern
Adebayo, T.S., Oladipupo, S.D., Adeshola, I., Rjoub, H., 2022. Wavelet analysis of impact
                                                                                                      California garment cleaning industry. Quant. Market. Econ. 13 (4), 319–358.
    of renewable energy consumption and technological innovation on CO2 emissions:
                                                                                                      https://doi.org/10.1007/s11129-015-9163-0.
    evidence from Portugal. Environ. Sci. Pollut. Control Ser. 29 (16), 23887–23904.
                                                                                                 Bouznit, M., Pablo-Romero, M., del, P., 2016. CO2 emission and economic growth in
    https://doi.org/10.1007/s11356-021-17708-8.
                                                                                                      Algeria. Energy Pol. 96, 93–104. https://doi.org/10.1016/J.ENPOL.2016.05.036.
Adedoyin, F.F., Zakari, A., 2020. Energy consumption, economic expansion, and CO2
                                                                                                 Braun, E., Wield, D., 1994. Regulation as a means for the social control of technology.
    emission in the UK: the role of economic policy uncertainty. Sci. Total Environ. 738,
                                                                                                      Technol. Anal. Strat. Manag. 6 (3), 259–272. https://doi.org/10.1080/
    140014 https://doi.org/10.1016/J.SCITOTENV.2020.140014.
                                                                                                      09537329408524171.
Ahir, H., Bloom, N., Furceri, D., 2022. The World Uncertainty Index. National bureau of
                                                                                                 Breusch, T.S., 1978. Testing for autocorrelation in dynamic linear models. Aust. Econ.
    economic research.
                                                                                                      Pap. 17 (31), 334–355.
Ahmed, Z., Cary, M., Shahbaz, M., Vo, X.V., 2021. Asymmetric nexus between economic
                                                                                                 Breusch, T.S., Pagan, A.R., 1979. A simple test for heteroscedasticity and random
    policy uncertainty, renewable energy technology budgets, and environmental
                                                                                                      coefficient variation. Econometrica 47 (5), 1287–1294.
    sustainability: evidence from the United States. J. Clean. Prod. 313 (3), 127723
                                                                                                 Brown, R.L., Durbin, J., Evans, J.M., 1975. Techniques for testing the constancy of
    https://doi.org/10.1016/j.jclepro.2021.127723.
                                                                                                      regression relationships over time. J. Roy. Stat. Soc. B 37 (2), 149–192.
Akadiri, S. Saint, Alola, A.A., Uzuner, G., 2020. Economic policy uncertainty and
                                                                                                 Buhari, D.O.Ğ.A.N., Lorente, D.B., Ali Nasir, M., 2020. European commitment to COP21
    tourism: evidence from the heterogeneous panel. Curr. Issues Tourism 23 (20),
                                                                                                      and the role of energy consumption, FDI, trade and economic complexity in
    2507–2514.
                                                                                                      sustaining economic growth. J. Environ. Manag. 273, 111146 https://doi.org/
Al-Mulali, U., Saboori, B., Ozturk, I., 2015. Investigating the environmental Kuznets
                                                                                                      10.1016/J.JENVMAN.2020.111146.
    curve hypothesis in Vietnam. Energy Pol. 76, 123–131. https://doi.org/10.1016/j.
                                                                                                 Can, M., Gozgor, G., 2017. The impact of economic complexity on carbon emissions:
    enpol.2014.11.019.
                                                                                                      evidence from France. Environ. Sci. Pollut. Control Ser. 24 (19), 16364–16370.
Al-Thaqeb, S.A., Algharabali, B.G., 2019. Economic policy uncertainty: a literature
                                                                                                      https://doi.org/10.1007/s11356-017-9219-7.
    review. J. Econ. Asymmetries 20, e00133. https://doi.org/10.1016/J.JECA.2019.
                                                                                                 Canh, N.P., Binh, N.T., Thanh, S.D., Schinckus, C., 2020. Determinants of foreign direct
    E00133.
                                                                                                      investment inflows: the role of economic policy uncertainty. International
Amin, A., Dogan, E., 2021. The role of economic policy uncertainty in the energy-
                                                                                                      Economics 161, 159–172. https://doi.org/10.1016/j.inteco.2019.11.012.
    environment nexus for China: evidence from the novel dynamic simulations method.
                                                                                                 Charfeddine, L., Kahia, M., 2019. Impact of renewable energy consumption and financial
    J. Environ. Manag. 292, 112865 https://doi.org/10.1016/j.jenvman.2021.112865.
                                                                                                      development on CO2 emissions and economic growth in the MENA region: a panel
Amin, N., Shabbir, M.S., Song, H., Farrukh, M.U., Iqbal, S., Abbass, K., 2023. A step
                                                                                                      vector autoregressive (PVAR) analysis. Renew. Energy 139, 198–213. https://doi.
    towards environmental mitigation: do green technological innovation and
                                                                                                      org/10.1016/j.renene.2019.01.010.
    institutional quality make a difference? Technol. Forecast. Soc. Change 190, 122413.
                                                                                                 Charfeddine, L., Kahia, M., 2021. Do information and communication technology and
    https://doi.org/10.1016/J.TECHFORE.2023.122413.
                                                                                                      renewable energy use matter for carbon dioxide emissions reduction? Evidence from
Amri, F., 2017. Carbon dioxide emissions, output, and energy consumption categories in
                                                                                                      the Middle East and North Africa region. J. Clean. Prod. 327, 129410 https://doi.
    Algeria. Environ. Sci. Pollut. Control Ser. 24 (17), 14567–14578. https://doi.org/
                                                                                                      org/10.1016/J.JCLEPRO.2021.129410.
    10.1007/s11356-017-8984-7.
                                                                                                 Chen, Y., Lee, C.C., 2020. Does technological innovation reduce CO2 emissions? Cross-
Anser, M.K., Apergis, N., Syed, Q.R., 2021a. Impact of economic policy uncertainty on
                                                                                                      country evidence. J. Clean. Prod. 263, 121550 https://doi.org/10.1016/J.
    CO2 emissions: evidence from top ten carbon emitter countries. Environ. Sci. Pollut.
                                                                                                      JCLEPRO.2020.121550.
    Control Ser. 28 (23), 29369–29378. https://doi.org/10.1007/s11356-021-12782-4.
                                                                                                 Chen, P.F., Lee, C.C., Zeng, J.H., 2019. Economic policy uncertainty and firm investment:
Anser, M.K., Syed, Q.R., Lean, H.H., Alola, A.A., Ahmad, M., 2021b. Do economic policy
                                                                                                      evidence from the US market. Appl. Econ. 51, 3423–3435.
    uncertainty and geopolitical risk lead to environmental degradation? Evidence from
                                                                                                 Chishti, M.Z., Sinha, A., 2022. Do the shocks in technological and financial innovation
    emerging economies. Sustainability 13 (11). https://doi.org/10.3390/su13115866.
                                                                                                      influence the environmental quality? Evidence from BRICS economies. Technol. Soc.
Ayad, H., Sari-Hassoun, S.E., Usman, M., Ahmad, P., 2023. The impact of economic
                                                                                                      68 (November 2021), 101828 https://doi.org/10.1016/j.techsoc.2021.101828.
    uncertainty, economic growth and energy consumption on environmental
                                                                                                 Danish, Baloch, M.A., Mahmood, N., Zhang, J.W., 2019. Effect of natural resources,
    degradation in MENA countries: fresh insights from multiple thresholds NARDL
                                                                                                      renewable energy and economic development on CO2 emissions in BRICS countries.
    approach. Environ. Sci. Pollut. Control Ser. 30 (1), 1806–1824. https://doi.org/
                                                                                                      Sci. Total Environ. 678, 632–638. https://doi.org/10.1016/j.scitotenv.2019.05.028.
    10.1007/s11356-022-22256-w.
Aydin, M., Degirmenci, T., 2023. The impact of clean energy consumption, green
    innovation, and technological diffusion on environmental sustainability: new


                                                                                            18
B. Bergougui et al.                                                                                                                 Journal of Environmental Management 360 (2024) 121172

Dibiasi, A., Abberger, K., Siegenthaler, M., Sturm, J.E., 2018. The effects of policy              Kirikkaleli, D., 2023. Resource efficiency, energy productivity, and environmental
    uncertainty on investment: evidence from the unexpected acceptance of a far-                        quality in Japan. Resour. Pol. 85, 104006 https://doi.org/10.1016/j.
    reaching referendum in Switzerland. Eur. Econ. Rev. 104, 38–67.                                     resourpol.2023.104006.
Doğan, B., Driha, O.M., Balsalobre Lorente, D., Shahzad, U., 2021. The mitigating effects         Koval, V., Laktionova, O., Atstāja, D., Grasis, J., Lomachynska, I., Shchur, R., 2022.
    of economic complexity and renewable energy on carbon emissions in developed                        Green financial instruments of cleaner production technologies. Sustainability 14
    countries. Sustain. Dev. 29 (1), 1–12. https://doi.org/10.1002/sd.2125.                             (17). https://doi.org/10.3390/su141710536.
EIA, 2020. Country Analysis Brief: Algeria. U.S. Energy Information Administration.                Lanoie, P., Laurent-Lucchetti, J., Johnstone, N., Ambec, S., 2011. Environmental policy,
    Technical report.                                                                                   innovation and performance: new insights on the porter hypothesis. J. Econ. Manag.
Elbadri, M., Bsikre, S., Alamari, O., Balcilar, M., 2023. Nexus between renewable energy                Strat. 20 (3), 803–842. https://doi.org/10.1111/j.1530-9134.2011.00301.x.
    consumption, economic growth, and CO 2 emissions in Algeria: new evidence from                 Leon, L.R., Bergquist, K., Wunsch-Vincent, S., et al., 2017. Measuring Innovation in
    the Fourier-Bootstrap ARDL approach. Nat. Resour. Forum 47 (3), 393–412. https://                   Energy Technologies: Green Patents as Captured by WIPO’s IPC Green Inventory.
    doi.org/10.1111/1477-8947.12292.                                                                    WIPO, vol. 44.
Enders, W., Lee, J., 2012. A unit root test using a fourier series to approximate smooth           Li, W., Lu, C., 2019. The multiple effectiveness of state natural gas consumption
    breaks. Oxf. Bull. Econ. Stat. 74 (4), 574–599. https://doi.org/10.1111/j.1468-                     constraint policies for achieving sustainable development targets in China. Appl.
    0084.2011.00662.x.                                                                                  Energy 235, 685–698. https://doi.org/10.1016/J.APENERGY.2018.11.013.
Esmaeili, P., Rafei, M., Balsalobre-Lorente, D., Adedoyin, F.F., 2023. The role of                 Lin, B., Ma, R., 2022. Green technology innovations, urban innovation environment and
    economic policy uncertainty and social welfare in the view of ecological footprint:                 CO2 emission reduction in China: fresh evidence from a partially linear functional-
    evidence from the traditional and novel platform in panel ARDL approaches.                          coefficient panel model. Technol. Forecast. Soc. Change 176, 121434. https://doi.
    Environ. Sci. Pollut. Control Ser. 30 (5), 13048–13066. https://doi.org/10.1007/                    org/10.1016/j.techfore.2021.121434.
    s11356-022-23044-2.                                                                            Liu, G., Zhang, C., 2020. Economic policy uncertainty and firms’ investment and
Evans, S., Osabuohien, U.R.E., Gitau, C.M.W., 2014. Beyond the environmental Kuznets                    financing decisions in China. China Econ. Rev. 63, 101279.
    curve in Africa: evidence from panel cointegration. J. Environ. Pol. Plann. 16 (4),            Liu, Y., Zhang, Z., 2022. How does economic policy uncertainty affect CO2 emissions? A
    517–538. https://doi.org/10.1080/1523908X.2013.867802.                                              regional analysis in China. Environ. Sci. Pollut. Control Ser. 29 (3), 4276–4290.
Godfrey, L.G., 1978a. Testing against general autoregressive and moving average error                   https://doi.org/10.1007/s11356-021-15936-6.
    models when the regressors include lagged dependent variables. Econometrica 46                 Liu, Y., Zhang, X., Shen, Y., 2024. Technology-driven carbon reduction: analyzing the
    (6), 1293–1301.                                                                                     impact of digital technology on China’s carbon emission and its mechanism.
Godfrey, L.G., 1978b. Testing for heteroscedasticity in dynamic linear models.                          Technol. Forecast. Soc. Change 200, 123124. https://doi.org/10.1016/J.
    Econometrica 46 (6), 1303–1311.                                                                     TECHFORE.2023.123124.
Gollin, D., Morris, M., Byerlee, D., 2005. Technology adoption in intensive post-green             Lorente, D.B., Mohammed, K.S., Cifuentes-Faura, J., Shahzad, U., 2023. Dynamic
    revolution systems. Am. J. Agric. Econ. 87 (5), 1310–1316. http://www.jstor.org/                    connectedness among climate change index, green financial assets and renewable
    stable/3697712.                                                                                     energy markets: novel evidence from sustainable development perspective. Renew.
Goodland, R., 1995. The concept of environmental sustainability. Annu. Rev. Ecol.                       Energy 204, 94–105. https://doi.org/10.1016/J.RENENE.2022.12.085.
    Systemat. 26, 1–24. http://www.jstor.org/stable/2097196.                                       Mealy, P., Teytelboym, A., 2022. Economic complexity and the green economy. Res. Pol.
Gorus, M.S., Aydin, M., 2019. The relationship between energy consumption, economic                     51 (8), 103948 https://doi.org/10.1016/J.RESPOL.2020.103948.
    growth, and CO2 emission in MENA countries: causality analysis in the frequency                Miao, C., Fang, D., Sun, L., Luo, Q., 2017. Natural resources utilization efficiency under
    domain. Energy 168, 815–822. https://doi.org/10.1016/J.ENERGY.2018.11.139.                          the influence of green technological innovation. Resour. Conserv. Recycl. 126,
Granger, Clive W.J., Yoon, Gawon, 2002. Hidden cointegration. In: U of California,                      153–161. https://doi.org/10.1016/J.RESCONREC.2017.07.019.
    Economics Working Paper No. 2002-02. https://doi.org/10.2139/ssrn.313831.                      Mighri, Z., AlSaggaf, M.I., 2023. Asymmetric impacts of renewable energy consumption
Hammar, H., Löfgren, Å., 2010. Explaining adoption of end of pipe solutions and clean                  and economic complexity on economic growth in Saudi Arabia: evidence from the
    technologies—determinants of firms’ investments for reducing emissions to air in                    NARDL model. Environ. Sci. Pollut. Control Ser. 30 (3), 7446–7473. https://doi.org/
    four sectors in Sweden. Energy Pol. 38 (7), 3644–3651. https://doi.org/10.1016/J.                   10.1007/s11356-022-22718-1.
    ENPOL.2010.02.041.                                                                             Narayan, P.K., Narayan, S., 2010. Carbon dioxide emissions and economic growth: panel
Hatemi-j, A., 2012. Asymmetric causality tests with an application. Empir. Econ. 43,                    data evidence from developing countries. Energy Pol. 38 (1), 661–666. https://doi.
    447–456.                                                                                            org/10.1016/j.enpol.2009.09.005.
Hottenrott, H., Rexhäuser, S., Veugelers, R., 2016. Organisational Change and the                 Nazlioglu, S., Gormus, N.A., Soytas, U., 2016. Oil prices and real estate investment trusts
    Productivity Effects of Green Technology Adoption (Issue 206). Heinrich Heine                       (REITs): gradual-shift causality and volatility transmission analysis. Energy Econ. 60,
    University Düsseldorf, Düsseldorf Institute for Competition Economics (DICE). http:                 168–175. https://doi.org/10.1016/j.eneco.2016.09.009.
    //hdl.handle.net/10419/125778.                                                                 Obobisa, E.S., 2022. Achieving 1.5 ◦ C and net-zero emissions target: the role of
Huang, J., Liu, Q., Cai, X., Hao, Y., Lei, H., 2018. The effect of technological factors on             renewable energy and financial development. Renew. Energy 188, 967–985. https://
    China’s carbon intensity: new evidence from a panel threshold model. Energy Pol.                    doi.org/10.1016/J.RENENE.2022.02.056.
    115, 32–42. https://doi.org/10.1016/J.ENPOL.2017.12.008.                                       Olanipekun, I., Olasehinde-Williams, G., Akadiri, S. Saint, 2019. Gasoline prices and
Hussain, M., Arshad, Z., Bashir, A., 2022. Do economic policy uncertainty and                           economic policy uncertainty: what causes what, and why does it matter? Evidence
    environment-related technologies help in limiting ecological footprint? Environ. Sci.               from 18 selected countries. Environ. Sci. Pollut. Control Ser. 26 (15), 15187–15193.
    Pollut. Res. Int. 29 (31), 46612–46619. https://doi.org/10.1007/s11356-022-                         https://doi.org/10.1007/s11356-019-04949-x.
    19000-9.                                                                                       Omay, T, 2015. Fractional Frequency Flexible Fourier Form to approximate smooth
IAEA, 2022. Annual Report for 2022. International Atomic Energy Agency.                                 breaks in unit root testing. Econ Lett 134, 123–126. doi:10.1016/J.ECONLET.2015.0
IEA, 2015. Co2 Emissions from Fuel Combustion Highlight. International Energy Agency,                   7.010.
    Paris. Technical report.                                                                       Ouedraogo, I., Ngoa Tabi, H., Atangana Ondoa, H., Jiya, A.N., 2022. Institutional quality
Jahanger, A., Yu, Y., Hossain, M.R., Murshed, M., Balsalobre-Lorente, D., Khan, U., 2022.               and human capital development in Africa. Econ. Syst. 46 (1), 100937 https://doi.
    Going away or going green in NAFTA nations? Linking natural resources, energy                       org/10.1016/J.ECOSYS.2021.100937.
    utilization, and environmental sustainability through the lens of the EKC hypothesis.          Pan, Y., Chen, Q., Zhang, P., 2020. Does policy uncertainty affect corporate
    Resour. Pol. 79, 103091 https://doi.org/10.1016/J.RESOURPOL.2022.103091.                            environmental information disclosure: evidence from China. Sustain Account Manag
Javed, A., Fuinhas, J.A., Rapposelli, A., 2023a. Asymmetric nexus between green                         Policy J 11, 903–931.
    technology innovations, economic policy uncertainty, and environmental                         Panayotou, T., 1993. Empirical Tests and Policy Analysis of Environmental Degradation
    sustainability: evidence from Italy. Energies 16 (8). https://doi.org/10.3390/                      at Different Stages of Economic Development. International Labour Office, Geneva.
    en16083557.                                                                                         Working Paper WP238, Technology and Employment Programme.
Javed, A., Rapposelli, A., Khan, F., Javed, A., 2023b. The impact of green technology              Pata, U.K., 2021. Renewable and non-renewable energy consumption, economic
    innovation, environmental taxes, and renewable energy consumption on ecological                     complexity, CO2 emissions, and ecological footprint in the USA: testing the EKC
    footprint in Italy: fresh evidence from novel dynamic ARDL simulations. Technol.                    hypothesis with a structural break. Environ. Sci. Pollut. Control Ser. 28 (1), 846–861.
    Forecast. Soc. Change 191, 122534. https://doi.org/10.1016/J.                                       https://doi.org/10.1007/s11356-020-10446-3.
    TECHFORE.2023.122534.                                                                          Porter, M.E., van der Linde, C., 1995. Toward a new conception of the environment-
Jeurissen, R., 2000. John elkington, cannibals with forks: the triple bottom line of 21st               competitiveness relationship. J. Econ. Perspect. 9 (4), 97–118. https://doi.org/
    century business. J. Bus. Ethics 23 (2), 229–231. https://doi.org/10.1023/A:                        10.1257/jep.9.4.97.
    1006129603978.                                                                                 Rafei, M., Esmaeili, P., Balsalobre-Lorente, D., 2022. A step towards environmental
Jiang, Y., Zhou, Z., Liu, C., 2019. Does economic policy uncertainty matter for carbon                  mitigation: how do economic complexity and natural resources matter? Focusing on
    emission? Evidence from US sector level data. Environ. Sci. Pollut. Control Ser. 26                 different institutional quality level countries. Resour. Pol. 78, 102848 https://doi.
    (24), 24380–24394. https://doi.org/10.1007/s11356-019-05627-8.                                      org/10.1016/J.RESOURPOL.2022.102848.
Jiang, T., Yu, Y., Jahanger, A., Balsalobre-Lorente, D., 2022. Structural emissions                Rahman, M.M., Alam, K., Velayutham, E., 2022. Reduction of CO2 emissions: the role of
    reduction of China’s power and heating industry under the goal of “double carbon”:                  renewable energy, technological innovation and export quality. Energy Rep. 8,
    a perspective from input-output analysis. Sustain. Prod. Consum. 31, 346–356.                       2793–2805. https://doi.org/10.1016/J.EGYR.2022.01.200.
    https://doi.org/10.1016/J.SPC.2022.03.003.                                                     Rahmane, A, Benelbar, M, Traich, M, 2021. The Nexus between sustainable energy and
Jordaan, S.M., Romo-Rabago, E., McLeary, R., Reidy, L., Nazari, J., Herremans, I.M.,                    ecological footprint: evidence from Algeria. Sustain Sci Pract Policy 17, 323–333.
    2017. The role of energy technology innovation in reducing greenhouse gas                           https://doi.org/10.1080/15487733.2021.1946298.
    emissions: a case study of Canada. Renew. Sustain. Energy Rev. 78, 1397–1409.                  Ramsey, J.B., 1969. Tests for specification errors in classical linear least-squares
    https://doi.org/10.1016/j.rser.2017.05.162.                                                         regression analysis. J. Roy. Stat. Soc. B 31 (2), 350–371.




                                                                                              19
B. Bergougui et al.                                                                                                                  Journal of Environmental Management 360 (2024) 121172

Razzaq, A., Sharif, A., Afshan, S., Li, C.J., 2023. Do climate technologies and recycling           Sun, Z., Sun, X., Wang, W., Wang, W., 2023. Source reduction strategy or end-of-pipe
     asymmetrically mitigate consumption-based carbon emissions in the United States?                   solution? The impact of green merger and acquisition on environmental investment
     New insights from Quantile ARDL. Technol. Forecast. Soc. Change 186, 122138.                       strategy of Chinese heavily polluting enterprises. J. Clean. Prod. 413, 137530
     https://doi.org/10.1016/J.TECHFORE.2022.122138.                                                    https://doi.org/10.1016/J.JCLEPRO.2023.137530.
Rej, S., Bandyopadhyay, A., Das, N., Hossain, Md E., Islam, Md S., Bera, P., Yeediballi, T.,        Sweidan, O.D., Alwaked, A.A., 2016. Economic development and the energy intensity of
     2023. The asymmetric influence of environmental-related technological innovation                   human well-being: evidence from the GCC countries. Renew. Sustain. Energy Rev.
     on climate change mitigation: what role do FDI and renewable energy play? Environ.                 55, 1363–1369. https://doi.org/10.1016/J.RSER.2015.06.001.
     Sci. Pollut. Control Ser. 30 (6), 14916–14931. https://doi.org/10.1007/s11356-022-             Syed, Q.R., Bouri, E., 2022. Impact of economic policy uncertainty on CO2 emissions in
     23182-7.                                                                                           the US: evidence from bootstrap ARDL approach. J. Publ. Aff. 22 (3), e2595 https://
REPN, 2015. Annual reporting on renewables: ten years of excellence. In: Technical                      doi.org/10.1002/pa.2595.
     Report, REN21: Renewable Energy Policy Network for the 21th Century.                           Syed, Q.R., Bhowmik, R., Adedoyin, F.F., Alola, A.A., Khalid, N., 2022. Do economic
Saidi, S., Hammami, S., 2017. Modeling the causal linkages between transport, economic                  policy uncertainty and geopolitical risk surge CO2 emissions? New insights from
     growth and environmental degradation for 75 countries. Transport. Res. Transport                   panel quantile regression approach. Environ. Sci. Pollut. Control Ser. 29 (19),
     Environ. 53, 415–427. https://doi.org/10.1016/J.TRD.2017.04.031.                                   27845–27861. https://doi.org/10.1007/s11356-021-17707-9.
Salahuddin, M., Gow, J., 2014. Economic growth, energy consumption and CO2                          Tiwari, A.K., Jana, R.K., Roubaud, D., 2019. The policy uncertainty and market volatility
     emissions in Gulf Cooperation Council countries. Energy 73, 44–58. https://doi.org/                puzzle: evidence from wavelet analysis. Finance Res. Lett. 31, 278–284. https://doi.
     10.1016/J.ENERGY.2014.05.054.                                                                      org/10.1016/J.FRL.2018.11.016.
Salahuddin, M., Gow, J., Ozturk, I., 2015. Is the long-run relationship between economic            Usman, M., Makhdum, M.S.A., Kousar, R., 2021. Does financial inclusion, renewable and
     growth, electricity consumption, carbon dioxide emissions and financial                            non-renewable energy utilization accelerate ecological footprints and economic
     development in Gulf Cooperation Council Countries robust? Renew. Sustain. Energy                   growth? Fresh evidence from 15 highest emitting countries. Sustain. Cities Soc. 65,
     Rev. 51, 317–326. https://doi.org/10.1016/J.RSER.2015.06.005.                                      102590 https://doi.org/10.1016/J.SCS.2020.102590.
Salahuddin, M., Alam, K., Ozturk, I., Sohag, K., 2018. The effects of electricity                   Usmani, M.S., Wang, J., Ahmad, N., Iqbal, M., Ahmed, R.I., 2021. Mapping green
     consumption, economic growth, financial development and foreign direct                             technologies literature published between 1995 and 2019: a scientometric review
     investment on CO2 emissions in Kuwait. Renew. Sustain. Energy Rev. 81,                             from the perspective of the manufacturing industry. Environ. Sci. Pollut. Control Ser.
     2002–2010. https://doi.org/10.1016/j.rser.2017.06.009.                                             28 (23), 28848–28864. https://doi.org/10.1007/s11356-021-13473-w.
Samour, A., Baskaya, M.M., Tursoy, T., 2022. The impact of financial development and                Verhoosel, G., 1998. Beyond the unsustainable rhetoric of sustainable development:
     FDI on renewable energy in the uae: a path towards sustainable development.                        transferring environmentally sound technologies. Geo. Int’l Envtl. L. Rev. 11, 49.
     Sustainability 14 (3). https://doi.org/10.3390/su14031208.                                     Wang, Z., Zhu, Y., 2020. Do energy technology innovations contribute to CO2 emissions
SARI HASSOUN, S.E., Mekidiche, M., Guellil, M.S., 2019. Examining the connection                        abatement? A spatial perspective. Sci. Total Environ. 726, 138574 https://doi.org/
     amongst renewable energy, economic growth and carbon dioxide emissions in                          10.1016/j.scitotenv.2020.138574.
     Algeria. EKOIST Journal of Econometrics and Statistics 14 (29), 199–223.                       Wang, Q., Xiao, K., Lu, Z., 2020. Does economic policy uncertainty affect CO2 emissions?
Senadheera, S.S., Withana, P.A., Dissanayake, P.D., Sarkar, B., Chopra, S.S., Rhee, J.H.,               Empirical evidence from the United States. Sustainability 12 (Issue 21). https://doi.
     Ok, Y.S., 2021. Scoring environment pillar in environmental, social, and governance                org/10.3390/su12219108.
     (ESG) assessment. Sustainable Environment 7 (1), 1960097. https://doi.org/                     Wilberforce, T., Olabi, A.G., Sayed, E.T., Elsaid, K., Abdelkareem, M.A., 2021. Progress in
     10.1080/27658511.2021.1960097.                                                                     carbon capture technologies. Sci. Total Environ. 761, 143203 https://doi.org/
Shabir, M., Pazienza, P., De Lucia, C., 2023. Energy innovation and ecological footprint:               10.1016/J.SCITOTENV.2020.143203.
     evidence from OECD countries during 1990–2018. Technol. Forecast. Soc. Change                  Yang, B., Usman, M., jahanger, A., 2021. Do industrialization, economic growth and
     196, 122836. https://doi.org/10.1016/J.TECHFORE.2023.122836.                                       globalization processes influence the ecological footprint and healthcare
She, W., Mabrouk, F., 2023. Impact of natural resources and globalization on green                      expenditures? Fresh insights based on the STIRPAT model for countries with the
     economic recovery: role of FDI and green innovations in BRICS economies. Resour.                   highest healthcare expenditures. Sustain. Prod. Consum. 28, 893–910. https://doi.
     Pol. 82, 103479 https://doi.org/10.1016/J.RESOURPOL.2023.103479.                                   org/10.1016/J.SPC.2021.07.020.
Shin, Y., Yu, B., Greenwood-Nimmo, M., 2014. Modelling asymmetric cointegration and                 Yilanci, V., Bozoklu, S., Gorus, M.S., 2020. Are BRICS countries pollution havens?
     dynamic multipliers in a nonlinear ARDL framework BT. In: Sickles, R.C.,                           Evidence from a bootstrap ARDL bounds testing approach with a Fourier function.
     Horrace, W.C. (Eds.), Festschrift in Honor of Peter Schmidt: Econometric Methods                   Sustain. Cities Soc. 55 https://doi.org/10.1016/J.SCS.2020.102035.
     and Applications. Springer, New York, pp. 281–314. https://doi.org/10.1007/978-1-              Yu, J., Shi, X., Guo, D., Yang, L., 2021. Economic policy uncertainty (EPU) and firm
     4899-8008-3_9.                                                                                     carbon emissions: evidence using a China provincial EPU index. Energy Econ. 94,
Shu, D.Y., Deutz, S., Winter, B.A., Baumgärtner, N., Leenders, L., Bardow, A., 2023. The               105071 https://doi.org/10.1016/j.eneco.2020.105071.
     role of carbon capture and storage to achieve net-zero energy systems: trade-offs              Yu, H., Xu, J., Hu, H., Shi, X., Wang, J., Liu, Y., 2023. How does green technology
     between economics and the environment. Renew. Sustain. Energy Rev. 178, 113246                     innovation influence industrial structure? Evidence of heterogeneous environmental
     https://doi.org/10.1016/J.RSER.2023.113246.                                                        regulation effects. Environ. Dev. Sustain. https://doi.org/10.1007/s10668-023-
Slocum, S.L., 2015. The viable, equitable and bearable in Tanzania. Tourism Manag.                      03369-9.
     Perspect. 16, 92–99. https://doi.org/10.1016/j.tmp.2015.07.012.                                Zaghdoudi, T., Tissaoui, K., Maaloul, M.H., Bahou, Y., Kammoun, N., 2023. Asymmetric
Soytas, U., Sarı, R., 2009. Energy consumption, economic growth, and carbon emissions:                  connectedness between oil price, coal and renewable energy consumption in China:
     challenges faced by an EU candidate member. Ecol. Econ. 68 (6), 1667–1675. https:                  evidence from Fourier NARDL approach. Energy 285, 129416. https://doi.org/
     //EconPapers.repec.org/RePEc:eee:ecolec:v:68:y:2009:i:6:p:1667-1675.                               10.1016/j.energy.2023.129416.
Sun, X., Chen, X., Wang, J., Li, J., 2020. Multi-scale interactions between economic                Zhang, J., Yu, B., Cai, J., Wei, Y.M., 2017. Impacts of household income change on CO2
     policy uncertainty and oil prices in time-frequency domains. N. Am. J. Econ. Finance               emissions: an empirical analysis of China. J. Clean. Prod. 157, 190–200. https://doi.
     51, 100854. https://doi.org/10.1016/j.najef.2018.10.002.                                           org/10.1016/J.JCLEPRO.2017.04.126.




                                                                                               20
